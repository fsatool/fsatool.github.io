
# mpirun -n 1 ../../fsatool analysis deep -i run062_srv_predict.x > log.txt; exit

../run.x "mpirun -n 1 ../../fsatool analysis deep -i run062_srv_predict.x > log.txt" \
"predict.txt freeenergy_1.txt" $0 $1

exit $?

&deep
  task = "srvpredict"
  trajfile = "../procinfo/levelinfo_0.txt"
  recstart = 1, recend = 400, 
  networkfile = "./save/run061_srv_train/network.txt"
/

&freehis
  cvfiles="./predict.txt"
  cvindex=1,2, cvngrid=10,10
  temperature=300.0
/

