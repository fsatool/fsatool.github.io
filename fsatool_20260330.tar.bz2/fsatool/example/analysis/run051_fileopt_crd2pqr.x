../run.x "mpirun -n 1 ../../fsatool analysis fileopt -i run051_fileopt_crd2pqr.x > log.txt" \
"output.pqr" $0 $1

exit $?

&fileopt
  topfile = "../procinfo/1le1.top"
  crdfile = "../procinfo/1le1.crd"
  fileout = "output.pqr" 
/

