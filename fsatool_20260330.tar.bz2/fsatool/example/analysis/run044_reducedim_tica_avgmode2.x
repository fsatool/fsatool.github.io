../run.x "mpirun -n 1 ../../fsatool analysis reducedim -i run044_reducedim_tica_avgmode2.x > log.txt" \
"tica_data.txt tica_eigen.txt freeenergy_1.txt" $0 $1

exit $?

&reducedim
  datafiles="../procinfo/levelinfo_0.txt", skipinitdata=0, skipdata=0
  method="tica"
  ncomponent=2
  lagstep=10
  avgmode=2
/

&freehis
  cvfiles="./tica_data.txt"
  cvindex=1,2, cvngrid=10,10
  temperature=300.0
/

