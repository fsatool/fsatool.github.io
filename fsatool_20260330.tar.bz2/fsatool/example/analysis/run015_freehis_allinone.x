#!/bin/bash

#set -x
infile="freehis.in"
outfile="log.txt"
moldir="./mol/"
execute="mpirun -n 1 ../../fsatool analysis freehis -i $infile -o $outfile"
run="../run.x"
checkfile="freeenergy.txt pot_histogram.txt"

#write the namelistfile
cat > $infile << EOF

&freehis
  cvfiles="../procinfo/levelinfo_0.txt","../procinfo/levelinfo_1.txt", skipdata=1,  skipinitdata=20
  cvindex=1,2, cvngrid=10,10, engrid=10,
  temperature=300.0
  ifallinone = .true.
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
