
# mpirun -n 1 ../../fsatool analysis reducedim -i run043_reducedim_tica_coor.x > log.txt; exit

../run.x "mpirun -n 1 ../../fsatool analysis reducedim -i run043_reducedim_tica_coor.x > log.txt" \
"tica_data.txt tica_eigen.txt" $0 $1

exit $?

&reducedim
!  datafiles="./leveltraj_0.nc", skipinitdata=0, skipdata=1
  datafiles="../procinfo/leveltraj_0.nc", skipinitdata=2, skipdata=1
  method="tica"
  ncomponent=2

  topfile = "../procinfo/1le1.top"
  selectatomtype="calpha"
/
