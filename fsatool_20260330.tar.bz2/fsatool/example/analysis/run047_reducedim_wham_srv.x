../run.x "mpirun -n 1 ../../fsatool analysis reducedim -i run047_reducedim_wham_srv.x > log.txt" \
"predict.txt network.txt freeenergy_1.txt uncertainty.txt" $0 $1

exit $?

&reducedim
  datafiles="../procinfo/levelinfo_0.txt",
            "../procinfo/levelinfo_1.txt"
  skipinitdata=0, skipdata=0
  method="srv"
  ncomponent=2
  lagstep=10
  temperature=300.0 , 305.0
  ikelvin0 = 2
  ifusembar=.false., engrid=5
  iuncertainty = 1
/

&deep
  task = "srvtrain", icudagroup = 0
  trajfile="../procinfo/levelinfo_0.txt",
           "../procinfo/levelinfo_1.txt"
  networkfile = "network.txt"
  cvstart = 1, cvend = 3
  activation = 'sigm'
  recstart = 1, recend = 400
  nepoch = 1, ntau = 10, learnrate = 0.0002, normalfactor = 1.0, normalmode = 0
  layers = 3,3, batchsize = 100
  iuncertainty = 1
  ifnormeigenvec=.true.
/

&freehis
  cvfiles="./predict.txt"
  cvindex=1,2, cvngrid=10,10
  temperature=300.0
/
