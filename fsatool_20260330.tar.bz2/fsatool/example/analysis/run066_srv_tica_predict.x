../run.x "mpirun -n 1 ../../fsatool analysis deep -i run066_srv_tica_predict.x > log.txt" \
"predict.txt freeenergy_1.txt" $0 $1

exit $?

&deep
  task = "srvpredict"
  trajfile = "../procinfo/levelinfo_0.txt"
  recstart = 1, recend = 400, 
  networkfile = "./save/run065_srv_tica/network.txt"
  srvavgmode=1
/

&freehis
  cvfiles="./predict.txt"
  cvindex=1,2, cvngrid=10,10
  temperature=300.0
/

