
# mpirun -n 1 ../../fsatool analysis deep -i run061_srv_train.x > log.txt; exit

../run.x "mpirun -n 1 ../../fsatool analysis deep -i run061_srv_train.x > log.txt" \
"network.txt" $0 $1

exit $?

&deep
  task = "srvtrain"
  trajfile = "../procinfo/levelinfo_0.txt"
  networkfile = "network.txt"
  cvstart = 1, cvend = 3
  batchnum = 8, activation = 'sigm'
  nepoch = 20, ntau = 10, normalmode = 1, normalfactor = 10.0, learnrate = 0.01
  layers = 3,10,10,2, batchsize = 40, recstart = 1, recend = 400
  ifnormeigenvec=.true.
/
