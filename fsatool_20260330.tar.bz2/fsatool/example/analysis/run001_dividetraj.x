mpirun -n 1 ../../fsatool analysis dividetraj -i run001_dividetraj.x > log.txt

    ncdump leveltraj_0.nc > leveltraj_0.nc.txt
    ncdump leveltraj_1.nc > leveltraj_1.nc.txt
    ncdump leveltraj_2.nc > leveltraj_2.nc.txt
    ncdump leveltraj_3.nc > leveltraj_3.nc.txt

    ncdump ../procinfo/leveltraj_0.nc > levelproc_0.nc.txt
    ncdump ../procinfo/leveltraj_1.nc > levelproc_1.nc.txt
    ncdump ../procinfo/leveltraj_2.nc > levelproc_2.nc.txt
    ncdump ../procinfo/leveltraj_3.nc > levelproc_3.nc.txt

    diff levelinfo_0.txt  ../procinfo/levelinfo_0.txt
    diff levelinfo_1.txt  ../procinfo/levelinfo_1.txt
    diff levelinfo_2.txt  ../procinfo/levelinfo_2.txt
    diff levelinfo_3.txt  ../procinfo/levelinfo_3.txt

    diff leveltraj_0.nc.txt  levelproc_0.nc.txt
    diff leveltraj_1.nc.txt  levelproc_1.nc.txt
    diff leveltraj_2.nc.txt  levelproc_2.nc.txt
    diff leveltraj_3.nc.txt  levelproc_3.nc.txt

echo finished

&dividetraj
    procFile = "../procinfo/procinfo_0.txt", "../procinfo/procinfo_1.txt",
               "../procinfo/procinfo_2.txt", "../procinfo/procinfo_3.txt",
    trajFile="../procinfo/proctraj_0.nc", "../procinfo/proctraj_1.nc",
             "../procinfo/proctraj_2.nc", "../procinfo/proctraj_3.nc",
    cvcoorlen=10         !   savtrajstep / printcvstep
    skipinitdata=0       !   skip the initial 20 records in procFile and 2 records in trajFile
/
