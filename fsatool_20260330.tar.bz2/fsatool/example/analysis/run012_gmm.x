
# mpirun -n 2 ../../fsatool analysis gmm -i run012_gmm.x > log.txt; exit

../run.x "mpirun -n 2 ../../fsatool analysis gmm -i run012_gmm.x > log.txt" \
"freeenergy.txt" $0 $1

exit $?

&gmm
!  cvfiles="levelinfo_0.txt", skipdata=1, skipinitdata=0
  cvfiles="../procinfo/levelinfo_0.txt", skipdata=1, skipinitdata=20
  cvindex=1,2, cvngrid=5,5,
  mincomponent=2, maxcomponent=4, increasestep=1
  temperature=300.0, tolerance=0.001, iseed=0
/
