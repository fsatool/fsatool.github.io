#! /bin/bash
# $1 CheckDir; $2 Operation; $3 SkipPrograms(*.x); $4 SkipDirectory
cd $1

# Color variables and horizontal rule
grn="\033[01;32m"; red="\033[01;31m"; yel="\033[01;33m"; std="\033[m"
hr='===================='; hr=${hr}${hr}${hr}
# Prepare arguments for "find" command, search all directories and find all *.x file to execute
# those files to skip are provided in $3, and those directories to skip are provided in $4

splitArray=($4)
for i in "${!splitArray[@]}"; do
    if [ $i -eq 0 ]; then skippath="("; fi
    skippath="${skippath} -path ./${splitArray[i]}"
    if [ $i -ne $((${#splitArray[@]}-1)) ]; then skippath="${skippath} -o"; fi
    if [ $i -eq $((${#splitArray[@]}-1)) ]; then skippath="${skippath} )"; fi
done

if [ "$4" != "" ]; then
  Programs=`ls $(find . $skippath -prune -o -name "run*.x" -print)`
else
  Programs=`ls $(find . -name "run*.x")`
fi
total=0; pass=0; fail=0; skip=0
# "check" Operation uses "PASS" and "Update" Operation uses "UPD"
# "DistUpdate" operation upates all the generated simulation files
# "" Operation is invaild
if [[ $2 == "check" ]]; then
  PASS="${grn}PASS: "
elif [[ $2 == "update" ]] || \
[[ $2 == "DistUpdate" ]]; then
  PASS="${grn}UPD:   "
else
  echo "Operate below are valid:"
  echo "   check update DistUpdate"
  exit
fi

# Set Title, SKIP and FAIL variables; Delete log file
Title="               FSATOOL 2.0: $2 $1"
SKIP="${yel}SKIP: "; FAIL="${red}FAIL: "; rm -f $2.log

# traverse Programs; cycle over the files in Programs
for i in ${Programs}; do let total=total+1
# Skip Programs, check if the file $i is contained in the argument $3 (skip files)
if [[ $3 =~ ${i:2} ]]; then
  echo -e "${SKIP}${i:2}${std}"; let skip=skip+1
else
  # run the command and save logs
  # update counts
  if (cd "`dirname $i`" && ./"`basename $i`" $2) >> $2.log; then
    echo -e "${PASS}${i:2}${std}"; let pass=pass+1
  else
    echo -e "${FAIL}${i:2}${std}" | tee -a $2.log; let fail=fail+1
  fi
fi
done

# Set color variables for hr and title
col=${grn}; if [ ${fail} -ne 0 ]; then col=${red}; fi

# print the info and counts
echo -e ${hr}; echo -e "${Title}"; echo -e ${hr}${std}

echo -e "${PASS}${pass}${std}   ${SKIP}${skip}${std}   ${FAIL}${fail}${std}   Total: ${total}"
#echo -e "${PASS}${pass}${std}"
#echo -e "${SKIP}${skip}${std}"
#echo -e "${FAIL}${fail}${std}"
echo -e ${hr}${std}

# if there are errors, Give the location of log file;
# if not, delete log file
if [[ ${fail} -ne 0 ]]; then
  failmsg="Please Check example/$1/$2.log"
  echo -e ${failmsg}; echo -e ${hr}${std}
else
  rm $2.log
fi
