#!/bin/bash

# mpirun ../../../fsatool msm tpt -i run.x && exit

../../run.x "mpirun ../../../fsatool msm tpt -i run.x" \
"stateinfo.txt statenetflux.txt" $0 $1

exit $?

&tpt
    nstate = 5
    tpmfile = "../all_in_one/save/run1_msm_cv/info/tpm.txt"
    statesfile = "../all_in_one/save/run1_msm_cv/info/states.txt"
    startstate = 1
    endstate = 3
    maxpath = 3
    cvtimestep = 0.02
    cutflux = 0
    lagstep=5
    randomseed=1234
/
