mol addfile replace_prmtop
mol addfile mdcrdfile  first 0 last -1 step 1 waitfor -1
set nframe [molinfo top get numframes]
mol modstyle 0 0 NewCartoon 0.1 2
mol modcolor 0 0 Occupancy
mol modmaterial 0 0 Glass3
mol drawframes 0 0 0:$nframe
color Display Background white
display projection orthographic
display depthcue off
axes location off



proc start_sscache {{molid top}} {
    global sscache_data
    if {! [string compare $molid top]} {
	set molid [molinfo top]
    }
    global vmd_frame
    # set a trace to detect when an animation frame changes
    trace variable vmd_frame($molid) w sscache
    return
}

# remove the trace (need one stop for every start)
proc stop_sscache {{molid top}} {
    if {! [string compare $molid top]} {
	set molid [molinfo top]
    }
    global vmd_frame
    trace vdelete vmd_frame($molid) w sscache
    return
}


# reset the whole secondary structure data cache
proc reset_sscache {} {
    global sscache_data
    if [info exists sscache_data] {
        unset sscache_data
    }
    return
}

# when the frame changes, trace calls this function
proc sscache {name index op} {
    # name == vmd_frame
    # index == molecule id of the newly changed frame
    # op == w
    
    global sscache_data

    # get the protein CA atoms
    set sel [atomselect $index "protein name CA"]

    ## get the new frame number
    # Tcl doesn't yet have it, but VMD does ...
    set frame [molinfo $index get frame]

    # see if the ss data exists in the cache
    if [info exists sscache_data($index,$frame)] {
	$sel set structure $sscache_data($index,$frame)
	return
    }

    # doesn't exist, so (re)calculate it
    vmd_calculate_structure $index
    # save the data for next time
    set sscache_data($index,$frame) [$sel get structure]

    return
}

start_sscache top

mol addrep 0
animate goto need_to_decide
mol modstyle 1 0 NewCartoon
mol modcolor 1 0 ColorID 1
mol modcolor 1 0 Structure
mol modmaterial 1 0 Occupancy

proc allign {{mol top}} {
    set reference [atomselect $mol "all" frame 0]
    set compare [atomselect $mol "all"]
    set num_steps [molinfo $mol get numframes]

    for {set frame 0} {$frame < $num_steps} {incr frame} {
    $compare frame $frame
    set trans_mat [measure fit $compare $reference]
    $compare move $trans_mat
    }
    render Tachyon vmdscene.dat
    exit
}

allign
