import numpy as np
import glob
#import matplotlib.pyplot as plt
import networkx as nx
import argparse
import os
from itertools import product
from networkx.drawing.nx_pydot import write_dot#, pydot_layout

def plot_flux_network(fluxmat,fraction=0.95,direction=True):##fraction=0.6817

    if direction:
        flux = nx.DiGraph()
    else:
        flux = nx.Graph()
    flux.graph["graph"] = {"rankdir": "LR"}

    ## Using the fraction to cut off the small flux
    if fraction != 1.0:
        fratot = np.sum(fluxmat)*fraction
        index = np.searchsorted(np.add.accumulate(np.sort(fluxmat.flatten())[::-1]), fratot)
        cutoff = np.sort(fluxmat.flatten())[::-1][index]
        fluxmat[np.where(fluxmat < cutoff)] = 0.0

    network_get_index(fluxmat)
    flux = network_add_node(flux)
    flux = network_add_edge(flux, fluxmat)
    write_dot(flux, "network.dot")

def network_add_node(flux):
    nodelist = []
    paramdict = {}
    for i in range(nstate):
        if index[i] == True :
            paramdict = {
                "fontsize"   : "20",
                "image"      : pngfile[i],
                "label"      : "<state "+str(i+1)+": P<SUB>f</SUB>="+"{:.2g}".format(pfold[i])+"<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>>",
                "labelfloat" : 'true',
                "labelloc"   : "t",
                "shape"      : "none",
#                "xlabel"     : "<state "+str(i+1)+" P<SUB>f</SUB>="+"{:.2g}".format(pfold[i])+">"
            }
            nodelist.append((i, paramdict))
    flux.add_nodes_from(nodelist)
    return flux

def network_get_index(fluxmat):
    global index
    index=[False for i in range(nstate)]
    for i,j in product(range(nstate), range(nstate)):
        if fluxmat[i, j] > 0:
            index[i] = index[j] = True

def network_add_edge(flux, fluxmat):
    fluxmatwidth = fluxmat/np.sum(fluxmat)
    fluxmatwidth = 15.0*np.sqrt(fluxmatwidth)
    edge = [(i, j, {
        "arrowsize": "{:.4f}".format(max(1.1-0.1*fluxmatwidth[i,j], 0.299-0.0199*fluxmatwidth[i,j])),
        "color"    : "red",
        'fontsize' : "30",
        'label'    : "{:.2e}".format(fluxmat[i, j]),
        'penwidth' : "{:.4f}".format(max(fluxmatwidth[i, j],1.0)),
        'label'    : "{:.2e}".format(fluxmat[i, j]),
        "style"    : "bold"
        })
        for i in range(nstate) for j in range(nstate) if fluxmat[i, j] > 0]
    flux.add_edges_from(edge)
    return flux

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Draw the transition pathway.')
    parser.add_argument('-i',"--input", type=str,
                        help='net flux input file')
    parser.add_argument('-d', "--directory", type=str, default="./",
                        help='The directory where the images has been putted, default is the current directory')
    args = parser.parse_args()
    inputfile = args.input
    directory = args.directory

    data = np.loadtxt(inputfile)
    nstate = data.shape[0]
    pfold=np.loadtxt('pfold.dat')
    pi=np.loadtxt('pi.dat')
    pngfile = sorted(glob.glob(os.path.join(directory,"state*.png")))
    plot_flux_network(data)
