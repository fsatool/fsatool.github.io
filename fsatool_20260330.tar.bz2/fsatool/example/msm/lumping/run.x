#!/bin/bash

# mpirun -n 1 ../../../fsatool msm lumping -i run.x && exit

../../run.x "mpirun -n 1 ../../../fsatool msm lumping -i run.x" \
"lumping.out" $0 $1

exit $?

&lumping
  datafile = "../all_in_one/save/run1_msm_cv/info/tpm.txt"
  nstate=5
  lumpingmethod = "pccaplus"
  randomseed=1234i
/
