#!/bin/bash

# mpirun -n 1 ../../../fsatool msm check -i run.x && exit

../../run.x "mpirun -n 1 ../../../fsatool msm check -i run.x" \
"check.out" $0 $1

exit $?

&check
    checkmethod="timescales", 
    datafile="../all_in_one/save/run1_msm_cv/info/cluster_forcheck.txt",
    lagstart=0
    lagend=20
    nits=5
    cvtimestep=1.0
    randomseed=1234
/
