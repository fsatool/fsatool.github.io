
# rm -rf info; mkdir info; cp save/run1_msm_cv/info/cluster* info; \
# mpirun -n 4 ../../../fsatool msm msm -i run6_msm_read_clusterfile_bace.x && exit

../../run.x "rm -rf info; mkdir info; cp save/run1_msm_cv/info/cluster* info; \
mpirun -n 4 ../../../fsatool msm msm -i run6_msm_read_clusterfile_bace.x" \
"" $0 $1

exit $?

&msm
    ncluster=40
    lagstep=5,
    nstate=5
    ifReadClusterFile=.true.
    lumpingmethod="bace"
    startstate = 1
    endstate = 3
    maxpath=3
    cutflux=0
    randomseed=1234
/
