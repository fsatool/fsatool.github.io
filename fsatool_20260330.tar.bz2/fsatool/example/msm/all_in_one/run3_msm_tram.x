#!/bin/bash

# mpirun -n 2 ../../../fsatool msm -i run3_msm_tram.x && exit

../../run.x "mpirun -n 2 ../../../fsatool msm -i run3_msm_tram.x" \
"info/*" $0 $1

exit $?

&msm
    ncluster=30
    lagstep=5,
    nstate=5
    ifReadClusterFile=.false.
    lumpingmethod="pccaplus"
    startstate = 1
    endstate = 3
    randomseed=1234
/

&trajs
!    cvfiles="../../analysis/levelinfo_0.txt", "../../analysis/levelinfo_1.txt"
    cvfiles="../../procinfo/levelinfo_0.txt", "../../procinfo/levelinfo_1.txt", skipinitdata=20
    temperature=300.0, 340.0
    cvindex=1, 2
    numFilePerLevel=1,1
/
