#!/bin/bash

# mpirun -n 4 ../../../fsatool msm -i run1_msm_cv.x && exit

../../run.x "mpirun -n 1 ../../../fsatool msm -i run1_msm_cv.x" \
"log.txt info/*" $0 $1

exit $?

&msm
    ncluster=40
    lagstep=5,
    nstate=5
    ifReadClusterFile=.false.
    lumpingmethod="pccaplus"
    startstate = 1
    endstate = 3
    maxpath=3
    cutflux=0
   randomseed=1234
/

&trajs
    cvfiles="../../procinfo/levelinfo_0.txt", "../../procinfo/levelinfo_1.txt"
    skipinitdata=20
    cvindex=1, 2
/
