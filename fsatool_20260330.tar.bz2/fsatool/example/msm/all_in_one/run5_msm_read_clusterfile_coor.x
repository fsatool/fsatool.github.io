
# rm -rf info; mkdir info; cp save/run2_msm_coordinate/info/cluster* info; \
# mpirun -n 4 ../../../fsatool msm -i run5_msm_read_clusterfile_coor.x && exit

../../run.x "rm -rf info; mkdir info; cp save/run2_msm_coordinate/info/cluster* info; \
sleep 1; mpirun -n 4 ../../../fsatool msm -i run5_msm_read_clusterfile_coor.x" \
"info/states.txt info/stateindex.txt info/tcm_reduce.txt" $0 $1

exit $?

&msm
    ncluster=6
    lagstep=3
    nstate=2
    ifReadClusterFile=.true.
    clustermethod="coordinate"
    lumpingmethod="pccaplus"
    startstate = 1
    endstate = 2
    randomseed=1234
/

&trajs
    cvfiles="../../procinfo/levelinfo_0.txt", "../../procinfo/levelinfo_1.txt"
    coorfiles="../../procinfo/leveltraj_0.nc", "../../procinfo/leveltraj_1.nc", skipinitdata=2
    cvindex=1, 2
    pdbfile="../../procinfo/model.pdb"
    clusterselecttype="allatom"   ! allatom, backbone, calpha, sidechain, heavyatom, sideheavy
/
