
# rm -rf info; mkdir info; cp save/run1_msm_cv/info/cluster* info; \
# mpirun -n 4 ../../../fsatool msm msm -i run4_msm_read_clusterfile.x && exit

../../run.x "rm -rf info;mkdir info;cp save/run1_msm_cv/info/cluster* info;\
mpirun -n 4 ../../../fsatool msm msm -i run4_msm_read_clusterfile.x" \
"info/states.txt info/stateindex.txt info/tcm_reduce.txt" $0 $1

exit $?

&msm
    ncluster=40
    lagstep=5,
    nstate=5
    ifReadClusterFile=.true.
    lumpingmethod="pccaplus"
    startstate = 1
    endstate = 3
    maxpath=3
    cutflux=0
    randomseed=1234
/
