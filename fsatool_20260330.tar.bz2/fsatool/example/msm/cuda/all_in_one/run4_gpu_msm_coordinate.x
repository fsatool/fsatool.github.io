#!/bin/bash

../../../run.x "mpirun -n 1 ../../../../fsatool msm msm -i run4_gpu_msm_coordinate.x" \
"info/*" $0 $1

exit $?

&msm
    ncluster=6
    lagstep=3
    nstate=2
    ifReadClusterFile=.false.
    clustermethod="coordinate"
    lumpingmethod="pccaplus"
    startstate = 1
    endstate = 2
    
    icuda=1
    randomseed=1234
    ifgpubench=.true.
    kmedoidsmatsize=10
/

&trajs
    cvfiles="../../../procinfo/levelinfo_0.txt","../../../procinfo/levelinfo_1.txt"
    coorfiles="../../../procinfo/leveltraj_0.nc","../../../procinfo/leveltraj_1.nc"
    skipinitdata=2
    cvindex=1, 2
    topfile="../../../procinfo/1le1.top"
    clusterselecttype="allatom"   ! allatom, backbone, calpha, sidechain, heavyatom, sideheavy
/
