#!/bin/bash

#SBATCH -J test2
#SBATCH --nodelist=gpu1
#SBATCH -n 4
#SBATCH -N 1
#SBATCH -p gpu
#SBATCH --gres=gpu:4
#SBATCH --output=log.txt
#SBATCH --error=err.txt

mol=1le1
mpirun ../../fsatool sim -i ./run.x -p ./$mol.top -c ./$mol.crd -r ./$mol.rst

&sim
! for structural minimization
! imin=1, igb=1, icuda=1, optmaxstep=500, optsdpstep=250, printcvstep=10, drms=0.00001 

! for molecular dynamics simulation
  igb=1, icuda=1, lagfreq=5.0, maxstep=4000000, printcvstep=10000, savetrajstep=100000, deltatime=0.002, kelvin0=300.0, iseed=0, ishake=1, itrajtype=3

  ifblocksum=.true.
  task="flood"
/

&flood
  kelvindown=300.0, kelvinup=310.0, exchangestep=500000, biasrep=1
  ss2cv=1,2, ssngrid=100,100, floodingtime=1.0
/

&fsacolvar
  cv_type = 'RMSD'
  cv_min = 0.0, cv_max = 20.0
  cv_i =     5,    16,    40,    54,    78,    93,   107,   114,   136,   160,   174,   198, 0, 
  cv_r = 
     4.018,      3.070,      0.130,      7.760,      3.987,     -0.210, 
    10.051,      7.121,     -0.016,     13.783,      8.078,     -0.453, 
    16.234,     11.064,     -0.078,     20.008,     11.867,     -0.555, 
    22.623,     14.620,      0.220,     26.423,     15.326,     -0.123, 
    28.852,     18.293,      0.361,     32.685,     18.848,      0.081, 
    35.299,     21.673,      0.511,     39.134,     22.254,      0.357, 
/
 
&fsacolvar
  cv_type = 'NCONTACT'
  cv_min = 0.0, cv_max = 9.0
  cv_i =   12,   52,   27,   76,   50,   91,   65,  105,   89,  112,  103,  134,  110,  158,  132,  172,  147,  196, 
  cv_r =  9.0
/

&fsacolvar
  cv_type = 'COM_DIS'
  cv_min=0.0, cv_max=50.0
  cv_i =   1,  0, 218
/
