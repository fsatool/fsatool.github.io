mpirun -np 1 ../../../fsatool sim -i ./opt.x -p ./1le1.top -c ./1le1.crd  && exit

&sim
  imin=1, ipb=1, icuda=0, discut=4.0, optmaxstep=2000, optsdpstep=1000, printcvstep=100, drms=0.00001
/

