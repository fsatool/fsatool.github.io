mpirun -np 2 ../../../../../../fsatool msm  cluster -i run2_gpu.x

exit $?

&cluster
  ncluster=5
  clustermethod="coordinate"
  datafile="ca_traj.pdb"
  pdbfile="ca_topology.pdb"
  clusterselecttype="allatom"
  skipinitdata=0
  trajtype=2
  randomseed=20260714
  clustercycle=100
  kmedoidsmatsize=32
  npicksnap=32
  ifgpubench=.true.
  icuda=1
  ifwriteclustersnaps=.true.
  clusterscore="DBI"
/
