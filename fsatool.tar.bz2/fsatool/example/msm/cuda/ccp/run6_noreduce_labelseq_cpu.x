#!/bin/bash

../../../run.x "mpirun -n 1 ../../../../fsatool msm ccp -i run6_noreduce_labelseq_cpu.x" \
"ccp.out cell_feature_space.txt cell_feature_space_testdata.txt" $0 $1

exit $?

&ccp
  ncluster1=5
  ncluster2=8
  ifgpubench=.true.
  icuda = 0
  reduceType="NOREDUCE"
  ccpfile="../../ccp/mnist_row_sample_col_labelseq.txt"
  randomSeed=25
  dataformat="labelseq"
  lowfeatureratio=0.1
  testfile="../../ccp/mnist_row_sample_col_labelseq.txt"
  knncut=5
  outputmaxfeature=5
/

