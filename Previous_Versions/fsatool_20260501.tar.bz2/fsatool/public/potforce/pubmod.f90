module pubmod
  use ambertop
  use public
  implicit none

  integer :: nowstep, printcvstep, itrajtype, nowikelvin, nkelvin, icuda, ioptmethod, deepmode
  real*8 :: realkelvin, epot, ekin, nowtime, kelvin0, taut, taup, pressure0
  real*8,dimension(:,:),allocatable :: refcoor

  integer :: cvnatom
  integer,dimension(:),allocatable :: cvatoms
  real*8,dimension(:,:),allocatable :: cvatomcoor,cvatomforce

  character*150 :: deepnetworkfile

  character*4 :: resnamelib(23) = [ 'ALA ','ILE ','LEU ','MET ','PHE ','VAL ','PRO ','GLY ', &
        'GLN ','ASN ','HIP ','HIE ','HID ','SER ','THR ','TYR ','CYS ','TRP ', &
        'ARG ','LYS ','ASP ','GLU ','ACME']

  integer,dimension(:),allocatable :: fepmols,fepatommark
  real*8 :: fepvdwalpha,fepelecbeta,fepscale,bindpot
  logical :: iffepsoftcore,ifmartini
  character(len=46),parameter :: pdbformat = "(A6,I5,1X,A4,1X,A4,1X,I4,4X,3F8.3)"

contains

subroutine pubmod_read_pdb_file(pdbfile,atommark,selectcoor,atomnum,atomindex,resnum,resindex,totatomnum,atomname,resname)
  character(len=*),intent(in) :: pdbfile
  character(len=*),intent(in) :: atommark
  real*8,intent(out),dimension(:,:),allocatable,optional :: selectcoor
  integer,intent(out),optional :: atomnum,totatomnum,resnum
  integer,intent(out),dimension(:),allocatable,optional :: atomindex,resindex
  character*4,intent(out),dimension(:),allocatable,optional :: atomname,resname
  integer,parameter :: maxatom=10000
  integer :: tpresindex(maxatom),tpatomindex(maxatom)
  integer :: iopdb,i,j,ierr,iatom,ires,preires,itotatom
  real*8 :: tpcoor(3),tpatomcoor(3,maxatom)
  character*4 :: tpresname,tpatomname,tpatomnames(maxatom)
  character*150 :: line
  character*6 :: tpstring

  iatom=0; ires=0; preires=0; itotatom=0
  tpatomindex=0; tpresindex=0; tpatomcoor=0d0
  call getfreeunit(iopdb)
  open(unit=iopdb,file=pdbfile,action="read")
  do
     read(iopdb,"(a150)",iostat=ierr) line
     if ( line(1:3) == "END" ) exit
     if ( ierr < 0 ) exit
     if ( line(1:6) /= "ATOM  " .and. line(1:6) /= "HETATM" ) cycle
     read(line,pdbformat ) tpstring,i, tpatomname, tpresname, j, tpcoor(1:3)
     if ( j /= preires ) then
        ires=ires+1; tpresindex(ires)=iatom
     end if
     preires=j

     itotatom = itotatom + 1
     if ( itotatom > maxatom ) call errormsg("atom number exceeds the maximum!",int1=itotatom,int2=maxatom)
     tpatomcoor(1:3,itotatom) = tpcoor(1:3)
     if ( tpatomname(1:1) == " " ) then
        tpatomname(1:3) = tpatomname(2:4); tpatomname(4:4)=" "
     end if
     tpatomnames(itotatom) = tpatomname
     call pubmod_search_atoms(atommark,itotatom,tpatomname,iatom,tpatomindex)
  end do
  close(iopdb)
  tpresindex(ires+1)=iatom

  if ( present(totatomnum) ) totatomnum=itotatom
  if ( present(atomnum) ) atomnum=iatom
  if ( present(resnum) ) resnum=ires
  if ( present(resindex) ) then
     if ( allocated(resindex) ) deallocate(resindex)
     allocate(resindex(ires+1)); resindex(1:ires+1) = tpresindex(1:ires+1)
  end if
  if ( present(atomindex) ) then
     if ( allocated(atomindex) ) deallocate(atomindex)
     allocate(atomindex(iatom)); atomindex(1:iatom) = tpatomindex(1:iatom)
  end if
  if ( present(selectcoor) ) then
     allocate(selectcoor(3,iatom))
     do i=1,iatom
        selectcoor(1:3,i)=tpatomcoor(1:3,tpatomindex(i))
     end do
  end if
  if ( present(atomname) ) then
     if ( allocated(atomname) ) deallocate(atomname)
     allocate(atomname(iatom)); atomname(1:iatom) = tpatomnames(1:iatom)
  end if
  if ( present(resname) ) then
     if ( allocated(resname) ) deallocate(resname)
     allocate(resname(iatom)); resname = tpresname
  end if
end subroutine

subroutine pubmod_read_top_file(topfile,atommark,atomnum,atomindex,resnum,resindex,totatomnum)
  use ambertop, only : ambertop_readtopfile,natom,nres,name,simresindex=>resindex
  character(len=*),intent(in) :: topfile
  character(len=*),intent(in) :: atommark
  integer,intent(out),optional :: atomnum,totatomnum,resnum
  integer,intent(out),dimension(:),allocatable,optional :: atomindex,resindex
  integer,dimension(:),allocatable :: tpresindex,tpatomindex
  integer :: i,iatom,ires

  if ( topfile /= "" ) call ambertop_readtopfile(topfile)
  allocate(tpresindex(nres+1),tpatomindex(natom)); tpatomindex=0; tpresindex=0

  if ( present(totatomnum) ) totatomnum = natom
  if ( present(resnum) ) resnum = nres
  iatom=0
  do ires=1,nres
     tpresindex(ires)=iatom
     do i=simresindex(ires)+1,simresindex(ires+1)
        call pubmod_search_atoms(atommark,i,name(i),iatom,tpatomindex)
     end do
  end do
  tpresindex(nres+1)=iatom

  if ( present(atomnum) ) atomnum=iatom
  if ( present(resindex) ) then
     if ( allocated(resindex) ) deallocate(resindex)
     allocate(resindex(nres+1)); resindex(1:nres+1) = tpresindex(1:nres+1)
  end if
  deallocate(tpresindex)
  if ( present(atomindex) ) then
     if ( allocated(atomindex) ) deallocate(atomindex)
     allocate(atomindex(iatom)); atomindex(1:iatom) = tpatomindex(1:iatom)
  end if
  deallocate(tpatomindex)
end subroutine

subroutine pubmod_search_atoms(atommark,i,tpatomname,iatom,tpatomindex)
  character(len=*),intent(in) :: atommark
  integer,intent(in) :: i
  character(len=*),intent(in) :: tpatomname
  integer,intent(inout) :: iatom,tpatomindex(:)
  logical,save :: ifrecord
  integer :: selecttype
  integer,parameter :: MARKALLATOM=1,MARKCALPHA=2,MARKBACKBONE=3,MARKSIDECHAIN=4,MARKHEAVYATOM=5,MARKSIDEHEAVY=6,MARKO5ATOM=7,MARKC5ATOM=8

  if ( atommark(1:7) == "allatom" ) then
     selecttype=MARKALLATOM
  else if ( atommark(1:6) == "calpha" ) then
     selecttype=MARKCALPHA
  else if ( atommark(1:8) == "backbone" ) then
     selecttype=MARKBACKBONE
  else if ( atommark(1:9) == "sidechain" ) then
     selecttype=MARKSIDECHAIN
  else if ( atommark(1:9) == "heavyatom" ) then
     selecttype=MARKHEAVYATOM
  else if ( atommark(1:9) == "sideheavy" ) then
     selecttype=MARKSIDEHEAVY
  else if ( atommark(1:6) == "o5atom" ) then
     selecttype=MARKO5ATOM
  else if ( atommark(1:6) == "c5atom" ) then
     selecttype=MARKC5ATOM
  else
     print *,"wrong atom mark ",atommark
  end if

  select case (selecttype)
  case ( MARKALLATOM )
     iatom = iatom + 1; tpatomindex(iatom)=i
  case ( MARKCALPHA )
     if ( tpatomname == "CA  " ) then
        iatom = iatom + 1; tpatomindex(iatom)=i
     end if
  case ( MARKBACKBONE )
     if ( (tpatomname == "CA  ") .or. (tpatomname =="N   ") .or. (tpatomname =="C   ") ) then
        iatom = iatom + 1; tpatomindex(iatom)=i
     end if
  case ( MARKSIDECHAIN )
     if ( (tpatomname /= "CA  ") .and. (tpatomname /= "N   ") .and. (tpatomname /= "C   ") .and.  &
          (tpatomname /= "O   ") .and. (tpatomname /= "OXT ") .and.    &
          (tpatomname /= "H   ") .and. (tpatomname /= "H1  ") .and. (tpatomname /= "H2  ") .and. (tpatomname /= "H3  ") .and. &
          (tpatomname /= "HA  ") .and. (tpatomname /= "HA1 ") .and. (tpatomname /= "HA2 ") .and. (tpatomname /= "HA3 ") ) then
        iatom = iatom + 1; tpatomindex(iatom)=i
     end if
  case ( MARKHEAVYATOM )
     if ( tpatomname(1:1) /= "H" ) then
        iatom = iatom + 1; tpatomindex(iatom)=i
     end if
  case ( MARKSIDEHEAVY )
     if ( (tpatomname /= "CA  ") .and. (tpatomname /="N   ") .and. (tpatomname /="C   ") .and.  &
          (tpatomname /= "O   ") .and. (tpatomname /="OXT ") .and. (tpatomname(1:1) /= "H")  ) then
        iatom = iatom + 1; tpatomindex(iatom)=i
     end if
  case ( MARKO5ATOM )
     if ( tpatomname == "O5' " ) then
        iatom = iatom + 1; tpatomindex(iatom)=i
     end if
  case ( MARKC5ATOM )
     if ( tpatomname == "C5  " ) then
        iatom = iatom + 1; tpatomindex(iatom)=i
     end if
  case default
     stop "unknow atom mark"
  end select

end subroutine

! calculate the lRMSD of a molecule
subroutine pubmod_lRMSD(ndim,coor1,coor2,rmsd,ifrotatecoor1,rotatemat,tpgrad)
  integer,intent(in) :: ndim
  real*8,intent(inout),dimension(ndim) :: coor1,coor2
  real*8,intent(out) :: rmsd
  logical,intent(in),optional :: ifrotatecoor1
  real*8,intent(out),optional :: rotatemat(3,3)
  real*8,intent(out),optional :: tpgrad(ndim)
  integer :: inum,i,j,idim,info,tpnatom
  real*8 :: tpvec(3),temp,umatrix(3,3),vmatrix(3,3),wvector(3),tpmatrix(3,3),tpvec2(ndim)
  real*8 :: originmatrix(3,3),determinant,dsign,tpcoor(ndim),work(15),rotmatdotdx(3)

  if ( mod(ndim,3) /= 0 ) call errormsg("wrong ndim in lRMSD!")
  tpnatom=ndim/3

  tpvec(1:3)=0.0d0
  do i=1,tpnatom
     tpvec(1:3)=tpvec(1:3)+coor1(3*i-2:3*i)
  end do
  tpvec(1:3)=tpvec(1:3)/dble(tpnatom)
  do i=1,tpnatom
     coor1(3*i-2:3*i)=coor1(3*i-2:3*i)-tpvec(1:3)
  end do

  tpvec(1:3)=0.0d0
  do i=1,tpnatom
     tpvec(1:3)=tpvec(1:3)+coor2(3*i-2:3*i)
  end do
  tpvec(1:3)=tpvec(1:3)/dble(tpnatom)
  do i=1,tpnatom
     coor2(3*i-2:3*i)=coor2(3*i-2:3*i)-tpvec(1:3)
  end do

  originmatrix(:,:)=0.0d0
  do i=1,3
     do j=1,3
        do idim=1,ndim,3
           originmatrix(i,j) = originmatrix(i,j) + coor1(idim+i-1)*coor2(idim+j-1)
        end do
     end do
  end do
  call getMatrixDeterminant(3,originmatrix,determinant); dsign=sign(1.0d0, determinant)

  wvector=0d0; umatrix=0d0; vmatrix=0d0; work=0d0
  call dgesvd("A", "A", 3, 3, originmatrix, 3, wvector, umatrix, 3, vmatrix, 3, work, 15, info)

  tpvec(1:3)=(/1.0d0,1.0d0,dsign/)
  do i=1,3
     do j=1,3
        temp=0.0d0
        do inum=1,3
           temp = temp + vmatrix(inum,i)*tpvec(inum)*umatrix(j,inum)
        end do
        tpmatrix(i,j)=temp
     end do
  end do
  rmsd=0.0d0; tpcoor=0d0
  do idim=1,ndim,3
     do i=1,3
        tpcoor(idim+i-1) = dot_product(tpmatrix(i,1:3),coor1(idim:idim+2))
        rmsd = rmsd + (tpcoor(idim+i-1) - coor2(idim+i-1))**2
     end do
  end do
  rmsd=sqrt(rmsd/dble(tpnatom))
  if ( present(ifrotatecoor1) ) then
     if (ifrotatecoor1 .eqv. .true. ) coor1=tpcoor
  end if
  if ( present(rotatemat) .eqv. .true. ) rotatemat = tpmatrix

  if ( present(tpgrad) ) then
     tpvec2(1:ndim) = 2.0d0*(tpcoor(1:ndim) - coor2(1:ndim))
     tpvec=0d0; tpgrad=0d0
     do i=1,tpnatom
        tpvec(1:3) = tpvec(1:3) + tpvec2(3*i-2:3*i)*2.0d0
     end do
     do j=1,3
        rotmatdotdx(j) = dot_product(tpmatrix(1:3,j), tpvec(1:3))/dble(tpnatom)
     end do
     do i=1,tpnatom
        do j=1,3
           tpgrad(3*(i-1)+j) = dot_product(tpmatrix(1:3,j),tpvec2(3*i-2:3*i)) - rotmatdotdx(j)
        end do
     end do
     tpgrad = 0.5d0/(rmsd*dble(tpnatom))*tpgrad
  end if
end subroutine

subroutine pubmod_get_resindex_resmass_rescharge()
  integer :: iatom,ires,jres,imol,ibond,jbond,i,j,tpnum,tpatommark(natom),tpbondmark(nbond),tpmol
  real*8 :: temp
  logical :: ifhit,ifallchecked

  call pubmod_read_top_file("","calpha",atomnum=numalpha,atomindex=calpha)
  call pubmod_read_top_file("","backbone",atomnum=numback,atomindex=backbone)
  call pubmod_read_top_file("","heavyatom",atomnum=numheavy,atomindex=heavyatoms,resindex=heavyindex)
  call pubmod_read_top_file("","sideheavy",atomnum=numheavysc,atomindex=heavyscatoms,resindex=heavyscindex)
  call pubmod_read_top_file("","o5atom",atomnum=numo5atom,atomindex=o5atoms)
  call pubmod_read_top_file("","c5atom",atomnum=numc5atom,atomindex=c5atoms)

  allocate(heavymass(nres),heavyscmass(nres)); heavymass=0d0; heavyscmass=0d0

! E (kcal/mol) = (1/4*pi*eps0)*(q1*q2/r) = (18.2223*q1)*(18.2223*q2)/r
  allocate(atomcharge(natom)); atomcharge=charge/18.2223d0
  allocate(resmass(nres),rescharge(nres),restype(nres)); resmass=0d0; rescharge=0d0; restype=0
  if ( ipb == 0 ) firstsolventres = nres+1
  do ires=1,nres
     rescharge(ires) = sum(atomcharge(resindex(ires)+1:resindex(ires+1)))
     if ( abs(rescharge(ires)) < 0.01d0 ) rescharge(ires)=0d0
     resmass(ires) = sum(mass(resindex(ires)+1:resindex(ires+1)))
     heavymass(ires) = sum(mass(heavyatoms(heavyindex(ires)+1:heavyindex(ires+1))))
     heavyscmass(ires) = sum(mass(heavyscatoms(heavyscindex(ires)+1:heavyscindex(ires+1))))
  end do

  if ( ipb == 0 ) then
     ! call pubmod_divide_mol_by_deep_first_search(tpatommark, nmol, natom, nbond, bondatom)
     call public_divide_mol_by_disjoint_set_union(tpatommark, nmol, natom, nbond, bondatom)
     allocate(natompermol(nmol)); natompermol=0
     do iatom=1,natom
        i = tpatommark(iatom)
        if ( i == 0 ) call errormsg("unmarked bond atom ",int1=iatom)
        natompermol(i) = natompermol(i) + 1
     end do
  end if
  iatom=0; jres=1; imol=1; tpnum=natompermol(imol)

  allocate(molindex(nmol+1)); molindex=0; iatom=0; ires=0
  do imol=1,nmol
     iatom = iatom + natompermol(imol)
     do
        ires = ires + 1
        if ( iatom == resindex(ires+1) ) then
           molindex(imol+1) = ires; exit
        end if
     end do
  end do
  firstsolventres = 0; if ( firstsolventmol > 0 ) firstsolventres = molindex(firstsolventmol)+1
  firstsolventatom = 0; if ( firstsolventmol > 0 ) firstsolventatom = resindex(firstsolventres)+1

  allocate(atommol(natom)); atommol=0
  allocate(molcharge(nmol),molmass(nmol),molcom(3,nmol)); molcharge=0d0; molmass=0d0; molcom=0d0
  allocate(resmol(nres)); resmol=0
  do imol=1,nmol
     do ires=molindex(imol)+1,molindex(imol+1)
        resmol(ires) = imol
        do iatom=resindex(ires)+1,resindex(ires+1)
           atommol(iatom) = imol
           molmass(imol) = molmass(imol) + mass(iatom)
        end do
     end do
     molcharge(imol) = sum(rescharge(molindex(imol)+1:molindex(imol+1)))
  end do
  totmass = sum(mass)

  allocate(atomres(natom)); atomres = 0
  do ires=1,nres
     do iatom=resindex(ires)+1, resindex(ires+1)
        atomres(iatom) = ires
     end do
  end do

  nbiores = 0; nbioatom = 0
  do imol=1,nmol
     nbiomol=imol; nbioatom = nbioatom + natompermol(imol)
     if ( natompermol(imol) <= 3 ) then
        nbiomol=imol-1; nbioatom = nbioatom - natompermol(imol); exit
     end if
  end do
  nbiores = molindex(nbiomol+1)
  do ibond=1,nbondh
     nbiobondh = ibond
     if ( bondhatom(3*ibond-2) > nbioatom ) then
        nbiobondh = ibond - 1; exit
     end if
  end do
  do ibond=1,nbond
     nbiobond = ibond
     if ( bondatom(3*ibond-2) > nbioatom ) then
        nbiobond = ibond - 1; exit
     end if
  end do

  nmolgroup = 1; tpmol = 1; tpnum = natompermol(tpmol)
  allocate(molgroupindex(nmol+1)); molgroupindex = [0]
  do imol = 2,nmol
     ! check if imol has a different atom number or residue number than tpmol
     if ( (natompermol(imol) /= tpnum) .or. &
          (molindex(imol+1)-molindex(imol)/=molindex(tpmol+1)-molindex(tpmol)) ) then
        nmolgroup = nmolgroup + 1; tpmol = imol; tpnum = natompermol(imol)
        molgroupindex = [molgroupindex,imol-1]
     else
        if ( natompermol(imol) == 1 ) cycle
        ! check if imol has a different sequence than tpmol
        jres = molindex(tpmol)+1
        do ires = molindex(imol)+1,molindex(imol+1)
           if (resname(ires)/=resname(jres)) then
              nmolgroup = nmolgroup + 1; tpmol = imol; tpnum = natompermol(imol)
              molgroupindex = [molgroupindex,imol-1]
              exit
           end if
           jres = jres + 1
        end do
     end if
  end do
  molgroupindex = [molgroupindex,nmol]

  do ires=1,nres
! https://proteinstructures.com/Structure/Structure/amino-acids.html
     select case(resname(ires))
! Hydrophobic (normally buried inside the protein core)
     case ('ALA ','ILE ','LEU ','MET ','PHE ','VAL ','PRO ','GLY ')
        restype(ires)=1
! Polar (form hydrogen bonds as proton donors or acceptors)
     case ('GLN ','ASN ','HIP ','HIE ','HID ','SER ','THR ','TYR ','CYS ','CYX ','TRP ')
        restype(ires)=2
! Charged (side chains often form salt bridges)
     case('ARG ','LYS ','ASP ','GLU ','ACE ','NME ')
        restype(ires)=3
     case ('WAT ')
        restype(ires)=2
     case ('Na+ ','Cl- ','ZN  ','MG  ')
        restype(ires)=3
     case default
!        call errormsg("unknown residue type!",str1=resname(ires))
     end select
  end do

! Kyte-Doolittle hydrophobic scales
! http://resources.qiagenbioinformatics.com/manuals/clcgenomicsworkbench/650/Hydrophobicity_scales.html
! https://www.cgl.ucsf.edu/chimera/docs/UsersGuide/midas/hydrophob.html
! residue radius from Darby and Creighton (1993)
  allocate(reskdscale(nres),resrad(nres)); reskdscale=0d0; resrad=0d0; temp=3d0/(4d0*pi)
  do ires=1,nres
     select case(resname(ires))

     case ('ILE '); reskdscale(ires)=4.5d0; resrad(ires)=(124d0*temp)**(1d0/3d0)
     case ('VAL '); reskdscale(ires)=4.2d0; resrad(ires)=(105d0*temp)**(1d0/3d0)
     case ('LEU '); reskdscale(ires)=3.8d0; resrad(ires)=(124d0*temp)**(1d0/3d0)
     case ('PHE '); reskdscale(ires)=2.8d0; resrad(ires)=(135d0*temp)**(1d0/3d0)
     case ('CYS ','CYX '); reskdscale(ires)=2.5d0; resrad(ires)=(86d0*temp)**(1d0/3d0)
     case ('MET '); reskdscale(ires)=1.9d0; resrad(ires)=(124d0*temp)**(1d0/3d0)
     case ('ALA '); reskdscale(ires)=1.8d0; resrad(ires)=(67d0*temp)**(1d0/3d0)

     case ('GLY '); reskdscale(ires)=-0.4d0; resrad(ires)=(48d0*temp)**(1d0/3d0)
     case ('THR '); reskdscale(ires)=-0.7d0; resrad(ires)=(93d0*temp)**(1d0/3d0)
     case ('SER '); reskdscale(ires)=-0.8d0; resrad(ires)=(73d0*temp)**(1d0/3d0)
     case ('TRP '); reskdscale(ires)=-0.9d0; resrad(ires)=(163d0*temp)**(1d0/3d0)
     case ('TYR '); reskdscale(ires)=-1.3d0; resrad(ires)=(141d0*temp)**(1d0/3d0)
     case ('PRO '); reskdscale(ires)=-1.6d0; resrad(ires)=(90d0*temp)**(1d0/3d0)

     case ('HIS ','HID ','HIP ','HIE '); reskdscale(ires)=-3.2d0; resrad(ires)=(118d0*temp)**(1d0/3d0)
     case ('GLU '); reskdscale(ires)=-3.5d0; resrad(ires)=(109d0*temp)**(1d0/3d0)
     case ('GLN '); reskdscale(ires)=-3.5d0; resrad(ires)=(114d0*temp)**(1d0/3d0)
     case ('ASP '); reskdscale(ires)=-3.5d0; resrad(ires)=(91d0*temp)**(1d0/3d0)
     case ('ASN '); reskdscale(ires)=-3.5d0; resrad(ires)=(96d0*temp)**(1d0/3d0)
     case ('LYS '); reskdscale(ires)=-3.9d0; resrad(ires)=(135d0*temp)**(1d0/3d0)
     case ('ARG '); reskdscale(ires)=-4.5d0; resrad(ires)=(148d0*temp)**(1d0/3d0)

     end select
  end do

end subroutine

! read a coordinate file
subroutine pubmod_read_crdfile(tpfilename,tpcoor,iftrajformat)
  character(len=*),intent(in) :: tpfilename
  logical,intent(in),optional :: iftrajformat
  real*8,intent(out) :: tpcoor(:,:)
  integer :: iofile
  logical :: tpif

  call getfreeunit(iofile); open(file=tpfilename, unit=iofile, action="read")

  if ( present(iftrajformat) ) tpif = iftrajformat
  if ( tpif ) then
     read(iofile,*)
     read(iofile,"(10f8.3)") tpcoor
  else
     read(iofile,*); read(iofile,*)
     read(iofile,"(6f12.7)") tpcoor
     if ( ipb > 0 ) read(iofile,*) pmecell(1),pmecell(2),pmecell(3),cellalpha,cellbeta,cellgamma
  end if
  close(iofile)
end subroutine

subroutine pubmod_read_traj(tpfilename,tpnatom,tpcoor,ierr)
  use netcdf_func, only: netcdf_format,Netcdf_read_traj
  character(len=*),intent(in) :: tpfilename
  integer,intent(in) :: tpnatom
  real*8,intent(out) :: tpcoor(3,tpnatom)
  integer,intent(out) :: ierr

  if (netcdf_format(tpfilename)) then
     call Netcdf_read_traj(tpfilename, tpnatom, tpcoor, ierr)
     if ( ierr < 0 ) call netcdf_read_traj("notfile", tpnatom, tpcoor, ierr)
  else
     call pubmod_read_traj_ascii(tpfilename, tpnatom, tpcoor, ierr)
     if ( ierr < 0 ) call pubmod_read_traj_ascii("notfile", tpnatom, tpcoor, ierr)
  end if
end subroutine

! read a trajectory in ascii format
subroutine pubmod_read_traj_ascii(tpfilename, tpnatom, tpcoor, ierr)
  character(len=*),intent(in) :: tpfilename
  integer,intent(in) :: tpnatom
  real*8,intent(out) :: tpcoor(3,tpnatom)
  integer,intent(out) :: ierr
  integer,save :: iotraj,trajntotatom,trajipb
  character*100,save :: prefilename
  real*8,dimension(:,:),allocatable,save :: tptpcoor
  character*10 :: tpstr
  logical :: ifexist

  if ( trim(tpfilename) /= trim(prefilename) ) then
     if (iotraj > 0) then
        close(iotraj); iotraj = 0
     end if
     prefilename=trim(tpfilename)
     inquire(file=tpfilename,exist=ifexist); if ( ifexist .eqv. .false. ) return
     call getfreeunit(iotraj); open(file=tpfilename, unit=iotraj, action="read"); trajntotatom = 0
     read(iotraj,"(a11,i10,5x,a14,f8.3,5x,a9,i2)") tpstr,trajntotatom,tpstr,deltatime,tpstr,trajipb
     if ( allocated(tptpcoor) ) deallocate(tptpcoor)
     if ( trajntotatom == 0 ) trajntotatom = tpnatom 
     allocate(tptpcoor(3,trajntotatom)); tptpcoor = 0d0
  end if
  read(iotraj,"(10f8.3)",iostat=ierr) tptpcoor
  if ( ierr < 0 ) return
  tpcoor(1:3,1:tpnatom) = tptpcoor(1:3,1:tpnatom)
  if ( trajipb > 0 ) read(iotraj,"(6f8.3)") pmecell,cellalpha,cellbeta,cellgamma
end subroutine

subroutine pubmod_read_multitraj(tpfilename,tpnatom,tpcoor,ierr)
  use netcdf_func, only: netcdf_format,netcdf_read_multitraj
  character(len=*),intent(in) :: tpfilename(:)
  integer,intent(in) :: tpnatom
  real*8,intent(out) :: tpcoor(3,tpnatom,size(tpfilename))
  integer,intent(out) :: ierr

  if (netcdf_format(tpfilename(1))) then
     call netcdf_read_multitraj(tpfilename, tpnatom, tpcoor, ierr)
     if ( ierr < 0 ) call netcdf_read_multitraj(["notfile"], tpnatom, tpcoor, ierr)
  else
     call pubmod_read_multitraj_ascii(tpfilename, tpnatom, tpcoor, ierr)
     if ( ierr < 0 ) call pubmod_read_multitraj_ascii(["notfile"], tpnatom, tpcoor, ierr)
  end if
end subroutine

subroutine pubmod_read_multitraj_ascii(tpfilename, tpnatom, tpcoor, ierr)
  character(len=*),intent(in) :: tpfilename(:)
  integer,intent(in) :: tpnatom
  real*8,intent(out) :: tpcoor(3,tpnatom,size(tpfilename))
  integer,intent(out) :: ierr
  integer,dimension(:),allocatable,save :: iotraj,trajntotatom,trajipb
  character*100,dimension(:),allocatable,save :: prefilename
  integer :: ifile
  real*8,dimension(:,:),allocatable,save :: tptpcoor
  character*10 :: tpstr
  logical :: ifexist,ifopennew

  ifopennew = .false.
  if ( .not. allocated(prefilename) ) then
     ifopennew=.true.
  else
     if ( trim(tpfilename(1)) /= trim(prefilename(1)) ) ifopennew=.true.
  end if

  if ( ifopennew .eqv. .true. ) then

     if ( allocated(prefilename) ) then
        do ifile = 1, size(prefilename)
           if ( iotraj(ifile) > 0 ) close(iotraj(ifile))
        end do
        deallocate(prefilename,iotraj,trajntotatom,trajipb)
        if ( allocated(tptpcoor) ) deallocate(tptpcoor)
     end if

     allocate(prefilename(size(tpfilename)),iotraj(size(tpfilename)),trajntotatom(size(tpfilename)),trajipb(size(tpfilename)))

     prefilename = tpfilename
     do ifile = 1, size(tpfilename)
        inquire(file=tpfilename(ifile),exist=ifexist)
        if ( ifexist .eqv. .false. ) return

        call getfreeunit(iotraj(ifile))
        open(file=tpfilename(ifile), unit=iotraj(ifile), action="read")
        read(iotraj(ifile),"(a11,i10,5x,a14,f8.3,5x,a9,i2)") tpstr,trajntotatom(ifile),tpstr,deltatime,tpstr,trajipb(ifile)
     end do
     allocate(tptpcoor(3,maxval(trajntotatom))); tptpcoor = 0d0
  end if

  do ifile = 1, size(tpfilename)
     read(iotraj(ifile),"(10f8.3)",iostat=ierr) tptpcoor(1:3,1:trajntotatom(ifile))
     if ( ierr < 0 ) return
     if ( tpnatom > trajntotatom(ifile) ) then
        tpcoor(1:3,1:trajntotatom(ifile),ifile) = tptpcoor(1:3,1:trajntotatom(ifile))
     else
        tpcoor(1:3,1:tpnatom,ifile) = tptpcoor(1:3,1:tpnatom)
     end if
     if ( trajipb(ifile) > 0 ) read(iotraj(ifile),"(6f8.3)") pmecell,cellalpha,cellbeta,cellgamma
  end do
end subroutine

! read a restart file
subroutine pubmod_read_restartfile(rstfilename)
  use netcdf_func, only: netcdf_format
  character(len=*),intent(in) :: rstfilename
  integer :: iofile,iatom,iaxis
  logical :: ifexist

  inquire(file=rstfilename, exist=ifexist)
  if ( ifexist .eqv. .false. ) return! call errormsg("restart file does not exist!")

  if ( netcdf_format(rstfilename) ) then
     call pubmod_read_restartfile_netcdf(rstfilename)
  else
     call pubmod_read_restartfile_ascii(rstfilename)
  end if
end subroutine

! read a restart file in ASCII format
subroutine pubmod_read_restartfile_ascii(rstfilename)
  character(len=*),intent(in) :: rstfilename
  integer :: iofile,iatom,iostat

  call getfreeunit(iofile); open(unit=iofile,file=rstfilename,action="read")
  read(iofile,*)
  read(iofile,"(i5,5e15.7)", iostat=iostat) iatom,nowtime
  if ( natom /= iatom ) call errormsg("atom number is inconsistent in restart file ",int1=iatom,int2=natom)

  read(iofile,"(6f12.7)") nowcoor
  read(iofile,"(6f12.7)") nowvel
  nowvel = nowvel/timescale
  if ( ipb > 0 ) read(iofile,*) pmecell(1),pmecell(2),pmecell(3),cellalpha,cellbeta,cellgamma
  close(iofile)
end subroutine

!! read a restart file in NETCDF format
subroutine pubmod_read_restartfile_netcdf(rstfilename)
  use netcdf_func
  character(len=*),intent(in) :: rstfilename
  integer :: tpncid, tpcoorid, tpvelid, iatom, tpcellLengthVID, tpcellAngleVID
  integer,save :: errorformat=0
  real*8 :: tpangle(3)

  call Netcdf_OpenFile(rstfilename, tpncid, coorVID=tpcoorid, velocityVID=tpvelid, &
                       cellLengthVID=tpcellLengthVID, cellAngleVID=tpcellAngleVID)
  call Netcdf_GetDimension(tpncid, "atom", iatom)
  if ( natom /= iatom ) call errormsg("atom number is inconsistent in restart file ",int1=iatom,int2=natom)
  call Netcdf_ReadVariables(tpncid, tpcoorid, nowcoor)
  call Netcdf_ReadVariables(tpncid, tpvelid, nowvel)
  if (ipb > 0) then
     if ( tpcellLengthVID == -1 ) call errormsg("restartfile do not have cell information.")
     call Netcdf_ReadVariables(tpncid, tpcellLengthVID, pmecell)
     call Netcdf_ReadVariables(tpncid, tpcellAngleVID, tpangle)
     cellalpha=tpangle(1); cellbeta=tpangle(2); cellgamma=tpangle(3)
  end if
  call Netcdf_CloseFile(tpncid)
end subroutine

subroutine pubmod_write_pdbmovie(tpncv,tpcvvec,tpcoor,ifpqr,tpiofile,tpindex,ifbiomol,tpadddata)
  integer,intent(in),optional :: tpncv,tpiofile,tpindex
  real*8,intent(in),optional :: tpcvvec(tpncv)
  real*8,intent(in),optional :: tpcoor(:,:),tpadddata(:,:)
  logical,intent(in),optional :: ifpqr,ifbiomol
  integer,save :: iomovie
  character*150 :: tpfilename
  integer :: i,iatom,ires,endres,endatom
  real*8 :: tpvec(3),tpcrd(3,natom)

  if ( .not. present(tpiofile) ) then
     if ( iomovie == 0 ) then
        call getfreeunit(iomovie)
        write(tpfilename,"(i4)") procid; tpfilename=adjustl(tpfilename)
        tpfilename="procinfo/movie_"//trim(tpfilename)//".pdb"
        open(file=tpfilename, unit=iomovie, action="write")
     end if
  else
     iomovie=tpiofile
  end if

  if ( present(tpcoor) ) then
     tpcrd = tpcoor
  else
     tpcrd = nowcoor
  end if

  endres = nres; endatom = natom
  if ( present(ifbiomol) ) then
     if ( ifbiomol .eqv. .true. ) then
        endres = molindex(nbiomol+1); endatom = resindex(endres+1)
     end if
  end if
  
  if ( ipb == 0 .or. endatom /= natom ) then
     do i=1,3; tpvec(i) = sum(tpcrd(i,1:endatom)); end do
     tpvec(1:3) = tpvec(1:3)/dble(endatom)
     do i=1,endatom
        tpcrd(1:3,i) = tpcrd(1:3,i) - tpvec(1:3)
     end do
  end if

  do ires=1,endres
     do iatom=resindex(ires)+1,resindex(ires+1)
        if ( present(ifpqr) ) then
           if ( ifpqr .eqv. .true. ) then
              if ( present(tpadddata) .eqv. .false. ) then
                 write(iomovie,"(a6,i5,1x,a4,1x,a3,1x,a1,i4,4x,3f8.3,2f8.4)")   &
                    "ATOM  ",iatom,name(iatom)(1:4),resname(ires)(1:3)," ",ires,tpcrd(1:3,iatom),atomcharge(iatom),radius(iatom)
              else
                 write(iomovie,"(a6,i5,1x,a4,1x,a3,1x,a1,i4,4x,3f8.3,*(f8.4))")   &
                    "ATOM  ",iatom,name(iatom)(1:4),resname(ires)(1:3)," ",ires,tpcrd(1:3,iatom),atomcharge(iatom),radius(iatom),tpadddata(:,iatom)
              end if
           end if
        else
           write(iomovie,"(a6,i5,1x,a4,1x,a3,1x,a1,i4,4x,3f8.3)")   &
               "ATOM  ",iatom,name(iatom)(1:4),resname(ires)(1:3)," ",ires,tpcrd(1:3,iatom)
        end if
     end do
     if ( (ires<nres) .and. (resmol(ires) /= resmol(ires+1)) ) write(iomovie,"(a,i4)") "TER ",resmol(ires)
  end do
  if ( present(tpncv) ) then
     if ( tpncv <= 10 ) then
        write(iomovie,"(a4,f10.3,10f7.2)") "END ",nowtime,tpcvvec(1:tpncv); flush(iomovie)
     else
        write(iomovie,"(a4,f10.3,10f7.2)") "END ",nowtime,tpcvvec(1:10); flush(iomovie)
     end if
  else
     if ( present(tpindex) ) then
        write(iomovie,"(a4,i10)") "END ",tpindex
     else
        write(iomovie,"(a4)") "END "
     end if
  end if
end subroutine

subroutine pubmod_molecule_com()
  integer :: imol,ires,iatom
  real*8 :: avgcoor(3)

  do imol=1,nmol
     avgcoor(:) = 0.d0
     do ires=molindex(imol)+1,molindex(imol+1)
        do iatom=resindex(ires)+1,resindex(ires+1)
           avgcoor(:) = avgcoor(:) + mass(iatom)*nowcoor(:,iatom)
        end do
     end do
     molcom(1:3,imol) = avgcoor(:)/molmass(imol)
  end do
end subroutine

subroutine pubmod_set_twowaybonds()
  integer :: iatom,ibond,i1,i2

  allocate(twowaybondindex(natom+1),twowaybonds(nbond*2))
  ntwowaybond = 0; twowaybondindex = 0; twowaybonds = 0
  do iatom = 1, natom
     do ibond = 1, nbond
        i1 = bondatom(3*ibond-2); i2 = bondatom(3*ibond-1)
        if ( iatom == i1 ) then
           ntwowaybond = ntwowaybond + 1; twowaybonds(ntwowaybond) = i2
        else if ( iatom == i2 ) then
           ntwowaybond = ntwowaybond + 1; twowaybonds(ntwowaybond) = i1
        end if
     end do
     twowaybondindex(iatom+1) = ntwowaybond
  end do
end subroutine

subroutine pubmod_get_getinerialaxis(tpcoor,tpmass,tpinerialaxis)
  real*8,intent(in) :: tpcoor(3,natom),tpmass(natom)
  real*8,intent(out) :: tpinerialaxis(3,3)
  real*8 ::  centroid(3), cencoor(3, natom), imomatrix(6)
  real*8 :: x2, y2, z2, xy, xz, yz, totmass,tptpmass,tpeigenval(3)
  integer :: N, liwork, lwork, LDZ, info,iatom
  integer, allocatable :: iwork(:)
  real*8, allocatable :: Z(:, :), work(:)
  character(len=1) :: JOBZ, UPLO

  totmass = 0.0d0; centroid = 0.0d0
  do iatom = 1, natom
     totmass = totmass + mass(iatom)
     centroid(:) = centroid(:) + tpmass(iatom)*tpcoor(:, iatom)
  end do
  centroid = centroid/totmass
  do iatom = 1, natom
     cencoor(:, iatom) = tpcoor(:, iatom) - centroid(:)
  end do

  imomatrix = 0.0d0
  do iatom = 1, natom
     tptpmass = tpmass(iatom)
     x2 = cencoor(1, iatom)*cencoor(1, iatom); y2 = cencoor(2, iatom)*cencoor(2, iatom); z2 = cencoor(3, iatom)*cencoor(3, iatom)
     xy = cencoor(1, iatom)*cencoor(2, iatom); xz = cencoor(1, iatom)*cencoor(3, iatom); yz = cencoor(2, iatom)*cencoor(3, iatom)

     imomatrix(1) = imomatrix(1) + tptpmass*(y2 + z2) ! Ixx
     imomatrix(3) = imomatrix(3) + tptpmass*(x2 + z2) ! Iyy
     imomatrix(6) = imomatrix(6) + tptpmass*(x2 + y2) ! Izz

     imomatrix(2) = imomatrix(2) - tptpmass*xy        ! Ixy
     imomatrix(4) = imomatrix(4) - tptpmass*xz        ! Ixz
     imomatrix(5) = imomatrix(5) - tptpmass*yz        ! Iyz
  end do

  N = 3; LDZ = 3; JOBZ = 'V'; UPLO = 'U'; lwork = 2*N*N + 6*N + 1; liwork = 3 + 5*N
  allocate (Z(N, N), work(lwork), iwork(liwork))
  call dspevd(JOBZ, UPLO, N, imomatrix, tpeigenval, Z, LDZ, work, lwork, iwork, liwork, info)
  if (info /= 0) call errormsg('dspevd info', int1=info)
  tpinerialaxis = Z
  deallocate (Z, work, iwork)

  do n = 1, 3
     tpeigenval(:) = tpinerialaxis(:,n); tpinerialaxis(:,n) = tpinerialaxis(:,n)/sqrt(dot_product(tpeigenval(:),tpeigenval(:)))
  end do

end subroutine

end module
