! transform distance vector into the periodic box system

! standard expression

! tpvec(1) = dot_product(dcoor(1:3),mat_car2frac_d(1,1:3))
! tpvec(2) = dot_product(dcoor(1:3),mat_car2frac_d(2,1:3))
! tpvec(3) = dot_product(dcoor(1:3),mat_car2frac_d(3,1:3))
! tpvec(1) = floor(tpvec(1)+0.5)
! tpvec(2) = floor(tpvec(2)+0.5)
! tpvec(3) = floor(tpvec(3)+0.5)
! dcoor(1) = dcoor(1) - dot_product(tpvec(1:3),mat_frac2car_d(1,1:3))
! dcoor(2) = dcoor(2) - dot_product(tpvec(1:3),mat_frac2car_d(2,1:3))
! dcoor(3) = dcoor(3) - dot_product(tpvec(1:3),mat_frac2car_d(3,1:3))


! simplified expression used in OpenMM

dcoor(1) = dcoor(1) - floor(dcoor(3)*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(1,3)
dcoor(2) = dcoor(2) - floor(dcoor(3)*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(2,3)
dcoor(3) = dcoor(3) - floor(dcoor(3)*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(3,3)

dcoor(1) = dcoor(1) - floor(dcoor(2)*mat_car2frac_d(2,2)+0.5)*mat_frac2car_d(1,2)
dcoor(2) = dcoor(2) - floor(dcoor(2)*mat_car2frac_d(2,2)+0.5)*mat_frac2car_d(2,2)

dcoor(1) = dcoor(1) - floor(dcoor(1)*mat_car2frac_d(1,1)+0.5)*mat_frac2car_d(1,1)

