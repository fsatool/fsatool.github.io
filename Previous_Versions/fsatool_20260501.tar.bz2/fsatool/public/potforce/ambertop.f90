module ambertop
  use public
  implicit none
  integer :: natom,nres,nbond,nangle,ndihedral,nnb14,nmol,ndihegroup
  integer :: nvdwtype,nbondh,nbondnoh,nangleh,nanglenoh,ndiheh,ndihenoh,nhparm,nparm
  integer :: nnb,nbonda,nanglea,ndihea,nbondtype,nangletype,ndihetype,natyp,nhbtype
  integer :: ifpert,nbper,ngper,ndper,mbper,mgper,mdper,nmaxresatom,ifcap,nextra,ncopy
  integer :: nbiobond,nbiobondh,nbioatom,nbiomol,nbiores,nsolventmol,endsoluteres,firstsolventres
  integer :: firstsolventmol,firstsolventatom,lastatombeforewatcap,ipol,ndof
  real*8 :: oldbeta,cutcap,xcap,ycap,zcap,totmass
  real*8 :: ebond,eangle,edihe,evdw,eelec,egb,egbsa,ehb,eelec14,evdw14
  real*8 :: eself,edirec,erecip,ecorr,evdwdirec,evdwcorr
  real*8,dimension(:),allocatable :: charge,mass,radius,bondforceconst,bondeqval,angleforceconst, &
          angleeqval,diheforceconst,diheperiod,dihephase,scale14elec,scale14vdw,solty,vdwacoef,vdwbcoef, &
          hbondacoef,hbondbcoef,hbondcut,atompolar,cosphase,sinphase,screen,vdweps,vdwsigma,vdwlambda
  integer,dimension(:),allocatable :: atomicnumber,typeindex,resindex, &
         nexcludedatoms,bondh,bondnoh,angleh,anglenoh,diheh,dihenoh,excludedatomlist, &
         natompermol,nonbondedparmindex,diheatom,bondatom,angleatom,bondhatom,dihegroupindex
  integer,dimension(:,:),allocatable :: nonbond14
  character*4,dimension(:),allocatable :: name,resname,type,treechainclass
  character*80 :: radiusset

  integer :: numalpha,numback,numheavy,numheavysc,nmolgroup,numo5atom,numc5atom
  integer,dimension(:),allocatable :: heavyscindex,heavyindex,heavyatoms,heavyscatoms
  integer,dimension(:),allocatable :: calpha,molindex,backbone,restype,resstate,molgroupindex
  integer,dimension(:),allocatable :: o5atoms, c5atoms
  real*8,dimension(:),allocatable :: heavymass,heavyscmass
  real*8,dimension(:),allocatable :: atomcharge,rescharge,resmass,resrad,reskdscale,molcharge,molmass

  integer :: igb,ipb,ishake,igbsa,ioct,iseed,respastep
  real*8 :: saltcon,deltatime,surften,lagfreq,discut,vellimit,forcelimit
  real*8,dimension(:,:),allocatable :: nowcoor,nowvel,nowforce,prevel,molcom
  logical :: ifcalfrc,ifcalpot,ifblocksum

  integer :: ntwowaybond
  integer,dimension(:),allocatable :: twowaybonds,twowaybondindex

  ! variables for PME
  integer,dimension(:),allocatable :: atommol,resmol,atomres
  real*8 :: cellalpha,cellbeta,cellgamma,pmecell(3),cellvolume,ewaldtol=0d0

  ! variables for LJ-PME
  integer :: iljpme

contains

subroutine ambertop_readtopfile(topfilename)
  character(len=*),intent(in) :: topfilename
  integer :: iotop,i,j,k,l,idihe,iatom,index,itype,iangle,ibond,tpatomarray(4)
  integer,dimension(:,:),allocatable :: tparray
  character*50 :: tpstring,tpformat
  logical :: ifexist

  inquire(file=topfilename, exist=ifexist)
  if ( ifexist .eqv. .false. ) then
     print *,"topology file does not exist: ",trim(topfilename); stop
  end if

  call getfreeunit(iotop)
  open(unit=iotop,file=topfilename,action="read")

!NATOM NTYPES NBONH MBONA NTHETH MTHETA NPHIH MPHIA NHPARM NPARM
!NNB NRES NBONA NTHETA NPHIA NUMBND NUMANG NPTRA NATYP NPHB
!IFPERT NBPER NGPER NDPER MBPER MGPER MDPER IFBOX NMXRS IFCAP
!NUMEXTRA NCOPY
  call pick_arrays("%FLAG POINTERS")
  read(iotop,tpformat)    &
        natom,nvdwtype,nbondh,nbondnoh,nangleh,nanglenoh,ndiheh,ndihenoh,nhparm,nparm, &
        nnb,nres,nbonda,nanglea,ndihea,nbondtype,nangletype,ndihetype,natyp,nhbtype, &
        ifpert,nbper,ngper,ndper,mbper,mgper,mdper,ipb,nmaxresatom,ifcap,  &
        nextra,ncopy

  allocate(name(natom)); name=""
  call pick_arrays("%FLAG ATOM_NAME"); read(iotop,tpformat) name 

  allocate(charge(natom)); charge=0d0
  call pick_arrays("%FLAG CHARGE"); read(iotop,tpformat) charge

  allocate(atomicnumber(natom)); atomicnumber=0
  call pick_arrays("%FLAG ATOMIC_NUMBER",ifexist=ifexist); 
  if ( ifexist ) read(iotop,tpformat) atomicnumber

  allocate(mass(natom)); mass=0d0
  call pick_arrays("%FLAG MASS"); read(iotop,tpformat) mass

  allocate(typeindex(natom)); typeindex=0
  call pick_arrays("%FLAG ATOM_TYPE_INDEX"); read(iotop,tpformat) typeindex

  allocate(nexcludedatoms(natom)); nexcludedatoms=0
  call pick_arrays("%FLAG NUMBER_EXCLUDED_ATOMS"); read(iotop,tpformat) nexcludedatoms

  allocate(nonbondedparmindex(nvdwtype*nvdwtype)); nonbondedparmindex=0
  call pick_arrays("%FLAG NONBONDED_PARM_INDEX"); read(iotop,tpformat) nonbondedparmindex
  do i=1,nvdwtype*nvdwtype
     ! If the index is negative, then it is an index in the hbondacoef and hbondbcoef array
     ! This term has been dropped from most modern force fields.
     ! For convenience, we just set it to an interaction with vdwacoef=0 and vdwbcoef=0
     if ( nonbondedparmindex(i) < 0 ) nonbondedparmindex(i) = nvdwtype*(nvdwtype+1)/2 + 1
  end do

  allocate(resname(nres)); resname=""
  call pick_arrays("%FLAG RESIDUE_LABEL"); read(iotop,tpformat) resname

  allocate(resindex(nres+1)); resindex=0
  call pick_arrays("%FLAG RESIDUE_POINTER"); read(iotop,tpformat) resindex(1:nres); resindex=resindex-1
  resindex(nres+1)=natom

  allocate(bondforceconst(nbondtype)); bondforceconst=0d0
  call pick_arrays("%FLAG BOND_FORCE_CONSTANT"); read(iotop,tpformat) bondforceconst

  allocate(bondeqval(nbondtype)); bondeqval=0d0
  call pick_arrays("%FLAG BOND_EQUIL_VALUE"); read(iotop,tpformat) bondeqval

  allocate(angleforceconst(nangletype)); angleforceconst=0d0
  call pick_arrays("%FLAG ANGLE_FORCE_CONSTANT"); read(iotop,tpformat) angleforceconst

  allocate(angleeqval(nangletype)); angleeqval=0d0
  call pick_arrays("%FLAG ANGLE_EQUIL_VALUE"); read(iotop,tpformat) angleeqval

  allocate(diheforceconst(ndihetype)); diheforceconst=0d0
  call pick_arrays("%FLAG DIHEDRAL_FORCE_CONSTANT"); read(iotop,tpformat) diheforceconst

  allocate(diheperiod(ndihetype)); diheperiod=0d0
  call pick_arrays("%FLAG DIHEDRAL_PERIODICITY"); read(iotop,tpformat) diheperiod
  !if(maxval(diheperiod) > 6) call errormsg("DIHEDRAL_PERIODICITY is bigger than 6")

  allocate(dihephase(ndihetype),cosphase(ndihetype),sinphase(ndihetype))
  dihephase=0d0; cosphase=0d0; sinphase=0d0
  call pick_arrays("%FLAG DIHEDRAL_PHASE"); read(iotop,tpformat) dihephase
  do i=1, ndihetype
    if (abs(dihephase(i) - acos(-1d0)) < 1d-3) dihephase(i) = sign(acos(-1d0), dihephase(i))
    sinphase(i)=sin(dihephase(i)); cosphase(i)=cos(dihephase(i))
  end do

  allocate(scale14elec(ndihetype)); scale14elec=1.2d0
  call pick_arrays("%FLAG SCEE_SCALE_FACTOR",ifexist=ifexist)
  if ( ifexist ) read(iotop,tpformat) scale14elec
  scale14elec=1d0/scale14elec

  allocate(scale14vdw(ndihetype)); scale14vdw=2d0
  call pick_arrays("%FLAG SCNB_SCALE_FACTOR",ifexist=ifexist)
  if ( ifexist ) read(iotop,tpformat) scale14vdw
  scale14vdw=1d0/scale14vdw

  allocate(solty(natyp)); solty=0d0
  call pick_arrays("%FLAG SOLTY"); read(iotop,tpformat) solty

  itype = nvdwtype*(nvdwtype+1)/2
  allocate(vdwacoef(itype+1)); vdwacoef=0d0
  call pick_arrays("%FLAG LENNARD_JONES_ACOEF"); read(iotop,tpformat) vdwacoef(1:itype)

  allocate(vdwbcoef(itype+1)); vdwbcoef=0d0
  call pick_arrays("%FLAG LENNARD_JONES_BCOEF"); read(iotop,tpformat) vdwbcoef(1:itype)

  allocate(vdwsigma(natom),vdweps(natom),vdwlambda(natom)); vdwsigma=0d0; vdweps=0d0; vdwlambda=0d0
  do iatom=1,natom
     itype = typeindex(iatom)
     index = nonbondedparmindex(nvdwtype*(itype-1) + itype)
     if ( vdwacoef(index) == 0d0 .or. vdwbcoef(index) == 0d0 ) cycle
     vdwsigma(iatom) = 0.5d0*(vdwacoef(index)/vdwbcoef(index))**(1d0/6d0)
     vdweps(iatom) = sqrt(vdwbcoef(index)/(2d0*vdwsigma(iatom))**6)
     vdwlambda(iatom) = sqrt(vdwbcoef(index))
  end do

  allocate(bondh(nbondh*3)); bondh=0
  call pick_arrays("%FLAG BONDS_INC_HYDROGEN"); read(iotop,tpformat) bondh

  allocate(bondnoh(nbondnoh*3)); bondnoh=0
  call pick_arrays("%FLAG BONDS_WITHOUT_HYDROGEN"); read(iotop,tpformat) bondnoh

  allocate(bondhatom(3*nbondh)); bondhatom=0
  nbond = nbondh + nbondnoh; allocate(bondatom(3*nbond)); bondatom=0
  do index=1,nbondh
     ibond = index
     i=bondh(3*ibond-2)/3+1; j=bondh(3*ibond-1)/3+1; itype=bondh(3*ibond)
     bondhatom(3*index-2:3*index) = (/i,j,itype/)
     ibond = index + nbondnoh
     bondatom(3*ibond-2:3*ibond) = (/i,j,itype/)
  end do
  do index=nbondh+1,nbond
     ibond = index - nbondh
     i=bondnoh(3*ibond-2)/3+1; j=bondnoh(3*ibond-1)/3+1; itype=bondnoh(3*ibond)
     bondatom(3*ibond-2:3*ibond) = (/i,j,itype/)
  end do

  allocate(angleh(nangleh*4)); angleh=0
  call pick_arrays("%FLAG ANGLES_INC_HYDROGEN"); read(iotop,tpformat) angleh

  allocate(anglenoh(nanglenoh*4)); anglenoh=0
  call pick_arrays("%FLAG ANGLES_WITHOUT_HYDROGEN"); read(iotop,tpformat) anglenoh

  nangle = nangleh + nanglenoh; allocate(angleatom(4*nangle)); angleatom=0
  do index=1,nangle
     if ( index <= nangleh ) then
        iangle = index
        i=angleh(4*iangle-3)/3+1; j=angleh(4*iangle-2)/3+1; k=angleh(4*iangle-1)/3+1
        itype=angleh(4*iangle)
     else
        iangle = index - nangleh
        i=anglenoh(4*iangle-3)/3+1; j=anglenoh(4*iangle-2)/3+1; k=anglenoh(4*iangle-1)/3+1
        itype=anglenoh(4*iangle)
     end if
     angleatom(4*index-3:4*index) = (/i,j,k,itype/)
  end do

  allocate(diheh(ndiheh*5)); diheh=0
  call pick_arrays("%FLAG DIHEDRALS_INC_HYDROGEN"); read(iotop,tpformat) diheh

  allocate(dihenoh(ndihenoh*5)); dihenoh=0
  call pick_arrays("%FLAG DIHEDRALS_WITHOUT_HYDROGEN"); read(iotop,tpformat) dihenoh

  ndihedral = ndiheh + ndihenoh; allocate(diheatom(5*ndihedral)); diheatom=0
  do index=1,ndihedral
     if ( index <= ndiheh ) then
        idihe = index
        i=diheh(5*idihe-4)/3+1; j=diheh(5*idihe-3)/3+1
        if ( diheh(5*idihe-2) > 0 ) then; k=diheh(5*idihe-2)/3+1
        else; k=diheh(5*idihe-2)/3-1; end if
        if ( diheh(5*idihe-1) > 0 ) then; l=diheh(5*idihe-1)/3+1
        else; l=diheh(5*idihe-1)/3-1; end if
        k = iabs(k); l = iabs(l)
        itype=diheh(5*idihe)
     else 
        idihe = index - ndiheh
        i=dihenoh(5*idihe-4)/3+1; j=dihenoh(5*idihe-3)/3+1
        if ( dihenoh(5*idihe-2) > 0 ) then; k=dihenoh(5*idihe-2)/3+1
        else; k=dihenoh(5*idihe-2)/3-1; end if
        if ( dihenoh(5*idihe-1) > 0 ) then; l=dihenoh(5*idihe-1)/3+1
        else; l=dihenoh(5*idihe-1)/3-1; end if
        k = iabs(k); l = iabs(l)
        itype=dihenoh(5*idihe)
     end if
     diheatom(5*index-4:5*index) = (/i,j,k,l,itype/)
  end do

  nnb14=0; allocate(tparray(3,ndiheh+ndihenoh)); tparray=0
  do idihe=1,ndiheh
     i=diheh(5*idihe-4)/3+1; j=diheh(5*idihe-3)/3+1
     if ( diheh(5*idihe-2) > 0 ) then; k=diheh(5*idihe-2)/3+1
     else; cycle; end if
     if ( diheh(5*idihe-1) > 0 ) then; l=iabs(diheh(5*idihe-1)/3+1)
     else; cycle; end if
     nnb14 = nnb14 + 1; tparray(1:3,nnb14)=(/i,l,diheh(5*idihe)/)
  end do

  do idihe=1,ndihenoh
     i=dihenoh(5*idihe-4)/3+1; j=dihenoh(5*idihe-3)/3+1
     if ( dihenoh(5*idihe-2) > 0 ) then; k=dihenoh(5*idihe-2)/3+1
     else; cycle; end if
     if ( dihenoh(5*idihe-1) > 0 ) then; l=iabs(dihenoh(5*idihe-1)/3+1)
     else; cycle; end if
     nnb14 = nnb14 + 1; tparray(1:3,nnb14)=(/i,l,dihenoh(5*idihe)/)
  end do
  allocate(nonbond14(3,nnb14)); nonbond14(1:3,1:nnb14)=tparray(1:3,1:nnb14)

  allocate(excludedatomlist(nnb)); excludedatomlist=0
  call pick_arrays("%FLAG EXCLUDED_ATOMS_LIST"); read(iotop,tpformat) excludedatomlist

  allocate(hbondacoef(nhbtype)); hbondacoef=0
  call pick_arrays("%FLAG HBOND_ACOEF"); read(iotop,tpformat) hbondacoef

  allocate(hbondbcoef(nhbtype)); hbondbcoef=0
  call pick_arrays("%FLAG HBOND_BCOEF"); read(iotop,tpformat) hbondbcoef

  allocate(hbondcut(nhbtype)); hbondcut=0
  call pick_arrays("%FLAG HBCUT"); read(iotop,tpformat) hbondcut

  allocate(type(natom)); type=""
  call pick_arrays("%FLAG AMBER_ATOM_TYPE"); read(iotop,tpformat) type

  allocate(treechainclass(natom)); treechainclass=""
  call pick_arrays("%FLAG TREE_CHAIN_CLASSIFICATION"); read(iotop,tpformat) treechainclass

  endsoluteres=0; nmol=0; firstsolventmol=0; oldbeta=0d0
  if ( ipb > 0 ) then
     call pick_arrays("%FLAG SOLVENT_POINTERS"); read(iotop,tpformat) endsoluteres,nmol,firstsolventmol
     nsolventmol = nmol - firstsolventmol + 1
     allocate(natompermol(nmol)); natompermol=0
     call pick_arrays("%FLAG ATOMS_PER_MOLECULE"); read(iotop,tpformat) natompermol
     call pick_arrays("%FLAG BOX_DIMENSIONS"); read(iotop,tpformat) oldbeta,pmecell(1:3)
     ioct=0; cellalpha = oldbeta; cellbeta=cellalpha; cellgamma=cellalpha
     if ( oldbeta /= 90.0d0 ) ioct = 1
     if ( ifcap /= 0 ) then
        call pick_arrays("%FLAG CAP_INFO"); read(iotop,tpformat) lastatombeforewatcap
        call pick_arrays("%FLAG CAP_INFO2"); read(iotop,tpformat) cutcap,xcap,ycap,zcap
     end if
  end if

  call pick_arrays("%FLAG RADIUS_SET"); read(iotop,tpformat) radiusset

  allocate(radius(natom)); radius=0d0
  call pick_arrays("%FLAG RADII"); read(iotop,tpformat) radius

  allocate(screen(natom)); screen=0d0
  call pick_arrays("%FLAG SCREEN"); read(iotop,tpformat) screen

  ipol=0
  call pick_arrays("%FLAG IPOL", ifexist=ifexist)
  if ( ifexist ) read(iotop,tpformat) ipol
  if ( ipol /= 0 ) then
     allocate(atompolar(natom)); atompolar=0d0
     call pick_arrays("%FLAG POLARIZABILITY"); read(iotop,tpformat) atompolar
  end if

  close(iotop)
  ndihegroup = 1; tpatomarray(1:4) = diheatom(1:4)
  do idihe=2, ndihedral
     itype=5*idihe-4
     i=diheatom(itype); j=diheatom(itype+1); k=diheatom(itype+2); l=diheatom(itype+3)
     if ( i/=tpatomarray(1) .or. j/=tpatomarray(2) .or. &
          k/=tpatomarray(3) .or. l/=tpatomarray(4) ) then
        ndihegroup = ndihegroup + 1
        tpatomarray(1:4) = diheatom(itype:itype+3)
     end if
  end do
  allocate(dihegroupindex(ndihegroup+1)); dihegroupindex=0
  ndihegroup = 1; tpatomarray(1:4) = diheatom(1:4)
  do idihe=2, ndihedral
     itype=5*idihe-4
     i=diheatom(itype); j=diheatom(itype+1); k=diheatom(itype+2); l=diheatom(itype+3)
     if ( i/=tpatomarray(1) .or. j/=tpatomarray(2) .or. &
          k/=tpatomarray(3) .or. l/=tpatomarray(4) ) then
        ndihegroup = ndihegroup + 1; dihegroupindex(ndihegroup)=idihe-1
        tpatomarray(1:4) = diheatom(itype:itype+3)
     end if
  end do
  dihegroupindex(ndihegroup+1) = ndihedral

  call ambertop_printinfo_topfile(ifsummary=.true.)

contains

subroutine pick_arrays(tplabel,ifexist)
  character(len=*),intent(in) :: tplabel
  logical,intent(out),optional :: ifexist
  logical :: iffound
  integer :: ierr

  iffound = .false.
  do
     read(iotop,"(a)",iostat=ierr) tpstring
     if ( ierr < 0 ) exit
     if ( trim(tpstring) == trim(tplabel) ) then
        iffound = .true.
        read(iotop,"(a)") tpformat; tpformat = tpformat(8:50); exit
     end if
  end do
  if ( iffound .eqv. .false. ) then
     print "(a,a,a)","Keyword ",trim(tplabel)," is not found in the topology file"
     rewind(iotop)
  end if
  if ( present(ifexist) ) ifexist=iffound
end subroutine
end subroutine

subroutine ambertop_printinfo_pot()
  print "(3(a10,f10.3,3x))","Bond=     ",ebond,"Angle=    ",eangle,"Dihedral= ",edihe
  print "(4(a10,f10.3,3x))","Elec=     ",eelec,"VDW=      ",evdw,"Elec14=    ",eelec14,"VDW14=    ",evdw14
end subroutine

subroutine ambertop_printinfo_topfile(ifsummary)
  logical,intent(in),optional :: ifsummary
  integer :: itype,ires,iatom,tpi,tpj

return
  do ires=1,nres
     print "(a,i4,a,a4)", "RES ",ires,": ",resname(ires)
     do iatom=resindex(ires)+1,resindex(ires+1)
        print "(a,i6,a5,f8.3,i3,f8.3,i3,2a4,f5.3)",   &
            "atom ",iatom,name(iatom),charge(iatom),atomicnumber(iatom),mass(iatom), &
            typeindex(iatom),type(iatom),treechainclass(iatom),radius(iatom)
     end do
  end do

  if ( present(ifsummary) ) then
     if ( ifsummary .eqv. .true. ) return
  end if

  print *; print "(a)","Bond types"
  do itype=1,nbondtype
     print "(a10,i5,a,2f8.3)","bond type ",itype,": ",bondforceconst(itype),bondeqval(itype)
  end do

  print *; print "(a)","Angle types"
  do itype=1,nangletype
     print "(a10,i5,a,2f8.3)","angle type",itype,": ",angleforceconst(itype),angleeqval(itype)
  end do

  print *; print "(a)","Dihedral types"
  do itype=1,ndihetype
     print "(a10,i5,a,5f8.3)","dihe type ",itype,": ",diheforceconst(itype),diheperiod(itype), &
            dihephase(itype),scale14elec(itype),scale14vdw(itype)
  end do

  print *; print "(a)","VDW types"
  do itype=1,nvdwtype*(nvdwtype+1)/2
     print "(a10,i5,a,2f12.3)","vdw type  ",itype,": ",vdwacoef(itype),vdwbcoef(itype)
  end do

  print *; print "(a)","Bonds with hydrogen"
  do itype=1,nbondh
     print "(a10,i5,a,3i6)","bond-H    ",itype,": ",bondh(3*itype-2:3*itype)
  end do

  print *; print "(a)","Bonds without hydrogen"
  do itype=1,nbondnoh
     print "(a10,i5,a,3i6)","bond-noh  ",itype,": ",bondnoh(3*itype-2:3*itype)
  end do

  print *; print "(a)","Angles with hydrogen"
  do itype=1,nangleh
     print "(a10,i5,a,4i6)","angle-H   ",itype,": ",angleh(4*itype-3:4*itype)
  end do

  print *; print "(a)","Angles without hydrogen"
  do itype=1,nanglenoh
     print "(a10,i5,a,4i6)","angle-noH ",itype,": ",anglenoh(4*itype-3:4*itype)
  end do

  print *; print "(a)","Dihedrals with hydrogen"
  do itype=1,ndiheh
     print "(a10,i5,a,5i6)","dihe-H    ",itype,": ",diheh(5*itype-4:5*itype)
  end do

  print *; print "(a)","Dihedrals without hydrogen"
  do itype=1,ndihenoh
     print "(a10,i5,a,5i6)","dihe-noH  ",itype,": ",dihenoh(5*itype-4:5*itype)
  end do

  print *; print "(a)","Excluded atoms"; tpi=0
  do iatom=1,natom
     tpj = nexcludedatoms(iatom)
     print "(a,i4,a,i3,a,100i4)","atom ",iatom," (",tpj,"): ",excludedatomlist(tpi+1:tpi+tpj)
     tpi = tpi + tpj
  end do

  if ( nhbtype > 0 ) then
     print *; print "(a)","Hydrogen bond types"
     do itype=1,nhbtype
        print "(a10,i5,a,3f8.3)","h-bond  ",itype,": ",hbondacoef(itype),hbondbcoef(itype),hbondcut(itype)
     end do
  end if

  if ( ipb > 0 ) then
     print *; print "(a)","Box info"
     print "(a,3i5,4f8.3)","IPTRES NSPM NSPSOL OLDBETA BOX(1:3): ",endsoluteres,nmol,firstsolventres,oldbeta,pmecell(:)
     print "(a)","Atom number per molecule "
     print "(30i3)",natompermol(1:nmol)
     if ( ifcap /= 0 ) then
        print "(a,i5)","last atom before water cap ",lastatombeforewatcap
        print "(a,4f8.3)","CUTMAP XCAP YCAP ZCAP: ",cutcap,xcap,ycap,zcap
     end if
  end if

  print *; print "(a,a)","Radius set: ",adjustl(radiusset)

  print *; print "(a)","Atom Radius"; print "(14f8.3)",radius(:)
  print *; print "(a)","Screen"; print "(14f8.3)",screen(:)

  print *; print "(a,i3)","IPOL: ",ipol
  if ( ipol /= 0 ) then
     print "(a)" ,"Atom polarizability"
     print "(30f8.3)",atompolar(:)
  end if
end subroutine

subroutine ambertop_checkforce(tpstring,tppot,tpfrc)
  character(len=*),intent(in) :: tpstring
  real*8,intent(in) :: tppot
  real*8,intent(in),optional :: tpfrc(3,natom)
  integer :: i,j
  real*8 :: tpvalue

  if ( present(tpfrc) ) then
     tpvalue=0d0
     do i=1,natom
        do j=1,3
           tpvalue = tpvalue + tpfrc(j,i)*dble(i-natom/2)
        end do
     end do
     print "(a,a10,2f25.16)","pot and scaled force for ",trim(tpstring),tppot,tpvalue
  else
     print "(a,a10,2f25.16)","pot for ",trim(tpstring),tppot
  end if
end subroutine

subroutine ambertop_potforce_bond(tpcoor,tppot,tpfrc)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tppot
  real*8,intent(inout),optional :: tpfrc(3,natom)
  integer :: i,j,itype,ibond,imol,tpmol
  real*8 :: tpdis,tpvec(3),tpvalue,tpdelta,tpfactor,tpk,tpeqdis

  tppot = 0d0
  do ibond=1,nbond
     if ( (ishake == 1) .and. (ibond>nbondnoh) ) cycle

     itype=bondatom(3*ibond); if ( itype == 0 ) cycle
     i=bondatom(3*ibond-2); j=bondatom(3*ibond-1)

     tpk=bondforceconst(itype); tpeqdis=bondeqval(itype)
     tpvec(1:3) = tpcoor(1:3,i) - tpcoor(1:3,j)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpdelta = tpdis - tpeqdis; tpfactor = tpk*tpdelta
     tppot = tppot + tpfactor*tpdelta

     if ( .not. present(tpfrc) ) cycle
     tpvec=2d0*tpfactor*tpvec/tpdis
     tpfrc(1:3,i) =  tpfrc(1:3,i) - tpvec(1:3)
     tpfrc(1:3,j) =  tpfrc(1:3,j) + tpvec(1:3)
  end do
end subroutine

subroutine ambertop_potforce_angle(tpcoor,tppot,tpfrc,tpmolarray)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tppot
  real*8,intent(inout),optional :: tpfrc(3,natom)
  integer,intent(in),optional :: tpmolarray(:)
  integer :: i,j,k,itype,iangle,imol,tpmol
  real*8 :: rijvec(3),rkjvec(3),tpfrcvec1(3),tpfrcvec2(3),tpfrcvec3(3),rijsq,rkjsq,rij,rkj,rijkj,costheta
  real*8 :: tptheta,tpdelta,tpfactor,tpk,tpeqval,tpkdelta

  tppot = 0d0
  do iangle=1,nangle

     itype=angleatom(4*iangle); if ( itype == 0 ) cycle
     i=angleatom(4*iangle-3); j=angleatom(4*iangle-2); k=angleatom(4*iangle-1)
     tpk=angleforceconst(itype); tpeqval=angleeqval(itype)

     rijvec(1:3)=tpcoor(1:3,i) - tpcoor(1:3,j); rijsq=dot_product(rijvec,rijvec); rij=sqrt(rijsq)
     rkjvec(1:3)=tpcoor(1:3,k) - tpcoor(1:3,j); rkjsq=dot_product(rkjvec,rkjvec); rkj=sqrt(rkjsq)
     rijkj=rij*rkj; costheta=dot_product(rijvec,rkjvec)/rijkj
     costheta = min(0.99999d0, max(-0.99999d0, costheta)); tptheta=acos(costheta)
     tpdelta = tptheta - tpeqval; tpkdelta = tpk*tpdelta
     tppot = tppot + tpkdelta*tpdelta

     if ( .not. present(tpfrc) ) cycle
     tpfactor = (2d0*tpkdelta)/sqrt(1.0-costheta**2)
! Reference:
! Alternative Expressions for Energies and Forces Due to Angle Bending and Torsional Energy. 
! W.C.Swope and D.M.Ferguson. J. Comput. Chem. 1992,13, 585-594. Eqs.(6),(15),and(18)
     tpfrcvec1 = ( (rkjvec(:)/rijkj) - rijvec(:)*costheta/rijsq )*tpfactor
     tpfrcvec2 = ( (rijvec(:)/rijkj) - rkjvec(:)*costheta/rkjsq )*tpfactor
     tpfrcvec3 =  tpfrcvec1 + tpfrcvec2
     tpfrc(1:3,i) = tpfrc(1:3,i) + tpfrcvec1(1:3)
     tpfrc(1:3,k) = tpfrc(1:3,k) + tpfrcvec2(1:3)
     tpfrc(1:3,j) = tpfrc(1:3,j) - tpfrcvec3(1:3)
  end do
end subroutine

! calculate the dihedral energy
subroutine ambertop_potforce_dihedral_original(tpcoor,tppot,tpfrc)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tppot
  real*8,intent(inout),optional :: tpfrc(3,natom)
  integer :: i,j,k,l,idihe,itype,ithread,iblock
  real*8 :: rijvec(3),rkjvec(3),rklvec(3),vec1(3),vec2(3),vec1unit(3),vec2unit(3)
  real*8:: dot1inv,dot2inv,rijrkj,rkj,rkjsq,rklrkj,tpcoeff
  real*8 :: tpn,tpk,tpphase,tpphi
  real*8 :: tpvec1(3),tpvec2(3),tpvec(3)

  tppot = 0.0d0
  do idihe=1, ndihedral
     itype=5*idihe-4; if ( diheatom(itype+4) == 0 ) cycle
     i=diheatom(itype); j=diheatom(itype+1); k=diheatom(itype+2); l=diheatom(itype+3)
     itype=diheatom(itype+4); vec1(1:3)=tpcoor(1:3,j); vec2(1:3)=tpcoor(1:3,k)
     rijvec(1:3)=tpcoor(1:3,i) - vec1(1:3)
     rkjvec(1:3)=vec2(1:3) - vec1(1:3)
     rklvec(1:3)=vec2(1:3) - tpcoor(1:3,l)
     call cross_product(rijvec,rkjvec,vec1)
     call cross_product(rkjvec,rklvec,vec2)
     dot1inv=1.0d0/dot_product(vec1,vec1); dot2inv=1.0d0/dot_product(vec2,vec2)
     vec1unit(1:3)=vec1(1:3)*sqrt(dot1inv); vec2unit(1:3)=vec2(1:3)*sqrt(dot2inv)
   
     tpphi=dot_product(vec1unit,vec2unit); tpphi = min(1.0d0, max(-1.0d0, tpphi))
     tpphi=sign(1.0d0,dot_product(rijvec,vec2))*acos( tpphi )
   
     tpk=diheforceconst(itype); tpn=diheperiod(itype)
     tpphase=-dihephase(itype); tpphi = tpn*tpphi+tpphase
   
     tppot = tppot + tpk*(1.0d0 + cos(tpphi))
   
     if ( .not. present(tpfrc) ) cycle
   
     rijrkj=dot_product(rijvec,rkjvec); rkjsq=dot_product(rkjvec,rkjvec)
     rkj=sqrt(rkjsq); rklrkj=dot_product(rklvec,rkjvec)
     tpcoeff = tpk*tpn*sin(tpphi)*rkj
     tpvec1(1:3) = tpcoeff*vec1(1:3)*dot1inv
     tpvec2(1:3) = -tpcoeff*vec2(1:3)*dot2inv
     tpvec(1:3) = (rijrkj*tpvec1(1:3) - rklrkj*tpvec2(1:3))/rkjsq

     tpfrc(1:3,i) = tpfrc(1:3,i) + tpvec1(1:3)
     tpfrc(1:3,j) = tpfrc(1:3,j) - tpvec1(1:3) + tpvec(1:3)
     tpfrc(1:3,k) = tpfrc(1:3,k) - tpvec2(1:3) - tpvec(1:3)
     tpfrc(1:3,l) = tpfrc(1:3,l) + tpvec2(1:3)
  end do
end subroutine

! calculate the dihedral energy
subroutine ambertop_potforce_dihedral(tpcoor,tppot,tpfrc)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tppot
  real*8,intent(inout),optional :: tpfrc(3,natom)
  integer :: i,j,k,l,idihe,itype,ithread,iblock
  real*8 :: rijvec(3),rkjvec(3),rklvec(3),vec1(3),vec2(3),vec1unit(3),vec2unit(3)
  real*8:: dot1inv,dot2inv,rijrkj,rkj,rkjsq,rklrkj,tpcoeff
  real*8 :: tpn,tpk,tpphase,tpphi,tpphi2
  real*8 :: tpvec1(3),tpvec2(3),tpvec(3)
  integer :: idihegroup

  tppot = 0.0d0
  do idihegroup=1,ndihegroup
     idihe=dihegroupindex(idihegroup)+1

     itype=5*idihe-4; if ( diheatom(itype+4) == 0 ) cycle
     i=diheatom(itype); j=diheatom(itype+1); k=diheatom(itype+2); l=diheatom(itype+3)
     vec1(1:3)=tpcoor(1:3,j); vec2(1:3)=tpcoor(1:3,k)
     rijvec(1:3)=tpcoor(1:3,i) - vec1(1:3)
     rkjvec(1:3)=vec2(1:3) - vec1(1:3)
     rklvec(1:3)=vec2(1:3) - tpcoor(1:3,l)
     call cross_product(rijvec,rkjvec,vec1)
     call cross_product(rkjvec,rklvec,vec2)
     dot1inv=1.0d0/dot_product(vec1,vec1); dot2inv=1.0d0/dot_product(vec2,vec2)
     vec1unit(1:3)=vec1(1:3)*sqrt(dot1inv); vec2unit(1:3)=vec2(1:3)*sqrt(dot2inv)

     tpphi=dot_product(vec1unit,vec2unit); tpphi = min(1.0d0, max(-1.0d0, tpphi))
     tpphi=sign(1.0d0,dot_product(rijvec,vec2))*acos( tpphi )

     tpcoeff=0.0d0
     do idihe=dihegroupindex(idihegroup)+1,dihegroupindex(idihegroup+1)
        itype=diheatom(5*idihe)
        tpk=diheforceconst(itype); tpn=diheperiod(itype); tpphase=-dihephase(itype)
        tpphi2 = tpn*tpphi+tpphase
        tppot = tppot + tpk*(1.0d0 + cos(tpphi2))
        if ( present(tpfrc) ) tpcoeff = tpcoeff + tpk*tpn*sin(tpphi2)
     end do

     if ( .not. present(tpfrc) ) cycle

     rijrkj=dot_product(rijvec,rkjvec); rkjsq=dot_product(rkjvec,rkjvec)
     rkj=sqrt(rkjsq); rklrkj=dot_product(rklvec,rkjvec)
     tpcoeff = tpcoeff*rkj

     tpvec1(1:3) = tpcoeff*vec1(1:3)*dot1inv
     tpvec2(1:3) = -tpcoeff*vec2(1:3)*dot2inv
     tpvec(1:3) = (rijrkj*tpvec1(1:3) - rklrkj*tpvec2(1:3))/rkjsq

     tpfrc(1:3,i) = tpfrc(1:3,i) + tpvec1(1:3)
     tpfrc(1:3,j) = tpfrc(1:3,j) - tpvec1(1:3) + tpvec(1:3)
     tpfrc(1:3,k) = tpfrc(1:3,k) - tpvec2(1:3) - tpvec(1:3)
     tpfrc(1:3,l) = tpfrc(1:3,l) + tpvec2(1:3)

  end do
end subroutine

! References
! Alternative Expressions for Energies and Forces Due to Angle Bending and Torsional Energy.
! W.C.Swope and D.M.Ferguson. J. Comput. Chem. 1992, 13: 585-594.
subroutine ambertop_potforce_dihedral_selectcase(tpcoor,tppot,tpfrc,tpmolarray)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tppot
  real*8,intent(inout),optional :: tpfrc(3,natom)
  integer,intent(in),optional :: tpmolarray(:)
  integer :: i,j,k,l,itype,idihe,imol,tpmol
  real*8 :: rijvec(3),rkjvec(3),rlkvec(3),tvec(3),uvec(3),tvecunit(3),uvecunit(3),negdev(3,4)
  real*8 :: tdot,udot,tpvec(3),rijrkj,rkj,rkjsq,rlkrkj,tpcoeff,tpcosphi,tpcosphi2,tpsinphi
  real*8 :: tpn,tpk,tpphase,tpcosnphi,tpdcosnphi

  tppot = 0d0
  do idihe=1,ndihedral

     itype=diheatom(5*idihe); if ( itype == 0 ) cycle
     i=diheatom(5*idihe-4); j=diheatom(5*idihe-3); k=diheatom(5*idihe-2); l=diheatom(5*idihe-1)

     rijvec(1:3)=tpcoor(1:3,i) - tpcoor(1:3,j)
     rkjvec(1:3)=tpcoor(1:3,k) - tpcoor(1:3,j)
     rlkvec(1:3)=tpcoor(1:3,l) - tpcoor(1:3,k)
     call cross_product(rijvec,rkjvec,tvec)
     call cross_product(rlkvec,rkjvec,uvec)
     tdot=dot_product(tvec,tvec); udot=dot_product(uvec,uvec)
     tvecunit(1:3)=tvec(1:3)/sqrt(tdot); uvecunit(1:3)=uvec(1:3)/sqrt(udot)

     tpcosphi=dot_product(tvecunit,uvecunit); tpcosphi = min(1.0d0, max(-1.0d0, tpcosphi))
     tpk=diheforceconst(itype); tpn=diheperiod(itype); tpphase=dihephase(itype)
     tpcosphi2 = tpcosphi*tpcosphi; tpcoeff = tpk*sign(1d0,cos(tpphase))

! cosnphi = cos(n*phi) = fun(n, cosphi, cosphi^2)     (note that phi is not a necessary parameter)
! d(cosnphi)/d(cosphi) = fun(n, cosphi, cosphi^2)

     select case( int(tpn) )
     case( 0 ); tpcosnphi = 1d0
                tpdcosnphi = 0d0
     case( 1 ); tpcosnphi = tpcosphi
                tpdcosnphi = 1d0
     case( 2 ); tpcosnphi = 2d0*tpcosphi2-1d0
                tpdcosnphi = 4d0*tpcosphi
     case( 3 ); tpcosnphi = (4d0*tpcosphi2-3d0)*tpcosphi
                tpdcosnphi = 12d0*tpcosphi2-3d0
     case( 4 ); tpcosnphi = 1d0+8d0*(tpcosphi2-1d0)*tpcosphi2
                tpdcosnphi = 16d0*(2d0*tpcosphi2-1d0)*tpcosphi
     case( 5 ); tpcosnphi = ((16d0*tpcosphi2-20d0)*tpcosphi2+5d0)*tpcosphi
                tpdcosnphi = 20d0*(4d0*tpcosphi2-3d0)*tpcosphi2+5d0
     case( 6 ); tpcosnphi = (16d0*(tpcosphi2-1d0)*tpcosphi2+1d0)*(2d0*tpcosphi2-1d0)
                tpdcosnphi = (192d0*(tpcosphi2-1d0)*tpcosphi2+36d0)*tpcosphi
     case default
                call multiple_angle_formulas(int(tpn),tpcosphi,tpcosphi2,tpcosnphi,tpdcosnphi)
     end select
     tppot = tppot + tpk+tpcoeff*tpcosnphi

     if ( .not. present(tpfrc) ) cycle  

     ! Eq.(44)
     tpsinphi=sign(sqrt(1-tpcosphi2),dot_product(rijvec,uvec))
     tpcoeff = -tpcoeff*tpdcosnphi*tpsinphi

     ! Eqs.(39)-(43)
     rijrkj=dot_product(rijvec,rkjvec); rkjsq=dot_product(rkjvec,rkjvec)
     rkj=sqrt(rkjsq); rlkrkj=dot_product(rlkvec,rkjvec)
     negdev(1:3,1) = ( -rkj*tvec(1:3) )/tdot
     negdev(1:3,4)= ( rkj*uvec(1:3) )/udot
     tpvec(1:3)= (rijrkj*negdev(1:3,1) + rlkrkj*negdev(1:3,4))/rkjsq
     negdev(1:3,2)= -negdev(1:3,1) + tpvec(1:3)
     negdev(1:3,3)= -negdev(1:3,4) - tpvec(1:3)

     tpfrc(1:3,i) = tpfrc(1:3,i) + tpcoeff*negdev(1:3,1)
     tpfrc(1:3,j) = tpfrc(1:3,j) + tpcoeff*negdev(1:3,2)
     tpfrc(1:3,k) = tpfrc(1:3,k) + tpcoeff*negdev(1:3,3)
     tpfrc(1:3,l) = tpfrc(1:3,l) + tpcoeff*negdev(1:3,4)
  end do
end subroutine

subroutine ambertop_potforce_elecvdw14(tpcoor,tpelec14,tpvdw14,tpfrc,tpmolarray)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpelec14,tpvdw14
  real*8,intent(inout),optional :: tpfrc(3,natom)
  integer,intent(in),optional :: tpmolarray(:)
  integer :: itype,idihe,iatom,jatom,tpindex,tpitype,tpjtype,imol,tpmol
  real*8 :: rijvec(3),tpfrcvec(3),tpiq,tpjq,tpicoor(3),tpjcoor(3),tpvalue
  real*8 :: tpdissqinv,tpdisinv,tpdis6inv,tpdis12inv,tpa,tpb,tpc,tpdissq
  logical :: ifhit

  tpelec14=0d0; tpvdw14=0d0
  do idihe=1,nnb14

     itype=nonbond14(3,idihe); if ( itype == 0 ) cycle
     iatom = nonbond14(1,idihe); jatom = nonbond14(2,idihe)

     tpitype=typeindex(iatom); tpiq = charge(iatom); tpicoor(1:3) = tpcoor(1:3,iatom)
     tpjtype=typeindex(jatom); tpjq = charge(jatom); tpjcoor(1:3) = tpcoor(1:3,jatom)
     rijvec(1:3) = tpicoor(1:3) - tpjcoor(1:3)

     tpdissq = dot_product(rijvec,rijvec); tpdisinv=1d0/sqrt(tpdissq); tpdissqinv=tpdisinv*tpdisinv
     tpvalue = scale14elec(itype)*tpiq*tpjq*tpdisinv
     tpelec14 = tpelec14 + tpvalue

     if ( present(tpfrc) ) then
        tpfrcvec(1:3) = tpvalue*rijvec(1:3)*tpdissqinv
     end if

     tpindex = nonbondedparmindex(nvdwtype*(tpitype-1) + tpjtype)
     tpa=vdwacoef(tpindex); tpb=vdwbcoef(tpindex); tpc=scale14vdw(itype)
     tpdis6inv = tpdissqinv**3; tpdis12inv = tpdis6inv**2
     tpa = tpc*tpa*tpdis12inv; tpb = tpc*tpb*tpdis6inv
     tpvalue = tpa - tpb
     tpvdw14 = tpvdw14 + tpvalue

     if ( .not. present(tpfrc) ) cycle
     tpfrcvec(1:3) = tpfrcvec(1:3) + 6d0*(tpa + tpvalue)*rijvec(1:3)*tpdissqinv
     tpfrc(1:3,iatom) = tpfrc(1:3,iatom) + tpfrcvec(1:3)
     tpfrc(1:3,jatom) = tpfrc(1:3,jatom) - tpfrcvec(1:3)
  end do

end subroutine

! get the atoms in a molecule or a residue
subroutine ambertop_getatoms(tpnatom,tpatoms,tpmols,tpres,ifcalpha,ifheavy,ifheavysc)
  integer,intent(out) :: tpnatom
  integer,dimension(natom),intent(out) :: tpatoms
  integer,dimension(:),intent(in),optional :: tpmols,tpres
  logical,intent(in),optional :: ifcalpha,ifheavy,ifheavysc
  integer :: i,k,iatom,ires,imol,istart,istop
  logical :: tpif

  tpatoms=0; tpnatom=0; tpif = .false.
  if ( present(tpmols) ) then
     do i=1,size(tpmols)
        imol = tpmols(i)
        do ires=molindex(imol)+1,molindex(imol+1)
        if ( present(ifcalpha) ) then
           if ( ifcalpha .eqv. .true. ) then
              tpnatom = tpnatom + 1; tpatoms(tpnatom) = calpha(ires)
              tpif = .true.
           end if
        else if ( present(ifheavy) ) then
           if ( ifheavy .eqv. .true. ) then
              do k=heavyindex(ires)+1, heavyindex(ires+1)
                 tpnatom = tpnatom + 1; tpatoms(tpnatom) = heavyatoms(k)
              end do
              tpif = .true.
           end if
        else if ( present(ifheavysc) ) then
           if ( ifheavysc .eqv. .true. ) then
              do k=heavyscindex(ires)+1, heavyscindex(ires+1)
                 tpnatom = tpnatom + 1; tpatoms(tpnatom) = heavyscatoms(k)
              end do
              tpif = .true.
           end if
        end if
        if ( .not. tpif ) then
           do k=resindex(ires)+1, resindex(ires+1)
              tpnatom = tpnatom + 1; tpatoms(tpnatom) = k
           end do
        end if
        end do
     end do
  else if ( present(tpres) ) then
     do i=1,size(tpres)
        ires = tpres(i)
        if ( present(ifcalpha) ) then
           if ( ifcalpha .eqv. .true. ) then
             tpnatom = tpnatom + 1; tpatoms(tpnatom) = calpha(ires)
             tpif = .true.
           end if
        else if ( present(ifheavy) ) then
           if ( ifheavy .eqv. .true. ) then
             do k=heavyindex(ires)+1, heavyindex(ires+1)
                tpnatom = tpnatom + 1; tpatoms(tpnatom) = heavyatoms(k)
             end do
             tpif = .true.
           end if
        else if ( present(ifheavysc))  then
           if ( ifheavysc .eqv. .true. ) then
             do k=heavyscindex(ires)+1, heavyscindex(ires+1)
                tpnatom = tpnatom + 1; tpatoms(tpnatom) = heavyscatoms(k)
             end do
             tpif = .true.
           end if
        end if
        if ( .not. tpif ) then
           do k=resindex(ires)+1, resindex(ires+1)
              tpnatom = tpnatom + 1; tpatoms(tpnatom) = k
           end do
        end if
     end do
  else
     stop "wrong in moldata_getatoms!"
  end if
end subroutine

! calculate the center-of-mass of a molecule, a residue or a group
subroutine ambertop_get_com(tpcoor,tppos,tpmols,tpres,tpatoms,ifcalpha,ifheavy,ifheavysc,tpmass)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tppos(3)
  integer,intent(in),dimension(:),optional :: tpmols,tpatoms,tpres
  logical,intent(in),optional :: ifcalpha,ifheavy,ifheavysc
  real*8,intent(out),optional :: tpmass
  integer :: imol,ires,i,k,tpnmol,istart,istop,tpnatom,tpatomarray(natom)
  real*8 :: tpvec(3),tptpmass

  if ( present(tpmols) ) then
     call ambertop_getatoms(tpnatom,tpatomarray,tpmols=tpmols,ifcalpha=ifcalpha,ifheavy=ifheavy,ifheavysc=ifheavysc)
  else if ( present(tpres) ) then     
     call ambertop_getatoms(tpnatom,tpatomarray,tpres=tpres,ifcalpha=ifcalpha,ifheavy=ifheavy,ifheavysc=ifheavysc)
  else if ( present(tpatoms) ) then
     tpnatom = size(tpatoms); tpatomarray(1:tpnatom)=tpatoms(1:tpnatom)
  end if

  tpvec(1:3)=0.0d0; tptpmass=0d0
  do i=1,tpnatom
     k = tpatomarray(i)
     tpvec(1:3)=tpvec(1:3)+tpcoor(1:3,k)*mass(k); tptpmass = tptpmass + mass(k)
  end do
  tppos(1:3)=tpvec(1:3)/tptpmass
  if ( present(tpmass) ) tpmass=tptpmass
end subroutine

subroutine ambertop_checkvir(tpstring,tpvir)
  character(len=*),intent(in) :: tpstring
  real*8,intent(in) :: tpvir(3)
  print "(a,a15,3f20.12)"," VIR for ",trim(tpstring),tpvir
end subroutine

subroutine ambertop_reschaininfo(tpires,tpreschaininfo)
  integer,intent(in) :: tpires
  integer,intent(out) :: tpreschaininfo
  logical,allocatable,dimension(:),save :: ifreschainend
  integer :: ires,iatom,imol

  if ( .not. allocated(ifreschainend) ) then
     allocate(ifreschainend(nbiores)); ifreschainend = .false.
     do imol = 1, nbiomol
        if ( molindex(imol)+1 == molindex(imol+1) ) then
           ires = molindex(imol)+1; ifreschainend(ires) = .true.
        else
           do ires = molindex(imol)+1, molindex(imol+1)
              if ( resname(ires) == "NME" .or. resname(ires) == "NHE" ) then
                 ifreschainend(ires) = .true.; cycle
              endif
              do iatom = resindex(ires) + 1, resindex(ires + 1)
                if ( name(iatom) == "OXT" ) then
                   ifreschainend(ires) = .true.; exit
                end if
              end do
           end do
        end if
     end do
  end if
  tpreschaininfo = 0
  if ( tpires == 1 .or. ifreschainend(tpires-1) ) then
     tpreschaininfo = 1   ! N-terminal in the chain
  else if ( ifreschainend(tpires) .or. tpires == nres ) then
     tpreschaininfo = 2   ! C-terminal in the chain
  end if
end subroutine

end module
