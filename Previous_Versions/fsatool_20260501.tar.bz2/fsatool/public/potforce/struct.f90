module struct 
  use ambertop; use pubmod
  use gb; use pme; use cudatop; use cudagb; use cudapme
  use martini_interface
  implicit none
  integer :: imin
  real*8,device :: stepsize_d
contains

subroutine struct_initialize()
  if ( icuda == 0 ) then
     call struct_initialize_cpu()
  else
     call struct_initialize_gpu()
  end if
end subroutine

! initialize the gb or pb calculation
subroutine struct_initialize_cpu()
  ifcalpot=.true.; ifcalfrc=.true.
  if ( ipb == 0 ) then
     call gb_initialize()
  else
     call pme_initialize()
  end if
end subroutine

subroutine struct_initialize_gpu()
  ifcalpot=.true.; ifcalfrc=.true.; ifcalpot_d=.true.; ifcalfrc_d=.true.
  call cudatop_initialize()
  if ( ipb == 0 ) then
     call cudagb_initialize()
  else
     call cudapme_initialize()
  end if
end subroutine

subroutine struct_potforce(check)
  logical,intent(in),optional :: check

  if ( icuda == 0 ) then
     call struct_potforce_cpu(check=check)
  else
     call struct_potforce_gpu()
  end if
end subroutine

subroutine struct_potforce_cpu(check)
  use gnn, only : gnn_potforce
  use colvar, only : colvar_internal_coordinates
  real*8 :: tpforce(3,natom),tpcoor(3*natom),tpinput(4*natom-9,1,1),tpoutput(3*natom,1,1),tpmat(3,3),tpintercoor(4*natom-3)
  logical,intent(in),optional :: check

  if ( ifmartini .eqv. .true. ) then
     if ( imin == 1 ) then
        call martini_potforce_cpu(epot,ifapplyconstraint=.true.,ifcalpot=ifcalpot)
     else
        call martini_potforce_cpu(epot,check=check,ifcalpot=ifcalpot)
     end if
  else if ( deepmode == 2 ) then
     call gnn_potforce(tpcoor=nowcoor,tppot=epot,tpforce=nowforce)
  else
     if ( ipb == 0 ) then
        call gb_potforce(nowcoor,epot,tpfrc=nowforce,check=check)
     else
        call pme_potforce(nowcoor,epot,tpfrc=nowforce,check=check)
     end if
  end if

end subroutine

! calculate the potential and force
subroutine struct_potforce_gpu()
  use gnn, only : gnn_potforce
  if ( ifmartini .eqv. .true. ) then
     if ( imin == 1 ) then
        call martini_potforce_gpu(epot_d,ifapplyconstraint=.true.,ifcalpot_d=ifcalpot_d)
     else
        call martini_potforce_gpu(epot_d,ifcalpot_d=ifcalpot_d)
     end if
  else if ( deepmode == 2 ) then
     call gnn_potforce(tpcoor_d=nowcoor_d,tppot_d=epot_d,tpforce_d=nowforce_d)
  else
     if ( ipb == 0 ) then
        call cudagb_potforce()
     else
        call cudapme_potforce()
     end if
  end if
end subroutine

! Steepest descent method and the conjugate gradient method
subroutine struct_minimize(opttotstep, optsdpstep, rms, printstep)
  integer,intent(in) :: opttotstep,optsdpstep,printstep
  real*8,intent(in) :: rms

  if ( icuda == 0 ) then
     if ( ioptmethod == 1 ) then
        call struct_minimize_cpu_sdpcg(opttotstep, optsdpstep, rms, printstep)
     else if ( ioptmethod == 2 ) then
        call struct_minimize_cpu_lbfgs(opttotstep, rms, printstep)
     end if
  else
     if ( ioptmethod == 1 ) then
        call struct_minimize_gpu_sdpcg(opttotstep, optsdpstep, rms, printstep)
     else if ( ioptmethod == 2 ) then
        call struct_minimize_gpu_lbfgs(opttotstep, rms, printstep)
     end if
     nowcoor = nowcoor_d
  end if
end subroutine

! Steepest descent method and the conjugate gradient method
subroutine struct_minimize_cpu_sdpcg(opttotstep, optsdpstep, rms, printstep)
  integer,intent(in) :: opttotstep,optsdpstep,printstep
  real*8,intent(in) :: rms
  integer :: istep,tpnatom,iatom
  real*8 :: stepsize,tpnorm,prenorm,prevec(3,natom)
  real*8 :: stepsizemin

  stepsizemin=1d-6; stepsize=stepsizemin; prenorm=0d0; tpnorm=0d0; nowforce=0d0; tpnatom = natom

  tpnatom = 0
  do iatom = 1, natom
     if ( radius(iatom) == 0d0 ) cycle
     tpnatom = tpnatom + 1 
  end do

  do istep=1,opttotstep
     call struct_potforce_cpu()

     call norm2d(natom*3,nowforce,tpnorm)

     if ( procid == 0 .and. (istep == 1 .or. mod(istep,printstep) == 0) ) then
        print "(a5,i5,a,f12.3,a5,f12.6)","Step ",istep,", Epot ",epot,", RMS  ",tpnorm/sqrt(dble(3*tpnatom))
     end if
     if ( tpnorm/sqrt(dble(3*tpnatom)) < rms ) then
        if ( procid == 0 ) print "(a,i5)","Optimization satisfies the RMS criterion at step ",istep
        exit
     end if

     if ( tpnorm > prenorm ) then
        stepsize = stepsize * 0.4d0
        if ( stepsize < stepsizemin ) stepsize = stepsizemin
     else
        stepsize = stepsize*1.5d0
     end if

     if ( istep > optsdpstep  ) then
        nowforce = nowforce + (tpnorm/prenorm)*prevec
        call norm2d(natom*3,nowforce,tpnorm)
     end if

     nowcoor = nowcoor + stepsize*nowforce/tpnorm
     if ( ifmartini ) call martini_virtual_site_set_coordinate_cpu()

     prevec=nowforce; prenorm=tpnorm
  end do
end subroutine

! L-BFGS optimization on CPU
! Jorge Nocedal
! Updating quasi-Newton matrices with limited storage.
! Mathematics of Computation. 1980, 35: 773-782 (page 779)

subroutine struct_minimize_cpu_lbfgs(opttotstep, rms, printstep)
  integer,intent(in) :: opttotstep,printstep
  real*8,intent(in) :: rms
  integer,parameter :: m = 6
  integer :: istep,tpnatom,iatom,i,j,k,tpnstep
  real*8,dimension(3*natom) :: dk,sk,yk
  real*8 :: tpvec(3),tpnorm,gdotd,rho,sigma,gk(3*natom),oldf,newf,beta,s(3*natom,m),y(3*natom,m),alpha(m),ydots(m)

  tpnorm=0d0; nowforce=0d0; tpnatom = natom

  tpnatom = 0
  do iatom = 1, natom
     if ( radius(iatom) == 0d0 ) cycle
     tpnatom = tpnatom + 1
  end do

  rho = 0.55d0    ! rho^x = alpha, x -> m
  sigma = 0.4d0   ! c1

  ! initial direction
  call struct_potforce_cpu()
  call norm2d(natom*3,nowforce,tpnorm)
  do i = 1, natom
     gk(3*i-2:3*i) = -nowforce(1:3,i)
  end do
  dk = -gk/tpnorm

  do istep = 1, opttotstep

     call struct_potforce_cpu()

     do i = 1, natom
        gk(3*i-2:3*i) = -nowforce(1:3,i)
     end do

     call norm2d(natom*3,nowforce,tpnorm)
     if ( procid == 0 .and. (istep == 1 .or. mod(istep,printstep) == 0) ) then
        print "(a5,i5,a,f12.3,a5,f12.6)","Step ",istep,", Epot ",epot,", RMS  ",tpnorm/sqrt(dble(3*tpnatom))
     end if
     if ( tpnorm/sqrt(dble(3*tpnatom)) < rms ) then
        if ( procid == 0 ) print "(a,i5)","Optimization satisfies the RMS criterion at step ",istep
        exit
     end if

     ! Wolfe condition
     ! https://fshen.org/en/2020/11-22-l-bfgs-and-wolfe-condition/#wolfe-condition
     ! sk = x(k+1) - x(k), yk = g(k+1) - g(k)
     gdotd = dot_product(gk,dk); oldf = epot; nowvel = nowcoor
     do i = 0, 20
        sk = (rho**i)*dk   ! alpha*pk
        do j = 1, natom
           nowcoor(1:3, j) = nowvel(1:3, j) + sk(3*j-2:3*j)
        end do
        if ( ifmartini ) call martini_virtual_site_set_coordinate_cpu()
        call struct_potforce_cpu(); newf = epot
        if ( newf < oldf + sigma*(rho**i)*gdotd ) exit
     end do

     do i = 1, natom
        tpvec(1:3) = -nowforce(1:3,i)
        yk(3*i-2:3*i) = tpvec - gk(3*i-2:3*i)
        gk(3*i-2:3*i) = tpvec
     end do

     if ( istep > m ) then
        do k = 1, m - 1
           s(:,k) = s(:,k + 1); y(:,k) = y(:,k + 1)
           ydots(k) = ydots(k+1)
        end do
        s(:,m) = sk; y(:,m) = yk; tpnstep = m
        ydots(m) = dot_product(yk,sk)
     else
        s(:,istep) = sk; y(:,istep) = yk; tpnstep = istep
        ydots(istep) = dot_product(yk,sk)
     end if

     do k = tpnstep, 1, -1
        alpha(tpnstep-k+1) = dot_product(s(:,k),gk)/ydots(k)   ! alpha(k) = s(k)*q(k+1)/y(k)*s(k)
        gk = gk - alpha(tpnstep-k+1)*y(:,k)                    ! g(k) = g(k+1) - alpha(k)*y(k)
     end do
     do k = 1, tpnstep
        beta = dot_product(y(:,k),gk)/ydots(k)                 ! beta(k) = y(k)*r(k)/y(k)*s(k)
        gk = gk + s(:,k)*(alpha(tpnstep - k + 1) - beta)       ! r(k+1) = r(k) + s(k)*(alpha(k)-beta(k))
     end do
     dk = -gk/sqrt(dot_product(gk,gk))
  end do
end subroutine

! Steepest descent method and the conjugate gradient method
subroutine struct_minimize_gpu_sdpcg(opttotstep, optsdpstep, rms, printstep)
  integer,intent(in) :: opttotstep,optsdpstep,printstep
  real*8,intent(in) :: rms
  integer :: istep, tpnatom, iatom
  real*8 :: tpnorm,prenorm,stepsize
  real*8 :: stepsizemin,tpradarray(natom)

  stepsizemin=1d-6; stepsize=stepsizemin; tpnorm=0d0; prenorm=0.0d0; printcvstep=1
  stepsize_d=stepsize; eprehalfkin_d=prenorm; ekin_d=tpnorm
  ifcalpot_d=.true.; prevel_d=0.0d0  ! preforce

  tpnatom = 0; tpradarray = radius_d 
  do iatom = 1, natom
     if ( tpradarray(iatom) /= 0d0 ) tpnatom = tpnatom + 1
  end do

  do istep=1,opttotstep

     call struct_potforce_gpu()
     call struct_minimize_norm_nowforce<<<nblockatom,cudathread,cudathread*4>>>()
     call struct_minimize_norm_nowforce_sum<<<1,cudathread,cudathread*4>>>()
     tpnorm=ekin_d

     if ( procid == 0 ) then
        if ( istep == 1 .or. mod(istep,printstep) == 0 ) then
           epot = epot_d
           print "(a5,i5,a,f12.3,a5,f12.6)","Step ",istep,", Epot ",epot,", RMS  ",tpnorm/sqrt(dble(3*tpnatom))
           ifcalpot_d = .false.
        else if ( mod(istep+1,printstep) == 0 ) then
           ifcalpot_d = .true.
        end if
     end if

     if ( sqrt(tpnorm/dble(3*tpnatom)) < rms ) then
        if ( procid == 0 ) print "(a,i5)","Optimization satisfies the RMS criterion at step ",istep
        exit
     end if

     if ( tpnorm > prenorm ) then
        stepsize=stepsize*0.4d0
        if ( stepsize < stepsizemin ) stepsize = stepsizemin
     else
        stepsize = stepsize*1.5d0
     end if
     if ( istep > optsdpstep  ) then
        call struct_minimize_cg_nowforce<<<nblockatom,cudathread>>>()
        call struct_minimize_norm_nowforce<<<nblockatom,cudathread,cudathread*4>>>()
        call struct_minimize_norm_nowforce_sum<<<1,cudathread,cudathread*4>>>()
        tpnorm = ekin_d
     end if
     stepsize_d=stepsize/tpnorm
     call struct_minimize_update_nowcoor_sdp<<<nblockatom,cudathread>>>()

     if ( ifmartini ) call martini_virtual_site_set_coordinate_gpu()

     eprehalfkin_d=ekin_d; prenorm=tpnorm   ! save the previous norm of the force array on both CPU and GPU
  end do
end subroutine

! L-BFGS optimization on GPU
subroutine struct_minimize_gpu_lbfgs(opttotstep, rms, printstep)
  integer,intent(in) :: opttotstep,printstep
  real*8,intent(in) :: rms
  integer,parameter :: m = 6
  integer :: istep, tpnatom, iatom, tpnstep, i, j, k
  real*8 :: tpradarray(natom),tpscalor
  real*8 :: tpnorm,gdotd,rho,sigma,gk(3*natom),oldf,newf,alpha(m),ydots(m)
  real*8,device ::  dotsum_d
  real,device :: s_d(3*natom,m),y_d(3*natom,m),rho_d
  real,device,dimension(3*natom) :: gk_d,dk_d,sk_d,yk_d

  ifcalpot_d=.true.; printcvstep=1
  tpnatom = 0; tpradarray = radius_d
  do iatom = 1, natom
     if ( tpradarray(iatom) /= 0d0 ) tpnatom = tpnatom + 1
  end do

  rho = 0.55d0; rho_d = rho    ! rho^x = alpha, x -> m
  sigma = 0.4d0   ! c1

  call struct_potforce_gpu()
  call struct_minimize_norm_nowforce<<<nblockatom,cudathread,cudathread*4>>>()
  call struct_minimize_norm_nowforce_sum<<<1,cudathread,cudathread*4>>>()
  tpnorm=ekin_d

  do i = 1, natom
     gk(3*i-2:3*i) = -nowforce_d(1:3,i)
  end do
  dk_d = -gk/tpnorm; gk_d = gk

  do istep = 1, opttotstep

     call struct_potforce_gpu()
     call struct_minimize_norm_nowforce<<<nblockatom,cudathread,cudathread*4>>>()
     call struct_minimize_norm_nowforce_sum<<<1,cudathread,cudathread*4>>>()
     tpnorm=ekin_d

     if ( procid == 0 ) then
        if ( istep == 1 .or. mod(istep,printstep) == 0 ) then
           epot = epot_d
           print "(a5,i5,a,f12.3,a5,f12.6)","Step ",istep,", Epot ",epot,", RMS  ",tpnorm/sqrt(dble(3*tpnatom))
        end if
     end if
     if ( tpnorm/sqrt(dble(3*tpnatom)) < rms ) then
        if ( procid == 0 ) print "(a,i5)","Optimization satisfies the RMS criterion at step ",istep
        exit
     end if

     dotsum_d = 0.0d0
     call struct_minimize_lbfgs_update_gk<<<nblockatom,cudathread>>>(gk_d,dk_d,dotsum_d)
     gdotd  = dotsum_d

     oldf = epot_d
     do i = 0, 20
        call struct_minimize_lbfgs_update_coor<<<nblockatom,cudathread>>>(dk_d,sk_d,rho_d,i)
        if ( ifmartini ) call martini_virtual_site_set_coordinate_gpu()
        call struct_potforce_gpu(); newf = epot_d
        if ( newf < oldf + sigma*(rho**i)*gdotd ) exit
     end do
     call struct_minimize_lbfgs_update_yk<<<nblockatom,cudathread>>>(gk_d,yk_d)

     if ( istep > m ) then
        tpnstep = m
        do k = 1, m - 1
           call cudatop_vec_scale<<<(3*natom-1)/32+1,32>>>(3*natom,s_d(:,k),1d0,s_d(:,k+1))
           call cudatop_vec_scale<<<(3*natom-1)/32+1,32>>>(3*natom,y_d(:,k),1d0,y_d(:,k+1))
           ydots(k) = ydots(k+1)
        end do
        call cudatop_vec_scale<<<(3*natom-1)/32+1,32>>>(3*natom,s_d(:,m),1d0,sk_d)
        call cudatop_vec_scale<<<(3*natom-1)/32+1,32>>>(3*natom,y_d(:,m),1d0,yk_d)
        dotsum_d = 0d0
        call cudatop_vec_dot<<<(3*natom-1)/32+1,32>>>(3*natom,1d0,yk_d,sk_d,dotsum_d)
        ydots(m) = dotsum_d
     else
        tpnstep = istep
        call cudatop_vec_scale<<<(3*natom-1)/32+1,32>>>(3*natom,s_d(:,istep),1d0,sk_d)
        call cudatop_vec_scale<<<(3*natom-1)/32+1,32>>>(3*natom,y_d(:,istep),1d0,yk_d)
        dotsum_d = 0d0
        call cudatop_vec_dot<<<(3*natom-1)/32+1,32>>>(3*natom,1d0,yk_d,sk_d,dotsum_d)
        ydots(istep) = dotsum_d
     end if

     do k = tpnstep, 1, -1
        dotsum_d = 0.0d0; tpscalor = 1.0d0/ydots(k)
        call cudatop_vec_dot<<<(3*natom-1)/32+1,32>>>(3*natom,tpscalor,s_d(:,k),gk_d,dotsum_d)
        alpha(tpnstep-k+1) = dotsum_d; tpscalor = -alpha(tpnstep-k+1)
        call cudatop_vec_add<<<(3*natom-1)/32+1,32>>>(3*natom,gk_d,tpscalor,y_d(:,k))
     end do

     do k = 1, tpnstep
        dotsum_d = 0.0d0; tpscalor = 1.0d0/ydots(k)
        call cudatop_vec_dot<<<(3*natom-1)/32+1,32>>>(3*natom,tpscalor,y_d(:,k),gk_d,dotsum_d)
        tpscalor = alpha(tpnstep-k+1) - dotsum_d
        call cudatop_vec_add<<<(3*natom-1)/32+1,32>>>(3*natom,gk_d,tpscalor,s_d(:,k))
     end do

     dotsum_d = 0.0d0
     call cudatop_vec_dot<<<(3*natom-1)/32+1,32>>>(3*natom,1d0,gk_d,gk_d,dotsum_d)
     tpscalor = dotsum_d; tpscalor = -1d0/sqrt(tpscalor)
     call cudatop_vec_scale<<<(3*natom-1)/32+1,32>>>(3*natom,dk_d,tpscalor,gk_d)

  end do

end subroutine

attributes(global) subroutine struct_minimize_lbfgs_update_gk(gk_d,dk_d,dotsum_d)
  real,intent(out) :: gk_d(3*natom_d)
  real,intent(in) :: dk_d(3*natom_d)
  real*8,intent(out) :: dotsum_d
  integer :: iatom
  real :: tpsum,tpvalue

  iatom = (blockidx%x-1)*blockdim%x+threadidx%x
  if ( iatom <= natom_d ) then
     gk_d(3*iatom-2:3*iatom) = -nowforce_d(1:3,iatom)
     tpsum = dot_product(gk_d(3*iatom-2:3*iatom),dk_d(3*iatom-2:3*iatom))
  else
     gk_d(3*iatom-2:3*iatom) = 0.0; tpsum = 0.0
  end if

  iatom = 1
  do while (iatom<=16)
     tpvalue = __shfl_xor(tpsum,iatom); tpsum = tpsum + tpvalue
     iatom = iatom*2
  end do
  if ( threadidx%x == 1 ) tpvalue = atomicadd(dotsum_d,dble(tpsum))
end subroutine

attributes(global) subroutine struct_minimize_lbfgs_update_coor(dk_d,sk_d,rho_d,i)
  real,intent(in) :: dk_d(3*natom_d)
  real,intent(out) :: sk_d(3*natom_d)
  real,intent(in) :: rho_d
  integer,intent(in),value :: i
  integer :: iatom

  iatom = (blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > natom_d ) return

  sk_d(3*iatom-2:3*iatom) = (rho_d**i)*dk_d(3*iatom-2:3*iatom)
  if ( i == 0 ) prevel_d(1:3,iatom) = nowcoor_d(1:3,iatom)
  nowcoor_d(1:3, iatom) = prevel_d(1:3, iatom) + sk_d(3*iatom-2:3*iatom)
end subroutine

attributes(global) subroutine struct_minimize_lbfgs_update_yk(gk_d,yk_d)
  real,intent(inout) :: gk_d(3*natom_d)
  real,intent(out) :: yk_d(3*natom_d)
  integer :: iatom
  real :: tpvec(3)

  iatom = (blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > natom_d ) return

  tpvec(1:3) = -nowforce_d(1:3,iatom)
  yk_d(3*iatom-2:3*iatom) = tpvec - gk_d(3*iatom-2:3*iatom)
  gk_d(3*iatom-2:3*iatom) = tpvec
end subroutine

! calculate the norm of the force of each atom
attributes(global) subroutine struct_minimize_norm_nowforce()
  real,shared :: threadpot(blockdim%x)
  integer :: ithread,iblock,nthread,iatom

  ithread=threadidx%x; iblock=blockidx%x; nthread=blockdim%x; iatom=(iblock-1)*nthread+ithread
  if (iatom<=natom_d) then
     threadpot(ithread)=dot_product(nowforce_d(1:3,iatom),nowforce_d(1:3,iatom))
  else
     threadpot(ithread)=0.0
  end if
  call cudatop_vec_sum(ithread,nthread,threadpot)
  if ( ithread == 1 ) blockkin_d(iblock)=threadpot(1)
end subroutine

! calculate the norm of the force
attributes(global) subroutine struct_minimize_norm_nowforce_sum()
  integer :: i,ithread,iblock,nthread
  real,shared :: threadpot(blockdim%x)

  ithread=threadidx%x; iblock=blockidx%x; nthread=blockdim%x; threadpot(ithread)=0.0
  do i=ithread,nblockatom_d,nthread
     threadpot(ithread) = threadpot(ithread) + blockkin_d(i)
  end do
  call cudatop_vec_sum(ithread,nthread,threadpot)
  if ( ithread == 1 ) ekin_d=sqrt(threadpot(1))
end subroutine

! determine the direction by the conjugate gradient method
attributes(global) subroutine struct_minimize_cg_nowforce()
  integer :: iatom
  real*8 :: tpscale

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x
  if ( iatom <= natom_d .and. radius_d(iatom) /= 0.0 ) then
     nowforce_d(1:3,iatom) = nowforce_d(1:3,iatom) + (ekin_d/eprehalfkin_d)*prevel_d(1:3,iatom)
  end if
end subroutine

! optimize the structure along the determined direction
attributes(global) subroutine struct_minimize_update_nowcoor_sdp()
  integer :: iatom
  real*8 :: tpscale

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x
  if ( iatom <= natom_d .and. radius_d(iatom) /= 0.0 ) then
     nowcoor_d(1:3,iatom) = nowcoor_d(1:3,iatom) + stepsize_d*nowforce_d(1:3,iatom)
     prevel_d(1:3,iatom) = nowforce_d(1:3,iatom)
  end if
end subroutine

end module
