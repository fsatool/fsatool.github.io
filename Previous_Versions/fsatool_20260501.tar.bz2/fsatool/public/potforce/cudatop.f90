module cudatop
  use pubmod; use ambertop
  implicit none

  integer,device :: igb_d,igbsa_d,ipb_d
  real*8,device :: ekin_d,ehalfkin_d,eprehalfkin_d,erefkin_d,totmass_d
  real*8,device :: ebond_d,eangle_d,evdw14_d,eelec14_d,edihe_d,epot_d,eelec_d,evdw_d,enb14_d,ecorr_d
  real*8,device :: totforce_d(3),totmomentum_d(3),vellimit_d,forcelimit_d
  real*8,device,allocatable,dimension(:,:),target :: nowcoor_d,nowvel_d,nowforce_d,prevel_d,bioatomtpforce_d

  real,device :: pmecell_d(3)

  integer,parameter :: cudathread=32
  logical,device :: ifcalfrc_d,ifcalpot_d,ifblocksum_d
  real,device,allocatable,dimension(:) :: mass_d,dt_inv_mass_d,radius_d
  character*4,device,dimension(:),allocatable :: name_d

  integer,device :: nres_d,natom_d,nbondh_d,nbondnoh_d,nbondtype_d,nbond_d,printcvstep_d,nsolventmol_d,firstsolventatom_d,firstsolventmol_d,nmol_d,nbioatom_d,nbiomol_d,nbiobond_d
  integer,device,allocatable,dimension(:),target :: bondh_d,bondnoh_d,bondatom_d,atombondindex_d,atombondlist_d,bondhatom_d
  real,device,allocatable,dimension(:),target :: bondforceconst_d,bondeqval_d

  integer,device :: nangleh_d,nanglenoh_d,nangletype_d,nangle_d
  integer,device,allocatable,dimension(:),target :: angleh_d,anglenoh_d,angleatom_d,atomangleindex_d,atomanglelist_d
  real,device,allocatable,dimension(:),target :: angleforceconst_d,angleeqval_d

  integer,device :: ndiheh_d,ndihenoh_d,ndihetype_d,ndihedral_d,ndihegroup_d
  integer,device,allocatable,dimension(:),target :: diheh_d,dihenoh_d,diheatom_d,atomdiheindex_d,atomdihelist_d,dihegroupindex_d
  real,device,allocatable,dimension(:),target :: diheforceconst_d,diheperiod_d,dihephase_d

  integer,device :: nnb14_d,nvdwtype_d
  integer,device,allocatable,dimension(:),target :: atomnb14index_d,atomnb14list_d
  integer,device,allocatable,dimension(:,:),target :: nonbond14_d
  real,device,allocatable,dimension(:),target :: scale14elec_d,scale14vdw_d,charge_d
  real,device,allocatable,dimension(:),target :: vdweps_d,vdwsigma_d

  integer,device :: nnb_d
  integer,device,allocatable,dimension(:),target :: nexcludedatoms_d,excludedatomlist_d

  integer :: nblockbondedterm
  integer,device :: nblockatom_d,nblockbondedterm_d
  real*8,device,allocatable,dimension(:) :: blockkin_d,blockhalfkin_d

  integer,device :: cvnatom_d
  integer,device,allocatable,dimension(:) :: cvatomindex_d
  real*8,device,allocatable,dimension(:,:) :: cvatomcoor_d,cvatomforce_d

  real,device :: pi_d = 3.141592653589793

  integer,device :: nblocknb_d,nblock14_d,nblockbond_d,nblockangle_d,nblockdihe_d
  integer :: nblocknb,nblock14,nblockbond,nblockangle,nblockdihe,nblockatom

  real,device,allocatable,dimension(:),target :: blockpotelec_d,blockpotvdw_d
  real,device,allocatable,dimension(:),target :: blockpotnb14_d,blockpotbond_d,blockpotangle_d,blockpotdihe_d
  integer,device,allocatable,dimension(:),target :: gpufrcindex_d,gpufrcposbond_d,gpufrcposnb14_d
  integer,device,allocatable,dimension(:),target :: gpufrcposangle_d,gpufrcposdihe_d
  real*8,device,allocatable,dimension(:,:),target :: gpufrc_d

  interface cudatop_vec_sum
    attributes(device) subroutine cudatop_vec_sum_single(ithread,nthread,arraydata)
      integer :: nthread,ithread
      real,dimension(nthread) :: arraydata
    end subroutine
    attributes(device) subroutine cudatop_vec_sum_double(ithread,nthread,arraydata)
      integer :: nthread,ithread
      real*8,dimension(nthread) :: arraydata
    end subroutine
    attributes(device) subroutine cudatop_vec_sum_int(ithread,nthread,arraydata)
      integer :: nthread,ithread
      integer,dimension(nthread) :: arraydata
    end subroutine
  end interface

contains

! prepare the arrays for the calculation of the bonded interactions on GPU
subroutine cudatop_initialize()
  integer :: itype,blocknum,iatom,tpi,tpnum,i,j,k,l,idihe,index,iangle,ibond,iblock
  integer,dimension(:),allocatable :: atomdiheindex,atomdihelist,atomangleindex,atomanglelist
  integer,dimension(:),allocatable :: atombondindex,atombondlist,atomnb14index,atomnb14list

  nmol_d = nmol; nres_d = nres; nsolventmol_d = nsolventmol
  firstsolventmol_d = firstsolventmol; firstsolventatom_d = firstsolventatom

  natom_d=natom; nbioatom_d=nbioatom; nbiomol_d=nbiomol; nbiobond_d=nbiobond; vellimit_d=vellimit; forcelimit_d = forcelimit
  nbondh_d=nbondh;  nbondnoh_d=nbondnoh; nbondtype_d=nbondtype
  allocate(bondh_d(nbondh*3),bondnoh_d(nbondnoh*3)); bondh_d=bondh; bondnoh_d=bondnoh
  allocate(bondforceconst_d(nbondtype)); bondforceconst_d=bondforceconst
  allocate(bondeqval_d(nbondtype)); bondeqval_d=bondeqval

  ibond = nbond;  if ( ishake == 1 ) ibond = nbondnoh
  nbond_d=ibond; allocate(bondatom_d(3*ibond),bondhatom_d(3*nbondh))
  bondatom_d(1:3*ibond)=bondatom(1:3*ibond); bondhatom_d(1:3*nbondh)=bondhatom(1:3*nbondh)

  nangleh_d=nangleh;  nanglenoh_d=nanglenoh; nangletype_d=nangletype
  allocate(angleh_d(nangleh*4),anglenoh_d(nanglenoh*4)); angleh_d=angleh; anglenoh_d=anglenoh
  allocate(angleforceconst_d(nangletype)); angleforceconst_d=angleforceconst
  allocate(angleeqval_d(nangletype)); angleeqval_d=angleeqval
  nangle_d=nangle
  allocate(angleatom_d(4*nangle)); angleatom_d=angleatom

  ndiheh_d=ndiheh;  ndihenoh_d=ndihenoh; ndihetype_d=ndihetype
  allocate(diheh_d(ndiheh*5),dihenoh_d(ndihenoh*5)); diheh_d=diheh; dihenoh_d=dihenoh
  allocate(diheforceconst_d(ndihetype)); diheforceconst_d=diheforceconst
  allocate(diheperiod_d(ndihetype)); diheperiod_d=diheperiod
  allocate(dihephase_d(ndihetype)); dihephase_d=dihephase
  ndihedral_d=ndihedral
  allocate(diheatom_d(5*ndihedral)); diheatom_d=diheatom
  ndihegroup_d=ndihegroup
  allocate(dihegroupindex_d(ndihegroup+1)); dihegroupindex_d=dihegroupindex

  nnb14_d=nnb14; nvdwtype_d=nvdwtype
  allocate(nonbond14_d(3,nnb14)); nonbond14_d=nonbond14
  allocate(scale14elec_d(ndihetype),scale14vdw_d(ndihetype)); scale14elec_d=scale14elec; scale14vdw_d=scale14vdw
  allocate(charge_d(natom)); charge_d = charge

  allocate(vdweps_d(natom),vdwsigma_d(natom)); vdwsigma_d = vdwsigma; vdweps_d = vdweps

  nnb_d=nnb
  allocate(nexcludedatoms_d(natom)); nexcludedatoms_d=nexcludedatoms 
  allocate(excludedatomlist_d(nnb)); excludedatomlist_d=excludedatomlist

  ifcalfrc_d=ifcalfrc
  allocate(nowcoor_d(3,natom),nowvel_d(3,natom),nowforce_d(3,natom),bioatomtpforce_d(3,natom),prevel_d(3,natom))
  nowcoor_d=nowcoor; nowvel_d = nowvel; nowforce_d = 0.0d0; bioatomtpforce_d=0d0; prevel_d = 0d0

  allocate(name_d(natom)); name_d=name
  allocate(mass_d(natom),dt_inv_mass_d(natom)); mass_d=mass; dt_inv_mass_d=deltatime*timescale/mass
  allocate(radius_d(natom)); radius_d=radius

  nblock14=(nnb14-1)/cudathread+1; nblock14_d=nblock14
  nblockbond=(ibond-1)/cudathread+1; nblockbond_d=nblockbond
  nblockangle=(nangle-1)/cudathread+1; nblockangle_d=nblockangle
  nblockdihe=(ndihegroup-1)/cudathread+1; nblockdihe_d=nblockdihe

  nblockbondedterm = nblockbond+nblockangle+nblockdihe+nblock14; nblockbondedterm_d=nblockbondedterm

  nblockatom = (natom-1)/cudathread + 1; nblockatom_d=nblockatom
  allocate(blockkin_d(nblockatom_d)); blockkin_d=0.0

  ifblocksum_d=ifblocksum 
  if (ifblocksum_d .eqv. .true. ) then
     allocate(blockhalfkin_d(nblockatom_d)); blockhalfkin_d=0.0
     allocate(blockpotnb14_d(nblock14)); blockpotnb14_d=0.0
     allocate(blockpotbond_d(nblockbond),blockpotangle_d(nblockangle),blockpotdihe_d(nblockdihe))
     blockpotbond_d=0.0; blockpotangle_d=0.0; blockpotdihe_d=0.0
  end if
end subroutine

! calculate the bonded energy interactions
attributes(global) subroutine cudatop_potforce_bondedterms()
  integer :: iblock

  iblock=blockidx%x
  if ( iblock <= nblockbond_d ) then
     call cudatop_potforce_bond(iblock)
  else
     iblock = iblock - nblockbond_d
     if ( iblock <= nblockangle_d ) then
        call cudatop_potforce_angle(iblock)
     else
        iblock = iblock - nblockangle_d
        if ( iblock <= nblockdihe_d ) then
           call cudatop_potforce_dihe(iblock)
        else
           iblock = iblock - nblockdihe_d
           if ( iblock <= nblock14_d ) then
              call cudatop_potforce_elecvdw14(iblock)
           end if
        end if
     end if
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_bond(iblock)
  integer :: iblock
  if ( ifcalpot_d ) then
     call cudatop_potforce_bond_potfrc(iblock)
  else
     call cudatop_potforce_bond_frc(iblock)
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_bond_potfrc(iblock)
  integer :: i,j,ibond,ithread,itype,iblock
  real :: tpvec(3),tpdis,tpdelta,tpk,tpeqdis,tpfactor,tppot
  real*8 :: tptpvec(3)

  ithread=threadidx%x; ibond=(iblock-1)*blockdim%x+ithread; itype = 0

  if ( ibond <= nbond_d ) then
     j=3*ibond-2; itype=bondatom_d(j+2)

     if ( itype > 0 ) then
        i=bondatom_d(j); j=bondatom_d(j+1)
        tpk=bondforceconst_d(itype); tpeqdis=bondeqval_d(itype)
        tpvec(1:3) = nowcoor_d(1:3,i) - nowcoor_d(1:3,j)
        tpdis = sqrt(dot_product(tpvec,tpvec))
        tpdelta = tpdis - tpeqdis; tpfactor = tpk*tpdelta
      
        ! if ( ifcalfrc_d .eqv. .true. ) then
           tptpvec = (-2.0*tpfactor/tpdis)*tpvec
      
           if ( ifblocksum_d ) then
              ibond = 2*ibond-1
              gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposbond_d(ibond))=tptpvec(1:3)
              gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposbond_d(ibond+1))=-tptpvec(1:3)
           else
              tppot = atomicadd(nowforce_d(1,i),tptpvec(1))
              tppot = atomicadd(nowforce_d(2,i),tptpvec(2))
              tppot = atomicadd(nowforce_d(3,i),tptpvec(3))
              tppot = atomicadd(nowforce_d(1,j),-tptpvec(1))
              tppot = atomicadd(nowforce_d(2,j),-tptpvec(2))
              tppot = atomicadd(nowforce_d(3,j),-tptpvec(3))
           end if
        ! end if
     end if
  end if

  ! if ( ifcalpot_d .eqv. .false. ) return
  tppot = 0.0; if ( itype > 0 ) tppot = tpfactor*tpdelta

  i = 1
  do while (i<=16)
     tpfactor = __shfl_xor(tppot,i); tppot = tppot + tpfactor
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotbond_d(iblock)=tppot
     else
        tpfactor = atomicadd(ebond_d,dble(tppot))
     end if
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_bond_frc(iblock)
  integer :: i,j,ibond,ithread,itype,iblock
  real :: tpvec(3),tpdis,tpk,tpeqdis
  real*8 :: tptpvec(3)

  ithread=threadidx%x; ibond=(iblock-1)*blockdim%x+ithread; if ( ibond > nbond_d ) return
  j=3*ibond-2; itype=bondatom_d(j+2); if ( itype == 0 ) return

  i=bondatom_d(j); j=bondatom_d(j+1)
  tpk=bondforceconst_d(itype); tpeqdis=bondeqval_d(itype)
  tpvec(1:3) = nowcoor_d(1:3,i) - nowcoor_d(1:3,j)
  tpdis = sqrt(dot_product(tpvec,tpvec))
  tptpvec = (-2.0*tpk*(tpdis - tpeqdis)/tpdis)*tpvec

  if ( ifblocksum_d ) then
     ibond = 2*ibond-1
     gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposbond_d(ibond))=tptpvec(1:3)
     gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposbond_d(ibond+1))=-tptpvec(1:3)
  else
     tpdis = atomicadd(nowforce_d(1,i),tptpvec(1))
     tpdis = atomicadd(nowforce_d(2,i),tptpvec(2))
     tpdis = atomicadd(nowforce_d(3,i),tptpvec(3))
     tpdis = atomicadd(nowforce_d(1,j),-tptpvec(1))
     tpdis = atomicadd(nowforce_d(2,j),-tptpvec(2))
     tpdis = atomicadd(nowforce_d(3,j),-tptpvec(3))
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_bond_pot(iblock)
  integer :: i,j,ibond,ithread,itype,iblock
  real :: tpvec(3),tpdis,tpk,tpeqdis
  real*8 :: tppot

  ithread=threadidx%x; ibond=(iblock-1)*blockdim%x+ithread; tppot = 0.0

  if ( ibond <= nbond_d ) then
     j=3*ibond-2; itype=bondatom_d(j+2)
     if ( itype > 0 ) then
        i=bondatom_d(j); j=bondatom_d(j+1)
        tpk=bondforceconst_d(itype); tpeqdis=bondeqval_d(itype)
        tpvec(1:3) = nowcoor_d(1:3,i) - nowcoor_d(1:3,j)
        tpdis = sqrt(dot_product(tpvec,tpvec))
        tppot = tpk*(tpdis - tpeqdis)**2
     end if
  end if

  i = 1
  do while (i<=16)
     tpdis = __shfl_xor(tppot,i); tppot = tppot + tpdis
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotbond_d(iblock)=tppot
     else
        tpdis = atomicadd(ebond_d,tppot)
     end if
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_angle(iblock)
  integer :: iblock
  if ( ifcalpot_d ) then
     call cudatop_potforce_angle_potfrc(iblock)
  else
     call cudatop_potforce_angle_frc(iblock)
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_angle_potfrc(iblock)
  integer :: i,j,k,iangle,itype,ithread,iblock
  real :: tpk,tpeqval,tptheta,tpdelta,tppot
  real :: rijvec(3),rkjvec(3),tpvec1(3),rijsq,rkjsq,rijrkjinv,costheta
  real*8 :: tptpvec1(3),tptpvec2(3)

  ithread=threadidx%x
  iangle=(iblock-1)*blockdim%x+ithread; itype = 0; tppot=0.0

  if ( iangle <= nangle_d ) then
     k=4*iangle-3; itype=angleatom_d(k+3)
   
     if ( itype > 0 ) then
        i=angleatom_d(k); j=angleatom_d(k+1); k=angleatom_d(k+2);
        tpk=angleforceconst_d(itype); tpeqval=angleeqval_d(itype)
        tpvec1(1:3)=nowcoor_d(1:3,j)
        rijvec(1:3)=nowcoor_d(1:3,i) - tpvec1(1:3); rijsq=dot_product(rijvec,rijvec)
        rkjvec(1:3)=nowcoor_d(1:3,k) - tpvec1(1:3); rkjsq=dot_product(rkjvec,rkjvec)
        rijrkjinv=1.0/sqrt(rijsq*rkjsq); costheta=dot_product(rijvec,rkjvec)*rijrkjinv
        costheta = min(0.99999, max(-0.99999, costheta)); tptheta=acos(costheta)
        tpdelta = tptheta - tpeqval; tppot = tpk*tpdelta
      
        ! if ( ifcalfrc_d .eqv. .true. ) then
      
           tpk = (2.0*tppot)/sqrt(1.0-costheta**2); tppot=tppot*tpdelta
           tptpvec1 = ( (rkjvec(1:3)*rijrkjinv) - rijvec(1:3)*costheta/rijsq )*tpk
           tptpvec2 = ( (rijvec(1:3)*rijrkjinv) - rkjvec(1:3)*costheta/rkjsq )*tpk
      
           if ( ifblocksum_d ) then
              iangle = 3*iangle-2
              gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposangle_d(iangle)) = tptpvec1
              gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposangle_d(iangle+1)) = -(tptpvec1+tptpvec2)
              gpufrc_d(1:3,gpufrcindex_d(k)+gpufrcposangle_d(iangle+2)) = tptpvec2
           else
              tpk = atomicadd(nowforce_d(1,i),tptpvec1(1))
              tpk = atomicadd(nowforce_d(2,i),tptpvec1(2))
              tpk = atomicadd(nowforce_d(3,i),tptpvec1(3))
              tpk = atomicadd(nowforce_d(1,j),-(tptpvec1(1)+tptpvec2(1)))
              tpk = atomicadd(nowforce_d(2,j),-(tptpvec1(2)+tptpvec2(2)))
              tpk = atomicadd(nowforce_d(3,j),-(tptpvec1(3)+tptpvec2(3)))
              tpk = atomicadd(nowforce_d(1,k),tptpvec2(1))
              tpk = atomicadd(nowforce_d(2,k),tptpvec2(2))
              tpk = atomicadd(nowforce_d(3,k),tptpvec2(3))
           end if
        ! end if

     end if
  end if

  i = 1
  do while (i<=16)
     tpk = __shfl_xor(tppot,i); tppot = tppot + tpk
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotangle_d(iblock)=tppot
     else
        tpk = atomicadd(eangle_d,dble(tppot))
     end if
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_angle_frc(iblock)
  integer :: i,j,k,iangle,itype,ithread,iblock
  real :: tpk,tpeqval,tptheta
  real :: rijvec(3),rkjvec(3),tpvec(3),rijsq,rkjsq,rijrkjinv,costheta
  real*8 :: tptpvec1(3),tptpvec2(3)

  ithread=threadidx%x
  iangle=(iblock-1)*blockdim%x+ithread; if ( iangle > nangle_d ) return
  k=4*iangle-3; itype=angleatom_d(k+3); if ( itype == 0 ) return

  i=angleatom_d(k); j=angleatom_d(k+1); k=angleatom_d(k+2);

  tpk=angleforceconst_d(itype); tpeqval=angleeqval_d(itype)
  tpvec(1:3)=nowcoor_d(1:3,j)
  rijvec(1:3)=nowcoor_d(1:3,i) - tpvec(1:3); rijsq=dot_product(rijvec,rijvec)
  rkjvec(1:3)=nowcoor_d(1:3,k) - tpvec(1:3); rkjsq=dot_product(rkjvec,rkjvec)
  rijrkjinv=1.0/sqrt(rijsq*rkjsq); costheta=dot_product(rijvec,rkjvec)*rijrkjinv
  costheta = min(0.99999, max(-0.99999, costheta)); tptheta=acos(costheta)

  tpk = 2.0*tpk*(tptheta - tpeqval)/sqrt(1.0-costheta**2)
  tptpvec1 = ( (rkjvec(1:3)*rijrkjinv) - rijvec(1:3)*costheta/rijsq )*tpk
  tptpvec2 = ( (rijvec(1:3)*rijrkjinv) - rkjvec(1:3)*costheta/rkjsq )*tpk

  if ( ifblocksum_d ) then
     iangle = 3*iangle-2
     gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposangle_d(iangle)) = tptpvec1
     gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposangle_d(iangle+1)) = -(tptpvec1+tptpvec2)
     gpufrc_d(1:3,gpufrcindex_d(k)+gpufrcposangle_d(iangle+2)) = tptpvec2
  else
     tpk = atomicadd(nowforce_d(1,i),tptpvec1(1))
     tpk = atomicadd(nowforce_d(2,i),tptpvec1(2))
     tpk = atomicadd(nowforce_d(3,i),tptpvec1(3))
     tpk = atomicadd(nowforce_d(1,j),-(tptpvec1(1)+tptpvec2(1)))
     tpk = atomicadd(nowforce_d(2,j),-(tptpvec1(2)+tptpvec2(2)))
     tpk = atomicadd(nowforce_d(3,j),-(tptpvec1(3)+tptpvec2(3)))
     tpk = atomicadd(nowforce_d(1,k),tptpvec2(1))
     tpk = atomicadd(nowforce_d(2,k),tptpvec2(2))
     tpk = atomicadd(nowforce_d(3,k),tptpvec2(3))
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_angle_pot(iblock)
  integer :: i,j,k,iangle,itype,ithread,iblock
  real :: tpk,tpeqval
  real :: rijvec(3),rkjvec(3),tpvec(3),rijsq,rkjsq,costheta
  real*8 :: tppot

  ithread=threadidx%x; iangle=(iblock-1)*blockdim%x+ithread; tppot = 0.0

  if ( iangle <= nangle_d ) then
     k=4*iangle-3; itype=angleatom_d(k+3)
     if ( itype > 0 ) then
        i=angleatom_d(k); j=angleatom_d(k+1); k=angleatom_d(k+2) 
        tpk=angleforceconst_d(itype); tpeqval=angleeqval_d(itype)
        tpvec(1:3)=nowcoor_d(1:3,j)
        rijvec(1:3)=nowcoor_d(1:3,i) - tpvec(1:3); rijsq=dot_product(rijvec,rijvec)
        rkjvec(1:3)=nowcoor_d(1:3,k) - tpvec(1:3); rkjsq=dot_product(rkjvec,rkjvec)
        costheta=dot_product(rijvec,rkjvec)/sqrt(rijsq*rkjsq)
        costheta = min(0.99999, max(-0.99999, costheta))
        tppot = tpk*(acos(costheta) - tpeqval)**2
     end if 
  end if

  i = 1
  do while (i<=16)
     tpk = __shfl_xor(tppot,i); tppot = tppot + tpk
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotangle_d(iblock)=tppot
     else
        tpk = atomicadd(eangle_d,tppot)
     end if
  end if
end subroutine

! calculate the dihedral energy
attributes(device) subroutine cudatop_potforce_dihe(iblock)
  integer :: iblock
  if ( ifcalpot_d ) then
     call cudatop_potforce_dihe_potfrc(iblock)
  else
     call cudatop_potforce_dihe_frc(iblock)
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_dihe_potfrc(iblock)
  integer :: i,j,k,l,idihe,itype,ithread,iblock,idihegroup
  real :: rijvec(3),rkjvec(3),rklvec(3),vec1(3),vec2(3)
  real :: dot1inv,dot2inv,rijrkj,rkj,rkjsq,rklrkj,tpphase,tpphi,tppot
  real*8 :: tpvec1(3),tpvec2(3),tpvec(3)

  ithread=threadidx%x; idihegroup=(iblock-1)*blockdim%x+ithread; itype = 0

  if ( idihegroup <= ndihegroup_d ) then
     idihe=dihegroupindex_d(idihegroup)+1; l=5*idihe-4; itype = diheatom_d(l+4)
   
     if ( itype > 0 ) then
   
        i=diheatom_d(l); j=diheatom_d(l+1); k=diheatom_d(l+2); l=diheatom_d(l+3)
        vec1(1:3)=nowcoor_d(1:3,j); vec2(1:3)=nowcoor_d(1:3,k)
        rijvec(1:3) = nowcoor_d(1:3,i) - vec1(1:3)
        rkjvec(1:3) = vec2(1:3) - vec1(1:3)
        rklvec(1:3) = vec2(1:3) - nowcoor_d(1:3,l)
      
      !  call cudatop_cross_product(rijvec,rkjvec,vec1)
        vec1(1) = rijvec(2) * rkjvec(3) - rijvec(3) * rkjvec(2)
        vec1(2) = rijvec(3) * rkjvec(1) - rijvec(1) * rkjvec(3)
        vec1(3) = rijvec(1) * rkjvec(2) - rijvec(2) * rkjvec(1)
      
      !  call cudatop_cross_product(rkjvec,rklvec,vec2)
        vec2(1) = rkjvec(2) * rklvec(3) - rkjvec(3) * rklvec(2)
        vec2(2) = rkjvec(3) * rklvec(1) - rkjvec(1) * rklvec(3)
        vec2(3) = rkjvec(1) * rklvec(2) - rkjvec(2) * rklvec(1)
      
        dot1inv=1.0/dot_product(vec1,vec1); dot2inv=1.0/dot_product(vec2,vec2)
        tpphi = sqrt(dot1inv*dot2inv)*dot_product(vec1,vec2)
        tpphi = min(1.0, max(-1.0, tpphi))
        tpphi = sign(1.0,dot_product(rijvec,vec2))*acos( tpphi )
      
        tppot = 0.0
        do idihe=dihegroupindex_d(idihegroup)+1,dihegroupindex_d(idihegroup+1)
           itype=diheatom_d(5*idihe)
           tpphase = diheperiod_d(itype)*tpphi-dihephase_d(itype)
           tppot = tppot + diheforceconst_d(itype)*diheperiod_d(itype)*sin(tpphase)
        end do
      
      !  if ( ifcalfrc_d .eqv. .true. ) then
           rijrkj=dot_product(rijvec,rkjvec); rkjsq=dot_product(rkjvec,rkjvec)
           rkj=sqrt(rkjsq); rklrkj=dot_product(rklvec,rkjvec)
           tppot = tppot*rkj
           tpvec1(1:3) = tppot*dot1inv*vec1(1:3)
           tpvec2(1:3) = -tppot*dot2inv*vec2(1:3)
           tpvec(1:3) = (rijrkj*tpvec1(1:3) - rklrkj*tpvec2(1:3))/rkjsq
      
           if ( ifblocksum_d ) then
              idihe = 4*idihegroup-3
              gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposdihe_d(idihe))=tpvec1(1:3)
              gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposdihe_d(idihe+1))=-tpvec1(1:3)+tpvec(1:3)
              gpufrc_d(1:3,gpufrcindex_d(k)+gpufrcposdihe_d(idihe+2))=-tpvec2(1:3)-tpvec(1:3)
              gpufrc_d(1:3,gpufrcindex_d(l)+gpufrcposdihe_d(idihe+3))=tpvec2(1:3)
           else
              tppot = atomicadd(nowforce_d(1,i),tpvec1(1))
              tppot = atomicadd(nowforce_d(2,i),tpvec1(2))
              tppot = atomicadd(nowforce_d(3,i),tpvec1(3))
              tppot = atomicadd(nowforce_d(1,j),-tpvec1(1)+tpvec(1))
              tppot = atomicadd(nowforce_d(2,j),-tpvec1(2)+tpvec(2))
              tppot = atomicadd(nowforce_d(3,j),-tpvec1(3)+tpvec(3))
              tppot = atomicadd(nowforce_d(1,k),-tpvec2(1)-tpvec(1))
              tppot = atomicadd(nowforce_d(2,k),-tpvec2(2)-tpvec(2))
              tppot = atomicadd(nowforce_d(3,k),-tpvec2(3)-tpvec(3))
              tppot = atomicadd(nowforce_d(1,l),tpvec2(1))
              tppot = atomicadd(nowforce_d(2,l),tpvec2(2))
              tppot = atomicadd(nowforce_d(3,l),tpvec2(3))
           end if
      !  end if
   
     end if
  end if

  ! if ( ifcalpot .eqv. .false. ) return
  tppot = 0.0
  if ( itype > 0 ) then
     do idihe=dihegroupindex_d(idihegroup)+1,dihegroupindex_d(idihegroup+1)
        itype=diheatom_d(5*idihe)
        tpphase = diheperiod_d(itype)*tpphi-dihephase_d(itype)
        tppot = tppot + diheforceconst_d(itype)*(1.0 + cos(tpphase))
     end do
  end if

  i = 1
  do while (i<=16)
     tpphi = __shfl_xor(tppot,i); tppot = tppot + tpphi
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotdihe_d(iblock)=tppot
     else
        tpphi = atomicadd(edihe_d,dble(tppot))
     end if
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_dihe_frc(iblock)
  integer :: i,j,k,l,idihe,itype,ithread,iblock,idihegroup
  real :: rijvec(3),rkjvec(3),rklvec(3),vec1(3),vec2(3)
  real :: dot1inv,dot2inv,rkjsq,tpsum,tpphi
  real*8 :: tpvec1(3),tpvec2(3),tpvec(3)

  ithread=threadidx%x
  idihegroup=(iblock-1)*blockdim%x+ithread; if ( idihegroup > ndihegroup_d ) return

  idihe=dihegroupindex_d(idihegroup)+1
  l=5*idihe-4; itype = diheatom_d(l+4); if ( itype == 0 ) return

  i=diheatom_d(l); j=diheatom_d(l+1); k=diheatom_d(l+2); l=diheatom_d(l+3)
  vec1(1:3)=nowcoor_d(1:3,j); vec2(1:3)=nowcoor_d(1:3,k)
  rijvec(1:3) = nowcoor_d(1:3,i) - vec1(1:3)
  rkjvec(1:3) = vec2(1:3) - vec1(1:3)
  rklvec(1:3) = vec2(1:3) - nowcoor_d(1:3,l)

!  call cudatop_cross_product(rijvec,rkjvec,vec1)
  vec1(1) = rijvec(2) * rkjvec(3) - rijvec(3) * rkjvec(2)
  vec1(2) = rijvec(3) * rkjvec(1) - rijvec(1) * rkjvec(3)
  vec1(3) = rijvec(1) * rkjvec(2) - rijvec(2) * rkjvec(1)

!  call cudatop_cross_product(rkjvec,rklvec,vec2)
  vec2(1) = rkjvec(2) * rklvec(3) - rkjvec(3) * rklvec(2)
  vec2(2) = rkjvec(3) * rklvec(1) - rkjvec(1) * rklvec(3)
  vec2(3) = rkjvec(1) * rklvec(2) - rkjvec(2) * rklvec(1)

  dot1inv=1.0/dot_product(vec1,vec1); dot2inv=1.0/dot_product(vec2,vec2)
  tpphi = sqrt(dot1inv*dot2inv)*dot_product(vec1,vec2)
  tpphi = min(1.0, max(-1.0, tpphi))
  tpphi = sign(1.0,dot_product(rijvec,vec2))*acos( tpphi )

  tpsum = 0.0
  do idihe=dihegroupindex_d(idihegroup)+1,dihegroupindex_d(idihegroup+1)
     itype=diheatom_d(5*idihe)
     tpsum = tpsum + diheforceconst_d(itype)*diheperiod_d(itype)*sin(diheperiod_d(itype)*tpphi-dihephase_d(itype))
  end do
  rkjsq=dot_product(rkjvec,rkjvec)
  tpsum = tpsum*sqrt(rkjsq)

  tpvec1(1:3) = tpsum*dot1inv*vec1(1:3)
  tpvec2(1:3) = -tpsum*dot2inv*vec2(1:3)
  tpvec(1:3) = (dot_product(rijvec,rkjvec)*tpvec1(1:3) - dot_product(rklvec,rkjvec)*tpvec2(1:3))/rkjsq

  if ( ifblocksum_d ) then
     idihe = 4*idihegroup-3
     gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposdihe_d(idihe))=tpvec1(1:3)
     gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposdihe_d(idihe+1))=-tpvec1(1:3)+tpvec(1:3)
     gpufrc_d(1:3,gpufrcindex_d(k)+gpufrcposdihe_d(idihe+2))=-tpvec2(1:3)-tpvec(1:3)
     gpufrc_d(1:3,gpufrcindex_d(l)+gpufrcposdihe_d(idihe+3))=tpvec2(1:3)
  else
     tpsum = atomicadd(nowforce_d(1,i),tpvec1(1))
     tpsum = atomicadd(nowforce_d(2,i),tpvec1(2))
     tpsum = atomicadd(nowforce_d(3,i),tpvec1(3))
     tpsum = atomicadd(nowforce_d(1,j),-tpvec1(1)+tpvec(1))
     tpsum = atomicadd(nowforce_d(2,j),-tpvec1(2)+tpvec(2))
     tpsum = atomicadd(nowforce_d(3,j),-tpvec1(3)+tpvec(3))
     tpsum = atomicadd(nowforce_d(1,k),-tpvec2(1)-tpvec(1))
     tpsum = atomicadd(nowforce_d(2,k),-tpvec2(2)-tpvec(2))
     tpsum = atomicadd(nowforce_d(3,k),-tpvec2(3)-tpvec(3))
     tpsum = atomicadd(nowforce_d(1,l),tpvec2(1))
     tpsum = atomicadd(nowforce_d(2,l),tpvec2(2))
     tpsum = atomicadd(nowforce_d(3,l),tpvec2(3))
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_dihe_pot(iblock)
  integer :: i,j,k,l,idihe,itype,ithread,iblock,idihegroup
  real :: rijvec(3),rkjvec(3),rklvec(3),vec1(3),vec2(3),tpphi,tpa
  real*8 :: tppot

  ithread=threadidx%x
  idihegroup=(iblock-1)*blockdim%x+ithread; tppot = 0.0

  if ( idihegroup <= ndihegroup_d ) then

     idihe=dihegroupindex_d(idihegroup)+1
     l=5*idihe-4; itype = diheatom_d(l+4)

     if ( itype > 0 ) then

        i=diheatom_d(l); j=diheatom_d(l+1); k=diheatom_d(l+2); l=diheatom_d(l+3) 
        vec1(1:3)=nowcoor_d(1:3,j); vec2(1:3)=nowcoor_d(1:3,k)
        rijvec(1:3) = nowcoor_d(1:3,i) - vec1(1:3)
        rkjvec(1:3) = vec2(1:3) - vec1(1:3)
        rklvec(1:3) = vec2(1:3) - nowcoor_d(1:3,l)
      
      !  call cudatop_cross_product(rijvec,rkjvec,vec1)
        vec1(1) = rijvec(2) * rkjvec(3) - rijvec(3) * rkjvec(2)
        vec1(2) = rijvec(3) * rkjvec(1) - rijvec(1) * rkjvec(3)
        vec1(3) = rijvec(1) * rkjvec(2) - rijvec(2) * rkjvec(1)
      
      !  call cudatop_cross_product(rkjvec,rklvec,vec2)
        vec2(1) = rkjvec(2) * rklvec(3) - rkjvec(3) * rklvec(2)
        vec2(2) = rkjvec(3) * rklvec(1) - rkjvec(1) * rklvec(3)
        vec2(3) = rkjvec(1) * rklvec(2) - rkjvec(2) * rklvec(1)
      
        tpphi = dot_product(vec1,vec2)/sqrt(dot_product(vec1,vec1)*dot_product(vec2,vec2))
        tpphi = min(1.0, max(-1.0, tpphi))
        tpphi = sign(1.0,dot_product(rijvec,vec2))*acos( tpphi )
   
        do idihe=dihegroupindex_d(idihegroup)+1,dihegroupindex_d(idihegroup+1)
           itype=diheatom_d(5*idihe)
           tpa = diheperiod_d(itype)*tpphi-dihephase_d(itype)
           tppot = tppot + diheforceconst_d(itype)*(1.0 + cos(tpa))
        end do

     end if
  end if

  i = 1
  do while (i<=16)
     tpa = __shfl_xor(tppot,i); tppot = tppot + tpa
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotdihe_d(iblock)=tppot
     else
        tpa = atomicadd(edihe_d,tppot)
     end if
  end if
end subroutine

! calculate the 1-4 electrostatic and vdw energy
attributes(device) subroutine cudatop_potforce_elecvdw14(iblock)
  integer :: iblock
  if ( ifcalpot_d ) then
     call cudatop_potforce_elecvdw14_potfrc(iblock)
  else
     call cudatop_potforce_elecvdw14_frc(iblock)
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_elecvdw14_potfrc(iblock)
  integer :: ktype,ithread,iblock,idihe,i,j
  real :: tpvec(3),tpvalue1,tpvalue2,tppot
  real :: tpdissqinv,tpdisinv,tpdis6inv,tpdis12inv,tpa
  real*8 :: tptpvec(3)

  ithread=threadidx%x; idihe=(iblock-1)*blockdim%x+ithread; ktype = 0

  if ( idihe <= nnb14_d ) then
     ktype=nonbond14_d(3,idihe)
   
     if ( ktype > 0 ) then
   
        i = nonbond14_d(1,idihe); j = nonbond14_d(2,idihe)
        tpvec(1:3) = nowcoor_d(1:3,i) - nowcoor_d(1:3,j)
        tpdissqinv = 1.0/dot_product(tpvec,tpvec); tpdisinv = sqrt(tpdissqinv)
        tpvalue1 = tpdisinv*scale14elec_d(ktype)*charge_d(i)*charge_d(j)
      
        tppot = vdwsigma_d(i) + vdwsigma_d(j)
        tppot = (tppot*tpdisinv)**2; tppot = tppot*tppot*tppot
        tpa = scale14vdw_d(ktype)*tppot*vdweps_d(i)*vdweps_d(j)
        tpvalue2 = tpa*(tppot - 1.0)
      
        ! if ( ifcalfrc_d .eqv. .true. ) then
           tptpvec(1:3)=(tpvalue1 + tpa*(12.0*tppot - 6.0) )*tpdissqinv*tpvec(1:3)
           if ( ifblocksum_d ) then
              idihe = 2*idihe-1
              gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposnb14_d(idihe))=tptpvec(1:3)
              gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposnb14_d(idihe+1))=-tptpvec(1:3)
           else
              tppot = atomicadd(nowforce_d(1,i),tptpvec(1))
              tppot = atomicadd(nowforce_d(2,i),tptpvec(2))
              tppot = atomicadd(nowforce_d(3,i),tptpvec(3))
              tppot = atomicadd(nowforce_d(1,j),-tptpvec(1))
              tppot = atomicadd(nowforce_d(2,j),-tptpvec(2))
              tppot = atomicadd(nowforce_d(3,j),-tptpvec(3))
           end if
        ! end if

     end if
  end if

  ! if ( ifcalpot_d .eqv. .false. ) return
  tppot = 0.0; if ( ktype > 0 ) tppot = tpvalue1 + tpvalue2

  i = 1
  do while (i<=16)
     tpa = __shfl_xor(tppot,i); tppot = tppot + tpa
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotnb14_d(iblock)=tppot
     else
        tpa = atomicadd(enb14_d,dble(tppot))
     end if
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_elecvdw14_frc(iblock)
  integer :: ktype,ithread,iblock,idihe,i,j
  real :: tpvec(3),tpvalue,tpdissqinv,tpdisinv,tpa,tpb
  real*8 :: tptpvec(3)

  ithread=threadidx%x; idihe=(iblock-1)*blockdim%x+ithread; if ( idihe > nnb14_d ) return
  ktype=nonbond14_d(3,idihe); if ( ktype == 0 ) return

  i = nonbond14_d(1,idihe); j = nonbond14_d(2,idihe)

  tpvec(1:3) = nowcoor_d(1:3,i) - nowcoor_d(1:3,j)
  tpdissqinv = 1.0/dot_product(tpvec,tpvec); tpdisinv = sqrt(tpdissqinv)
  tpvalue = tpdisinv*scale14elec_d(ktype)*charge_d(i)*charge_d(j)

  tpb = vdwsigma_d(i) + vdwsigma_d(j)
  tpb = (tpb*tpdisinv)**2; tpb = tpb*tpb*tpb
  tpa = scale14vdw_d(ktype)*tpb*vdweps_d(i)*vdweps_d(j)

  tptpvec(1:3) = ( tpvalue + tpa*(12.0*tpb - 6.0) )*tpdissqinv*tpvec(1:3)
  if ( ifblocksum_d ) then
     idihe = 2*idihe-1
     gpufrc_d(1:3,gpufrcindex_d(i)+gpufrcposnb14_d(idihe))=tptpvec(1:3)
     gpufrc_d(1:3,gpufrcindex_d(j)+gpufrcposnb14_d(idihe+1))=-tptpvec(1:3)
  else
     tpa = atomicadd(nowforce_d(1,i),tptpvec(1))
     tpa = atomicadd(nowforce_d(2,i),tptpvec(2))
     tpa = atomicadd(nowforce_d(3,i),tptpvec(3))
     tpa = atomicadd(nowforce_d(1,j),-tptpvec(1))
     tpa = atomicadd(nowforce_d(2,j),-tptpvec(2))
     tpa = atomicadd(nowforce_d(3,j),-tptpvec(3))
  end if
end subroutine

attributes(device) subroutine cudatop_potforce_elecvdw14_pot(iblock)
  integer :: ktype,ithread,iblock,idihe,i,j
  real :: tpvec(3),tpvalue1,tpvalue2
  real :: tpdisinv,tpa,tpb
  real*8 :: tppot

  ithread=threadidx%x; idihe=(iblock-1)*blockdim%x+ithread; tppot = 0.0

  if ( idihe <= nnb14_d ) then
     ktype=nonbond14_d(3,idihe)
     if ( ktype > 0 ) then
        i = nonbond14_d(1,idihe); j = nonbond14_d(2,idihe)
        tpvec(1:3) = nowcoor_d(1:3,i) - nowcoor_d(1:3,j)

        tpdisinv=1.0/sqrt(dot_product(tpvec,tpvec))
        tpvalue1 = tpdisinv*scale14elec_d(ktype)*charge_d(i)*charge_d(j)
      
        tpb = vdwsigma_d(i) + vdwsigma_d(j)
        tpb = (tpb*tpdisinv)**2; tpb = tpb*tpb*tpb
        tpa = scale14vdw_d(ktype)*tpb*vdweps_d(i)*vdweps_d(j)
        tpvalue2 = tpa*(tpb - 1.0)
   
        tppot = tpvalue1 + tpvalue2
     end if
   end if

  i = 1
  do while (i<=16)
     tpa = __shfl_xor(tppot,i); tppot = tppot + tpa
     i = i*2
  end do

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotnb14_d(iblock)=tppot
     else
        tpa = atomicadd(enb14_d,tppot)
     end if
  end if
end subroutine

! cross product calculation on GPU
attributes(device) subroutine cudatop_cross_product ( vec1, vec2, vec3)
  implicit none
  real, dimension(1:3), intent(in) :: vec1, vec2
  real, dimension(1:3), intent(out) :: vec3

  vec3(1) = vec1(2) * vec2(3) - vec1(3) * vec2(2)
  vec3(2) = vec1(3) * vec2(1) - vec1(1) * vec2(3)
  vec3(3) = vec1(1) * vec2(2) - vec1(2) * vec2(1)
end subroutine

! sum of a vector on GPU
attributes(device) subroutine cudatop_vec_sum_double(ithread,nthread,arraydata)
  integer :: nthread,ithread
  real*8,dimension(nthread) :: arraydata
  integer :: ihalf,iup

  ihalf=nthread
  do while ( ihalf >= 2 )
     call syncthreads()
     if ( mod(ihalf,2) == 1 ) then
        ihalf = ihalf/2 + 1; iup = ihalf - 1
     else
        ihalf = ihalf/2; iup = ihalf
     end if
     if ( ithread <= iup ) then
        arraydata(ithread) = arraydata(ithread) + arraydata(ithread+ihalf)
     end if
  end do
end subroutine

! sum of a vector on GPU
attributes(device) subroutine cudatop_vec_sum_single(ithread,nthread,arraydata)
  integer :: nthread,ithread
  real,dimension(nthread) :: arraydata
  integer :: ihalf,iup

  ihalf=nthread
  do while ( ihalf >= 2 )
     call syncthreads()
     if ( mod(ihalf,2) == 1 ) then
        ihalf = ihalf/2 + 1; iup = ihalf - 1
     else
        ihalf = ihalf/2; iup = ihalf
     end if
     if ( ithread <= iup ) then
        arraydata(ithread) = arraydata(ithread) + arraydata(ithread+ihalf)
     end if
  end do
end subroutine

attributes(device) subroutine cudatop_vec_sum_int(ithread,nthread,arraydata)
  integer :: nthread,ithread
  integer,dimension(nthread) :: arraydata
  integer :: ihalf,iup

  ihalf=nthread
  do while ( ihalf >= 2 )
     call syncthreads()
     if ( mod(ihalf,2) == 1 ) then
        ihalf = ihalf/2 + 1; iup = ihalf - 1
     else
        ihalf = ihalf/2; iup = ihalf
     end if
     if ( ithread <= iup ) then
        arraydata(ithread) = arraydata(ithread) + arraydata(ithread+ihalf)
     end if
  end do
end subroutine

attributes(device) subroutine cudatop_vec_sumall(ithread,nthread,arraydata,ndim,tpsum)
  integer :: nthread,ithread,i,ndim
  real,dimension(ndim) :: arraydata
  real*8 :: tpsum,tpvalue
  
  tpsum=0d0
  do i=ithread,ndim,nthread
     tpsum = tpsum + arraydata(i)
  end do
  i = 1
  do while (i<=16)
     tpvalue = __shfl_xor(tpsum,i); tpsum = tpsum + tpvalue
     i = i*2
  end do
end subroutine

attributes(global) subroutine cudatop_vec_add(n,a_d,scalor,b_d)
  integer,intent(in),value :: n
  real,intent(inout) :: a_d(n)
  real*8,intent(in),value :: scalor
  real,intent(in) :: b_d(n)
  integer :: i

  i = (blockidx%x-1)*blockdim%x+threadidx%x; if ( i > n ) return
  a_d(i) = a_d(i) + scalor*b_d(i)
end subroutine

attributes(global) subroutine cudatop_vec_scale(n,a_d,scalor,b_d)
  integer,intent(in),value :: n
  real,intent(inout) :: a_d(n)
  real*8,intent(in),value :: scalor
  real,intent(in) :: b_d(n)
  integer :: i

  i = (blockidx%x-1)*blockdim%x+threadidx%x; if ( i > n ) return
  a_d(i) = scalor*b_d(i)
end subroutine

attributes(global) subroutine cudatop_vec_dot(n,scalor,a_d,b_d,dot_d)
  integer,intent(in),value :: n
  real*8,intent(in),value :: scalor
  real,intent(in) :: a_d(n),b_d(n)
  real*8,intent(out) :: dot_d
  integer :: i
  real :: tpsum, tpvalue

  i = (blockidx%x-1)*blockdim%x+threadidx%x
  if ( i <= n ) then
     tpsum = a_d(i)*b_d(i)*scalor
  else
     tpsum = 0.0
  end if
  i = 1
  do while (i<=16)
     tpvalue = __shfl_xor(tpsum,i); tpsum = tpsum + tpvalue
     i = i*2
  end do
  if ( threadidx%x == 1 ) tpvalue = atomicadd(dot_d,dble(tpsum))
end subroutine

end module
