subroutine cudapme_get_nmaxblockdirec(tpnmaxblockdirec)
  integer :: tpnmaxblockdirec
  tpnmaxblockdirec = nmaxblockdirec
end subroutine

attributes(global) subroutine cudapme_potforce_direct_fep()
  integer :: iblock
  iblock=blockidx%x; if ( iblock > nblockdirec_d ) return
  if ( iblock <= nbox_d ) then
     call cudapme_potforce_selfexcl_fep(iblock)
  else
     if ( iblock <= gexcltilenum_d ) then
        call cudapme_potforce_interexcl_fep(iblock)
     else
        iblock = iblock - gexcltilenum_d
        if ( iblock <= gnlj32num_d ) then
           call cudapme_potforce_tile_fep(iblock)
        else
           iblock = iblock - gnlj32num_d
           call cudapme_potforce_ijbin_fep(iblock)
        end if
     end if
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_selfexcl_fep(iblock)
  integer :: ipb,ioct,natom,ithread,iblock,iexcl,ibin,jbin,iatom,jloop,inext
  real :: discutsq,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),ifrc(3),jfrc(3),icharge,jcharge
  real :: dis,disinv,dissq,dissqinv,tpelec,tpvdw,tpcorr,tpfrccoef,coef1,vir(3)
  real :: ivdwsigma,jvdwsigma,ivdweps,jvdweps
  logical :: ifcalpot

  integer :: jatom
  logical :: ifdofepsoftcore,iffepsoftcore
  real :: tpbindpot,tpfepdissq,tpfepvalue,tpvalue,fepscale,fepvdwalpha,fepelecbeta
  iffepsoftcore = iffepsoftcore_d; fepscale = fepscale_d; fepvdwalpha = fepvdwalpha_d; fepelecbeta = fepelecbeta_d

  discutsq=discutsq_d; ifcalpot=ifcalpot_d; cellvec=pmecell_d; cellvecinv=pmecellinv_d
  natom = natom_d; ewaldalpha = ewaldalpha_d; ipb=ipb_d; ioct=ioct_d

  if ( ipb_d > 1 ) vir=0.0

  ! each thread starts from a diagonal element in the tile (box-box pair)
  ithread=threadidx%x; inext = ithread+1

  ! iblock : excluded box pair ibox-ibox, one tile has 32 encoded lists for 32 atoms
  ! iexcl : each thread processes one atom's encoded list of 32 excluded atoms
  ! iexcl = biencodedexcludedtilelist_d(ithread,iblock)
  ! i.e., ithread=3 starts from iatom=3 and jatom=3
  ! so the encoded list should be transfered to let the ithread's excluded list also starts from the diagonal element
  ! for example, the exludes matrix of all atoms in a box are (note that first position is on the right side)
  ! 1 1 0 1
  ! 0 1 1 0
  ! 1 0 1 1
  ! 0 1 1 1
  ! for ithread=3, its encoded list (1 0 1 1) should be tranfered to (1110)
  ! iexcl = ior(ishft(iexcl,1-ithread),ishft(iexcl,33-ithread))
  ! diagonal element should be skipped
  ! iexcl = ior(ishft(iexcl,-ithread),ishft(iexcl,32-ithread))

  ! alternative method
  iexcl = ishftc(biencodedexcludedtilelist_d(ithread,iblock),-ithread)

  ! ibin : anchor atom
  ibin = (iblock-1)*32+ithread; jbin=ibin
  if ( ibin <= natom ) then
     iatom = binatom_d(ibin); icharge = charge_d(iatom)
     icoor(1:3) = nowcoor_d(1:3,iatom)
     jatom = iatom; jcharge = icharge; jcoor = icoor
     ivdwsigma = vdwsigma_d(iatom); ivdweps = vdweps_d(iatom)
     jvdwsigma = ivdwsigma; jvdweps = ivdweps
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpcorr = 0.0; tpbindpot = 0.0
  end if
  ifrc = 0.0; jfrc = 0.0

  do jloop = 1, 16

     ! get the next atom ( it is contained by the neighboring thread, use shuffle function to get it )
     jbin = __shfl(jbin,inext)

     jcharge = __shfl(jcharge,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jvdwsigma = __shfl(jvdwsigma,inext); jvdweps = __shfl(jvdweps,inext)

     if ( ibin <= natom ) then
     if ( jbin <= natom ) then
     if ( ithread <= 16 .or. jloop < 16  ) then

         dcoor = icoor - jcoor
         if ( ioct > 0 ) then
            include "cudapme_octcal.f90"
         else
            dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
         end if
         dissq = dot_product(dcoor,dcoor)

         if ( dissq <= discutsq ) then

            if (btest(iexcl,0)) then

               dis = sqrt(dissq); disinv=1.0/dis
               coef1 = icharge*jcharge*disinv; dis=ewaldalpha*dis
               call erfc_function_simple(dis,dissqinv,tpfrccoef)     ! dissqinv: erfc, tpfrccoef: erfc dev
               dis = coef1*(-dis*tpfrccoef+dissqinv); dissq = coef1*dissqinv
               dissqinv=disinv*disinv

               if (ifcalpot) tpcorr = tpcorr + dissq - coef1
               tpfrccoef = dissqinv*(dis-coef1)

            else

               ifdofepsoftcore = .false.
               if ( iffepsoftcore .eqv. .true. ) then
                  if ( iatom <= nbioatom_d .and. jatom <= nbioatom_d ) then
                     if ( fepatommark_d(iatom)*fepatommark_d(jatom) < 0 ) then
                        tpfepdissq = dissq; ifdofepsoftcore = .true.
                        tpfepvalue = fepelecbeta_d*(1.0-fepscale) + tpfepdissq
                        dissq = tpfepvalue
                     end if
                  end if
               end if

               dis = sqrt(dissq); disinv=1.0/dis
               coef1 = icharge*jcharge*disinv; dis=ewaldalpha*dis
               call erfc_function_simple(dis,dissqinv,tpfrccoef)     ! dissqinv: erfc, tpfrccoef: erfc dev
               if ( ifcalpot ) then
                  tpvalue = coef1*dissqinv
                  if ( ifdofepsoftcore .eqv. .true. ) then
                     tpvalue = tpvalue*fepscale
                     tpbindpot = tpbindpot + tpvalue
                  end if
                  tpelec = tpelec + tpvalue
               end if
               tpfrccoef = coef1*(-dis*tpfrccoef+dissqinv)*disinv
               if ( ifdofepsoftcore .eqv. .true. ) then
                  tpfrccoef = tpfrccoef*fepscale*(1.0/2.0)*(tpfepvalue**(-1.0/2.0))*2.0*sqrt(tpfepdissq)
               end if

               if ( ifdofepsoftcore .eqv. .true. ) then
                  tpfepvalue = fepvdwalpha*(1.0-fepscale)*((ivdwsigma+jvdwsigma)**6)+tpfepdissq**3
                  dissq = tpfepvalue**(1.0/3.0); disinv = 1.0/sqrt(dissq)
               end if

               dis = ivdwsigma + jvdwsigma; dis = (dis*disinv)**2; dis = dis*dis*dis
               coef1 = dis*ivdweps*jvdweps
               if ( ifcalpot ) then
                  tpvalue = coef1*(dis - 1.0)
                  if ( ifdofepsoftcore .eqv. .true. ) then
                     tpvalue = tpvalue*fepscale
                     tpbindpot = tpbindpot + tpvalue
                  end if
                  tpvdw = tpvdw + tpvalue
               end if
               tpvalue = coef1*(12.0*dis - 6.0)*disinv
               if ( ifdofepsoftcore .eqv. .true. ) then
                  tpvalue = tpvalue*fepscale*(1.0/6.0)*(tpfepvalue**(-5.0/6.0))*6.0*sqrt(tpfepdissq)**5
               end if
               tpfrccoef = tpfrccoef + tpvalue

               if ( ifdofepsoftcore .eqv. .true. ) then
                  tpfrccoef = tpfrccoef/sqrt(tpfepdissq)
               else
                  tpfrccoef = tpfrccoef*disinv
               end if

            end if

            if ( ipb > 1 ) then
               vir(:) = vir(:) + dcoor(:)*dcoor(:)*tpfrccoef
            end if

            dcoor = dcoor*tpfrccoef
            ifrc = ifrc + dcoor; jfrc = jfrc - dcoor

         end if

     end if; end if; end if

     ! move to the next bit on the encoded list
     iexcl = ishft(iexcl,-1)

     ! get the force of jatom that has been summed on the neighboring thread
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
     jatom = __shfl(jatom,inext)

  end do

  inext = ithread - 17
  jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
  if ( ibin <= natom ) then
     coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)+jfrc(1)))
     coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)+jfrc(2)))
     coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)+jfrc(3)))
  end if

  if ( ipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpcorr,jloop); tpcorr = tpcorr + coef1
     coef1 = __shfl_xor(tpbindpot,jloop); tpbindpot = tpbindpot + coef1
     jloop = jloop*2
  end do
  if (ithread==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
     coef1 = atomicadd(ecorr_d,dble(tpcorr))
     coef1 = atomicadd(bindpot_d,dble(tpbindpot))
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_interexcl_fep(iblock)
  integer :: ipb,ioct,natom,ithread,iblock,ibox,jbox,iexcl,iatom,jatom,jloop,inext
  real :: discutsq,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),ifrc(3),jfrc(3),icharge,jcharge
  real :: dis,disinv,dissq,dissqinv,tpelec,tpvdw,tpcorr,tpfrccoef,coef1,vir(3)
  real :: ivdwsigma,jvdwsigma,ivdweps,jvdweps
  logical :: ifcalpot

  logical :: ifdofepsoftcore,iffepsoftcore
  real :: tpbindpot,tpfepdissq,tpfepvalue,tpvalue,fepscale,fepvdwalpha,fepelecbeta
  iffepsoftcore = iffepsoftcore_d; fepscale = fepscale_d; fepvdwalpha = fepvdwalpha_d; fepelecbeta = fepelecbeta_d

  discutsq=discutsq_d; ifcalpot=ifcalpot_d; cellvec=pmecell_d; cellvecinv=pmecellinv_d
  natom = natom_d; ewaldalpha = ewaldalpha_d; ipb=ipb_d; ioct=ioct_d
  if ( ipb > 1 ) vir=0.0

  ! each thread starts from a diagonal element in the tile (box-box pair)
  ithread=threadidx%x; inext = ithread+1

  ibox = biexcludedtilelist_d(1,iblock); jbox = biexcludedtilelist_d(2,iblock)
  ! iexcl = ior(ishft(iexcl,1-ithread),ishft(iexcl,33-ithread))
  iexcl = ishftc(biencodedexcludedtilelist_d(ithread,iblock),-ithread+1)

  iatom = (ibox-1)*32+ithread
  if ( iatom <= natom ) then
     iatom = binatom_d(iatom); icharge = charge_d(iatom)
     icoor(1:3) = nowcoor_d(1:3,iatom)
     ivdwsigma = vdwsigma_d(iatom); ivdweps = vdweps_d(iatom)
  end if

  jatom = (jbox-1)*32+ithread
  if ( jatom <= natom ) then
     jatom = binatom_d(jatom); jcharge = charge_d(jatom)
     jcoor(1:3) = nowcoor_d(1:3,jatom)
     jvdwsigma = vdwsigma_d(jatom); jvdweps = vdweps_d(jatom)
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpcorr = 0.0; tpbindpot = 0.0
  end if
  ifrc = 0.0; jfrc = 0.0

  do jloop = 1,32

     if ( iatom <= natom ) then
     if ( jatom <= natom ) then

     dcoor = icoor - jcoor
     if ( ioct > 0 ) then
        include "cudapme_octcal.f90"
     else
        dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
     end if
     dissq = dot_product(dcoor,dcoor)

     if ( dissq <= discutsq ) then

        if (btest(iexcl,0)) then

           dis = sqrt(dissq); disinv=1.0/dis
           coef1 = icharge*jcharge*disinv; dis=ewaldalpha*dis
           call erfc_function_simple(dis,dissqinv,tpfrccoef)     ! dissqinv: erfc, tpfrccoef: erfc dev
           dis = coef1*(-dis*tpfrccoef+dissqinv); dissq = coef1*dissqinv
           dissqinv=disinv*disinv

           if (ifcalpot) tpcorr = tpcorr + dissq - coef1
           tpfrccoef = dissqinv*(dis-coef1)

        else

           ifdofepsoftcore = .false.
           if ( iffepsoftcore .eqv. .true. ) then
              if ( iatom <= nbioatom_d .and. jatom <= nbioatom_d ) then
                 if ( fepatommark_d(iatom)*fepatommark_d(jatom) < 0 ) then
                    tpfepdissq = dissq; ifdofepsoftcore = .true.
                    tpfepvalue = fepelecbeta_d*(1.0-fepscale) + tpfepdissq
                    dissq = tpfepvalue
                 end if
              end if
           end if

           dis = sqrt(dissq); disinv=1.0/dis
           coef1 = icharge*jcharge*disinv; dis=ewaldalpha*dis
           call erfc_function_simple(dis,dissqinv,tpfrccoef)     ! dissqinv: erfc, tpfrccoef: erfc dev
           if ( ifcalpot ) then
              tpvalue = coef1*dissqinv
              if ( ifdofepsoftcore .eqv. .true. ) then
                  tpvalue = tpvalue*fepscale
                  tpbindpot = tpbindpot + tpvalue
              end if
              tpelec = tpelec + tpvalue
           end if
           tpfrccoef = coef1*(-dis*tpfrccoef+dissqinv)*disinv
           if ( ifdofepsoftcore .eqv. .true. ) then
              tpfrccoef = tpfrccoef*fepscale*(1.0/2.0)*(tpfepvalue**(-1.0/2.0))*2.0*sqrt(tpfepdissq)
           end if

           if ( ifdofepsoftcore .eqv. .true. ) then
              tpfepvalue = fepvdwalpha*(1.0-fepscale)*(ivdwsigma+jvdwsigma)**6+tpfepdissq**3
              dissq = tpfepvalue**(1.0/3.0); disinv = 1.0/sqrt(dissq)
           end if

           dis = ivdwsigma + jvdwsigma; dis = (dis*disinv)**2; dis = dis*dis*dis
           coef1 = dis*ivdweps*jvdweps
           if ( ifcalpot ) then
              tpvalue = coef1*(dis - 1.0)
              if ( ifdofepsoftcore .eqv. .true. ) then
                  tpvalue = tpvalue*fepscale
                  tpbindpot = tpbindpot + tpvalue
              end if
              tpvdw = tpvdw + tpvalue
           end if
           tpvalue = coef1*(12.0*dis - 6.0)*disinv
           if ( ifdofepsoftcore .eqv. .true. ) then
              tpvalue = tpvalue*fepscale*(1.0/6.0)*(tpfepvalue**(-5.0/6.0))*6.0*sqrt(tpfepdissq)**5
           end if
           tpfrccoef = tpfrccoef + tpvalue

           if ( ifdofepsoftcore .eqv. .true. ) then
              tpfrccoef = tpfrccoef/sqrt(tpfepdissq)
           else
              tpfrccoef = tpfrccoef*disinv
           end if

        end if

        if ( ipb > 1 ) then
           vir(:) = vir(:) + dcoor(:)*dcoor(:)*tpfrccoef
        end if

        dcoor = dcoor*tpfrccoef
        ifrc = ifrc + dcoor; jfrc = jfrc - dcoor
     end if

     end if; end if

     iexcl = ishft(iexcl,-1); jcharge = __shfl(jcharge,inext); jatom = __shfl(jatom,inext)

     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
     jvdwsigma = __shfl(jvdwsigma,inext); jvdweps = __shfl(jvdweps,inext)
  end do

  if ( iatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)))
     coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)))
     coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)))
  end if
  if ( jatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,jatom),dble(jfrc(1)))
     coef1 = atomicadd(nowforce_d(2,jatom),dble(jfrc(2)))
     coef1 = atomicadd(nowforce_d(3,jatom),dble(jfrc(3)))
  end if

  if ( ipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpcorr,jloop); tpcorr = tpcorr + coef1
     coef1 = __shfl_xor(tpbindpot,jloop); tpbindpot = tpbindpot + coef1
     jloop = jloop*2
  end do

  if (ithread==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
     coef1 = atomicadd(ecorr_d,dble(tpcorr))
     coef1 = atomicadd(bindpot_d,dble(tpbindpot))
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_tile_fep(iblock)
  integer :: ipb,ioct,natom,ithread,iblock,ibox,iatom,jatom,jloop,inext
  real :: discutsq,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),icharge,jcharge,ifrc(3),jfrc(3)
  real :: dis,disinv,dissq,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  real :: ivdweps,ivdwsigma,jvdweps,jvdwsigma
  logical :: ifcalpot

  logical :: ifdofepsoftcore,iffepsoftcore
  real :: tpbindpot,tpfepdissq,tpfepvalue,tpvalue,fepscale,fepvdwalpha,fepelecbeta
  iffepsoftcore = iffepsoftcore_d; fepscale = fepscale_d; fepvdwalpha = fepvdwalpha_d; fepelecbeta = fepelecbeta_d

  discutsq=discutsq_d; ifcalpot=ifcalpot_d; cellvec=pmecell_d; cellvecinv=pmecellinv_d
  natom = natom_d; ewaldalpha = ewaldalpha_d; ipb=ipb_d; ioct=ioct_d
  if ( ipb > 1 ) vir=0.0

  ithread=threadidx%x; ibox=gnliboxlist_d(iblock); iatom = (ibox-1)*32+ithread

  ! iatom info (ibox)
  if ( iatom <= natom ) then
     iatom = binatom_d(iatom); icharge = charge_d(iatom)
     icoor(1:3) = nowcoor_d(1:3,iatom); inext = ithread+1
     ivdwsigma = vdwsigma_d(iatom); ivdweps = vdweps_d(iatom)
  end if

  ! jatom info (jbox)
  jatom = gnljbinlist_d((iblock-1)*32+ithread)
  if ( jatom > 0 ) then
     jatom = binatom_d(jatom); jcharge = charge_d(jatom)
     jcoor(1:3) = nowcoor_d(1:3,jatom)
     jvdwsigma = vdwsigma_d(jatom); jvdweps = vdweps_d(jatom)
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpbindpot = 0.0
  end if
  ifrc=0.0; jfrc=0.0

  do jloop = 1,32
     if ( iatom <= natom ) then
     if ( jatom /= 0 ) then

        dcoor = icoor - jcoor
        if ( ioct > 0 ) then
           include "cudapme_octcal.f90"
        else
           dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
        end if
        dissq = dot_product(dcoor,dcoor)

        if ( dissq <= discutsq ) then

           ifdofepsoftcore = .false.
           if ( iffepsoftcore .eqv. .true. ) then
              if ( iatom <= nbioatom_d .and. jatom <= nbioatom_d ) then
                 if ( fepatommark_d(iatom)*fepatommark_d(jatom) < 0 ) then
                    tpfepdissq = dissq; ifdofepsoftcore = .true.
                    tpfepvalue = fepelecbeta_d*(1.0-fepscale) + tpfepdissq
                    dissq = tpfepvalue
                 end if
              end if
           end if

           dis = sqrt(dissq); disinv=1.0/dis; coef1 = icharge*jcharge*disinv; dis = ewaldalpha*dis
           call erfc_function_simple(dis,dissq,tpfrccoef)     ! dissq=erfc, tpfrccoef=erfc_dev
           if ( ifcalpot ) then
              tpvalue = coef1*dissq
              if ( ifdofepsoftcore .eqv. .true. ) then
                 tpvalue = tpvalue*fepscale
                 tpbindpot = tpbindpot + tpvalue
              end if
              tpelec = tpelec + tpvalue
           end if
           tpfrccoef = coef1*(-dis*tpfrccoef+dissq)*disinv
           if ( ifdofepsoftcore .eqv. .true. ) then
              tpfrccoef = tpfrccoef*fepscale*(1.0/2.0)*(tpfepvalue**(-1.0/2.0))*2.0*sqrt(tpfepdissq)
           end if

           if ( ifdofepsoftcore .eqv. .true. ) then
              tpfepvalue = fepvdwalpha*(1.0-fepscale)*(ivdwsigma+jvdwsigma)**6+tpfepdissq**3
              dissq = tpfepvalue**(1.0/3.0); disinv = 1.0/sqrt(dissq)
           end if

           dis = ivdwsigma + jvdwsigma; dis = (dis*disinv)**2; dis = dis*dis*dis
           coef1 = dis*ivdweps*jvdweps
           if ( ifcalpot ) then
              tpvalue = coef1*(dis - 1.0)
              if ( ifdofepsoftcore .eqv. .true. ) then
                 tpvalue = tpvalue*fepscale
                 tpbindpot = tpbindpot + tpvalue
              end if
              tpvdw = tpvdw + tpvalue
           end if
           tpvalue = coef1*(12.0*dis - 6.0)*disinv
           if ( ifdofepsoftcore .eqv. .true. ) then
              tpvalue = tpvalue*fepscale*(1.0/6.0)*(tpfepvalue**(-5.0/6.0))*6.0*sqrt(tpfepdissq)**5
           end if
           tpfrccoef = tpfrccoef + tpvalue

           if ( ifdofepsoftcore .eqv. .true. ) then
              tpfrccoef = tpfrccoef/sqrt(tpfepdissq)
           else
              tpfrccoef = tpfrccoef*disinv
           end if

           if ( ipb > 1 ) then
              vir(:) = vir(:) + dcoor(:)*dcoor(:)*tpfrccoef
           end if
           dcoor = dcoor*tpfrccoef
           ifrc = ifrc + dcoor; jfrc = jfrc - dcoor
        end if

     end if; end if

     jcharge = __shfl(jcharge,inext); jatom = __shfl(jatom,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
     jvdwsigma = __shfl(jvdwsigma,inext); jvdweps = __shfl(jvdweps,inext)

  end do

  if ( iatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)))
     coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)))
     coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)))
  end if
  if ( jatom > 0 .and. jatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,jatom),dble(jfrc(1)))
     coef1 = atomicadd(nowforce_d(2,jatom),dble(jfrc(2)))
     coef1 = atomicadd(nowforce_d(3,jatom),dble(jfrc(3)))
  end if

  if ( ipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  ! sum up energy by shfl.
  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpbindpot,jloop); tpbindpot = tpbindpot + coef1
     jloop = jloop*2
  end do
  if (ithread==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
     coef1 = atomicadd(bindpot_d,dble(tpbindpot))
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_ijbin_fep(iblock)
  integer :: irec,iatom,jatom,iblock
  real :: dcoor(3),dis,disinv,dissq,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  logical :: ifcalpot,ipb

  logical :: ifdofepsoftcore,iffepsoftcore
  real :: tpbindpot,tpfepdissq,tpfepvalue,tpvalue,fepscale,fepvdwalpha,fepelecbeta
  iffepsoftcore = iffepsoftcore_d; fepscale = fepscale_d; fepvdwalpha = fepvdwalpha_d; fepelecbeta = fepelecbeta_d

  ifcalpot = ifcalpot_d; ipb = ipb_d
  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpbindpot = 0.0
  end if
  if ( ipb > 1 ) vir = 0.0

  irec = (iblock-1)*blockdim%x+threadidx%x

  if ( irec <= gijbinnum_d ) then

     ! atom-atom pair in small box-box pair
     iatom = binatom_d(gijbinlist_d(1,irec)); jatom = binatom_d(gijbinlist_d(2,irec))

     dcoor = nowcoor_d(1:3,iatom) - nowcoor_d(1:3,jatom)
     if ( ioct_d > 0 ) then
        include "cudapme_octcal.f90"
     else
        dcoor = dcoor - floor(dcoor*pmecellinv_d+0.5)*pmecell_d
     end if
     dissq = dot_product(dcoor,dcoor)

     if ( dissq <= discutsq_d ) then

        ifdofepsoftcore = .false.
        if ( iffepsoftcore .eqv. .true. ) then
           if ( iatom <= nbioatom_d .and. jatom <= nbioatom_d ) then
              if ( fepatommark_d(iatom)*fepatommark_d(jatom) < 0 ) then
                 tpfepdissq = dissq; ifdofepsoftcore = .true.
                 tpfepvalue = fepelecbeta_d*(1.0-fepscale) + tpfepdissq
                 dissq = tpfepvalue
              end if
           end if
        end if

        dis = sqrt(dissq); disinv=1.0/dis; coef1 = charge_d(iatom)*charge_d(jatom)*disinv
        dis = ewaldalpha_d*dis
        call erfc_function_simple(dis,dissq,tpfrccoef)     ! dissq=erfc, tpfrccoef=erfc_dev
        if ( ifcalpot ) then
           tpvalue = coef1*dissq
           if ( ifdofepsoftcore .eqv. .true. ) then
              tpvalue = tpvalue*fepscale
              tpbindpot = tpbindpot + tpvalue
           end if
           tpelec = tpvalue
        end if
        tpfrccoef = coef1*(-dis*tpfrccoef+dissq)*disinv
        if ( ifdofepsoftcore .eqv. .true. ) then
           tpfrccoef = tpfrccoef*fepscale*(1.0/2.0)*(tpfepvalue**(-1.0/2.0))*2.0*sqrt(tpfepdissq)
        end if

        if ( ifdofepsoftcore .eqv. .true. ) then
           tpfepvalue = fepvdwalpha*(1.0-fepscale)*(vdwsigma_d(iatom) + vdwsigma_d(jatom))**6+tpfepdissq**3
           dissq = tpfepvalue**(1.0/3.0); disinv = 1.0/sqrt(dissq)
        end if

        dis = vdwsigma_d(iatom) + vdwsigma_d(jatom); dis = (dis*disinv)**2; dis = dis*dis*dis
        coef1 = dis*vdweps_d(iatom)*vdweps_d(jatom)
        if ( ifcalpot ) then
           tpvalue = coef1*(dis - 1.0)
           if ( ifdofepsoftcore .eqv. .true. ) then
              tpvalue = tpvalue*fepscale
              tpbindpot = tpbindpot + tpvalue
           end if
           tpvdw = tpvalue
        end if
        tpvalue = coef1*(12.0*dis - 6.0)*disinv
        if ( ifdofepsoftcore .eqv. .true. ) then
           tpvalue = tpvalue*fepscale*(1.0/6.0)*(tpfepvalue**(-5.0/6.0))*6.0*sqrt(tpfepdissq)**5
        end if
        tpfrccoef = tpfrccoef + tpvalue

        if ( ifdofepsoftcore .eqv. .true. ) then
           tpfrccoef = tpfrccoef/sqrt(tpfepdissq)
        else
           tpfrccoef = tpfrccoef*disinv
        end if

        if ( ipb > 1 ) then
           vir(:) = dcoor(:)*dcoor(:)*tpfrccoef
        end if
        dcoor = dcoor*tpfrccoef
        coef1 = atomicadd(nowforce_d(1,iatom),dble(dcoor(1)))
        coef1 = atomicadd(nowforce_d(2,iatom),dble(dcoor(2)))
        coef1 = atomicadd(nowforce_d(3,iatom),dble(dcoor(3)))
        coef1 = atomicadd(nowforce_d(1,jatom),dble(-dcoor(1)))
        coef1 = atomicadd(nowforce_d(2,jatom),dble(-dcoor(2)))
        coef1 = atomicadd(nowforce_d(3,jatom),dble(-dcoor(3)))
     end if

  end if

  if ( ipb > 1 ) then
     irec = 1
     do while (irec<=16)
        coef1 = __shfl_xor(vir(1),irec); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),irec); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),irec); vir(3) = vir(3) + coef1
        irec = irec*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  irec = 1
  do while (irec<=16)
     coef1 = __shfl_xor(tpelec,irec); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,irec); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpbindpot,irec); tpbindpot = tpbindpot + coef1
     irec = irec*2
  end do
  if (threadidx%x==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
     coef1 = atomicadd(bindpot_d,dble(tpbindpot))
  end if
end subroutine

