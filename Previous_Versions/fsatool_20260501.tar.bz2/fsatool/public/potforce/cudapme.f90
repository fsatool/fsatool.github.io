module cudapme
  use iso_c_binding; use cudafft; use cudafor
  use ambertop; use cudatop
  implicit none

  integer (kind=cuda_stream_kind) :: stream1, stream2, stream3
  integer,device,private :: bimaxnexc_d,ioct_d
  integer,device,dimension(:),allocatable,private :: atommol_d
  real,device,dimension(:),allocatable,private :: halfqq_d

  real,device,private :: evdwcorr_d,eself_d,erecip_d
  real,device,private :: discut_d,discutsq_d,cellvolume_d,hfskinsq_d
  real,device,private :: cosgamma_d,singamma_d,cosbeta_d,latticeterm1_d,latticeterm2_d,latticeterm3_d

  real*8,device :: bindpot_d
  real,device :: fepscale_d, fepvdwalpha_d, fepelecbeta_d
  integer,device,dimension(:),allocatable :: fepatommark_d
  logical,device :: iffepsoftcore_d

  ! variables for direct space

  integer,private :: nmaxblockdirec,nblocknl,hashtable(4,4,4),nbox,nblockbox,nblockmol
  integer,device,private :: ifactivebox_d,nmaxblockdirec_d,nblockdirec_d,hashtable_d(4,4,4),nbox_d,maxtiles_d,maxijpairs_d
  real,device,private :: pmecellinv_d(3),fullcut_d,fullcutsq_d,inievdwcorr_d,inicellvolume_d,inipmevir_d(3)

  integer,device,dimension(:),allocatable,private :: boxatom_d,binatom_d,molbin_d,molmol_d,resindex_d,molindex_d,natompermol_d,molgroupstartatom_d,molgroupstartmol_d,molgroupindex_d,boxsorted2box_d
  real,device,dimension(:),allocatable,private :: box2size_d
  real,device,dimension(:,:),allocatable,private :: boxinfo_d,boxsortedinfo_d
  real,device,dimension(:,:),allocatable,target,private :: bincoor_d

  integer,private :: nsharedfornlbox
  integer,device,private :: maxbiexcboxnum_d
  integer,device,dimension(:),allocatable,private :: biexcludedboxlist_d,biexcludedboxlistindex_d
  integer,device,dimension(:,:),allocatable,private :: biexcludedtilelist_d,biencodedexcludedtilelist_d

  integer,private :: gexcltilenum
  integer,device,private :: gnlj32num_d,gijbinnum_d,gexcltilenum_d,ijpairsize_d
  integer,device,dimension(:),allocatable,private :: gnliboxlist_d,gnljbinlist_d
  integer,device,dimension(:,:),allocatable,target,private :: gijbinlist_d

  ! variables for reciprocal space

  integer,private :: fftnhalftotgrid,nblockrecip
  integer,device,private :: fftnhalftotgrid_d
  type(c_ptr) :: fftplan1,fftplan2
  integer,private :: fftntotgrid
  real,device,private :: mat_frac2car_d(3,3),mat_car2frac_d(3,3),ewaldalpha_d
  real,device,private :: inipmecell_d(3),inimat_frac2car_d(3,3),inimat_car2frac_d(3,3)
  integer,device,private :: fftngrid_d(3),splineorder_d,fftntotgrid_d
  integer,device,dimension(:,:),allocatable,target,private :: chargegrid_d
  real,device,dimension(:,:),allocatable,private,target :: ewaldbmsq_d,pmemterm_d,chargexi_d
  real,device,dimension(:,:,:),allocatable,private,target :: pmebcterm_d,realgridcharge_d
  complex,device,dimension(:,:,:),allocatable,target,private :: gridcharge_d

  ! variables for npt ensemble

  integer :: nblocksolventmol
  real,device :: nptcoeff_d(3),pressure0_d,realpressure_d,nptfactor_d,lastmat_car2frac_d(3,3)
  real*8,device,private :: pmemolekin_d(3),pmevir_d(3)
  real,device,dimension(:,:),allocatable,private :: molcom_d,molmove_d
  real,device,dimension(:),allocatable,private :: molmass_d,molmassinv_d

contains

! collective the arrays for PME calculation on GPU
subroutine cudapme_initialize()
  use sortmod; use pme
  integer :: iatom,jatom,tpi,tpnum,i,j,k,maxijpairs,maxtiles,gnlj32num,gijbinnum
  integer :: jres,ibox,jbox,ijstride,tpadnum,i1,i2,i3,j1,j2,j3,i1l,i1r,i2l,i2r,i3l,i3r,csidx,igrid,jgrid,kgrid
  integer :: tpl,tpr,ibin,imol,ires,imolgroup,iatompermol,imolbegin,imolend,molpos,atompos,realmol,binvec(3)
  integer :: iaxis,ibegin,iend,jbegin,jend,encodedtile(32),maxbiexcboxnum
  real*8 :: avgcoor(3),tpvec(3),tpatomarray(natom),temp
  integer,dimension(:),allocatable :: binatom,molbin,molmol,molgroupstartatom,molgroupstartmol
  logical,dimension(:),allocatable :: ifexclbox
  integer,dimension(:),allocatable :: biexcludedboxlist,biexcludedboxlistindex
  integer,dimension(:,:),allocatable :: biexcludedtilelist,biencodedexcludedtilelist

  if ( .not. allocated(pmebcterm) ) call pme_initialize()

  cosgamma_d=cos(cellgamma); singamma_d=sin(cellgamma); cosbeta_d=cos(cellbeta)
  temp = ( cos(cellalpha) - cos(cellbeta)*cos(cellgamma) )/sin(cellgamma)
  latticeterm1_d = temp
  latticeterm2_d = sqrt(sin(cellbeta)**2 - temp**2)
  latticeterm3_d = cos(cellgamma)*temp - cos(cellbeta)*sin(cellgamma)

  i = cudaStreamCreate(stream1)
  i = cudaStreamCreate(stream2)
  i = cudaStreamCreate(stream3)

  ! hashtable presented in the reference
  ! R. Salomon-Ferrer, A. W. Gotz, D. Poole, S. Le Grand, and R. C. Walker.
  ! Routine Microsecond Molecular Dynamics Simulations with AMBER on GPUs. 2. Explicit Solvent Particle Mesh Ewald.
  ! J. Chem. Theory Comput. 2013: 9, 3878-3888 
  hashtable(1:4,1,1) = [34,35,60,61]; hashtable(1:4,2,1) = [33,32,63,62]
  hashtable(1:4,3,1) = [30,31, 0, 1]; hashtable(1:4,4,1) = [29,28, 3, 2]

  hashtable(1:4,1,2) = [37,36,59,58]; hashtable(1:4,2,2) = [38,39,56,57]
  hashtable(1:4,3,2) = [25,24, 7, 6]; hashtable(1:4,4,2) = [26,27, 4, 5]

  hashtable(1:4,1,3) = [42,43,54,53]; hashtable(1:4,2,3) = [41,40,55,52]
  hashtable(1:4,3,3) = [20,23, 8, 9]; hashtable(1:4,4,3) = [21,22,11,10]

  hashtable(1:4,1,4) = [45,44,49,50]; hashtable(1:4,2,4) = [46,47,48,51]
  hashtable(1:4,3,4) = [19,16,15,14]; hashtable(1:4,4,4) = [18,17,12,13]

  hashtable_d = hashtable

  ipb_d=ipb; ioct_d=ioct
  pressure0_d=pressure0; nptfactor_d = isocompress*bar2pascal*deltatime/taup

  discut_d=discut; discutsq_d=discut**2

  allocate(halfqq_d(natom))
  do i=1,natom; tpatomarray(i) = 0.5*charge(i)**2; end do
  halfqq_d = tpatomarray

  nbox = (natom-1)/32+1; nbox_d = nbox
  allocate(molmass_d(nmol),molmassinv_d(nmol),molcom_d(3,nmol),atommol_d(natom))
  molmass_d = molmass; molmassinv_d=1.0/molmass; molcom_d = 0.0d0; atommol_d = 0
  atommol_d = atommol

  allocate(molmove_d(3,nmol)); molmove_d=0.0

  nblockbox = (nbox-1)/32+1; nblockmol = (nmol-1)/32+1; nblocksolventmol = (nmol-nbiomol-1)/32+1

!=============================================================
! prepare the variables in the direct space sum

  inievdwcorr_d = inievdwcorr; inicellvolume_d = inicellvolume; inipmevir_d = inipmevir
  eself_d = eself; evdwcorr_d = inievdwcorr
  inipmecell_d = inipmecell; inimat_frac2car_d=inimat_frac2car; inimat_car2frac_d=inimat_car2frac

  bimaxnexc_d = bimaxnexc; fullcut_d=discut+skin; fullcutsq_d=fullcutsq; hfskinsq_d = hfskinsq

  ifactivebox_d=.false.; pmecell_d = pmecell; pmecellinv_d = pmecellinv
  mat_frac2car_d=mat_frac2car; mat_car2frac_d=mat_car2frac
  ewaldalpha_d=ewaldalpha; cellvolume_d=cellvolume

  allocate(molgroupindex_d(nmolgroup+1)); molgroupindex_d=molgroupindex
  allocate(molbin(nmol),molmol(nmol)); molbin = 0; molmol = 0
  allocate(binatom(natom),binatom_d(natom)); binatom = 0; binatom_d = 0
  allocate(natompermol_d(nmol)); natompermol_d=natompermol
  allocate(resindex_d(nres+1),molindex_d(nmol+1)); resindex_d=resindex; molindex_d=molindex
  allocate(molbin_d(nmol),molmol_d(nmol)); molbin_d = 0; molmol_d = 0

  allocate(molgroupstartmol(nmol),molgroupstartatom(nmol)); molgroupstartmol=0; molgroupstartatom=0
  allocate(molgroupstartmol_d(nmol),molgroupstartatom_d(nmol)); molgroupstartmol_d=0; molgroupstartatom_d=0

  molpos = 0; atompos = 0
  do imolgroup=1,nmolgroup
     imolbegin = molgroupindex(imolgroup) + 1; imolend = molgroupindex(imolgroup+1)
     molgroupstartmol(imolbegin:imolend) = molpos
     molgroupstartatom(imolbegin:imolend) = atompos
     if ( imolgroup == nmolgroup ) exit
     molpos = molpos + imolend - imolbegin + 1
     atompos = atompos + natompermol(imolbegin)*(imolend-imolbegin+1)
  end do
  molgroupstartatom_d=molgroupstartatom; molgroupstartmol_d=molgroupstartmol 

  ! set binatom for the first molecular group, these atoms does not need to be sorted
  imolgroup=1
  do imol=molgroupindex(imolgroup) + 1, molgroupindex(imolgroup+1)
     do iatom=resindex(molindex(imol)+1)+1, resindex(molindex(imol+1)+1)
        binatom(iatom) = iatom
     end do
  end do

!========================== sort atoms on CPU =========================

  do imolgroup=1,nmolgroup
     imolbegin = molgroupindex(imolgroup) + 1; imolend = molgroupindex(imolgroup+1)

     do imol=imolbegin,imolend
        avgcoor = 0.0d0
        do ires=molindex(imol)+1,molindex(imol+1)
           do iatom=resindex(ires)+1,resindex(ires+1)
              avgcoor(:) = avgcoor(:) + nowcoor(:,iatom)
           end do
        end do
        avgcoor = avgcoor/dble(natompermol(imol))
        do iaxis = 1,3
           tpvec(iaxis) = dot_product(avgcoor,mat_car2frac(iaxis,:))
           tpvec(iaxis) = tpvec(iaxis) - floor(tpvec(iaxis))
        end do
        avgcoor = tpvec*4d0
        binvec = int(avgcoor+1)
        if ( binvec(1) < 1 .or. binvec(1) > 4 .or. &
             binvec(2) < 1 .or. binvec(2) > 4 .or. &
             binvec(3) < 1 .or. binvec(3) > 4 ) then
           print "(a,3i4)","molecule is out of the central periodic box ",imol,binvec(:); stop
        end if

        ibin = hashtable(binvec(1),binvec(2),binvec(3))
        binvec = int( (avgcoor - real(binvec-1))*4.0 + 1 )
        ibin = (ibin-1)*64 + hashtable(binvec(1),binvec(2),binvec(3))

        molbin(imol) = ibin; molmol(imol) = imol
     end do

     ! sort the indices of the molecules acoording their bin indices
     call sort_by_keys(imolend-imolbegin+1,molbin(imolbegin:imolend),molmol(imolbegin:imolend))

     do imol=imolbegin, imolend
        realmol = molmol(imol)
        atompos = molgroupstartatom(imol) + (imol-molgroupstartmol(imol)-1)*natompermol(imol)
        ibegin = resindex(molindex(realmol)+1)+1; iend = resindex(molindex(realmol+1)+1)
        do iatom=ibegin,iend
           binatom(atompos + iatom - ibegin + 1) = iatom
        end do
     end do

  end do

  binatom_d = binatom
!======================================================================

  allocate(bincoor_d(3,natom))
  call cudapme_set_bincoor<<<nblockatom,cudathread>>>()

  ! divide all the atoms in the bins with the same number (32)
  allocate(boxsorted2box_d(nbox)); boxsorted2box_d = 0
  allocate(box2size_d(nbox)); box2size_d = 0.0
  allocate(boxinfo_d(7,nbox),boxsortedinfo_d(7,nbox)); boxinfo_d = 0.0; boxsortedinfo_d = 0.0

  ! calculate the box size and center
  call cudapme_set_box<<<(nbox-1)/32+1,32>>>()

  ! sort the indices of boxes by their sizes
  call thrustsort(box2size_d,boxsorted2box_d,nbox)

  ! now, begin to handle the excluded boxes
  
  ! calculate the number of exclusion boxes
  allocate(biexcludedboxlistindex(nbox+1),biexcludedboxlistindex_d(nbox+1)); biexcludedboxlistindex = 0
  tpnum = 0
  allocate(ifexclbox(nbox)); ifexclbox = .false.
  do ibox = 1,nbox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,natom); tpl = ibegin; tpr = iend
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = biexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .true.
           tpl = min(tpl,jatom); tpr = max(tpr,jatom)
        end do
     end do
     do jbox = ibox+1,(tpr+31)/32
        if(ifexclbox(jbox)==.true.) tpnum = tpnum + 1
     end do
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = biexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .false.
        end do
     end do
  end do
  gexcltilenum = nbox+tpnum; gexcltilenum_d = gexcltilenum
  allocate(biexcludedboxlist(nbox+2*tpnum),biexcludedboxlist_d(nbox+2*tpnum)); biexcludedboxlist = 0
  allocate(biexcludedtilelist(2,nbox+tpnum),biexcludedtilelist_d(2,nbox+tpnum)); biexcludedtilelist = 0
  allocate(biencodedexcludedtilelist(32,nbox+tpnum),biencodedexcludedtilelist_d(32,nbox+tpnum)); biencodedexcludedtilelist = 0

  ! save ibox's excluded boix list into biexcludedboxlist

  ! save all jbox that have the exluced atoms in ibox ( jbox < ibox, jbox=jbox and jbox > ibox )
  tpnum = 0; maxbiexcboxnum = 0
  do ibox = 1,nbox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,natom); tpl = ibegin; tpr = iend
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = biexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .true.
           tpl = min(tpl,jatom); tpr = max(tpr,jatom)
        end do
     end do
     ifexclbox(ibox) = .true.

     do jbox = (tpl+31)/32,(tpr+31)/32
        if (ifexclbox(jbox)==.true.) then
           tpnum = tpnum + 1; biexcludedboxlist(tpnum) = jbox
        end if
     end do

     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = biexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .false.
        end do
     end do
     ifexclbox(ibox) = .false.
     biexcludedboxlistindex(ibox+1) = tpnum

     i = biexcludedboxlistindex(ibox+1) - biexcludedboxlistindex(ibox)
     if ( i > maxbiexcboxnum ) maxbiexcboxnum = i
  end do
  biexcludedboxlistindex_d = biexcludedboxlistindex; biexcludedboxlist_d = biexcludedboxlist
  maxbiexcboxnum_d = maxbiexcboxnum

  ! encode the excluded atoms only in ibox
  ! the encode operation is performed for the atoms with their original indices
  ! note that their relative indices do not change after the sort opertation above
  do ibox = 1,nbox
     biexcludedtilelist(1,ibox) = ibox; biexcludedtilelist(2,ibox) = ibox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,natom); encodedtile = 0
     do iatom = ibegin,iend
        ! encode all excluded atoms of iatom into one integer
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = biexcludedatomlist(j)
           if (jatom==0) cycle
           if ((jatom>=ibegin) .and. (jatom<=iend)) then
              encodedtile(iatom-ibegin+1) = ibset(encodedtile(iatom-ibegin+1),jatom-ibegin)
           end if
        end do
     end do
     biencodedexcludedtilelist(:,ibox) = encodedtile(:)
  end do

  ! encode the excluded atoms out of ibox (jbox > ibox)
  tpnum = 0
  do ibox = 1,nbox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,natom); tpl = ibegin; tpr = iend
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = biexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .true.
           tpl = min(tpl,jatom); tpr = max(tpr,jatom)
        end do
     end do

     do jbox = ibox+1,(tpr+31)/32
        if (ifexclbox(jbox)==.true.) then
           tpnum = tpnum + 1
           biexcludedtilelist(1,nbox+tpnum) = ibox; biexcludedtilelist(2,nbox+tpnum) = jbox
           jbegin = (jbox-1)*32+1; jend = min(jbox*32,natom); encodedtile = 0
           do iatom = ibegin,iend
              do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
                 jatom = biexcludedatomlist(j)
                 if (jatom==0) cycle
                 if ((jatom>=jbegin) .and. (jatom<=jend)) then
                    encodedtile(iatom-ibegin+1) = ibset(encodedtile(iatom-ibegin+1),jatom-jbegin)
                 end if
              end do
           end do
           biencodedexcludedtilelist(:,nbox+tpnum) = encodedtile(:)
        end if
     end do

     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = biexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .false.
        end do
     end do
  end do
  biexcludedtilelist_d = biexcludedtilelist; biencodedexcludedtilelist_d = biencodedexcludedtilelist

  ! normal box-box pairs (tiles) (gnlj32num_d)
  if ( ipb > 1 ) then
     maxtiles = nbox*30; maxtiles_d=maxtiles
  else
     maxtiles = nbox*20; maxtiles_d=maxtiles
  end if
  allocate(gnliboxlist_d(maxtiles)); gnliboxlist_d=0
  allocate(gnljbinlist_d(maxtiles*32)); gnljbinlist_d=0

  ! single atom-atom pairs (gijbinnum_d)
  ijpairsize_d=2; maxijpairs = natom*ijpairsize_d*10; maxijpairs_d=maxijpairs
  allocate(gijbinlist_d(2,maxijpairs)); gijbinlist_d=0

  ! gexcltilenum : number of excluded box-box pairs
  nmaxblockdirec=0.7*(gexcltilenum+maxtiles+(maxijpairs-1)/32+1); nmaxblockdirec_d=nmaxblockdirec

  ! build the neighbor list for all atoms in every box (tile)
  gnlj32num_d = 0; gijbinnum_d = 0; nsharedfornlbox = 7*32*4+2*256*4+5*4+maxbiexcboxnum*4
  call cudapme_set_nlbox<<<nbox,32,nsharedfornlbox>>>()
  call cudapme_check_exceedarray<<<3,1>>>()

!==================================================================
! prepare the variables in the reciprocal space sum

  fftngrid_d = fftngrid; fftntotgrid=product(fftngrid); fftntotgrid_d=fftntotgrid
  splineorder_d = splineorder

  fftnhalftotgrid = (fftngrid(1)/2+1)*fftngrid(2)*fftngrid(3)-1; fftnhalftotgrid_d=fftnhalftotgrid
  nblockrecip=(fftnhalftotgrid-1)/32+1

  allocate(chargexi_d(3,natom)); chargexi_d=0.0
  allocate(gridcharge_d(fftngrid(1)/2+1,fftngrid(2),fftngrid(3))); gridcharge_d=cmplx(0.0,0.0)
  allocate(realgridcharge_d(fftngrid(1),fftngrid(2),fftngrid(3)))
  realgridcharge_d=0.0
  allocate(chargegrid_d(3,natom)); chargegrid_d=0

  allocate(ewaldbmsq_d(3,fftmaxngrid)); ewaldbmsq_d=ewaldbmsq
  allocate(pmemterm_d(3,fftmaxngrid)); pmemterm_d=pmemterm
  allocate(pmebcterm_d(fftngrid(1)/2+1,fftngrid(2),fftngrid(3)))
  pmebcterm_d=pmebcterm

  call cufftPlan3d(fftplan1,fftngrid(3),fftngrid(2),fftngrid(1),CUFFT_R2C,1)
  call cufftPlan3d(fftplan2,fftngrid(3),fftngrid(2),fftngrid(1),CUFFT_C2R,1)

  if ( ipb > 1 ) then
     call cudapme_npt_com_biomol<<<nbiomol,cudathread>>>()
     call cudapme_npt_com_ionwat<<<nblocksolventmol,cudathread>>>()
  end if
end subroutine

subroutine cudapme_potforce()
  use pme, only : ifactivebox,fftngrid,pme_prepare_cell
  use sortmod
  integer,save :: isortstep

  if ( ifactivebox .eqv. .true. ) then
     ifactivebox_d = .true.; isortstep = -10000
     if ( ipb > 1 ) then
        call cudapme_npt_prepare_cell<<<16,1>>>()
        call cudapme_npt_pmebcterm<<<nblockrecip,cudathread>>>()
     end if
  end if

  call cudapme_clear_force<<<nblockatom,cudathread>>>()
  if ( ifactivebox .eqv. .false. ) ifactivebox = ifactivebox_d

  if ( ifactivebox .eqv. .true. ) then
     ifactivebox = .false.
     ! resort the molecules for the generation of the box atoms
     if ( (nowstep-isortstep) >= 100 ) then
        isortstep = nowstep
        call cudapme_set_molbin<<<nblockmol,cudathread>>>()
        call thrustsort(molbin_d,molmol_d,molgroupindex_d,nmolgroup)
        call cudapme_set_atombin<<<nblockmol,cudathread>>>()
     end if
     ! save the atom coordinates with the sorted indices
     call cudapme_set_bincoor<<<nblockatom,cudathread>>>()
     ! divide the sorted atoms into boxes of 32 atoms, and calculate every box's sizes and centers
     call cudapme_set_box<<<nblockbox,cudathread>>>()
     ! sort the boxes according to their sizes
     call thrustsort(box2size_d,boxsorted2box_d,nbox)
     ! build the neighbor list
     call cudapme_set_nlbox<<<nbox,32,nsharedfornlbox>>>()
     call cudapme_check_exceedarray<<<3,1>>>()
  end if

  ! calculate the interactions in the direct space
 if ( iffepsoftcore .eqv. .false. ) then
    call cudapme_potforce_direct<<<nmaxblockdirec,cudathread>>>()
 else
    call cudapme_potforce_direct_fep<<<nmaxblockdirec,cudathread>>>()
 end if

  ! calculate the interactions in the reciprocal space
  call cudapme_set_gridcharge<<<nblockatom,cudathread>>>()
  call cufftExec(fftplan1,realgridcharge_d,gridcharge_d)
  call cudapme_potforce_recippot<<<nblockrecip,cudathread>>>()
  call cufftExec(fftplan2,gridcharge_d,realgridcharge_d)
  call cudapme_potforce_recipfrc<<<nblockatom,cudathread>>>()

  ! pressure coupling
  if ( ipb > 1 ) call cudapme_npt_vir_mol<<<nblockatom,cudathread>>>()

  call cudatop_potforce_bondedterms<<<nblockbondedterm,cudathread>>>()

  if ( mod(nowstep,printcvstep) == 0 ) call cudapme_potforce_sumpot<<<1,1>>>()

end subroutine

include "cudapme_potforce_direct_fep.f90"

attributes(global) subroutine cudapme_check_exceedarray()
  integer :: i
  select case (blockidx%x)
  case (1)
     if ( gnlj32num_d >= maxtiles_d ) then
        print *,"tile number exceeds the limit!",gnlj32num_d,maxtiles_d; stop
     end if
  case (2)
     if ( gijbinnum_d >= maxijpairs_d ) then
        print *,"single pair number exceeds the limit!",gijbinnum_d,maxijpairs_d; stop
     end if
  case (3)
     i = gexcltilenum_d + gnlj32num_d + (gijbinnum_d-1)/32+1; nblockdirec_d = i
     if ( i > nmaxblockdirec_d ) then
        print *,"nblockdirec exceeds the limit!",i,nmaxblockdirec_d; stop
     end if
  end select
end subroutine

! sum of all the energy terms
attributes(global) subroutine cudapme_potforce_sumpot()
  epot_d = enb14_d+ebond_d+eangle_d+edihe_d+evdwcorr_d+eself_d+eelec_d+evdw_d+ecorr_d+erecip_d
end subroutine

subroutine cudapme_reset_inievdwcorr_eself(tpevdw,tpeself)
  real*8,intent(in) :: tpevdw,tpeself
  evdwcorr_d = tpevdw; eself_d = tpeself
  if ( ipb > 1 ) inievdwcorr_d = tpevdw
end subroutine

attributes(global) subroutine cudapme_clear_force()
  integer :: iatom,i,igrid,jgrid,kgrid,fftngrid(3),ihalf
  real :: tpvec(3),insradius

  fftngrid = fftngrid_d; ihalf=fftngrid(1)/2
  do iatom=blockidx%x,fftngrid(2)*fftngrid(3),nblockatom_d
     kgrid = (iatom-1)/fftngrid(2)+1; jgrid = iatom - (kgrid-1)*fftngrid(2)
     do igrid = threadidx%x, ihalf+1, blockdim%x
        realgridcharge_d(igrid,jgrid,kgrid) = 0.0
        i = igrid + ihalf
        if ( i <= fftngrid(1) ) realgridcharge_d(i,jgrid,kgrid) = 0.0
     end do
  end do

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > natom_d ) return

  nowforce_d(:,iatom) = 0.0d0
  if ( blockidx%x == 1 .and. threadidx%x == 1 ) then
     enb14_d=0d0; ebond_d=0d0; eangle_d=0d0; edihe_d=0d0
     eelec_d=0d0; evdw_d=0d0; ecorr_d=0d0; erecip_d=0d0
     totforce_d=0d0; realgridcharge_d(1,1,1)=0.0

     if ( ipb_d > 1 ) then
        tpvec(1) = inicellvolume_d/cellvolume_d
        pmevir_d = inipmevir_d*tpvec(1)
        evdwcorr_d = inievdwcorr_d*tpvec(1)
        realpressure_d=0.0; pmemolekin_d=0.0

        if ( ioct_d > 0 ) then
           insradius = 1.0/sqrt( dot_product(mat_car2frac_d(1,:),mat_car2frac_d(1,:) ) )
           insradius = min(insradius,1.0/sqrt(mat_car2frac_d(2,2)**2+mat_car2frac_d(2,3)**2))
           insradius = 0.5*min(insradius, 1.0/mat_car2frac_d(3,3))
        else
           insradius = 0.5*minval(pmecell_d)
        end if
        if ( fullcut_d >= insradius ) then
           print *,"cutoff must be smaller than the radius of inscribed sphere ",insradius,fullcut_d; stop
        end if
     end if
  end if

  if ( ifactivebox_d ) return

  tpvec(:) = nowcoor_d(:,binatom_d(iatom)) - bincoor_d(:,iatom)
  if ( dot_product(tpvec,tpvec) > hfskinsq_d ) then
     if ( .not. ifactivebox_d ) ifactivebox_d = .true.
  end if
end subroutine

! set bin index for molecules
attributes(global) subroutine cudapme_set_molbin()
  integer :: natominmol,imol,istart,iend,iatom,binvec(3)
  real :: avgcoor(3),tpvec(3),tpvalue

  imol = (blockidx%x-1)*blockdim%x + threadidx%x; if ( (imol <= nbiomol_d) .or. (imol > nmol_d) ) return

  istart = resindex_d(molindex_d(imol)+1)+1; iend = resindex_d(molindex_d(imol+1)+1)
  avgcoor(1) = sum(nowcoor_d(1,istart:iend))
  avgcoor(2) = sum(nowcoor_d(2,istart:iend))
  avgcoor(3) = sum(nowcoor_d(3,istart:iend))
  avgcoor = avgcoor/dble(natompermol_d(imol))

  if ( ioct_d > 0 ) then
     tpvec(1) = dot_product(mat_car2frac_d(1,1:3),avgcoor(1:3))
     tpvec(2) = mat_car2frac_d(2,2)*avgcoor(2) + mat_car2frac_d(2,3)*avgcoor(3)
     tpvec(3) = mat_car2frac_d(3,3)*avgcoor(3)
  else
     tpvec = avgcoor*pmecellinv_d
  end if

  do istart = 1, 3
     avgcoor(istart) = 4.0*( tpvec(istart) - floor(tpvec(istart)) )
     binvec(istart) = int(avgcoor(istart)+1)
     if ( binvec(istart) < 1 ) then
        binvec(istart)=1
     else if ( binvec(istart) > 4 ) then
        binvec(istart)=4
     end if
  end do

  iatom = hashtable_d(binvec(1),binvec(2),binvec(3))
  binvec = int( (avgcoor - real(binvec-1))*4.0 + 1 )
  do istart = 1, 3
     if ( binvec(istart) < 1 ) then
        binvec(istart)=1
     else if ( binvec(istart) > 4 ) then
        binvec(istart)=4
     end if
  end do
  iatom = iatom*64 + hashtable_d(binvec(1),binvec(2),binvec(3))

  molbin_d(imol) = iatom; molmol_d(imol) = imol
end subroutine

! set bin index for atoms
attributes(global) subroutine cudapme_set_atombin()
  integer :: imol,realmol,ibegin,iend,iatom,atompos

  imol = (blockidx%x-1)*blockdim%x + threadidx%x; if ( (imol <= nbiomol_d) .or. (imol > nmol_d) ) return
  realmol = molmol_d(imol)
  atompos = molgroupstartatom_d(imol) + (imol-molgroupstartmol_d(imol)-1)*natompermol_d(imol)
  ibegin = resindex_d(molindex_d(realmol)+1)+1; iend = resindex_d(molindex_d(realmol+1)+1)

  atompos = atompos - ibegin + 1
  do iatom=ibegin,iend
     binatom_d(atompos + iatom) = iatom
  end do
end subroutine

attributes(global) subroutine cudapme_potforce_compute_global_force()
  integer :: index,iatom
  real*8 :: tpx,tpy,tpz,tpvalue

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x; tpx = 0.0; tpy = 0.0; tpz = 0.0

  if ( iatom <= natom_d ) then
     tpx = nowforce_d(1,iatom); tpy = nowforce_d(2,iatom); tpz = nowforce_d(3,iatom)
  end if

  index = 1
  do while (index<=16)
     tpvalue = __shfl_xor(tpx,index); tpx = tpx + tpvalue
     tpvalue = __shfl_xor(tpy,index); tpy = tpy + tpvalue
     tpvalue = __shfl_xor(tpz,index); tpz = tpz + tpvalue
     index = index*2
  end do
  if ( threadidx%x == 1 ) then
     tpvalue = atomicadd(totforce_d(1),tpx)
     tpvalue = atomicadd(totforce_d(2),tpy)
     tpvalue = atomicadd(totforce_d(3),tpz)
  end if
end subroutine

attributes(global) subroutine cudapme_potforce_remove_global_force()
  integer :: iatom
  iatom = (blockidx%x - 1)*blockdim%x + threadidx%x; if ( iatom > natom_d ) return
  nowforce_d(1:3,iatom) = nowforce_d(1:3,iatom) - totforce_d(1:3)/real(natom_d)
end subroutine

attributes(global) subroutine cudapme_set_bincoor()
  integer :: ibin
  ibin=(blockidx%x-1)*blockdim%x+threadidx%x; if ( ibin > natom_d ) return
  bincoor_d(:,ibin) = nowcoor_d(:,binatom_d(ibin))
  if ( blockidx%x==1 .and. threadidx%x==1 ) then
     gnlj32num_d=0; gijbinnum_d=0; ifactivebox_d=.false.
  end if
end subroutine

attributes(global) subroutine cudapme_set_box()
  integer :: ioct,ibox,ibin,ibegin,iend
  real :: minvec(3),maxvec(3),ctrvec(3),tpvec(3),dmax,cellvec(3),cellvecinv(3)

  ibox = (blockidx%x-1)*blockdim%x + threadidx%x
  ibegin = (ibox-1)*32+1; iend = min(ibox*32,natom_d); ioct=ioct_d

  cellvec=pmecell_d; cellvecinv=pmecellinv_d

  if (ibegin <= natom_d) then
     ! set the left corner of the periodic box as the origin and re-calculate the coordinate of the first atom in the box
     tpvec = bincoor_d(1:3,ibegin)
     if ( ioct > 0 ) then
        tpvec(1) = tpvec(1) - floor(tpvec(3)*mat_car2frac_d(3,3))*mat_frac2car_d(1,3)
        tpvec(2) = tpvec(2) - floor(tpvec(3)*mat_car2frac_d(3,3))*mat_frac2car_d(2,3)
        tpvec(3) = tpvec(3) - floor(tpvec(3)*mat_car2frac_d(3,3))*mat_frac2car_d(3,3)
        
        tpvec(1) = tpvec(1) - floor(tpvec(2)*mat_car2frac_d(2,2))*mat_frac2car_d(1,2)
        tpvec(2) = tpvec(2) - floor(tpvec(2)*mat_car2frac_d(2,2))*mat_frac2car_d(2,2)
        
        tpvec(1) = tpvec(1) - floor(tpvec(1)*mat_car2frac_d(1,1))*mat_frac2car_d(1,1)
     else
        tpvec = tpvec - floor(tpvec*cellvecinv)*cellvec
     end if

     minvec = tpvec; maxvec = tpvec; ctrvec = tpvec
     do ibin = ibegin+1,iend
        ! set the temporary box center as the origin and calculate the atoms(ibin)'s coordinate
        ! range [-cella/2, cella/2], [-cellb/2, cellb/2], [-cellc/2, cellc/2]
        tpvec = bincoor_d(1:3,ibin)
        if ( ioct > 0 ) then
           tpvec(1) = tpvec(1) - floor((tpvec(3)-ctrvec(3))*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(1,3)
           tpvec(2) = tpvec(2) - floor((tpvec(3)-ctrvec(3))*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(2,3)
           tpvec(3) = tpvec(3) - floor((tpvec(3)-ctrvec(3))*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(3,3)
           
           tpvec(1) = tpvec(1) - floor((tpvec(2)-ctrvec(2))*mat_car2frac_d(2,2)+0.5)*mat_frac2car_d(1,2)
           tpvec(2) = tpvec(2) - floor((tpvec(2)-ctrvec(2))*mat_car2frac_d(2,2)+0.5)*mat_frac2car_d(2,2)
            
           tpvec(1) = tpvec(1) - floor((tpvec(1)-ctrvec(1))*mat_car2frac_d(1,1)+0.5)*mat_frac2car_d(1,1)
        else
           tpvec = tpvec - floor((tpvec-ctrvec)*cellvecinv+0.5)*cellvec
        end if

        ! update the boundary and center of the box
        minvec = min(minvec,tpvec); maxvec = max(maxvec,tpvec); ctrvec = (minvec+maxvec)*0.5
     end do

     ! save the final center and size of the box
     boxinfo_d(1:3,ibox) = ctrvec; boxinfo_d(4:6,ibox) = (maxvec-minvec)*0.5
     box2size_d(ibox) = sum(maxvec - minvec)*0.5

     ! update all the atom coordinates in the box
     dmax = 0.0
     do ibin = ibegin,iend
        tpvec = bincoor_d(1:3,ibin) - ctrvec
        if ( ioct > 0 ) then
           tpvec(1) = tpvec(1) - floor(tpvec(3)*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(1,3)
           tpvec(2) = tpvec(2) - floor(tpvec(3)*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(2,3)
           tpvec(3) = tpvec(3) - floor(tpvec(3)*mat_car2frac_d(3,3)+0.5)*mat_frac2car_d(3,3)
           
           tpvec(1) = tpvec(1) - floor(tpvec(2)*mat_car2frac_d(2,2)+0.5)*mat_frac2car_d(1,2)
           tpvec(2) = tpvec(2) - floor(tpvec(2)*mat_car2frac_d(2,2)+0.5)*mat_frac2car_d(2,2)
           
           tpvec(1) = tpvec(1) - floor(tpvec(1)*mat_car2frac_d(1,1)+0.5)*mat_frac2car_d(1,1)
        else
           tpvec = tpvec - floor(tpvec*cellvecinv+0.5)*cellvec
        end if

        dmax = max(dmax,dot_product(tpvec,tpvec))
     end do
     boxsorted2box_d(ibox) = ibox; boxinfo_d(7,ibox) = sqrt(dmax)
  end if
end subroutine

attributes(device) subroutine cudapme_set_ijbin(ibox,nljbinlist,nlipacklist,nlistidx,ifclearup)
  integer,intent(in) :: ibox
  integer,intent(inout) :: nljbinlist(256),nlipacklist(256),nlistidx
  logical,intent(in) :: ifclearup
  integer,shared :: gnlj32num,tpnlistidx
  integer :: nlj32num,ithread,idx,ijnum,ipack,jbegin,jbinloop,i,jbin,tilejbin,votetilejbin

  ithread = threadidx%x
  if ( nlistidx > 32 ) then

     ! count the number of small neighbor pairs whose neighbors are less than 2 (ijum)
     ijnum = 0; jbegin = 0; i = ijpairsize_d
     do jbinloop = ithread, nlistidx, 32
        idx = __popc(nlipacklist(jbinloop))
        if ( idx <= i ) ijnum = ijnum + idx
     end do
   
     ! sum up small neighbor pairs, ijnum
     i = 1
     do while ( i <= 16 )
        ! shift the integer value, ijnum, from ithread-thread to (ithread + i)-ithread
        idx = __shfl_up(ijnum,i)
        ! sum up ijnum
        if ( ithread > i ) ijnum = ijnum + idx
        i = i*2   ! double the current stride for summation
     end do
   
     ! accumulate the number of small neighbor pairs, gijbinnum_d
     ! ijnum : total number of small neighbor pairs in the current list (256 members)
     ! idx : previous number of small neighbor pairs (shared variable)
     if ( ithread == 32 ) then
        tpnlistidx = 0
        idx = atomicadd(gijbinnum_d,ijnum)
     end if

     ! broadcast previous gijbinnum from thread 32
     idx = __shfl(idx,32)
   
     ! locate the position idx to save the small neighbor pairs by a particular thread
     ! shift the integer value, ijnum, from ithread-thread to (ithread+1)-ithread
     ! for example, there are three threads with different small neighbor pairs
     !      thread1 : 1, thread2 : 2, thread3 : 1
     ! their start idx are
     !      thread1 : 0, thread2 : 1, thread3 : 3
     i = __shfl_up(ijnum,1)
     if ( ithread > 1 ) idx = idx + i
   
     ! flush the neighbor list to the global memory
     ! cannot use some code like "do jbinloop=ithread,nmax,32", because there is a vote function in the cycle
     jbegin = 0
     do while (jbegin<nlistidx)
        jbinloop = jbegin + ithread; tilejbin = 0
        if (jbinloop<=nlistidx) then
   
           jbin = nljbinlist(jbinloop)      ! jbin atom
           ipack = nlipacklist(jbinloop)    ! encoded neighbor list of jbin atom in ibox
           i = __popc(ipack)                ! number of neighbors of jbin atom
   
           if ( i > ijpairsize_d ) then
   
              ! set the related bit to 1 for jbin atom with large neighbors, we'll handle it later
              tilejbin = 1  
   
           else
   
              ! deal with small neighbor pair
              i = (ibox-1)*32    ! initial position of atoms in ibox
              do while ( ipack /= 0 )
                 idx = idx + 1
                 ! pick iatom in the encoded neighbor list one by one
                 gijbinlist_d(1:2,idx) = [ i +__ffs(ipack), jbin ]
                 ! set the corresponding bit to 0
                 ipack = ibclr(ipack,__ffs(ipack)-1)
              end do
   
           end if
        end if
   
        ! warp vote function ballot(predicate)
        ! Evaluate predicate for all active threads of the warp and return an integer whose Nth bit is set if and only if predicate evaluates to non-zero for the Nth thread of the warp and the Nth thread is active.
        ! encode 32 jbin atoms whose neighbor atoms in ibox is larger than 2
        votetilejbin = ballot(tilejbin)
        if (tilejbin/=0) then
           ! position of jbin atom in the neighbor list for ithread, see explanation in set_nlbox()
           i = __popc(iand(votetilejbin,ior(ishft(1,ithread-1),ishft(1,ithread-1)-1)))
           nljbinlist(tpnlistidx+i) = jbin
           nlipacklist(tpnlistidx+i) = ipack
        end if
        if ( ithread == 1 ) tpnlistidx = tpnlistidx + __popc(votetilejbin)
        jbegin = jbegin + 32
     end do
     if ( ithread == 1 ) nlistidx = tpnlistidx
     call syncthreads()
  end if

  ! do not clear up all the neighbor list array, keep the remainder of 32
  if ( ifclearup .eqv. .false. ) then

     ! regroup all the neighboring jatoms into a set of 32-atom boxes
     ! estimate the number of jbox to save
     nlj32num = nlistidx/32
     if (ithread==1) then
        ! gnlistnum : previous gnlj32num_d
        gnlj32num = atomicadd(gnlj32num_d,nlj32num)
        ! decrease the temporary neighbor list size
        nlistidx = nlistidx - nlj32num*32
     end if
     ! save the ibox-jbox pair to global memory
     call syncthreads()
     do i=ithread,nlj32num,32
        gnliboxlist_d(gnlj32num+i) = ibox
     end do
     ijnum = gnlj32num*32
     do i = 1,nlj32num
        ! save all jatoms in jbox (not the encoded list)
        idx = (i-1)*32+ithread
        gnljbinlist_d(ijnum+idx) = nljbinlist(idx)
     end do
     ! move the remainder neighbors to the head of the array
     if ( ithread <= nlistidx ) then
        idx = nlj32num*32+ithread
        nljbinlist(ithread) = nljbinlist(idx)
        nlipacklist(ithread) = nlipacklist(idx)
     end if

  ! clear up all the neighbor list to the global memory
  else if ( nlistidx > 0 ) then

     nlj32num = (nlistidx+31)/32
     if (ithread==1) then
        gnlj32num = atomicadd(gnlj32num_d,nlj32num)
     end if
     call syncthreads()
     do i=ithread,nlj32num,32
        gnliboxlist_d(gnlj32num+i) = ibox
     end do
     ijnum = gnlj32num*32
     do i = 1,nlj32num
        idx = (i-1)*32+ithread
        if ( idx <= nlistidx ) then
           gnljbinlist_d(ijnum+idx) = nljbinlist(idx)
        else
           gnljbinlist_d(ijnum+idx) = 0
        end if
     end do

  end if

end subroutine

attributes(global) subroutine cudapme_set_nlbox()
  integer,shared :: nljbinlist(256),nlipacklist(256),nlistidx
  integer,shared :: biexclbox(maxbiexcboxnum_d),biexclboxpos,biexclboxnum
  real,shared :: ibincoor(3,32),jboxctr(3,32),jboxsize(32)
  integer :: ithread,ibox,jbox,jbegin,votenlbox,ibin,jbin,votenlibin,votenljbin
  integer :: ifnlbox,nlbin,idx,inum,natom,nbox,ioct
  real :: iboxctr(3),iboxsizevec(3),iboxsize,dcoor(3),jbincoor(3),cellvec(3),cellvecinv(3),cellhalf(3),fullcutsq,fullcut
  logical :: ifvalidatom

  ! each block handles one box (32 atoms
  ithread=threadidx%x; ibox = boxsorted2box_d(blockidx%x)
  if (ithread==1) then
     biexclboxpos = biexcludedboxlistindex_d(ibox)
     biexclboxnum = biexcludedboxlistindex_d(ibox+1)-biexclboxpos
  end if
  call syncthreads()
  do inum = ithread,biexclboxnum,32
     biexclbox(inum) = biexcludedboxlist_d(biexclboxpos+inum)
  end do

  fullcut=fullcut_d; fullcutsq=fullcutsq_d; natom=natom_d; nbox=nbox_d; ioct=ioct_d
  cellvec=pmecell_d; cellvecinv=pmecellinv_d

  if ( ioct > 0 ) then
     cellhalf(1) = 0.5*sqrt( dot_product(mat_frac2car_d(1,:),mat_frac2car_d(1,:)) ) - fullcut
     cellhalf(2) = 0.5*sqrt( mat_frac2car_d(2,2)**2 +  mat_frac2car_d(2,3)**2 ) - fullcut
     cellhalf(3) = 0.5*mat_frac2car_d(3,3) - fullcut
  else
     cellhalf = 0.5*cellvec - fullcut
  end if

  ! get one atom in ibox for each thread
  ibin = (ibox-1)*32+ithread; ifvalidatom=.false.
  if ( ibin <= natom ) then
     ifvalidatom=.true.; ibincoor(:,ithread) = bincoor_d(:,ibin)
  end if

  ! box center
  iboxctr(1:3) = boxinfo_d(1:3,ibox)

  ! box size (half length) in three dimensions, and box volumn size (largest distance from atom to box center)
  iboxsizevec(1:3) = boxinfo_d(4:6,ibox); iboxsize = boxinfo_d(7,ibox)
  jbegin = blockidx%x; nlistidx = 0

  do while (jbegin<nbox)
    
     ! first, box-to-box, search the distance between ibox and the next 32 boxes 
     inum = jbegin+ithread; ifnlbox = 0
     if ( inum <= nbox ) then
        jbox = boxsorted2box_d(inum)

        ! remove jbox from exclusion list.
        ! if jbox is in the excluded box list of ibox, then it is not a neightboring box of ibox
        do inum = 1,biexclboxnum
           if ( biexclbox(inum) == jbox ) goto 101
        end do

        ! get jbox's center and size
        jboxctr(1:3,ithread) = boxinfo_d(1:3,jbox); jboxsize(ithread) = fullcut+boxinfo_d(7,jbox)

        ifnlbox = 1 
        jbincoor(1) = iboxsizevec(1) + boxinfo_d(4,jbox)
        if ( jbincoor(1) > cellhalf(1) ) goto 101
        jbincoor(2) = iboxsizevec(2) + boxinfo_d(5,jbox)
        if ( jbincoor(2) > cellhalf(2) ) goto 101
        jbincoor(3) = iboxsizevec(3) + boxinfo_d(6,jbox)
        if ( jbincoor(3) > cellhalf(3) ) goto 101

        ! calculate the real ibox-jbox displacement vector
        dcoor(1:3) = iboxctr(1:3) - jboxctr(1:3,ithread)
        ! calculate the minimal ibox-jbox image displacement in the periodic box
        if ( ioct > 0 ) then
           include "cudapme_octcal.f90"
        else
           dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
        end if

        ifnlbox = 0 
        if ( dot_product(dcoor,dcoor) > (iboxsize+jboxsize(ithread))**2 ) goto 101

        ! if ibox-jbox distance exceeds the cutoff, then it is not a neightbor box of ibox
        dcoor = max(0.0,abs(dcoor)-jbincoor)
        if ( dot_product(dcoor,dcoor) > fullcutsq ) goto 101

        ifnlbox = 1
     end if
101 continue

     ! warp vote function ballot(), other vote functions: __all(), __any()
     ! encode all 32 boxes within the cutoff to an integer "votenlbox"
     votenlbox = ballot(ifnlbox)

     do while (votenlbox/=0)

        ! second, atom-to-box, search 32 atoms in ibox to one marked jbox by all threads at one time
        ! when one jbox is finished, jump to the next jbox
        ! ffs: locate the first non-zero bit (jbox), ibclr: clear the selected bit
        inum = __ffs(votenlbox)

        ! clear the corresponding i-bit
        votenlbox = ibclr(votenlbox,inum-1)

        ! get the real jbox index
        jbox = boxsorted2box_d(jbegin+inum)

        nlbin = 0
        if ( ifvalidatom ) then
           ! calculate the distance from ithread's atom in ibox to jbox's center
           dcoor = ibincoor(1:3,ithread)-jboxctr(1:3,inum)
           if ( ioct > 0 ) then
              include "cudapme_octcal.f90"
           else
              dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
           end if

           ! if the distance exceeds the cutoff, set nlbin to zero
           if ( dot_product(dcoor,dcoor) < jboxsize(inum)**2 ) nlbin = 1
        end if

        ! encode all atoms in ibox to an integer "votenlibin"
        votenlibin = ballot(nlbin)

        if (votenlibin/=0) then

           ! third, atom-to-atom
           ! each thread picks one jbin atom in jbox and check its distance to ibinl-to-ibinr atoms in ibox
           jbin = (jbox-1)*32+ithread; nlbin = 0

           if (jbin<=natom) then
              jbincoor = bincoor_d(1:3,jbin)
              ! search ibinl-to-ibinr atoms in ibox
              do while ( votenlibin /= 0 )
                 inum = __ffs(votenlibin)
                 dcoor = ibincoor(1:3,inum) - jbincoor

                 if ( ioct > 0 ) then
                    include "cudapme_octcal.f90"
                 else
                    dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
                 end if
               
                 ! mark the bit to 1 if the corresponding jbin atom is a neighbor of ibin atom
                 if ( dot_product(dcoor,dcoor) < fullcutsq ) nlbin = ibset(nlbin,inum-1)
                 votenlibin = ibclr(votenlibin,inum-1)
              end do
           end if

           ! encoded all the jbin atoms in jbox
           ! nlbin is an encoded list of jbin atom in ibox, nlbin == 0 means jbin atom does not have a neighbor atom in  ibox
           votenljbin = ballot(nlbin)

           if (nlbin/=0) then
              ! __popc(i) : get the number of bits of 1 in integer i
              ! ior(ishft(1,ithread-1),ishft(1,ithread-1)-1) : get the bits blong to ithread and jbin atom
              ! for example, votenljbin="11101" with five threads 
              ! for ithread=3, i1=ishft(1,ithread-1)="100", i2=ishft(1,ithread-1)-1="011"
              ! so ior(i1,i2)="111"=i3
              ! why not just use ishft(1,ithread)-1="111"? because for ithread=32,ishft(1,ithread) exceeds the upper limit of an 32-bit integer
              ! iand(votenljbin,i3)="00101" indicates that ithread=3's jbin atom is a neighbour atom of ibox
              ! finally,__popc("00101")=2 indicates the local position of ithread=3's jbin atom in the neighbor list is 2.
              idx = nlistidx + __popc(iand(votenljbin,ior(ishft(1,ithread-1),ishft(1,ithread-1)-1)))

              ! each thread saves one jbin atom's index in the nljbinlist array and
              ! its encoded neighboring list "nlbin" to the nlipacklist array
              ! maximum neighbors of atoms in ibox is 256
              nljbinlist(idx) = jbin; nlipacklist(idx) = nlbin
           end if

           if ( ithread == 1 ) nlistidx = nlistidx + __popc(votenljbin)
           call syncthreads()

           ! if the neighbor list, nlipacklist, is almost full, i.e., it cannot save 32 more intergers (neighboring atoms)
           ! then, call cudapme_set_ijbin to extract small neighbors and move the data to global memory
           ! and then, reset nlistidx=0
           if ( nlistidx + 32 > 256 ) then
              call cudapme_set_ijbin(ibox,nljbinlist,nlipacklist,nlistidx, ifclearup=.false.)
           end if
        end if
     end do
     jbegin = jbegin + 32
  end do

  call syncthreads()
  call cudapme_set_ijbin(ibox,nljbinlist,nlipacklist,nlistidx,ifclearup=.true.)

end subroutine

attributes(global) subroutine cudapme_potforce_direct()
  integer :: iblock
  iblock=blockidx%x; if ( iblock > nblockdirec_d ) return
  if ( iblock <= nbox_d ) then
     call cudapme_potforce_selfexcl(iblock)
  else
     if ( iblock <= gexcltilenum_d ) then
        call cudapme_potforce_interexcl(iblock)
     else
        iblock = iblock - gexcltilenum_d
        if ( iblock <= gnlj32num_d ) then
           call cudapme_potforce_tile(iblock)
        else
           iblock = iblock - gnlj32num_d
           call cudapme_potforce_ijbin(iblock)
        end if
     end if
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_selfexcl(iblock)
  integer :: ipb,ioct,natom,ithread,iblock,iexcl,ibin,jbin,iatom,jloop,inext
  real :: discutsq,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),ifrc(3),jfrc(3),icharge,jcharge
  real :: dis,disinv,dissq,dissqinv,tpelec,tpvdw,tpcorr,tpfrccoef,coef1,vir(3)
  real :: ivdwsigma,jvdwsigma,ivdweps,jvdweps
  logical :: ifcalpot

  discutsq=discutsq_d; ifcalpot=ifcalpot_d; cellvec=pmecell_d; cellvecinv=pmecellinv_d
  natom = natom_d; ewaldalpha = ewaldalpha_d; ipb=ipb_d; ioct=ioct_d
  if ( ipb_d > 1 ) vir=0.0

  ! each thread starts from a diagonal element in the tile (box-box pair)
  ithread=threadidx%x; inext = ithread+1

  ! iblock : excluded box pair ibox-ibox, one tile has 32 encoded lists for 32 atoms
  ! iexcl : each thread processes one atom's encoded list of 32 excluded atoms
  ! iexcl = biencodedexcludedtilelist_d(ithread,iblock)
  ! i.e., ithread=3 starts from iatom=3 and jatom=3
  ! so the encoded list should be transfered to let the ithread's excluded list also starts from the diagonal element
  ! for example, the exludes matrix of all atoms in a box are (note that first position is on the right side)
  ! 1 1 0 1
  ! 0 1 1 0
  ! 1 0 1 1
  ! 0 1 1 1
  ! for ithread=3, its encoded list (1 0 1 1) should be tranfered to (1110)
  ! iexcl = ior(ishft(iexcl,1-ithread),ishft(iexcl,33-ithread))
  ! diagonal element should be skipped
  ! iexcl = ior(ishft(iexcl,-ithread),ishft(iexcl,32-ithread))

  ! alternative method
  iexcl = ishftc(biencodedexcludedtilelist_d(ithread,iblock),-ithread)

  ! ibin : anchor atom
  ibin = (iblock-1)*32+ithread; jbin=ibin
  if ( ibin <= natom ) then
     iatom = binatom_d(ibin); icharge = charge_d(iatom)
     icoor(1:3) = nowcoor_d(1:3,iatom)
     jcharge = icharge; jcoor = icoor
     ivdwsigma = vdwsigma_d(iatom); ivdweps = vdweps_d(iatom)
     jvdwsigma = ivdwsigma; jvdweps = ivdweps
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpcorr = 0.0
  end if
  ifrc = 0.0; jfrc = 0.0

  do jloop = 1, 16

     ! get the next atom ( it is contained by the neighboring thread, use shuffle function to get it )
     jbin = __shfl(jbin,inext)

     jcharge = __shfl(jcharge,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jvdwsigma = __shfl(jvdwsigma,inext); jvdweps = __shfl(jvdweps,inext)

     if ( ibin <= natom ) then
     if ( jbin <= natom ) then
     if ( ithread <= 16 .or. jloop < 16  ) then

         dcoor = icoor - jcoor
         if ( ioct > 0 ) then
            include "cudapme_octcal.f90"
         else
            dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
         end if
         dissq = dot_product(dcoor,dcoor)

         if ( dissq <= discutsq ) then

            dis = sqrt(dissq); disinv=1.0/dis
            coef1 = icharge*jcharge*disinv; dis=ewaldalpha*dis
            call erfc_function_simple(dis,dissqinv,tpfrccoef)     ! dissqinv: erfc, tpfrccoef: erfc dev
            dis = coef1*(-dis*tpfrccoef+dissqinv); dissq = coef1*dissqinv
            dissqinv=disinv*disinv
            if (btest(iexcl,0)) then
               if (ifcalpot) tpcorr = tpcorr + dissq - coef1
               tpfrccoef = dissqinv*(dis-coef1)
            else
               tpfrccoef = dis
               dis = ivdwsigma + jvdwsigma; dis = (dis*disinv)**2; dis = dis*dis*dis
               coef1 = dis*ivdweps*jvdweps
               if ( ifcalpot ) then
                  tpelec = tpelec + dissq
                  tpvdw = tpvdw + coef1*(dis - 1.0)
               end if
               tpfrccoef = (tpfrccoef + coef1*(12.0*dis - 6.0))*dissqinv
            end if

            if ( ipb > 1 ) then
               vir(:) = vir(:) + dcoor(:)*dcoor(:)*tpfrccoef
            end if

            dcoor = dcoor*tpfrccoef
            ifrc = ifrc + dcoor; jfrc = jfrc - dcoor

         end if

     end if; end if; end if

     ! move to the next bit on the encoded list
     iexcl = ishft(iexcl,-1)

     ! get the force of jatom that has been summed on the neighboring thread
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)

  end do

  inext = ithread - 17
  jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
  if ( ibin <= natom ) then
     coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)+jfrc(1)))
     coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)+jfrc(2)))
     coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)+jfrc(3)))
  end if

  if ( ipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpcorr,jloop); tpcorr = tpcorr + coef1
     jloop = jloop*2
  end do
  if (ithread==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
     coef1 = atomicadd(ecorr_d,dble(tpcorr))
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_interexcl(iblock)
  integer :: ipb,ioct,natom,ithread,iblock,ibox,jbox,iexcl,iatom,jatom,jloop,inext
  real :: discutsq,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),ifrc(3),jfrc(3),icharge,jcharge
  real :: dis,disinv,dissq,dissqinv,tpelec,tpvdw,tpcorr,tpfrccoef,coef1,vir(3)
  real :: ivdwsigma,jvdwsigma,ivdweps,jvdweps
  logical :: ifcalpot

  discutsq=discutsq_d; ifcalpot=ifcalpot_d; cellvec=pmecell_d; cellvecinv=pmecellinv_d
  natom = natom_d; ewaldalpha = ewaldalpha_d; ipb=ipb_d; ioct=ioct_d
  if ( ipb > 1 ) vir=0.0

  ! each thread starts from a diagonal element in the tile (box-box pair)
  ithread=threadidx%x; inext = ithread+1

  ibox = biexcludedtilelist_d(1,iblock); jbox = biexcludedtilelist_d(2,iblock)
  ! iexcl = ior(ishft(iexcl,1-ithread),ishft(iexcl,33-ithread))
  iexcl = ishftc(biencodedexcludedtilelist_d(ithread,iblock),-ithread+1)

  iatom = (ibox-1)*32+ithread
  if ( iatom <= natom ) then
     iatom = binatom_d(iatom); icharge = charge_d(iatom)
     icoor(1:3) = nowcoor_d(1:3,iatom)
     ivdwsigma = vdwsigma_d(iatom); ivdweps = vdweps_d(iatom)
  end if

  jatom = (jbox-1)*32+ithread
  if ( jatom <= natom ) then
     jatom = binatom_d(jatom); jcharge = charge_d(jatom)
     jcoor(1:3) = nowcoor_d(1:3,jatom)
     jvdwsigma = vdwsigma_d(jatom); jvdweps = vdweps_d(jatom)
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpcorr = 0.0
  end if
  ifrc = 0.0; jfrc = 0.0

  do jloop = 1,32

     if ( iatom <= natom ) then
     if ( jatom <= natom ) then

     dcoor = icoor - jcoor
     if ( ioct > 0 ) then
        include "cudapme_octcal.f90"
     else
        dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
     end if
     dissq = dot_product(dcoor,dcoor)

     if ( dissq <= discutsq ) then

        dis = sqrt(dissq); disinv=1.0/dis
        coef1 = icharge*jcharge*disinv; dis=ewaldalpha*dis
        call erfc_function_simple(dis,dissqinv,tpfrccoef)     ! dissqinv: erfc, tpfrccoef: erfc dev
        dis = coef1*(-dis*tpfrccoef+dissqinv); dissq = coef1*dissqinv
        dissqinv=disinv*disinv
        if (btest(iexcl,0)) then
           if (ifcalpot) tpcorr = tpcorr + dissq - coef1
           tpfrccoef = dissqinv*(dis-coef1)
        else
           tpfrccoef = dis
           dis = ivdwsigma + jvdwsigma; dis = (dis*disinv)**2; dis = dis*dis*dis
           coef1 = dis*ivdweps*jvdweps
           if ( ifcalpot ) then
              tpelec = tpelec + dissq
              tpvdw = tpvdw + coef1*(dis - 1.0)
           end if
           tpfrccoef = (tpfrccoef + coef1*(12.0*dis - 6.0))*dissqinv
        end if

        if ( ipb > 1 ) then
           vir(:) = vir(:) + dcoor(:)*dcoor(:)*tpfrccoef
        end if

        dcoor = dcoor*tpfrccoef
        ifrc = ifrc + dcoor; jfrc = jfrc - dcoor
     end if

     end if; end if

     iexcl = ishft(iexcl,-1); jcharge = __shfl(jcharge,inext); jatom = __shfl(jatom,inext)

     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
     jvdwsigma = __shfl(jvdwsigma,inext); jvdweps = __shfl(jvdweps,inext)
  end do

  if ( iatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)))
     coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)))
     coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)))
  end if
  if ( jatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,jatom),dble(jfrc(1)))
     coef1 = atomicadd(nowforce_d(2,jatom),dble(jfrc(2)))
     coef1 = atomicadd(nowforce_d(3,jatom),dble(jfrc(3)))
  end if

  if ( ipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpcorr,jloop); tpcorr = tpcorr + coef1
     jloop = jloop*2
  end do

  if (ithread==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
     coef1 = atomicadd(ecorr_d,dble(tpcorr))
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_tile(iblock)
  integer :: ipb,ioct,natom,ithread,iblock,ibox,iatom,jatom,jloop,inext
  real :: discutsq,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),icharge,jcharge,ifrc(3),jfrc(3)
  real :: dis,disinv,dissq,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  real :: ivdweps,ivdwsigma,jvdweps,jvdwsigma
  logical :: ifcalpot

  discutsq=discutsq_d; ifcalpot=ifcalpot_d; cellvec=pmecell_d; cellvecinv=pmecellinv_d
  natom = natom_d; ewaldalpha = ewaldalpha_d; ipb=ipb_d; ioct=ioct_d
  if ( ipb > 1 ) vir=0.0

  ithread=threadidx%x; ibox=gnliboxlist_d(iblock); iatom = (ibox-1)*32+ithread

  ! iatom info (ibox)
  if ( iatom <= natom ) then
     iatom = binatom_d(iatom); icharge = charge_d(iatom)
     icoor(1:3) = nowcoor_d(1:3,iatom); inext = ithread+1
     ivdwsigma = vdwsigma_d(iatom); ivdweps = vdweps_d(iatom)
  end if

  ! jatom info (jbox)
  jatom = gnljbinlist_d((iblock-1)*32+ithread)
  if ( jatom > 0 ) then
     jatom = binatom_d(jatom); jcharge = charge_d(jatom)
     jcoor(1:3) = nowcoor_d(1:3,jatom)
     jvdwsigma = vdwsigma_d(jatom); jvdweps = vdweps_d(jatom)
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0
  end if
  ifrc=0.0; jfrc=0.0

  do jloop = 1,32
     if ( iatom <= natom ) then
     if ( jatom /= 0 ) then

        dcoor = icoor - jcoor
        if ( ioct > 0 ) then
           include "cudapme_octcal.f90"
        else
           dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
        end if
        dissq = dot_product(dcoor,dcoor)

        if ( dissq <= discutsq ) then

           dis = sqrt(dissq); disinv=1.0/dis; coef1 = icharge*jcharge*disinv; dis = ewaldalpha*dis
           call erfc_function_simple(dis,dissq,tpfrccoef)     ! dissq=erfc, tpfrccoef=erfc_dev
           if (ifcalpot) tpelec = tpelec + coef1*dissq
           tpfrccoef = coef1*(-dis*tpfrccoef+dissq)

           dis = ivdwsigma + jvdwsigma; dis = (dis*disinv)**2; dis = dis*dis*dis
           coef1 = dis*ivdweps*jvdweps
           if ( ifcalpot ) tpvdw = tpvdw + coef1*(dis - 1.0)
           tpfrccoef = (tpfrccoef + coef1*(12.0*dis - 6.0))*disinv*disinv

           if ( ipb > 1 ) then
              vir(:) = vir(:) + dcoor(:)*dcoor(:)*tpfrccoef
           end if
           dcoor = dcoor*tpfrccoef
           ifrc = ifrc + dcoor; jfrc = jfrc - dcoor
        end if

     end if; end if

     jcharge = __shfl(jcharge,inext); jatom = __shfl(jatom,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
     jvdwsigma = __shfl(jvdwsigma,inext); jvdweps = __shfl(jvdweps,inext)

  end do

  if ( iatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)))
     coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)))
     coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)))
  end if
  if ( jatom > 0 .and. jatom <= natom ) then
     coef1 = atomicadd(nowforce_d(1,jatom),dble(jfrc(1)))
     coef1 = atomicadd(nowforce_d(2,jatom),dble(jfrc(2)))
     coef1 = atomicadd(nowforce_d(3,jatom),dble(jfrc(3)))
  end if

  if ( ipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  ! sum up energy by shfl.
  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     jloop = jloop*2
  end do
  if (ithread==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
  end if
end subroutine

attributes(device) subroutine cudapme_potforce_ijbin(iblock)
  integer :: irec,iatom,jatom,iblock
  real :: dcoor(3),dis,disinv,dissq,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  logical :: ifcalpot,ipb

  ifcalpot = ifcalpot_d; ipb = ipb_d
  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0
  end if
  if ( ipb > 1 ) vir = 0.0

  irec = (iblock-1)*blockdim%x+threadidx%x

  if ( irec <= gijbinnum_d ) then

     ! atom-atom pair in small box-box pair
     iatom = binatom_d(gijbinlist_d(1,irec)); jatom = binatom_d(gijbinlist_d(2,irec))

     dcoor = nowcoor_d(1:3,iatom) - nowcoor_d(1:3,jatom)
     if ( ioct_d > 0 ) then
        include "cudapme_octcal.f90"
     else
        dcoor = dcoor - floor(dcoor*pmecellinv_d+0.5)*pmecell_d
     end if
     dissq = dot_product(dcoor,dcoor)

     if ( dissq <= discutsq_d ) then

        dis = sqrt(dissq); disinv=1.0/dis; coef1 = charge_d(iatom)*charge_d(jatom)*disinv
        dis = ewaldalpha_d*dis
        call erfc_function_simple(dis,dissq,tpfrccoef)     ! dissq=erfc, tpfrccoef=erfc_dev
        if ( ifcalpot ) tpelec = coef1*dissq
        tpfrccoef = coef1*(-dis*tpfrccoef+dissq)

        dis = vdwsigma_d(iatom) + vdwsigma_d(jatom); dis = (dis*disinv)**2; dis = dis*dis*dis
        coef1 = dis*vdweps_d(iatom)*vdweps_d(jatom)
        if ( ifcalpot ) tpvdw = coef1*(dis - 1.0)
        tpfrccoef = (tpfrccoef + coef1*(12.0*dis - 6.0))*disinv*disinv

        if ( ipb > 1 ) then
           vir(:) = dcoor(:)*dcoor(:)*tpfrccoef
        end if
        dcoor = dcoor*tpfrccoef
        coef1 = atomicadd(nowforce_d(1,iatom),dble(dcoor(1)))
        coef1 = atomicadd(nowforce_d(2,iatom),dble(dcoor(2)))
        coef1 = atomicadd(nowforce_d(3,iatom),dble(dcoor(3)))
        coef1 = atomicadd(nowforce_d(1,jatom),dble(-dcoor(1)))
        coef1 = atomicadd(nowforce_d(2,jatom),dble(-dcoor(2)))
        coef1 = atomicadd(nowforce_d(3,jatom),dble(-dcoor(3)))
     end if

  end if

  if ( ipb > 1 ) then
     irec = 1
     do while (irec<=16)
        coef1 = __shfl_xor(vir(1),irec); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),irec); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),irec); vir(3) = vir(3) + coef1
        irec = irec*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(pmevir_d(1),dble(vir(1)))
        coef1 = atomicadd(pmevir_d(2),dble(vir(2)))
        coef1 = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  irec = 1
  do while (irec<=16)
     coef1 = __shfl_xor(tpelec,irec); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,irec); tpvdw = tpvdw + coef1
     irec = irec*2
  end do
  if (threadidx%x==1) then
     coef1 = atomicadd(eelec_d,dble(tpelec))
     coef1 = atomicadd(evdw_d,dble(tpvdw))
  end if
end subroutine

attributes(global) subroutine cudapme_set_gridcharge()
  integer :: iatom,i,j,k,kgrid,gridvec(3),fftngrid(3),chargeigrid(4),chargejgrid(4)
  real :: xivec(3),tpdev,basisi,basisk,basisjk

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > natom_d ) return
  fftngrid=fftngrid_d; ! norder = splineorder_d

  xivec = nowcoor_d(:,iatom)
  if ( ioct_d > 0 ) then
     xivec(1) = dot_product(mat_car2frac_d(1,:),xivec)
     xivec(2) = mat_car2frac_d(2,2)*xivec(2) + mat_car2frac_d(2,3)*xivec(3)
     xivec(3) = mat_car2frac_d(3,3)*xivec(3)
  else
     xivec = xivec*pmecellinv_d
  end if

  xivec = (xivec-anint(xivec)+0.5)*real(fftngrid) - 0.00001
  gridvec = int(xivec); xivec = xivec - real(gridvec)
  gridvec = gridvec - 3

  chargegrid_d(:,iatom)=gridvec; chargexi_d(:,iatom)=xivec

  do i = 1, 4   ! norder
     chargejgrid(i) = gridvec(2) + i
     if ( chargejgrid(i)<=0) chargejgrid(i) = chargejgrid(i) + fftngrid(2)
     chargeigrid(i) = gridvec(1) + i
     if ( chargeigrid(i)<=0) chargeigrid(i) = chargeigrid(i) + fftngrid(1)
  end do

  tpdev = charge_d(iatom)
  do k = 1, 4 ! norder
     kgrid = gridvec(3)+k; if (kgrid<=0) kgrid = kgrid + fftngrid(3)
     call cudapme_potforce_spline(k,xivec(3),basisk); basisk=basisk*tpdev
     do j = 1, 4 ! norder
        call cudapme_potforce_spline(j,xivec(2),basisjk); basisjk=basisjk*basisk
        do i = 1, 4 ! norder
           call cudapme_potforce_spline(i,xivec(1),basisi)
           basisi = atomicadd(realgridcharge_d(chargeigrid(i),chargejgrid(j),kgrid),basisi*basisjk)
        end do
     end do
  end do

end subroutine

attributes(device) subroutine cudapme_potforce_spline(igrid,xi,basisfunc,basisdev)
  integer,intent(in) :: igrid
  real,intent(in) :: xi
  real,intent(out) :: basisfunc
  real,intent(out),optional :: basisdev
  real :: xi_2, one_xi, one_xi_2

  xi_2 = xi**2*0.5; one_xi = 1.0 - xi; one_xi_2 = one_xi**2*0.5

  select case (igrid)
  case (1); basisfunc = one_xi*one_xi_2*0.333333333
  case (2); basisfunc = xi_2*(xi-2.0) + 0.666666667
  case (3); basisfunc = one_xi_2*(one_xi-2.0) + 0.666666667
  case (4); basisfunc = xi*xi_2*0.333333333
  end select

  if ( .not. present(basisdev) ) return
  select case (igrid)
  case (1); basisdev = -one_xi_2
  case (2); basisdev = xi*(xi-2.0) + xi_2
  case (3); basisdev = -one_xi*(one_xi-2.0) - one_xi_2
  case (4); basisdev = xi_2
  end select
end subroutine

attributes(global) subroutine cudapme_potforce_recippot()
  integer :: igrid,jgrid,kgrid,ihalf,i
  real :: tpbcterm,tppot,tpa,msq,vir(3)
  complex :: tpgridcharge

  if ( ipb_d > 1 ) vir=0.0; if ( ifcalpot_d ) tppot=0.0

  igrid = (blockidx%x-1)*blockdim%x+threadidx%x
  if ( igrid <= fftnhalftotgrid_d ) then

     igrid = igrid + 1    ! skip the first grid (igrid=1,jgrid=1,kgrid=1)
     ihalf = fftngrid_d(1)/2+1; i = ihalf*fftngrid_d(2)
     kgrid = (igrid-1)/i + 1; i = igrid - (kgrid-1)*i
     jgrid = (i-1)/ihalf + 1
     igrid = i - (jgrid-1)*ihalf

     tpgridcharge = gridcharge_d(igrid,jgrid,kgrid)
     tpbcterm = pmebcterm_d(igrid,jgrid,kgrid)
     gridcharge_d(igrid,jgrid,kgrid) = 2.0*tpbcterm*tpgridcharge

     if ( ifcalpot_d ) then
        tppot = 2.0*tpbcterm*( real(tpgridcharge)**2 + aimag(tpgridcharge)**2 )
        if ( igrid == 1 .or. ( igrid == (fftngrid_d(1)/2+1) .and. btest(igrid,0) ) ) tppot = tppot*0.5
     end if
   
     if ( ipb_d > 1 ) then
        vir(1) = pmemterm_d(1,igrid); vir(2) = pmemterm_d(2,jgrid); vir(3) = pmemterm_d(3,kgrid)
        if ( ioct_d > 0 ) then
           vir(3) = dot_product(mat_car2frac_d(:,3),vir)**2
           vir(2) = (mat_car2frac_d(1,2)*vir(1) + mat_car2frac_d(2,2)*vir(2))**2
           vir(1) = ( mat_car2frac_d(1,1)*vir(1) )**2
        else
           vir = (vir*pmecellinv_d)**2
        end if
        msq = vir(1) + vir(2) + vir(3)

        tpa = tpbcterm*(real(tpgridcharge)**2+aimag(tpgridcharge)**2)/msq
        vir = 2.0*tpa*(msq-(2.0*(1.0+msq*(pi/ewaldalpha_d)**2))*vir(:)) 
        if ( igrid == 1 .or. (igrid==(fftngrid_d(1)/2+1) .and. btest(igrid,0)) ) vir=vir*0.5
     end if

  end if

  if ( ipb_d > 1 ) then
     igrid = 1
     do while (igrid<=16)
        tpa = __shfl_xor(vir(1),igrid); vir(1) = vir(1) + tpa
        tpa = __shfl_xor(vir(2),igrid); vir(2) = vir(2) + tpa
        tpa = __shfl_xor(vir(3),igrid); vir(3) = vir(3) + tpa
        igrid = igrid*2
     end do
     if ( threadidx%x == 1 ) then
        tpa = atomicadd(pmevir_d(1),dble(vir(1)))
        tpa = atomicadd(pmevir_d(2),dble(vir(2)))
        tpa = atomicadd(pmevir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot_d .eqv. .false. ) return

  igrid = 1
  do while (igrid<=16)
     tpa = __shfl_xor(tppot,igrid); tppot = tppot + tpa
     igrid = igrid*2
  end do
  if ( threadidx%x == 1 ) tpa = atomicadd(erecip_d,tppot)
end subroutine

attributes(global) subroutine cudapme_potforce_recipfrc()
  integer :: iatom,i,j,k,kgrid,fftngrid(3),chargekgrid,chargejgrid(4),chargeigrid(4)
  real :: tpdev(3),spline23,spline1,spline3,dev1,dev3,dev23,dev32,tpq,xivec(3)

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > natom_d ) return
  fftngrid=fftngrid_d; ! norder = splineorder_d

  chargeigrid = chargegrid_d(:,iatom)
  chargekgrid = chargeigrid(3)
  chargejgrid(1) = chargeigrid(2)
  do i = 4, 1, -1   ! norder
     chargejgrid(i) = chargejgrid(1) + i
     if ( chargejgrid(i) < 1 ) chargejgrid(i) = chargejgrid(i) + fftngrid(2)
     chargeigrid(i) = chargeigrid(1) + i
     if ( chargeigrid(i) < 1 ) chargeigrid(i) = chargeigrid(i) + fftngrid(1)
  end do

  tpdev=0.0; xivec=chargexi_d(:,iatom)
  do k = 1, 4 ! norder
     kgrid = chargekgrid+k
     if ( kgrid < 1 ) kgrid = kgrid + fftngrid(3)
     call cudapme_potforce_spline(k,xivec(3),spline3,dev3); dev3=dev3*real(fftngrid(3))
     do j = 1, 4 ! norder
        call cudapme_potforce_spline(j,xivec(2),dev1,dev23)
        spline23=spline3*dev1; dev23=dev23*spline3*real(fftngrid(2)); dev32 = dev3*dev1
        do i = 1, 4 ! norder
           tpq=realgridcharge_d(chargeigrid(i),chargejgrid(j),kgrid)
           call cudapme_potforce_spline(i,xivec(1),spline1,dev1)
           spline1=tpq*spline1; dev1=tpq*dev1*real(fftngrid(1))
           tpdev(1) = tpdev(1) + dev1*spline23
           tpdev(2) = tpdev(2) + spline1*dev23
           tpdev(3) = tpdev(3) + spline1*dev32
        end do
     end do
  end do

  tpdev = -charge_d(iatom)*tpdev
  if ( ioct_d > 0 ) then
     tpdev(3) = dot_product(mat_car2frac_d(:,3),tpdev)
     tpdev(2) = mat_car2frac_d(1,2)*tpdev(1) + mat_car2frac_d(2,2)*tpdev(2)
     tpdev(1) = mat_car2frac_d(1,1)*tpdev(1)
  else
     tpdev = tpdev*pmecellinv_d
  end if
  dev1 = atomicadd(nowforce_d(1,iatom),dble(tpdev(1)))
  dev1 = atomicadd(nowforce_d(2,iatom),dble(tpdev(2)))
  dev1 = atomicadd(nowforce_d(3,iatom),dble(tpdev(3)))
end subroutine

! Simplfied erfc function, as used in OPENMM
! https://en.wikipedia.org/wiki/Error_function
attributes(device) subroutine erfc_function_simple(x,erfc,deriv)
  implicit none
  real,device,intent(in) :: x
  real,device,intent(out) :: erfc,deriv
  real,device :: t,exp_xsq

  t = 1.0/(1.0+0.3275911*x); exp_xsq=exp(-x*x)
  erfc = t*(0.254829592+t*(-0.284496736+t*(1.421413741+t*(-1.453152027+t*1.061405429))))*exp_xsq
  deriv = -1.128379133*exp_xsq
end subroutine

!============================================= pressure coupling

attributes(global) subroutine cudapme_npt_prepare_cell()
  select case(blockidx%x)
  case (1)
    mat_frac2car_d(1,1) = pmecell_d(1)
  case (2)
    mat_frac2car_d(1,2) = pmecell_d(2)*cosgamma_d
  case (3)
    mat_frac2car_d(2,2) = pmecell_d(2)*singamma_d
  case (4)
    mat_frac2car_d(1,3) = pmecell_d(3)*cosbeta_d
  case (5)
    mat_frac2car_d(2,3) = pmecell_d(3)*latticeterm1_d
  case (6)
    mat_frac2car_d(3,3) = pmecell_d(3)*latticeterm2_d
  case (7)
    cellvolume_d = pmecell_d(1)*pmecell_d(2)*pmecell_d(3)*singamma_d*latticeterm2_d
  case (8)
    pmecellinv_d(1) = 1.0/pmecell_d(1)
  case (9)
    pmecellinv_d(2) = 1.0/pmecell_d(2)
  case (10)
    pmecellinv_d(3) = 1.0/pmecell_d(3)
  case (11)
    mat_car2frac_d(1,1) = 1.0/pmecell_d(1)
  case (12)
    mat_car2frac_d(1,2) = -cosgamma_d/(pmecell_d(1)*singamma_d)
  case (13)
    mat_car2frac_d(1,3) = latticeterm3_d / (pmecell_d(1)*singamma_d*latticeterm2_d)
  case (14)
    mat_car2frac_d(2,2) = 1.0/(pmecell_d(2)*singamma_d)
  case (15)
    mat_car2frac_d(2,3) = -latticeterm1_d/(pmecell_d(2)*singamma_d*latticeterm2_d)
  case (16)
    mat_car2frac_d(3,3) = 1.0/(pmecell_d(3)*latticeterm2_d)
  end select
end subroutine

attributes(global) subroutine cudapme_npt_com_biomol()
  integer :: i,imol,istartatom,iatom
  real :: avgcoor(3),tpa

  avgcoor = 0.0; imol = blockidx%x; istartatom = resindex_d(molindex_d(imol)+1)
  do i=threadidx%x, natompermol_d(imol), 32
     iatom = istartatom + i
     avgcoor(:) = avgcoor(:) + mass_d(iatom)*nowcoor_d(:,iatom)
  end do
  avgcoor(:) = avgcoor(:)*molmassinv_d(imol)
  i = 1
  do while (i<=16)
     tpa = __shfl_xor(avgcoor(1),i); avgcoor(1) = avgcoor(1) + tpa
     tpa = __shfl_xor(avgcoor(2),i); avgcoor(2) = avgcoor(2) + tpa
     tpa = __shfl_xor(avgcoor(3),i); avgcoor(3) = avgcoor(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) molcom_d(:,imol) = avgcoor(:)
end subroutine

attributes(global) subroutine cudapme_npt_com_ionwat()
  integer :: imol,ires,iatom
  real :: avgcoor(3),vir(3)

  imol = (blockidx%x-1)*blockdim%x + threadidx%x + nbiomol_d; if ( imol > nmol_d ) return

  avgcoor = 0.0
  do ires=molindex_d(imol)+1,molindex_d(imol+1)
     do iatom=resindex_d(ires)+1,resindex_d(ires+1)
        avgcoor(:) = avgcoor(:) + mass_d(iatom)*nowcoor_d(:,iatom)
     end do
  end do
  molcom_d(:,imol)=avgcoor*molmassinv_d(imol)
end subroutine

attributes(global) subroutine cudapme_npt_vir_mol()
  integer :: i
  real :: vir(3),tpa

  i = (blockidx%x-1)*blockdim%x + threadidx%x; vir = 0.0
  if ( i <= natom_d ) then
     vir(:) = (molcom_d(:,atommol_d(i)) - nowcoor_d(:,i))*nowforce_d(:,i)
  end if

  i = 1
  do while (i<=16)
     tpa = __shfl_xor(vir(1),i); vir(1) = vir(1) + tpa
     tpa = __shfl_xor(vir(2),i); vir(2) = vir(2) + tpa
     tpa = __shfl_xor(vir(3),i); vir(3) = vir(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) then
     tpa = atomicadd(pmevir_d(1),dble(vir(1)))
     tpa = atomicadd(pmevir_d(2),dble(vir(2)))
     tpa = atomicadd(pmevir_d(3),dble(vir(3)))
  end if
end subroutine

subroutine cudapme_npt_isobaric_Berendsen()
  call cudapme_npt_ekin_biomol<<<nbiomol,cudathread>>>()
  call cudapme_npt_ekin_ionwat<<<nblocksolventmol,cudathread>>>()
  call cudapme_npt_compute_pressure<<<1,1>>>()

  call cudapme_npt_scale_cell<<<8,1>>>()
  call cudapme_npt_pmebcterm<<<nblockrecip,32>>>()

  call cudapme_npt_com_biomol<<<nbiomol,cudathread>>>()
  call cudapme_npt_com_ionwat<<<nblocksolventmol,cudathread>>>()

  call cudapme_npt_mol_move<<<nblockmol,cudathread>>>()
  call cudapme_npt_coupling<<<nblockatom,cudathread>>>()
end subroutine

attributes(global) subroutine cudapme_npt_ekin_biomol()
  integer :: i,imol,iatom,istartatom
  real :: tpa,avgmom(3)

  avgmom = 0.0; imol = blockidx%x; istartatom = resindex_d(molindex_d(imol)+1)
  do i=threadidx%x, natompermol_d(imol), 32
     iatom = istartatom + i
     avgmom(:) = avgmom(:) + mass_d(iatom)*( nowvel_d(:,iatom) + 0.5*dt_inv_mass_d(iatom)*nowforce_d(:,iatom) )
  end do
  i = 1
  do while (i<=16)
     tpa = __shfl_xor(avgmom(1),i); avgmom(1) = avgmom(1) + tpa
     tpa = __shfl_xor(avgmom(2),i); avgmom(2) = avgmom(2) + tpa
     tpa = __shfl_xor(avgmom(3),i); avgmom(3) = avgmom(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) then
     avgmom = avgmom**2*molmassinv_d(imol)
     imol = atomicadd(pmemolekin_d(1),dble(avgmom(1)))
     imol = atomicadd(pmemolekin_d(2),dble(avgmom(2)))
     imol = atomicadd(pmemolekin_d(3),dble(avgmom(3)))
  end if
end subroutine

attributes(global) subroutine cudapme_npt_ekin_ionwat()
  integer :: imol,ires,iatom,i
  real :: molp(3),tpa,tpekin(3)

  imol = (blockidx%x-1)*blockdim%x + threadidx%x + nbiomol_d; tpekin = 0.0
  if ( imol <= nmol_d ) then
     molp = 0.0
     do ires=molindex_d(imol)+1,molindex_d(imol+1)
        do iatom=resindex_d(ires)+1,resindex_d(ires+1)
           molp = molp + mass_d(iatom)*( nowvel_d(:,iatom) + 0.5*dt_inv_mass_d(iatom)*nowforce_d(:,iatom) )
        end do
     end do
     tpekin = molp**2*molmassinv_d(imol)
  end if

  i = 1
  do while (i<=16)
     tpa = __shfl_xor(tpekin(1),i); tpekin(1) = tpekin(1) + tpa
     tpa = __shfl_xor(tpekin(2),i); tpekin(2) = tpekin(2) + tpa
     tpa = __shfl_xor(tpekin(3),i); tpekin(3) = tpekin(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) then
     tpa = atomicadd(pmemolekin_d(1),dble(tpekin(1)))
     tpa = atomicadd(pmemolekin_d(2),dble(tpekin(2)))
     tpa = atomicadd(pmemolekin_d(3),dble(tpekin(3)))
  end if
end subroutine

attributes(global) subroutine cudapme_npt_compute_pressure()
  real :: tppressure(3)

  tppressure = pressconvert*(pmemolekin_d+pmevir_d)/cellvolume_d
  realpressure_d = sum(tppressure)/3.0
  if ( ipb_d == 2 ) then
     nptcoeff_d = (1.0 - nptfactor_d*(pressure0_d - realpressure_d))**(0.333333333)
  else if ( ipb_d == 3 ) then
     nptcoeff_d = (1.0 - nptfactor_d*(pressure0_d - tppressure))**(0.333333333)
  end if
  pmecell_d = pmecell_d*nptcoeff_d
end subroutine

attributes(global) subroutine cudapme_npt_scale_cell()
  real :: nptcoeff(3)
  nptcoeff = pmecell_d/inipmecell_d
  select case (blockidx%x )
  case (1); cellvolume_d = inicellvolume_d*product(nptcoeff)
  case (2); pmecellinv_d = 1.0/pmecell_d
  case (3); mat_frac2car_d(1,:) = inimat_frac2car_d(1,:)*nptcoeff
  case (4); mat_frac2car_d(2,:) = inimat_frac2car_d(2,:)*nptcoeff
  case (5); mat_frac2car_d(3,:) = inimat_frac2car_d(3,:)*nptcoeff
  Case (6); 
     if ( ioct_d > 0 ) lastmat_car2frac_d(:,1) = mat_car2frac_d(:,1)
     mat_car2frac_d(:,1) = inimat_car2frac_d(:,1)/nptcoeff
  case (7); 
     if ( ioct_d > 0 ) lastmat_car2frac_d(:,2) = mat_car2frac_d(:,2)
     mat_car2frac_d(:,2) = inimat_car2frac_d(:,2)/nptcoeff
  case (8); 
     if ( ioct_d > 0 ) lastmat_car2frac_d(:,3) = mat_car2frac_d(:,3)
     mat_car2frac_d(:,3) = inimat_car2frac_d(:,3)/nptcoeff
  end select
end subroutine

attributes(global) subroutine cudapme_npt_pmebcterm()
  integer :: igrid,jgrid,kgrid,i,ihalf
  real*8 :: mterm(3),msq,expcoef,pivol2

  pivol2 = 2.0*pi_d*cellvolume_d; expcoef = (pi_d/ewaldalpha_d)**2

  igrid = (blockidx%x-1)*blockdim%x+threadidx%x
  if ( igrid <= fftnhalftotgrid_d ) then

     igrid = igrid + 1    ! skip the first grid (igrid=1,jgrid=1,kgrid=1)
     ihalf = fftngrid_d(1)/2+1; i = ihalf*fftngrid_d(2)
     kgrid = (igrid-1)/i + 1; i = igrid - (kgrid-1)*i
     jgrid = (i-1)/ihalf + 1
     igrid = i - (jgrid-1)*ihalf

     mterm(1) = pmemterm_d(1,igrid); mterm(2) = pmemterm_d(2,jgrid); mterm(3) = pmemterm_d(3,kgrid)
     if ( ioct_d > 0 ) then
        mterm(3) = dot_product(mat_car2frac_d(:,3),mterm)**2
        mterm(2) = (mat_car2frac_d(1,2)*mterm(1) + mat_car2frac_d(2,2)*mterm(2))**2
        mterm(1) = (mat_car2frac_d(1,1)*mterm(1))**2
     else
        mterm = (mterm*pmecellinv_d)**2
     end if
     msq = mterm(1) + mterm(2) + mterm(3)
     pmebcterm_d(igrid,jgrid,kgrid) = ewaldbmsq_d(1,igrid)*ewaldbmsq_d(2,jgrid)*ewaldbmsq_d(3,kgrid)*exp(-expcoef*msq)/(msq*pivol2)

  end if
end subroutine

attributes(global) subroutine cudapme_npt_mol_move()
  integer :: imol
  real :: tpvec(3),tpcom(3)

  imol = (blockidx%x-1)*blockdim%x + threadidx%x; if ( imol > nmol_d ) return
  tpcom = molcom_d(1:3,imol)
  if ( ioct_d > 0 ) then
     tpvec(1) = tpcom(3)*lastmat_car2frac_d(3,3)*mat_frac2car_d(1,3)
     tpvec(2) = tpcom(3)*lastmat_car2frac_d(3,3)*mat_frac2car_d(2,3)
     tpvec(3) = tpcom(3)*lastmat_car2frac_d(3,3)*mat_frac2car_d(3,3)
     tpvec(1) = tpcom(2)*lastmat_car2frac_d(2,2)*mat_frac2car_d(1,2)
     tpvec(2) = tpcom(2)*lastmat_car2frac_d(2,2)*mat_frac2car_d(2,2)
     tpvec(1) = tpcom(1)*lastmat_car2frac_d(1,1)*mat_frac2car_d(1,1)
  else
     tpvec = nptcoeff_d*tpcom
  end if
  molmove_d(:,imol) = tpvec - tpcom
  molcom_d(:,imol) = tpvec
end subroutine

attributes(global) subroutine cudapme_npt_coupling()
  integer :: iatom
  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > natom_d ) return
  nowcoor_d(:,iatom) = nowcoor_d(:,iatom) + molmove_d(:,atommol_d(iatom))
end subroutine

end module
