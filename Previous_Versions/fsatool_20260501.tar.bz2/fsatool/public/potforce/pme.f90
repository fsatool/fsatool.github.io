! Reference Paper
!
! [1] U. Essmann, Lalith Perera, and Max L. Berkowitz
!     A Smooth Particle Mesh Ewald Method.
!     J. Chem. Phys. 1995. 103: 8577-8593

module pme
  use ambertop; use pubmod; use ISO_C_BINDING
  implicit none

  integer,parameter :: splineorder=4,iadgrid=1
  integer :: fftmaxngrid,fftngrid(3),bimaxnexc,pmenbox,pmenboxvec(3),pmemaxnnl
  real*8 :: inipmecell(3),pmecellinv(3),pmesavecell(3),mat_frac2car(3,3),mat_car2frac(3,3)
  real*8 :: inimat_frac2car(3,3),inimat_car2frac(3,3)
  real*8 :: pmefftn(3),pmevir(3),inipmevir(3),pmeekin(3),inicellvolume,inievdwcorr,realpressure,ewaldalpha
  logical :: ifactivebox

  type(C_PTR) :: plan_forward,plan_backward

  real*8 :: skin,hfskinsq,fullcutsq,settlewatparm(6)

  integer,dimension(:),allocatable :: atombox,pmeboxtypeindex,pmeboxnl

  real*8 :: pmepbcrd(3,18)

  integer,dimension(:),allocatable :: boxatom,boxatomindex
  integer,dimension(:),allocatable :: bilastnexc,binexcludedatoms,biexcludedatomlist
  integer,dimension(:),allocatable :: pmeboxnlindex,boxnlboxindex,boxnlboxes,boxnlboxcsidx
  integer,dimension(:,:),allocatable :: pmepbidx,chargegrid

  real*8,dimension(:),allocatable :: pmeboxcharge
  real*8,dimension(:,:),allocatable :: ewaldbmsq,pmemterm
  real*8,dimension(:,:),allocatable :: pmeboxcoor,pmeboxfrc,pmesavecoor,pmesaveboxcoor,pmeunitcoor
  real*8,dimension(:,:),allocatable :: pmeenebasic,pmefrcbasic,pmeenefarbasic,pmefrcfarbasic
  real*8,dimension(:,:,:),allocatable :: pmebcterm,realgridcharge,basisfunc,basisdev

  complex(kind=8),dimension(:,:,:),allocatable :: gridcharge
  logical,dimension(:),allocatable :: pmevdwskip

! variables for LJ-PME.
  integer :: ljngrid(3)
  real*8 :: ljalpha,lj6dir,lj6excl,eljrecip,eljself

contains

subroutine pme_initialize()
  integer :: i
  real*8 :: tpbound(2,3)

  ! convert the box angles from degrees to radians
  cellalpha=cellalpha*pi/180d0; cellbeta=cellbeta*pi/180d0; cellgamma=cellgamma*pi/180d0

  ! set the transform matrix between Cartesian coordinates and fractional coordinates in periodic box
  call pme_prepare_cell()

  ! set a proper parameter of ewaldalpha for the smeared charge distributions
  call pme_set_ewaldalpha()

  ! prepare for the calculation of the direct space sum
  call pme_prepare_direct()

  ! prepare for the calculation of the reciprocal space sum
  call pme_prepare_recip()

  call pubmod_molecule_com()

  call pme_prepare_settlewatparm()

  do i=1,3
     tpbound(1,i) = minval(nowcoor(i,:)); tpbound(2,i) = maxval(nowcoor(i,:))
  end do

  if ( procid == 0 ) then
     write(iosiminfo,"(/,20x,a)") "Simulation Model"
     write(iosiminfo,"(a)") "============================================================="
     if ( ipb == 1 .and. ioct == 0 ) then
        write(iosiminfo,"(a)") "NVT simulation in a rectangular periodic box"
     else if ( ipb == 1 .and. ioct > 0 ) then
        write(iosiminfo,"(a)")"NVT simulation in a non-rectangular periodic box"
     else if ( ipb > 1 .and. ioct == 0 ) then
        write(iosiminfo,"(a)") "NPT simulation in a rectangular periodic box"
     else if ( ipb > 1 .and. ioct > 0 ) then
        write(iosiminfo,"(a)")"NPT simulation in a non-rectangular periodic box"
     end if
     write(iosiminfo,"(a,1x,2f8.3,4x,2f8.3,4x,2f8.3)") "Coordinate Borders ",tpbound(1:2,1),tpbound(1:2,2),tpbound(1:2,3)
     write(iosiminfo,"(a,3f8.3,5x,a,3f8.3)") "Cell length ",pmecell(1),pmecell(2),pmecell(3),"Cell angle ",cellalpha*180d0/pi,cellbeta*180d0/pi,cellgamma*180d0/pi
     write(iosiminfo,"(a,f8.3,9x,a,f14.3)") "Ewald Alpha ",ewaldalpha,"Distance cutoff ",discut
     write(iosiminfo,"(a,3i5)") "Boxes in direct space     ",pmenboxvec
     write(iosiminfo,"(a,3i5)") "Grids in reciprocal space ",fftngrid(:)

     if ( ewaldtol > 0d0 ) write(iosiminfo,"(a,e8.2e2)") "Ewald tolerance             ",ewaldtol
     if ( iljpme > 0 ) write(iosiminfo,"(a)")      "Applying LJ-PME           "

     if ( ioct > 0 .and. ipb == 3 ) call errormsg("ipb can not be 3 for non-rectangular periodic box")
  end if
end subroutine

!=================================== general preparations

! set a proper parameter of ewaldalpha for the smeared charges
subroutine pme_set_ewaldalpha()
  integer :: icycle
  real*8 :: etol,tpalpha,alphalow,alphaup,erfcval

  if ( ewaldtol == 0d0 ) then

     ! locate the point where erfc(x) is smaller than etol
     etol = 1d-5; alphalow = 0d0; alphaup = 1d0
     call erfc_function(alphaup,erfcval)
     do while ( erfcval >= etol )
        alphaup = 2d0*alphaup
        call erfc_function(alphaup,erfcval)
     end do
   
     ! the energy component in direct space, Eq.(2.3) in Ref.1, has a factor of erfc(alpha*r/r)
     ! determine the alpha to satisfy the condition erfc(alpha*r)/r <= etol for r = discut
     do icycle=1,50
        tpalpha = (alphalow + alphaup)/2.d0
        call erfc_function(tpalpha*discut,erfcval)  ! erfc(discut*r)
        if ( erfcval/discut > etol ) then
           alphalow = tpalpha
        else
           alphaup = tpalpha
        end if
     end do
     ewaldalpha = tpalpha
   
  else

     ! presented in OpenMM
     ewaldalpha = sqrt(-log(2d0*ewaldtol))/discut
   
  end if

  if ( iljpme == 1 ) then
     ljalpha = ewaldalpha; eljself = sum(vdwlambda(:)**2)*ljalpha**6d0/12d0
  end if

  ! self energy, Ref.1, Page 8578, second term in Eq.(2.5)
  eself = -sum(charge(:)**2)*ewaldalpha/sqrt(pi)
end subroutine

subroutine pme_prepare_eself()
  integer :: iatom
  eself = 0d0
  do iatom = 1, natom
     eself = eself + charge(iatom)**2
  end do
  eself = -eself*ewaldalpha/sqrt(pi)
end subroutine

! set the transform matrix between Cartesian coordinates and fractional coordinates in periodic box
subroutine pme_prepare_cell(nptcoeff)
  real*8,intent(in),optional :: nptcoeff(3)
  integer :: i,j,k,l,iaxis
  real*8 :: tpterm,ijkvec(3),tpterm2,tpcut,insradius

  pmesavecell = pmecell
  if ( present(nptcoeff) ) then
     pmecell = pmecell*nptcoeff; pmecellinv = 1d0/pmecell
     do i=1,18
        pmepbcrd(:,i) = pmepbcrd(:,i)*nptcoeff
     end do
     do i=1,3
        mat_frac2car(i,:) = inimat_frac2car(i,:)*pmecell/inipmecell
        mat_car2frac(:,i) = inimat_car2frac(:,i)*inipmecell/pmecell
     end do
     cellvolume = inicellvolume*product(pmecell)/product(inipmecell)

     insradius = 1000.0d0
     do i=1,3
        tpcut = 1.0d0/sqrt( dot_product(mat_car2frac(i,:),mat_car2frac(i,:) ) )
        insradius = min(insradius,tpcut)
     end do
     insradius = 0.5d0*insradius

     if ( procid == 0 ) then
        if (discut+skin>=insradius) call errormsg("extended cutoff distance (discut+skin) must be smaller than the radius of inscribed sphere",real1=insradius, real2=discut, real3=discut+skin)
     end if
     return
  end if

  inipmecell = pmecell; pmecellinv(:) = 1.d0/pmecell

  ! Duncan McKie and Christine McKie. Essentials of Crystallography. 1986
  tpterm = ( dcos(cellalpha) - dcos(cellbeta)*dcos(cellgamma) )/dsin(cellgamma)
  tpterm2 = pmecell(3)*dsqrt(dsin(cellbeta)**2 - tpterm**2)
  mat_frac2car(1,:)=(/pmecell(1), 0.0d0, 0.0d0/)
  mat_frac2car(2,:)=(/pmecell(2)*dcos(cellgamma), pmecell(2)*dsin(cellgamma), 0d0/)
  mat_frac2car(3,:)=(/pmecell(3)*dcos(cellbeta), pmecell(3)*tpterm, tpterm2/)
  cellvolume = mat_frac2car(1,1)*mat_frac2car(2,2)*mat_frac2car(3,3)
  if ( inicellvolume == 0d0) inicellvolume=cellvolume
  mat_frac2car = transpose(mat_frac2car)

  mat_car2frac = mat_frac2car; call inversematrix(3,mat_car2frac)

  inimat_car2frac=mat_car2frac; inimat_frac2car = mat_frac2car

  ! set the translation vector between the periodic boxes at the bottom two layers (3*3*2)
  ! if one of ibox's neighbor, jbox, is in the left periodic box to the center box (ibox),
  ! then, in the calculations of the interactions between the atoms in the two boxes, all the atomic coordinates in the ibox, icoor, should be moved to icoor - pmecell
  ! so, actually, we move the atoms in ibox, not jbox
  do k = 1,2; do j = 1,3; do i = 1,3
     l = (k-1)*9+(j-1)*3+i; ijkvec = dble((/i,j,k/))-2.d0
     if ( ioct > 0 ) then
        pmepbcrd(1,l) = - dot_product(ijkvec,mat_frac2car(1,:))
        pmepbcrd(2,l) = - dot_product(ijkvec,mat_frac2car(2,:))
        pmepbcrd(3,l) = - dot_product(ijkvec,mat_frac2car(3,:))
     else
        pmepbcrd(:,l) = - ijkvec(:)*pmecell(:)
     end if
  end do; end do; end do

end subroutine

subroutine pme_ljpme_gfunction(x,gx,dgx)
  implicit none
  real*8,intent(in) :: x
  real*8,intent(out) :: gx
  real*8,intent(out),optional :: dgx
  real*8 :: xsq
 
  xsq = x*x; gx = exp(-xsq)*(1d0+xsq+xsq*xsq/2d0); dgx = -xsq*xsq*x*exp(-xsq)
end subroutine

subroutine pme_ljpme_ffunction(x,fx,dfx)
  implicit none
  real*8,intent(in) :: x
  real*8,intent(out) :: fx
  real*8,intent(out),optional :: dfx
  real*8 :: xsq,verfc
 
  xsq = x*x; call erfc_function(x,verfc)
  fx = ((1-2d0*xsq)*exp(-xsq)+2d0*x*xsq*sqrt(pi)*verfc)/3d0
end subroutine

!=================================== prepare for the calculation of the direct space sum

subroutine pme_prepare_direct()
  integer :: i,l

  ! set a marker for non-interaction VDW pairs
  allocate(pmevdwskip(nvdwtype*nvdwtype)); pmevdwskip = .false.
  do i = 1,nvdwtype*nvdwtype
     l = nonbondedparmindex(i)
     if ( (abs(vdwacoef(l)) < 1.d-10) .and. (abs(vdwbcoef(l)) < 1.d-10) ) pmevdwskip(i) = .true.
  end do

  ! build a bidirectional excluded atom list
  call pme_prepare_biexcludedatomlist()

  ! prepare Taylor series expansions for erfc function
  call pme_prepare_enefrc_basic()

  ! allocate the arrays for boxes in the periodic box  
  call pme_prepare_box()

  ! calculate the energy correction term of the van der Waals interaction
  call pme_calculate_vdwcorr()
end subroutine

! prepare bidirectional excluded atom list
subroutine pme_prepare_biexcludedatomlist()
  integer :: biidx(natom),tpnexc,iatom,jatom,j

  ! binexcludedatoms(iatom) : number of excluded atoms for iatom (the maximum is bimaxnexc)
  ! [bilastnexc(iatom)+1 : bilastnexc(iatom+1)] : index range in the bidirectional excluded atom list for iatom
  ! biexcludedatomlist : full bidirectional excluded atom list
  allocate(bilastnexc(natom+1),binexcludedatoms(natom))

  ! first, copy the forward directional excluded atom list to the bidirectional list
  binexcludedatoms(:) = nexcludedatoms(:); tpnexc = 0

  ! second, count and record the excluded atom number of jatom in the reverse direction
  do iatom = 1,natom
     do j = tpnexc+1,tpnexc+nexcludedatoms(iatom)
        jatom = excludedatomlist(j)
        if ( jatom .ne. 0 ) then
           binexcludedatoms(jatom) = binexcludedatoms(jatom) + 1
        end if
     end do
     tpnexc = tpnexc + nexcludedatoms(iatom)
  end do
  allocate(biexcludedatomlist(2*tpnexc))   ! estimate the array size of the bidirectional list

  ! third, record the first position, biidx(iatom), for iatom in the bidirectional list
  bilastnexc(1) = 0
  do iatom = 1,natom
     biidx(iatom) = bilastnexc(iatom) + 1
     bilastnexc(iatom+1) = bilastnexc(iatom) + binexcludedatoms(iatom)
  end do

  ! fourth, insert the atoms in the forward directional list to the bidirectional list
  tpnexc = 0
  do iatom = 1,natom
     do j = tpnexc+1,tpnexc+nexcludedatoms(iatom)
        jatom = excludedatomlist(j)    ! excluded pair iatom-jatom
        ! copy jatom to iatom's excluded list
        biexcludedatomlist(biidx(iatom)) = jatom; biidx(iatom) = biidx(iatom) + 1
        if ( jatom == 0 ) cycle
        ! copy iatom to jatom's excluded list
        biexcludedatomlist(biidx(jatom)) = iatom; biidx(jatom) = biidx(jatom) + 1
     end do
     tpnexc = tpnexc + nexcludedatoms(iatom)
  end do

  ! fifth, get the maximum excluded atom number of a single atom
  bimaxnexc = 0
  do iatom=1, natom
     j = bilastnexc(iatom+1) - bilastnexc(iatom)
     if ( j > bimaxnexc )  bimaxnexc = j
  end do
end subroutine

! build a three-order Taylor expansion for erfc function on a set of evenly distributed grid points
subroutine pme_prepare_enefrc_basic()
  real*8 :: nowx,nextatomx,nowalphax,nextatomalphax,nowerfc,nextatomerfc,nowdev,nextatomdev,dx,tp
  real*8 :: nowxsq,startxsq,nextatomxsq,dxsq,sqdis,xsqdis
  integer :: xpos,i,tpimax

  ! Taylor series on the grids distributed in the range [0:10]
  allocate(pmeenebasic(4,1000)); pmeenebasic = 0.d0
  allocate(pmefrcbasic(4,1000)); pmefrcbasic = 0.d0
  dx = 0.01d0; nowx = 0.d0; nowalphax = ewaldalpha*nowx
  call erfc_function(nowalphax,nowerfc,nowdev)
  do i = 1,1000
     nextatomx = dble(i) * dx; nextatomalphax = ewaldalpha*nextatomx
     call erfc_function(nextatomalphax,nextatomerfc,nextatomdev)

     pmeenebasic(1,i) = nowerfc
     pmeenebasic(2,i) = -2d0*ewaldalpha*dexp(-nowalphax**2)/sqrt(pi)
     pmeenebasic(3,i) = 4d0*ewaldalpha**3*nowx*dexp(-nowalphax**2)/sqrt(pi)/2d0
     pmeenebasic(4,i) = (nextatomerfc-pmeenebasic(1,i))/dx**3 - pmeenebasic(2,i)/dx**2 - pmeenebasic(3,i)/dx

     pmefrcbasic(1,i) = 2d0*nowalphax*dexp(-nowalphax**2)/sqrt(pi)+nowerfc
     pmefrcbasic(2,i) = -4d0*ewaldalpha**3*nowx**2*dexp(-nowalphax**2)/sqrt(pi)
     pmefrcbasic(3,i) = 8d0*ewaldalpha**3*nowx*(nowalphax**2-1d0)*dexp(-nowalphax**2)/sqrt(pi)/2d0
     tp = 2d0*nextatomalphax*dexp(-nextatomalphax**2)/sqrt(pi)+nextatomerfc
     pmefrcbasic(4,i) = (tp-pmefrcbasic(1,i))/dx**3 - pmefrcbasic(2,i)/dx**2 - pmefrcbasic(3,i)/dx

     nowalphax = nextatomalphax; nowx = nextatomx; nowerfc = nextatomerfc; nowdev = nextatomdev
  end do

  ! Taylor series on the grids distributed in the range [sqrt(7):discut]
  startxsq=7.0; dxsq=0.02d0; tpimax = discut**2/dxsq + 1  
  allocate(pmeenefarbasic(4,tpimax)); pmeenefarbasic = 0.0d0
  allocate(pmefrcfarbasic(4,tpimax)); pmefrcfarbasic = 0.0d0
  nowxsq = startxsq; nowalphax = ewaldalpha*sqrt(nowxsq)
  call erfc_function(nowalphax,nowerfc,nowdev)
  do i = startxsq/dxsq+1,tpimax
     nextatomxsq = dble(i)*dxsq; nextatomalphax = ewaldalpha*sqrt(nextatomxsq)
     call erfc_function(nextatomalphax,nextatomerfc,nextatomdev)
     pmeenefarbasic(1,i) = nowerfc/sqrt(nowxsq)
     pmeenefarbasic(2,i) = -ewaldalpha*dexp(-ewaldalpha**2*nowxsq)/(sqrt(pi)*nowxsq) - nowerfc/(2d0*nowxsq**1.5d0)
     pmeenefarbasic(3,i) = (ewaldalpha**3*dexp(-ewaldalpha**2*nowxsq)/(sqrt(pi)*nowxsq) + &
                 3d0*ewaldalpha*dexp(-ewaldalpha**2*nowxsq)/(2d0*sqrt(pi)*nowxsq**2)+&
                 3d0*nowerfc/(4d0*nowxsq**2.5d0))/2d0
     pmeenefarbasic(4,i) = (nextatomerfc/sqrt(nextatomxsq)-pmeenefarbasic(1,i))/dxsq**3 - pmeenefarbasic(2,i)/dxsq**2 - pmeenefarbasic(3,i)/dxsq

     pmefrcfarbasic(1,i) = 2d0*ewaldalpha*dexp(-ewaldalpha**2*nowxsq)/sqrt(pi) + pmeenefarbasic(1,i)
     pmefrcfarbasic(2,i) = -2d0*ewaldalpha**3*dexp(-ewaldalpha**2*nowxsq)/sqrt(pi) + pmeenefarbasic(2,i)     
     pmefrcfarbasic(3,i) = 2d0*ewaldalpha**5*dexp(-ewaldalpha**2*nowxsq)/sqrt(pi)/2d0 + pmeenefarbasic(3,i)     
     pmefrcfarbasic(4,i) = (2d0*ewaldalpha*dexp(-ewaldalpha**2*nextatomxsq)/sqrt(pi) + nextatomerfc/sqrt(nextatomxsq) -&
     pmefrcfarbasic(1,i))/dxsq**3 - pmefrcfarbasic(2,i)/dxsq**2 - pmefrcfarbasic(3,i)/dxsq

     nowalphax = nextatomalphax; nowxsq = nextatomxsq; nowerfc = nextatomerfc; nowdev = nextatomdev
  end do
end subroutine

subroutine pme_prepare_box()
  real*8 :: tpdis,insradius
  integer :: i,j,k,l
  integer :: ijstride,tpadnum,ibox,jbox,maxnbox,csidx,i1,i2,i3,j1,j2,j3,i1l,i1r,i2l,i2r,i3l,i3r
  integer,dimension(:,:),allocatable :: pmeboxidx

  skin = 1.0d0; hfskinsq = skin*skin/4.0d0; fullcutsq = (discut+skin)**2
  if ( ioct > 0 ) then
     insradius = 1000.0d0
     do i=1,3
        tpdis = 1.0d0/sqrt( dot_product(mat_car2frac(i,:),mat_car2frac(i,:) ) )
        insradius = min(insradius,tpdis)
        pmenboxvec(i) = max(int(tpdis/((discut+skin)/dble(iadgrid+1)+1d-4)),1)
     end do
  else
     insradius = minval(pmecell)
     pmenboxvec(1:3) = max(int(pmecell(1:3)/((discut+skin)/dble(iadgrid+1)+1d-4)),1)
  end if

  insradius = 0.5d0*insradius  
  if (discut+skin>=insradius) call errormsg("cutoff must be smaller than the radius of inscribed sphere",real1=insradius, real2=discut+skin)

  pmenbox = pmenboxvec(1)*pmenboxvec(2)*pmenboxvec(3)
  allocate(boxatom(natom),boxatomindex(pmenbox+1))
  boxatom = 0; boxatomindex = 0

  allocate(pmeboxcharge(natom),pmeboxtypeindex(natom))
  pmeboxcharge = 0.d0; pmeboxtypeindex = 0

  pmemaxnnl=natom*int( 1.1d0*(4d0/3d0)*pi*fullcutsq**1.5*dble(natom)/cellvolume )
  allocate(pmeboxnl(pmemaxnnl),pmeboxnlindex(natom+1))
  pmeboxnl = 0; pmeboxnlindex = 0

  ! set up box info in the periodic box
  ! for example, there are 2*3*4=24 boxes (pmenboxvec(1)=2,pmenboxvec(2)=3,pmenboxvec(3)=4)
  ! pmepbidx(1,:) =  1 1       2 2        3  3
  ! pmepbidx(2,:) =  0 0 0     3 3 3      6  6  6
  ! pmepbidx(3,:) =  0 0 0 0   9 9 9 9    18 18 18 18
  ! pmeboxidx(1,:) = 1 2       1 2        1  2
  ! pmeboxidx(2,:) = 1 2 3     1 2 3      1  2  3
  ! pmeboxidx(3,:) = 1 2 3 4   1 2 3 4    1  2  3  4
  ! each one of the 24 boxes, ibox, has many neighbor boxes. some of them are in the central periodic box and others are the box images in the neighbor periodic box.
  ! for each neighbor jbox of ibox
  ! pmepbidx records the periodic box position of jbox (ranges from 1 to 27)
  ! pmeboxidx records the actual index of jbox (ranges from 1 to 24)
  ! for example, pmepbidx(1,j1)+pmepbidx(2,j2)+pmepbidx(3,j3)=1+0+0=1, indicates that jbox is the periodic box at the bottom-left corner
  ! pmepbidx(1,j1)+pmepbidx(2,j2)+pmepbidx(3,j3)=3+6+18=27, indicates that jbox is the periodic box at the upper-right corner
  ! note that we only need to consider two layers of periodic boxes at the bottom (including the one at the center). so sum(pmepbidx(1:3)) ranges from 1 to 18.

  maxnbox = max(pmenboxvec(1),pmenboxvec(2),pmenboxvec(3))
  allocate(pmepbidx(3,3*maxnbox),pmeboxidx(3,3*maxnbox))
  pmepbidx = 0; pmeboxidx = 0
  do i = 1,3*pmenboxvec(1)
     pmepbidx(1,i) = int((i-1)/pmenboxvec(1)) + 1; pmeboxidx(1,i) = mod(i-1,pmenboxvec(1)) + 1
  end do
  do i = 1,3*pmenboxvec(2)
     pmepbidx(2,i) = int((i-1)/pmenboxvec(2))*3; pmeboxidx(2,i) = mod(i-1,pmenboxvec(2)) + 1
  end do
  do i = 1,3*pmenboxvec(3)
     pmepbidx(3,i) = int((i-1)/pmenboxvec(3))*9; pmeboxidx(3,i) = mod(i-1,pmenboxvec(3)) + 1
  end do

  allocate(atombox(natom),pmeboxcoor(3,natom),pmeboxfrc(3,natom),pmesavecoor(3,natom),pmesaveboxcoor(3,natom),pmeunitcoor(3,natom))
  atombox = 0; pmeboxcoor = 0.d0; pmesaveboxcoor = 0.d0; pmeboxfrc = 0.d0; pmeunitcoor = 0d0
  ijstride = pmenboxvec(1)*pmenboxvec(2); tpadnum = iadgrid + 1
  k = ( (2*tpadnum+1)**3 - 1 )*pmenbox/2

  ! build the neighbour box list, each box has 124 neighbour boxes, because of duplication, only 62 of them are required for consideration
  allocate(boxnlboxindex(pmenbox+1),boxnlboxcsidx(k)); boxnlboxindex=0; boxnlboxcsidx=0
  allocate(boxnlboxes(k)); boxnlboxes=0; k = 0
  do i3=1,pmenboxvec(3); do i2=1,pmenboxvec(2); do i1=1,pmenboxvec(1)
     ibox = i1 + (i2-1)*pmenboxvec(1) + (i3-1)*ijstride
     ! actually, ibox's neighbor box in x-axis starts from i1-2 and ends at i1+2 ( totally 125 boxes in three directions)
     ! however, we add pmenboxvec(1) to the index to make it an positive integer in all cases
     i1l = i1 - tpadnum + pmenboxvec(1); i1r = i1 + tpadnum + pmenboxvec(1)
     i2l = i2 - tpadnum + pmenboxvec(2); i2r = i2 + tpadnum + pmenboxvec(2)
     i3l = i3 - tpadnum + pmenboxvec(3); i3r = i3 + pmenboxvec(3)
     do j3=i3l,i3r; do j2=i2l,i2r; do j1=i1l,i1r
        ! use pmeboxidx to get the original jbox's index in central periodic box
        jbox = pmeboxidx(1,j1) + (pmeboxidx(2,j2)-1)*pmenboxvec(1) + (pmeboxidx(3,j3)-1)*ijstride
        ! periodic box index
        csidx = pmepbidx(1,j1)+pmepbidx(2,j2)+pmepbidx(3,j3)
        if ( jbox .eq. ibox ) goto 1002
        k = k + 1; boxnlboxes(k) = jbox; boxnlboxcsidx(k)=csidx
     end do; end do; end do
1002 continue
     boxnlboxindex(ibox+1) = k
  end do; end do; end do
  deallocate(pmeboxidx)

end subroutine

! See: https://gomc-wsu.github.io/Manual/long_range_correction.html
! Integration of van der Waals potential in the space out of the cut-off distance
! Evdwcorr = Sigma_ij(V_ij) = Sigma_typeij( 0.5*num(typei)*num(typej)/V *
!                                             Integral_rcut_to_infinite(4*pi*r^2*Evdw(i,j)*dr)
! Evdw(i,j) = A_ij/r^12 - B_ij/r^6   ! here the repulsive term is omitted out of cut-off distance
! Virial = Sigma_ij( r_ij * F_ij) = Sigma_ij( r_ij * -Grad(V_ij) )     
!                                 = 6.0 * Evdwcorr
! On each axis, the virial is 2.0 * Evdwcorr
subroutine pme_calculate_vdwcorr()
  integer :: itype,jtype,index,i,tpvdwatom(nvdwtype)
  real*8 :: tpsum

  evdwcorr = 0.d0; tpvdwatom = 0
  do i = 1, natom
     itype = typeindex(i); tpvdwatom(itype) = tpvdwatom(itype) + 1
  end do
  do itype = 1, nvdwtype
     tpsum = 0d0
     do jtype = 1,nvdwtype
        index = nonbondedparmindex(nvdwtype*(itype-1) + jtype)
        tpsum = tpsum + tpvdwatom(jtype)*vdwbcoef(index)
     end do
     evdwcorr = evdwcorr + tpsum*tpvdwatom(itype)
  end do
  
  evdwcorr = (-2.d0*pi/(3.d0*cellvolume*discut**3.d0))*evdwcorr
  inievdwcorr = evdwcorr

  if ( ipb > 1 ) inipmevir(:) = 2.d0*inievdwcorr
end subroutine

!=================================== prepare for the calculation of the reciprocal space sum

subroutine pme_prepare_recip()
  include 'fftw3.f03'
  integer :: i,j,tpvec(3),tpgridnum

  ! as required in the document of NVIDIA Toolkit 4.2 CUFFT Library
  ! the FFT grid number should be an integral multiple of 2,3 or 5
  do i = 1,3
     if ( ewaldtol == 0d0 ) then
        fftngrid(i) = ceiling(pmecell(i))
     else
        ! presented in OpenMM manual
        fftngrid(i) = ceiling(2d0*ewaldalpha*pmecell(i)/(3d0*(ewaldtol)**0.2d0))
     end if
     do
        tpgridnum = fftngrid(i)
        do while ( mod(tpgridnum,2) == 0 )
           tpgridnum = tpgridnum/2
        end do
        if ( tpgridnum == 1 ) exit
        do while ( mod(tpgridnum,3) == 0 )
           tpgridnum = tpgridnum/3
        end do
        if ( tpgridnum == 1 ) exit
        do while ( mod(tpgridnum,5) == 0 )
           tpgridnum = tpgridnum/5
        end do
        if ( tpgridnum == 1 ) exit
        fftngrid(i) = fftngrid(i) + 1
     end do
  end do
  if ( iljpme == 1 ) fftngrid = fftngrid*3
  allocate(realgridcharge(fftngrid(1),fftngrid(2),fftngrid(3))); realgridcharge=0d0
  allocate(gridcharge(fftngrid(1)/2+1,fftngrid(2),fftngrid(3))); gridcharge=cmplx(0.d0,0.d0,8)
  allocate(basisfunc(splineorder,3,natom),basisdev(splineorder,3,natom)); basisfunc=0d0; basisdev=0d0
  fftmaxngrid = max(fftngrid(1),fftngrid(2),fftngrid(3))
  allocate(ewaldbmsq(3,fftmaxngrid)); ewaldbmsq=0d0
  allocate(pmemterm(3,fftmaxngrid)); pmemterm=0d0
  allocate(pmebcterm(fftngrid(1)/2+1,fftngrid(2),fftngrid(3))); pmebcterm = 0.d0
  allocate(chargegrid(3,natom)); chargegrid=0d0

  ! prepare the FFTW plan
  call dfftw_plan_dft_r2c_3d(plan_forward,fftngrid(1),fftngrid(2),fftngrid(3),realgridcharge,gridcharge,FFTW_ESTIMATE)
  call dfftw_plan_dft_c2r_3d(plan_backward,fftngrid(1),fftngrid(2),fftngrid(3),gridcharge,realgridcharge,FFTW_ESTIMATE)

  call pme_prepare_bmsq()
  call pme_prepare_bcterm()
end subroutine

! prepare bi(mi) in Eq.(4.4), Ref.1
subroutine pme_prepare_bmsq()
  integer :: im,iaxis,i,j,k,igrid,halfngrid(3),ipos
  real*8 :: basisfunc(splineorder),basisdev(splineorder)
  real*8 :: realpart,imagpart,tpvalue,eps,factor
  real*8 :: bmsqcoef(fftmaxngrid,3),up,down,phase

  ! transform FFT grids from [1,N] to [-N/2, N/2]
  halfngrid(1:3) = (fftngrid(1:3)+1)/2; bmsqcoef = 1.0d0
  do i = 1,3
     do j = 1,fftngrid(i)
        if ( j > halfngrid(i) ) then
           pmemterm(i,j) = dble(j-1-fftngrid(i))
        else
           pmemterm(i,j) = dble(j-1)
        end if
     end do
  end do

  ! get the B-spline basis function values and derivatives on the control points where x=0
  call getbspline(0.d0,splineorder,basisfunc,basisdev)

  eps = 1.0d-7
  do iaxis=1,3
     factor = 2.0d0*pi/dble(fftngrid(iaxis))
     do im = 1, fftngrid(iaxis)
        realpart = 0.0d0; imagpart = 0.0d0
        do k = 1, splineorder
           tpvalue = factor*dble((im-1)*(k-1))
           ! Mn(k) * cos(2*pi*mi*k/N)
           realpart = realpart + basisfunc(k)*cos(tpvalue)
           ! Mn(k) * sin(2*pi*mi*k/N)
           imagpart = imagpart + basisfunc(k)*sin(tpvalue)
        end do
        ! |bi(mi)|^-2, Ref.1, Eq(4.4), the numerator has been moved to the denominator, and reset j=n-j
        ewaldbmsq(iaxis,im) = realpart**2 + imagpart**2
     end do
     ! smooth bi(mi)^-2 function
     if (ewaldbmsq(iaxis,1) < eps) ewaldbmsq(iaxis,1) = 0.5d0*ewaldbmsq(iaxis,2)
     do im = 2, fftngrid(iaxis)-1
        if ( ewaldbmsq(iaxis,im) < eps ) then
           ewaldbmsq(iaxis,im) = 0.5d0*(ewaldbmsq(iaxis,im-1) + ewaldbmsq(iaxis,im+1))
        end if
     end do
     if ( ewaldbmsq(iaxis,fftngrid(iaxis)) < eps ) then
        ewaldbmsq(iaxis,fftngrid(iaxis)) = 0.5d0*ewaldbmsq(iaxis,fftngrid(iaxis)-1)
     end if
  end do

  ! bi(mi)^2
  do i = 1,3
     do j = 1,fftngrid(i)
        ewaldbmsq(i,j) = bmsqcoef(j,i)*bmsqcoef(j,i)/ewaldbmsq(i,j)
     end do
  end do
end subroutine

! prepare B*C terms in Eq.(4.7), Ref.1
subroutine pme_prepare_bcterm()
  integer :: kvec1,kvec2,kvec3
  real*8 :: mterm(3),msq,expcoef,pivol2,bmcoef1,bmcoef12
  logical :: ifstarted

  pivol2 = 2d0*pi*cellvolume; expcoef = (pi/ewaldalpha)**2    ! pi^2/beta^2
  ifstarted=.false.
  do kvec1 = 1,fftngrid(1)/2+1
     bmcoef1 = ewaldbmsq(1,kvec1)/pivol2   ! |bi(mi)^2| / (2*pi*V)
     if ( ioct == 0 ) then
        mterm(1) = (pmemterm(1,kvec1)*pmecellinv(1))**2
     else
        mterm(1) = pmemterm(1,kvec1)       ! m1 in [-N/2, N/2]
     end if
     do kvec2 = 1,fftngrid(2)
        bmcoef12 = bmcoef1*ewaldbmsq(2,kvec2)
        if ( ioct == 0 ) then
           mterm(2) = (pmemterm(2,kvec2)*pmecellinv(2))**2
        else
           mterm(2) = pmemterm(2,kvec2)
        end if
        do kvec3 = 1,fftngrid(3)
           if ( ifstarted .eqv. .false. ) then
              ifstarted=.true.; cycle
           end if
           if ( ioct == 0 ) then
              mterm(3) = (pmemterm(3,kvec3)*pmecellinv(3))**2
              msq = mterm(1) + mterm(2) + mterm(3)        ! |m|^2
           else
              mterm(3) = pmemterm(3,kvec3)
              msq = dot_product(mat_car2frac(:,1),mterm(:))**2 + &
                    dot_product(mat_car2frac(:,2),mterm(:))**2 + &
                    dot_product(mat_car2frac(:,3),mterm(:))**2
           end if

           ! pmebcterm = B*C/2*pi*V, Ref.1, Eq.(4.7) .and (4.8)
           ! B=|b1(m1)|^2*|b2(m2)|^2*|b3(m3)|^2, C=exp(-pi^2*m^2/beta^2)/m^2
           ! here m_vector = m1*a1^* + m2*a2^* + m3*a3^*   Eq.(2.2)
           pmebcterm(kvec1,kvec2,kvec3) = bmcoef12*ewaldbmsq(3,kvec3)*exp(-expcoef*msq)/msq
        end do
     end do
  end do
end subroutine

! calculate the water parameters, ra, rb, rc, in Fig.2a in the paper.
!
! Shuichi Miyamoto and Peter A. Kollman
! SETTLE: An Analytical Version of the SHAKE and RATTLE Algorithm for Rigid Water Models
! J. Comput. Chem. 1992, 13: 952-962

subroutine pme_prepare_settlewatparm()
  integer :: i,j,k,io,ih
  real*8 :: tpvec(3),ohdis,hhdis,hmass,omass,p1(2),p2(2),p3(2),tpval,tpdis,tricom(2)
  
  if ( name(natom-2)(1:1) /= "O" ) call errormsg("Oxygen atom should be at the first place in the water!")

  hhdis = 0d0; ohdis = 0d0
  do i = nbondh - 2, nbondh
     if ( name(bondhatom(3*i-2))(1:1) == "H" .and. name(bondhatom(3*i-1))(1:1) == "H" ) then
        hhdis = bondeqval(bondhatom(3*i)); hmass = mass(bondhatom(3*i-2))
     else if ( ( name(bondhatom(3*i-2))(1:1) == "O" .and. name(bondhatom(3*i-1))(1:1) == "H" ) .or. &
               ( name(bondhatom(3*i-2))(1:1) == "H" .and. name(bondhatom(3*i-1))(1:1) == "O" )  ) then
        ohdis = bondeqval(bondhatom(3*i))
        if ( name(bondhatom(3*i-2))(1:1) == "O" ) then
           omass = mass(bondhatom(3*i-2))
        else
           omass = mass(bondhatom(3*i-1))
        end if
     end if 
  end do
  if ( hhdis == 0d0 .or. ohdis == 0d0 ) call errormsg("improper atoms in the water molecule!")

  tpval = sqrt(ohdis**2 - (hhdis/2d0)**2)
  p1(1:2) = [-hhdis/2d0, -tpval]; p2(1:2) = [hhdis/2d0, -tpval]; p3(1:2) = [0d0, 0d0]

  tricom(:) = ( p1(:)*hmass + p2(:)*hmass + p3(:)*omass )/(2d0*hmass + omass)

  tpdis = sqrt( dot_product(tricom(:),tricom) )
  settlewatparm(1) = tpdis             ! ra
  settlewatparm(2) = tpval - tpdis     ! rb
  settlewatparm(3) = hhdis/2d0         ! rc
  settlewatparm(4) = 4.0*settlewatparm(3)**2
  tpval = omass+hmass+hmass
  settlewatparm(5) = omass/tpval
  settlewatparm(6) = hmass/tpval
end subroutine

!=================================== perform the formal PME calculation

subroutine pme_potforce(tpcoor,tppot,tpfrc,check)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tppot
  real*8,intent(out),optional :: tpfrc(3,natom)
  logical,intent(in),optional :: check
  real*8,dimension(:,:),allocatable :: tptpfrc
  integer :: i,j,iatom
  real*8 :: tpvec(3),tpvalue
  logical :: pme_check

  tpfrc=0d0; edirec = 0d0; erecip = 0d0; ecorr = 0d0; evdwdirec = 0d0
  lj6dir = 0d0; lj6excl = 0d0; eljrecip = 0d0

  if ( (ifactivebox == .true.) .and. (ipb > 1) ) then
     call pme_prepare_cell(); call pme_prepare_bcterm()
  end if

  evdwcorr = inievdwcorr*inicellvolume/cellvolume

  if ( ipb > 1 ) pmevir = inipmevir*inicellvolume/cellvolume

  pme_check=.false.
  if ( present(check) ) then
     if ( check .eqv. .true. ) then
        pme_check=.true.; allocate(tptpfrc(3,natom)); tptpfrc=0d0
     end if
  end if

  call pme_potforce_recip(erecip,tpfrc=tpfrc)
  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("erecip ",erecip,tpfrc-tptpfrc); tptpfrc = tpfrc
  end if
  if ( iljpme == 1 ) then
     call pme_potforce_recip(eljrecip,tpfrc=tpfrc,ifljpme=.true.)
     if ( pme_check .eqv. .true. ) then
        call ambertop_checkforce("eljrecip ",eljrecip,tpfrc-tptpfrc); tptpfrc = tpfrc
     end if
  end if

  call pme_potforce_direct(edirec,evdwdirec,ecorr,tpfrc=tpfrc)
  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("direc ",edirec,tpfrc-tptpfrc)
     call ambertop_checkforce("evdwdirec ",evdwdirec,tpfrc-tptpfrc)
     call ambertop_checkforce("corr ",ecorr,tpfrc-tptpfrc); tptpfrc = tpfrc
     call ambertop_checkforce("self ",eself,tpfrc-tptpfrc)
  end if

  if ( pme_check .eqv. .true. ) then
     if ( iljpme == 1 ) then
        call ambertop_checkforce("evdwself ",eljself,tpfrc-tptpfrc); tptpfrc = tpfrc
     else
        call ambertop_checkforce("evdwcorr ",evdwcorr,tpfrc-tptpfrc); tptpfrc = tpfrc
     end if
  end if

  if ( ipb > 1 ) call pme_npt_vir_mol()

  call ambertop_potforce_elecvdw14(tpcoor,eelec14,evdw14,tpfrc=tpfrc)
  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("elec14 ",eelec14,tpfrc-tptpfrc)
     call ambertop_checkforce("vdw14 ",evdw14,tpfrc-tptpfrc); tptpfrc = tpfrc
  end if
  call ambertop_potforce_bond(tpcoor,ebond,tpfrc=tpfrc)
  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("bond ",ebond,tpfrc-tptpfrc); tptpfrc = tpfrc
  end if
  call ambertop_potforce_angle(tpcoor,eangle,tpfrc=tpfrc)
  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("angle ",eangle,tpfrc-tptpfrc); tptpfrc = tpfrc
  end if
  call ambertop_potforce_dihedral(tpcoor,edihe,tpfrc=tpfrc)
  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("dihe ",edihe,tpfrc-tptpfrc); tptpfrc = tpfrc
  end if

  tpvec(1:3) = sum(tpfrc,2)/dble(natom)
  do i = 1, natom
     tpfrc(:,i) = tpfrc(:,i) - tpvec(:)
  end do

  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("netcorr ",0.0d0,tpfrc-tptpfrc); tptpfrc = tpfrc
  end if

  eelec = edirec + erecip + ecorr + eself
  if ( iljpme == 0 ) then
     evdw = evdwdirec + evdwcorr
  else
     evdw = evdwdirec + eljrecip + eljself
  end if
  tppot = eelec+evdw+eelec14+evdw14+ebond+eangle+edihe

  if ( pme_check .eqv. .true. ) then
     call ambertop_checkforce("total ",tppot,tpfrc)
  end if
end subroutine

!=================================== perform PME calculation in direct space

subroutine pme_potforce_direct(tpelecdirec,tpvdwdirec,tpcorr,tpfrc)
  real*8,intent(inout) :: tpelecdirec,tpvdwdirec,tpcorr
  real*8,dimension(3,natom),intent(inout),optional :: tpfrc
  integer :: iatom,jatom,ibox,jbox,i,j,idx,tpi,iaxis,index,xpos,ivdwtype,csidx,lexcluded,rexcluded
  real*8 :: tpcoorvec(3),tpfrccoef,tpifrc(3),tpfrcvec(3),dis,disinv,dis6inv,dissqinv,coef1,coef2,coef12,expdij,ewalddis,xdis
  real*8 :: iboxcoor(3,0:18),discutsq,dissq,tpvec(4),tpvalue,tpfepvalue,tpfepdissq
  real*8 :: ljalphaxsq,gx,dgx
  logical :: ifdofepsoftcore

  if ( ipb > 1 ) then
     tpcoorvec(:) = pmecell(:)/pmesavecell(:)
     do iatom = 1,natom
        pmesavecoor(:,iatom) = pmesavecoor(:,iatom)*tpcoorvec(:)
        pmesaveboxcoor(:,iatom) = pmesaveboxcoor(:,iatom)*tpcoorvec(:)
     end do
  end if

  if ( ifactivebox .eqv. .false. ) then
     do iatom = 1,natom
        tpvec(:) = nowcoor(:,iatom) - pmesavecoor(:,iatom)
        if ( dot_product(tpvec,tpvec) > hfskinsq ) then
           ifactivebox = .true.; exit
        end if
     end do
  end if

  if ( (ifactivebox .eqv. .true.) .and. (.not. allocated(fepmols)) ) then
     call pme_set_boxcoor_and_neighborlist(); ifactivebox=.false.
  else
     do i = 1, natom
        iatom = boxatom(i)
        pmeboxcoor(:,i) = pmesaveboxcoor(:,i) + nowcoor(:,iatom) - pmesavecoor(:,iatom)
     end do
  end if

  tpelecdirec = 0.d0; tpvdwdirec = 0.d0; tpcorr = 0.d0; pmeboxfrc = 0.d0; discutsq = discut**2.d0

  ! cycle over all boxes in the periodic box
  do ibox=1,pmenbox
     ! cycle over all atoms in the ibox
     do i=boxatomindex(ibox)+1,boxatomindex(ibox+1)
        iatom = boxatom(i); ivdwtype = nvdwtype*(pmeboxtypeindex(i) - 1)
        if ( allocated(fepmols) ) then
           if ( .not. any(atommol(iatom) == fepmols) ) cycle
        end if
        ! get the image coordinates of iatom in bottom two layers of periodic boxes, index from 1 to 18
        do j = 1,18
           iboxcoor(:,j) = pmeboxcoor(:,i) + pmepbcrd(:,j)
        end do
        tpifrc(:) = 0.d0
        ! cycle over all atoms in iatom's neighbor list
        do idx = pmeboxnlindex(i)+1,pmeboxnlindex(i+1)
           ! get the jatom and neighbor periodic box index
           tpi=pmeboxnl(idx); j=iand(Z"FFFFF",tpi); csidx = ishft(tpi,-20)
           jatom = boxatom(j)
           if ( allocated(fepmols) ) then
              if ( .not. any(atommol(jatom) == fepmols) ) cycle
           end if
           tpcoorvec(:) = iboxcoor(:,csidx) - pmeboxcoor(:,j)

           dissq = dot_product(tpcoorvec,tpcoorvec)

           if ( dissq <= discutsq ) then

              ! slower method: calculate the electrostatic energy directly in direct space by erfc function

              ! dis = sqrt(dissq); disinv=1.0/dis; coef1 = pmeboxcharge(i)*pmeboxcharge(j)*disinv
              ! call erfc_function(ewaldalpha*dis,xdis,coef2)   ! accurate erfc function
              ! call erfc_fast(ewaldalpha*dis,xdis,coef2)       ! simplified erfc function
              ! if (ifcalpot) tpelecdirec = tpelecdirec + coef1*xdis
              ! tpfrccoef = coef1*(-ewaldalpha*dis*coef2 + xdis)

              ! faster method: calculate the electrostatic energy by the saved Taylor series on the left grid point in the corresponding interval

              ifdofepsoftcore = .false.
              if ( iffepsoftcore .eqv. .true. ) then
                 if ( iatom <= nbioatom .and. jatom <= nbioatom ) then
                    if ( fepatommark(iatom)*fepatommark(jatom) < 0 ) then
                       tpfepdissq = dissq; ifdofepsoftcore =  .true.
                       tpfepvalue = fepelecbeta*(1d0-fepscale) + tpfepdissq
                       dissq = tpfepvalue
                    end if
                 end if
              end if

              dis = sqrt(dissq); disinv = 1d0/dis
              if ( dissq >= 7.d0 ) then
                 xpos = ceiling(dissq*50.d0); xdis = dissq - dble(xpos-1) * 0.02d0
                 if ( ifcalpot ) then
                    tpvec(1:4) = pmeenefarbasic(1:4,xpos)
                    tpvalue = pmeboxcharge(i)*pmeboxcharge(j)*(tpvec(1) + xdis * (tpvec(2) + xdis * (tpvec(3) + xdis * tpvec(4))))
                    if ( ifdofepsoftcore .eqv. .true. ) then
                       tpvalue = tpvalue*fepscale
                       bindpot = bindpot + tpvalue
                    end if
                    tpelecdirec = tpelecdirec + tpvalue
                 end if
                 tpfrccoef = pmeboxcharge(i)*pmeboxcharge(j)*(pmefrcfarbasic(1,xpos) + xdis * (pmefrcfarbasic(2,xpos) + xdis * (pmefrcfarbasic(3,xpos) + xdis * pmefrcfarbasic(4,xpos))))
              else
                 coef1 = pmeboxcharge(i)*pmeboxcharge(j)*disinv
                 xpos = ceiling(dis*100.d0); xdis = dis - int(dis*100.d0) * 0.01d0
                 if ( ifcalpot ) then
                    tpvalue = coef1*(pmeenebasic(1,xpos) + xdis * (pmeenebasic(2,xpos) + xdis * (pmeenebasic(3,xpos) + xdis * pmeenebasic(4,xpos))))
                    if ( ifdofepsoftcore .eqv. .true. ) then
                       tpvalue = tpvalue*fepscale
                       bindpot = bindpot + tpvalue
                    end if
                    tpelecdirec = tpelecdirec + tpvalue
                 end if
                 tpfrccoef = coef1*(pmefrcbasic(1,xpos) + xdis * (pmefrcbasic(2,xpos) + xdis * (pmefrcbasic(3,xpos) + xdis * pmefrcbasic(4,xpos))))
              end if

              tpfrccoef = tpfrccoef*disinv
              if ( ifdofepsoftcore .eqv. .true. ) then
                 tpfrccoef = tpfrccoef*fepscale*(1d0/2d0)*tpfepvalue**(-1d0/2d0)*2d0*sqrt(tpfepdissq)
              end if

              if ( ifdofepsoftcore .eqv. .true. ) then
                 tpfepvalue = fepvdwalpha*(1d0-fepscale)*(vdwsigma(iatom)+vdwsigma(jatom))**6+tpfepdissq**3
                 dissq = tpfepvalue**(1d0/3d0)
              end if

              tpi = ivdwtype + pmeboxtypeindex(j); dissqinv = 1.d0/dissq; disinv = sqrt(dissqinv)
              if ( pmevdwskip(tpi) .eq. .false. ) then
                 index = nonbondedparmindex(tpi)
                 dis6inv = dissqinv*dissqinv*dissqinv
                 if ( iljpme == 1 ) then
                    ljalphaxsq = ljalpha*ljalpha*dissq
                    call pme_ljpme_gfunction(sqrt(ljalphaxsq),gx,dgx)
                    tpfrccoef = tpfrccoef + disinv*dis6inv*vdwlambda(iatom)*vdwlambda(jatom)*( dgx*sqrt(ljalphaxsq) - 6.d0*(gx-1d0) )
                 end if
                 if ( ifcalpot ) then
                    tpvalue = dis6inv*(vdwacoef(index)*dis6inv - vdwbcoef(index))
                    if ( ifdofepsoftcore .eqv. .true. ) then
                       tpvalue = tpvalue*fepscale
                       bindpot = bindpot + tpvalue
                    end if
                    tpvdwdirec = tpvdwdirec + tpvalue
                    if ( iljpme == 1 ) then
                       lj6dir = lj6dir - dis6inv*vdwlambda(iatom)*vdwlambda(jatom)*(gx-1d0)
                    end if
                 end if
                 tpvalue = dis6inv*(12.d0*vdwacoef(index)*dis6inv-6.d0*vdwbcoef(index))*disinv
                 if ( ifdofepsoftcore .eqv. .true. ) then
                    tpvalue = tpvalue*fepscale*(1d0/6d0)*tpfepvalue**(-5d0/6d0)*6d0*sqrt(tpfepdissq)**5
                 end if
                 tpfrccoef = tpfrccoef + tpvalue
              end if

              if ( ifdofepsoftcore .eqv. .true. ) then
                 tpvalue = tpfrccoef/sqrt(tpfepdissq)
              else
                 tpvalue = tpfrccoef*disinv
              end if
              tpfrcvec(:) = tpcoorvec(:)*tpvalue
              if ( ipb > 1 ) then
                 pmevir(:) = pmevir(:) + tpcoorvec(:)*tpfrcvec(:)
              end if
              tpifrc(:) = tpifrc(:) + tpfrcvec(:)
              pmeboxfrc(:,j) = pmeboxfrc(:,j) - tpfrcvec(:)

           end if
        end do
        pmeboxfrc(:,i) = pmeboxfrc(:,i) + tpifrc(:)
     end do
  end do

  ! calculate the correction force between excluded atom-atomn pairs, first term in eq.(2.5) in Ref.1
  ! it is omitted by previous nonbonded interaction calculations
  lexcluded = 0; rexcluded = 0
  do iatom = 1, natom
     lexcluded = rexcluded + 1; rexcluded = rexcluded + nexcludedatoms(iatom)
     do j = lexcluded,rexcluded
        jatom = excludedatomlist(j); if ( jatom .eq. 0 ) exit
        ! calculate atom-to-atom displacement vector and ensure it is smaller than half of the size of periodic box on each axis
        do iaxis = 1,3
           tpcoorvec(iaxis) = nowcoor(iaxis,iatom) - nowcoor(iaxis,jatom)
           if ( abs(tpcoorvec(iaxis)) .le. pmecell(iaxis)*0.5d0 ) cycle
           if ( tpcoorvec(iaxis) .lt. 0d0 ) then
              tpcoorvec(iaxis) = tpcoorvec(iaxis) + pmecell(iaxis)
           else
              tpcoorvec(iaxis) = tpcoorvec(iaxis) - pmecell(iaxis)
           end if
        end do
        dissq = dot_product(tpcoorvec,tpcoorvec); if ( dissq > discutsq ) cycle
        dis = sqrt(dissq); disinv = 1d0/dis
        coef1 = charge(iatom)*charge(jatom)*disinv; dissqinv = disinv**2
        xpos = ceiling(dis*100.d0); xdis = dis - int(dis*100.d0) * 0.01d0
        tpcorr = tpcorr + coef1*(pmeenebasic(1,xpos) + xdis * (pmeenebasic(2,xpos) + xdis * (pmeenebasic(3,xpos) + xdis * pmeenebasic(4,xpos))) - 1.d0)

        tpfrccoef = coef1*(pmefrcbasic(1,xpos) + xdis * (pmefrcbasic(2,xpos) + xdis * (pmefrcbasic(3,xpos) + xdis * pmefrcbasic(4,xpos))) - 1.d0)
        if ( iljpme == 1 ) then
           dis6inv = dissqinv*dissqinv*dissqinv; ljalphaxsq = ljalpha*ljalpha*dissq
           call pme_ljpme_gfunction(sqrt(ljalphaxsq),gx,dgx)
           lj6excl = lj6excl - dis6inv*vdwlambda(iatom)*vdwlambda(jatom)*(gx-1d0)
           tpfrccoef = tpfrccoef + dis6inv*vdwlambda(iatom)*vdwlambda(jatom)*( dgx*sqrt(ljalphaxsq) - 6.d0*(gx-1d0) )
        end if
        tpfrcvec(:) = tpcoorvec(:)*tpfrccoef*dissqinv
        if ( ipb > 1 ) then
           pmevir(:) = pmevir(:) + tpcoorvec(:)*tpfrcvec(:)
        end if
        tpfrc(:,iatom) = tpfrc(:,iatom) + tpfrcvec(:)
        tpfrc(:,jatom) = tpfrc(:,jatom) - tpfrcvec(:)
     end do
  end do
  if ( ifcalpot .and. iljpme == 1 ) then
     tpvdwdirec = tpvdwdirec + lj6dir + lj6excl
     !write(6,'(100a15)'),'tpvdwdirec','lj6dir','lj6excl'
     !write(6,'(100f15.6)'),tpvdwdirec,lj6dir,lj6excl
  end if

  ! put the direct space forces back to the original atoms
  do i = 1,natom
     iatom = boxatom(i)
     tpfrc(:,iatom) = tpfrc(:,iatom) + pmeboxfrc(:,i)
  end do
end subroutine

subroutine pme_set_boxcoor_and_neighborlist()
  integer :: iaxis,iatom,jatom,ibox,jbox,tpboxvec(3),ijstride,i,j,idx,jboxpos,tpidx,csidx,index
  integer :: nextatom(natom),firstatom(pmenbox),lastatom(pmenbox)
  real*8 :: tpcoorvec(3),tpvec(3),dis,iboxcoor(3,0:18)
  logical :: ifskipatoms(0:natom),ifskip

  ! put the atoms in the boxes and sort the atom indices
  nextatom = 0; firstatom = 0; lastatom = 0
  ijstride = pmenboxvec(1)*pmenboxvec(2)

  ! find the owner boxes for all atoms
  do iatom=1,natom
     if ( ioct > 0 ) then
        ! box position in the three directions in the periodic box
        tpboxvec(1:3) = int(pmeunitcoor(1:3,iatom)*dble(pmenboxvec(1:3)))+1
        ! tranform back to the Cartesian coordinates in the periodic box, it will be copied to boxcoor later
        do iaxis = 1,3
           pmesavecoor(iaxis,iatom) = dot_product(pmeunitcoor(:,iatom),mat_frac2car(iaxis,:))
        end do
     else
        tpboxvec(1:3) = int(pmeunitcoor(1:3,iatom)*dble(pmenboxvec(1:3)))+1
        pmesavecoor(1:3,iatom) = pmeunitcoor(1:3,iatom)*pmecell(1:3)
     end if

     ! tranform the 3D box index vector to 1D
     ibox = tpboxvec(1) + (tpboxvec(2)-1)*pmenboxvec(1) + (tpboxvec(3)-1)*ijstride

     ! put the iatom to the related box and connect it to prevous atom in the same box
     if ( lastatom(ibox) == 0 ) then
        firstatom(ibox) = iatom; lastatom(ibox) = iatom
     else
        nextatom(lastatom(ibox)) = iatom; lastatom(ibox) = iatom
     end if
  end do

  ! resort the atom indices according to their box indices
  boxatom = 0; boxatomindex = 0; idx = 0
  do ibox = 1,pmenbox
     if ( firstatom(ibox) .ne. 0 ) then
        idx = idx + 1; iatom = firstatom(ibox); boxatom(idx) = iatom; atombox(iatom) = idx
        do while ( nextatom(iatom) .ne. 0 )
           idx = idx + 1; iatom = nextatom(iatom); boxatom(idx) = iatom; atombox(iatom) = idx
        end do
     end if
     boxatomindex(ibox+1) = idx
  end do

  ! update the coordinate list according to the new atom list
  do i = 1,natom
     iatom = boxatom(i)
     pmeboxcharge(i) = charge(iatom); pmeboxtypeindex(i) = typeindex(iatom)
     pmeboxcoor(:,i) = pmesavecoor(:,iatom)
  end do
  pmesavecoor = nowcoor; pmesaveboxcoor = pmeboxcoor

  idx = 0; ifskipatoms = .false.; pmeboxnlindex(1) = 0
  do ibox=1,pmenbox
     do i=boxatomindex(ibox)+1,boxatomindex(ibox+1)
        iatom = boxatom(i)

        ! mark the excluded atoms of iatom in the bidirectional exclusion list
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           ifskipatoms(atombox(biexcludedatomlist(j))) = .true.
        end do

        ! cycle over the atoms only in the jbox=ibox, if its distance to iatom is smaller than cutoff, then add it to the neighbor list 
        ! atom index: j, neighbor periodic box index: 14 (just the central periodic box, recoded in the higher bits of j)
        do j=boxatomindex(ibox)+1,i-1
           if ( ifskipatoms(j) .eq. .false. ) then
              tpcoorvec(:) = pmeboxcoor(:,i) - pmeboxcoor(:,j)
              if ( dot_product(tpcoorvec,tpcoorvec) <= fullcutsq ) then
                 idx = idx + 1; pmeboxnl(idx) = ior(j,ishft(14,20))
              end if
           end if
        end do

        ! build the neighbor list for the atoms in the neighboring box around ibox

        ! image coordinates of iatom in the two layers of periodic boxes at the bottom
        do csidx = 1,18
           iboxcoor(:,csidx) = pmeboxcoor(:,i) + pmepbcrd(:,csidx)
        end do

        ! cycle over the 62 neighbor boxs of ibox and their locations in the central or neighbor periodic box, csidx
        do jboxpos=boxnlboxindex(ibox)+1,boxnlboxindex(ibox+1)
           jbox = boxnlboxes(jboxpos); csidx = boxnlboxcsidx(jboxpos)
           ! cycle over all atoms in jbox 
           do j=boxatomindex(jbox)+1,boxatomindex(jbox+1)
              if ( ifskipatoms(j) .eq. .false. ) then
                 ! iboxcoor, image coordinate of iatom in the neighbor periodic box specified by csidx
                 tpcoorvec(:) = iboxcoor(:,csidx) - pmeboxcoor(:,j)
                 if ( dot_product(tpcoorvec,tpcoorvec) <= fullcutsq ) then
                    ! neighbor atom: j, neighbor periodic box index: csidx
                    idx = idx + 1; pmeboxnl(idx) = ior(j,ishft(csidx,20))
                 end if
              end if
           end do
        end do

        ! reset the excluded atom list
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           ifskipatoms(atombox(biexcludedatomlist(j))) = .false.
        end do

        ! start to build the neighbors for the next atom
        pmeboxnlindex(i+1) = idx
     end do
  end do

  if ( procid == 0 .and. idx > pmemaxnnl) then
     call errormsg("neighbor list exceeds the array bound! ",int1=pmemaxnnl,int2=idx)
  end if
end subroutine

!=================================== perform PME calculation in reciprocal space

subroutine pme_potforce_recip(tpelecvdw,tpfrc,ifljpme)
  include 'fftw3.f03'
  real*8,intent(out) :: tpelecvdw
  real*8,dimension(3,natom),intent(out),optional :: tpfrc
  logical,intent(in),optional :: ifljpme

  call pme_transform_coordinates_to_unitcoor()
  call pme_set_gridcharge(ifljpme)
  call dfftw_execute_dft_r2c(plan_forward,realgridcharge,gridcharge)
  call pme_potforce_recippot(tpelecvdw,ifljpme)
  call dfftw_execute_dft_c2r(plan_backward,gridcharge,realgridcharge)
  call pme_potforce_recipfrc(tpfrc,ifljpme)
end subroutine

subroutine pme_transform_coordinates_to_unitcoor()
  integer :: iatom,iaxis
  real*8 :: tpvec(3)

  if ( ioct > 0 ) then

     do iatom = 1, natom
        do iaxis = 1,3
           ! fractional coordinate
           tpvec(iaxis) = dot_product(nowcoor(:,iatom),mat_car2frac(iaxis,:))
           ! move to the corresponding periodic box (unit cell), and exchange the two halves of the periodic box
           ! that it, transform the coordinates from [0.0,0.5]+[0.5,1.0] to [0.5:1.0]+[0.0:0.5]
           tpvec(iaxis) = tpvec(iaxis)-dnint(tpvec(iaxis))+0.5d0
           if ( tpvec(iaxis) < 0.d0 ) then
              tpvec(iaxis) = tpvec(iaxis) + 1.d0
           else if ( tpvec(iaxis) >= 1.d0 ) then
              tpvec(iaxis) = tpvec(iaxis) - 1.d0
           end if
        end do
        pmeunitcoor(1:3,iatom) = tpvec(1:3)
     end do

  else

     do iatom = 1, natom
        do iaxis = 1,3
           tpvec(iaxis) = nowcoor(iaxis,iatom)*pmecellinv(iaxis)
           tpvec(iaxis) = tpvec(iaxis)-dnint(tpvec(iaxis))+0.5d0
           if ( tpvec(iaxis) < 0.d0 ) then
              tpvec(iaxis) = tpvec(iaxis) + 1.d0
           else if ( tpvec(iaxis) >= 1.d0 ) then
              tpvec(iaxis) = tpvec(iaxis) - 1.d0
           end if
        end do
        pmeunitcoor(1:3,iatom) = tpvec(1:3)
     end do

  end if
end subroutine

! distribute the atom charges to the FFT grids in the cell, Page 8581. Eq.(4.6)
subroutine pme_set_gridcharge(ifljpme)
  logical,intent(in),optional :: ifljpme
  integer :: igrid,jgrid,kgrid,iatom,iaxis,i,j,k
  real*8 :: xivec(3),qz,qyz,tpcoor

  do iatom = 1, natom
     do iaxis=1,3
        ! locate owner FFT grid of iatom
        tpcoor = pmeunitcoor(iaxis,iatom)*dble(fftngrid(iaxis))
        igrid = int(tpcoor); 
        ! compute the bias from the left grid in the current interval
        xivec(iaxis) = tpcoor - dble(igrid)
        ! compute the basis function values and derivatives of the B-spline
        call getbspline_order4(xivec(iaxis),basisfunc(:,iaxis,iatom),basisdev(:,iaxis,iatom))

        ! grid save type 1
        ! chargegrid(iaxis,iatom) = igrid - splineorder + 3
        ! grid save type 2 
        chargegrid(iaxis,iatom) = igrid - splineorder + 1
     end do
  end do

  realgridcharge(:,:,:) = 0.d0
  do iatom = 1, natom
     do k = 1, splineorder

        ! grid save type 1
        ! kgrid = chargegrid(3,iatom) + k
        ! if ( kgrid < 1 ) kgrid = kgrid + fftngrid(3)
        ! if ( kgrid > fftngrid(3) ) kgrid = kgrid - fftngrid(3)

        ! grid save type 2
        kgrid = chargegrid(3,iatom) + k
        if ( kgrid <= 0 ) kgrid = kgrid + fftngrid(3)

        if ( .not. present(ifljpme) ) then
           qz = basisfunc(k,3,iatom) * charge(iatom)
        else
           if (present(ifljpme)) qz = basisfunc(k,3,iatom) * vdwlambda(iatom)
        end if
        do j = 1, splineorder

           jgrid = chargegrid(2,iatom) + j
           if (jgrid <= 0 ) jgrid = jgrid + fftngrid(2)

           qyz = qz*basisfunc(j,2,iatom)
           do i = 1, splineorder

              igrid = chargegrid(1,iatom) + i
              if ( igrid <= 0 ) igrid = igrid + fftngrid(1)

              realgridcharge(igrid,jgrid,kgrid) = realgridcharge(igrid,jgrid,kgrid) + qyz*basisfunc(i,1,iatom)
           end do
        end do
     end do
  end do
end subroutine

! electrostatic energy in reciprocal space, Ref.1, Eq.(4.7)
subroutine pme_potforce_recippot(tpelec,ifljpme)
  real*8,intent(out) :: tpelec
  logical,intent(in),optional :: ifljpme
  integer :: igrid,ngrid12,i,kvec1,kvec2,kvec3
  real*8 :: qsq,bcterm,tppot,mterm(3),tpmterm(3),msq,x,fx
  logical :: ifstarted

  tpelec = 0d0; ifstarted = .false.
  do kvec1 = 1,fftngrid(1)/2+1; do kvec2 = 1,fftngrid(2); do kvec3 = 1,fftngrid(3)

     ! B*C
     if ( .not. present(ifljpme) ) then
        if ( ifstarted .eqv. .false. ) then
           ifstarted = .true.; cycle
        end if
        bcterm = pmebcterm(kvec1,kvec2,kvec3)
     else if ( ifljpme .eqv. .true. ) then
        mterm(1) = (pmemterm(1,kvec1)*pmecellinv(1))**2
        mterm(2) = (pmemterm(2,kvec2)*pmecellinv(2))**2
        mterm(3) = (pmemterm(3,kvec3)*pmecellinv(3))**2
        msq = mterm(1) + mterm(2) + mterm(3)        ! |m|^2
        x = pi*sqrt(msq)/ljalpha
        call pme_ljpme_ffunction(x,fx)
        bcterm = -pi*sqrt(pi)*ljalpha**3d0*fx/(2d0*cellvolume)
     end if

     ! F(q)(m)*F(q)(-m)
     qsq = real(gridcharge(kvec1,kvec2,kvec3))**2 + aimag(gridcharge(kvec1,kvec2,kvec3))**2

     if ( ifcalpot ) then
        ! R-TO-C FFT transform, Hermite symmetry (only half of kvec1 grids are considered)
        ! double the reciprocal potential on the grids
        tppot = bcterm*qsq*2.d0
        if ( kvec1 == 1 .or. ( kvec1 == (fftngrid(1)/2+1) .and. btest(kvec1,0) ) ) tppot = tppot*0.5
        tpelec = tpelec + tppot
     end if
     gridcharge(kvec1,kvec2,kvec3) = 2.d0*bcterm*gridcharge(kvec1,kvec2,kvec3)

     ! calculate virial
     if ( ipb > 1 ) then
        if ( ioct > 0 ) then
           tpmterm(1) = pmemterm(1,kvec1); tpmterm(2) = pmemterm(2,kvec2); tpmterm(3) = pmemterm(3,kvec3)
           mterm(1) = dot_product(mat_car2frac(:,1),tpmterm(:))
           mterm(2) = dot_product(mat_car2frac(:,2),tpmterm(:))
           mterm(3) = dot_product(mat_car2frac(:,3),tpmterm(:))
        else
           mterm(1) = pmemterm(1,kvec1)*pmecellinv(1)
           mterm(2) = pmemterm(2,kvec2)*pmecellinv(2)
           mterm(3) = pmemterm(3,kvec3)*pmecellinv(3)
        end if
        msq = dot_product(mterm,mterm)

        ! Ref.1, Eq.(2.7), here q^2 = S(m)*S(-m)
        ! Eq.(3.6), S(m)=FFT(q)(m), S(-m)=FFT(q)(-m)
        mterm(:) = bcterm*qsq*(1d0 - 2d0*(1.d0+msq*(pi/ewaldalpha)**2)*mterm(:)**2/msq)
        if ( kvec1 == 1 .or. ( kvec1 == (fftngrid(1)/2+1) .and. btest(kvec1,0) ) ) then
           pmevir(:) = pmevir(:) + mterm(:)
        else
           pmevir(:) = pmevir(:) + 2d0*mterm(:)
        end if
     end if
  end do; end do; end do
end subroutine

! Page. 8581. Eq.(4.9)
subroutine pme_potforce_recipfrc(tpfrc,ifljpme)
  real*8,dimension(3,natom),intent(out) :: tpfrc
  logical,intent(in),optional :: ifljpme
  integer :: igrid,jgrid,kgrid,iatom,iaxis,i,j,k
  real*8 :: dev(3),tpq

  ! chargegrid: FFT grids owned by the atoms
  ! realgridcharge = FFT^-1(2*B*C*FFT(q))
  do iatom = 1, natom

     dev=0d0
     do k = 1, splineorder

        ! get the cubic B-spline grids around the point charge [grid1,grid2,grid3,grid4], point charge is between grid2 and grid3
        kgrid = chargegrid(3,iatom) + k

        ! shift the spline grid to the intervavl [1,fftngrid(3)], actually it is [0,fftngrid(3)-1] in FFT
        if ( kgrid < 1 ) kgrid = kgrid + fftngrid(3)
        ! if ( kgrid > fftngrid(3) ) kgrid = kgrid - fftngrid(3)  ! this is not necessary

        do j = 1, splineorder

           jgrid = chargegrid(2,iatom) + j
           if ( jgrid <= 0 ) jgrid = jgrid + fftngrid(2)

           do i = 1, splineorder

              igrid = chargegrid(1,iatom) + i
              if ( igrid <= 0 ) igrid = igrid + fftngrid(1)

              tpq = realgridcharge(igrid,jgrid,kgrid)
              dev(1) = dev(1) + tpq*basisdev(i,1,iatom)*basisfunc(j,2,iatom)*basisfunc(k,3,iatom)
              dev(2) = dev(2) + tpq*basisfunc(i,1,iatom)*basisdev(j,2,iatom)*basisfunc(k,3,iatom)
              dev(3) = dev(3) + tpq*basisfunc(i,1,iatom)*basisfunc(j,2,iatom)*basisdev(k,3,iatom)
           end do
        end do
     end do

     if ( .not. present(ifljpme) ) then

        if ( ioct > 0 ) then
           do i = 1, 3
              tpfrc(i,iatom) = tpfrc(i,iatom) - charge(iatom)*dot_product(mat_car2frac(:,i),dev(:))*dble(fftngrid(i))
           end do
        else
           do i = 1, 3
              tpfrc(i,iatom) = tpfrc(i,iatom) - charge(iatom)*pmecellinv(i)*dev(i)*dble(fftngrid(i))
           end do
        end if

     else if ( ifljpme .eqv. .true. ) then

        if ( ioct > 0 ) then
           do i = 1, 3
              tpfrc(i,iatom) = tpfrc(i,iatom) - vdwlambda(iatom)*dot_product(mat_car2frac(:,i),dev(:))*dble(fftngrid(i))
           end do
        else
           do i = 1, 3
              tpfrc(i,iatom) = tpfrc(i,iatom) - vdwlambda(iatom)*pmecellinv(i)*dev(i)*dble(fftngrid(i))
           end do
        end if

     end if
  end do
end subroutine

!=================================== pressure coupling

subroutine pme_npt_vir_mol()
  integer :: iatom,ires,imol
  real*8 :: avgcoor(3)

  ! as introduced in J. Chem. Phys. 81, 3684 (1984), Eq,14
  ! the virial can be simplified by the center of mass coordinates of molecules
  ! virial = Sum_ij( R_comi - R_comj )*F_ij )
  !        = Sum_i( (R_comi - R_i)*F_i ) + Sum_j( (R_comj - R_j)*F_j ) + Sum_ij( (R_i-R_j)*F_ij )

  do imol = 1, nmol
     do ires=molindex(imol)+1,molindex(imol+1)
        do iatom=resindex(ires)+1,resindex(ires+1)
           pmevir(:) = pmevir(:) + (molcom(:,imol)-nowcoor(:,iatom))*nowforce(:,iatom)
        end do
     end do
  end do
end subroutine

subroutine pme_npt_isobaric_Berendsen()
  integer :: iatom,ires,imol
  real*8 :: tpcoeff(3),tppressure(3),tpekin(3),molp(3),tpmat_car2frac(3,3),tpvec(3),tpvec2(3)

  ! calculate the kinetic energy
  tpekin = 0d0
  do imol=1,nmol
     molp(:) = 0d0
     do ires=molindex(imol)+1,molindex(imol+1)
        do iatom=resindex(ires)+1,resindex(ires+1)
           tpcoeff = 0.5d0*deltatime*timescale/mass(iatom)
           molp(:) = molp(:) + mass(iatom)*( nowvel(:,iatom) + tpcoeff*nowforce(:,iatom) )
        end do
     end do
     tpekin(:) = tpekin(:) + molp(:)**2/molmass(imol)
  end do

  ! calculate pressure by virial theorem, see Eq.13 in the reference
  ! H.J.C. Berendsen, J.P.M. Postma, W.F. van Gunsteren, A. DiNola and J. R. Haak
  ! J. Chem. Phys. 81, 3684 (1984)
  ! P = 2.0 * pressconvert * [ kinetic_energy + virial ]/(6*cell_volume)
  ! pressconvert = pressure unit convert factor from kcal/mol/Ang^3 to bar

  tppressure(:) = pressconvert*(tpekin(:)+pmevir(:))/cellvolume
  realpressure = sum(tppressure)/3d0

  ! coupling to an external bath with a constant pressure
  ! Berendsen method, Eq.21 in the following reference
  ! H.J.C. Berendsen, J.P.M. Postma, W.F. van Gunsteren, A. DiNola and J. R. Haak
  ! J. Chem. Phys. 81, 3684 (1984)
  ! scale the cell volumn by mu = ( 1 - (deltatime/taup)*kappa*(P0 - P(t)) )**(1/3)
  ! kappa=isocompress : constant isothermal compressibility of water  

  if ( ipb == 2 ) then
     tpcoeff(1:3) = (1.d0 - isocompress*(pressure0 - realpressure)*bar2pascal*deltatime/taup)**(1.d0/3.d0)
  else if ( ipb == 3 ) then
     tpcoeff(1:3) = (1.d0 - isocompress*(pressure0 - tppressure(:))*bar2pascal*deltatime/taup)**(1.d0/3.d0)
  end if

  tpmat_car2frac = mat_car2frac
  call pme_prepare_cell(nptcoeff=tpcoeff)
  call pme_prepare_bcterm()

  ! note that the coordinates of all atoms (center-of-mass of molecules) are changed here
  ! and the bonded energy terms are calculated in pme_potforce() after this change
  ! but this is ok, because moving the COM does not change the atom-to-atom distance inside the molecule

  call pubmod_molecule_com()

  do imol=1,nmol
     if ( ioct > 0 ) then
!        do i=1,3
!           tpvec2(i) = dot_product(tpmat_car2frac(i,:),molcom(:,imol))
!        end do
!        do i=1,3
!           tpvec(i) = dot_product(mat_frac2car(i,:),tpvec2)
!        end do
        tpvec2 = molcom(1:3,imol)
        tpvec(1) = tpvec2(3)*tpmat_car2frac(3,3)*mat_frac2car(1,3)
        tpvec(2) = tpvec2(3)*tpmat_car2frac(3,3)*mat_frac2car(2,3)
        tpvec(3) = tpvec2(3)*tpmat_car2frac(3,3)*mat_frac2car(3,3)
        tpvec(1) = tpvec2(2)*tpmat_car2frac(2,2)*mat_frac2car(1,2)
        tpvec(2) = tpvec2(2)*tpmat_car2frac(2,2)*mat_frac2car(2,2)
        tpvec(1) = tpvec2(1)*tpmat_car2frac(1,1)*mat_frac2car(1,1)
     else
        tpvec(:) = tpcoeff*molcom(1:3,imol)
     end if
     do ires=molindex(imol)+1,molindex(imol+1)
        do iatom=resindex(ires)+1,resindex(ires+1)
           nowcoor(:,iatom) = nowcoor(:,iatom) + tpvec(:) - molcom(:,imol)
        end do
     end do
     molcom(:,imol) = tpvec(:)
  end do
end subroutine

end module
