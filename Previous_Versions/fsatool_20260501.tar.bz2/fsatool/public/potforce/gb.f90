! Reference paper for igb=-1 (old pairwise generalized Born model))
!
! [1] Tsui, V., Case, D. A. 
!     Molecular dynamics simulations of nucleic acids with a generalized Born solvation model.
!     J. Am. Chem. Soc.. 2000, 122: 2489-2498.
!
! Reference paper for igb=1 (GBNeck2 model)
!
! [2] Mongan, J., Simmerling, C., Mccammon, J.A. et al. 
!     Generalized Born model with a simple, robust molecular volume correction.
!     J. Chem. Theory Comput. 2007, 3: 156-169.
!
! [3] Nguyen, H., Roe, D.R., Simmerling, C.
!     Improved generalized Born solvent model parameters for protein simulations.
!     J. Chem. Theory Comput. 2013, 9: 2020-2034.
!
! Reference paper for igbsa=1 (pwSASA model)
!
! [4] Huang H. and Simmerling C.
!     Fast Pairwise Approximation of Solvent Accessible Surface Area for Implicit Solvent Simulations
!     of Proteins on CPUs and GPUs.
!     J. Chem. Theory Comput. 2018, 14: 5797-5814.
!
! Reference paper for RESPA
!
! [5] Humphreys D.D., Friesner R. A., Berne B. J. 
! A Multiple-Time-Step Molecular Dynamics Algorithm for Macromolecules. 
! Journal of Physical Chemistry, 1994, 98: 6885-6892.

module gb
  use pubmod
  use ambertop 
  use parmdata
  implicit none
  real*8,parameter :: offset = 0.09d0, gbdiscut=25.0d0, epsin=1.0d0, epsout=78.5d0
  real*8 :: fsrhomax,discutrespa,kappa
  real*8,allocatable,dimension(:) :: fsrho,radeff,gbfrccoef,radoff

! parameters for igb=1 (GBNeck2 model)
!
! gb1watrad (water molecule radius) is shown in fig.1 of Ref.2 (page 158)
! screen parameters are in table 2 of Ref.3 (page 2026)
!
! gb1offset is given in table 2 (page 2026) and used in eq.4b (page 2021) of Ref.3
! gb1psi(atom) = (radius(atom) - gb1offset)*Coulomb_integral (eq.4b, Ref.3)
!
! gb1alpha, gb1beta, gb1gamma are in table 2 (page 2026) and used in eq.4a (page 2021) of Ref.3
! for the calculation of the effective Born radii of atoms
!
! gb1sneck=Sneck is given in table 2 (page 2026, Ref.3), which is used to scale the Seck integral in eq 6 of Ref.2 (page 159)
!
! gb1mmat=d0, gb1dmat=m0 are given in table 3 (page 161) and used in eq.6 (page 159) to calculate
! the neck integral and its derivative (Ref.2)

contains

subroutine gb_initialize()
  logical :: iffind
  integer :: i,iatom,ires

  if ( procid == 0 ) then
     write(iosiminfo,"(/,20x,a)") "Simulation Model"
     write(iosiminfo,"(a)") "============================================================="
     write(iosiminfo,"(a26,2i4)")     "GB and GBSA model         ",igb,igbsa
     write(iosiminfo,"(a26,f8.3)")    "Salt concentration        ",saltcon
     write(iosiminfo,"(a26,f8.3)")    "Distance cutoff           ",discut
     if ( igb == 0 .and. igbsa > 0 ) call errormsg("igbsa can not be positive when igb=0",int1=igb,int2=igbsa)
  end if

  allocate(fsrho(natom),radeff(natom),gbfrccoef(natom))
  fsrho=0d0; radeff=0d0; gbfrccoef=0d0

  allocate(radoff(natom)); radoff=0d0

  if ( igb == -1 ) then

     radoff(:) = radius(:) - offset

  else if ( igb == 1 ) then

! The GBNeck2 parameters have been presented in the reference papers.
! However, the same parameters in AMBER have more digits after the decimal place.
! For example, the parameter Sneck(gb1sneck) is 0.827 in the paper and it is 0.826836 in AMBER.

! In FSATOOL, subroutine parmdata_gb1_amber() contains the GBNeck2 parameters from AMBER and subroutine parmdata_gb1_reference_paper() contains the same parameters from the reference papers.

     call parmdata_gb1_amber()
!    call parmdata_gb1_reference_paper()

     radoff(:) = radius(:) - gb1offset

  end if

! Multiple Time Step (MTS) method (RESPA) in Ref.5, Eq.26. (page 6887)
! It decomposes the original force into the "long-range" and the "short-range" force.
! The "short" force is updated at every step and the "long" force is updated at "respastep".
! In Ref.5, F_long(r)=[1-S(r)]*F(r), F_short=S(r)*F(r), here S(r) is a smooth function between r and rc
! Here we follow the steps in AMBER, which is different to Ref.5
  discutrespa = 8.0d0

! Eq.4 in Ref.1 (page 2490)
  fsrho(:) = screen(:)*radoff(:)
  fsrhomax=0d0; do i=1,natom; if ( fsrho(i) > fsrhomax ) fsrhomax=fsrho(i); end do

  ! kappa = sqrt(2*I*NA*e^2/(solvent_eps*kB*temperature))
  kappa = sqrt(0.10806d0*saltcon)
  kappa = 0.73d0*kappa

! SASA parameters in Ref.4
  surften = 0.005d0
  if ( igbsa == 1 )  call parmdata_gbsa()

end subroutine

subroutine gb_potforce(tpcoor,tppot,tpfrc,check)
  real*8,intent(in) :: tpcoor(:,:)
  real*8,intent(out) :: tppot
  real*8,intent(out),optional :: tpfrc(:,:)
  logical,intent(in),optional :: check
  integer :: i
  real*8 :: tppot2,tppot3,tppot4
  real*8,dimension(:,:),allocatable :: tptpfrc
  logical :: ifcheck

  ifcheck=.false.
  if ( present(check) ) then
     if ( check .eqv. .true. ) then
        ifcheck=.true.; allocate(tptpfrc(3,natom)); tptpfrc=0d0
     end if
  end if

  if ( present(tpfrc) ) tpfrc=0d0
  tppot=0d0; tppot2=0d0; tppot3=0d0; tppot4=0d0
  call gb_potforce_elecvdw(tpcoor,tppot,tppot2,tppot3,tppot4,tpfrc=tpfrc)
  eelec=tppot; evdw=tppot2; egb=tppot3; egbsa=tppot4
  if ( ifcheck .eqv. .true. ) then
     tptpfrc = tptpfrc + tpfrc; print *
     call ambertop_checkforce("elec ",eelec,tpfrc); tpfrc=0d0
     call ambertop_checkforce("vdw ",evdw,tpfrc); tpfrc=0d0
     call ambertop_checkforce("gb ",egb,tpfrc); tpfrc=0d0
     call ambertop_checkforce("gbsa ",egbsa,tpfrc); tpfrc=0d0
  end if

  call ambertop_potforce_elecvdw14(tpcoor,tppot,tppot2,tpfrc=tpfrc)
  eelec14=tppot; evdw14=tppot2
  if ( ifcheck .eqv. .true. ) then
     tptpfrc = tptpfrc + tpfrc
     call ambertop_checkforce("elec14 ",eelec14,tpfrc); tpfrc=0d0
     call ambertop_checkforce("vdw14 ",evdw14,tpfrc); tpfrc=0d0
  end if

  call ambertop_potforce_bond(tpcoor,tppot,tpfrc=tpfrc); ebond=tppot
  if ( ifcheck .eqv. .true. ) then
     tptpfrc = tptpfrc + tpfrc
     call ambertop_checkforce("bond ",ebond,tpfrc); tpfrc=0d0
  end if

  call ambertop_potforce_angle(tpcoor,tppot,tpfrc=tpfrc); eangle=tppot
  if ( ifcheck .eqv. .true. ) then
     tptpfrc = tptpfrc + tpfrc
     call ambertop_checkforce("angle ",eangle,tpfrc); tpfrc=0d0
  end if

  if ( ifcheck .eqv. .true. ) tpfrc=0d0
  call ambertop_potforce_dihedral(tpcoor,tppot,tpfrc=tpfrc); edihe=tppot
  if ( ifcheck .eqv. .true. ) then
     tptpfrc = tptpfrc + tpfrc
     call ambertop_checkforce("dihe ",edihe,tpfrc); tpfrc=0d0
  end if

  tppot = eelec+evdw+eelec14+evdw14+ebond+eangle+edihe+egb+egbsa
  if ( ifcheck .eqv. .true. ) then
     tpfrc=tptpfrc
     print *; call ambertop_checkforce("total ",tppot,tpfrc)
  end if

end subroutine

subroutine gb_potforce_elecvdw(tpcoor,tpelec,tpvdw,tpgb,tpgbsa,tpfrc,tpsasa,tprespairdecomp,tpatompairdecomp,tpgbrespairdecomp,tpgbatompairdecomp)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpelec,tpvdw,tpgb,tpgbsa
  real*8,intent(inout),optional :: tpfrc(3,natom)
  real*8,intent(out),optional :: tpsasa
  real*8,intent(out), optional :: tprespairdecomp(:,:), tpatompairdecomp(:,:)
  real*8,intent(out), optional :: tpgbrespairdecomp(:,:), tpgbatompairdecomp(:,:)
  integer :: ires,jres,iatom,jatom,lastiexc,tpnexc,index,itype,jtype,i,j,iofile,imol
  real*8 :: tpvec(3),iq,jq,icoor(3),jcoor(3),tpvalue
  real*8 :: qq,dissqinv,disinv,dis6inv,dis12inv,dissq
  logical :: ifskipatoms(0:natom),ifhit

  real*8 :: coef1,coef2,coef3,frccoef,fgb,radij,expdij
  real*8 :: temp,epsininv,epsoutinv,fgbinv
  real*8 :: iradius,jradius,iradinv,gbdiscutsq,gbdiscutinv,gbdiscutsqinv,jrad,irad,ifsrho,ifsrhosq,jfsrho,jfsrhosq,jradinv,dis
  real*8 :: dadr,tpfrcvec(3),tpcoorvec(3),sigma,epsilon,cutoff
  real*8 :: disbias,disbias2,disbias3,disbias5,disbias6,dpar,mpar,tanhi,derivative_tanhi,tanhj,derivative_tanhj
  real*8,parameter :: ca=4d0/3d0, cb=12d0/5d0, cc=24d0/7d0, cd=40d0/9d0, ce=60d0/11d0
  real*8,dimension(natom) :: dgbda     ! dgbda = d(gb)/d(ai^-1)   ! ai: effective Born radius
integer :: mres,kres


  if ( igb /= 0 ) then
     call gb_radeffborn(tpcoor)
     dgbda=0d0; gbdiscutsq = (gbdiscut+fsrhomax)**2; gbdiscutinv=1d0/gbdiscut; gbdiscutsqinv=gbdiscutinv**2
  end if

  if ( present(tprespairdecomp) ) tprespairdecomp = 0d0
  if ( present(tpatompairdecomp) ) tpatompairdecomp = 0d0
  if ( present(tpgbrespairdecomp) ) tpgbrespairdecomp = 0d0
  if ( present(tpgbatompairdecomp) ) tpgbatompairdecomp = 0d0

  lastiexc=0; tpelec=0d0; tpvdw=0d0; tpgb=0d0; tpgbsa=0d0; epsoutinv=1d0/epsout; epsininv=1d0/epsin

  do iatom=1,natom-1

     ifskipatoms(iatom+1:natom)=.false.; tpnexc = nexcludedatoms(iatom)
     ifskipatoms(excludedatomlist(lastiexc+1:lastiexc+tpnexc))=.true.; lastiexc = lastiexc + tpnexc 

     iq = charge(iatom); if ( iq == 0.0d0 ) cycle
     itype = typeindex(iatom); icoor(1:3) = tpcoor(1:3,iatom); tpfrcvec=0.0d0
     ires = atomres(iatom)
     if ( igb /= 0 ) irad=radeff(iatom)

     do jatom=iatom+1,natom

        jq = charge(jatom); if ( jq == 0.0d0 ) cycle
        jtype = typeindex(jatom); tpcoorvec(1:3) = icoor(1:3) - tpcoor(1:3,jatom)
        jres = atomres(jatom)
        dissq = dot_product(tpcoorvec,tpcoorvec)

        if ( dissq > discut**2 ) cycle
        if ( (mod(nowstep,respastep) /= 0) .and. (dissq > discutrespa**2) ) cycle

        dis=sqrt(dissq); disinv=1.0/dis
        dissqinv=disinv*disinv; frccoef=0.0; qq=charge(iatom)*charge(jatom)

        if ( igb /= 0 ) then
           jrad = radeff(jatom); radij=irad*jrad
           expdij = exp(-dissq/(4d0*radij))                ! exp(-rij^2/[4*ai*aj])=exp(-Dij)
           fgb = sqrt(dissq + radij*expdij)                ! sqrt(rij^2 + ai*aj*exp(-Dij)) = f_GB

           if ( kappa == 0d0 ) then
              coef1 = 0d0; coef2 = epsininv - epsoutinv
           else
              coef2 = epsoutinv*exp(-kappa*fgb)            ! exp(-kappa*f_GB)/eps_out
              coef1 = -kappa*fgb*coef2                     ! -kappa*f_GB*exp(-kappa*f_GB)/eps_out
              coef2 = epsininv - coef2                     ! 1/eps_in - exp(-kappa*f_GB)/esp_out
           end if
           fgb = 1d0/fgb; tpvalue = -qq*coef2*fgb
           tpgb = tpgb + tpvalue

           if ( present(tpgbrespairdecomp) ) then
              temp = tpvalue/2d0
              if ( ires == jres ) temp=temp*2d0
              tpgbrespairdecomp(ires,jres) = tpgbrespairdecomp(ires,jres) + temp
           end if
           if ( present(tpgbatompairdecomp) ) then
              temp = tpvalue/2d0
              tpgbatompairdecomp(iatom,jatom) = temp
              tpgbatompairdecomp(jatom,iatom) = temp
           end if

           if ( present(tpfrc) .eqv. .true. ) then
! -qi*qj/f_GB^3*[ 1/epsin - exp(-kappa*f_GB)/epsout) - kappa*f_GB*exp(-kappa*f_GB)/epsout ]
              coef1 = -qq*(coef1+coef2)*(fgb**3)
              frccoef = coef1*(1d0 - 0.25d0*expdij)

              coef2 = 0.5d0*expdij*coef1*(radij + 0.25d0*dissq)
              dgbda(iatom) = dgbda(iatom) + irad*coef2
              dgbda(jatom) = dgbda(jatom) + jrad*coef2
           end if

! SASA energy in Ref.4, eq(5) (page 5801)
           if ( igbsa == 1 ) then
              if ( (gb1sigma(iatom) /= 0d0) .and. (gb1sigma(jatom) /= 0d0) ) then
                 cutoff = gb1cutoff(iatom)+gb1cutoff(jatom)
                 if ( dis < cutoff ) then
                    sigma = gb1sigma(iatom)+gb1sigma(jatom)
                    epsilon = sqrt(gb1epsilon(iatom)*gb1epsilon(jatom))
!                   tpgbsa = tpgbsa + epsilon + epsilon*gb1c1/(1d0+(cutoff-dis)/sigma)**gb1m -  &
!                                               epsilon*gb1c2/(1d0+(cutoff-dis)/sigma)**gb1n
                    coef3 = 1d0+(cutoff-dis)/sigma
                    coef1=coef3**2; coef2=coef1**2; coef1=(coef2**2)*coef1
                    tpgbsa = tpgbsa + 2.0d0*(epsilon + epsilon*(gb1c1/coef1 - gb1c2/coef2))
                    if ( present(tpfrc) ) then
                       frccoef = frccoef + (1.2d0*surften*epsilon/(coef3*sigma*dis))*  &
                                                      (10.0d0*gb1c1/coef1 - 4.0d0*gb1c2/coef2)
                    end if
                 end if
              end if
           end if
        end if

        if ( ifskipatoms(jatom) .eqv. .false. ) then
! calculate the electrostatic energy
           coef1 = qq*disinv
           tpelec = tpelec + coef1

! calculate the van der Waals energy
           index = nonbondedparmindex(nvdwtype*(itype-1) + jtype)
           dis6inv = dissqinv**3
           qq = vdwacoef(index)*dis6inv*dis6inv
           coef2 = qq - vdwbcoef(index)*dis6inv
           tpvdw = tpvdw + coef2
           if ( present(tpfrc) ) frccoef = frccoef + (coef1+6.0*(qq + coef2))*dissqinv

           if ( present(tprespairdecomp) ) then
              temp = (coef1 + coef2)/2d0
              if ( ires == jres ) temp = temp*2d0
              tprespairdecomp(ires,jres) = tprespairdecomp(ires,jres) + temp
           end if
           if ( present(tpatompairdecomp) ) then 
              temp = (coef1 + coef2)/2d0
              tpatompairdecomp(iatom, jatom) = temp
              tpatompairdecomp(jatom, iatom) = temp
           end if

        end if

        if ( (mod(nowstep,respastep)==0) .and. (dissq > discutrespa**2) ) frccoef = frccoef*dble(respastep)

        if ( present(tpfrc) ) then
           tpvec(1:3) = frccoef*tpcoorvec(1:3)
           tpfrcvec(1:3) = tpfrcvec(1:3) + tpvec(1:3)
           tpfrc(1:3,jatom) = tpfrc(1:3,jatom) - tpvec(1:3)
        end if
     end do
     if ( present(tpfrc) ) tpfrc(1:3,iatom) = tpfrc(1:3,iatom) + tpfrcvec(1:3)
  end do

  if ( present(tprespairdecomp) ) then
     do ires = 1, nres
        do jres = ires+1, nres
           tprespairdecomp(jres,ires) = tprespairdecomp(ires,jres)
        end do
     end do
  end if

  if ( igb == 0 ) return
  if ( mod(nowstep,respastep) /= 0 ) return

! molecular surface in Ref.4, Eq.S6-S11
  if ( igbsa == 1 ) then
     tpgbsa=surften*(gb1maxsum*0.6814d0 + 361.1d0 - tpgbsa*0.6d0)
     if ( present(tpsasa) ) tpsasa = gb1maxsum*0.6814d0 + 361.1d0 - tpgbsa*0.6d0
  end if

  do iatom=1,natom
     iq = charge(iatom); if ( iq == 0.0d0 ) cycle
     irad = radeff(iatom)
     temp = 0.5*iq**2            !  0.5*qi*qi
     coef1 = exp(-kappa*irad)*epsoutinv     !  exp(-kappa*ai)/epsout
     coef2 = temp*(epsininv - coef1)        !  0.5*qi*qi*(1/eps_in - exp(-kappa*ai)/epsout)
     tpvalue = - coef2/irad
     tpgb = tpgb + tpvalue
     gbfrccoef(iatom) = -dgbda(iatom) + coef2 - kappa*temp*coef1*irad

     if ( present(tpgbrespairdecomp) ) then
        ires = atomres(iatom)
        tpgbrespairdecomp(ires,ires) = tpgbrespairdecomp(ires,ires) + tpvalue
     end if
     if ( present(tpgbatompairdecomp) ) then
        tpgbatompairdecomp(iatom,iatom) = tpvalue
     end if
  end do
  if ( present(tpgbrespairdecomp) ) then
     do ires = 1, nres
        do jres = ires+1, nres
           tpgbrespairdecomp(jres,ires) = tpgbrespairdecomp(ires,jres)
        end do
     end do
  end if

  if ( .not. present(tpfrc) ) return

  do iatom=1,natom

     iradius = radius(iatom); if ( iradius == 0.0d0 ) cycle
     tpfrcvec(1:3) = 0d0; irad = radoff(iatom)
     ifsrho=fsrho(iatom); ifsrhosq=ifsrho*ifsrho; icoor(1:3) = tpcoor(1:3,iatom)

     if ( igb == 1 ) then
! tanh(alpha*psi-beta*psi^2+gamma*psi^3) in eq.4 of Ref.2 (page 158)
        tanhi=tanh((gb1alpha(iatom)+gb1gamma(iatom)*gb1psi(iatom)**2-gb1beta(iatom)*   &
                gb1psi(iatom))*gb1psi(iatom))
! derivative of tanh in eq.4 
        derivative_tanhi=(gb1alpha(iatom)+3d0*gb1gamma(iatom)*gb1psi(iatom)**2-        &
                2d0*gb1beta(iatom)*gb1psi(iatom))*(1d0-tanhi**2)*radoff(iatom)/iradius
     end if

     do jatom=iatom+1,natom
        jradius = radius(jatom); if ( jradius == 0.0d0 ) cycle
        tpcoorvec(1:3) = icoor(1:3) - tpcoor(1:3,jatom)
        dissq = dot_product(tpcoorvec,tpcoorvec); if ( dissq > gbdiscutsq ) cycle
        disinv=1d0/sqrt(dissq); dissqinv=disinv*disinv; dis=disinv*dissq
        jfsrho=fsrho(jatom); jfsrhosq=jfsrho*jfsrho
        jrad = radoff(jatom)

! dadr = (1/r)(d(ai^-1)/dr),   here ai is effective Born radius of atom i, r is atom-atom distance

! distance division as in NAMD (explained in NAMD user's guide)
! https://www.ks.uiuc.edu/Research/namd/2.14/ug/node31.html

! sphere j partially within cutoff
        if ( dis <= (gbdiscut + jfsrho) ) then
        if ( dis > (gbdiscut - jfsrho) ) then
           coef1 = 1d0 /(dis-jfsrho)
           dadr = 0.125d0*dissqinv*disinv*((dissq + jfsrhosq)*(coef1**2 - gbdiscutsqinv) - 2d0*log(gbdiscut*coef1))
! artifical regime for smoothing (Taylor series of Hij III)
        else if ( dis > 4d0*jfsrho) then
           coef1 = jfsrhosq*dissqinv
           coef2 = ca + coef1*(cb + coef1*(cc + coef1*(cd + coef1*ce)))
           dadr = coef1*jfsrho*dissqinv*dissqinv*coef2
! spheres not overlapping
        else if ( dis > (irad + jfsrho) ) then
           coef1 = 1d0/(dissq - jfsrhosq)
           coef2 = log((dis - jfsrho)/(dis + jfsrho))
           dadr = coef1*jfsrho*(-0.5d0*dissqinv + coef1) + 0.25d0*dissqinv*disinv*coef2
! spheres overlapping
        else if ( dis > abs(irad - jfsrho) ) then
           coef1 = dissqinv*disinv
           coef2 = 1d0/(dis + jfsrho)
           dadr = -0.25d0*(-0.5d0*(dissq - irad**2 + jfsrhosq)*coef1/(irad**2) + &
                          disinv*coef2*(coef2 - disinv) - coef1*log(irad*coef2))
! sphere i inside sphere j
        else if ( irad < jfsrho ) then
           coef1 = 1d0/(dissq - jfsrhosq)
           coef2 = log((jfsrho - dis)/(dis + jfsrho))
           dadr = -0.5d0*(jfsrho*dissqinv*coef1 - 2d0*jfsrho*coef1*coef1 - 0.5d0*dissqinv*disinv*coef2)
! sphere j inside sphere j
        else
           dadr = 0.0d0
        end if

        if ( igb == 1 ) then
           if ( dis < ( iradius+jradius+gb1watrad ) ) then   
              i = nint((iradius-0.95d0)/0.05d0)
              j = nint((jradius-0.95d0)/0.05d0)
! gb1dmat,gb1mmat (d0,m0) in eq.6 of Ref.2 (page 159) 
              dpar = gb1dmat(i,j); mpar = gb1mmat(i,j)
! disbias=d-d0, disbias2=(d-d0)^2, disbias6=(d-d0)^6 (eq.7, Ref.2, page 159)
              disbias=dis-dpar; disbias2=disbias*disbias; disbias3=disbias2*disbias
              disbias5=disbias3*disbias2; disbias6=disbias3*disbias3
! dadr=dadr+neck_integral'(d)*gb1sneck/d, eq.7, Ref.2
              dadr = dadr + (((2d0*disbias+(9d0/5d0)*disbias5)*mpar )*gb1sneck)/    &
                                 ((1d0+disbias2+0.3d0*disbias6)**2*dis )
           end if
! dR/dr=(dR/dI)*(dI/dr), I=integral((r^-4)dV), eq.4 and eq.5, Ref.2
           dadr=dadr*derivative_tanhi
        end if
  
        dadr = dadr*dble(respastep)
        tpvec(1:3) = dadr*gbfrccoef(iatom)*tpcoorvec(1:3)
        tpfrcvec(1:3) = tpfrcvec(1:3) + tpvec(1:3)
        tpfrc(1:3,jatom) = tpfrc(1:3,jatom) - tpvec(1:3)
        end if

        if ( dis <= (gbdiscut + ifsrho) ) then
        if ( dis > (gbdiscut - ifsrho) ) then
           coef1 = 1d0 /(dis-ifsrho)
           dadr = 0.125d0*dissqinv*disinv*((dissq + ifsrhosq)*(coef1**2 - gbdiscutsqinv) - 2d0*log(gbdiscut*coef1))
        else if ( dis > 4d0*ifsrho) then
           coef1 = ifsrhosq*dissqinv
           coef2 = ca + coef1*(cb + coef1*(cc + coef1*(cd + coef1*ce)))
           dadr = coef1*ifsrho*dissqinv*dissqinv*coef2
        else if ( dis > (jrad + ifsrho) ) then
           coef1 = 1d0/(dissq - ifsrhosq)
           coef2 = log((dis - ifsrho)/(dis + ifsrho))
           dadr = coef1*ifsrho*(-0.5d0*dissqinv + coef1) + 0.25d0*dissqinv*disinv*coef2
        else if ( dis > abs(jrad - ifsrho) ) then
           coef1 = dissqinv*disinv
           coef2 = 1d0/(dis + ifsrho)
           dadr = -0.25d0*(-0.5d0*(dissq - jrad**2 + ifsrhosq)*coef1/(jrad**2) + &
                          disinv*coef2*(coef2 - disinv) - coef1*log(jrad*coef2))
        else if ( jrad < ifsrho ) then
           coef1 = 1d0/(dissq - ifsrhosq)
           coef2 = log((ifsrho - dis)/(dis + ifsrho))
           dadr = -0.5d0*(ifsrho*dissqinv*coef1 - 2d0*ifsrho*coef1*coef1 - 0.5d0*dissqinv*disinv*coef2)
        else
           dadr = 0.0d0
        end if

        if ( igb == 1 ) then
           if ( dis < ( iradius+jradius+gb1watrad ) ) then   
              i = nint((iradius-0.95d0)/0.05d0)
              j = nint((jradius-0.95d0)/0.05d0)
! gb1dmat,gb1mmat (d0,m0) in eq.6 of Ref.2 (page 159)
              dpar = gb1dmat(j,i); mpar = gb1mmat(j,i)
! disbias=d-d0, disbias2=(d-d0)^2, disbias6=(d-d0)^6 (eq.7, Ref.2, page 159)
              disbias=dis-dpar; disbias2=disbias*disbias; disbias3=disbias2*disbias
              disbias5=disbias3*disbias2; disbias6=disbias3*disbias3
! dadr=dadr+neck_integral'(d)*gb1sneck/d, eq.7, Ref.2
              dadr=dadr + (((2d0*disbias+(9d0/5d0)*disbias5)*mpar )*gb1sneck)/    &
                          ((1d0+disbias2+0.3d0*disbias6)**2*dis )
           end if
! tanh(alpha*psi-beta*psi^2+gamma*psi^3) in eq.4 of Ref.2 (page 158)
           tanhj=tanh((gb1alpha(jatom)+gb1gamma(jatom)*gb1psi(jatom)**2-gb1beta(jatom)*  &
                    gb1psi(jatom))*gb1psi(jatom))
! derivative of eq.4, Ref.2
           derivative_tanhj=(gb1alpha(jatom)+3d0*gb1gamma(jatom)*gb1psi(jatom)**2-  &
               2d0*gb1beta(jatom)*gb1psi(jatom))*(1d0-tanhj**2)*radoff(jatom)/jradius
! dR/dr=(dR/dI)*(dI/dr), I=integral((r^-4)dV), eq.4 and eq.5, Ref.2
           dadr = dadr*derivative_tanhj
        end if

        dadr = dadr*dble(respastep)
        tpvec(1:3) = dadr*gbfrccoef(jatom)*tpcoorvec(1:3)
        tpfrcvec(1:3) = tpfrcvec(1:3) + tpvec(1:3)
        tpfrc(1:3,jatom) = tpfrc(1:3,jatom) - tpvec(1:3)
        end if

     end do
     tpfrc(1:3, iatom) = tpfrc(1:3, iatom) + tpfrcvec(1:3)
  end do

end subroutine

subroutine gb_radeffborn(tpcoor, dradeffdI)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,optional,intent(out) :: dradeffdI(2,natom)
  character :: atom_type
  integer :: iatom,jatom,i,j,iofile,imol,tpmol
  real*8 :: icoor(3),jcoor(3),tpvec(3),dissq,gbdiscutsq,irad,jrad,ifsrho,jfsrho,disbias,disbias2,disbias6
  real*8 :: iradius,jradius,dis,radeffi,gbdiscutinv,gbdiscutsqinv,disinv,dissqinv,iradinv,jradinv,ifsrhosq,jfsrhosq,coef1,coef2
  real*8 :: neck_integral,dpar,mpar
  real*8,parameter :: ca=1d0/3d0,cb=2d0/5d0,cc=3d0/7d0,cd=4d0/9d0,ce=5d0/11d0
  logical :: ifhit

  radeff=0d0; gbdiscutsq = (gbdiscut+fsrhomax)**2
  gbdiscutinv = 1d0/gbdiscut; gbdiscutsqinv = gbdiscutinv**2
  do iatom=1, natom

     iradius = radius(iatom); if ( iradius == 0.0d0 ) cycle
     icoor(1:3) = tpcoor(1:3,iatom); irad = radoff(iatom); iradinv=1d0/irad
     ifsrho=fsrho(iatom); ifsrhosq=ifsrho**2; radeffi = radeff(iatom)
     
     do jatom=iatom+1, natom

        jradius = radius(jatom); if ( jradius == 0.0d0 ) cycle
        tpvec(1:3) = icoor(1:3) - tpcoor(1:3,jatom)
        dissq=dot_product(tpvec,tpvec); if ( dissq > gbdiscutsq ) cycle
        disinv=1d0/sqrt(dissq); dis=disinv*dissq; dissqinv=disinv**2
        jfsrho=fsrho(jatom)
        jrad=radoff(jatom); jradinv=1d0/jrad

        if ( dis <= (gbdiscut + jfsrho) ) then
           if ( dis > (gbdiscut - jfsrho) ) then
              radeffi = radeffi - 0.125d0*disinv*( 1.0d0 + 2.0d0*dis/(dis-jfsrho) + &
                      gbdiscutsqinv * (dissq - 4.0d0*gbdiscut*dis - jfsrho**2) + &
                      2.0d0*log((dis - jfsrho)*gbdiscutinv)   )
           else if ( dis > 4.0d0*jfsrho) then
              coef1 = jfsrho*jfsrho*dissqinv
              coef2 = ca + coef1*(cb+coef1*(cc + coef1*(cd + coef1*ce)))
              radeffi = radeffi - coef1*jfsrho*dissqinv*coef2
           else if ( dis > (irad + jfsrho) ) then
              coef1 = log((dis-jfsrho)/(dis+jfsrho))
              radeffi = radeffi - 0.5d0*(jfsrho/(dissq - jfsrho**2) + 0.5d0*disinv*coef1)
           else if ( dis > abs(irad - jfsrho)) then
              coef1 = 0.5d0*iradinv*disinv*(dissq + irad**2 - jfsrho**2)
              coef2 = 1.0d0/(dis+jfsrho)
              radeffi = radeffi - 0.25d0*(iradinv*(2.0d0 - coef1) - coef2 + disinv*log(irad*coef2))
           else if (irad < jfsrho) then
              coef1 = log((jfsrho-dis)/(dis+jfsrho))
              radeffi = radeffi - 0.5d0*(jfsrho/(dissq - jfsrho**2) + 2.0d0*iradinv + 0.5d0*disinv*coef1)
           end if
  
           if ( igb == 1 ) then
              if ( dis < ( iradius+jradius+gb1watrad ) ) then   
                 i = nint((iradius-0.95d0)/0.05d0); j = nint((jradius-0.95d0)/0.05d0)
                 dpar = gb1dmat(i,j); mpar = gb1mmat(i,j)
                 disbias=dis-dpar; disbias2=disbias*disbias; disbias6=disbias2*disbias2*disbias2
! inv_eff_R = inv_eff_R - gb1sneck*neck_integral ( eq.5, Ref.2, page 158)
! here neck_integer=mpar/(1+disbias2+0.3d0*disbias6) (eq.6, Ref.2, page 159)
                 radeffi=radeffi-gb1sneck*(mpar/(1.0d0+disbias2+0.3d0*disbias6))
              end if
           end if
        
        end if

        if ( dis <= (gbdiscut + ifsrho) ) then
           if ( dis > (gbdiscut - ifsrho) ) then
              radeff(jatom) = radeff(jatom) - 0.125*disinv*( 1.0d0 + 2.0d0*dis/(dis-ifsrho) + &
                                 gbdiscutsqinv*(dissq - 4.0d0*gbdiscut*dis - ifsrho**2) + &
                                 2.0d0*log((dis - ifsrho)*gbdiscutinv) )
           else if ( dis > 4.0d0*ifsrho) then
              coef1 = ifsrho*ifsrho*dissqinv
              coef2 = ca + coef1*(cb+coef1*(cc + coef1*(cd + coef1*ce)))
              radeff(jatom) = radeff(jatom) - coef1*ifsrho*dissqinv*coef2
           else if ( dis > (jrad + ifsrho) ) then
              coef1 = log((dis-ifsrho)/(dis+ifsrho))
              radeff(jatom) = radeff(jatom) - 0.5d0*(ifsrho/(dissq - ifsrho**2) +0.5d0*disinv*coef1)
           else if ( dis > abs(jrad - ifsrho)) then
              coef1 = 0.5d0*jradinv*disinv*(dissq + jrad**2 - ifsrho**2)
              coef2 = 1.0d0/(dis + ifsrho)
              radeff(jatom) = radeff(jatom) - 0.25d0*(jradinv*(2.0d0-coef1)-coef2 + disinv*log(jrad*coef2))
           else if (jrad < ifsrho) then
              coef1 = log((ifsrho-dis)/(dis+ifsrho))
              radeff(jatom) = radeff(jatom)-0.5d0*(ifsrho/(dissq-ifsrho**2)+2.0d0*jradinv+0.5d0*disinv*coef1)
           end if

           if (igb == 1) then
              if ( dis < ( iradius+jradius+gb1watrad ) ) then   
                 i = nint((iradius-0.95d0)/0.05d0); j = nint((jradius-0.95d0)/0.05d0)
                 dpar = gb1dmat(j,i); mpar = gb1mmat(j,i)
                 disbias=dis-dpar; disbias2=disbias*disbias; disbias6=disbias2*disbias2*disbias2
! inv_eff_R = inv_eff_R - gb1sneck*neck_integral ( eq.5, Ref.2, page 158)
! here neck_integer=mpar/(1+disbias2+0.3d0*disbias6) (eq.6, Ref.2, page 159)
                 radeff(jatom)=radeff(jatom)-gb1sneck*(mpar/(1.0d0+disbias2+0.3d0*disbias6))
              end if
           end if
        end if
     end do

     radeff(iatom) = radeffi
         
  end do

  if ( igb == -1 ) then 

     do iatom=1, natom
        iradius = radius(iatom); if ( iradius == 0.0d0 ) cycle
        irad = radoff(iatom)
        radeff(iatom) = irad/( radeff(iatom)*irad + 1.0d0 )
     end do

  else if ( igb == 1 ) then

     do iatom=1, natom
        iradius = radius(iatom); if ( iradius == 0.0d0 ) cycle
        irad = radoff(iatom)
        ! gb1psi(atom) = (radius(atom) - offset)*Coulomb_integral (eq.4b, Ref.3)
        gb1psi(iatom)=-radeff(iatom)*irad
        ! Eq.4a in Ref.3 (page 2021)
        coef1 = tanh(gb1alpha(iatom)*gb1psi(iatom)-gb1beta(iatom)*(gb1psi(iatom)**2)+gb1gamma(iatom)*(gb1psi(iatom)**3))
        ! Eq.4a in Ref.3 (page 2021)
        radeff(iatom)=(irad*iradius)/(iradius-irad*coef1)
        if (present(dradeffdI)) then
           ! dradeffdI(:,natom) -> dradeff, d2radeff
           coef2 = gb1alpha(iatom) - 2d0*gb1beta(iatom)*gb1psi(iatom) + 3d0*gb1gamma(iatom)*(gb1psi(iatom)**2)
           dradeffdI(1,iatom) = radeff(iatom) * irad/iradius*(1-coef1**2)*coef2
           dradeffdI(2,iatom) = - radeff(iatom) * irad**2/iradius*(1-coef1**2) * &
              2d0*(3d0*gb1gamma(iatom)*gb1psi(iatom) - gb1beta(iatom) - coef1*coef2**2)
        endif
     end do
  end if

end subroutine

end module
