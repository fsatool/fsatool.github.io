module cudagb
  use pubmod; use ambertop; use cudatop
  implicit none
  integer,private :: blocknbdim
  integer,device,private :: blocknbdim_d
  integer,device,dimension(:),allocatable,private :: excludedatomindex_d
  integer,device,dimension(:,:),allocatable,private :: blocknbskip_d,blocknbpos_d
  real*8,device,dimension(:),allocatable :: dgbda_d,radeff_d
  real*8,device,private :: egb_d

  real,device,private :: epsin_d,epsout_d,gbdiscut_d,gbdiscutinv_d,gbdiscutsq_d,gbdiscutsqinv_d,kappa_d
  real,device,private :: epsininv_d,epsoutinv_d
  real,device,dimension(:),allocatable,private :: halfqq_d
  real,device,dimension(:),allocatable :: radoff_d,fsrho_d

  real,device,dimension(:),allocatable,private :: blockpotgb_d
  real,device,dimension(:,:),allocatable,private :: blockradeff_d,blockdgbda_d

! parameters for igb=1
  integer,device,dimension(:),allocatable,private :: gb1radbin_d
  real,device,private :: gb1watrad_d,gb1sneck_d
  real,device,dimension(21,21),private :: gb1dmat_d,gb1mmat_d
  real,device,dimension(:),allocatable :: gb1alpha_d,gb1beta_d,gb1gamma_d,gb1psi_d

! parameters for igbsa=1
  real,device :: gb1maxsum_d
  real,device :: surften_d
  real,device,allocatable,dimension(:) :: gb1cutoff_d,gb1sigma_d,gb1epsilon_d
contains

! collect the arrays for the nonboned and gb energy calculation on GPU
subroutine cudagb_initialize()
  use gb
  integer :: iatom,tpi,tpnum,i,j,idihe,index,iangle,ibond,iblock
  integer :: excludedatomindex(natom+1)
  integer,dimension(:,:),allocatable :: blockpos
  integer,dimension(:),allocatable :: gpufrcindex,gpufrcposbond,gpufrcposangle,gpufrcposdihe,gpufrcposnb14

  igb_d=igb; igbsa_d=igbsa
  blocknbdim=(natom-1)/cudathread+1; blocknbdim_d=blocknbdim
  nblocknb=blocknbdim*(1+blocknbdim)/2; nblocknb_d=nblocknb
  allocate(blocknbpos_d(2,nblocknb),blockpos(2,nblocknb)); blockpos=1
  do i=2,nblocknb
     blockpos(1,i)=blockpos(1,i-1); blockpos(2,i)=blockpos(2,i-1)+cudathread
     if ( blockpos(2,i) > natom ) then
        blockpos(1,i)=blockpos(1,i-1)+cudathread; blockpos(2,i)=blockpos(1,i)
        if ( blockpos(1,i) > natom ) exit
     end if
  end do
  blocknbpos_d=blockpos 

  excludedatomindex=0; i=0
  do iatom=1,natom
     i = i + nexcludedatoms(iatom)
     excludedatomindex(iatom+1) = i
  end do
  allocate(excludedatomindex_d(natom+1)); excludedatomindex_d = excludedatomindex

  allocate(blocknbskip_d(3,nblocknb*cudathread)); blocknbskip_d=0
  call cudagb_potforce_nonbond_init<<<nblocknb_d,cudathread>>>()

  if ( ifblocksum .eqv. .true. ) then
     allocate(blockpotelec_d(nblocknb),blockpotvdw_d(nblocknb)); blockpotelec_d=0.0; blockpotvdw_d=0.0
     allocate(blockpotgb_d(nblocknb)); blockpotgb_d=0.0
     allocate(blockradeff_d(blocknbdim,natom)); blockradeff_d=0.0
     allocate(blockdgbda_d(blocknbdim,natom)); blockdgbda_d=0.0
     allocate(gpufrcindex(natom+1),gpufrcindex_d(natom+1)); gpufrcindex=0; gpufrcindex_d=0

     i=nbond*2+nangle*3+ndihegroup*4+nnb14*2+blocknbdim*natom
     if ( igb /= 0 ) i = i + (blocknbdim-1)*natom
     allocate(gpufrc_d(3,i)); gpufrc_d=0.0
     i=2*nbond; allocate(gpufrcposbond(i),gpufrcposbond_d(i)); gpufrcposbond=0; gpufrcposbond_d=0
     i=3*nangle; allocate(gpufrcposangle(i),gpufrcposangle_d(i)); gpufrcposangle=0; gpufrcposangle_d=0
     i=4*ndihegroup; allocate(gpufrcposdihe(i),gpufrcposdihe_d(i)); gpufrcposdihe=0; gpufrcposdihe_d=0
     i=2*nnb14; allocate(gpufrcposnb14(i),gpufrcposnb14_d(i)); gpufrcposnb14=0; gpufrcposnb14_d=0
     tpnum = 0
     do iatom=1,natom
        i=blocknbdim; if ( igb /= 0 ) i=i+blocknbdim-1
        tpnum=tpnum+i
        do idihe=1,nnb14
           if ( iatom == nonbond14(1,idihe) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposnb14(2*idihe-1)=i
           else if ( iatom == nonbond14(2,idihe) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposnb14(2*idihe)=i
           end if
        end do
        do idihe=1,ndihegroup
           j=dihegroupindex(idihe)+1
           if ( iatom == diheatom(5*j-4) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposdihe(4*idihe-3)=i
           else if ( iatom == diheatom(5*j-3) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposdihe(4*idihe-2)=i
           else if ( iatom == diheatom(5*j-2) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposdihe(4*idihe-1)=i
           else if ( iatom == diheatom(5*j-1) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposdihe(4*idihe)=i
           end if
        end do
        do iangle=1,nangle
           if ( iatom == angleatom(4*iangle-3) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposangle(3*iangle-2)=i
           else if ( iatom == angleatom(4*iangle-2) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposangle(3*iangle-1)=i
           else if ( iatom == angleatom(4*iangle-1) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposangle(3*iangle)=i
           end if
        end do
        do ibond=1,nbond
           if ( iatom == bondatom(3*ibond-2) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposbond(2*ibond-1)=i
           else if ( iatom == bondatom(3*ibond-1) ) then
              tpnum = tpnum + 1; i = i + 1; gpufrcposbond(2*ibond)=i
           end if
        end do
        gpufrcindex(iatom+1)=tpnum
     end do
     gpufrcposbond_d=gpufrcposbond; gpufrcposangle_d=gpufrcposangle; gpufrcposdihe_d=gpufrcposdihe
     gpufrcposnb14_d=gpufrcposnb14; gpufrcindex_d=gpufrcindex
  end if
 
  if ( igb == 0 ) then
     return
  else
     if ( .not. allocated(fsrho) ) call gb_initialize()
  end if

  egb_d=0.0; epsin_d=epsin; epsout_d=epsout; epsininv_d=1.0/epsin; epsoutinv_d=1.0/epsout
  gbdiscut_d=gbdiscut; gbdiscutinv_d = 1.0/gbdiscut; gbdiscutsqinv_d = (1.0/gbdiscut)**2

  if ( saltcon > 0.0 ) kappa_d=kappa

  allocate(halfqq_d(natom))
  do i=1,natom
     halfqq_d(i)=0.5*charge(i)**2
  end do

  allocate(radoff_d(natom),fsrho_d(natom),radeff_d(natom),dgbda_d(natom))
  radoff_d=radoff; fsrho_d=fsrho; radeff_d=0d0; dgbda_d=0d0
  gbdiscutsq_d=(gbdiscut+fsrhomax)**2

  if ( igb == 1 ) then
     gb1watrad_d=gb1watrad; gb1sneck_d=gb1sneck
     allocate(gb1radbin_d(natom)); gb1radbin_d = nint((radius(:)-0.95d0)*20.0d0) 
     gb1dmat_d=gb1dmat; gb1mmat_d=gb1mmat
     allocate(gb1alpha_d(natom),gb1beta_d(natom),gb1gamma_d(natom),gb1psi_d(natom))
     gb1alpha_d=gb1alpha; gb1beta_d=gb1beta; gb1gamma_d=gb1gamma
  end if

  if ( igbsa == 1 ) then
     gb1maxsum_d = gb1maxsum; surften_d = surften
     allocate(gb1cutoff_d(natom),gb1sigma_d(natom),gb1epsilon_d(natom))
     gb1cutoff_d=gb1cutoff; gb1sigma_d=gb1sigma; gb1epsilon_d=gb1epsilon
  end if

end subroutine

! calculate the all the energy terms and forces on GPU
subroutine cudagb_potforce()

  if ( ifblocksum .eqv. .false.) call cudagb_clear_force<<<nblockatom,cudathread>>>()

  if ( igb /= 0 ) then
     call cudagb_effectiveBorn<<<blocknbdim**2,cudathread>>>()
     call cudagb_effectiveBorn2<<<nblockatom,cudathread>>>()
  end if

  call cudagb_potforce_allterms<<<nblockbondedterm+nblocknb,cudathread>>>()

  if ( (igb /= 0) .and. (ifcalfrc .eqv. .true.) ) then
     call cudagb_potforce_gbfrc<<<blocknbdim*blocknbdim,cudathread>>>()
  end if
  if ( ifblocksum .eqv. .true. ) then
     if ( mod(nowstep,printcvstep) == 0 ) then
        call cudagb_potforce_sumfrc<<<(natom-1)/(cudathread/8)+8,cudathread,cudathread*24>>>()
        call cudagb_potforce_sumpot<<<1,1>>>()
     else
        call cudagb_potforce_sumfrc<<<(natom-1)/(cudathread/8)+1,cudathread,cudathread*24>>>()
     end if
  else
     if ( mod(nowstep,printcvstep) == 0 ) then
        call cudagb_potforce_sumpot<<<1,1>>>()
     end if
  end if
end subroutine

attributes(global) subroutine cudagb_potforce_allterms()
  integer :: iblock

  iblock=blockidx%x
  if ( iblock <= nblocknb_d ) then
     call cudagb_potforce_elecvdw(iblock)
  else
     iblock = iblock - nblocknb_d
     if ( iblock <= nblock14_d ) then
        call cudatop_potforce_elecvdw14(iblock)
     else
        iblock = iblock - nblock14_d
        if ( iblock <= nblockdihe_d ) then
           call cudatop_potforce_dihe(iblock)
        else
           iblock = iblock - nblockdihe_d
           if ( iblock <= nblockangle_d ) then
              call cudatop_potforce_angle(iblock)
           else
              iblock = iblock - nblockangle_d
              call cudatop_potforce_bond(iblock)
           end if
        end if
     end if
  end if
end subroutine

! sum of all the energy terms
attributes(global) subroutine cudagb_potforce_sumpot()
  epot_d = egb_d+eelec_d+evdw_d+enb14_d+ebond_d+eangle_d+edihe_d
  if ( igbsa_d == 1 ) epot_d = epot_d + surften_d*(gb1maxsum_d*0.6814 + 361.1)
end subroutine

! sum of the forces of the atoms in all the blocks
attributes(global) subroutine cudagb_potforce_sumfrc()
  integer :: iatom,i,ithread,iblock,nthread,ipart,nthreadperatom,blockedge
  real*8,shared :: threadfrc(3,blockdim%x)
  real*8 :: tppot

  ithread=threadidx%x; iblock=blockidx%x; nthread=blockdim%x
  blockedge=(natom_d-1)/(nthread/8)+1

  if ( iblock <= blockedge ) then

     nthreadperatom=8; ipart=(ithread-1)/nthreadperatom
     iatom=(iblock-1)*(nthread/nthreadperatom) + ipart + 1
     if ( iatom > natom_d ) return
     ipart=ithread-nthreadperatom*ipart; threadfrc(1:3,ithread)=0.0d0

     do i=gpufrcindex_d(iatom)+ipart,gpufrcindex_d(iatom+1),nthreadperatom
        threadfrc(1:3,ithread) = threadfrc(1:3,ithread) + gpufrc_d(1:3,i)
     end do

     call syncthreads()

     if (ipart == 1) then
        do i=1,3
           nowforce_d(i,iatom)=sum(threadfrc(i,ithread:ithread+nthreadperatom-1))
        end do
     end if

  else

     iblock = iblock - blockedge
     select case (iblock)
     case (1)
        call cudatop_vec_sumall(ithread,nthread,blockpotelec_d,nblocknb_d,tppot)
        if (ithread == 1) eelec_d=tppot
     case (2)
        call cudatop_vec_sumall(ithread,nthread,blockpotvdw_d,nblocknb_d,tppot)
        if (ithread == 1) evdw_d=tppot
     case (3)
        call cudatop_vec_sumall(ithread,nthread,blockpotnb14_d,nblock14_d,tppot)
        if (ithread == 1) enb14_d=tppot
     case (4)
        call cudatop_vec_sumall(ithread,nthread,blockpotbond_d,nblockbond_d,tppot)
        if (ithread == 1) ebond_d=tppot
     case (5)
        call cudatop_vec_sumall(ithread,nthread,blockpotangle_d,nblockangle_d,tppot)
        if (ithread == 1) eangle_d=tppot
     case (6)
        call cudatop_vec_sumall(ithread,nthread,blockpotdihe_d,nblockdihe_d,tppot)
        if (ithread == 1) edihe_d=tppot
     case (7)
        call cudatop_vec_sumall(ithread,nthread,blockpotgb_d,nblocknb_d,tppot)
        if (ithread == 1) egb_d=tppot
     end select

  end if
end subroutine

attributes(global) subroutine cudagb_clear_force()
  integer :: iatom

  iatom = (blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > natom_d ) return
  nowforce_d(1:3,iatom) = 0d0

  if ( igb_d /= 0 ) then
     radeff_d(iatom) = 0d0; dgbda_d(iatom) = 0d0
  end if

  if ( blockidx%x /= 1 ) return

  if ( ifcalpot_d ) then
     select case(threadidx%x)
       case(1); egb_d=0d0; case(2); eelec_d=0d0; case(3); evdw_d=0d0; case(4); enb14_d=0d0
       case(5); ebond_d=0d0; case(6); eangle_d=0d0; case(7); edihe_d=0d0
     end select
  end if
end subroutine

! sum of the effective Born radii of the atoms
attributes(global) subroutine cudagb_effectiveBorn2()
  integer :: iatom
  real :: iradoff
  real*8 :: tppsi,iradeff

  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > natom_d ) return
  iradoff = radoff_d(iatom)
  if ( ifblocksum_d ) then
     iradeff = sum(blockradeff_d(1:blocknbdim_d,iatom))
  else
     iradeff = radeff_d(iatom)
  end if   

  if ( igb_d == -1 ) then
     radeff_d(iatom)=iradoff/(iradeff*iradoff+1.0)
  else if ( igb_d == 1 ) then
     tppsi=-iradeff*iradoff; gb1psi_d(iatom)=tppsi
     tppsi=tanh(gb1alpha_d(iatom)*tppsi-gb1beta_d(iatom)*(tppsi**2)+gb1gamma_d(iatom)*(tppsi**3))
     radeff_d(iatom)= (iradoff*radius_d(iatom))/(radius_d(iatom) - iradoff*tppsi)
  end if
end subroutine

! prepare the excluded atom list in each block
attributes(global) subroutine cudagb_potforce_nonbond_init()
  integer :: i,j,iatom,jatom,iatomstart,iatomend,jatomstart,jatomend,ithread,iblock,index,nthread
  integer :: iskip,tpindex,nskip,iskipstart,iskipend

  ithread=threadidx%x; iblock=blockidx%x; nthread=blockdim%x
  i = blocknbpos_d(1,iblock); iatomstart = i; iatomend = i + blockdim%x - 1
  i = blocknbpos_d(2,iblock); jatomstart = i; jatomend = i + blockdim%x - 1
  iatom = iatomstart + ithread - 1; iskip = 0
  if ( iatom < natom_d ) then
     index = nexcludedatoms_d(iatom); iskip=0; iskipstart=0
     if ( index > 0 ) then
        i = excludedatomindex_d(iatom)
        do tpindex=1,index
           jatom = excludedatomlist_d(i+tpindex)
           if ( (jatom >= jatomstart) .and. (jatom <= jatomend) .and. (jatom <= natom_d) ) then
              if ( iskipstart == 0 ) iskipstart = i + tpindex
              iskipend = i + tpindex
              if ( (jatom >= (jatomstart + ithread - 1)) .and. (iskip == 0) ) iskip = i + tpindex
           end if
        end do
        if ( (iskip == 0) .and. (iskipstart > 0) ) iskip = iskipstart
     end if
     blocknbskip_d(1:3,(iblock-1)*nthread+ithread) = (/iskip,iskipstart,iskipend/)
  end if
end subroutine

! calculate the nonbonded energy terms on GPU 
attributes(device) subroutine cudagb_potforce_elecvdw(iblock)
  real :: epsininv,epsoutinv,kappa,surften
  integer :: natom,igb,igbsa
  logical :: ifcalfrc,ifcalpot
  integer :: i,j,iatom,jatom,jatomstart,jatomend,ithread,iblock,index,nthread
  integer :: iskip,iskipstart,iskipend,skipatom,inext
  real :: tpcoorvec(3),disinv,tpelec,tpvdw,tpgb,dis,dissq,coef1,coef2,coef3,irad,jrad
  real :: icoor(3),ifrc(3),idgbda,icharge,dissqinv,qq,frccoef,fgb,expdij,radij,igb1cutoff,igb1sigma,igb1epsilon
  real :: jcoor(3),jfrc(3),jcharge,jradeff,jgb1cutoff,jgb1sigma,jgb1epsilon,jdgbda
  real :: ivdwsigma,ivdweps,jvdwsigma,jvdweps

  ithread=threadidx%x; nthread=blockdim%x; inext=ithread+1
  tpelec=0.0; tpvdw=0.0; tpgb=0.0; ifrc=0.0; jfrc=0.0

  natom=natom_d; ifcalfrc=ifcalfrc_d; igb=igb_d
  kappa=kappa_d; epsininv=epsininv_d; epsoutinv=epsoutinv_d
  igbsa=igbsa_d; surften=surften_d; ifcalpot=ifcalpot_d

  iatom = blocknbpos_d(1,iblock) + ithread - 1
  jatomstart = blocknbpos_d(2,iblock); jatomend = jatomstart + nthread - 1

  jatom = jatomstart+ithread-1; jcharge = 0.0
  if ( jatom <= natom ) then
     jcoor(1:3) = nowcoor_d(1:3,jatom); jcharge=charge_d(jatom)
     jvdwsigma = vdwsigma_d(jatom); jvdweps = vdweps_d(jatom)
     if ( igb /= 0 ) then
        jradeff=radeff_d(jatom); jdgbda=0.0
        if ( igbsa == 1 ) then
           jgb1cutoff=gb1cutoff_d(jatom); jgb1sigma=gb1sigma_d(jatom); jgb1epsilon=gb1epsilon_d(jatom)
        end if
     end if
  end if

  skipatom = 0; icharge = 0.0
  if ( iatom <= natom ) then
     i=(iblock-1)*nthread+ithread
     iskip = blocknbskip_d(1,i); iskipstart = blocknbskip_d(2,i); iskipend = blocknbskip_d(3,i)
     icharge = charge_d(iatom); icoor(1:3) = nowcoor_d(1:3,iatom)
     ivdwsigma = vdwsigma_d(iatom); ivdweps = vdweps_d(iatom)
     if ( iskip > 0 ) skipatom=excludedatomlist_d(iskip)
     if ( igb /= 0 ) then
        irad = radeff_d(iatom); idgbda=0.0
        if ( igbsa == 1 ) then
           igb1cutoff = gb1cutoff_d(iatom); igb1sigma = gb1sigma_d(iatom); igb1epsilon = gb1epsilon_d(iatom)
        end if

        if ( ifcalpot .eqv. .true. ) then
           if ( blocknbpos_d(1,iblock) == blocknbpos_d(2,iblock) ) then
              if ( kappa == 0.0 ) then
                  coef2 = halfqq_d(iatom)*(epsininv - epsoutinv)  !  0.5*qi*qi*(1/eps_in - 1/epsout)
              else
                  coef1 = exp(-kappa*irad)*epsoutinv              ! exp(-kappa*ai)/epsout
                  coef2 = halfqq_d(iatom)*(epsininv - coef1)      ! 0.5*qi*qi*(1/eps_in - exp(-kappa*ai/epsout))
              end if
              if ( icharge /= 0.0 ) tpgb = tpgb - coef2/irad
           end if
        end if
     end if
  end if

  do index=1,nthread

     if ( icharge /= 0.0 .and. jcharge /= 0.0 ) then
     if ( iatom < jatom .and. jatom <= natom ) then

     tpcoorvec = icoor - jcoor
     dissq = dot_product(tpcoorvec,tpcoorvec)
     dis=sqrt(dissq); disinv=1.0/dis; dissqinv=disinv*disinv
     qq = icharge*jcharge; frccoef=0.0

     if ( igb /= 0 ) then
        jrad = jradeff; radij=irad*jrad
        expdij = exp(-dissq/(4.0*radij))                ! exp(-rij^2/[4*ai*aj])=exp(-Dij)
        fgb = sqrt(dissq + radij*expdij)                ! sqrt(rij^2 + ai*aj*exp(-Dij)) = f_GB

        if ( kappa == 0.0 ) then
           coef1 = 0.0; coef2 = epsininv - epsoutinv
        else
           coef2 = epsoutinv*exp(-kappa*fgb)            ! exp(-kappa*f_GB)/eps_out
           coef1 = -kappa*fgb*coef2                     ! -kappa*f_GB*exp(-kappa*f_GB)/eps_out
           coef2 = epsininv - coef2                     ! 1/eps_in - exp(-kappa*f_GB)/esp_out
        end if

        fgb = 1.0/fgb
        if ( ifcalpot .eqv. .true. ) tpgb = tpgb - qq*coef2*fgb

!        if ( ifcalfrc .eqv. .true. ) then
! -qi*qj/f_GB^3*[ 1/epsin - exp(-kappa*f_GB)/epsout) -kappa*f_GB*exp(-kappa*f_GB)(1 + f_GB*ai*aj/A )/epsout]
           coef1 = -qq*(coef1+coef2)*(fgb**3); coef2 = 0.25*coef1*expdij
           frccoef = coef1 - coef2
           coef2 = 2.0*coef2*(radij + 0.25*dissq)
           idgbda = idgbda + irad*coef2
           jdgbda = jdgbda + jrad*coef2
!        end if

        if ( igbsa == 1 ) then
           if ( (igb1sigma /= 0.0) .and. (jgb1sigma /= 0.0) ) then
              radij = igb1cutoff + jgb1cutoff
              if ( dis < radij ) then
                 expdij = igb1sigma + jgb1sigma
                 coef3 = expdij/(expdij+radij-dis)
                 coef1 = coef3**2; coef2=coef1**2; coef1=(coef2**2)*coef1
                 fgb = 1.2*surften*sqrt(igb1epsilon*jgb1epsilon)
                 if ( ifcalpot .eqv. .true.) tpgb = tpgb - fgb - fgb*(0.666666667*coef1 - 1.666666667*coef2)
!                 if ( ifcalfrc .eqv. .true. ) then
                    frccoef = frccoef + (fgb*disinv*coef3/expdij)*6.666666667*(coef1-coef2)
!                 end if
              end if
           end if
        end if

     end if

     if ( jatom == skipatom ) then

        iskip = iskip + 1; if ( iskip > iskipend ) iskip=iskipstart
        skipatom = excludedatomlist_d(iskip)

     else

! calculate the electrostatic energy
        coef1 = qq*disinv
        if ( ifcalpot ) tpelec = tpelec + coef1

! calculate the van der Waals energy
        qq = ivdwsigma + jvdwsigma
        qq = (qq*disinv)**2; qq = qq*qq*qq
        coef2 = qq*ivdweps*jvdweps
        if ( ifcalpot ) tpvdw = tpvdw + coef2*(qq - 1.0)

!        if ( ifcalfrc .eqv. .true. ) then
            frccoef = frccoef + (coef1 + coef2*(12.0*qq - 6.0))*dissqinv
!        end if

     end if

!     if ( ifcalfrc .eqv. .true. ) then
        tpcoorvec(1:3) = frccoef*tpcoorvec(1:3)
        ifrc(1:3) = ifrc(1:3) + tpcoorvec(1:3)
        jfrc(1:3) = jfrc(1:3) - tpcoorvec(1:3)
!     end if

      end if; end if

      jatom = __shfl(jatom,inext); jcharge = __shfl(jcharge,inext)
      jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
      jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
      jvdwsigma = __shfl(jvdwsigma,inext); jvdweps = __shfl(jvdweps,inext)

      if ( igb /= 0 ) then
         jradeff = __shfl(jradeff,inext)
         jdgbda = __shfl(jdgbda,inext)
         if ( igbsa == 1 ) then
            jgb1cutoff = __shfl(jgb1cutoff,inext)
            jgb1sigma = __shfl(jgb1sigma,inext)
            jgb1epsilon = __shfl(jgb1epsilon,inext)
         end if
      end if

  end do
  call syncthreads()

  if ( iatom <= natom ) then
     i = (jatomstart - blocknbpos_d(1,iblock))/nthread + 1 

     if ( ifblocksum_d ) then

        if ( i == 1 ) then
           if (iatom<=natom) then
              gpufrc_d(1:3,gpufrcindex_d(iatom)+i)=ifrc(1:3)+jfrc(1:3)
              if ( igb /= 0 ) blockdgbda_d(i,iatom) = idgbda + jdgbda
           end if
        else
           if (iatom<=natom) then
              gpufrc_d(1:3,gpufrcindex_d(iatom)+i)=ifrc(1:3)
              if ( igb /= 0 ) blockdgbda_d(i,iatom) = idgbda
           end if
           j = blocknbdim_d - i + 2; jatom = jatomstart + ithread-1
           if (jatom<=natom) then
              gpufrc_d(1:3,gpufrcindex_d(jatom)+j)=jfrc(1:3)
              if ( igb /= 0 ) blockdgbda_d(j,jatom) = jdgbda
           end if
        end if

     else

        if ( i == 1 ) then
           if ( iatom <= natom ) then
              coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)+jfrc(1)))
              coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)+jfrc(2)))
              coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)+jfrc(3)))
              if ( igb /= 0 ) coef1 = atomicadd(dgbda_d(iatom),dble(idgbda+jdgbda))
           end if
        else
           if ( iatom <= natom ) then
              coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)))
              coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)))
              coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)))
              if ( igb /= 0 ) coef1 = atomicadd(dgbda_d(iatom),dble(idgbda))
           end if
           j = blocknbdim_d - i + 2; jatom = jatomstart + ithread-1
           if ( jatom <= natom ) then
              coef1 = atomicadd(nowforce_d(1,jatom),dble(jfrc(1)))
              coef1 = atomicadd(nowforce_d(2,jatom),dble(jfrc(2)))
              coef1 = atomicadd(nowforce_d(3,jatom),dble(jfrc(3)))
              if ( igb /= 0 ) coef1 = atomicadd(dgbda_d(jatom),dble(jdgbda))
           end if
        end if

     end if

  end if

  if ( ifcalpot .eqv. .false. ) return

  index = 1
  do while (index<=16)
     coef1 = __shfl_xor(tpelec,index); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,index); tpvdw = tpvdw + coef1
     index = index*2
  end do
  if ( igb /= 0 ) then
     index = 1
     do while (index<=16)
        coef1 = __shfl_xor(tpgb,index); tpgb= tpgb + coef1
        index = index*2
     end do
  end if

  if ( ithread == 1 ) then
     if ( ifblocksum_d ) then
        blockpotelec_d(iblock)=tpelec; blockpotvdw_d(iblock)=tpvdw
        if (igb /= 0) blockpotgb_d(iblock)=tpgb
     else
        coef1 = atomicadd(eelec_d,dble(tpelec))
        coef1 = atomicadd(evdw_d,dble(tpvdw))
        if ( igb /= 0 ) coef1 = atomicadd(egb_d,dble(tpgb))
     end if
  end if

!  if ( ithread == 1 ) then
!     blockpotelec_d(iblock)=tpelec; blockpotvdw_d(iblock)=tpvdw
!     if (igb /= 0) blockpotgb_d(iblock)=tpgb
!  end if

!  threadpotelec(ithread) = tpelec; threadpotvdw(ithread) = tpvdw
!  call cudatop_vec_sum(ithread,nthread,threadpotelec)
!  call cudatop_vec_sum(ithread,nthread,threadpotvdw)
!  if ( igb /= 0 ) then
!     threadpotgb(ithread) = tpgb
!     call cudatop_vec_sum(ithread,nthread,threadpotgb)
!  end if

!  if ( (ithread == 1) .and. (iblock <= nblocknb_d) ) then
!     do while ( atomiccas(lock,0,1) == 1); end do
!     eelec_d = eelec_d + threadpotelec(1)
!     call threadfence(); lock = 0
!  end if
end subroutine

! calculate the gb force ( dR/dr )
attributes(global) subroutine cudagb_potforce_gbfrc()
  real,parameter :: ca=4.0/3.0,cb=12.0/5.0,cc=24.0/7.0,cd=40.0/9.0,ce=60.0/11.0
  integer :: natom,igb
  real :: gb1sneck,gbdiscutsq,gbdiscut,gbdiscutsqinv,gb1watrad
  integer :: ibin,jbin,iatom,jatom,jatomstart,jatomend,ithread,iblock,index,nthread,blockrow,blockcol,inext
  real :: irad,icoor(3),tpcoorvec(3),dissq,dissqinv,disinv,iradsqinv
  real :: ifrc(3),dis,frccoef,iradius,coef1,coef2,dadr,iradsq,tanhi,tanhidev
  real :: jcoor(3),jfrc(3),jfsrho,jradius,jfsrhosq

  natom=natom_d; igb=igb_d; gb1watrad=gb1watrad_d; gb1sneck=gb1sneck_d
  gbdiscutsq=gbdiscutsq_d; gbdiscut=gbdiscut_d; gbdiscutsqinv=gbdiscutsqinv_d

  ithread=threadidx%x; iblock=blockidx%x; nthread=blockdim%x; inext=ithread+1
  ifrc=0.0; jfrc=0.0

  blockrow=(iblock-1)/blocknbdim_d+1; blockcol=iblock - (blockrow-1)*blocknbdim_d
  iatom = (blockrow-1)*nthread+ithread
  jatomstart = (blockcol-1)*nthread+1; jatomend = jatomstart + nthread - 1

  jatom = jatomstart+ithread-1; jradius = 0.0
  if ( jatom <= natom ) then
     jcoor(1:3) = nowcoor_d(1:3,jatom)
     jfsrho = fsrho_d(jatom); jradius = radius_d(jatom); jfsrhosq = jfsrho**2
     if (igb==1) jbin=gb1radbin_d(jatom)
  end if

  iradius = 0.0
  if ( iatom <= natom ) then
     icoor(1:3) = nowcoor_d(1:3,iatom); irad = radoff_d(iatom); iradsq=irad*irad; iradsqinv=1.0/iradsq
     if ( ifblocksum_d ) then
        frccoef = sum(blockdgbda_d(1:blocknbdim_d,iatom))
     else
        frccoef = dgbda_d(iatom)
     end if
     if ( kappa_d == 0.0 ) then
        coef1 = halfqq_d(iatom)*(epsininv_d - epsoutinv_d)     !  0.5*qi*qi*(1/eps_in - 1/epsout)
        frccoef = -frccoef + coef1
     else
        coef1 = exp(-kappa_d*radeff_d(iatom))*epsoutinv_d      !  exp(-kappa*ai)/epsout
        coef2 = halfqq_d(iatom)*(epsininv_d - coef1)           !  0.5*qi*qi*(1/eps_in - exp(-kappa*ai/epsout))
        frccoef = -frccoef + coef2 - kappa_d*halfqq_d(iatom)*coef1*radeff_d(iatom)
     end if

     if ( igb == 1 ) then
        iradius = radius_d(iatom); ibin=gb1radbin_d(iatom)
        dis = gb1psi_d(iatom); dissq = dis**2
        tanhi = tanh((gb1alpha_d(iatom)+gb1gamma_d(iatom)*dissq-gb1beta_d(iatom)*dis)*dis)
        tanhidev = (gb1alpha_d(iatom)+3.0*gb1gamma_d(iatom)*dissq -  &
                         2.0*gb1beta_d(iatom)*dis)*(1.0-tanhi**2)*irad/iradius
     end if
  end if

  do index=1,nthread

     if ( iradius /= 0.0 .and. jradius /= 0.0 ) then
     if ( iatom <= natom .and. jatom <= natom .and. jatom /= iatom ) then

     tpcoorvec = icoor - jcoor; dissq = dot_product(tpcoorvec,tpcoorvec)

     if ( dissq < gbdiscutsq ) then

     dis=sqrt(dissq)

     if ( dis < (gbdiscut + jfsrho) ) then

     disinv=1.0/dis; dissqinv=disinv**2

     ! dadr = (1/r)(dai/dr)
     if ( dis > (gbdiscut - jfsrho) ) then
        coef1 = 1.0 /(dis-jfsrho)
        dadr = 0.125*dissqinv*disinv*((dissq + jfsrhosq)*(coef1**2 - gbdiscutsqinv) - 2.0*log(gbdiscut*coef1))
     else if ( dis > 4.0*jfsrho) then
        coef1 = jfsrhosq*dissqinv
        coef2 = ca + coef1*(cb + coef1*(cc + coef1*(cd + coef1*ce)))
        dadr = coef1*jfsrho*dissqinv*dissqinv*coef2
     else if ( dis > (irad + jfsrho) ) then
        coef1 = 1.0/(dissq - jfsrhosq)
        coef2 = log((dis - jfsrho)/(dis + jfsrho))
        dadr = coef1*jfsrho*(-0.5*dissqinv + coef1) + 0.25*dissqinv*disinv*coef2
     else if ( dis > abs(irad - jfsrho) ) then
        coef1 = dissqinv*disinv
        coef2 = 1.0/(dis + jfsrho)
        dadr = -0.25*(-0.5*(dissq - iradsq + jfsrhosq)*coef1*iradsqinv + &
                          disinv*coef2*(coef2 - disinv) - coef1*log(irad*coef2))
     else if ( irad < jfsrho ) then
        coef1 = 1.0/(dissq - jfsrhosq)
        coef2 = log((jfsrho - dis)/(dis + jfsrho))
        dadr = -0.5*(jfsrho*dissqinv*coef1 - 2.0*jfsrho*coef1*coef1 - 0.5*dissqinv*disinv*coef2)
     else
        dadr = 0.0
     end if

     if ( igb == 1 ) then
        if ( dis < ( iradius+jradius+gb1watrad ) ) then
           coef1 = dis-gb1dmat_d(ibin,jbin); coef2=coef1**2; dissq=coef1*coef2
           dadr = dadr + (((2.0*coef1+1.8*coef2*dissq)*gb1mmat_d(ibin,jbin) )*gb1sneck)/    &
                                 ( (1.0+coef2+0.3*dissq*dissq)**2*dis )
        end if
        dadr = dadr*tanhidev
     end if

     tpcoorvec(1:3) = dadr*frccoef*tpcoorvec(1:3)
     ifrc = ifrc + tpcoorvec; jfrc = jfrc - tpcoorvec

     end if; end if; end if; end if

     jatom = __shfl(jatom,inext); jbin = __shfl(jbin,inext)
     jfsrho = __shfl(jfsrho,inext); jfsrhosq = __shfl(jfsrhosq,inext); jradius = __shfl(jradius,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)

  end do

  call syncthreads()

  if ( ifblocksum_d .eqv. .true. ) then

     if ( blockrow == blockcol ) then
        if ( iatom <= natom ) then
           ibin = gpufrcindex_d(iatom) + blockcol
           gpufrc_d(1:3,ibin) = gpufrc_d(1:3,ibin) + ifrc(1:3) + jfrc(1:3)
        end if
     else
        if ( iatom <= natom ) then
           ibin = gpufrcindex_d(iatom) + blockcol
           gpufrc_d(1:3,ibin) = gpufrc_d(1:3,ibin) + ifrc(1:3)
        end if
        jatom = (blockcol-1)*nthread+ithread
        if ( jatom <= natom ) then
           ibin = gpufrcindex_d(jatom) + blocknbdim_d + blockrow
           if ( blockrow > blockcol ) ibin = ibin - 1
           gpufrc_d(1:3,ibin) = jfrc(1:3)
        end if
     end if

  else

     if ( blockrow == blockcol ) then
        if ( iatom <= natom ) then
           coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)+jfrc(1)))
           coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)+jfrc(2)))
           coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)+jfrc(3)))
        end if
     else
        if ( iatom <= natom ) then
           coef1 = atomicadd(nowforce_d(1,iatom),dble(ifrc(1)))
           coef1 = atomicadd(nowforce_d(2,iatom),dble(ifrc(2)))
           coef1 = atomicadd(nowforce_d(3,iatom),dble(ifrc(3)))
        end if
        jatom = (blockcol-1)*nthread+ithread
        if ( jatom <= natom ) then
           coef1 = atomicadd(nowforce_d(1,jatom),dble(jfrc(1)))
           coef1 = atomicadd(nowforce_d(2,jatom),dble(jfrc(2)))
           coef1 = atomicadd(nowforce_d(3,jatom),dble(jfrc(3)))
        end if
     end if

  end if

end subroutine

attributes(global) subroutine cudagb_effectiveBorn()
  real,parameter :: ca=1.0/3.0,cb=2.0/5.0,cc=3.0/7.0,cd=4.0/9.0,ce=5.0/11.0
  integer :: natom,igb,ibin,jbin,iatom,jatom,jatomstart,jatomend,ithread,iblock,index,nthread,blockcol,inext
  real :: gbdiscut,gbdiscutsq,gbdiscutinv,gbdiscutsqinv,gb1watrad,gb1sneck
  real :: tpcoorvec(3),disinv,dissq,dis,irad,tpradeff,iradinv
  real :: icoor(3),iradius,dissqinv,coef1,coef2
  real :: jcoor(3),jfsrho,jradius

  ithread=threadidx%x; iblock=blockidx%x; nthread=blockdim%x; inext=ithread+1
  ibin=(iblock-1)/blocknbdim_d+1; blockcol=iblock - (ibin-1)*blocknbdim_d
  jatomstart=(blockcol-1)*nthread+1; jatomend = jatomstart + nthread - 1

  natom=natom_d; igb=igb_d; gb1watrad=gb1watrad_d; gb1sneck=gb1sneck_d
  gbdiscut=gbdiscut_d; gbdiscutsq=gbdiscutsq_d; gbdiscutinv=gbdiscutinv_d; gbdiscutsqinv=gbdiscutsqinv_d

  jatom = jatomstart+ithread-1; jradius = 0.0
  if ( jatom <= natom ) then
     jcoor = nowcoor_d(1:3,jatom); jfsrho = fsrho_d(jatom); jradius = radius_d(jatom)
     if ( igb == 1 ) jbin=gb1radbin_d(jatom)
  end if

  iatom = (ibin-1)*nthread+ithread; iradius = 0.0
  if ( iatom <= natom ) then
     icoor(1:3) = nowcoor_d(1:3,iatom)
     irad=radoff_d(iatom); iradinv=1.0/irad; iradius=radius_d(iatom)
     if ( igb == 1 ) ibin=gb1radbin_d(iatom)
  end if

  tpradeff=0.0
  do index=1,nthread

     if ( iradius /= 0.0 .and. jradius /= 0.0 ) then
     if ( iatom <= natom .and. jatom <= natom .and. iatom /= jatom ) then

     tpcoorvec = icoor - jcoor; dissq=dot_product(tpcoorvec,tpcoorvec)

     if ( dissq < gbdiscutsq ) then

     dis=sqrt(dissq)

     if ( dis < (gbdiscut + jfsrho) ) then

     disinv=1.0/dis; dissqinv=disinv**2

     if ( dis > (gbdiscut - jfsrho) ) then
        tpradeff = tpradeff - 0.125*disinv*( 1.0 + 2.0*dis/(dis-jfsrho) + &
                      gbdiscutsqinv * (dissq - 4.0*gbdiscut*dis - jfsrho**2) + &
                      2.0*log((dis - jfsrho)*gbdiscutinv)   )
     else if ( dis > 4.0*jfsrho) then
        coef1 = jfsrho*jfsrho*dissqinv
        coef2 = ca + coef1*(cb+coef1*(cc + coef1*(cd + coef1*ce)))
        tpradeff = tpradeff - coef1*jfsrho*dissqinv*coef2
     else if ( dis > (irad + jfsrho) ) then
        coef1 = log((dis-jfsrho)/(dis+jfsrho))
        tpradeff = tpradeff - 0.5*(jfsrho/(dissq - jfsrho**2) + 0.5*disinv*coef1)
     else if ( dis > abs(irad - jfsrho)) then
        coef1 = 0.5*iradinv*disinv*(dissq + irad**2 - jfsrho**2)
        coef2 = 1.0/(dis+jfsrho)
        tpradeff = tpradeff - 0.25*(iradinv*(2.0 - coef1) - coef2 + disinv*log(irad*coef2))
     else if (irad < jfsrho) then
        coef1 = log((jfsrho-dis)/(dis+jfsrho))
        tpradeff = tpradeff - 0.5*(jfsrho/(dissq - jfsrho**2) + 2.0*iradinv + 0.5*disinv*coef1)
     end if

     if ( igb == 1 ) then
        if ( dis < ( iradius + jradius + gb1watrad ) ) then
           coef1=(dis-gb1dmat_d(ibin,jbin))**2
           tpradeff=tpradeff-gb1sneck*(gb1mmat_d(ibin,jbin)/(1.0+coef1+0.3*coef1**3))
        end if
     end if

     end if; end if; end if; end if

     jatom = __shfl(jatom,inext); jfsrho = __shfl(jfsrho,inext); jradius = __shfl(jradius,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jbin = __shfl(jbin,inext)
  end do

  if (iatom <= natom) then
     if ( ifblocksum_d ) then
        blockradeff_d(blockcol,iatom) = tpradeff
     else
        coef1 = atomicadd(radeff_d(iatom),dble(tpradeff))
     end if
  end if
end subroutine

end module
