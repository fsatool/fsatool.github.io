module colvar
  use public; use pubmod; use ambertop; use gb; use pme
  implicit none
  include 'mpif.h'

  integer :: ncv,moviecv
  real*8,dimension(:),allocatable :: cvlowrange,cvuprange

  integer :: reccvidata,reccvstart,reccvend,reccvnkelvin,reccvndata,reccvlagstep
  integer,dimension(:),pointer :: rectrajindex
  real*8,dimension(:,:),pointer :: rectrajcoor

  type fsacvs_t
     integer :: type = -1, ni,nr,ngroup,cv_index,ni2,nr2,ni3,ni4
     character*30 :: typename
     logical :: ifperiodic
     integer, pointer :: i(:) => null(), groups(:,:) => null()
     integer, pointer :: i2(:) => null(), groups2(:,:) => null()
     integer, pointer :: i3(:) => null(), groups3(:,:) => null()
     integer, pointer :: i4(:) => null(), groups4(:,:) => null()
     double precision, pointer :: r(:) => null(),r2(:) => null()
     character*150 :: cv_s
  end type
  type(fsacvs_t), allocatable :: fsacvs(:)
  integer,parameter :: CV_COM_POS=1, CV_COM_DIS=2, CV_COM_POSAXIS=3, CV_PCA=4, CV_RMSD=5, CV_DISAVG=6, &
        CV_DIHEDRAL=7, CV_POT=8, CV_NCONTACT=9, CV_NCONTACTRES=10, CV_NRESSTATE=11, CV_DISAVGRES=12, &
        CV_NANTIHB=13, CV_ANGLE=14, CV_GYRATION=15, CV_GYRATIONRES=16, CV_NCONTACTRESVEC=17,     &
        CV_DIHEDRAL_ENDEND=18, CV_RMSD_ENDEND=19, CV_DISAVG_ENDEND=20, CV_DISAVG_END4=21,        &
        CV_COM_DIS_RES=22, CV_COS_OF_DIHEDRAL=23, CV_ANGLE_BETWEEN_HELIX=24, CV_PATH_RMSD=25,    &
        CV_DRMSD=26,CV_DRMSD_ENDEND=27, CV_COMBINECV=28, CV_POT_VDW=29, CV_POT_ELEC=30,          &
        CV_POT_BOND=31, CV_POT_ANGLE=32, CV_POT_DIHE=33, CV_POT_ELECVDW14=34, CV_POT_GB=35,      &
        CV_POT_GAS=36, CV_SRV=37, CV_COSDIHEDRAL=38, CV_SINDIHEDRAL=39, CV_GYRATIONRESAVG = 40,  &
        CV_TAE=41, CV_TICA=42, CV_POT_GASGB=43, CV_BOND=44

contains

subroutine colvar_init()
  use gb, only:gb_initialize,radeff; use pme, only:pme_initialize,pmebcterm
  use srv, only : srv_allocate_arrays,srv_flooding_initialize,cmat,smat,lmat,linvmat,lambda,gmean,gbasis
  use deep, only : netnum,nlayer,layers,noutput,ninput,STREAM,deepntotdata,jobtype,timestepsize,deep_initialize
  use mlp, only : mlp_initialize
  use cudatop, only : cudatop_initialize,cvnatom_d,cvatomcoor_d,cvatomforce_d,cvatomindex_d,natom_d,nres_d,igb_d,igbsa_d
  use cudagb, only : cudagb_initialize
  logical :: iffind,ifaddedcvatoms

  integer,dimension(natom) :: cv_i,cv_i2,cv_i3,cv_i4
  real*8,dimension(natom*3) :: cv_r,cv_r2
  integer :: iomdin,i,j,k,tpni,iatom,icv,cv_ni,cv_ni2,cv_ni3,cv_ni4,ierr
  integer :: cv_nr,cv_index,ires,jres,tpi,tpj,tpatoms(natom)
  character*150 :: cv_type,cv_s
  real*8 :: cv_min, cv_max, tpvec(3),tpdiscut
  namelist / fsacolvar / cv_type, cv_i, cv_r, cv_index, cv_s, cv_min, cv_max, cv_r2, cv_i2, cv_i3, cv_i4

  icv = 0; cv_ni=0; cv_ni2=0; cv_ni3=0; cv_ni4=0
  open(newunit=iomdin,file=parmfile,action="read")
  do
     call searchnamelist(iomdin,'fsacolvar',iffind)
     if ( iffind .eqv. .false. ) exit
     read(iomdin,'(a80)',iostat=ierr); if ( ierr < 0 ) exit
     icv = icv + 1
  end do
  if ( icv == 0 ) then
     close(iomdin); return
  end if
  ncv = icv; allocate(fsacvs(ncv)); fsacvs(1:ncv)%ifperiodic=.false.
  allocate(cvlowrange(ncv),cvuprange(ncv)); cvlowrange=0.0d0; cvuprange=0.0d0

  rewind(iomdin)
  do icv=1,ncv
     call searchnamelist(iomdin,'fsacolvar',iffind)
     cv_i(:)=-10000; cv_i2(:)=-10000; cv_r(:)=-10000.0d0; cv_r2(:)=-10000.0d0
     cv_i3(:)=-10000; cv_i4(:)=-10000; cv_s = ""
     read(iomdin,nml=fsacolvar)
     do i=1,natom
        if ( cv_i(i) == -10000 ) exit
     end do
     fsacvs(icv)%ni=i-1; 
     if ( fsacvs(icv)%ni > 0 ) then
        allocate(fsacvs(icv)%i(fsacvs(icv)%ni))
        fsacvs(icv)%i(1:fsacvs(icv)%ni) = cv_i(1:fsacvs(icv)%ni)
     end if
     do i=1,natom*3
        if ( cv_r(i) == -10000.0d0 ) exit
     end do
     fsacvs(icv)%nr=i-1; 
     if ( fsacvs(icv)%nr > 0 ) then
        allocate(fsacvs(icv)%r(fsacvs(icv)%nr))
        fsacvs(icv)%r(1:fsacvs(icv)%nr) = cv_r(1:fsacvs(icv)%nr)
     end if
     do i=1,natom
        if ( cv_i2(i) == -10000 ) exit
     end do
     fsacvs(icv)%ni2=i-1
     if ( fsacvs(icv)%ni2 > 0 ) then
        allocate(fsacvs(icv)%i2(fsacvs(icv)%ni2))
        fsacvs(icv)%i2(1:fsacvs(icv)%ni2) = cv_i2(1:fsacvs(icv)%ni2)
     end if
     do i=1,natom*3
        if ( cv_r2(i) == -10000.0d0 ) exit
     end do
     fsacvs(icv)%nr2=i-1
     if ( fsacvs(icv)%nr2 > 0 ) then
        allocate(fsacvs(icv)%r2(fsacvs(icv)%nr2))
        fsacvs(icv)%r2(1:fsacvs(icv)%nr2) = cv_r2(1:fsacvs(icv)%nr2)
     end if

     do i=1,natom
        if ( cv_i3(i) == -10000 ) exit
     end do
     fsacvs(icv)%ni3=i-1
     if ( fsacvs(icv)%ni3 > 0 ) then
        allocate(fsacvs(icv)%i3(fsacvs(icv)%ni3))
        fsacvs(icv)%i3(1:fsacvs(icv)%ni3) = cv_i3(1:fsacvs(icv)%ni3)
     end if
     do i=1,natom
        if ( cv_i4(i) == -10000 ) exit
     end do
     fsacvs(icv)%ni4=i-1
     if ( fsacvs(icv)%ni4 > 0 ) then
        allocate(fsacvs(icv)%i4(fsacvs(icv)%ni4))
        fsacvs(icv)%i4(1:fsacvs(icv)%ni4) = cv_i4(1:fsacvs(icv)%ni4)
     end if
     cvlowrange(icv) = cv_min; cvuprange(icv)= cv_max; ifaddedcvatoms=.false.

     j=0
     do i=1,fsacvs(icv)%ni
        iatom = fsacvs(icv)%i(i)
        if ( (iatom == 0) .or. ((i==fsacvs(icv)%ni) .and. (iatom>0)) ) j=j+1
     end do
     fsacvs(icv)%ngroup = j; ! if ( j == 0 ) call errormsg("group num error!")
     allocate(fsacvs(icv)%groups(2,j)); fsacvs(icv)%groups=0
     j=0; fsacvs(icv)%groups(1,1)=1
     do i=1,fsacvs(icv)%ni
        iatom = fsacvs(icv)%i(i)
        if ( (iatom == 0) .or. ((i==fsacvs(icv)%ni)) .and. (iatom>0) ) then
           j = j + 1
           if ( (i==fsacvs(icv)%ni) .and. (iatom>0) ) then
              fsacvs(icv)%groups(2,j) = i; exit
           else if ( iatom == 0 ) then
              fsacvs(icv)%groups(2,j) = i-1; if ( i==fsacvs(icv)%ni ) exit
              fsacvs(icv)%groups(1,j+1) = i+1
           end if
        end if
     end do

     fsacvs(icv)%typename = trim(cv_type)
     if ( cv_type == 'COM_POS' ) then
        fsacvs(icv)%type = CV_COM_POS
     else if ( cv_type == 'COM_DIS' ) then
        if ( fsacvs(icv)%ngroup /= 2 ) call errormsg("atom group number in COM_DIS must be 2!")
        fsacvs(icv)%type = CV_COM_DIS
     else if ( cv_type == 'COM_POSAXIS' ) then
        fsacvs(icv)%type = CV_COM_POSAXIS
     else if ( cv_type == 'PCA' ) then
        fsacvs(icv)%type = CV_PCA; fsacvs(icv)%cv_index=cv_index; fsacvs(icv)%cv_s=cv_s
     else if ( cv_type == 'RMSD' ) then
        fsacvs(icv)%type = CV_RMSD
      !   if (fsacvs(icv)%nr /= fsacvs(icv)%ni*3 ) call errormsg("RMSD definition error ",int1=fsacvs(icv)%ni,int2=fsacvs(icv)%nr)
      !   tpvec=0d0
      !   do i=1,fsacvs(icv)%ni
      !      tpvec(1:3) = tpvec(1:3) + fsacvs(icv)%r(3*i-2:3*i)
      !   end do
      !   tpvec(1:3)=tpvec(1:3)/dble(fsacvs(icv)%ni)
      !   do i=1,fsacvs(icv)%ni
      !      fsacvs(icv)%r(3*i-2:3*i) = fsacvs(icv)%r(3*i-2:3*i) - tpvec(1:3)
      !   end do
     else if ( cv_type == 'DRMSD' ) then
        fsacvs(icv)%type = CV_DRMSD
        i = fsacvs(icv)%ni; i=i*(i-1)/2 
        if ( fsacvs(icv)%nr /= i ) call errormsg("DRMSD error: inconsistent number ",int1=i,int2=fsacvs(icv)%nr)
     else if ( cv_type == 'DISAVG' ) then
        if ( mod(fsacvs(icv)%ni,2) /= 0 ) call errormsg("DISAVG: atom number is not even!")
        fsacvs(icv)%type = CV_DISAVG
     else if ( cv_type == 'DIHEDRAL' ) then
        if ( fsacvs(icv)%ni /= 4 ) call errormsg("DIHEDRAL: atom number should be 4!")
        fsacvs(icv)%type = CV_DIHEDRAL
        fsacvs(icv)%ifperiodic = .true.
     else if ( cv_type == 'ANGLE' ) then
        if ( fsacvs(icv)%ni /= 3 ) call errormsg("ANGLE: atom number should be 3!")
        fsacvs(icv)%type = CV_ANGLE
        fsacvs(icv)%ifperiodic = .true.
     else if ( cv_type == 'BOND' ) then
        if ( fsacvs(icv)%ni /= 2 ) call errormsg("BOND: atom number should be 2!")
        fsacvs(icv)%type = CV_BOND
     else if ( cv_type == 'POT' ) then
        ifaddedcvatoms=.true.
        if ( ipb == 0 ) then
           if ( .not. allocated(radeff) ) then
              i=igb; j=igbsa; igb=1; igbsa=1
              call gb_initialize()
              igb=i; igbsa=j
           end if
        else
           if (.not. allocated(pmebcterm)) call pme_initialize()
        end if
        fsacvs(icv)%type = CV_POT; ifcalpot=.true.
        tpatoms=0; do i=1,natom; tpatoms(i)=i; end do
        call colvar_addcvatoms(tpatoms(1:natom))
     else if ( cv_type == 'POT_BOND' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        fsacvs(icv)%type = CV_POT_BOND
     else if ( cv_type == 'POT_ANGLE' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        fsacvs(icv)%type = CV_POT_ANGLE
     else if ( cv_type == 'POT_DIHE' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        fsacvs(icv)%type = CV_POT_DIHE
     else if ( cv_type == 'POT_ELECVDW14' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        fsacvs(icv)%type = CV_POT_ELECVDW14
     else if ( cv_type == 'POT_ELEC' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        fsacvs(icv)%type = CV_POT_ELEC
     else if ( cv_type == 'POT_VDW' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        fsacvs(icv)%type = CV_POT_VDW
     else if ( cv_type == 'POT_GB' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        if (.not. allocated(radeff)) then
           i=igb; j=igbsa; k=natom; tpni=nres; igb=1; igbsa=1; natom=nbioatom; nres=nbiores
           call gb_initialize()
           igb=i; igbsa=j; natom=k; nres=tpni
        end if
        fsacvs(icv)%type = CV_POT_GB
        tpatoms=0; do i=1,nbioatom; tpatoms(i)=i; end do
        call colvar_addcvatoms(tpatoms(1:nbioatom))
     else if ( cv_type == 'POT_GAS' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        fsacvs(icv)%type = CV_POT_GAS
        tpatoms=0; do i=1,nbioatom; tpatoms(i)=i; end do
        call colvar_addcvatoms(tpatoms(1:nbioatom))
     else if ( cv_type == 'POT_GASGB' ) then
        ifaddedcvatoms=.true.; ifcalpot=.true.
        if (.not. allocated(radeff)) then
           i=igb; j=igbsa; k=natom; tpni=nres; tpdiscut=discut
           igb=1; igbsa=0; natom=nbioatom; nres=nbiores; discut=10000d0
           if ( icuda > 0 ) then
              igb_d=igb; igbsa_d=igbsa; natom_d=natom; nres_d=nres
           end if
           if ( icuda == 0 ) then
              call gb_initialize()
           else
              call cudagb_initialize()
           end if
           igb=i; igbsa=j; natom=k; nres=tpni; discut=tpdiscut
           if ( icuda > 0 ) then
              igb_d=igb; igbsa_d=igbsa; natom_d=natom; nres_d=nres
           end if
        end if
        fsacvs(icv)%type = CV_POT_GASGB
     else if ( cv_type == 'NCONTACT' ) then
        if ( mod(fsacvs(icv)%ni,2) /= 0 ) call errormsg("NCONTACT: cv_ni is not even!")
        fsacvs(icv)%type = CV_NCONTACT
     else if ( cv_type == 'COMBINECV' ) then
        ifaddedcvatoms = .true.
        if ( fsacvs(icv)%ni /= fsacvs(icv)%nr ) &
         call errormsg("COMBINECV does not have the same number of cv and weight ",int1=fsacvs(icv)%ni, int2=fsacvs(icv)%nr)
        fsacvs(icv)%type = CV_COMBINECV
     else if ( cv_type == 'NCONTACTRES' ) then
        fsacvs(icv)%type = CV_NCONTACTRES; ifaddedcvatoms=.true.
        tpi=1
        if ( fsacvs(icv)%i(1)*fsacvs(icv)%i(2) < 0 ) then
           j=fsacvs(icv)%i(1); k=-fsacvs(icv)%i(2); tpi=3
        end if
        do i=tpi,fsacvs(icv)%ni,2
           ires = fsacvs(icv)%i(i); jres = fsacvs(icv)%i(i+1)
           if ( tpi == 3 ) then
              if ( ((jres-ires) < j) .or. ((jres-ires) > k ) ) cycle
           end if
           call ambertop_getatoms(tpj,tpatoms,tpres=(/ires,jres/),ifheavysc=.true.)
           call colvar_addcvatoms(tpatoms(1:tpj))
        end do
     else if ( cv_type == 'NRESSTATE' ) then
        fsacvs(icv)%type = CV_NRESSTATE; ifaddedcvatoms=.true.
        ires=2; jres=nres-1;
        if ( (fsacvs(icv)%i(2)>2) .and. (fsacvs(icv)%i(2)<(nres-1)) ) ires=fsacvs(icv)%i(2)
        if ( (fsacvs(icv)%i(3)>2) .and. (fsacvs(icv)%i(3)<(nres-1)) ) jres=fsacvs(icv)%i(3)
        do ires=ires,jres
           if ( resname(ires) == "PRO " ) cycle
           call colvar_addcvatoms(tpatoms=(/resindex(ires)-1, resindex(ires)+1, &
                         resindex(ires)+3, resindex(ires+1)-1, resindex(ires+1)+1/))
        end do
     else if ( cv_type == 'DISAVGRES' ) then
        if ( mod(fsacvs(icv)%ni,2) /= 0 ) call errormsg("DISAVGRES: cv_ni is not even!")
        fsacvs(icv)%type = CV_DISAVGRES; ifaddedcvatoms=.true.
        tpni=1; if ( fsacvs(icv)%i(1)*fsacvs(icv)%i(2) < 0 ) tpni=3 
        do i=tpni,fsacvs(icv)%ni,2
           ires = fsacvs(icv)%i(i); jres = fsacvs(icv)%i(i+1)
           if ( tpi == 3 ) then
              if ( ((jres-ires) < j) .or. ((jres-ires) > k ) ) cycle
           end if
           call ambertop_getatoms(tpj,tpatoms,tpres=(/ires,jres/),ifheavysc=.true.)
           call colvar_addcvatoms(tpatoms(1:tpj))
        end do
     else if ( cv_type == 'NANTIHB' ) then
        fsacvs(icv)%type = CV_NANTIHB; ifaddedcvatoms=.true.
        ires=1; jres=nres; tpi=0; tpj=0
        if ( (fsacvs(icv)%i(1)>0) .and. (fsacvs(icv)%i(2)>0) ) then
           ires=fsacvs(icv)%i(1); jres=fsacvs(icv)%i(2)
        end if
        do i=ires,jres
           if ( resname(i) == "PRO " ) cycle
           if ( (fsacvs(icv)%i(3)>0) .and. (fsacvs(icv)%i(4)>0) ) then
              tpi=fsacvs(icv)%i(3); tpj=fsacvs(icv)%i(4)
           else
              tpi=i+3; tpj=jres
           end if
           do j=tpi,tpj
              if ( resname(j) == "PRO " ) cycle
              call colvar_addcvatoms(tpatoms=((/resindex(i)+2, resindex(i+1), resindex(j)+2, resindex(j+1)/)))
           end do
        end do
     else if ( cv_type == 'GYRATION' ) then
        fsacvs(icv)%type = CV_GYRATION
     else if ( cv_type == 'GYRATIONRES' ) then
        fsacvs(icv)%type = CV_GYRATIONRES; ifaddedcvatoms=.true.
        do i=1,fsacvs(icv)%ni
           ires = fsacvs(icv)%i(i)
           call ambertop_getatoms(tpj,tpatoms,tpres=(/ires/),ifheavysc=.true.)
           call colvar_addcvatoms(tpatoms(1:tpj))
        end do
     else if ( cv_type == 'GYRATIONRESAVG' ) then
        fsacvs(icv)%type = CV_GYRATIONRESAVG; ifaddedcvatoms=.true.
        do i=1,fsacvs(icv)%ni
           ires = fsacvs(icv)%i(i); if ( ires == 0 ) cycle
           call ambertop_getatoms(tpj,tpatoms,tpres=(/ires/),ifheavysc=.true.)
           call colvar_addcvatoms(tpatoms(1:tpj))
        end do
     else if ( cv_type == 'NCONTACTRESVEC' ) then
        fsacvs(icv)%type = CV_NCONTACTRESVEC; ifaddedcvatoms=.true.
        tpi=1
        if ( fsacvs(icv)%i(1)*fsacvs(icv)%i(2) < 0 ) then
           j=fsacvs(icv)%i(1); k=-fsacvs(icv)%i(2); tpi=3
        end if
        do i=tpni,fsacvs(icv)%ni
           ires = fsacvs(icv)%i(i)
           do j=i+1,fsacvs(icv)%ni
              jres = fsacvs(icv)%i(j)
              if ( tpi == 3 ) then
                 if ( ((jres-ires) < j) .or. ((jres-ires) > k ) ) cycle
              end if
              call ambertop_getatoms(tpj,tpatoms,tpres=(/ires,jres/),ifheavysc=.true.)
              call colvar_addcvatoms(tpatoms(1:tpj))
           end do
        end do
     else if ( cv_type == 'DIHEDRAL_ENDEND' ) then
        if ( (fsacvs(icv)%ni/fsacvs(icv)%nr) /= 4 ) call errormsg("DIHEDRAL: atom number should be a multiple of 4!")
        if ( fsacvs(icv)%nr /= fsacvs(icv)%nr2 ) call errormsg("cv_r has different members to cv_r2", &
                  int1=icv,int2=fsacvs(icv)%nr,int3=fsacvs(icv)%nr2) 
        fsacvs(icv)%type = CV_DIHEDRAL_ENDEND
        fsacvs(icv)%r(1:fsacvs(icv)%nr) = fsacvs(icv)%r(1:fsacvs(icv)%nr)*pi/180d0
        fsacvs(icv)%r2(1:fsacvs(icv)%nr) = fsacvs(icv)%r2(1:fsacvs(icv)%nr)*pi/180d0
     else if ( cv_type == 'RMSD_ENDEND' ) then
        fsacvs(icv)%type = CV_RMSD_ENDEND
        ! if ( fsacvs(icv)%nr /= fsacvs(icv)%ni*3 ) call errormsg("RMSD definition error ",int1=fsacvs(icv)%ni,int2=fsacvs(icv)%nr)
        if ( fsacvs(icv)%nr /= fsacvs(icv)%nr2 ) call errormsg("cv_r has different members to cv_r2", &
                  int1=icv,int2=fsacvs(icv)%nr,int3=fsacvs(icv)%nr2)
        fsacvs(icv)%type = CV_RMSD_ENDEND
        ! tpvec=0d0
        ! do i=1,fsacvs(icv)%ni
        !    tpvec(1:3) = tpvec(1:3) + fsacvs(icv)%r(3*i-2:3*i)
        ! end do
        ! tpvec(1:3)=tpvec(1:3)/dble(fsacvs(icv)%ni)
        ! do i=1,fsacvs(icv)%ni
        !    fsacvs(icv)%r(3*i-2:3*i) = fsacvs(icv)%r(3*i-2:3*i) - tpvec(1:3)
        ! end do
        ! tpvec=0d0
        ! do i=1,fsacvs(icv)%ni
        !    tpvec(1:3) = tpvec(1:3) + fsacvs(icv)%r2(3*i-2:3*i)
        ! end do
        ! tpvec(1:3)=tpvec(1:3)/dble(fsacvs(icv)%ni)
        ! do i=1,fsacvs(icv)%ni
        !    fsacvs(icv)%r2(3*i-2:3*i) = fsacvs(icv)%r2(3*i-2:3*i) - tpvec(1:3)
        ! end do
     else if ( cv_type == 'DRMSD_ENDEND' ) then
        fsacvs(icv)%type = CV_DRMSD_ENDEND
        i = fsacvs(icv)%ni; i=i*(i-1)/2 
        if ( fsacvs(icv)%nr /= i ) call errormsg("DRMSD error: inconsistent number ",int1=i,int2=fsacvs(icv)%nr)
        if ( fsacvs(icv)%nr /= fsacvs(icv)%nr2 ) call errormsg("cv_r has different members to cv_r2", &
                  int1=icv,int2=fsacvs(icv)%nr,int3=fsacvs(icv)%nr2)
     else if ( cv_type == 'DISAVG_ENDEND' ) then
        if ( (fsacvs(icv)%ni==0) .or. (mod(fsacvs(icv)%ni,2) /= 0) ) call errormsg("DISAVG_ENDEND: atom number is not even!")
        if ( (fsacvs(icv)%ni2==0) .or. (mod(fsacvs(icv)%ni2,2) /= 0) ) call errormsg("DISAVG_ENDEND: atom number2 is not even!")
        fsacvs(icv)%type = CV_DISAVG_ENDEND
     else if ( cv_type == 'DISAVG_END4' ) then
        if ( (fsacvs(icv)%ni==0) .or. (mod(fsacvs(icv)%ni,2) /= 0) ) call errormsg("DISAVG_END4: atom number is not even!")
        if ( (fsacvs(icv)%ni2==0) .or. (mod(fsacvs(icv)%ni2,2) /= 0) ) call errormsg("DISAVG_END4: atom number2 is not even!")
        if ( (fsacvs(icv)%ni3==0) .or. (mod(fsacvs(icv)%ni3,2) /= 0) ) call errormsg("DISAVG_END4: atom number3 is not even!")
        if ( (fsacvs(icv)%ni4==0) .or. (mod(fsacvs(icv)%ni4,2) /= 0) ) call errormsg("DISAVG_END4: atom number4 is not even!")
        if ( fsacvs(icv)%nr /= 2 ) call errormsg("DISAVG_END4: nr must be 2!")
        fsacvs(icv)%type = CV_DISAVG_END4
     else if ( cv_type == 'COM_DIS_RES' ) then
        fsacvs(icv)%type = CV_COM_DIS_RES; ifaddedcvatoms=.true.
        do i=1,fsacvs(icv)%ni
           ires = fsacvs(icv)%i(i); if ( ires <= 0 ) cycle
           call ambertop_getatoms(tpj,tpatoms,tpres=(/ires/),ifheavysc=.true.)
           call colvar_addcvatoms(tpatoms(1:tpj))
        end do
     else if ( cv_type == 'COS_OF_DIHEDRAL' ) then
        if ( mod(fsacvs(icv)%ni,4) /= 0 ) call errormsg("DIHEDRAL: atom number should be a mulitiple of 4!")
        fsacvs(icv)%type = CV_COS_OF_DIHEDRAL
     else if ( cv_type == 'ANGLE_BETWEEN_HELIX' ) then
        if (fsacvs(icv) % ni / 2 < 8) call errormsg("ANGLE_BETWEEN_HELIX: helix must contains at least 4 residues")
        fsacvs(icv)%type = CV_ANGLE_BETWEEN_HELIX
     else if (cv_type =="PATH_RMSD") then
        if (fsacvs(icv)%nr /= fsacvs(icv)%ni*3 ) call errormsg("PATH_RMSD definition error ",&
                   int1=fsacvs(icv)%ni,int2=fsacvs(icv)%nr)
        if (fsacvs(icv)%nr /= fsacvs(icv)%nr2 ) call errormsg("cv_r has different members to cv_r2", &
                  int1=icv,int2=fsacvs(icv)%nr,int3=fsacvs(icv)%nr2)
        fsacvs(icv)%type = CV_PATH_RMSD
        tpvec=0d0
        do i=1,fsacvs(icv)%ni
           tpvec(1:3) = tpvec(1:3) + fsacvs(icv)%r(3*i-2:3*i)
        end do
        tpvec(1:3)=tpvec(1:3)/dble(fsacvs(icv)%ni)
        do i=1,fsacvs(icv)%ni
           fsacvs(icv)%r(3*i-2:3*i) = fsacvs(icv)%r(3*i-2:3*i) - tpvec(1:3)
        end do
        tpvec=0d0
        do i=1,fsacvs(icv)%ni
           tpvec(1:3) = tpvec(1:3) + fsacvs(icv)%r2(3*i-2:3*i)
        end do
        tpvec(1:3)=tpvec(1:3)/dble(fsacvs(icv)%ni)
        do i=1,fsacvs(icv)%ni
           fsacvs(icv)%r2(3*i-2:3*i) = fsacvs(icv)%r2(3*i-2:3*i) - tpvec(1:3)
        end do
     else if ( cv_type == 'SRV' ) then
        ifaddedcvatoms = .true.
        fsacvs(icv)%type = CV_SRV; fsacvs(icv)%cv_s=cv_s
        if ( fsacvs(icv)%ni2 /= 2 ) call errormsg("In SRV, fsacvs(icv)%ni2 must be 2!")

        if ( nlayer == 0 ) then
           if ( fsacvs(icv)%ni3 == 0 ) then   ! flooding by standard prediction
              call srv_flooding_initialize(fsacvs(icv)%cv_s,nbiores,resname(1:nbiores))
           else                               ! flooding by streaming method
              if ( procnum < 3 ) call errormsg("procnum must be larger than 2 for flooding by streaming")
              jobtype = STREAM; netnum=2; timestepsize = printcvstep*deltatime*0.001d0
              reccvstart = fsacvs(icv)%i2(1); reccvend =  fsacvs(icv)%i2(2); netnum = 2
              do i = 0, procnum - 1
                 call mpi_barrier(mpi_comm_world,ierr)
                 if ( procid /= i ) cycle
                 call deep_initialize(fsacvs(icv)%cv_s)
                 call mlp_initialize(ninput,noutput,nlayer,layers,j)
              end do
              call mpi_barrier(mpi_comm_world,ierr)
              if ( ninput /= (reccvend-reccvstart+1) ) call errormsg("SRV input error! ",int1=ninput,int2=reccvend-reccvstart+1)
              call srv_allocate_arrays()
              reccvndata = fsacvs(icv)%i3(1); deepntotdata = reccvndata
           end if
           if ( fsacvs(icv)%ni > noutput ) call errormsg("SRV mode index exceeds the maximum!",int1=fsacvs(icv)%ni,int2=noutput)
           if ( (fsacvs(icv)%i2(2)-fsacvs(icv)%i2(1)+1) /= ninput ) then
              call errormsg("SRV input number is not correct!",int1=fsacvs(icv)%i2(1),int2=fsacvs(icv)%i2(2),int3=ninput)
           end if
        end if
     else if ( cv_type == 'TAE' ) then
        ifaddedcvatoms = .true.
        fsacvs(icv)%type = CV_TAE; fsacvs(icv)%cv_s=cv_s
        if ( fsacvs(icv)%ni2 /= 2 ) call errormsg("In TAE, fsacvs(icv)%ni2 must be 2!")
     else if ( cv_type == 'TICA' ) then
        ifaddedcvatoms = .true.
        fsacvs(icv)%type = CV_TICA; fsacvs(icv)%cv_s=cv_s
        if ( fsacvs(icv)%ni2 /= 2 ) call errormsg("In TICA, fsacvs(icv)%ni2 must be 2!")
        reccvstart = fsacvs(icv)%i2(1); reccvend =  fsacvs(icv)%i2(2)
        if ( fsacvs(icv)%ni3 == 0 ) then ! flooding by reference eigen info
           if ( fsacvs(icv)%nr == 0 ) call errormsg("There is no eigen info!")
        else                             ! flooding by streaming method
           if ( fsacvs(icv)%ni3 /= 2 ) call errormsg("In TICA, fsacvs(icv)%ni3 must be 2!")
           if ( procnum < 3 ) call errormsg("procnum must be larger than 2 for flooding by streaming")
           reccvndata = fsacvs(icv)%i3(1); reccvlagstep = fsacvs(icv)%i3(2)
        end if
     else if ( cv_type == 'COSDIHEDRAL' ) then
        if ( fsacvs(icv)%ni /= 4 ) call errormsg("COSDIHEDRAL: atom number should be 4!")
        fsacvs(icv)%type = CV_COSDIHEDRAL
     else if ( cv_type == 'SINDIHEDRAL' ) then
        if ( fsacvs(icv)%ni /= 4 ) call errormsg("SINDIHEDRAL: atom number should be 4!")
        fsacvs(icv)%type = CV_SINDIHEDRAL
     else
        call errormsg("colvar type error :"//trim(cv_type))
     end if
     if ( (ifaddedcvatoms .eqv. .false.) .and. (fsacvs(icv)%ni > 0) ) then
        call colvar_addcvatoms(fsacvs(icv)%i(1:fsacvs(icv)%ni))
        if ( fsacvs(icv)%ni2 > 0 ) call colvar_addcvatoms(fsacvs(icv)%i2(1:fsacvs(icv)%ni2))
     end if
  end do
  close(iomdin); flush(iosiminfo)

  if ( cvnatom > 0 ) then
     do i=1,cvnatom
        do j=i+1,cvnatom
           if ( cvatoms(i) > cvatoms(j) ) then
              tpi=cvatoms(i); cvatoms(i)=cvatoms(j); cvatoms(j)=tpi
           else if ( cvatoms(i) == cvatoms(j) ) then
              call errormsg("wrong cvatoms ",int1=cvatoms(i),int2=cvatoms(j))
           end if
        end do
     end do
     allocate(cvatomcoor(3,cvnatom),cvatomforce(3,cvnatom)); cvatomcoor=0.0d0; cvatomforce=0.0d0
     if ( icuda > 0 ) then   
        cvnatom_d = cvnatom
        allocate(cvatomindex_d(natom)); cvatomindex_d=0
        allocate(cvatomcoor_d(3,cvnatom),cvatomforce_d(3,cvnatom)); cvatomcoor_d=0.0; cvatomforce_d=0.0
        do i=1,cvnatom
           cvatomindex_d(cvatoms(i))=i
           cvatomcoor(1:3,i) = nowcoor(1:3,cvatoms(i))
        end do
        cvatomcoor_d = cvatomcoor
     end if
  end if

  if ( procid == 0 ) then
     write(iosiminfo,"(/,a)" ) "Collective Variable Info"
     do icv=1,ncv
        write(iosiminfo,"(a,i4,a,a,3(a,i4))") "CV ",icv,":  type ",trim(fsacvs(icv)%typename), &
              ", group number ",fsacvs(icv)%ngroup, &
              ", integers ",fsacvs(icv)%ni+fsacvs(icv)%ni2, ", floats ",fsacvs(icv)%nr+fsacvs(icv)%nr2
        if ( fsacvs(icv)%ngroup > 1 ) then
           write(iosiminfo,"(10x,20(a,i3,a,2i5,a2,3x))") ("group ",j,"  index range ", &
                fsacvs(icv)%groups(1:2,j),", ", j=1,fsacvs(icv)%ngroup)
        end if
     end do
     write(iosiminfo,*); flush(iosiminfo)
  
     if ( cvnatom < nbioatom ) then
        write(iosiminfo,"(a,i5,a)") "All",cvnatom," atoms in CV are listed below"
        write(iosiminfo,"(14i6)") cvatoms(1:cvnatom)
        flush(iosiminfo)
     end if
  end if

!  additional operations
  if ( procid == 0 ) then

!  call colvar_check_gradient(tpcoor)
!  call ambertop_get_com(nowcoor,tpvec,tpmols=(/1/),ifcalpha=.true.); write(iosiminfo,"(a,10f8.3)") "com1 ",tpvec(:)
!  call ambertop_get_com(nowcoor,tpvec,tpmols=(/2/),ifcalpha=.true.); write(iosiminfo,"(a,10f8.3)") "com2 ",tpvec(:)

!  call moldata_anchor_and_rotate(nowcoor,ifwritecrd=.true.,anchorres=(/1/),rotateres=(/nres/),ifcalpha=.true.)
!  call colvar_printcv_calpharmsd((/1,nres,0/), stride=1)
!  call colvar_printcv_backbonermsd((/52,102,0/))
!  call colvar_printcv_helixhb_antihb()

!  call colvar_printcv_heavyrmsd((/1,nres,0/))
!  call colvar_printcv_sidechainheavyatoms(2)

!  call colvar_printcv_contacts((/1,nres,0/),9.0d0,tpstride=3,ifheavy=.true.)
!  call colvar_printcv_hydrophobic_core(10.0d0,8,resstart=1,resend=53,tpcoor=nowcoor)
!  call colvar_printcv_backbonenhb(1,53,4,tpdismark=3.0d0,tpanglemark=90d0,tpcoor=nowcoor)

!  call colvar_printcv_hydrophobic_core_ncontactresvec()
!  call colvar_printcv_hydrophobic_pair(8,resstart=1,resend=30,discut=8.0d0)
!  call colvar_printcv_gyration_kdscale()

!  call colvar_printcv_calpha2calphadis()
!  call colvar_printcv_phipsichi(ifsincos=.true.)
!  call colvar_printcv_chain2chaindis([1],[2])

!  call colvar_printcv_dna_backbonermsd_o5atom([1,56,0])
!  call colvar_printcv_contacts((/1,56,0/),8.0d0,tpstride=3,ifc5atom=.true.)
!  call colvar_printcv_contacts_dnaprotein((/1,56,0/),[57,nbiores,0], 8.0d0)
!  call colvar_printcv_calpharmsd((/1,numalpha,0/), stride=10)

  end if

  flush(iosiminfo)
end subroutine

subroutine colvar_addcvatoms(tpatoms)
  integer,intent(in),dimension(:) :: tpatoms
  integer :: tpni,i,j,iatom,ires,tparray(natom)
  logical :: iffind

  tparray=0
  if ( .not. allocated(cvatoms) ) then
     allocate(cvatoms(size(tpatoms))); cvnatom=0
  else
     tparray(1:cvnatom) = cvatoms(1:cvnatom)
  end if
  do i=1,size(tpatoms)
     iatom = tpatoms(i); if ( iatom == 0 ) cycle
     iffind=.false.
     do j=1,cvnatom
        if ( iatom == tparray(j) ) then
           iffind=.true.; exit
        end if
     end do
     if ( iffind .eqv. .true. ) cycle
     cvnatom = cvnatom + 1
     tparray(cvnatom) = iatom
  end do
  deallocate(cvatoms)
  allocate(cvatoms(cvnatom)); cvatoms(1:cvnatom) = tparray(1:cvnatom)
end subroutine

!subroutine colvar_check_gradient(tpcoor)
!  real*8,intent(in) :: tpcoor(3,natom)
!  real*8 :: tptpcoor(3,natom),tptpgrad(3,natom),tpvalue,tpless
!  real*8 :: h,upv,downv,maxerr,tperr,tpvec(3)
!  integer :: i,j,k,icv,tpsrvnum,tpsrvindex,tptaenum,tptaeindex,tpticanum,tpticaindex
!
!  tpsrvnum = 0; tptaenum = 0; tpticanum = 0
!  do icv = 1,ncv
!     if ( fsacvs(icv)%type == CV_SRV ) tpsrvnum = tpsrvnum + 1
!     if ( fsacvs(icv)%type == CV_TAE ) tptaenum = tptaenum + 1
!     if ( fsacvs(icv)%type == CV_TICA ) tpticanum = tpticanum + 1
!  end do
!
!  h = 0.001d0; maxerr = 0d0; tpsrvindex = 0; tptaeindex = 0; tpticaindex = 0
!  do icv = 1, ncv
!     tptpgrad = 0d0
!
!     if ( fsacvs(icv)%type == CV_SRV ) then
!        tpsrvindex = tpsrvindex + 1
!        do k = 1, tpsrvnum  ! forward propagation
!           call colvar_fsainfo(icv,tpcoor,tpvalue)
!        end do
!        do k = 1, tpsrvnum  ! backward propagation
!           if ( tpsrvindex == k ) then
!              call colvar_fsainfo(icv,tpcoor,tpvalue,tptpgrad,tpfactor=1d0)
!           else
!              call colvar_fsainfo(icv,tpcoor,tpvalue,tptpgrad,tpfactor=0d0)
!           end if
!        end do
!     else if ( fsacvs(icv)%type == CV_TAE ) then
!        tptaeindex = tptaeindex + 1
!        do k = 1, tptaenum  ! forward propagation
!           call colvar_fsainfo(icv,tpcoor,tpvalue)
!        end do
!        do k = 1, tptaenum  ! backward propagation
!           if ( tptaeindex == k ) then
!              call colvar_fsainfo(icv,tpcoor,tpvalue,tptpgrad,tpfactor=1d0)
!           else
!              call colvar_fsainfo(icv,tpcoor,tpvalue,tptpgrad,tpfactor=0d0)
!           end if
!        end do
!     else if ( fsacvs(icv)%type == CV_TICA ) then
!        tpticaindex = tpticaindex + 1
!        do k = 1, tpticanum  ! forward
!           call colvar_fsainfo(icv,tpcoor,tpvalue)
!        end do
!        do k = 1, tpticanum  ! backward
!           if ( tpticaindex == k ) then
!              call colvar_fsainfo(icv,tpcoor,tpvalue,tptpgrad,tpfactor=1d0)
!           else
!              call colvar_fsainfo(icv,tpcoor,tpvalue,tptpgrad,tpfactor=0d0)
!           end if
!        end do
!     else
!        call colvar_fsainfo(icv,tpcoor,tpvalue,tptpgrad,tpfactor=1d0)
!     end if
!
!     tptpcoor = tpcoor; tperr = 0d0
!     do i = 1, natom
!        tpvec = tpcoor(:,i)
!        do j = 1, 3
!           tptpcoor(j,i) = tpvec(j) + h
!
!           if ( fsacvs(icv)%type == CV_SRV ) then
!              do k = 1, tpsrvnum
!                 if ( tpsrvindex == k ) then
!                    call colvar_fsainfo(icv,tptpcoor,upv)
!                 else
!                    call colvar_fsainfo(icv,tptpcoor,tpless)
!                 end if
!              end do
!           else if ( fsacvs(icv)%type == CV_TAE ) then
!              do k = 1, tptaenum
!                 if ( tptaeindex == k ) then
!                    call colvar_fsainfo(icv,tptpcoor,upv)
!                 else
!                    call colvar_fsainfo(icv,tptpcoor,tpless)
!                 end if
!              end do
!           else if ( fsacvs(icv)%type == CV_TICA ) then
!              do k = 1, tpticanum
!                 if ( tpticaindex == k ) then
!                    call colvar_fsainfo(icv,tptpcoor,upv)
!                 else
!                    call colvar_fsainfo(icv,tptpcoor,tpless)
!                 end if
!              end do
!           else
!              call colvar_fsainfo(icv,tptpcoor,upv)
!           end if
!           tptpcoor(j,i) = tpvec(j) - h
!           if ( fsacvs(icv)%type == CV_SRV ) then
!              do k = 1, tpsrvnum
!                 if ( tpsrvindex == k ) then
!                    call colvar_fsainfo(icv,tptpcoor,downv)
!                 else
!                    call colvar_fsainfo(icv,tptpcoor,tpless)
!                 end if
!              end do
!           else if ( fsacvs(icv)%type == CV_TAE ) then
!              do k = 1, tptaenum
!                 if ( tptaeindex == k ) then
!                    call colvar_fsainfo(icv,tptpcoor,downv)
!                 else
!                    call colvar_fsainfo(icv,tptpcoor,tpless)
!                 end if
!              end do
!           else if ( fsacvs(icv)%type == CV_TICA ) then
!              do k = 1, tpticanum
!                 if ( tpticaindex == k ) then
!                    call colvar_fsainfo(icv,tptpcoor,downv)
!                 else
!                    call colvar_fsainfo(icv,tptpcoor,tpless)
!                 end if
!              end do
!           else
!              call colvar_fsainfo(icv,tptpcoor,downv)
!           end if
!           tptpcoor(j,i) = tpvec(j)
!           tperr = max(tperr,abs((upv-downv)/(2d0*h)-tptpgrad(j,i)))
!        end do
!     end do
!     print "(a,i5,f20.15)",'CV Gradient Error :',icv,tperr
!     maxerr = max(maxerr, tperr)
!  end do
!  print "(/,a,f20.15)","Max Error : ",maxerr
!end subroutine

subroutine colvar_printcv_helixhb_antihb()
  integer :: io,jo,ih,jh,ires,jres

  do ires = 2, nbiores - 1
     io = resindex(ires+1)
     do jres = ires + 4, nbiores - 1
        jh = resindex(jres) + 2
        write(iosiminfo,"(/,a,a,i3,1x,a3,a,a,i3,1x,a3)") "&fsacolvar  ! Helix HB, ",resname(ires),ires,name(io)," - ",resname(jres),jres,name(jh)
        write(iosiminfo,"(a)")   '  cv_type = "DISAVG"'
        write(iosiminfo,"(a,i4,a,i4)") "  cv_i = ",io,", ",jh
        write(iosiminfo,"(a)") "/"
     end do
  end do

  do ires = 2, nbiores - 1
     io = resindex(ires+1); ih = resindex(ires) + 2
     do jres = ires + 3, nbiores - 1
        jo = resindex(jres+1); jh = resindex(jres) + 2
        write(iosiminfo,"(/,a,a,i3,a,a,i3)") "&fsacolvar  ! Antibeta HB, ",resname(ires),ires," - ",resname(jres),jres
        write(iosiminfo,"(a)")   '  cv_type = "DISAVG"'
        write(iosiminfo,"(a,i4,a,i4,a,i4,a,i4)") "  cv_i = ",io,", ",jh,", ",ih,", ",jo
        write(iosiminfo,"(a)") "/"
     end do
  end do
end subroutine

subroutine colvar_printcv_calmodulin()
  integer :: iatom,jatom,katom,latom,ires,jres,kres,lres,ca2index(4),tpindex,tpstart,tpres,tpbonds(2,24),ibond
  real*8 :: tpdis,tpvec(3)

  write(iosiminfo,"(a)") "collective variable info for calmodulin"

  ires=5; jres=80; kres=146; lres=119
  iatom=resindex(ires)+3; jatom=resindex(jres)+3; katom=resindex(kres)+3; latom=resindex(lres)+3

  ires=5; jres=146
  iatom=resindex(ires)+3; jatom=resindex(jres)+3
  tpvec(1:3) = nowcoor(1:3,iatom) - nowcoor(1:3,jatom)
  tpdis = sqrt(dot_product(tpvec,tpvec))
  write(iosiminfo,"(a,2i6,f8.3)") "distance between CA in residues: ",iatom,jatom,tpdis

  ires=5; jres=80; kres=119
  iatom=resindex(ires)+3; jatom=resindex(jres)+3; katom=resindex(kres)+3
  call colvar_angle(1,nowcoor,tpdis,tpatoms=(/iatom,jatom,katom/))
  write(iosiminfo,"(a,3i6,f8.3)") "angle between CA in residues: ",iatom,jatom,katom,tpdis

  ires=40; jres=5; kres=80; lres=138
  iatom=resindex(ires)+3; jatom=resindex(jres)+3; katom=resindex(kres)+3; latom=resindex(lres)+3
  call colvar_dihedral(1,nowcoor,tpdis,tpatoms=(/iatom,jatom,katom,latom/))
  write(iosiminfo,"(a,4i6,f8.3)") "dihedral between CA in residues: ",iatom,jatom,katom,latom,tpdis
  write(iosiminfo,*)

  write(iosiminfo,*) "Calcium ions"; flush(iosiminfo)
  ca2index=0; tpindex=0
  do ires=1,nres
     if ( resname(ires) /= "CA  " ) cycle
     tpindex = tpindex + 1; ca2index(tpindex)=resindex(ires)+1
     write(iosiminfo,"(a,2i6,2a6,f8.3)") "calcium ion ",tpindex,ca2index(tpindex),resname(ires), &
                  name(ca2index(tpindex)),atomcharge(ca2index(tpindex))
  end do

  ibond = 0
  do tpindex=1,4
     select case(tpindex)
     case (1); tpstart=19
     case (2); tpstart=55
     case (3); tpstart=92
     case (4); tpstart=128
     end select

     do tpres=1,12
        ires = tpstart + tpres
        select case (tpres)
        case (1,3,5)
           do iatom=resindex(ires)+1,resindex(ires+1)
              if ( name(iatom) == "OD1 " ) then 
                 ibond=ibond+1; tpbonds(1:2,ibond)=(/ca2index(tpindex),iatom/)
              end if
           end do
        case (7)
           do iatom=resindex(ires)+1,resindex(ires+1)
              if ( name(iatom) == "O   " ) then
                 ibond=ibond+1; tpbonds(1:2,ibond)=(/ca2index(tpindex),iatom/)
              end if
           end do
        case (12)
           do iatom=resindex(ires)+1,resindex(ires+1)
              if ( (name(iatom) == "OE1 ") .or. (name(iatom) == "OE2 ") ) then
                 ibond=ibond+1; tpbonds(1:2,ibond)=(/ca2index(tpindex),iatom/)
              end if
           end do
        end select
     end do
  end do

  do ibond=1,24
     tpvec(1:3) = nowcoor(1:3,tpbonds(1,ibond)) - nowcoor(1:3,tpbonds(2,ibond))
     tpdis = sqrt(dot_product(tpvec,tpvec))
     write(iosiminfo,"(i4,2a6,f8.3)") ibond,name(tpbonds(1,ibond)),name(tpbonds(2,ibond)),tpdis
  end do

  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'NCONTACT'"
  write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpbonds(iatom,ibond),", ",iatom=1,2),ibond=1,24)
  write(iosiminfo,"(a,f4.1)") "  cv_r = ",3.0
  write(iosiminfo,"(a)") "/"

  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'DISAVG'"
  write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpbonds(iatom,ibond),", ",iatom=1,2), ibond=1,6)
  write(iosiminfo,"(a)") "/"

  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'DISAVG'"
  write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpbonds(iatom,ibond),", ",iatom=1,2), ibond=7,12)
  write(iosiminfo,"(a)") "/"

  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'DISAVG'"
  write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpbonds(iatom,ibond),", ",iatom=1,2), ibond=13,18)
  write(iosiminfo,"(a)") "/"

  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'DISAVG'"
  write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpbonds(iatom,ibond),", ",iatom=1,2), ibond=19,24)
  write(iosiminfo,"(a)") "/"


  flush(iosiminfo)
end subroutine

subroutine colvar_printcv_gyration_kdscale()
  integer :: tpresarray(nres),ires,tpnres

  if ( procid > 0 ) return

  tpnres = 0; tpresarray=0
  do ires=1,nres
     if ( reskdscale(ires) > 0d0 ) then
        tpnres = tpnres + 1; tpresarray(tpnres) = ires
     end if
  end do
  write(iosiminfo,*)
  write(iosiminfo,"(a,i6)") "#hydrophobic residues ",tpnres
  write(iosiminfo,"(a)" )
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'GYRATIONRES'"
  write(iosiminfo,"(a,1000(i3,a2))") "  cv_i = ",(tpresarray(ires),", ", ires=1,tpnres)
  write(iosiminfo,"(a)") "/"

  tpnres = 0; tpresarray=0
  do ires=1,nres
     if ( reskdscale(ires) < -3d0 ) then
        tpnres = tpnres + 1; tpresarray(tpnres) = ires
     end if
  end do
  write(iosiminfo,*)
  write(iosiminfo,"(a,i6)") "#hydrophilic residues ",tpnres
  write(iosiminfo,"(a)" )
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'GYRATIONRES'"
  write(iosiminfo,"(a,1000(i3,a2))") "  cv_i = ",(tpresarray(ires),", ", ires=1,tpnres)
  write(iosiminfo,"(a)") "/"

  flush(iosiminfo)

end subroutine

subroutine colvar_printcv_sidechainheavyatoms(ires)
  integer,intent(in) :: ires
  integer :: iatom,tpnheavy,tpheavys(100)

  tpheavys=0; tpnheavy=0
  do iatom=resindex(ires)+1, resindex(ires+1)
     if ( (name(iatom) == "N   ") .or. (name(iatom) == "CA  ") .or. &
          (name(iatom) == "O   ") .or. (name(iatom) == "C   ") .or. &
          (name(iatom)(1:1) == "H")  ) cycle
     tpnheavy = tpnheavy + 1; tpheavys(tpnheavy) = iatom
  end do
  write(iosiminfo,"(a,i5)") "heavy atoms of residue ",ires
  write(iosiminfo,"(18i6)") tpheavys(1:tpnheavy)
end subroutine

subroutine colvar_printcv_hydrophobic_pair(stride,resstart,resend,discut)
  integer,intent(in) :: stride
  integer,intent(in),optional :: resstart,resend
  real*8,intent(in),optional :: discut
  integer,parameter :: maxncontact=1000
  integer :: ires,jres,tpncontact,tpcontacts(2,maxncontact),tpresstart,tpresend
  real*8 :: tpweights(maxncontact),tprescom1(3),tprescom2(3),tpvec(3),tpdis

  tpncontact=0; tpweights=0d0; tpresstart=1; tpresend=nres
  if ( present(resstart) .and. present(resend) ) then
     tpresstart=resstart; tpresend=resend
  end if
  do ires=tpresstart,tpresend
     if ( reskdscale(ires) <= 0d0 ) cycle
     do jres=ires+stride,tpresend
        if ( reskdscale(jres) <= 0d0 ) cycle

        if ( present(discut) ) then
           call ambertop_get_com(nowcoor,tprescom1,tpres=(/ires/),ifheavy=.true.)
           call ambertop_get_com(nowcoor,tprescom2,tpres=(/jres/),ifheavy=.true.)
           tpvec(1:3) = tprescom1(1:3) - tprescom2(1:3)
           tpdis = sqrt(dot_product(tpvec,tpvec))
           if ( tpdis > discut ) cycle
        end if

        tpncontact = tpncontact + 1; tpcontacts(1:2,tpncontact)=(/ires,jres/)
        tpweights(tpncontact) = reskdscale(ires)+reskdscale(jres)
     end do
  end do

  if ( procid == 0 ) then
     write(iosiminfo,*)
     write(iosiminfo,"(a,i3,a,i3)") "#hydrophobic residue pairs ",tpncontact," with stride,",stride
     write(iosiminfo,"(a)") "&fsacolvar"
     write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRES'"
     write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpcontacts(jres,ires),", ",jres=1,2),ires=1,tpncontact)
     write(iosiminfo,"(a,1000(f4.1,a2))") "  cv_r = ",8.0d0,", ",(tpweights(ires),", ",ires=1,tpncontact)
     write(iosiminfo,"(a)") "/"
  end if
end subroutine

subroutine colvar_printcv_hydrophobic_core(tpdismark,stride,resstart,resend,tpcoor)
  integer,intent(in) :: stride
  real*8,intent(in) :: tpdismark
  integer,intent(in),optional :: resstart,resend
  real*8,intent(in),optional :: tpcoor(3,natom)
  integer,parameter :: maxncontact=1000
  integer :: ires,jres,tpncontact,tpcontacts(2,maxncontact),tpresstart,tpresend
  real*8 :: tpdis,iresvec(3),jresvec(3),tpvec(3)

  tpncontact=0; tpresstart=1; tpresend=nres
  if ( present(resstart) ) tpresstart=resstart
  if ( present(resend) ) tpresend=resend
  do ires=tpresstart,tpresend
     if ( restype(ires) /= 1 .or. resname(ires) == "GLY " ) cycle
     if ( present(tpcoor) ) then
        call ambertop_get_com(tpcoor,iresvec,tpres=(/ires/))
     else
        call ambertop_get_com(nowcoor,iresvec,tpres=(/ires/))
     end if
     do jres=ires+stride,tpresend
        if ( restype(jres) /= 1 .or. resname(jres) == "GLY " ) cycle
        if ( present(tpcoor) ) then
           call ambertop_get_com(tpcoor,jresvec,tpres=(/jres/))
        else
           call ambertop_get_com(nowcoor,jresvec,tpres=(/jres/))
        end if
        tpvec(1:3) = iresvec(1:3) - jresvec(1:3)
        tpdis = sqrt(dot_product(tpvec,tpvec)); if ( tpdis > tpdismark ) cycle
        tpncontact = tpncontact + 1; tpcontacts(1:2,tpncontact)=(/ires,jres/)
     end do
  end do

  if ( procid == 0 ) then
     write(iosiminfo,*)
     write(iosiminfo,"(a,i2,a,i3)") "#contacts in hydrophobic core, stride ",stride,", contact ",tpncontact
     write(iosiminfo,"(a)") "&fsacolvar"
     write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRES'"
     write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpcontacts(jres,ires),", ",jres=1,2),ires=1,tpncontact)
     write(iosiminfo,"(a,f4.1)") "  cv_r = ",tpdismark
     write(iosiminfo,"(a)") "/"
  end if
end subroutine

subroutine colvar_printcv_hydrophobic_core_ncontactresvec()
  integer,parameter :: maxncontact=1000
  integer :: ires,tpncontact,tpcontact(maxncontact)

  ! tpncontact=0; tpcontact=0
  ! do ires=1,nres
     ! if ( restype(ires) .eq. 1 ) then
        ! tpncontact=tpncontact+1; tpcontact(tpncontact)=ires
     ! end if
  ! end do

  ! if ( procid == 0 ) then
     ! write(iosiminfo,*)
     ! write(iosiminfo,"(a,i2,a)") "#contactresvec in hydrophobic core, contact ",tpncontact,", proteinstructures"
     ! write(iosiminfo,"(a)") "&fsacolvar"
     ! write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRESVEC'"
     ! write(iosiminfo,"(a,i2,a,i3)") "  cv_min= ",0,",cv_max= ",tpncontact*(tpncontact-1)/2+1
     ! write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",(tpcontact(ires),", ",ires=1,tpncontact)
     ! write(iosiminfo,"(a)") "/"
  ! end if

  tpncontact=0; tpcontact=0
  do ires=1,nres
     if ( reskdscale(ires) > 0d0 ) then
        tpncontact=tpncontact+1; tpcontact(tpncontact)=ires
     end if
  end do

  if ( procid == 0 ) then
     write(iosiminfo,*)
     write(iosiminfo,"(a,i3)") "#contactresvec in hydrophobic core with K-D scales > 0, contact ",tpncontact
     write(iosiminfo,"(a)") "&fsacolvar"
     write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRESVEC'"
     write(iosiminfo,"(a,i2,a,i3)") "  cv_min= ",0,", cv_max= ",tpncontact*(tpncontact-1)/2
     write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",(tpcontact(ires),", ",ires=1,tpncontact)
     write(iosiminfo,"(a,f5.1)") "  cv_r = ",8.0
     write(iosiminfo,"(a)") "/"
  end if

  tpncontact=0; tpcontact=0
  do ires=1,nres
     if ( reskdscale(ires) < 0d0 ) then
        tpncontact=tpncontact+1; tpcontact(tpncontact)=ires
     end if
  end do

  if ( procid == 0 ) then
     write(iosiminfo,*)
     write(iosiminfo,"(a,i3)") "#contactresvec in hydrophilic pairs with K-D scales < 0, contact ",tpncontact
     write(iosiminfo,"(a)") "&fsacolvar"
     write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRESVEC'"
     write(iosiminfo,"(a,i2,a,i3)") "  cv_min= ",0,", cv_max= ",tpncontact*(tpncontact-1)/2
     write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",(tpcontact(ires),", ",ires=1,tpncontact)
     write(iosiminfo,"(a,f5.1)") "  cv_r = ",8.0
     write(iosiminfo,"(a)") "/"
  end if

end subroutine

subroutine colvar_printcv_contacts(tpgs1,tpmarkdis,tpstride,tpgs2,ifcalpha,ifheavy,ifresdis,ifrescharge,ifc5atom,  &
            tpncontact,tpcontactatoms,tpcoor,tpcontactnatom)
  integer,dimension(:),intent(in) :: tpgs1
  real*8,intent(in) :: tpmarkdis
  integer,intent(in),optional :: tpstride
  integer,intent(in),dimension(:),optional :: tpgs2
  logical,intent(in),optional :: ifcalpha,ifresdis,ifrescharge,ifheavy,ifc5atom
  integer,intent(out),optional :: tpncontact,tpcontactnatom
  integer,intent(out),optional :: tpcontactatoms(natom)
  real*8,intent(in),optional :: tpcoor(3,natom)
  integer,parameter :: maxncontact=1000
  integer :: istride,igroup,jgroup,tpngroup1,tpngroup2,tpgroups1(2,nres),tpgroups2(2,nres)
  integer :: ncontact,iatom,jatom,i,j,k,m,n,ires,jres,ibond,tpcontacts(4,maxncontact)
  logical :: iffind

  istride=1; tpngroup1 = size(tpgs1)/3; tpgroups1=0
  if ( present(tpstride) ) istride=tpstride
  do igroup=1,tpngroup1
     tpgroups1(1,igroup) = tpgs1(3*igroup-2); tpgroups1(2,igroup) = tpgs1(3*igroup-1)
  end do

  ncontact=0; tpcontacts=0
  if ( .not. present(tpgs2) ) then

     do igroup=1,tpngroup1
        do ires=tpgroups1(1,igroup),tpgroups1(2,igroup)
           do jgroup=igroup,tpngroup1
              do jres=tpgroups1(1,jgroup),tpgroups1(2,jgroup)
                 if ( (jres-ires) >= istride ) then
                    if ( present(ifrescharge) ) then
                       if ( ifrescharge .eqv. .true. ) then
                          if ( rescharge(ires)*rescharge(jres) < -0.5d0 ) then 
                             ncontact = ncontact + 1
                             if ( ncontact > maxncontact ) call errormsg("too much contacts ",int1=ncontact,int2=maxncontact)
                             iatom=ires; jatom=jres; tpcontacts(1:4,ncontact) = (/iatom,jatom,ires,jres/)
                          end if
                       else
                          call findrescontact()
                       end if
                    else
                       call findrescontact()
                    end if
                 end if
              end do
           end do
        end do
     end do

  else

     tpngroup2 = size(tpgs2)/3; tpgroups2=0
     do igroup=1,tpngroup2
        tpgroups2(1,igroup) = tpgs2(3*igroup-2); tpgroups2(2,igroup) = tpgs2(3*igroup-1)
     end do

     do igroup=1,tpngroup1
        do ires=tpgroups1(1,igroup),tpgroups1(2,igroup),istride
           do jgroup=1,tpngroup2
              do jres=tpgroups2(1,jgroup),tpgroups2(2,jgroup),istride
                 if ( present(ifrescharge) ) then
                    if ( ifrescharge .eqv. .true. ) then
                       if ( rescharge(ires)*rescharge(jres) < -0.5d0 ) then
                          ncontact = ncontact + 1
                          if ( ncontact > maxncontact ) call errormsg("too much contacts ",int1=ncontact,int2=maxncontact)
                          iatom=ires; jatom=jres; tpcontacts(1:4,ncontact) = (/iatom,jatom,ires,jres/)
                       end if
                    else
                       call findrescontact()
                    end if
                 else
                    call findrescontact()
                 end if
              end do
           end do
        end do
     end do

  end if

  if ( procid == 0 ) then
     write(iosiminfo,*)
     write(iosiminfo,"(a)") "&fsacolvar"
     write(iosiminfo,"(a)") "  cv_type = 'NCONTACT'"
     write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpcontacts(iatom,ibond),", ",iatom=1,2),ibond=1,ncontact)
     write(iosiminfo,"(a,f4.1)") "  cv_r = ",tpmarkdis
     write(iosiminfo,"(a)") "/"
  end if

  if ( present(tpncontact) ) tpncontact=ncontact
  if ( present(tpcontactatoms) ) then
     tpcontactatoms=0; k=0; m=0
     do i=1,ncontact
        do j=1,2
           iffind = .false.
           do k=1,m
              if ( tpcontactatoms(k) == tpcontacts(j,i) ) then
                 iffind = .true.; exit
              end if
           end do
           if ( iffind .eqv. .false. ) then
              m = m + 1; tpcontactatoms(m) = tpcontacts(j,i)
              do k=1,m-1
                 if ( tpcontactatoms(m) < tpcontactatoms(k) ) then
                    do n=m,k+1,-1
                       tpcontactatoms(n) = tpcontactatoms(n-1)
                    end do
                    tpcontactatoms(k) = tpcontacts(j,i)
                    exit
                 end if
              end do
           end if 
        end do
     end do
     if ( procid == 0 ) then
        write(iosiminfo,"(a,i6)") "number of contact atoms ",m
        write(iosiminfo,"(18i6)") tpcontactatoms(1:m)
     end if
     if ( present(tpcontactnatom) ) tpcontactnatom = m
  end if

contains
  subroutine findrescontact()
    real*8 :: tpdis,tpmindis,tpvec(3),tprescom1(3),tprescom2(3)

    tpmindis = 10000.0d0
    if ( .not. present(ifresdis) ) then
       do i=resindex(ires)+1,resindex(ires+1)
          if ( (present(ifcalpha)) .and. (name(i)(1:4) /= "CA  ") ) cycle
          if ( (present(ifheavy)) .and. (name(i)(1:1) == "H") ) cycle
          if ( (present(ifc5atom)) .and. (name(i)(1:4) /= "C5  ") ) cycle

          do j=resindex(jres)+1,resindex(jres+1)
             if ( (present(ifcalpha)) .and. (name(j)(1:4) /= "CA  ") ) cycle
             if ( (present(ifheavy)) .and. (name(j)(1:1) == "H") ) cycle
             if ( (present(ifc5atom)) .and. (name(j)(1:4) /= "C5  ") ) cycle
             if ( present(tpcoor) ) then
                tpvec(1:3) = tpcoor(1:3,i) - tpcoor(1:3,j)
             else
                tpvec(1:3) = nowcoor(1:3,i) - nowcoor(1:3,j)
             end if
             tpdis = sqrt(dot_product(tpvec,tpvec))
             if ( tpdis < tpmindis ) then
                tpmindis = tpdis; iatom = i; jatom=j
             end if
          end do
       end do
    else
       call ambertop_get_com(nowcoor,tprescom1,tpres=(/ires/),ifheavy=ifheavy)
       call ambertop_get_com(nowcoor,tprescom2,tpres=(/jres/),ifheavy=ifheavy)
       tpvec(1:3) = tprescom1(1:3) - tprescom2(1:3)
       tpmindis = sqrt(dot_product(tpvec,tpvec)); iatom=ires; jatom=jres
    end if

    if ( tpmindis < tpmarkdis ) then
       ncontact = ncontact + 1
       if ( ncontact > maxncontact ) call errormsg("too much contacts ",int1=ncontact,int2=maxncontact)
       tpcontacts(1:4,ncontact) = (/iatom,jatom,ires,jres/)
!       write(iosiminfo,"(a,i3,a1,3x,a4,i3,a1,a4,a3,a4,i3,a1,a4)")  &
!          "contacts ",ncontact,":",resname(tpcontacts(3,ncontact)), &
!          tpcontacts(3,ncontact),":",name(tpcontacts(1,ncontact))," - ",resname(tpcontacts(4,ncontact)), &
!          tpcontacts(4,ncontact),":",name(tpcontacts(2,ncontact))
    end if
  end subroutine
end subroutine

subroutine colvar_printcv_contacts_dnaprotein(tpgs1,tpgs2,tpmarkdis)
  integer,dimension(:),intent(in) :: tpgs1,tpgs2
  real*8,intent(in) :: tpmarkdis
  integer,parameter :: maxncontact=1000
  integer :: istride,igroup,jgroup,tpngroup1,tpngroup2,tpgroups1(2,nres),tpgroups2(2,nres)
  integer :: ncontact,iatom,jatom,i,j,k,m,n,ires,jres,ibond,tpcontacts(4,maxncontact)
  logical :: iffind

  tpngroup1 = size(tpgs1)/3; tpgroups1=0
  do igroup=1,tpngroup1
     tpgroups1(1,igroup) = tpgs1(3*igroup-2); tpgroups1(2,igroup) = tpgs1(3*igroup-1)
  end do

  tpngroup2 = size(tpgs2)/3; tpgroups2=0
  do igroup=1,tpngroup2
     tpgroups2(1,igroup) = tpgs2(3*igroup-2); tpgroups2(2,igroup) = tpgs2(3*igroup-1)
  end do

  ncontact=0; tpcontacts=0; istride=1

  do igroup=1,tpngroup1
     do ires=tpgroups1(1,igroup),tpgroups1(2,igroup),istride
        do jgroup=1,tpngroup2
           do jres=tpgroups2(1,jgroup),tpgroups2(2,jgroup),istride
              call findrescontact()
           end do
        end do
     end do
  end do

  if ( procid == 0 ) then
     write(iosiminfo,*)
     write(iosiminfo,"(a)") "&fsacolvar"
     write(iosiminfo,"(a)") "  cv_type = 'NCONTACT'"
     write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",((tpcontacts(iatom,ibond),", ",iatom=1,2),ibond=1,ncontact)
     write(iosiminfo,"(a,f4.1)") "  cv_r = ",tpmarkdis
     write(iosiminfo,"(a)") "/"
  end if

contains
  subroutine findrescontact()
    real*8 :: tpdis,tpmindis,tpvec(3),tprescom1(3),tprescom2(3)

    tpmindis = 10000.0d0
    do i=resindex(ires)+1,resindex(ires+1)
       if (  name(i)(1:4) /= "C5  ") cycle
       do j=resindex(jres)+1,resindex(jres+1)
          if ( name(j)(1:1) == "H" ) cycle
          tpvec(1:3) = nowcoor(1:3,i) - nowcoor(1:3,j)
          tpdis = sqrt(dot_product(tpvec,tpvec))
          if ( tpdis < tpmindis ) then
             tpmindis = tpdis; iatom = i; jatom=j
          end if
       end do
    end do

    if ( tpmindis < tpmarkdis ) then
       ncontact = ncontact + 1
       if ( ncontact > maxncontact ) call errormsg("too much contacts ",int1=ncontact,int2=maxncontact)
       tpcontacts(1:4,ncontact) = (/iatom,jatom,ires,jres/)
    end if
  end subroutine
end subroutine

subroutine colvar_printcv_calpharmsd(tpgs, stride)
  integer,intent(in),dimension(:) :: tpgs
  integer,intent(in),optional :: stride
  integer :: igroup,tpngroup,tpnres,ires,index,tpgroups(2,nres),tpstride,tpn(nres)
  character*150:: tpformat

  tpstride=1; if ( present(stride) ) tpstride=stride
  tpngroup = size(tpgs)/3; tpnres=0
  do igroup=1,tpngroup
     tpgroups(1,igroup) = tpgs(3*igroup-2); tpgroups(2,igroup) = tpgs(3*igroup-1)
     ires=0
     do index=tpgroups(1,igroup),tpgroups(2,igroup),tpstride
        ires = ires + 1
     end do
     tpn(igroup) = ires
     tpnres = tpnres + ires
  end do
  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'RMSD'"
  write(iosiminfo,"(a,i3,a,i4)") "  cv_ni= ",tpnres+tpngroup,", cv_nr=",(tpnres*3)

  tpformat(1:3)="(a,"; index=4
  do igroup=1,tpngroup 
     write(tpformat(index+(igroup-1)*17:index+(igroup-1)*17+16),"(i3,a14)") &
          tpn(igroup),"(i5,a2),'0, ',"
  end do
  tpformat(index+tpngroup*17-1:index+tpngroup*17-1) = ")"
  write(iosiminfo,fmt=tpformat) "  cv_i = ",((calpha(ires),", ",  &
          ires=tpgroups(1,igroup),tpgroups(2,igroup),tpstride),igroup=1,tpngroup)

  write(iosiminfo,"(a)") "  cv_r = "
  do igroup=1,tpngroup
      write(iosiminfo,"(6(f10.3,a2))") ((nowcoor(index,calpha(ires)),", ",index=1,3), &
                 ires=tpgroups(1,igroup),tpgroups(2,igroup),tpstride)
  end do
  write(iosiminfo,"(a)") "/"
  flush(iosiminfo)
end subroutine

subroutine colvar_printcv_dna_backbonermsd_o5atom(tpgs, stride)
  integer,intent(in),dimension(:) :: tpgs
  integer,intent(in),optional :: stride
  integer :: igroup,tpngroup,tpnres,ires,index,tpgroups(2,nres),tpstride,tpn(nres)
  character*150:: tpformat

  tpstride=1; if ( present(stride) ) tpstride=stride
  tpngroup = size(tpgs)/3; tpnres=0
  do igroup=1,tpngroup
     tpgroups(1,igroup) = tpgs(3*igroup-2); tpgroups(2,igroup) = tpgs(3*igroup-1)
     ires=0
     do index=tpgroups(1,igroup),tpgroups(2,igroup),tpstride
        ires = ires + 1
     end do
     tpn(igroup) = ires
     tpnres = tpnres + ires
  end do
  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&fsacolvar"
  write(iosiminfo,"(a)") "  cv_type = 'RMSD'"
  write(iosiminfo,"(a,i3,a,i4)") "  cv_ni= ",tpnres+tpngroup,", cv_nr=",(tpnres*3)

  tpformat(1:3)="(a,"; index=4
  do igroup=1,tpngroup
     write(tpformat(index+(igroup-1)*17:index+(igroup-1)*17+16),"(i3,a14)") &
          tpn(igroup),"(i5,a2),'0, ',"
  end do
  tpformat(index+tpngroup*17-1:index+tpngroup*17-1) = ")"
  write(iosiminfo,fmt=tpformat) "  cv_i = ",((o5atoms(ires),", ",  &
          ires=tpgroups(1,igroup),tpgroups(2,igroup),tpstride),igroup=1,tpngroup)

  write(iosiminfo,"(a)") "  cv_r = "
  do igroup=1,tpngroup
      write(iosiminfo,"(6(f10.3,a2))") ((nowcoor(index,o5atoms(ires)),", ",index=1,3), &
                 ires=tpgroups(1,igroup),tpgroups(2,igroup),tpstride)
  end do
  write(iosiminfo,"(a)") "/"
  flush(iosiminfo)
end subroutine

subroutine colvar_printcv_backbonermsd(tpgs)
  integer,intent(in),dimension(:) :: tpgs
  integer :: igroup,tpngroup,tpnres,ires,index,tpgroups(2,nres),i
  character*150:: tpformat

  tpngroup = size(tpgs)/3; tpnres=0
  do igroup=1,tpngroup
     tpgroups(1,igroup) = tpgs(3*igroup-2); tpgroups(2,igroup) = tpgs(3*igroup-1)
     tpnres = tpnres + tpgroups(2,igroup) - tpgroups(1,igroup) + 1
  end do
  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&colvar"
  write(iosiminfo,"(a)") "  cv_type = 'MULTI_RMSD'"
  write(iosiminfo,"(a,i3,a,i4)") "  cv_ni= ",tpnres*3+tpngroup,", cv_nr=",(tpnres*9)

  tpformat(1:3)="(a,"; index=4
  do igroup=1,tpngroup 
     write(tpformat(index+(igroup-1)*17:index+(igroup-1)*17+16),"(i3,a14)") &
          (tpgroups(2,igroup)-tpgroups(1,igroup)+1)*3,"(i4,a2),'0, ',"
  end do
  tpformat(index+tpngroup*17-1:index+tpngroup*17-1) = ")"
  write(iosiminfo,fmt=tpformat) "  cv_i = ",(( (backbone(i),", ", i=3*ires-2,3*ires),  &
          ires=tpgroups(1,igroup),tpgroups(2,igroup)),igroup=1,tpngroup)

  write(iosiminfo,"(a)") "  cv_r = "
  do igroup=1,tpngroup
      write(iosiminfo,"(6(f10.3,a2))") (((nowcoor(index,backbone(i)),", ",index=1,3),i=3*ires-2,3*ires), &
                 ires=tpgroups(1,igroup),tpgroups(2,igroup))
  end do
  write(iosiminfo,"(a)") "/"
  flush(iosiminfo)
end subroutine

subroutine colvar_printcv_heavyrmsd(tpgs)
  integer,intent(in),dimension(:) :: tpgs
  integer :: igroup,tpngroup,tpnres,ires,index,i,iatom,tpnheavy,tpheavys(numheavy),tpheavyindex(0:numheavy)
  character*150:: tpformat

  tpngroup = size(tpgs)/3; tpnres=0; tpnheavy=0; tpheavyindex=0
  do igroup=1,tpngroup
     do ires = tpgs(3*igroup-2), tpgs(3*igroup-1)
        do iatom=resindex(ires)+1, resindex(ires+1)
           if ( (name(iatom)(1:1) == "N") .or. (name(iatom)(1:1) == "C") .or. &
                (name(iatom)(1:1) == "O") .or. (name(iatom)(1:1) == "S") .or. &
                (name(iatom)(1:1) == "P") )  then
              tpnheavy = tpnheavy + 1; tpheavys(tpnheavy) = iatom
           end if
        end do
     end do
     tpheavyindex(igroup) = tpnheavy
  end do

  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&colvar"
  write(iosiminfo,"(a)") "  cv_type = 'MULTI_RMSD'"
  write(iosiminfo,"(a,i3,a,i4)") "  cv_ni= ",tpnheavy+tpngroup,", cv_nr=",(tpnheavy*3)

  tpformat(1:3)="(a,"; index=4
  do igroup=1,tpngroup
     write(tpformat(index+(igroup-1)*17:index+(igroup-1)*17+16),"(i3,a14)") &
          tpheavyindex(igroup)-tpheavyindex(igroup-1),"(i4,a2),'0, ',"
  end do
  tpformat(index+tpngroup*17-1:index+tpngroup*17-1) = ")"
  write(iosiminfo,fmt=tpformat) "  cv_i = ", ( tpheavys(i),", ", i=1,tpnheavy )

  write(iosiminfo,"(a)") "  cv_r = "
  do igroup=1,tpngroup
      write(iosiminfo,"(6(f10.3,a2))") &
      ( (nowcoor(index,tpheavys(i)),", ",index=1,3),i=tpheavyindex(igroup-1)+1, tpheavyindex(igroup) )
  end do
  write(iosiminfo,"(a)") "/"
  flush(iosiminfo)
end subroutine

subroutine colvar_printcv_backbonenhb(istart,istop,iskip,tpdismark,tpanglemark,tpcoor)
  integer,intent(in) :: istart,istop,iskip
  real*8,intent(in),optional :: tpdismark,tpcoor(3,natom),tpanglemark
  integer :: nhb,iatom,jatom,ires,jres,io,in,ih,io2,ih2,in2,hbonds(4,nres*4),ibond
  real*8 :: tpvec(3),tpdis,tpdis0,tpangle0,tpangle

  nhb=0; tpdis0=2.5d0; if ( present(tpdismark) ) tpdis0=tpdismark
  tpangle0=90d0*pi/180d0; if ( present(tpanglemark) ) tpangle0 = tpanglemark*pi/180d0
  do ires=istart,istop
!     if ( (resname(ires)=="ACE ") .or. (resname(ires)=="NME ") .or. (resname(ires)=="NH2 ") ) cycle 
     if ( resname(ires) == "PRO " ) cycle
     io = 0; ih = 0; in = 0
     do iatom=resindex(ires)+1,resindex(ires+1)
        if ( name(iatom)(1:4) == "O   " ) then
           io = iatom
        else if ( name(iatom)(1:4) == "H   " ) then
           ih = iatom
        else if ( name(iatom)(1:4) == "N   " ) then
           in = iatom
        end if
     end do
     if ( (io == 0) .or. (ih == 0) .or. (in == 0) ) cycle
     
     do jres = ires + iskip, istop
        if ( resname(jres) == "PRO " ) cycle
        io2 = 0; ih2 = 0; in2 = 0
        do jatom = resindex(jres)+1,resindex(jres+1)
           if ( name(jatom)(1:4) == "O   " ) then
              io2 = jatom
           else if ( name(jatom)(1:4) == "H   " ) then
              ih2 = jatom
           else if ( name(jatom)(1:4) == "N   " ) then
              in2 = jatom
           end if
        end do
        if ( (io2 == 0) .or. (ih2 == 0) .or. (in2 == 0) ) cycle

        if ( present(tpcoor) ) then
           tpvec(1:3) = tpcoor(1:3,io) - tpcoor(1:3,ih2)
        else
           tpvec(1:3) = nowcoor(1:3,io) - nowcoor(1:3,ih2)
        end if
        tpdis = sqrt(dot_product(tpvec,tpvec))
        call colvar_angle(1,tpcoor,tpangle,tpatoms=(/in2,ih2,io/))
        if ( (tpdis < tpdis0) .and. (tpangle > tpangle0) ) then
           nhb = nhb + 1
           hbonds(1:4,nhb) = (/io,ih2,ires,jres/)
           write(iosiminfo,"(a,i3,a1,3x,a4,i3,a1,a4,a3,a4,i3,a1,a4)")  &
                 "hbond ",nhb,":",resname(hbonds(3,nhb)),hbonds(3,nhb),":", &
           name(hbonds(1,nhb))," - ",resname(hbonds(4,nhb)),hbonds(4,nhb),":",name(hbonds(2,nhb))
        end if

        if ( present(tpcoor) ) then
           tpvec(1:3) = tpcoor(1:3,ih) - tpcoor(1:3,io2)
        else
           tpvec(1:3) = nowcoor(1:3,ih) - nowcoor(1:3,io2)
        end if
        tpdis = sqrt(dot_product(tpvec,tpvec))
        call colvar_angle(1,tpcoor,tpangle,tpatoms=(/in,ih,io2/))
        if ( (tpdis < tpdis0) .and. (tpangle > tpangle0) ) then
           nhb = nhb + 1
           hbonds(1:4,nhb) = (/ih,io2,ires,jres/)
           write(iosiminfo,"(a,i3,a1,3x,a4,i3,a1,a4,a3,a4,i3,a1,a4)")  &
                 "hbond ",nhb,":",resname(hbonds(3,nhb)),hbonds(3,nhb),":", &
           name(hbonds(1,nhb))," - ",resname(hbonds(4,nhb)),hbonds(4,nhb),":",name(hbonds(2,nhb))
        end if

        if ( nhb >= 4*nres ) call errormsg("hbonds array is too small!",int1=4*nres)
     end do
  end do

  write(iosiminfo,*)
  write(iosiminfo,*) "total hydrogen bonds in backbone"
  write(iosiminfo,"(a)") "&colvar"
  write(iosiminfo,"(a)") "  cv_type = 'N_OF_BONDS'"
  write(iosiminfo,"(a,i3,a,i2)") "  cv_ni= ",nhb*2,", cv_nr= ",1
  write(iosiminfo,"(a,100(i4,a2))") "  cv_i = ",((hbonds(iatom,ibond),", ",iatom=1,2),ibond=1,nhb)
  write(iosiminfo,"(a,f4.1)") "  cv_r = ",3.0d0
  write(iosiminfo,"(a)") "/"

  return
  write(iosiminfo,"(a)") "every backbone h-bond distance"
  do ibond = 1, nhb
     write(iosiminfo,*)
     write(iosiminfo,"(a)") "&colvar"
     write(iosiminfo,"(a)") "  cv_type = 'DISTANCE'"
     write(iosiminfo,"(a,i3,a,i4)") "  cv_ni= ",2
     write(iosiminfo,"(a,i4,a2,i4)") "  cv_i = ",hbonds(1,ibond),", ",hbonds(2,ibond)
     write(iosiminfo,"(a)") "/"
  end do
end subroutine

subroutine colvar_printcv_chain2chaindis(chainarray1,chainarray2)
  integer,intent(in),dimension(:) :: chainarray1,chainarray2
  integer :: i,ires,igroup,tpngroup1,tpngroup2,tpgroup1(2,nres),tpgroup2(2,nres),tpnres1,tpnres2

  tpngroup1=size(chainarray1,1); tpngroup2=size(chainarray2,1); tpnres1=0; tpnres2=0
  do i=1,tpngroup1
     igroup = chainarray1(i)
     tpgroup1(1,i) = molindex(igroup)+1; tpgroup1(2,i) = molindex(igroup+1)
     tpnres1 = tpnres1 + tpgroup1(2,i) - tpgroup1(1,i) + 1
  end do
  do i=1,tpngroup2
     igroup = chainarray2(i)
     tpgroup2(1,i) = molindex(igroup)+1; tpgroup2(2,i) = molindex(igroup+1)
     tpnres2 = tpnres2 + tpgroup2(2,i) - tpgroup2(1,i) + 1
  end do

  write(iosiminfo,*)
  write(iosiminfo,"(a)") "&colvar"
  write(iosiminfo,"(a)") "  cv_type = 'COM_DISTANCE'"
  write(iosiminfo,"(a,i6)") "  cv_ni= ",tpnres1+tpnres2+1
  write(iosiminfo,"(a,100(i4,a2))") "  cv_i = ",((calpha(ires),",",ires=tpgroup1(1,igroup),tpgroup1(2,igroup)), &
                             igroup=1,tpngroup1)
  write(iosiminfo,"(a,100(i4,a2))") "      0, ",((calpha(ires),",",ires=tpgroup2(1,igroup),tpgroup2(2,igroup)), &
                             igroup=1,tpngroup2)
  write(iosiminfo,"(a)") "/"
  flush(iosiminfo)
end subroutine

subroutine colvar_printcv_calpha2calphadis()
  integer :: ires,jres

  do ires = 1, nres
     do jres = ires + 4, nres
        print "(/,a,2i3)","&fsacolvar ! calpha-calpha distance ",ires,jres
        print "(a,i4,a2,i4)","  cv_type = 'DISAVG', cv_i = ",calpha(ires),", ",calpha(jres)
        print "(a)","/"
     end do
  end do
end subroutine

subroutine colvar_printcv_phipsichi(ifsincos)
  logical,intent(in),optional :: ifsincos 
  integer :: iatom,ires,i,j,k,l,itype

  do ires = 1, nbiores
     if ( ires > 1 ) then
        i = backbone(3*ires-3); j = backbone(3*ires-2); k = backbone(3*ires-1); l = backbone(3*ires)
        if ( .not. present(ifsincos) ) then
           print "(/,a,a,i3)","&fsacolvar ! backbone dihedral PHI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'DIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
        else if ( ifsincos .eqv. .true. ) then
           print "(/,a,a,i3)","&fsacolvar ! backbone dihedral PHI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'SINDIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
           print "(/,a,a,i3)","&fsacolvar ! backbone dihedral PHI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'COSDIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
        end if
     end if

     if ( ires < nres ) then
        i = backbone(3*ires-2); j = backbone(3*ires-1); k = backbone(3*ires); l = backbone(3*ires+1)
        if ( .not. present(ifsincos) ) then
           print "(/,a,a,i3)","&fsacolvar ! backbone dihedral PSI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'DIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
        else if ( ifsincos .eqv. .true. ) then
           print "(/,a,a,i3)","&fsacolvar ! backbone dihedral PSI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'SINDIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
           print "(/,a,a,i3)","&fsacolvar ! backbone dihedral PSI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'COSDIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
        end if        
     end if

     if ( resname(ires) == "GLY " .or. resname(ires) == "PRO " .or. resname(ires) == "ALA " ) cycle
     i = 0 ; j = 0; k = 0; l = 0
     do iatom = resindex(ires)+1, resindex(ires+1)
        select case(name(iatom))
           case ("N   "); i = iatom
           case ("CA  "); j = iatom
           case ("CB  "); k = iatom
           case ("CG  ", "OG  ", "SG  ", "CG1 ", "CG2 "); l = iatom
        end select
     end do
     if ( i /= 0 .and. j /= 0 .and. k /= 0 .and. l /= 0 ) then
        if ( .not. present(ifsincos) ) then
           print "(/,a,a,i3)","&fsacolvar ! sidechain dihedral CHI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'DIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
        else if ( ifsincos .eqv. .true. ) then
           print "(/,a,a,i3)","&fsacolvar ! sidechain dihedral CHI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'SINDIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
           print "(/,a,a,i3)","&fsacolvar ! sidechain dihedral CHI, residue ",resname(ires),ires
           print "(a,i4,a2,i4,a2,i4,a2,i4)","  cv_type = 'COSDIHEDRAL', cv_i = ",i,", ",j,", ",k,", ",l
           print "(a)","/"
        end if
     else
        call errormsg("dihedral error!",int1=ires,str1=resname(ires))
     end if
  end do
end subroutine

subroutine colvar_calandrec(tpcvvec,ifnorecord,ifrecmovie)
  use srv, only : srv_train
  use deep, only : trajmin,trajmax,deep_traj_normalization,srvavgmode,ntau,netnum,batchsize,batchnum,ninput,deepntotdata,jobtype,timestepsize,deeptrajcoor,deeptrajindex
  use mlp, only : mlp_initialize

  real*8,intent(out) :: tpcvvec(ncv)
  logical,intent(in),optional :: ifnorecord
  logical,intent(out),optional :: ifrecmovie
  integer,save :: ioprocinfo,tptotntraj
  integer,dimension(:),allocatable,save :: iolevel,tplastnkelvin,tptrajindex
  real*8,save :: moviecvvalue
  integer :: i,j,k,icv,ierr,iatom,ires,ikelvin
  integer,dimension(0:procnum-1) :: tpcountarray,tpposarray,tprepnkelvin
  real*8 :: tpreppot(0:procnum-1),tprepcv(1:ncv,0:procnum-1)
  real*8 :: temp,tpcoor(3,natom),tpvec(3)
  character*100 :: tpfilename

  do icv = 1, ncv
     call colvar_fsainfo(icv,nowcoor,tpcvvec(icv))
  end do
  if ( present(ifnorecord) ) then
     if ( ifnorecord .eqv. .true. ) return
  end if

  if ( mod(nowstep,printcvstep) /= 0 ) call errormsg("error ",int1=nowstep,int2=printcvstep)

  if ( present(ifrecmovie) ) then
     ifrecmovie= .false.
     if ( moviecv /= 0 ) then
        if ( ( (moviecv < 0 ) .and. (tpcvvec(iabs(moviecv)) < moviecvvalue) ) .or. &
             ( (moviecv > 0 ) .and. (tpcvvec(iabs(moviecv)) > moviecvvalue) ) .or. &
             ( moviecvvalue == 0.0d0 ) ) then
           ifrecmovie = .true.
           moviecvvalue = tpcvvec(iabs(moviecv))
        end if
     end if
  end if

! save cvs to each temperature level file by the root process
  if ( (itrajtype == 1) .or. (itrajtype == 3) ) then
  if ( procid == 0 ) then
     tpcountarray(0:procnum-1)=1
     do i=0,procnum-1; tpposarray(i)=i; end do
  end if
  call mpi_gatherv(nowikelvin, 1, mpi_integer, &
       tprepnkelvin, tpcountarray, tpposarray,mpi_integer,0,mpi_comm_world, ierr)
  call mpi_gatherv(epot, 1, mpi_double_precision, &
       tpreppot, tpcountarray, tpposarray,mpi_double_precision,0,mpi_comm_world, ierr)
  if ( procid == 0 ) then
     tpcountarray(0:procnum-1)=ncv
     do i=0,procnum-1; tpposarray(i)=i*ncv; end do
  end if
  call mpi_gatherv(tpcvvec, ncv, mpi_double_precision, &
       tprepcv, tpcountarray, tpposarray, mpi_double_precision,0,mpi_comm_world, ierr)

  if ( reccvndata > 0 ) then
     reccvidata = reccvidata + 1

     if ( .not. allocated(rectrajindex) ) then
        reccvndata = reccvndata*reccvnkelvin
        call MPISharedMemoryAllocate(i, dimreal2d=(/reccvend-reccvstart+1,reccvndata/), sharereal2d=rectrajcoor)
        call MPISharedMemoryAllocate(i, dimint1d=(/reccvndata/), shareint1d=rectrajindex)
        if ( shareid == 0 ) then
           rectrajcoor = 0d0; rectrajindex = 0
        end if
     end if

     if ( deepntotdata > 0 .and. (.not. allocated(deeptrajindex)) ) then
        deepntotdata = reccvndata
        call MPISharedMemoryAllocate(i, dimreal2d=(/ninput,deepntotdata/), sharereal2d=deeptrajcoor)
        call MPISharedMemoryAllocate(i, dimint1d=(/deepntotdata/), shareint1d=deeptrajindex)
        if ( shareid == 0 ) then
           deeptrajcoor = 0d0; deeptrajindex = 0
        end if
        if ( batchnum == 0 ) then
           batchnum = (deepntotdata - 1)/batchsize + 1
        else if ( batchnum > ((deepntotdata - 1)/batchsize + 1) ) then
           call errormsg("batchnum exceeds the maximum ", int1=batchnum, int2=((deepntotdata - 1)/batchsize + 1))
        end if

        if ( procid == 0 ) then
           write(iosiminfo,*)
           write(iosiminfo, "(a,i10)") "          Batch Size : ",batchsize
           write(iosiminfo, "(a,i10)") "   Number of Batches : ",batchnum
           write(iosiminfo, "(a,i10)") "    SRV Average Mode : ",srvavgmode
           write(iosiminfo, "(a,i10)") "    Lagged time step : ",ntau
           write(iosiminfo,*)
        end if
     end if
  end if

  if ( procid == 0 ) then
     if ( .not. allocated(iolevel) ) then
        allocate(iolevel(0:procnum-1),tptrajindex(0:procnum-1),tplastnkelvin(0:procnum-1));
        iolevel=0; tptrajindex=0; tplastnkelvin=0
        do ikelvin=0,nkelvin-1
           call getfreeunit(iolevel(ikelvin)); write(tpfilename,"(i4)") ikelvin
           tpfilename=adjustl(tpfilename)
           tpfilename="procinfo/levelinfo_"//trim(tpfilename)//".txt"
           open(file=tpfilename, unit=iolevel(ikelvin), action="write")
           tptrajindex(ikelvin) = ikelvin + 1
        end do
        tptotntraj = procnum; tplastnkelvin = tprepnkelvin
     end if

     do i=0,procnum-1
        ikelvin = tprepnkelvin(i)
        if ( ikelvin /= tplastnkelvin(i) ) then
           tptotntraj = tptotntraj + 1; tptrajindex(i) = tptotntraj
        end if
        write(iolevel(ikelvin),"(f10.3,i3,i6,f12.3,2000f8.3)") nowtime, i, tptrajindex(i), tpreppot(i), tprepcv(1:ncv,i)
        flush(iolevel(ikelvin))

        if ( reccvndata > 0 .and. ikelvin < reccvnkelvin ) then
           k = reccvidata+ikelvin*reccvndata/reccvnkelvin
           rectrajcoor(:, k) = tprepcv(reccvstart:reccvend,i)
           rectrajindex(k) = tptrajindex(i)
        end if

     end do

     tplastnkelvin(0:procnum-1) = tprepnkelvin(0:procnum-1)
  end if
  end if

  call mpi_barrier(mpi_comm_world,ierr)

  if ( reccvndata > 0 .and. reccvidata == reccvndata/reccvnkelvin ) then
     reccvidata = 0
     if ( deepntotdata > 0 ) then
        deeptrajcoor = rectrajcoor; deeptrajindex = rectrajindex
        if ( procid == 0 ) call deep_traj_normalization(ifresettrajmin=.true.)
        call mpi_bcast(trajmin, ninput , mpi_double_precision, 0, mpi_comm_world, ierr)
        call mpi_bcast(trajmax, ninput , mpi_double_precision, 0, mpi_comm_world, ierr)
        if ( procid > reccvnkelvin ) then
           if ( procid == procnum - 1 ) then
              call srv_train(ifsavenetwork=.true.)
           else
              call srv_train(ifsavenetwork=.false.)
           end if
        end if
     end if
  end if

  call mpi_barrier(mpi_comm_world,ierr)

! save cvs on each proccess
  if ( (itrajtype==2) .or. (itrajtype==3) ) then
     if ( ioprocinfo == 0 ) then
        call getfreeunit(ioprocinfo); write(tpfilename,"(i4)") procid; tpfilename=adjustl(tpfilename)
        tpfilename="procinfo/procinfo_"//trim(tpfilename)//".txt"
        open(file=tpfilename, unit=ioprocinfo, action="write")
     end if
     write(ioprocinfo,"(f10.3,i3,f12.3,2000f8.3)") nowtime,nowikelvin,epot,tpcvvec(1:ncv)
     flush(ioprocinfo)
  end if

end subroutine

subroutine colvar_fsainfo(icv,tpcoor,tpvalue,tpgrad, tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  if ( fsacvs(icv)%type == CV_COM_POS ) then
     call colvar_com_pos(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_COM_DIS ) then
     call colvar_com_dis(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_COM_POSAXIS ) then
     call colvar_com_posaxis(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_PCA ) then
     call colvar_pca(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_RMSD ) then
     call colvar_rmsd(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DRMSD ) then
     call colvar_drmsd(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DISAVG ) then
     call colvar_disavg(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DIHEDRAL ) then
     call colvar_dihedral(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_ANGLE ) then
     call colvar_angle(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_BOND ) then
     call colvar_bond(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT ) then
     call colvar_pot(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_BOND ) then
     call colvar_pot_bond(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_ANGLE ) then
     call colvar_pot_angle(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_DIHE ) then
     call colvar_pot_dihe(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_ELECVDW14 ) then
     call colvar_pot_elecvdw14(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_ELEC ) then
     call colvar_pot_elec(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_VDW ) then
     call colvar_pot_vdw(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_GB ) then
     call colvar_pot_gb(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_GASGB ) then
     call colvar_pot_gasgb(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_POT_GAS ) then
     call colvar_pot_gas(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_NCONTACT ) then
     call colvar_ncontact(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_NCONTACTRES ) then
     call colvar_ncontactres(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_NRESSTATE ) then
     call colvar_nresstate(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DISAVGRES ) then
     call colvar_disavgres(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_NANTIHB ) then
     call colvar_nantihb(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_GYRATION ) then
     call colvar_gyration(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_GYRATIONRES ) then
     call colvar_gyrationres(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_GYRATIONRESAVG ) then
     call colvar_gyrationresavg(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_NCONTACTRESVEC ) then
     call colvar_ncontactresvec(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DIHEDRAL_ENDEND ) then
     call colvar_dihedral_endend(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_RMSD_ENDEND ) then
     call colvar_rmsd_endend(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DRMSD_ENDEND ) then
     call colvar_drmsd_endend(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DISAVG_ENDEND ) then
     call colvar_disavg_endend(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_DISAVG_END4 ) then
     call colvar_disavg_end4(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_COM_DIS_RES ) then
     call colvar_com_dis_res(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_COS_OF_DIHEDRAL ) then
     call colvar_cos_of_dihedral(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_ANGLE_BETWEEN_HELIX ) then
     call colvar_angle_between_helix(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_PATH_RMSD ) then
     call colvar_path_rmsd(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_COMBINECV ) then
     call colvar_combinecv(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_SRV ) then
     call colvar_srv(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_TAE ) then
     call colvar_tae(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_TICA ) then
     call colvar_tica(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_SINDIHEDRAL ) then
     call colvar_sindihedral(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else if ( fsacvs(icv)%type == CV_COSDIHEDRAL ) then
     call colvar_cosdihedral(icv, tpcoor, tpvalue, tpgrad, tpfactor)
  else
     call errormsg("wrong fsacolvar type ! ", int1=fsacvs(icv)%type)
  end if
end subroutine

subroutine colvar_cosdihedral(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: i,j,k,l
  real*8 :: tpphi,tpcoeff

  call colvar_dihedral(1, tpcoor, tpphi, tpatoms=fsacvs(icv)%i(1:4))
  tpvalue = cos(tpphi)

  if ( .not. present(tpgrad) ) return
  
  tpcoeff = -sin(tpphi); if ( present(tpfactor) ) tpcoeff = tpcoeff*tpfactor
  call colvar_dihedral(1, tpcoor, tpphi, tpgrad = tpgrad, tpfactor = tpcoeff, tpatoms=fsacvs(icv)%i(1:4))
end subroutine

subroutine colvar_sindihedral(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: i,j,k,l
  real*8 :: tpphi,tpcoeff

  call colvar_dihedral(1, tpcoor, tpphi, tpatoms=fsacvs(icv)%i(1:4))
  tpvalue = sin(tpphi)

  if ( .not. present(tpgrad) ) return

  tpcoeff = cos(tpphi); if ( present(tpfactor) ) tpcoeff = tpcoeff*tpfactor
  call colvar_dihedral(1, tpcoor, tpphi, tpgrad = tpgrad, tpfactor = tpcoeff, tpatoms=fsacvs(icv)%i(1:4))
end subroutine

subroutine colvar_tica(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer,save :: ivalueadd,igradadd,prereccvidata,ioeigenerr
  real*8,save,allocatable,dimension(:) :: eigenbuffer,eigenval
  real*8,save,dimension(:),pointer :: datamean
  real*8,save,dimension(:,:),pointer :: eigenvec
  real*8,save,dimension(:,:),allocatable :: preeigenvec
  integer :: i,iofile,ierr
  real*8 :: temp,cvin(fsacvs(icv)%i2(2)-fsacvs(icv)%i2(1)+1)

  if ( fsacvs(icv)%ni3 == 0 ) then

     if ( fsacvs(icv)%nr == 0 ) call errormsg("There is no reference eigen info!")
     if ( .not. allocated(eigenbuffer) ) then
        igradadd = 0; ivalueadd = 0
        allocate(eigenbuffer(fsacvs(icv)%ni)); eigenbuffer = 0d0
        allocate(eigenval(fsacvs(icv)%ni)); eigenval = 0d0
        call MPISharedMemoryAllocate(i, dimreal2d=(/reccvend-reccvstart+1,fsacvs(icv)%ni/), sharereal2d=eigenvec)
        call MPISharedMemoryAllocate(i, dimreal1d=(/reccvend-reccvstart+1/), sharereal1d=datamean)
        if ( procid == 0 ) then
           do i = 1, fsacvs(icv)%ni
              eigenvec(:,i) = fsacvs(icv+i-1)%r(1:fsacvs(icv+i-1)%nr)
           end do
           datamean(:) = fsacvs(icv)%r2(1:fsacvs(icv)%nr2)
        end if
        call mpi_barrier(mpi_comm_world,ierr)
     end if

  else

     if ( .not. allocated(eigenbuffer) ) then
        if ( reccvidata == 0 .and. prereccvidata > 0 ) then
           igradadd = 0; ivalueadd = 0
           allocate(eigenbuffer(fsacvs(icv)%ni)); eigenbuffer = 0d0
           allocate(eigenval(fsacvs(icv)%ni)); eigenval = 0d0
           call MPISharedMemoryAllocate(i, dimreal2d=(/reccvend-reccvstart+1,fsacvs(icv)%ni/), sharereal2d=eigenvec)
           call MPISharedMemoryAllocate(i, dimreal1d=(/reccvend-reccvstart+1/), sharereal1d=datamean)
           if ( procid == procnum - 1 ) then
              eigenvec = 0d0; datamean = 0d0
           end if
           call mpi_barrier(mpi_comm_world,ierr)
        else
           tpvalue = 0d0; prereccvidata = reccvidata; return
        end if
     end if
   
     if ( reccvidata == 0 .and. prereccvidata > 0 ) then
        if ( procid == 0 ) then
           call tica_accumulate_data(rectrajcoor, reccvndata, reccvend-reccvstart+1, reccvlagstep, &
                rectrajindex, selecteigens=fsacvs(icv)%i(1:fsacvs(icv)%ni), eigenval=eigenval,     &
                eigenvec=eigenvec, datamean=datamean)
           if ( .not. allocated(preeigenvec) ) then
              allocate(preeigenvec(reccvend-reccvstart+1,fsacvs(icv)%ni))
           else
              do i = 1, fsacvs(icv)%ni
                 temp = dot_product(eigenvec(:,i),preeigenvec(:,i))
                 if ( temp < 0d0 ) eigenvec(:,i) = -eigenvec(:,i)
              end do
           end if
           preeigenvec = eigenvec
           open(newunit=iofile, file="tica_eigeninfo.txt", action="write")
           write(iofile,"(a)")  "Selected Eigens"
           write(iofile,"(15x,50i10)") fsacvs(icv)%i(1:fsacvs(icv)%ni)
           write(iofile, "(a)") "Eigenvalues"
           write(iofile, "(15x,50f10.3)") eigenval(1:fsacvs(icv)%ni)
           write(iofile, "(a)") "CV index, Data average and Eigenvectors"
           do i = 1, fsacvs(icv)%i2(2) - fsacvs(icv)%i2(1) + 1
              write(iofile, "(i5,50f10.3)") i+fsacvs(icv)%i2(1)-1,datamean(i),eigenvec(i,1:fsacvs(icv)%ni)
           end do
           close(iofile)
   
           if ( fsacvs(icv)%nr > 0 ) then
              if ( ioeigenerr == 0 ) then
                 call getfreeunit(ioeigenerr); open(unit=ioeigenerr,file="tica_eigenerr.txt")
              end if
              do i = 1, fsacvs(icv)%ni
                 eigenval(i) = dot_product(eigenvec(:,i),fsacvs(icv+i-1)%r(1:fsacvs(icv+i-1)%nr))
                 temp = sqrt(dot_product(eigenvec(:,i),eigenvec(:,i)))*    &
                        sqrt(dot_product(fsacvs(icv+i-1)%r(1:fsacvs(icv+i-1)%nr),fsacvs(icv+i-1)%r(1:fsacvs(icv+i-1)%nr)))
                 eigenval(i) = acos(eigenval(i)/temp)
              end do
              write(ioeigenerr,"(f12.3,100f10.3)") dble(nowstep)*deltatime*0.001d0,eigenval(1:fsacvs(icv)%ni)
              flush(ioeigenerr)
           end if
        end if
        call mpi_barrier(mpi_comm_world,ierr)
     end if
     prereccvidata = reccvidata

  end if

  if ( present(tpgrad) ) then

     if ( .not. present(tpfactor) ) call errormsg("input parameter tpfactor does not exist in colvar_ticda!")
     igradadd = igradadd + 1; if ( igradadd > fsacvs(icv)%ni ) igradadd = 1
     if ( igradadd==1 ) eigenbuffer = 0d0
     eigenbuffer(igradadd) = tpfactor

     if ( igradadd == fsacvs(icv)%ni ) then
        do i = 1, fsacvs(icv)%i2(2) - fsacvs(icv)%i2(1) + 1
           cvin(i) = dot_product(eigenvec(i,:),eigenbuffer(:))
           call colvar_fsainfo(i+fsacvs(icv)%i2(1)-1, tpcoor, temp, tpgrad=tpgrad, tpfactor=cvin(i))
        end do
     end if

  else

     ivalueadd = ivalueadd + 1; if ( ivalueadd > fsacvs(icv)%ni ) ivalueadd = 1

     if ( ivalueadd == 1 ) then
        do i = 1, fsacvs(icv)%i2(2) - fsacvs(icv)%i2(1) + 1
           call colvar_fsainfo(i+fsacvs(icv)%i2(1)-1, tpcoor, cvin(i))
           cvin(i) = cvin(i) - datamean(i)
        end do
        do i = 1, fsacvs(icv)%ni
           eigenbuffer(i) = dot_product(eigenvec(:,i),cvin(:))
        end do
     end if
     tpvalue = eigenbuffer(ivalueadd)

  end if

end subroutine

subroutine colvar_srv(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use srv, only : srv_flooding_backward, srv_flooding_forward, gmean, gbasis
  use deep, only : noutput
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer,save :: ivalueadd,igradadd
  real*8,save,allocatable,dimension(:) :: srvbuffer
  integer :: i,iatom,jatom,srvindex
  real*8 :: temp,srvin(fsacvs(icv)%i2(2)-fsacvs(icv)%i2(1)+1)

  if ( .not. allocated(srvbuffer) ) then
     igradadd = 0; ivalueadd = 0
     allocate(srvbuffer(noutput)); srvbuffer = 0d0
  end if

  if ( gbasis(1,1) == 0d0 .and. gmean(1) == 0d0 ) then
     tpvalue = 0d0; return
  end if

  if ( present(tpgrad) ) then

     if ( .not. present(tpfactor) ) call errormsg("input parameter tpfactor does not exist in colvar_srv!")
     igradadd = igradadd + 1; if ( igradadd > fsacvs(icv)%ni ) igradadd = 1
     if ( igradadd==1 ) srvbuffer = 0d0

     srvindex = fsacvs(icv)%i(igradadd)
     srvbuffer(srvindex) = tpfactor

     if ( igradadd == fsacvs(icv)%ni ) then
        call srv_flooding_backward(1,srvbuffer,srvin)
        do i = fsacvs(icv)%i2(1), fsacvs(icv)%i2(2)
           call colvar_fsainfo(i, tpcoor, temp, tpgrad=tpgrad, tpfactor=srvin(i-fsacvs(icv)%i2(1)+1))
        end do
     end if

     ! if (nowstep==1) call srv_check_flood()

  else

     ivalueadd = ivalueadd + 1; if ( ivalueadd > fsacvs(icv)%ni ) ivalueadd = 1

     if ( ivalueadd == 1 ) then
        do i = fsacvs(icv)%i2(1), fsacvs(icv)%i2(2)
           call colvar_fsainfo(i, tpcoor, srvin(i-fsacvs(icv)%i2(1)+1))
        end do
        call srv_flooding_forward(srvin,srvbuffer)
     end if
     srvindex = fsacvs(icv)%i(ivalueadd)
     tpvalue = srvbuffer(srvindex)

  end if
end subroutine

subroutine colvar_tae(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use tae
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer,save :: ivalueadd,igradadd
  real*8,save,allocatable,dimension(:) :: taebuffer
  integer :: i,iatom,jatom,taeindex,taeninput,taenoutput
  real*8 :: temp,taein(fsacvs(icv)%i2(2)-fsacvs(icv)%i2(1)+1)

  if ( .not. allocated(taebuffer) ) then
     ivalueadd = 0; igradadd = 0
     call tae_flooding_initialize(fsacvs(icv)%cv_s,taeninput,taenoutput)

     allocate(taebuffer(taenoutput)); taebuffer = 0d0
     if ( fsacvs(icv)%ni > taenoutput ) call errormsg("TAE mode index exceeds the maximum!",int1=fsacvs(icv)%ni,int2=taenoutput)
     if ( (fsacvs(icv)%i2(2)-fsacvs(icv)%i2(1)+1) /= taeninput ) call errormsg("TAE input number is not correct!",int1=fsacvs(icv)%i2(1),int2=fsacvs(icv)%i2(2),int3=taeninput)

  end if

  if ( present(tpgrad) ) then
     if ( .not. present(tpfactor) ) call errormsg("input parameter tpfactor does not exist in colvar_tae!")
     igradadd = igradadd + 1; if ( igradadd > fsacvs(icv)%ni ) igradadd = 1
     if ( igradadd==1 ) taebuffer = 0d0

     taeindex = fsacvs(icv)%i(igradadd)
     taebuffer(taeindex) = tpfactor

     if ( igradadd == fsacvs(icv)%ni ) then
        call tae_flooding_backward(taebuffer,taein)
        do i = fsacvs(icv)%i2(1), fsacvs(icv)%i2(2)
           call colvar_fsainfo(i, tpcoor, temp, tpgrad=tpgrad, tpfactor=taein(i-fsacvs(icv)%i2(1)+1))
        end do
     end if

  else

     ivalueadd = ivalueadd + 1; if ( ivalueadd > fsacvs(icv)%ni ) ivalueadd = 1
     if ( ivalueadd == 1 ) then
        do i = fsacvs(icv)%i2(1), fsacvs(icv)%i2(2)
           call colvar_fsainfo(i, tpcoor, taein(i-fsacvs(icv)%i2(1)+1))
        end do
        call tae_flooding_forward(taein,taebuffer)
     end if
     taeindex = fsacvs(icv)%i(ivalueadd)
     tpvalue = taebuffer(taeindex)

  end if

end subroutine

subroutine colvar_combinecv(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpicv,i
  real*8 :: tpweight,tpcvvalue,tpbias

  tpvalue=0.0d0
  do i = 1, fsacvs(icv)%ni
     tpicv = fsacvs(icv)%i(i)
     tpweight = fsacvs(icv)%r(i)
     tpbias = fsacvs(icv)%r2(i)
     if ( present(tpfactor) ) tpweight = tpweight*tpfactor
     call colvar_fsainfo(tpicv, tpcoor, tpcvvalue, tpgrad=tpgrad, tpfactor=tpweight)
     tpvalue = tpvalue + tpweight*(tpcvvalue - tpbias)
  end do
end subroutine

subroutine colvar_path_rmsd(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  real*8, dimension(fsacvs(icv)%ni*3) :: coor1, coor2, coor0, grad
  integer :: i, j, iatom
  real*8 :: rmsd1, rmsd2, denominator, numerator, denominator2, expRmsd
  real*8 :: lambda, temp, p_f_d1, p_f_d2, tpcoeff

  lambda = 1d0
  coor1 = fsacvs(icv)%r(1:fsacvs(icv)%nr)
  coor2 = fsacvs(icv)%r2(1:fsacvs(icv)%nr)

  coor0 = 0d0
  do i = 1, fsacvs(icv) % ni
    iatom = fsacvs(icv) % i(i)
    coor0(3*i-2 : 3*i) = tpcoor(1:3, iatom)
  enddo

  tpvalue = 0d0;

  call pubmod_lRMSD(fsacvs(icv) % nr, coor0, coor1, rmsd1)
  call pubmod_lRMSD(fsacvs(icv) % nr, coor0, coor2, rmsd2)


  if(rmsd1 > rmsd2) then 
    temp = rmsd1 - rmsd2
    expRmsd = exp(-lambda * temp)
    numerator = 2 + expRmsd
    denominator = 1 + expRmsd
  else 
    temp = rmsd2 - rmsd1
    expRmsd = exp(-lambda * temp)
    numerator = 1 + 2 * expRmsd
    denominator = 1 + expRmsd
  endif
  tpvalue = numerator / denominator

  if ( .not. present(tpgrad)) return
  tpcoeff = 1.0
  if (present(tpfactor)) tpcoeff = tpcoeff * tpfactor
  denominator2 = denominator * denominator

  if(rmsd1 > rmsd2) then
   p_f_d1 = - expRmsd * lambda * denominator + expRmsd * lambda * numerator
   p_f_d1 = p_f_d1 / denominator2

   p_f_d2 = expRmsd * lambda * denominator - expRmsd * lambda * numerator
   p_f_d2 = p_f_d2 / denominator2
  else 
   p_f_d1 = 2 * expRmsd * lambda * denominator - expRmsd * lambda * numerator
   p_f_d1 = p_f_d1 / denominator2

   p_f_d2 = - 2 * expRmsd * lambda * denominator + expRmsd * lambda * numerator
   p_f_d2 = p_f_d2 / denominator2
  endif

  call pubmod_lRMSD(fsacvs(icv)%nr, coor0, coor1, temp, tpgrad=grad)
  do i = 1, fsacvs(icv) % ni
      iatom = fsacvs(icv) % i(i)
      tpgrad(1:3, iatom) = tpgrad(1:3, iatom) + p_f_d1 * grad(3*i-2 : 3*i)
  enddo

  call pubmod_lRMSD(fsacvs(icv)%nr, coor0, coor2, temp, tpgrad=grad)
  do i = 1, fsacvs(icv) % ni
      iatom = fsacvs(icv) % i(i)
      tpgrad(1:3, iatom) = tpgrad(1:3, iatom) + p_f_d2 * grad(3*i-2 : 3*i)
  enddo
end subroutine

subroutine colvar_angle_between_helix(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  real*8 :: tpcoeff, cosTheta, dotVec1Vec2
  real*8 :: vec(2,3),vecTemp(3), vecSquare(2), vecNorm(2)
  real*8 :: p_f_cosTheta, p_f_vec1(3), p_f_vec2(3), p_f_idx1(3), p_f_idx2(3)
  integer ::  groupIdx, groupIdxStart, groupIdxEnd, i, atomIdx1, atomIdx2, residueCount(2)

  tpvalue = 0d0; tpcoeff=1.0; residueCount=0

  if(fsacvs(icv)%ngroup/=2) call errormsg("angle_between_helix ", int1=fsacvs(icv)%ngroup)
  do groupIdx = 1, fsacvs(icv)%ngroup
    groupIdxStart = fsacvs(icv)%groups(1, groupIdx) 
    groupIdxEnd = fsacvs(icv)%groups(2, groupIdx)
    vecTemp = 0d0
    do i = groupIdxStart, groupIdxEnd, 2
        atomIdx1 = fsacvs(icv)%i(i)
        atomIdx2 = fsacvs(icv)%i(i+1)
        vecTemp(:) = vecTemp(:) + tpcoor(:, atomIdx1) - tpcoor(:, atomIdx2)
        residueCount(groupIdx) = residueCount(groupIdx) + 1
    enddo
    vec(groupIdx, :) = vecTemp / residueCount(groupIdx)
    vecSquare(groupIdx) = dot_product(vec(groupIdx,:), vec(groupIdx, :))
    vecNorm(groupIdx) = sqrt(vecSquare(groupIdx))
  enddo

  dotVec1Vec2 = dot_product(vec(1,:), vec(2, :))
  cosTheta = dotVec1Vec2 / (vecNorm(1) * vecNorm(2))
  tpvalue = acos(cosTheta)

  if( .not. present(tpgrad)) return
  if(present(tpfactor)) tpcoeff = tpfactor

  p_f_cosTheta = -1 / sqrt( 1 - cosTheta ** 2)
  p_f_vec1 = p_f_cosTheta /(vecNorm(1) * vecNorm(2))*(vec(2,:) - (dotVec1Vec2 * vec(1,:) / vecSquare(1)))
  p_f_vec2 = p_f_cosTheta /(vecNorm(1) * vecNorm(2))*(vec(1,:) - (dotVec1Vec2 * vec(2,:) / vecSquare(2)))

  vecTemp = p_f_vec1
  do groupIdx = 1, 2
    if(groupIdx == 2) vecTemp =  p_f_vec2
    groupIdxStart = fsacvs(icv)%groups(1, groupIdx) 
    groupIdxEnd = fsacvs(icv)%groups(2, groupIdx)
    p_f_idx1 = vecTemp / residueCount(groupIdx)
    p_f_idx2 = -vecTemp / residueCount(groupIdx)
    do i = groupIdxStart, groupIdxEnd, 2
        atomIdx1 = fsacvs(icv)%i(i)
        atomIdx2 = fsacvs(icv)%i(i+1)
        tpgrad(:, atomIdx1) = tpgrad(:, atomIdx1) + tpcoeff*p_f_idx1
        tpgrad(:, atomIdx2) = tpgrad(:, atomIdx2) + tpcoeff*p_f_idx2
       ! TEST
       ! if(nowstep==100) then
       !     write(iosiminfo, *) tpcoor(:, atomIdx1)
       !     write(iosiminfo, *) p_f_idx1
       !     write(iosiminfo, *) tpcoor(:, atomIdx2)
       !     write(iosiminfo, *) p_f_idx2
       ! endif
    enddo
  enddo
  !flush(iosiminfo);if(nowstep==100) stop
end subroutine colvar_angle_between_helix

subroutine colvar_cos_of_dihedral(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  integer :: idx, i, j, k, l, numDihedral
  real*8 :: rijVec3(3), rjkVec3(3), rklVec3(3), n1(3), n2(3), t1Vec3(3), t2Vec3(3)
  real*8 :: p_f_n1(3), p_f_n2(3), p_f_rij(3), p_f_rjk(3), p_f_rkl(3)
  real*8 :: p_f_i(3), p_f_j(3), p_f_k(3), p_f_l(3)
  real*8 :: tpcoeff, n1Square, n2Square, dotN1N2, normN1, normN2, cosDihedral, dihedral
  real*8 :: relativeDihedral, p_f_dihedral, p_f_cosDihedral

  tpvalue = 0d0; tpcoeff = 1.0;
  if (present(tpfactor)) tpcoeff = tpfactor
  numDihedral = fsacvs(icv)%ni / 4  ! normalize the tpvalue (between 0 and 1)

  do idx = 1, fsacvs(icv)%ni, 4
     i = fsacvs(icv)%i(idx); j = fsacvs(icv)%i(idx+1); k = fsacvs(icv)%i(idx+2); l = fsacvs(icv)%i(idx+3)
     rijVec3 = tpcoor(:, j) - tpcoor(:, i)
     rjkVec3 = tpcoor(:, k) - tpcoor(:, j)
     rklVec3 = tpcoor(:, l) - tpcoor(:, k)
     call cross_product(rijVec3, rjkVec3, n1)
     call cross_product(rjkVec3, rklVec3, n2)
     n1Square = dot_product(n1, n1); normN1 = sqrt(n1Square)
     n2Square = dot_product(n2, n2); normN2 = sqrt(n2Square)
     dotN1N2 = dot_product(n1, n2)
     cosDihedral = dotN1N2 / (normN1 * normN2)
     dihedral = acos(cosDihedral)
     relativeDihedral=cos(dihedral-fsacvs(icv)%r(idx/4+1))
     tpvalue = tpvalue + (relativeDihedral + 1) / (2 * numDihedral)

    if ( present(tpgrad) ) then

        !calculate p_f_dihedral
        p_f_dihedral = -sin(dihedral - fsacvs(icv)%r(idx/4+1)) / (2 * numDihedral)

        !calculate p_f_cosDihedral
        p_f_cosDihedral = -p_f_dihedral / sqrt( 1 - cosDihedral ** 2)

        ! calculate p_f_n1 (partial_f_n1) , p_f_n2, where n1 is the norm vector
        p_f_n1 = p_f_cosDihedral/(normN1 * normN2)*(n2(:) - (dotN1N2 * n1(:) / n1Square))
        p_f_n2 = p_f_cosDihedral/(normN1 * normN2)*(n1(:) - (dotN1N2 * n2(:) / n2Square))

        ! calculate p_f_r (partial_f_r), where r is the difference betwen the vector
        call cross_product(rjkVec3, p_f_n1, p_f_rij)
        call cross_product(p_f_n1, rijVec3, t1Vec3)
        call cross_product(rklVec3, p_f_n2, t2Vec3)
        p_f_rjk = t1Vec3 + t2Vec3
        call cross_product(p_f_n2, rjkVec3, p_f_rkl)

        ! calcualte p_f_i, p_f_j, p_f_k, p_f_l, where i,j,k,l represent the atom index
        p_f_i = - p_f_rij
        p_f_j = (p_f_rij - p_f_rjk)
        p_f_k = (p_f_rjk - p_f_rkl)
        p_f_l = p_f_rkl

        tpgrad(:, i) = tpgrad(:, i) + tpcoeff * p_f_i 
        tpgrad(:, j) = tpgrad(:, j) + tpcoeff * p_f_j 
        tpgrad(:, k) = tpgrad(:, k) + tpcoeff * p_f_k
        tpgrad(:, l) = tpgrad(:, l) + tpcoeff * p_f_l

    endif
  enddo
end subroutine
 
subroutine colvar_com_dis_res(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  integer :: i,igroup,iatom,iaxis,j,k,ires,jres
  real*8 :: tppos1(3),tppos2(3),tpvec(3),tpcoeff
  real*8 :: groupmass(fsacvs(icv)%ngroup),groupvec(3,fsacvs(icv)%ngroup)

  if ( mod(fsacvs(icv)%ngroup,2) /= 0 ) call errormsg("com_dis error ",int1=fsacvs(icv)%ngroup)
  groupvec=0d0; groupmass=0d0; tpvalue=0d0
  do igroup=1,fsacvs(icv)%ngroup
     i=fsacvs(icv)%groups(1,igroup); j=fsacvs(icv)%groups(2,igroup)
     call ambertop_get_com(tpcoor,groupvec(1:3,igroup),tpres=fsacvs(icv)%i(i:j),ifheavysc=.true.,tpmass=groupmass(igroup))
     if ( mod(igroup,2) == 1 ) cycle
     tpvec(1:3) = groupvec(1:3,igroup-1) - groupvec(1:3,igroup)
     do iaxis=1,3
        if ( (fsacvs(icv)%nr > 0) .and. (fsacvs(icv)%r(iaxis) <= 0d0) ) cycle
        tpvalue = tpvalue + tpvec(iaxis)**2
     end do
     tpvalue = sqrt(tpvalue)
     groupvec(1:3,igroup-1) = tpvec(1:3)/tpvalue; groupvec(1:3,igroup) = tpvec(1:3)/tpvalue
  end do

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor
  do igroup=1,fsacvs(icv)%ngroup
     tpvec(1:3) = tpcoeff*groupvec(1:3,igroup)
     i=fsacvs(icv)%groups(1,igroup); j=fsacvs(icv)%groups(2,igroup)
     do ires=fsacvs(icv)%i(i),fsacvs(icv)%i(j)
        do k=heavyscindex(ires)+1,heavyscindex(ires+1)
           iatom = heavyscatoms(k)
           do iaxis=1,3
              if ( (fsacvs(icv)%nr > 0) .and. (fsacvs(icv)%r(iaxis) <= 0d0) ) cycle
              if ( mod(igroup,2) == 1 ) then
                 tpgrad(iaxis,iatom) = tpgrad(iaxis,iatom) + tpvec(iaxis)*mass(iatom)/groupmass(igroup)
              else if ( mod(igroup,2) == 0 ) then
                 tpgrad(iaxis,iatom) = tpgrad(iaxis,iatom) - tpvec(iaxis)*mass(iatom)/groupmass(igroup)
              end if
           end do
        end do
     end do
  end do
end subroutine

subroutine colvar_disavg_endend(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,i
  real*8 :: tpdis,tpdis1,tpdis2,tpdis12,tpvec(3),tpcoeff,temp

  tpvalue = 0d0; tpdis1=0d0; tpdis2=0d0
  do i=1,fsacvs(icv)%ni,2
     iatom = fsacvs(icv)%i(i); jatom = fsacvs(icv)%i(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis1 = tpdis1 + sqrt(dot_product(tpvec,tpvec))
  end do
  tpdis1 = tpdis1/dble(fsacvs(icv)%ni/2)
  do i=1,fsacvs(icv)%ni2,2
     iatom = fsacvs(icv)%i2(i); jatom = fsacvs(icv)%i2(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis2 = tpdis2 + sqrt(dot_product(tpvec,tpvec))
  end do
  tpdis2 = tpdis2/dble(fsacvs(icv)%ni2/2)
  tpdis12 = tpdis1 + tpdis2; tpvalue = tpdis1/tpdis12

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0; if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  temp = (tpcoeff*(tpdis12 - tpdis1)/(tpdis12**2))/dble(fsacvs(icv)%ni/2)
  do i=1,fsacvs(icv)%ni,2
     iatom = fsacvs(icv)%i(i); jatom = fsacvs(icv)%i(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tpvec(1:3)/tpdis
     tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - temp*tpvec(1:3)/tpdis
  end do
  temp = (tpcoeff*(-tpdis1)/(tpdis12**2))/dble(fsacvs(icv)%ni2/2)
  do i=1,fsacvs(icv)%ni2,2
     iatom = fsacvs(icv)%i2(i); jatom = fsacvs(icv)%i2(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tpvec(1:3)/tpdis
     tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - temp*tpvec(1:3)/tpdis
  end do
end subroutine

subroutine colvar_disavg_end4(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,i
  real*8 :: tpdis,tpdis1,tpdis2,tpdis3,tpdis4,tpdis12,tpdis34,tpvec(3),tpcoeff,temp,tpfraction1,tpfraction2

  tpvalue = 0d0; tpdis1=0d0; tpdis2=0d0
  do i=1,fsacvs(icv)%ni,2
     iatom = fsacvs(icv)%i(i); jatom = fsacvs(icv)%i(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis1 = tpdis1 + sqrt(dot_product(tpvec,tpvec))
  end do
  tpdis1 = tpdis1/dble(fsacvs(icv)%ni/2)
  do i=1,fsacvs(icv)%ni2,2
     iatom = fsacvs(icv)%i2(i); jatom = fsacvs(icv)%i2(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis2 = tpdis2 + sqrt(dot_product(tpvec,tpvec))
  end do
  tpdis2 = tpdis2/dble(fsacvs(icv)%ni2/2)
  tpdis12 = tpdis1 + tpdis2; tpfraction1 = tpdis1/tpdis12

  tpdis3=0d0; tpdis4=0d0
  do i=1,fsacvs(icv)%ni3,2
     iatom = fsacvs(icv)%i3(i); jatom = fsacvs(icv)%i3(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis3 = tpdis3 + sqrt(dot_product(tpvec,tpvec))
  end do
  tpdis3 = tpdis3/dble(fsacvs(icv)%ni3/2)
  do i=1,fsacvs(icv)%ni4,2
     iatom = fsacvs(icv)%i4(i); jatom = fsacvs(icv)%i4(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis4 = tpdis4 + sqrt(dot_product(tpvec,tpvec))
  end do
  tpdis4 = tpdis4/dble(fsacvs(icv)%ni4/2)
  tpdis34 = tpdis3 + tpdis4; tpfraction2 = tpdis3/tpdis34
  tpvalue = sqrt((tpfraction1 - fsacvs(icv)%r(1))**2 + (tpfraction2 - fsacvs(icv)%r(2))**2)

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0; if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  tpfraction1 = (tpfraction1 - fsacvs(icv)%r(1))/tpvalue
  tpfraction2 = (tpfraction2 - fsacvs(icv)%r(2))/tpvalue
  temp = tpfraction1*(tpcoeff*(tpdis12 - tpdis1)/(tpdis12**2))/dble(fsacvs(icv)%ni/2)
  do i=1,fsacvs(icv)%ni,2
     iatom = fsacvs(icv)%i(i); jatom = fsacvs(icv)%i(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tpvec(1:3)/tpdis
     tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - temp*tpvec(1:3)/tpdis
  end do
  temp = tpfraction1*(tpcoeff*(-tpdis1)/(tpdis12**2))/dble(fsacvs(icv)%ni2/2)
  do i=1,fsacvs(icv)%ni2,2
     iatom = fsacvs(icv)%i2(i); jatom = fsacvs(icv)%i2(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tpvec(1:3)/tpdis
     tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - temp*tpvec(1:3)/tpdis
  end do

  temp = tpfraction2*(tpcoeff*(tpdis34 - tpdis3)/(tpdis34**2))/dble(fsacvs(icv)%ni3/2)
  do i=1,fsacvs(icv)%ni3,2
     iatom = fsacvs(icv)%i3(i); jatom = fsacvs(icv)%i3(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tpvec(1:3)/tpdis
     tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - temp*tpvec(1:3)/tpdis
  end do
  temp = tpfraction2*(tpcoeff*(-tpdis3)/(tpdis34**2))/dble(fsacvs(icv)%ni4/2)
  do i=1,fsacvs(icv)%ni4,2
     iatom = fsacvs(icv)%i4(i); jatom = fsacvs(icv)%i4(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tpvec(1:3)/tpdis
     tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - temp*tpvec(1:3)/tpdis
  end do
end subroutine

subroutine colvar_rmsd_endend(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: i, iatom, igroup
  real*8 :: temp,tpdis1,tpdis2,tpdis12, tpcoeff, temp2
  real*8 :: tptpgrad(3, natom), tptpgrad2(3, natom)

  call colvar_rmsd(icv, tpcoor, tpdis1, tptpgrad, endend=1)
  call colvar_rmsd(icv, tpcoor, tpdis2, tptpgrad2, endend=2)

  tpdis12 = tpdis1 + tpdis2
  tpvalue = tpdis1/tpdis12

  if(.not. present(tpgrad)) return
  tpcoeff=1.0 
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor

  temp = tpcoeff*(tpdis12 - tpdis1)/(tpdis12**2)
  temp2 = tpcoeff*(-tpdis1)/(tpdis12**2)
  do igroup=1,fsacvs(icv)%ngroup
    do i=fsacvs(icv)%groups(1,igroup),fsacvs(icv)%groups(2,igroup)
      iatom = fsacvs(icv)%i(i)
      tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tptpgrad(1:3, iatom)
      tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp2*tptpgrad2(1:3, iatom)
    end do
  enddo
end subroutine

subroutine colvar_drmsd_endend(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: i,j,iatom
  real*8 :: temp,tpdis1,tpdis2,tpdis12,tpvec(3),tpcoeff,tprmsd
  real*8 :: tptpgrad(3, natom)

  call colvar_drmsd(icv, tpcoor, tpdis1, endend=1)
  call colvar_drmsd(icv, tpcoor, tpdis2, endend=2)
  tpdis12=tpdis1+tpdis2
  tpvalue=tpdis1/tpdis12

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor

  temp = tpcoeff*tpdis2/(tpdis12**2)
  call colvar_drmsd(icv, tpcoor, tprmsd, tpgrad=tptpgrad, endend=1)
  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i)
     tpgrad(1:3,iatom)=tpgrad(1:3,iatom) + temp*tptpgrad(1:3, iatom)
  end do

  temp = tpcoeff*(-tpdis1)/(tpdis12**2)
  call colvar_drmsd(icv, tpcoor, tprmsd, tpgrad=tptpgrad, endend=2)
  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i)
     tpgrad(1:3,iatom)=tpgrad(1:3,iatom) + temp*tptpgrad(1:3, iatom)
  end do
end subroutine

subroutine colvar_dihedral_endend(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,tpatoms(4),i,j
  real*8 :: temp,tpdis1,tpdis2,tpdis12,tpvec(3),tpcoeff,tpangle,tpdelta,tpdeltavec1(fsacvs(icv)%nr),tpdeltavec2(fsacvs(icv)%nr)

  tpvalue = 0d0; tpdis1=0d0; tpdis2=0d0; tpdeltavec1=0d0; tpdeltavec2=0d0
  do i=1,fsacvs(icv)%nr
     tpatoms(1:4) = fsacvs(icv)%i(1+4*(i-1):4*i)
     call colvar_dihedral(1, tpcoor, tpangle, tpatoms=tpatoms)
     tpdelta = tpangle - fsacvs(icv)%r(i)
     if ( tpdelta > pi ) tpdelta = tpdelta - 2d0*pi
     if ( tpdelta < -pi ) tpdelta = tpdelta + 2d0*pi
     tpdeltavec1(i) = tpdelta; tpdis1 = tpdis1 + tpdelta**2

     tpdelta = tpangle - fsacvs(icv)%r2(i)
     if ( tpdelta > pi ) tpdelta = tpdelta - 2d0*pi
     if ( tpdelta < -pi ) tpdelta = tpdelta + 2d0*pi
     tpdeltavec2(i) = tpdelta; tpdis2 = tpdis2 + tpdelta**2
  end do
  tpdis1 = sqrt(tpdis1); tpdis2 = sqrt(tpdis2); tpdis12 = tpdis1 + tpdis2
  tpvalue = tpdis1/tpdis12

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0; if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor

  do i=1,fsacvs(icv)%nr
     tpatoms(1:4) = fsacvs(icv)%i(1+4*(i-1):4*i)
     temp = tpcoeff*(tpdis12-tpdis1)*tpdeltavec1(i)/(tpdis1*(tpdis12**2))
     call colvar_dihedral(1, nowcoor, tpangle, tpatoms=tpatoms, tpgrad=tpgrad, tpfactor=temp)

     temp = tpcoeff*(-tpdis1)*tpdeltavec2(i)/(tpdis2*(tpdis12**2))
     call colvar_dihedral(1, nowcoor, tpangle, tpatoms=tpatoms, tpgrad=tpgrad, tpfactor=temp)
  end do
end subroutine

subroutine colvar_gyrationres(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: i,j,k,iatom,tpnum,ires
  real*8 :: tpcoeff,tpvec(3),tpcomvec(3),tpmass

  tpvalue = 0d0; tpmass = 0d0; tpnum = 0
  call ambertop_get_com(tpcoor,tpcomvec(1:3),tpres=fsacvs(icv)%i(1:fsacvs(icv)%ni),ifheavysc=.true.,tpmass=tpmass)
  do i=1,fsacvs(icv)%ni
     ires = fsacvs(icv)%i(i); tpnum = tpnum + heavyscindex(ires+1) - heavyscindex(ires)
     do k=heavyscindex(ires)+1, heavyscindex(ires+1)
        iatom = heavyscatoms(k)
        tpvec(1:3) = tpcoor(1:3,iatom) - tpcomvec(1:3)
        tpvalue = tpvalue + dot_product(tpvec,tpvec)
     end do
  end do
  tpvalue = sqrt(tpvalue/dble(tpnum))

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  tpcoeff = tpcoeff/(dble(tpnum)*tpvalue)
  do i=1,fsacvs(icv)%ni
     ires = fsacvs(icv)%i(i)
     do k=heavyscindex(ires)+1, heavyscindex(ires+1)
        iatom = heavyscatoms(k)
        tpvec(1:3) = tpcoeff*(tpcoor(1:3,iatom) - tpcomvec(1:3))
        tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec(1:3)*(1d0 - mass(iatom)/tpmass)
     end do
  end do
end subroutine

subroutine colvar_gyrationresavg(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: igroup,i,k,ires,iatom,ilow,iup,tpnum,tpgynumvec(fsacvs(icv)%ngroup)
  real*8 :: tpcoeff,tpvec(3),tpcomvec(3,fsacvs(icv)%ngroup),tpmassvec(fsacvs(icv)%ngroup),tpsum,tpgyvec(fsacvs(icv)%ngroup)

  tpvalue = 0d0
  do igroup=1,fsacvs(icv)%ngroup
     ilow = fsacvs(icv)%groups(1,igroup); iup = fsacvs(icv)%groups(2,igroup)
     call ambertop_get_com(tpcoor,tpcomvec(1:3,igroup),tpres=fsacvs(icv)%i(ilow:iup),ifheavysc=.true.,tpmass=tpmassvec(igroup))
     tpsum = 0d0; tpnum = 0
     do i=ilow, iup
        ires = fsacvs(icv)%i(i); tpnum = tpnum + heavyscindex(ires+1) - heavyscindex(ires)
        do k=heavyscindex(ires)+1, heavyscindex(ires+1)
           iatom = heavyscatoms(k)
           tpvec(1:3) = tpcoor(1:3,iatom) - tpcomvec(1:3,igroup)
           tpsum = tpsum + dot_product(tpvec,tpvec)
        end do
     end do
     tpgynumvec(igroup) = tpnum
     tpsum = sqrt(tpsum/dble(tpgynumvec(igroup)))
     tpgyvec(igroup) = tpsum
     tpvalue = tpvalue + tpsum
  end do

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor

  do igroup=1,fsacvs(icv)%ngroup
     ilow = fsacvs(icv)%groups(1,igroup); iup = fsacvs(icv)%groups(2,igroup)
     tpsum = tpcoeff/(dble(tpgynumvec(igroup))*tpgyvec(igroup))
     do i=ilow, iup
        ires = fsacvs(icv)%i(i)
        do k=heavyscindex(ires)+1, heavyscindex(ires+1)
           iatom = heavyscatoms(k)
           tpvec(1:3) = tpsum*(tpcoor(1:3,iatom) - tpcomvec(1:3,igroup))
           tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec(1:3)*(1d0 - mass(iatom)/tpmassvec(igroup))
        end do
     end do
  end do
end subroutine

subroutine colvar_gyration(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: i,iatom,tpni
  real*8 :: tpcoeff,tpvec(3),tpcomvec(3),tpmass

  tpvalue = 0d0; tpvec=0d0; tpni=fsacvs(icv)%ni; tpmass=0d0
  tpcoeff=1.0; if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  do i=1,tpni
     iatom = fsacvs(icv)%i(i); tpmass = tpmass + mass(iatom)
     tpvec(1:3) = tpvec(1:3) + tpcoor(1:3,iatom)*mass(iatom)
  end do
  tpcomvec(1:3) = tpvec(1:3)/tpmass
  do i=1,tpni
     iatom = fsacvs(icv)%i(i)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcomvec(1:3)
     tpvalue = tpvalue + dot_product(tpvec,tpvec)
  end do
  tpvalue = sqrt(tpvalue/dble(tpni))

  if ( .not. present(tpgrad) ) return

  tpcoeff = tpcoeff/(dble(tpni)*tpvalue)
  do i=1,tpni
     iatom = fsacvs(icv)%i(i)
     tpvec(1:3) = tpcoeff*(tpcoor(1:3,iatom) - tpcomvec(1:3))
     tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec(1:3)*(1d0 - mass(iatom)/tpmass)
  end do
end subroutine

subroutine colvar_nantihb(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,ires,jres,io,jo,ih,jh,i,j,tpi,tpj
  real*8 :: tpdis,tpdis1,tpvec1(3),tpdis2,tpvec2(3),tpcoeff,tpmark,tpratio,tpr6,tpr12,tpr5,tpr11,temp

  tpvalue = 0d0; tpcoeff=1.0; tpmark = fsacvs(icv)%r(1)
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor

  ires=2; jres=nres-1; tpi=0; tpj=0
  if ( (fsacvs(icv)%ni==2) .and. (fsacvs(icv)%i(1)>0) .and. (fsacvs(icv)%i(2)>0) ) then
     ires=fsacvs(icv)%i(1); jres=fsacvs(icv)%i(2)
  end if
  do i=ires,jres
     if ( resname(i) == "PRO " ) cycle
!     if ( reskdscale(i) > 0d0 ) cycle
     if ( (fsacvs(icv)%ni==4) .and. (fsacvs(icv)%i(3)>0) .and. (fsacvs(icv)%i(4)>0) ) then
        tpi=fsacvs(icv)%i(3); tpj=fsacvs(icv)%i(4)
     else
        tpi=i+3; tpj=jres
     end if
     do j=tpi,tpj
        if ( resname(j) == "PRO " ) cycle
!        if ( reskdscale(j) > 0d0 ) cycle

        if ( ( ((reskdscale(i-1)<0d0) .or. (reskdscale(j+1)<0d0)) ) .and.  &
             ( ((reskdscale(i+1)<0d0) .or. (reskdscale(j-1)<0d0)) ) ) cycle 
        ih = resindex(i)+2; io = resindex(i+1); jh = resindex(j)+2; jo = resindex(j+1)
        tpvec1(1:3)=tpcoor(1:3,ih)-tpcoor(1:3,jo); tpdis1 = sqrt(dot_product(tpvec1,tpvec1))
        tpvec2(1:3)=tpcoor(1:3,io)-tpcoor(1:3,jh); tpdis2 = sqrt(dot_product(tpvec2,tpvec2)) 
        tpdis = 0.5d0*(tpdis1+tpdis2); tpratio = tpdis/tpmark
        tpr6 = tpratio**6; tpr12 = tpr6**2; tpr5 = tpr6/tpratio; tpr11 = tpr12/tpratio
        temp = (1d0 - tpr6)/(1d0 - tpr12)
        tpvalue = tpvalue + temp
        if ( present(tpgrad) ) then
           temp = (-6d0*tpr5*(1d0-tpr12) + (1d0-tpr6)*12d0*tpr11)/((1d0-tpr12)**2)
           temp = tpcoeff*(temp/tpmark)*0.5d0
           tpvec1 = temp*tpvec1/tpdis1
           tpgrad(1:3,ih) = tpgrad(1:3,ih) + tpvec1(1:3)
           tpgrad(1:3,jo) = tpgrad(1:3,jo) - tpvec1(1:3)
           tpvec2 = temp*tpvec2/tpdis2
           tpgrad(1:3,io) = tpgrad(1:3,io) + tpvec2(1:3)
           tpgrad(1:3,jh) = tpgrad(1:3,jh) - tpvec2(1:3)
        end if
     end do 
  end do
end subroutine

subroutine colvar_ncontactresvec(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,ires,jres,ilow,iup,istart,iend,i,j,k,tptype
  real*8 :: tpweight,tpdis,tpvec(3),tpcoeff,tpmark,tpratio,tpr6,tpr12,tpr5,tpr11,temp,tpcom1(3),tpcom2(3)
  real*8 :: tpcomvec(3,fsacvs(icv)%ni)
  logical :: ifcycle
  logical,save :: ifnotfirst(10)

  ilow=0; iup=0; istart=1
  if ( fsacvs(icv)%i(1)*fsacvs(icv)%i(2) < 0 ) then
     if ( (fsacvs(icv)%i(1) > 0) .and. (fsacvs(icv)%i(2) < 0) ) then
        ilow=fsacvs(icv)%i(1); iup=-fsacvs(icv)%i(2); istart=3
        if ( (ilow < 1) .or. (iup > (nres-1)) ) call errormsg("wrong contact interval ",int1=ilow,int2=iup)
        if ( (ifnotfirst(icv) .eqv. .false.) .and. (procid==(procnum-1)) ) then
           ifnotfirst(icv)=.true.; tpndim = 0
           write(iosiminfo,*)
           do i=istart,fsacvs(icv)%ni
              ires = fsacvs(icv)%i(i)
              do j=i+1,fsacvs(icv)%ni
                 jres = fsacvs(icv)%i(j)
                 if ( ((jres-ires) < ilow) .or. ((jres-ires) > iup) ) cycle
                 tpndim = tpndim + 1
                 write(iosiminfo,"(a,i3,a,2i6)") "contact ",tpndim,": ",ires,jres
              end do
           end do
           write(iosiminfo,"(a,i3,a,2i5,a,i5)") "colvar_ncontactresvec, icv ", icv,", range ",ilow,iup,", num ",tpndim
           flush(iosiminfo)
        end if
     else
        call errormsg("wrong contact interval ",int1=ilow,int2=iup)
     end if
  end if

  if ( fsacvs(icv)%nr == 0 ) then
     tptype = 0 
  else if ( fsacvs(icv)%nr == 1 ) then
     tptype = 1; tpmark = fsacvs(icv)%r(1)
  else 
     call errormsg("wrong type in NCONTACTRESVEC ",int1=fsacvs(icv)%nr)
  end if
  tpcoeff=1.0; if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  tpvalue=0d0; tpcomvec=0d0; tpweight=1d0
  do i=istart,fsacvs(icv)%ni
     ires = fsacvs(icv)%i(i)
     call ambertop_get_com(tpcoor,tpcomvec(1:3,i),tpatoms=heavyscatoms(heavyscindex(ires)+1:heavyscindex(ires+1)))
  end do

  do i=istart,fsacvs(icv)%ni
     ires = fsacvs(icv)%i(i); tpcom1 = tpcomvec(1:3,i)
     do j=i+1,fsacvs(icv)%ni
        jres = fsacvs(icv)%i(j)
        if ( istart == 3 ) then
           if ( ((jres-ires) < ilow) .or. ((jres-ires) > iup) ) cycle
        end if
        tpcom2 = tpcomvec(1:3,j); tpvec(1:3) = tpcom1(1:3) - tpcom2(1:3)
        if ( tptype == 0 ) tpmark = resrad(ires) + resrad(jres)
!        tpweight = 0.5d0*(abs(reskdscale(ires))+abs(reskdscale(jres)))
        tpdis = sqrt(dot_product(tpvec,tpvec)); tpratio = tpdis/tpmark

        tpr6 = tpratio**6; tpr12 = tpr6**2; tpr5 = tpr6/tpratio; tpr11 = tpr12/tpratio
        temp = (1d0 - tpr6)/(1d0 - tpr12)
        tpvalue = tpvalue + temp*tpweight

        if ( present(tpgrad) ) then
           temp = (-6d0*tpr5*(1d0-tpr12) + (1d0-tpr6)*12d0*tpr11)/((1d0-tpr12)**2)
           tpvec=tpcoeff*tpweight*(temp/tpmark)*tpvec/tpdis
           do k=heavyscindex(ires)+1,heavyscindex(ires+1)
              iatom = heavyscatoms(k)
              tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec(1:3)*mass(iatom)/heavyscmass(ires)
           end do
           do k=heavyscindex(jres)+1,heavyscindex(jres+1)
              jatom = heavyscatoms(k)
              tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - tpvec(1:3)*mass(jatom)/heavyscmass(jres)
           end do
        end if
     end do
  end do
end subroutine

subroutine colvar_ncontactres(icv,tpcoor,tpvalue,tpgrad,tpfactor,tprespairs)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  integer,intent(in),dimension(:),optional :: tprespairs
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,ires,jres,ilow,iup,istart,iend,i,k,ipair
  real*8 :: tpweight,tpdis,tpvec(3),tpcoeff,tpmark,tpratio,tpr6,tpr12,tpr5,tpr11,temp,tpcom1(3),tpcom2(3)
  logical,save :: ifnotfirst(30)
  logical :: ifweight

  ilow=0; iup=0; istart=1; ipair=0
  if ( (.not. present(tprespairs)) .and. (fsacvs(icv)%i(1)*fsacvs(icv)%i(2) < 0) ) then
     if ( (fsacvs(icv)%i(1) > 0) .and. (fsacvs(icv)%i(2) < 0) ) then
        ilow=fsacvs(icv)%i(1); iup=-fsacvs(icv)%i(2); istart=3
        if ( (ilow < 1) .or. (iup > (nres-1)) ) call errormsg("wrong contact interval ",int1=ilow,int2=iup)
        if ( (ifnotfirst(icv) .eqv. .false.) .and. (procid==(procnum-1)) ) then
           ifnotfirst(icv)=.true.; tpndim = 0
           write(iosiminfo,*)
           write(iosiminfo,"(a,i3,a,2i5)") "colvar_ncontactres, icv ", icv,", range ",ilow,iup
           do i=istart,fsacvs(icv)%ni,2
              ires = fsacvs(icv)%i(i); jres = fsacvs(icv)%i(i+1)
              if ( ((jres-ires) < ilow) .or. ((jres-ires) > iup) ) cycle
              tpndim = tpndim + 1
              write(iosiminfo,"(a,i3,a,2i6)") "contact ",tpndim,": ",ires,jres
           end do
           write(iosiminfo,"(a,i3,a,2i5,a,i5)") "colvar_ncontactres, icv ", icv,", range ",ilow,iup,", num ",tpndim
           flush(iosiminfo)
        end if
     else
        call errormsg("wrong contact interval ",int1=ilow,int2=iup)
     end if
  end if
  if ( present(tprespairs) ) then
     iend=size(tprespairs)
  else
     iend=fsacvs(icv)%ni
  end if
  tpvalue = 0d0; tpcoeff=1.0; tpmark = fsacvs(icv)%r(1)
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  tpweight=1d0; ifweight=.false.; if ( fsacvs(icv)%nr > 1 ) ifweight=.true.
  do i=istart,iend,2
     ipair = ipair + 1
     if ( present(tprespairs) ) then
        ires = tprespairs(i); jres = tprespairs(i+1)
     else
        ires = fsacvs(icv)%i(i); jres = fsacvs(icv)%i(i+1)
        if ( istart == 3 ) then
           if ( ((jres-ires) < ilow) .or. ((jres-ires) > iup) ) cycle
        end if
     end if
     if ( (ires < 0) .or. (jres < 0) ) cycle

     call ambertop_get_com(tpcoor,tpcom1,tpatoms=heavyscatoms(heavyscindex(ires)+1:heavyscindex(ires+1)))
     call ambertop_get_com(tpcoor,tpcom2,tpatoms=heavyscatoms(heavyscindex(jres)+1:heavyscindex(jres+1)))

     tpvec(1:3) = tpcom1(1:3) - tpcom2(1:3)
     tpdis = sqrt(dot_product(tpvec,tpvec)); tpratio = tpdis/tpmark
     tpr6 = tpratio**6; tpr12 = tpr6**2; tpr5 = tpr6/tpratio; tpr11 = tpr12/tpratio
     temp = (1d0 - tpr6)/(1d0 - tpr12)
     if ( ifweight .eqv. .true. ) tpweight = fsacvs(icv)%r(ipair + 1)

     tpvalue = tpvalue + temp*tpweight
     if ( present(tpgrad) ) then
        temp = (-6d0*tpr5*(1d0-tpr12) + (1d0-tpr6)*12d0*tpr11)/((1d0-tpr12)**2)
        tpvec=tpcoeff*tpweight*(temp/tpmark)*tpvec/tpdis
        do k=heavyscindex(ires)+1,heavyscindex(ires+1)
           iatom = heavyscatoms(k)
           tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec(1:3)*mass(iatom)/heavyscmass(ires)
        end do
        do k=heavyscindex(jres)+1,heavyscindex(jres+1)
           jatom = heavyscatoms(k)
           tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - tpvec(1:3)*mass(jatom)/heavyscmass(jres)
        end do
     end if
  end do
end subroutine

subroutine colvar_ncontact(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,i
  real*8 :: tpdis,tpvec(3),tpcoeff,tpmark,tpratio,tpr6,tpr12,tpr5,tpr11,temp
  real*8 :: tpr4, tpr2, tpr3

  tpvalue = 0d0; tpcoeff=1.0; tpmark = fsacvs(icv)%r(1)
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  do i=1,fsacvs(icv)%ni,2
     iatom = fsacvs(icv)%i(i); jatom = fsacvs(icv)%i(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     if ( fsacvs(icv)%nr > 1 ) then            ! use the 2-4 form
        if ( tpdis > tpmark ) then
           tpratio = (tpdis - tpmark)/tpmark
        else
           tpratio = 0.0d0
        end if
        tpr2 = tpratio**2; tpr4 = tpratio**4
        temp = (1d0 - tpr2) / (1d0 - tpr4)
     else                                      ! use the 6-12 form
        tpratio = tpdis/tpmark
        tpr6 = tpratio**6; tpr12 = tpr6**2
        temp = (1d0 - tpr6)/(1d0 - tpr12)
     end if
     tpvalue = tpvalue + temp
     if ( present(tpgrad) ) then
        if ( fsacvs(icv)%nr > 1 ) then  
            if(tpdis <= tpmark) then
                temp = 0d0
            else
                tpr3 = tpr4/tpratio;
                temp = (-2d0*tpratio*(1-tpr4) + 4d0*tpr3*(1d0-tpr2))/((1d0-tpr4)**2)
            endif
        else
           tpr5 = tpr6/tpratio; tpr11 = tpr12/tpratio
           temp = (-6d0*tpr5*(1d0-tpr12) + (1d0-tpr6)*12d0*tpr11)/((1d0-tpr12)**2)
        end if
        tpvec=tpcoeff*(temp/tpmark)*tpvec/tpdis
        tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec(1:3)
        tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - tpvec(1:3)
     end if
  end do
end subroutine

subroutine colvar_nresstate(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,ires,iresstart,iresend,tpphiatoms(4),tppsiatoms(4),iofile
  real*8 :: tpphi,tppsi,tpdis,tpcoeff,tpmark,tpratio,tpr6,tpr12,tpr5,tpr11,temp,temp2,tpdis2
  real*8 :: tpphi0,tppsi0,tpdeltaphi, tpdeltapsi,tpaphi0,tpbphi0,tpapsi0,tpbpsi0
  integer,dimension(:),allocatable,save :: resstate
  logical,save :: ifnotfirst
  character*200 :: tpseq

  tpvalue = 0d0; tpcoeff=1.0; tpmark = fsacvs(icv)%r(1)*pi/180d0
  iresstart=2; iresend=nres-1;
  tpaphi0 = -57d0*pi/180d0; tpapsi0 = -47d0*pi/180d0
  tpbphi0 = -80d0*pi/180d0; tpbpsi0 = 150d0*pi/180d0
  if ( (fsacvs(icv)%i(2)>2) .and. (fsacvs(icv)%i(2)<(nres-1)) ) iresstart=fsacvs(icv)%i(2)
  if ( (fsacvs(icv)%i(3)>2) .and. (fsacvs(icv)%i(3)<(nres-1)) ) iresend=fsacvs(icv)%i(3)
  select case (fsacvs(icv)%i(1))
  case (1); tpphi0 = tpaphi0; tppsi0 = tpapsi0
  case (2); tpphi0 = tpbphi0; tppsi0 = tpbpsi0
  case (3)
  if ( ifnotfirst .eqv. .false. ) then
     if (procid==(procnum-1)) then
        write(iosiminfo,*); write(iosiminfo,"(a)") "Initializing secondary structure restraints"
     end if
     ifnotfirst = .true.; allocate(resstate(nres)); resstate=0; tpndim=0

goto 1001
     call getfreeunit(iofile); open(unit=iofile,file="metapsicov.txt",action="read")
     tpndim=0; ires=0; tpseq=""; read(iofile,"(a)") tpseq
     do ires = 1, 200
        if ( tpseq(ires:ires) == "H" ) then
           resstate(ires)=1; tpndim=tpndim+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(2i4,2a6)") tpndim,ires,resname(ires), " alpha"
        else if ( tpseq(ires:ires) == "E" ) then
           resstate(ires)=2; tpndim=tpndim+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(2i4,2a6)") tpndim,ires,resname(ires), " beta"
        end if
     end do
     close(iofile)
1001 continue

     do ires=2,nres-1
        if ( resname(ires) == "PRO " ) cycle
        tpphiatoms(1:4) = (/resindex(ires) - 1, resindex(ires) + 1, resindex(ires) + 3, resindex(ires+1) - 1/)
        tppsiatoms(1:4) = (/resindex(ires) + 1, resindex(ires) + 3, resindex(ires+1) - 1, resindex(ires+1) + 1/)
        call colvar_dihedral(1, refcoor, tpphi, tpatoms=tpphiatoms)
        call colvar_dihedral(1, refcoor, tppsi, tpatoms=tppsiatoms)

        tpdis = sqrt( (tpphi-tpaphi0)**2 + (tppsi-tpapsi0)**2 )
        tpdis2= sqrt( (tpphi-tpbphi0)**2 + (tppsi-tpbpsi0)**2 )
        if ( (tpdis < tpmark) .and. (tpdis2 < tpmark) ) &
              call errormsg("r(1) is too large in cv_nresstate! ",real1=tpmark,real2=tpdis,real3=tpdis2)
        if ( tpdis < tpmark ) then
           resstate(ires)=1; tpndim=tpndim+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(2i4,2a6)") tpndim,ires,resname(ires), " alpha"
        else if ( tpdis2 < tpmark ) then
           resstate(ires)=2; tpndim=tpndim+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(2i4,2a6)") tpndim,ires,resname(ires), "  beta"
        end if
     end do

     flush(iosiminfo)
  end if
  case default; call errormsg("wrong cv_i in CV_NRESSTATE ",int1=fsacvs(icv)%i(1))
  end select 

  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  do ires=iresstart, iresend
     if ( resname(ires) == "PRO " ) cycle

     tpphiatoms(1:4) = (/resindex(ires) - 1, resindex(ires) + 1, resindex(ires) + 3, resindex(ires+1) - 1/)
     tppsiatoms(1:4) = (/resindex(ires) + 1, resindex(ires) + 3, resindex(ires+1) - 1, resindex(ires+1) + 1/)
     call colvar_dihedral(1, tpcoor, tpphi, tpatoms=tpphiatoms)
     call colvar_dihedral(1, tpcoor, tppsi, tpatoms=tppsiatoms)

     select case (fsacvs(icv)%i(1))
     case (1); tpphi0 = tpaphi0; tppsi0 = tpapsi0
     case (2); tpphi0 = tpbphi0; tppsi0 = tpbpsi0
     case (3);
       if ( resstate(ires) == 1 ) then
          tpphi0 = tpaphi0; tppsi0 = tpapsi0
       else if ( resstate(ires) == 2 ) then
          tpphi0 = tpbphi0; tppsi0 = tpbpsi0
       else
          cycle
       end if
     end select

     tpdeltaphi = tpphi - tpphi0
     if ( tpdeltaphi > pi ) then
        tpdeltaphi = tpdeltaphi - 2d0*pi
     else if ( tpdeltaphi < -pi) then
        tpdeltaphi = tpdeltaphi + 2d0*pi
     end if
     tpdeltapsi = tppsi - tppsi0
     if ( tpdeltapsi > pi ) then
        tpdeltapsi = tpdeltapsi - 2d0*pi
     else if ( tpdeltapsi < -pi) then
        tpdeltapsi = tpdeltapsi + 2d0*pi
     end if
     tpdis = sqrt( tpdeltaphi**2 + tpdeltapsi**2 ); tpratio = tpdis/tpmark
     tpr6 = tpratio**6; tpr12 = tpr6**2; tpr5 = tpr6/tpratio; tpr11 = tpr12/tpratio
     temp = (1d0 - tpr6)/(1d0 - tpr12)
     tpvalue = tpvalue + temp
     if ( present(tpgrad) ) then
        temp = ((-6d0*tpr5*(1d0-tpr12) + (1d0-tpr6)*12d0*tpr11)/((1d0-tpr12)**2))/(tpmark*tpdis)
        temp2 = tpcoeff*temp*tpdeltaphi
        call colvar_dihedral(1, tpcoor, tpdis, tpatoms=tpphiatoms, tpgrad=tpgrad, tpfactor=temp2)
        temp2 = tpcoeff*temp*tpdeltapsi
        call colvar_dihedral(1, tpcoor, tpdis, tpatoms=tppsiatoms, tpgrad=tpgrad, tpfactor=temp2)
     end if
  end do
end subroutine

subroutine colvar_pot(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use gb, only : gb_potforce; use pme, only : pme_potforce
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  real*8 :: tpfrc(3,natom)

  if ( ipb == 0 ) then
     call gb_potforce(tpcoor,tpvalue,tpfrc=tpfrc)
  else 
     call pme_potforce(tpcoor,tpvalue,tpfrc=tpfrc)
  end if

  if ( .not. present(tpgrad) ) return
  if ( present(tpfactor) ) tpfrc = tpfactor*tpfrc
  tpgrad = tpgrad - tpfrc
end subroutine

subroutine colvar_pot_bond(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  real*8 :: tpfrc(3,natom)

  tpfrc = 0d0
  call ambertop_potforce_bond(tpcoor,tpvalue,tpfrc=tpfrc)
  if ( .not. present(tpgrad) ) return
  tpfrc = 0d0
  if ( present(tpfactor) ) tpfrc = tpfactor*tpfrc
  tpgrad = tpgrad - tpfrc
end subroutine

subroutine colvar_pot_angle(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  real*8 :: tpfrc(3,natom)

  tpfrc = 0d0
  call ambertop_potforce_angle(tpcoor,tpvalue,tpfrc=tpfrc)
  if ( .not. present(tpgrad) ) return
  if ( present(tpfactor) ) tpfrc = tpfactor*tpfrc
  tpgrad = tpgrad - tpfrc
end subroutine

subroutine colvar_pot_dihe(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  real*8 :: tpfrc(3,natom)

  tpfrc = 0d0
  call ambertop_potforce_dihedral(tpcoor,tpvalue,tpfrc=tpfrc)
  if ( .not. present(tpgrad) ) return
  if ( present(tpfactor) ) tpfrc = tpfactor*tpfrc
  tpgrad = tpgrad - tpfrc
end subroutine

subroutine colvar_pot_elecvdw14(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  real*8 :: tpfrc(3,natom),tpelec14,tpvdw14

  tpfrc = 0d0
  call ambertop_potforce_elecvdw14(tpcoor,tpelec14,tpvdw14,tpfrc=tpfrc)
  tpvalue = tpelec14 + tpvdw14
  if ( .not. present(tpgrad) ) return
  if ( present(tpfactor) ) tpfrc = tpfactor*tpfrc
  tpgrad = tpgrad - tpfrc
end subroutine

subroutine colvar_pot_elec(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use gb, only : gb_potforce_elecvdw
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: saveigb
  real*8 :: tpelec,tpvdw,tpgb,tpgbsa

  saveigb=igb; igb=0
  call gb_potforce_elecvdw(tpcoor,tpelec,tpvdw,tpgb,tpgbsa)
  tpvalue = tpelec; igb=saveigb
end subroutine

subroutine colvar_pot_vdw(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use gb, only : gb_potforce_elecvdw
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: saveigb
  real*8 :: tpelec,tpvdw,tpgb,tpgbsa

  saveigb=igb; igb=0
  call gb_potforce_elecvdw(tpcoor,tpelec,tpvdw,tpgb,tpgbsa)
  tpvalue = tpvdw; igb=saveigb
end subroutine

subroutine colvar_pot_gas(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use gb, only : gb_potforce_elecvdw
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpigb,tpigbsa,tpnatom,tpnres,index
  real*8 :: tpelec,tpvdw,tpgb,tpgbsa,tpelec14,tpvdw14,tpbond,tpangle,tpdihe,tpdiscut
  integer,save :: tpnbond,tpnangle,tpndihe,tpnnb14
  integer,dimension(:),allocatable,save :: tpbondtype,tpbondindex,tpangletype,tpangleindex,tpdihetype,tpdiheindex,tpnb14type,tpnb14index

  tpigb=igb; tpigbsa=igbsa; tpnatom=natom; tpnres=nres; tpdiscut=discut; igb=0; igbsa=0; natom=nbioatom; nres=nbiores; discut=10000.0d0

  if ( .not. allocated(tpbondindex) ) then
     tpnbond = 0
     do index = nbondnoh+1, nbond
        if ( bondatom(3*index - 2) > nbioatom ) tpnbond = tpnbond + 1
     end do
     allocate(tpbondtype(tpnbond),tpbondindex(tpnbond)); tpbondtype=0; tpbondindex=0; tpnbond = 0
     do index = nbondnoh+1, nbond
        if ( bondatom(3*index - 2) > nbioatom ) then
           tpnbond = tpnbond + 1; tpbondindex(tpnbond)=3*index; tpbondtype(tpnbond)=bondatom(tpbondindex(tpnbond))
        end if
     end do
     tpnangle = 0
     do index = 1, nangleh
        if ( angleatom(4*index - 3) > nbioatom ) tpnangle = tpnangle + 1
     end do
     allocate(tpangletype(tpnangle),tpangleindex(tpnangle)); tpangletype=0; tpangleindex=0; tpnangle = 0
     do index = 1, nangleh
        if ( angleatom(4*index - 3) > nbioatom ) then
           tpnangle = tpnangle + 1; tpangleindex(tpnangle)=4*index; tpangletype(tpnangle)=angleatom(tpangleindex(tpnangle))
        end if
     end do
     tpndihe = 0
     do index = 1, ndihedral
        if ( diheatom(5*index - 4) > nbioatom ) tpndihe = tpndihe + 1
     end do
     allocate(tpdihetype(tpndihe),tpdiheindex(tpndihe)); tpdihetype=0; tpdiheindex=0; tpndihe = 0
     do index = 1, ndihedral
        if ( diheatom(5*index - 4) > nbioatom ) then
           tpndihe = tpndihe + 1; tpdiheindex(tpndihe)=5*index; tpdihetype(tpndihe)=diheatom(tpdiheindex(tpndihe))
        end if
     end do
     tpnnb14 = 0
     do index = 1, nnb14
        if ( nonbond14(1,index) > nbioatom ) tpnnb14 = tpnnb14 + 1
     end do
     allocate(tpnb14type(tpnnb14),tpnb14index(tpnnb14)); tpnb14type=0; tpnb14index=0; tpnnb14 = 0
     do index = 1, nnb14
        if ( nonbond14(1,index) > nbioatom ) then
           tpnnb14 = tpnnb14 + 1; tpnb14index(tpnnb14)=index; tpnb14type(tpnnb14)=nonbond14(3,tpnb14index(tpnnb14))
        end if
     end do
  end if

  do index = 1, tpnbond
     bondatom(tpbondindex(index)) = 0
  end do
  do index = 1, tpnangle
     angleatom(tpangleindex(index)) = 0
  end do
  do index = 1, tpndihe
     diheatom(tpdiheindex(index)) = 0
  end do
  do index = 1, tpnnb14
     nonbond14(3,tpnb14index(index)) = 0
  end do

  call gb_potforce(tpcoor,tpvalue)

  igb=tpigb; igbsa=tpigbsa; natom=tpnatom; nres=tpnres; discut=tpdiscut

  do index = 1, tpnbond
     bondatom(tpbondindex(index)) = tpbondtype(index)
  end do
  do index = 1, tpnangle
     angleatom(tpangleindex(index)) = tpangletype(index)
  end do
  do index = 1, tpndihe
     diheatom(tpdiheindex(index)) = tpdihetype(index)
  end do
  do index = 1, tpnnb14
     nonbond14(3,tpnb14index(index)) = tpnb14type(index)
  end do
end subroutine

subroutine colvar_pot_gb(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use gb, only : gb_potforce_elecvdw
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpigb,tpigbsa,tpnatom,tpnres
  real*8 :: tpelec,tpvdw,tpgb,tpgbsa,tpdiscut

  tpigb=igb; tpigbsa=igbsa; tpnatom=natom; tpnres=nres; tpdiscut=discut; igb=1; igbsa=1; natom=nbioatom; nres=nbiores; discut=10000.0d0
  call gb_potforce_elecvdw(tpcoor,tpelec,tpvdw,tpgb,tpgbsa)
  igb=tpigb; igbsa=tpigbsa; natom=tpnatom; nres=tpnres; discut=tpdiscut
  tpvalue = tpgb+tpgbsa
end subroutine

subroutine colvar_pot_gasgb(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  use cudatop; use cudagb
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpigb,tpigbsa,tpnatom,tpnbond
  real*8 :: tpdiscut,tpepot
  logical :: tpifcalpot
  real*8,dimension(:,:),allocatable :: tpfrc

  tpigb=igb; tpigbsa=igbsa; tpnatom=natom; tpnbond=nbond
  igb=1; igbsa=0; natom=nbioatom; nbond=nbiobond
  if ( icuda == 1 ) then
     igb_d=igb; igbsa_d=igbsa; natom_d=natom; nbond_d=nbond
  end if

  if ( icuda == 0 ) then

     allocate(tpfrc(3,nbioatom))
     tpdiscut=discut; discut=10000d0
     call gb_potforce(tpcoor,tpvalue,tpfrc=tpfrc)
     if ( present(tpgrad) ) then
        if ( present(tpfactor) ) tpfrc = tpfactor*tpfrc
        tpgrad(1:3,1:nbioatom) = tpgrad(1:3,1:nbioatom) - tpfrc(1:3,1:nbioatom)
     end if
     deallocate(tpfrc)
     discut=tpdiscut
   
  else

     tpepot = epot_d; tpifcalpot = ifcalpot_d; ifcalpot_d=.true.
     call colvar_pot_gasgb_nowforce<<<(nbioatom-1)/cudathread+1,cudathread>>>(1,0d0)
     call cudagb_potforce(); call cudagb_potforce_sumpot<<<1,1>>>(); tpvalue = epot_d
     if ( present(tpgrad) ) then
        call colvar_pot_gasgb_nowforce<<<(nbioatom-1)/cudathread+1,cudathread>>>(2,tpfactor)
     else
        call colvar_pot_gasgb_nowforce<<<(nbioatom-1)/cudathread+1,cudathread>>>(2,0d0)
     end if
     epot_d = tpepot; ifcalpot_d = tpifcalpot

  end if

  igb=tpigb; igbsa=tpigbsa; natom=tpnatom; nbond=tpnbond
  if ( icuda == 1 ) then
     igb_d=igb; igbsa_d=igbsa; natom_d=natom; nbond_d=nbond
  end if

end subroutine

attributes(global) subroutine colvar_pot_gasgb_nowforce(optdirect,tpfactor)
  use cudatop, only : nowforce_d,nbioatom_d,bioatomtpforce_d
  integer,value :: optdirect
  real*8,value :: tpfactor
  integer :: iatom

  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > nbioatom_d) return

  if ( optdirect == 1 ) then
     bioatomtpforce_d(1:3,iatom) = nowforce_d(1:3,iatom)
  else if ( optdirect == 2 ) then
     if ( tpfactor == 0d0 ) then
        nowforce_d(1:3,iatom) = bioatomtpforce_d(1:3,iatom)
     else
        nowforce_d(1:3,iatom) = bioatomtpforce_d(1:3,iatom) - tpfactor*nowforce_d(1:3,iatom)
     end if
  end if
end subroutine

subroutine colvar_bond(icv,tpcoor,tpvalue,tpgrad,tpfactor,tpatoms)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer,intent(in),optional :: tpatoms(2)

  integer :: iatom,jatom
  real*8 :: tpvec(3),tpcoeff

  if ( present(tpatoms) ) then
     iatom=tpatoms(1); jatom=tpatoms(2)
     if ( iatom == 0 .or. jatom == 0 ) then
        call errormsg("tpatoms error in colvar_bond ",int1=iatom,int2=jatom)
     end if
  else
     iatom=fsacvs(icv)%i(1); jatom=fsacvs(icv)%i(2)
  end if

  tpvalue=0d0
  tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
  tpvalue = sqrt(dot_product(tpvec,tpvec))

  if ( .not. present(tpgrad) ) return
  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor

  tpvec = tpcoeff*tpvec/tpvalue
  tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec
  tpgrad(1:3,jatom) = tpgrad(1:3,jatom) - tpvec
end subroutine

subroutine colvar_angle(icv,tpcoor,tpvalue,tpgrad,tpfactor,tpatoms)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer,intent(in),optional :: tpatoms(3)
  integer :: i,j,k
  real*8 :: rijvec(3),rkjvec(3),coef1(3),coef2(3),coef3(3),rijsq,rkjsq,rij,rkj,rik,theta,costheta
  real*8 :: ri_k,tpcoeff

  if ( present(tpatoms) ) then
     i=tpatoms(1); j=tpatoms(2); k=tpatoms(3)
     if ( (i==0) .or. (j==0) .or. (k==0) ) then
        call errormsg("tpatoms error in colvar_angle ",int1=i,int2=j,int3=k)
     end if
  else
     i=fsacvs(icv)%i(1); j=fsacvs(icv)%i(2); k=fsacvs(icv)%i(3)
  end if

  rijvec(1:3)=tpcoor(1:3,i) - tpcoor(1:3,j); rijsq=dot_product(rijvec,rijvec); rij=sqrt(rijsq)
  rkjvec(1:3)=tpcoor(1:3,k) - tpcoor(1:3,j); rkjsq=dot_product(rkjvec,rkjvec); rkj=sqrt(rkjsq)
  ri_k=dot_product(rijvec,rkjvec); rik=rij*rkj; costheta=ri_k/rik; tpvalue=acos(costheta)

  if ( .not. present(tpgrad) ) return

  coef1 = ( (rkjvec(:)/rik) - rijvec(:)*costheta/rijsq )
  coef2 = ( (rijvec(:)/rik) - rkjvec(:)*costheta/rkjsq )
  coef3 =  coef1 + coef2
  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor
  tpgrad(1:3,i) = tpgrad(1:3,i) - tpcoeff*coef1(1:3)
  tpgrad(1:3,k) = tpgrad(1:3,k) - tpcoeff*coef2(1:3)
  tpgrad(1:3,j) = tpgrad(1:3,j) + tpcoeff*coef3(1:3)
end subroutine

subroutine colvar_dihedral(icv,tpcoor,tpvalue,tpgrad,tpfactor,tpatoms)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer,intent(in),optional :: tpatoms(4)
  integer :: i,j,k,l
  real*8 :: rijvec(3),rkjvec(3),rklvec(3),vec1(3),vec2(3),vec1unit(3),vec2unit(3),negdev(3,4)
  real*8 :: dot1inv,dot2inv,tpvec(3),rijrkj,rkjsize,rkj2,rklrkj,tpcoeff

  if ( present(tpatoms) ) then
     i=tpatoms(1); j=tpatoms(2); k=tpatoms(3); l=tpatoms(4)
     if ( (i==0) .or. (j==0) .or. (k==0) .or. (l==0) ) then
        tpvalue=0d0; return
     end if
  else
     i=fsacvs(icv)%i(1); j=fsacvs(icv)%i(2); k=fsacvs(icv)%i(3); l=fsacvs(icv)%i(4)
  end if
  rijvec(1:3)=tpcoor(1:3,i) - tpcoor(1:3,j)
  rkjvec(1:3)=tpcoor(1:3,k) - tpcoor(1:3,j)
  rklvec(1:3)=tpcoor(1:3,k) - tpcoor(1:3,l)
  call cross_product(rijvec,rkjvec,vec1)
  call cross_product(rkjvec,rklvec,vec2)
  dot1inv=1d0/dot_product(vec1,vec1); dot2inv=1d0/dot_product(vec2,vec2)
  vec1unit(1:3)=vec1(1:3)*sqrt(dot1inv); vec2unit(1:3)=vec2(1:3)*sqrt(dot2inv)
  
  tpvalue=dot_product(vec1unit,vec2unit); tpvalue = min(1.0d0, max(-1.0d0, tpvalue))
  tpvalue=sign(1.0d0,dot_product(rijvec,vec2))*acos( tpvalue )
   
  if ( .not. present(tpgrad) ) return

  rijrkj=dot_product(rijvec,rkjvec); rkj2=dot_product(rkjvec,rkjvec)
  rkjsize=sqrt(rkj2); rklrkj=dot_product(rklvec,rkjvec)
  negdev(1:3,1) = ( -rkjsize*vec1(1:3) )*dot1inv
  negdev(1:3,4) = ( rkjsize*vec2(1:3) )*dot2inv
  tpvec(1:3) = (rijrkj*negdev(1:3,1) - rklrkj*negdev(1:3,4))/rkj2
  negdev(1:3,2)= -negdev(1:3,1) + tpvec(1:3)
  negdev(1:3,3)= -negdev(1:3,4) - tpvec(1:3)

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor
  tpgrad(1:3,i) = tpgrad(1:3,i) - tpcoeff*negdev(1:3,1)
  tpgrad(1:3,j) = tpgrad(1:3,j) - tpcoeff*negdev(1:3,2)
  tpgrad(1:3,k) = tpgrad(1:3,k) - tpcoeff*negdev(1:3,3)
  tpgrad(1:3,l) = tpgrad(1:3,l) - tpcoeff*negdev(1:3,4)
end subroutine

subroutine colvar_disavg(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,i
  real*8 :: tpdis,tpvec(3),tpcoeff

  tpvalue = 0d0; tpcoeff=1.0/dble(fsacvs(icv)%ni/2)
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  do i=1,fsacvs(icv)%ni,2
     iatom = fsacvs(icv)%i(i); jatom = fsacvs(icv)%i(i+1)
     tpvec(1:3) = tpcoor(1:3,iatom) - tpcoor(1:3,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpvalue = tpvalue + tpdis
     if ( present(tpgrad) ) then
        tpvec=tpcoeff*tpvec
        tpgrad(1:3,iatom) =  tpgrad(1:3,iatom) + tpvec(1:3)/tpdis
        tpgrad(1:3,jatom) =  tpgrad(1:3,jatom) - tpvec(1:3)/tpdis
     end if 
  end do
  tpvalue = tpvalue/dble(fsacvs(icv)%ni/2)
end subroutine

subroutine colvar_disavgres(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer :: tpndim,iatom,jatom,i,k,ires,jres,ilow,iup,istart
  real*8 :: tpdis,tpvec(3),tpcoeff,tpcom1(3),tpcom2(3),temp
  logical,save :: ifnotfirst(30)

  ilow=0; iup=0; istart=1
  if ( fsacvs(icv)%i(1)*fsacvs(icv)%i(2) < 0 ) then
     if ( (fsacvs(icv)%i(1) > 0) .and. (fsacvs(icv)%i(2) < 0) ) then
        ilow=fsacvs(icv)%i(1); iup=-fsacvs(icv)%i(2); istart=3
        if ( (ilow < 1) .or. (iup > (nres-1)) ) call errormsg("wrong contact interval ",int1=ilow,int2=iup)
        if ( ifnotfirst(icv) .eqv. .false. ) then
           ifnotfirst(icv)=.true.; tpndim = 0; write(iosiminfo,"(a,2i5)") "colvar_ncontactres, range ",ilow,iup
           do i=istart,fsacvs(icv)%ni,2
              ires = fsacvs(icv)%i(i); jres = fsacvs(icv)%i(i+1)
              if ( ((jres-ires) < ilow) .or. ((jres-ires) > iup) ) cycle
              tpndim = tpndim + 1
              write(iosiminfo,"(a,i3,a,2i6)") "contact ",tpndim,": ",ires,jres
           end do
           flush(iosiminfo)
        end if
     else
        call errormsg("wrong contact interval ",int1=ilow,int2=iup)
     end if
  end if

  tpvalue = 0d0; tpcoeff=1.0/dble(fsacvs(icv)%ni/2)
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor
  do i=istart,fsacvs(icv)%ni,2
     ires = fsacvs(icv)%i(i); jres = fsacvs(icv)%i(i+1)
     if ( (ires < 0) .or. (jres < 0) ) cycle
     if ( istart == 3 ) then
        if ( ((jres-ires) < ilow) .or. ((jres-ires) > iup) ) cycle
     end if

     call ambertop_get_com(tpcoor,tpcom1,tpres=(/ires/),ifheavysc=.true.)
     call ambertop_get_com(tpcoor,tpcom2,tpres=(/jres/),ifheavysc=.true.)
     tpvec(1:3) = tpcom1(1:3) - tpcom2(1:3)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     tpvalue = tpvalue + tpdis
     if ( present(tpgrad) ) then
        tpvec=tpcoeff*tpvec; temp=tpdis*resmass(ires)
        do k=heavyscindex(ires)+1,heavyscindex(ires+1)
           iatom=heavyscatoms(k)
           tpgrad(1:3,iatom) =  tpgrad(1:3,iatom) + tpvec(1:3)*mass(iatom)/temp
        end do
        temp=tpdis*resmass(jres)
        do k=heavyscindex(jres)+1,heavyscindex(jres+1)
           jatom=heavyscatoms(k)
           tpgrad(1:3,jatom) =  tpgrad(1:3,jatom) - tpvec(1:3)*mass(jatom)/temp
        end do
     end if
  end do
  tpvalue = tpvalue/dble(fsacvs(icv)%ni/2)
end subroutine

subroutine colvar_rmsd_updaterefcoor(icv,tpcoor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  integer :: i,iatom
  real*8 :: tpvec(3)
  if ( (icv <= 0) .or. (fsacvs(icv)%type /= CV_RMSD) ) then
     call errormsg("error cv index in colvar_rmsd_updaterefcoor ",int1=icv)
  end if
  do i=1,fsacvs(icv)%ni
     iatom=fsacvs(icv)%i(i)
     fsacvs(icv)%r(3*i-2:3*i) = tpcoor(1:3,iatom)
  end do
  tpvec=0d0
  do i=1,fsacvs(icv)%ni
     tpvec(1:3) = tpvec(1:3) + fsacvs(icv)%r(3*i-2:3*i)
  end do
  tpvec(1:3)=tpvec(1:3)/dble(fsacvs(icv)%ni)
  do i=1,fsacvs(icv)%ni
     fsacvs(icv)%r(3*i-2:3*i) = fsacvs(icv)%r(3*i-2:3*i) - tpvec(1:3)
  end do
end subroutine

subroutine colvar_rmsd(icv,tpcoor,tpvalue,tpgrad,tpfactor,endend)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer, optional :: endend
  integer :: tpndim,iatom,i,j, igroup, offset
  real*8,dimension(fsacvs(icv)%nr) :: coor1,coor2,tptpgrad
  real*8 :: totmass, temp, tpcoeff
  real*8,dimension(fsacvs(icv)%ngroup) :: groupmass, tprmsd

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor

  coor2=fsacvs(icv)%r
  if(present(endend)) then
      if(endend==2) then
         coor2 = fsacvs(icv)%r2
      endif
      if(present(tpgrad)) then
         tpgrad=0d0
      endif
  endif
  totmass=0d0; tpvalue=0d0; groupmass=0d0

  offset=0
  do igroup=1,fsacvs(icv)%ngroup
     do i=fsacvs(icv)%groups(1,igroup),fsacvs(icv)%groups(2,igroup)
        iatom = fsacvs(icv)%i(i)
        coor1(3*(i-offset)-2 : 3*(i-offset))=tpcoor(1:3,iatom)
        groupmass(igroup) = groupmass(igroup) + mass(iatom)
     end do
     totmass = totmass + groupmass(igroup)
     offset = offset+1
  enddo

  offset = 0
  do igroup=1,fsacvs(icv)%ngroup
    i=fsacvs(icv)%groups(1,igroup)-offset
    j=fsacvs(icv)%groups(2,igroup)-offset
    call pubmod_lRMSD((j-i+1)*3, coor1(3*i-2 : 3*j), coor2(3*i-2 : 3*j),  &
                  tprmsd(igroup),tpgrad=tptpgrad(3*i-2 : 3*j))
    tpvalue = tpvalue + (tprmsd(igroup)**2)*groupmass(igroup)/totmass
    offset = offset + 1
  end do
  tpvalue = sqrt(tpvalue)
  if ( .not. present(tpgrad) ) return
  offset = 0
  do igroup=1,fsacvs(icv)%ngroup
    temp = tpcoeff*groupmass(igroup)*tprmsd(igroup)/(tpvalue*totmass)
    do i=fsacvs(icv)%groups(1,igroup),fsacvs(icv)%groups(2,igroup)
      iatom = fsacvs(icv)%i(i)
      tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tptpgrad(3*(i-offset)-2 : 3*(i-offset))
    end do
    offset = offset + 1
  enddo
end subroutine

subroutine colvar_drmsd(icv,tpcoor,tpvalue,tpgrad,tpfactor,endend)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer, intent(in), optional :: endend
  integer :: tpndim,iatom,jatom,i,j,index
  real*8 :: coor1(3),coor2(3),dis,refdis,tpcoeff,tpvec(3)
  real*8, pointer :: fsacvsPointer(:)

  fsacvsPointer => fsacvs(icv) % r
  if(present(endend)) then
      if(endend==2) then
         fsacvsPointer => fsacvs(icv)%r2
      endif
      if(present(tpgrad)) then
         tpgrad=0d0
      endif
  endif

  tpvalue = 0d0; index = 0
  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i); coor1(1:3)=tpcoor(1:3,iatom)
     do j=i+1,fsacvs(icv)%ni
        jatom = fsacvs(icv)%i(j)
        coor2(1:3)=tpcoor(1:3,jatom)
        tpvec(1:3) = coor1(1:3) - coor2(1:3)
        dis = sqrt(dot_product(tpvec,tpvec))
        index = index + 1
        refdis = fsacvsPointer(index)
        tpvalue = tpvalue + (dis - refdis)**2
     end do
  end do
  tpvalue = sqrt(tpvalue/dble(fsacvs(icv)%nr))

  if ( .not. present(tpgrad) ) return

  index = 0
  tpcoeff=1.0/(tpvalue*dble(fsacvs(icv)%nr))
  if ( present(tpfactor) ) tpcoeff=tpcoeff*tpfactor

  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i); coor1(1:3)=tpcoor(1:3,iatom)
     do j=i+1,fsacvs(icv)%ni
        jatom = fsacvs(icv)%i(j); coor2(1:3)=tpcoor(1:3,jatom)
        tpvec(1:3) = coor1(1:3) - coor2(1:3)
        dis = sqrt(dot_product(tpvec,tpvec))
        index = index + 1
        refdis = fsacvsPointer(index)
        tpvec(1:3) = tpcoeff*(dis-refdis)*tpvec(1:3)/dis
        tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpvec(1:3)
        tpgrad(1:3,iatom) = tpgrad(1:3,iatom) - tpvec(1:3)
     end do
  end do
end subroutine

subroutine colvar_com_pos(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  integer :: i,iatom,iaxis
  real*8 :: tppos(3),tpvec(3),tpmass,tpcoeff

  tppos(1:3)=0.0d0; tpmass=0d0
  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i)
     tppos(1:3)=tppos(1:3)+tpcoor(1:3,iatom)*mass(iatom)
     tpmass = tpmass + mass(iatom)
  end do
  tppos(1:3)=tppos(1:3)/tpmass
  tpvec(1:3) = tppos(1:3) - fsacvs(icv)%r(1:3)

  tpvalue = 0d0
  do iaxis=1,3
     if ( fsacvs(icv)%r(iaxis) < -999.0d0 ) cycle
     tpvalue = tpvalue + tpvec(iaxis)**2
  end do
  tpvalue = sqrt(tpvalue)

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor
  tpvec(1:3) = tpcoeff*tpvec(1:3)/(tpvalue*tpmass)
  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i)
     do iaxis=1,3
        if ( fsacvs(icv)%r(iaxis) < -999.0d0 ) cycle
        tpgrad(iaxis,iatom) = tpgrad(iaxis,iatom) + tpvec(iaxis)*mass(iatom)
     end do
  end do
end subroutine

subroutine colvar_com_posaxis(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  integer :: i,iatom,iaxis
  real*8 :: tppos(3),tpvec(3),tpmass,tpcoeff

  iaxis=0
  do i=1,3
     if ( fsacvs(icv)%r(i) > -999.0d0 ) then
        iaxis=i; exit;
     end if
  end do
  if ( (iaxis < 1) .or. (iaxis > 3) ) call errormsg("wrong axis in posaxis ",int1=iaxis)

  tppos(iaxis)=0.0d0; tpmass=0d0
  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i)
     tppos(iaxis)=tppos(iaxis)+tpcoor(iaxis,iatom)*mass(iatom)
     tpmass = tpmass + mass(iatom)
  end do
  tppos(iaxis)=tppos(iaxis)/tpmass
  tpvalue = tppos(iaxis)

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor
  tpcoeff = tpcoeff/tpmass
  do i=1,fsacvs(icv)%ni
     iatom = fsacvs(icv)%i(i)
     tpgrad(iaxis,iatom) = tpgrad(iaxis,iatom) + tpcoeff*mass(iatom)
  end do
end subroutine

subroutine colvar_com_dis(icv,tpcoor,tpvalue,tpgrad,tpfactor)
  integer,intent(in) :: icv
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpvalue
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor

  integer :: i,igroup,iatom,iaxis
  real*8 :: tppos1(3),tppos2(3),tpvec(3),tpcoeff
  real*8 :: groupmass(fsacvs(icv)%ngroup),groupvec(3,fsacvs(icv)%ngroup)

  groupvec=0d0; groupmass=0d0; tpvalue=0d0
  do igroup=1,fsacvs(icv)%ngroup
     do i=fsacvs(icv)%groups(1,igroup),fsacvs(icv)%groups(2,igroup)
        iatom = fsacvs(icv)%i(i)
        groupvec(1:3,igroup) = groupvec(1:3,igroup) + tpcoor(1:3,iatom)*mass(iatom)
        groupmass(igroup) = groupmass(igroup) + mass(iatom)
     end do
     groupvec(1:3,igroup) = groupvec(1:3,igroup)/groupmass(igroup)
  end do

  tpvec(1:3) = groupvec(1:3,1) - groupvec(1:3,2)
  tpvalue = sqrt(dot_product(tpvec,tpvec))

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor
  tpvec = tpcoeff*tpvec/tpvalue
  do igroup=1,fsacvs(icv)%ngroup
     do i=fsacvs(icv)%groups(1,igroup),fsacvs(icv)%groups(2,igroup)
        iatom = fsacvs(icv)%i(i)
        if ( igroup == 1 ) then
           tpgrad(:,iatom) = tpgrad(:,iatom) + tpvec(:)*mass(iatom)/groupmass(igroup)
        else if ( igroup == 2 ) then
           tpgrad(:,iatom) = tpgrad(:,iatom) - tpvec(:)*mass(iatom)/groupmass(igroup)
        end if
     end do
  end do
end subroutine

subroutine colvar_pca(tpcvindex,tptpcoor,tpcv,tpgrad,tpfactor)
  integer,intent(in) :: tpcvindex
  real*8,intent(in) :: tptpcoor(3,natom)
  real*8,intent(out) :: tpcv
  real*8,intent(inout),optional :: tpgrad(3,natom)
  real*8,intent(in),optional :: tpfactor
  integer,save :: pcanatom,pcanpc
  integer,allocatable,dimension(:),save :: pcaatoms,pcaindex,pc2cv
  real*8,allocatable,dimension(:),save :: tprefcoor,tppcavec,tpcoor
  real*8,allocatable,dimension(:,:),save :: pcavec,pcavecsum
  real*8,save :: tprotmat(3,3),tpdis
  logical,save :: ifpolar
  integer :: ipc,i,j,icv,iofile,iatom,tppcindex
  real*8 :: tpcoeff,temp
  character*100 :: pcaeigenfile
  logical :: iffind

  if ( .not. allocated(pcavecsum) ) then

     ipc=0; allocate(pcaindex(cvnatom*3),pc2cv(ncv)); pcaindex=0; pc2cv=0
     do icv=1,ncv
        if ( fsacvs(icv)%type == CV_PCA ) then
           ipc = ipc + 1; pcaindex(ipc)=fsacvs(icv)%cv_index; pc2cv(ipc)=icv
           if ( ipc == 1 ) then
              pcaeigenfile=fsacvs(icv)%cv_s; pcanatom=fsacvs(icv)%ni
              allocate(pcaatoms(pcanatom)); pcaatoms(1:pcanatom)=fsacvs(icv)%i(1:pcanatom)
           end if
        end if
     end do
     if ( pcaindex(1) < 0 ) then
        if ( ipc /= 2 ) call errormsg("wrong number of pca collective variable!")
        pcanpc = abs(pcaindex(1)); ifpolar=.true.
        do i=1,pcanpc; pcaindex(i)=i; end do
     else
        pcanpc = ipc
        do ipc=1,pcanpc
           do i=ipc+1,pcanpc
              if ( pcaindex(ipc) == pcaindex(i) ) call errormsg("pcaindex error ",int1=ipc,int2=i,int3=pcaindex(i))
           end do
        end do
     end if
     allocate(tprefcoor(3*pcanatom),tpcoor(3*pcanatom)); tprefcoor=0d0; tpcoor=0d0
     allocate(pcavec(3*pcanatom,pcanpc),tppcavec(3*pcanatom)); pcavec=0d0; tppcavec=0d0

     call getfreeunit(iofile); open(unit=iofile,file=pcaeigenfile,action="read")
     read(iofile,"(10x,10000f8.3)") tppcavec(1:3*pcanatom)
     tprefcoor(1:3*pcanatom) = tppcavec(1:3*pcanatom)
!     do i=1, pcanatom; tprefcoor(3*i-2:3*i) = nowcoor(1:3, pcaatoms(i)); end do
     read(iofile,*); read(iofile,*)
     i=0; ipc=1
     do
        read(iofile,"(4x,10000f8.3)") tppcavec(1:3*pcanatom)
        i = i + 1
        if ( i == pcaindex(ipc) ) then
           pcavec(1:3*pcanatom,ipc)=tppcavec(1:3*pcanatom)
           tpcoeff = sqrt(dot_product(pcavec(1:3*pcanatom,ipc),pcavec(1:3*pcanatom,ipc)))
           if ( abs(1.0d0-tpcoeff) > 0.01d0 ) call errormsg("pca axis is not normalized ",int1=ipc,real1=tpcoeff)
           if ( ipc == pcanpc ) exit
           ipc = ipc + 1
        end if
     end do
     close(iofile)

     allocate(pcavecsum(3,pcanpc)); pcavecsum=0d0
     do ipc=1,pcanpc
        do i=1,pcanatom
           pcavecsum(1:3,ipc) = pcavecsum(1:3,ipc) + pcavec(3*i-2:3*i,ipc)
        end do
     end do
     pcavecsum = pcavecsum/dble(pcanatom)

     if ( procid == 0 ) then
        write(iosiminfo,*)
        write(iosiminfo,"(a)") "use pca collective variables"
        write(iosiminfo,"(a)") "pca eigen file ",trim(pcaeigenfile)
        write(iosiminfo,"(a,i6,5x,a,i6)") "pca natom ",pcanatom
        write(iosiminfo,"(a)") "pca atoms "
        write(iosiminfo,"(18i6)") pcaatoms(1:pcanatom)
        write(iosiminfo,"(a,i6)") "pca npc ",pcanpc
        if ( ifpolar .eqv. .false. ) then
           write(iosiminfo,"(a,100i4)") "pca indices: ",pcaindex(1:pcanpc)
        else
           write(iosiminfo,"(a)") "use polar coordinates in pca space"
        end if
        flush(iosiminfo)
     end if
  end if

  iffind=.false.; tppcindex=0
  do
     tppcindex = tppcindex + 1
     if ( pc2cv(tppcindex) == tpcvindex ) then; iffind=.true.; exit; end if
     if ( ifpolar .eqv. .false. ) then
        if ( tppcindex == pcanpc ) exit
     else
        if ( tppcindex == 2 ) exit
     end if
  end do
  if ( iffind .eqv. .false. ) call errormsg("wrong tpcvindex in moldata_colvar_pca",int1=tpcvindex)
         
  if ( tppcindex == 1 ) then
     do i=1, pcanatom
        tpcoor(3*i-2:3*i) = tptpcoor(1:3, pcaatoms(i))
     end do
     call pubmod_lRMSD(pcanatom*3,tpcoor,tprefcoor,tpcoeff,ifrotatecoor1=.true.,rotatemat=tprotmat)
     if ( ifpolar .eqv. .true. ) then
        tppcavec=0d0
        do ipc=1,pcanpc
           tppcavec(ipc)=dot_product(pcavec(1:3*pcanatom,ipc),tpcoor(1:3*pcanatom))
        end do
        tpdis = sqrt(dot_product(tppcavec(1:pcanpc),tppcavec(1:pcanpc)))
     end if
  end if

  if ( ifpolar .eqv. .false. ) then
     tpcv = dot_product(pcavec(1:3*pcanatom,tppcindex),tpcoor(1:3*pcanatom))
  else
     if ( tppcindex == 1 ) then
        tpcv = tpdis
     else if ( tppcindex == 2 ) then
        tpcv = acos(tppcavec(1)/tpdis)
     else
        call errormsg("wrong tppcindex ",int1=tppcindex,int2=tpcvindex)
     end if
  end if

  if ( .not. present(tpgrad) ) return

  tpcoeff=1.0d0; if ( present(tpfactor) ) tpcoeff=tpfactor

  if ( ifpolar .eqv. .false. ) then

     do i=1,pcanatom
        iatom = pcaatoms(i)
        do j=1,3
           tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpcoeff*  &
              ( pcavec(3*i-3+j,tppcindex)*tprotmat(j,1:3) - pcavecsum(j,tppcindex)*tprotmat(j,1:3) )
        end do
     end do

  else

     if ( tppcindex == 1 ) then
        tpcoeff = tpcoeff/tpdis
        do ipc=1,pcanpc
           do i=1,pcanatom
              iatom = pcaatoms(i)
              do j=1,3
                 tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + tpcoeff*tppcavec(ipc)*  &
                     ( pcavec(3*i-3+j,ipc)*tprotmat(j,1:3) - pcavecsum(j,ipc)*tprotmat(j,1:3) )
              end do
           end do
        end do
     else if ( tppcindex == 2 ) then
        temp = tppcavec(1)/tpdis; temp = -1d0/sqrt(1-temp**2)
        tpcoeff = tpcoeff*temp
        do ipc=1,pcanpc
           do i=1,pcanatom
              temp = tpcoeff/tpdis
              do j=1,3
                 tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*  &
                    ( pcavec(3*i-3+j,1)*tprotmat(j,1:3) - pcavecsum(j,1)*tprotmat(j,1:3) )
              end do
              temp = tpcoeff*tppcavec(1)*(-1d0)/(tpdis**3)
              do j=1,3
                 tpgrad(1:3,iatom) = tpgrad(1:3,iatom) + temp*tppcavec(ipc)* &
                     ( pcavec(3*i-3+j,ipc)*tprotmat(j,1:3) - pcavecsum(j,ipc)*tprotmat(j,1:3) )
              end do
           end do
        end do
     end if
  end if
end subroutine

subroutine colvar_getkeydihedrals(tpnkey,tpkeyatoms)
  integer,intent(out) :: tpnkey
  integer,intent(out) :: tpkeyatoms(4,*)
  integer :: ires,iatom,preic,nextin,in,ica,ic,icb,icg,icd,icz,ice,ind,ine,inh,inz,ioe,iog,iod,isg,isd
  tpnkey = 0
  do ires=2, nres-1
     preic=0; nextin=0; in=0; ica=0; ic=0; icb=0; icg=0; icd=0; ice=0; icz=0; ind=0; ine=0; inh=0; 
     inz=0; ioe=0; iog=0; iod=0; isg=0; isd=0
     do iatom=resindex(ires-1)+1,resindex(ires)
        if ( name(iatom) == "C   " ) then
           preic=iatom; exit
        end if
     end do
     do iatom=resindex(ires+1)+1,resindex(ires+2)
        if ( name(iatom) == "N   " ) then
           nextin=iatom; exit
        end if
     end do
     do iatom=resindex(ires)+1,resindex(ires+1)
        select case(name(iatom))
        case("N   "); in=iatom
        case("CA  "); ica=iatom
        case("C   "); ic=iatom
        case("CB  ","CB1 "); icb=iatom
        case("CG  ","CG1 "); icg=iatom
        case("CD  ","CD1 "); icd=iatom
        case("CZ  ","CZ1 "); icz=iatom
        case("CE  ","CE1 "); ice=iatom
        case("ND  ","ND1 ","ND2 "); ind=iatom
        case("NE  ","NE1 ","NE2 "); ine=iatom
        case("NH  ","NH1 ","NH2 "); inh=iatom
        case("NZ  ","NZ1 ","NZ2 "); inz=iatom
        case("OD  ","OD1 ","OD2 "); iod=iatom
        case("OG  ","OG1 ","OG2 "); iog=iatom
        case("OE  ","OE1 ","OE2 "); ioe=iatom
        case("SG  ","SG1 ","SG2 "); isg=iatom
        case("SD  ","SD1 "); isd=iatom
        end select
     end do

!     if ( (allocated(resstate)) .and. (resstate(ires) == 0) ) then
!        if (resname(ires) /= "PRO ") call addkeydihedrals(preic,in,ica,ic)
!        call addkeydihedrals(in,ica,ic,nextin)
!     end if

     select case(resname(ires))
     case("ALA ")
     case("ARG ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd); call addkeydihedrals(icb,icg,icd,ine); 
       call addkeydihedrals(icg,icd,ine,icz); call addkeydihedrals(icd,ine,icz,inh);
     case("ASN ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,ind);
     case("ASP ")
      call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,iod); 
     case("CYS ","CYX ")
       call addkeydihedrals(in,ica,icb,isg); 
     case("GLN ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd); call addkeydihedrals(icb,icg,icd,ine);
     case("GLU ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd); call addkeydihedrals(icb,icg,icd,ioe);
     case("GLY ")
     case("ILE ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd);
     case("LEU ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd);
     case("LYS ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd); call addkeydihedrals(icb,icg,icd,ice);
       call addkeydihedrals(icg,icd,ice,inz)
     case("MET ") 
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,isd); call addkeydihedrals(icb,icg,isd,ice);
     case("PHE ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd)
     case("PRO ")
     case("SER ")
       call addkeydihedrals(in,ica,icb,iog)
     case("THR ")
       call addkeydihedrals(in,ica,icb,iog)
     case("TRP ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd);
     case("TYR ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,icd);
     case("VAL ")
       call addkeydihedrals(in,ica,icb,icg)
     case("HIS ","HID ","HIP ","HIE ")
       call addkeydihedrals(in,ica,icb,icg); 
       call addkeydihedrals(ica,icb,icg,ind);
     case default
       call errormsg("unrecognized resname ",str1=resname(ires))
     end select
  end do

contains
  subroutine addkeydihedrals(i,j,k,l)
    integer,intent(in) :: i,j,k,l
    real*8 :: tpvec(3),tpdis,tpmark
    tpmark=1.85d0
    if ( (i==0) .or. (j==0) .or. (k==0) .or. (l==0) ) call errormsg("wrong atom index in addkeydihedrals")
    tpvec(1:3) = nowcoor(1:3,i) - nowcoor(1:3,j); tpdis = sqrt(dot_product(tpvec,tpvec))
    if (tpdis > tpmark ) call errormsg("wrong distance ",int1=i,int2=j,real1=tpdis)
    tpvec(1:3) = nowcoor(1:3,j) - nowcoor(1:3,k); tpdis = sqrt(dot_product(tpvec,tpvec))
    if (tpdis > tpmark ) call errormsg("wrong distance ",int1=j,int2=k,real1=tpdis)
    tpvec(1:3) = nowcoor(1:3,k) - nowcoor(1:3,l); tpdis = sqrt(dot_product(tpvec,tpvec))
    if (tpdis > tpmark ) call errormsg("wrong distance ",int1=k,int2=l,real1=tpdis)
    tpnkey = tpnkey + 1
    tpkeyatoms(1:4,tpnkey) = (/i,j,k,l/)
  end subroutine
end subroutine

subroutine colvar_addrestraints_phipsi(tpcoor,tpfrc)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(inout) :: tpfrc(3,natom)
  integer :: ires,in,ica,ic,iprec,inextn,i,iofile,tpndim,resstride,ierr
  real*8 :: tpaphi0,tpapsi0,tpbphi0,tpbpsi0,tpphi,tppsi,tpssrstrad,tpssrstslope,tpdis,tpdis2,tpfactor,temp
  real*8 :: tpdeltaphi,tpdeltapsi
  integer,save,dimension(:),allocatable :: resssstate
  logical,save :: ifnotfirst
  character*200 :: tpseq

  tpssrstrad = 20d0*pi/180d0; tpssrstslope = 1d0*180d0/pi
  tpaphi0 = -57d0*pi/180d0; tpapsi0 = -47d0*pi/180d0
  tpbphi0 = -80d0*pi/180d0; tpbpsi0 = 150d0*pi/180d0

  if ( ifnotfirst .eqv. .false. ) then
     if (procid==(procnum-1)) then
        write(iosiminfo,*); write(iosiminfo,"(a)") "Initializing secondary structure restraints"
        write(iosiminfo,"(2(a,f8.3,3x))") "ssrstslope ",tpssrstslope*pi/180d0,", ssrstrad ",tpssrstrad*180d0/pi
     end if
     ifnotfirst = .true.

     if ( .not. allocated(refcoor) ) then
     if ( procid == (procnum-1) ) then
        call getfreeunit(iofile); open(unit=iofile,file="metapsicov.txt",action="read"); read(iofile,*)
        allocate(resssstate(4*nres)); resssstate=0; resstride=10; ica=0

        tpndim=0.4d0*nres
        do
           read(iofile,*,iostat=ierr) in,ic; if ( ierr < 0 ) exit
           if ( (ic-in) > resstride ) then
              ica=ica+1; resssstate(2*ica-1:2*ica)=(/in,ic/)
              if ( ica == tpndim ) exit
           end if
        end do
        if ( (ierr >= 0) .and. (ica==tpndim) ) then
           write(iosiminfo,"(i3,a,i2)") tpndim," contacts for resstride>",resstride
           write(iosiminfo,"(a)") "&fsacolvar"
           write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRES'"
           write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",(resssstate(i),", ",i=1,tpndim*2)
           write(iosiminfo,"(a,f4.1)") "  cv_r = ",7.0
           write(iosiminfo,"(a)") "/"
        end if

        tpndim=0.6d0*nres
        do
           read(iofile,*,iostat=ierr) in,ic; if ( ierr < 0 ) exit
           if ( (ic-in) > resstride ) then
              ica=ica+1; resssstate(2*ica-1:2*ica)=(/in,ic/)
              if ( ica == tpndim ) exit
           end if
        end do
        if ( (ierr >= 0) .and. (ica==tpndim) ) then
           write(iosiminfo,"(i3,a,i2)") tpndim," contacts for resstride>",resstride
           write(iosiminfo,"(a)") "&fsacolvar"
           write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRES'"
           write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",(resssstate(i),", ",i=1,tpndim*2)
           write(iosiminfo,"(a,f4.1)") "  cv_r = ",7.0
           write(iosiminfo,"(a)") "/"
        end if

        tpndim=0.8d0*nres
        do
           read(iofile,*,iostat=ierr) in,ic; if ( ierr < 0 ) exit
           if ( (ic-in) > resstride ) then
              ica=ica+1; resssstate(2*ica-1:2*ica)=(/in,ic/)
              if ( ica == tpndim ) exit
           end if
        end do
        if ( (ierr >= 0) .and. (ica==tpndim) ) then
           write(iosiminfo,"(i3,a,i2)") tpndim," contacts for resstride>",resstride
           write(iosiminfo,"(a)") "&fsacolvar"
           write(iosiminfo,"(a)") "  cv_type = 'NCONTACTRES'"
           write(iosiminfo,"(a,1000(i4,a2))") "  cv_i = ",(resssstate(i),", ",i=1,tpndim*2)
           write(iosiminfo,"(a,f4.1)") "  cv_r = ",7.0
           write(iosiminfo,"(a)") "/"
        end if

        deallocate(resssstate); close(iofile)
     end if

     tpndim=0; tpseq=""; allocate(resssstate(nres)); resssstate=0;
     call getfreeunit(iofile); open(unit=iofile,file="metapsicov.txt",action="read")
     read(iofile,"(a)") tpseq
     do ires = 1, 200
        if ( tpseq(ires:ires) == "H" ) then
           resssstate(ires)=1; tpndim=tpndim+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(2i4,2a6)") tpndim,ires,resname(ires), " alpha"
        else if ( tpseq(ires:ires) == "E" ) then
           resssstate(ires)=2; tpndim=tpndim+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(2i4,2a6)") tpndim,ires,resname(ires), " beta"
        end if
     end do
     close(iofile)
     allocate(resstate(nres)); resstate=resssstate
     else

     allocate(resssstate(nres)); resssstate=0; i=0
     do ires=2,nres-1
        if ( resname(ires) == "PRO " ) cycle
        iprec=resindex(ires)-1; in=resindex(ires)+1; ica=resindex(ires)+3; 
        ic=resindex(ires+1)-1; inextn=resindex(ires+1)+1
        call colvar_dihedral(1, refcoor, tpphi, tpatoms=(/iprec,in,ica,ic/))
        call colvar_dihedral(1, refcoor, tppsi, tpatoms=(/in,ica,ic,inextn/))

        tpdis = sqrt( (tpphi-tpaphi0)**2 + (tppsi-tpapsi0)**2 )
        tpdis2= sqrt( (tpphi-tpbphi0)**2 + (tppsi-tpbpsi0)**2 )
        if ( (tpdis < tpssrstrad) .and. (tpdis2 < tpssrstrad) ) call errormsg("ssrstrad is too large!")
        if ( tpdis < tpssrstrad ) then
           resssstate(ires)=1; i=i+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(i3,a,i3,2a6)") i,": ",ires,resname(ires), " alpha"
        else if ( tpdis2 < tpssrstrad ) then
           resssstate(ires)=2; i=i+1
           if ( procid == (procnum-1) ) write(iosiminfo,"(i3,a,i3,2a6)") i,": ",ires,resname(ires), "  beta"
        end if
     end do

     end if
     flush(iosiminfo)
  end if

  do ires=2,nres-1
     if ( (resname(ires) == "PRO ") .or. (resssstate(ires)==0) ) cycle
     iprec=resindex(ires)-1; in=resindex(ires)+1; ica=resindex(ires)+3;
     ic=resindex(ires+1)-1; inextn=resindex(ires+1)+1
     call colvar_dihedral(1, tpcoor, tpphi, tpatoms=(/iprec,in,ica,ic/))
     call colvar_dihedral(1, tpcoor, tppsi, tpatoms=(/in,ica,ic,inextn/))
     select case(resssstate(ires))
     case(1)
        tpdeltaphi = tpphi - tpaphi0
        tpdeltapsi = tppsi - tpapsi0
     case(2)
        tpdeltaphi = tpphi - tpbphi0
        tpdeltapsi = tppsi - tpbpsi0
     end select
     if ( tpdeltaphi > pi ) then; tpdeltaphi = tpdeltaphi - 2d0*pi
     else if ( tpdeltaphi < -pi) then;  tpdeltaphi = tpdeltaphi + 2d0*pi; end if
     if ( tpdeltapsi > pi ) then;  tpdeltapsi = tpdeltapsi - 2d0*pi
     else if ( tpdeltapsi < -pi) then; tpdeltapsi = tpdeltapsi + 2d0*pi; end if
     tpdis = sqrt( tpdeltaphi**2 + tpdeltapsi**2 )

     if ( tpdis > tpssrstrad ) then
        temp = -tpssrstslope*(tpdis-tpssrstrad)/tpdis
        tpfactor = temp*tpdeltaphi
        call colvar_dihedral(1, tpcoor, tpphi, tpfrc, tpfactor=tpfactor, tpatoms=(/iprec,in,ica,ic/))
        tpfactor = temp*tpdeltapsi
        call colvar_dihedral(1, tpcoor, tppsi, tpfrc, tpfactor=tpfactor, tpatoms=(/in,ica,ic,inextn/)) 
     end if
  end do
end subroutine

subroutine colvar_addrepulsepot_kdscale(tpcoor,tpfrc,tprad,tpslope)
  real*8,intent(in) :: tpcoor(3,natom),tprad,tpslope
  real*8,intent(inout) :: tpfrc(3,natom)
  integer :: ires,jres,iatom,jatom,i,j,k
  real*8 :: tpdis,tpvec(3),tpcom1(3),tpcom2(3),tpcomvec(3,nres)

  tpcomvec=0d0
  do ires=1,nres
     if ( (reskdscale(ires) > -3d0) .and. (reskdscale(ires) < 0d0) ) cycle 
     call ambertop_get_com(tpcoor,tpcomvec(1:3,ires),tpatoms=heavyscatoms(heavyscindex(ires)+1:heavyscindex(ires+1)))
  end do

  do ires=1,nres
     if ( reskdscale(ires) > -3d0 ) cycle
     tpcom1 = tpcomvec(1:3,ires)
     do jres=1,nres
        if ( reskdscale(jres) < 0d0 ) cycle
        tpcom2 = tpcomvec(1:3,jres)
        tpvec = tpcom1 - tpcom2
        tpdis = sqrt(dot_product(tpvec,tpvec))
        if ( tpdis > tprad ) cycle
        if ( tpdis == 0d0 ) call errormsg("wrong com distance in addrepulsepot ",int1=ires,int2=jres, &
             str1=resname(ires),str2=resname(jres))
        tpvec = tpslope*tpvec/tpdis
        do k=heavyscindex(ires)+1,heavyscindex(ires+1)
           iatom = heavyscatoms(k)
           tpfrc(1:3,iatom) = tpfrc(1:3,iatom) + tpvec(1:3)*mass(iatom)/heavyscmass(ires)
        end do
        do k=heavyscindex(jres)+1,heavyscindex(jres+1)
           jatom = heavyscatoms(k)
           tpfrc(1:3,jatom) = tpfrc(1:3,jatom) - tpvec(1:3)*mass(jatom)/heavyscmass(jres)
        end do
     end do
  end do
end subroutine

subroutine colvar_internal_coordinates(tpcoor,tpintercoor,tpforce,tprotforce,tprotmat,tpinteratom)
  real*8,intent(in) :: tpcoor(3,natom)
  real*8,intent(out) :: tpintercoor(4*natom-3)
  real*8,intent(in),optional :: tpforce(3,natom)
  real*8,intent(out),optional :: tprotforce(3,natom),tprotmat(3,3)
  integer,intent(out),optional :: tpinteratom(3,natom)

  integer :: iatom,jatom,katom,i,j,k,index,tpinterindex
  integer :: nearatoms(natom),internalatom(3,natom),nearestatom,ipiv(3*natom),info,tpndim,tpnbond,tpnangle,tpndihe,tpibond,tpiangle,tpidihe
  real*8 :: internalcoor(3,natom),tpvec(3),tpvalue,tpgrad(3,natom),tpsum
  real*8 :: tpdqdr(3*natom,3*natom),tpdrdq(3*natom,3*natom),tpdvdr(3*natom),tpdvdq(3*natom),tpq(3*natom),tpr(3*natom)
  real*8 :: work(3*natom),tpdqdr2(3*natom,natom-3)
  real*8 :: tptprotmat(3,3),tpaxes(3,3),tprotaxes(3,3),tpvec2(3)

  if ( .not. allocated(twowaybonds) ) call pubmod_set_twowaybonds()

  internalcoor = 0.0d0; internalatom = 0d0; nearatoms = 0; nearatoms(1)=1
  tpdqdr = 0d0; tpdrdq = 0d0; tpr = pack(tpcoor,.true.)
  tpnbond = natom - 1; tpnangle = natom - 2; tpndihe = natom - 3
  tpibond = 0; tpiangle = 0; tpidihe = 0

  tpq(1:3) = tpcoor(1:3,1); tpq(4:5) = tpcoor(2:3,2); tpq(6) = tpcoor(3,3)
  tpdqdr(1,1) = 1.0d0; tpdqdr(2,2) = 1.0d0; tpdqdr(3,3) = 1.0d0; tpdqdr(5,4) = 1.0d0;  tpdqdr(6,5) = 1.0d0;  tpdqdr(9,6) = 1.0d0

  do iatom = 2, natom
     internalatom(1,iatom) = iatom; tpvec = 0.0d0
     call find_nearest_atoms(iatom,0,0,nearestatom); tpgrad = 0d0
     call colvar_bond(1,tpcoor,tpvalue,tpatoms=[iatom,nearestatom],tpgrad=tpgrad)
     internalatom(1,iatom)=nearestatom; internalcoor(1,iatom) = tpvalue
     if ( present(tpinteratom) ) tpinteratom(1,iatom) = nearestatom
     jatom = nearestatom; nearatoms(iatom) = jatom

     tpibond = tpibond + 1; tpinterindex = 6 + tpibond
     tpintercoor(tpinterindex) = tpvalue
     tpdqdr(:,tpinterindex) = pack(tpgrad,.true.); tpq(tpinterindex) = tpvalue

     if ( iatom >= 3 ) then
        jatom = nearestatom; call find_nearest_atoms(jatom,iatom,0,nearestatom); tpgrad = 0d0
        call colvar_angle(1,tpcoor,tpvalue,tpatoms=[iatom,jatom,nearestatom],tpgrad=tpgrad)
        internalatom(2,iatom)=nearestatom; internalcoor(2,iatom) = tpvalue*180d0/pi
        if ( present(tpinteratom) ) tpinteratom(2,iatom) = nearestatom

        tpiangle = tpiangle + 1; tpinterindex = 6 + tpnbond + tpiangle
        tpintercoor(tpinterindex) = tpvalue; tpq(tpinterindex) = tpvalue
        tpdqdr(:,tpinterindex) = pack(tpgrad,.true.)

        if ( iatom >= 4 ) then
           katom = nearestatom; call find_nearest_atoms(katom,jatom,iatom,nearestatom); tpgrad = 0d0
           call colvar_dihedral(1,tpcoor,tpvalue,tpatoms=[iatom,jatom,katom,nearestatom],tpgrad=tpgrad)
           internalatom(3,iatom)=nearestatom; internalcoor(3,iatom) = tpvalue*180d0/pi
           if ( present(tpinteratom) ) tpinteratom(3,iatom) = nearestatom

           tpidihe = tpidihe + 1; tpinterindex = 6 + tpnbond + tpnangle + tpidihe
           tpintercoor(tpinterindex) = sin(tpvalue); tpq(tpinterindex) = sin(tpvalue)
           tpdqdr(:,tpinterindex) = cos(tpvalue)*pack(tpgrad,.true.)

           tpinterindex = tpinterindex + tpndihe
           tpintercoor(tpinterindex) = cos(tpvalue)
           tpdqdr2(:,tpidihe) = -sin(tpvalue)*pack(tpgrad,.true.)
        end if
     end if

     do j = 1, 3
        do  k = j+1, 3
            if ( internalatom(k,iatom) == 0 ) exit
            if ( internalatom(j,iatom) == internalatom(k,iatom) ) call errormsg("internal atom error!",int1=iatom,int2=j,int3=k)
        end do
     end do

  end do

  if ( tpinterindex /= (4*natom-3) ) call errormsg("interal coordinate error!",int1=tpinterindex,int2=(4*natom-3))

  tpaxes(1:3,1) = [1d0,0d0,0d0]; tpaxes(1:3,2) = [0d0,1d0,0d0]; tpaxes(1:3,3) = [0d0,0d0,1d0]
  tpvec = tpcoor(1:3,2) - tpcoor(1:3,1); tprotaxes(1:3,1) = tpvec/sqrt(dot_product(tpvec,tpvec))
  tpvec2(1:3) = tpcoor(1:3,3) - tpcoor(1:3,1)
  call cross_product( tprotaxes(1:3,1), tpvec2(1:3), tpvec(1:3)); tprotaxes(1:3,3) = tpvec/sqrt(dot_product(tpvec,tpvec))
  call cross_product( tprotaxes(1:3,3), tprotaxes(1:3,1), tpvec); tprotaxes(1:3,2) = tpvec/sqrt(dot_product(tpvec,tpvec))

  tptprotmat(:,1) = [dot_product(tpaxes(:,1),tprotaxes(:,1)), dot_product(tpaxes(:,1),tprotaxes(:,2)),dot_product(tpaxes(:,1),tprotaxes(:,3))]
  tptprotmat(:,2) = [dot_product(tpaxes(:,2),tprotaxes(:,1)), dot_product(tpaxes(:,2),tprotaxes(:,2)),dot_product(tpaxes(:,2),tprotaxes(:,3))]
  tptprotmat(:,3) = [dot_product(tpaxes(:,3),tprotaxes(:,1)), dot_product(tpaxes(:,3),tprotaxes(:,2)),dot_product(tpaxes(:,3),tprotaxes(:,3))]

  tpsum = acos(tptprotmat(3,3)); tpintercoor(1) = sin(tpsum); tpintercoor(2) = cos(tpsum)
  tpsum = atan(-tptprotmat(3,1)/tptprotmat(3,2)); tpintercoor(3) = sin(tpsum); tpintercoor(4) = cos(tpsum)
  tpsum = atan(tptprotmat(1,3)/tptprotmat(2,3)); tpintercoor(5) = sin(tpsum); tpintercoor(6) = cos(tpsum)

  if ( present(tprotmat) ) tprotmat = tptprotmat
  if ( present(tprotforce) ) then
     if ( .not. present(tpforce) ) call errormsg("not input force data!")
     tprotforce = matmul(tptprotmat,tpforce)
     return
  end if

  if ( .not. present(tpforce) ) return

  print "(a)","Internal Coordinates"
  do iatom = 1, natom
     print "(i5,2x,a4,3(i5,f10.3))",iatom,name(iatom),(internalatom(i,iatom),internalcoor(i,iatom),i=1,3)
  end do

  tpdrdq = tpdqdr; tpndim = size(tpdrdq, 1)
  call DGETRF(tpndim, tpndim, tpdrdq, tpndim, ipiv, info)
  call DGETRI(tpndim, tpdrdq, tpndim, ipiv, work, tpndim, info)
  tpdvdr = pack(tpforce,.true.); tpdvdq = matmul(tpdvdr,tpdrdq)
  tpq = matmul(tpdvdq,tpdqdr); do i = 1, 3*natom; print *,"dvdr ",i,tpdvdr(i),tpq(i); end do

  tpdqdr(:,6+tpnbond+tpnangle+1:6+tpnbond+tpnangle+tpndihe) = tpdqdr2(:,1:tpndihe)
  tpdrdq = tpdqdr; tpndim = size(tpdrdq, 1)
  call DGETRF(tpndim, tpndim, tpdrdq, tpndim, ipiv, info)
  call DGETRI(tpndim, tpdrdq, tpndim, ipiv, work, tpndim, info)
  tpdvdr = pack(tpforce,.true.); tpdvdq = matmul(tpdvdr,tpdrdq)
  tpq = matmul(tpdvdq,tpdqdr); do i = 1, 3*natom; print *,"dvdr ",i,tpdvdr(i),tpq(i); end do

contains

subroutine find_nearest_atoms(firstatom,secondatom,thirdatom,nearestatom)
  integer,intent(in) :: firstatom,secondatom,thirdatom
  integer,intent(out) :: nearestatom
  integer :: iatom,index,ilist,tpnlist,tpbondedatomlist(10),inearest
  real*8 :: tpmindis,tpdis,tpvec(3)

  tpnlist = 0
  do index = twowaybondindex(firstatom)+1, twowaybondindex(firstatom+1)
     iatom = twowaybonds(index); inearest = nearatoms(iatom)
     if ( inearest /= 0 .and. iatom /= secondatom ) then
        if ( secondatom == 0 ) then
           tpnlist = tpnlist + 1; tpbondedatomlist(tpnlist) =  iatom
        else if ( inearest == firstatom .or. nearatoms(firstatom) == iatom ) then
           tpnlist = tpnlist + 1; tpbondedatomlist(tpnlist) =  iatom
        end if
     end if
  end do

  if ( tpnlist == 0 ) then

     nearestatom = 0; tpmindis = 1d10
     do iatom = 1, natom
        inearest = nearatoms(iatom); if ( inearest == 0 ) cycle
        if ( iatom == firstatom .or. iatom == secondatom .or. iatom == thirdatom) cycle

        tpvec = tpcoor(1:3,iatom) - tpcoor(1:3,firstatom)
        tpdis = sqrt(dot_product(tpvec,tpvec))
        if ( tpdis < tpmindis ) then
           nearestatom = iatom; tpmindis = tpdis
        end if

        if ( secondatom == 0 ) cycle
        tpvec = tpcoor(1:3,iatom) - tpcoor(1:3,secondatom)
        tpdis = sqrt(dot_product(tpvec,tpvec))
        if ( tpdis < tpmindis ) then
           nearestatom = iatom; tpmindis = tpdis
        end if

        if ( thirdatom == 0 ) cycle
        tpvec = tpcoor(1:3,iatom) - tpcoor(1:3,thirdatom)
        tpdis = sqrt(dot_product(tpvec,tpvec))
        if ( tpdis < tpmindis ) then
           nearestatom = iatom; tpmindis = tpdis
        end if

     end do

  else

     nearestatom = tpbondedatomlist(1)
     do ilist = 1, tpnlist
        inearest = tpbondedatomlist(ilist)
        do index = twowaybondindex(inearest)+1, twowaybondindex(inearest+1)
           iatom = twowaybonds(index)
           if ( nearatoms(iatom) /= 0 .and. iatom /= firstatom ) then
              nearestatom = inearest; return
           end if
        end do
     end do

  end if
end subroutine
end subroutine

subroutine colvar_internal_coordinates_fast(tpcoor,tpinteratom,tpintercoor,tprotmat)
  real*8,intent(in) :: tpcoor(3,natom)
  integer,intent(in) :: tpinteratom(3,natom)
  real*8,intent(out) :: tpintercoor(4*natom-3)
  real*8,intent(out) :: tprotmat(3,3)
  integer :: iatom,jatom,katom,latom,tpinterindex
  real*8 :: tpaxes(3,3),tprotaxes(3,3),tpvec(3),tpvec2(3),tpvalue

  tpinterindex = 6
  do iatom = 2, natom
     jatom = tpinteratom(1,iatom)
     call colvar_bond(1,tpcoor,tpvalue,tpatoms=[iatom,jatom])
     tpinterindex = tpinterindex + 1
     tpintercoor(tpinterindex) = tpvalue
  end do

  do iatom = 3, natom
     jatom = tpinteratom(1,iatom); katom = tpinteratom(2,iatom)
     call colvar_angle(1,tpcoor,tpvalue,tpatoms=[iatom,jatom,katom])
     tpinterindex = tpinterindex + 1
     tpintercoor(tpinterindex) = tpvalue
  end do

  do iatom = 4, natom
     jatom = tpinteratom(1,iatom); katom = tpinteratom(2,iatom); latom = tpinteratom(3,iatom)
     call colvar_dihedral(1,tpcoor,tpvalue,tpatoms=[iatom,jatom,katom,latom])
     tpinterindex = tpinterindex + 1; tpintercoor(tpinterindex) = sin(tpvalue)
     tpintercoor(tpinterindex+natom-3) = cos(tpvalue)
  end do

  tpaxes(1:3,1) = [1d0,0d0,0d0]; tpaxes(1:3,2) = [0d0,1d0,0d0]; tpaxes(1:3,3) = [0d0,0d0,1d0]
  tpvec = tpcoor(1:3,2) - tpcoor(1:3,1); tprotaxes(1:3,1) = tpvec/sqrt(dot_product(tpvec,tpvec))
  tpvec2(1:3) = tpcoor(1:3,3) - tpcoor(1:3,1)
  call cross_product( tprotaxes(1:3,1), tpvec2(1:3), tpvec(1:3)); tprotaxes(1:3,3) = tpvec/sqrt(dot_product(tpvec,tpvec))
  call cross_product( tprotaxes(1:3,3), tprotaxes(1:3,1), tpvec); tprotaxes(1:3,2) = tpvec/sqrt(dot_product(tpvec,tpvec))
  tprotmat(:,1) = [dot_product(tpaxes(:,1),tprotaxes(:,1)), dot_product(tpaxes(:,1),tprotaxes(:,2)),dot_product(tpaxes(:,1),tprotaxes(:,3))]
  tprotmat(:,2) = [dot_product(tpaxes(:,2),tprotaxes(:,1)), dot_product(tpaxes(:,2),tprotaxes(:,2)),dot_product(tpaxes(:,2),tprotaxes(:,3))]
  tprotmat(:,3) = [dot_product(tpaxes(:,3),tprotaxes(:,1)), dot_product(tpaxes(:,3),tprotaxes(:,2)),dot_product(tpaxes(:,3),tprotaxes(:,3))]
end subroutine

end module
