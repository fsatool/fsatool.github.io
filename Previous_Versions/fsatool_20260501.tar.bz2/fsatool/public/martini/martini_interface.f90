module martini_interface
    use itp_reader
    use martini
    use cgpb
    use cudacg
    use utils, only: get_vec_by_coor, m_format_print
    implicit none

    type(itp_info) :: itp_reader
    type(MartiniClass) :: martiniPotentialForce

    real*8, dimension(:,:), pointer, private :: main_force

contains

subroutine martini_initialize(tpparmdir,tpnatom,tpncst,tpnres,tpnmol,tpnbiomol)
    character(len=*),intent(in) :: tpparmdir
    integer,intent(out) :: tpnatom,tpncst,tpnres,tpnbiomol,tpnmol

    call itp_reader%init(tpparmdir)
    call martiniPotentialForce%init(itp_reader)
    tpnatom = itp_reader%atom_num
    tpncst = itp_reader%constraint_num + nvirtualsite*3
    tpnres = itp_reader%res_num
    tpnmol = cgnmol
    tpnbiomol = cgnbiomol
end subroutine

subroutine martini_set_parameters(tpicuda, tpboxvec,tpangle,tpipb,tpprintcvstep,tpcoor,tpforce,tpvel,tpcgpbmethod, &
                     tpmaxatomperbox,tpmaxnlperatom,tpcgcsttol,tpcoor_d,tpforce_d,tpvel_d)

    integer,intent(in) :: tpicuda,tpipb,tpprintcvstep,tpcgpbmethod,tpmaxatomperbox,tpmaxnlperatom
    real*8,intent(in) :: tpboxvec(3),tpangle(3),tpcgcsttol
    real*8,intent(in),target :: tpcoor(:,:),tpforce(:,:),tpvel(:,:)
    real*8,intent(in),target,device :: tpcoor_d(:,:)
    real*8,intent(out),target,device :: tpforce_d(:,:),tpvel_d(:,:)

    cgcell = tpboxvec; cgcellalpha = tpangle(1); cgcellbeta = tpangle(2); cgcellgamma = tpangle(3)
    cgipb = tpipb; cgicuda = tpicuda; cgprintcvstep = tpprintcvstep; cgpbmethod = tpcgpbmethod
    cgcoor => tpcoor; cgforce => tpforce; cgvel => tpvel; cgprecoor => tpforce

    call martiniPotentialForce%force_pointer()
    if ( cgipb > 0 ) call cgpb_initialize(martiniPotentialForce%LJ_force)

    if ( cgicuda > 0 ) then
        cgmaxatomperbox = tpmaxatomperbox; cgmaxnlperatom = tpmaxnlperatom; cgcsttol = tpcgcsttol
        cgcoor_d => tpcoor_d; cgforce_d => tpforce_d; cgvel_d => tpvel_d; cgprecoor_d => tpforce_d
        call cudacg_initialize(itp_reader)
    end if
end subroutine

subroutine martini_ccma_cpu(ifdovel)
    logical,intent(in),optional :: ifdovel

    if ( .not. present(ifdovel) ) then
       !cgprecoor => tpprecoor
       call martini_ccma_execute(itp_reader)
    else
       !cgvel => tpvel
       call martini_ccma_execute(itp_reader,ifdovel=ifdovel)
    end if
end subroutine

subroutine martini_ccma_gpu(ifdovel)
    logical,intent(in),optional :: ifdovel

    if ( .not. present(ifdovel) ) then
       !cgprecoor_d => tpprecoor_d
       call cudacg_ccma_execute()
    else
       !cgvel_d => tpvel_d
       call cudacg_ccma_execute(ifdovel=ifdovel)
    end if
end subroutine

subroutine martini_topdata(mass,resindex,atomname,resname,atommol,resmol,molindex)
    real*8,intent(out),optional :: mass(:)
    integer,intent(out),optional :: resindex(:),resmol(:),atommol(:),molindex(:)
    character(len=4),intent(out),optional :: atomname(:),resname(:)
    if ( present(mass)) mass = cgmass
    if ( present(resindex) ) resindex = cgresindex
    if ( present(atomname) ) atomname = cgname
    if ( present(resname) ) resname = cgresname
    if ( present(atommol) ) atommol = cgatommol
    if ( present(resmol) ) resmol = cgresmol
    if ( present(molindex) ) molindex = cgmolindex
end subroutine

subroutine martini_virtual_site_set_coordinate_cpu()
  if ( nvirtualsite == 0 ) return
  call virtual_site_set_coordinate(itp_reader)
end subroutine

subroutine martini_virtual_site_set_coordinate_gpu()
  if ( nvirtualsite == 0 ) return
  call cudacg_virtualsite_set_coordinate<<<(nvirtualsite-1)/32+1,32>>>()
end subroutine

subroutine martini_potforce_cpu(tppot, check, ifapplyconstraint, ifcalpot)
    real*8,intent(out) :: tppot
    logical,optional,intent(in) :: check, ifapplyconstraint, ifcalpot

    if ( present(ifcalpot) ) cgifcalpot = ifcalpot

    call martiniPotentialForce%potforce(check=check)

    tppot = martiniPotentialForce%total_potential
    if ( present(ifapplyconstraint) ) call martiniPotentialForce%constraint_bond()
end subroutine

subroutine check_force(force, force_1, string)
    real*8, dimension(:, :), pointer :: force, force_1
    character(len=*) :: string
    integer :: atom_num
    integer :: i_atom, i_coor
    integer :: out_of_tol

    real*8 :: TOL, error
    TOL = 0.1
    out_of_tol = 0

    atom_num = itp_reader%atom_num
    print *, "==== compare force per atom ====", string
    do i_atom = 1, atom_num
        ! out_of_tol = 0
        do i_coor = 1, 3
            error = abs(force(i_coor, i_atom)-force_1(i_coor, i_atom))
            if (error > TOL) then
                if (out_of_tol == 0) then
                    out_of_tol = 1
                    print *, "i_coor:"
                end if
                print *, i_coor, error
            end if
        end do
        if (out_of_tol == 1) then
            out_of_tol = 0
            print *, " ^^^ i_atom", i_atom, "============"
        end if
    end do
end subroutine

subroutine _compare_GPU_CPU()
    real*8 :: temp
    INTEGER :: number

    PRINT *, "vvv==============COMPARE===========================vvv"
    main_force = cgforce_d
    temp = cgepot_d
    CALL m_format_print("All", temp-martiniPotentialForce%total_potential, scaled_force(main_force-cgforce, cgnatom))

    cgebond = cgebond_d
    main_force = bond_force_d
    CALL m_format_print("bond", cgebond-martiniPotentialForce%bond_potential, scaled_force(main_force-martiniPotentialForce%bond_force, cgnatom))
    cgeangle1 = cgeangle1_d
    main_force = angle_force_1_d
    CALL m_format_print("angle_1", cgeangle1-martiniPotentialForce%angle_1_potential, scaled_force(main_force-martiniPotentialForce%angle_force_1, cgnatom))
    cgeangle2 = cgeangle2_d
    main_force = angle_force_2_d
    CALL m_format_print("angle_2", cgeangle2-martiniPotentialForce%angle_2_potential, scaled_force(main_force-martiniPotentialForce%angle_force_2, cgnatom))
    cgeangle10 = cgeangle10_d
    main_force = angle_force_10_d
    CALL m_format_print("angle_10", cgeangle10-martiniPotentialForce%angle_10_potential, scaled_force(main_force-martiniPotentialForce%angle_force_10, cgnatom))
    cgedihedral1 = cgedihedral1_d
    main_force = dihedral_force_1_d
    CALL m_format_print("dihedral_1", cgedihedral1-martiniPotentialForce%dihedral_1_potential, scaled_force(main_force-martiniPotentialForce%dihedral_force_1, cgnatom))
    cgedihedral2 = cgedihedral2_d
    main_force = dihedral_force_2_d
    CALL m_format_print("dihedral_2", cgedihedral2-martiniPotentialForce%dihedral_2_potential, scaled_force(main_force-martiniPotentialForce%dihedral_force_2, cgnatom))
    cgedihedral3 = cgedihedral3_d
    main_force = dihedral_force_3_d
    CALL m_format_print("dihedral_3", cgedihedral3-martiniPotentialForce%dihedral_3_potential, scaled_force(main_force-martiniPotentialForce%dihedral_force_3, cgnatom))
    cgedihedral4 = cgedihedral4_d
    main_force = dihedral_force_4_d
    CALL m_format_print("dihedral_4", cgedihedral4-martiniPotentialForce%dihedral_4_potential, scaled_force(main_force-martiniPotentialForce%dihedral_force_4, cgnatom))
    temp = cgevdw_d
    main_force = elecvdw_force_d
    CALL m_format_print("LJ_force", temp-cgevdw, scaled_force(main_force-martiniPotentialForce%LJ_force, cgnatom))
    temp = cgeelec_d
    main_force = elecvdw_force_d
    CALL m_format_print("elec_static", temp-cgeelec, scaled_force(main_force-martiniPotentialForce%LJ_force, cgnatom))
    temp = cgeself_d
    main_force = 0.0d0
    CALL m_format_print("elec_self", temp-cgeself, scaled_force(main_force, cgnatom))
    temp = cgeexclude_d
    main_force = elecS_exclude_force_d
    CALL m_format_print("elecS_exclude", temp-martiniPotentialForce%elec_exclude_potential, scaled_force(main_force-martiniPotentialForce%elecS_exclude_force, cgnatom))
end subroutine

subroutine _print_GPU_single_pointe_info()
    real*8 :: temp
    INTEGER :: number

    PRINT *, "vvv==================================================vvv"
    main_force = total_force_d
    temp = cgepot_d
    call m_format_print("All", temp, scaled_force(main_force, cgnatom))

    cgebond = cgebond_d
    main_force = bond_force_d
    CALL m_format_print("bond", cgebond, scaled_force(main_force, cgnatom))
    cgeangle1 = cgeangle1_d
    main_force = angle_force_1_d
    CALL m_format_print("angle_1", cgeangle1, scaled_force(main_force, cgnatom))
    cgeangle2 = cgeangle2_d
    main_force = angle_force_2_d
    CALL m_format_print("angle_2", cgeangle2, scaled_force(main_force, cgnatom))
    cgeangle10 = cgeangle10_d
    main_force = angle_force_10_d
    CALL m_format_print("angle_10", cgeangle10, scaled_force(main_force, cgnatom))
    cgedihedral1 = cgedihedral1_d
    main_force = dihedral_force_1_d
    CALL m_format_print("dihedral_1", cgedihedral1, scaled_force(main_force, cgnatom))
    cgedihedral2 = cgedihedral2_d
    main_force = dihedral_force_2_d
    CALL m_format_print("dihedral_2", cgedihedral2, scaled_force(main_force, cgnatom))
    cgedihedral3 = cgedihedral3_d
    main_force = dihedral_force_3_d
    CALL m_format_print("dihedral_3", cgedihedral3, scaled_force(main_force, cgnatom))
    cgedihedral4 = cgedihedral4_d
    main_force = dihedral_force_4_d
    CALL m_format_print("dihedral_4", cgedihedral4, scaled_force(main_force, cgnatom))
    temp = cgevdw_d
    main_force = elecvdw_force_d
    CALL m_format_print("LJ_force", temp, scaled_force(main_force, cgnatom))
    temp = cgeelec_d
    main_force = elecvdw_force_d
    CALL m_format_print("elec_static", temp, scaled_force(main_force, cgnatom))
    temp = cgeself_d
    main_force = elecS_exclude_force_d
    CALL m_format_print("elec_self", temp, scaled_force(main_force, cgnatom))
    temp = cgeexclude_d
    main_force = elecS_exclude_force_d
    CALL m_format_print("elecS_exclude", temp, scaled_force(main_force, cgnatom))

end subroutine

subroutine martini_potforce_gpu(tppot_d,check, ifapplyconstraint,ifcalpot_d)
    real*8,intent(inout),device :: tppot_d
    logical,optional,intent(in) :: check,ifapplyconstraint
    logical,optional,intent(in),device :: ifcalpot_d

    if ( present(ifcalpot_d) ) then
       cgifcalpot = ifcalpot_d; cgifcalpot_d = ifcalpot_d
    end if

    call cudacg_potforce(check=check)
    tppot_d = cgepot_d

    if ( present(check) ) then
       if (check .eqv. .true. ) then
          if ( .not. allocated(main_force) ) allocate(main_force(3, cgnatom))
          call _print_GPU_single_pointe_info()
          call _compare_GPU_CPU()
      end if
    end if

    if ( present(ifapplyconstraint) ) then
       call cudacg_constraint_bond<<<(ncst-1)/32+1,32>>>()
    end if
end subroutine

end module
