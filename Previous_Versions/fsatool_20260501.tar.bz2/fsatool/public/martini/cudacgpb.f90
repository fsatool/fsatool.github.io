module cudacgpb
  use itp_reader; use utils; use public; use cgpb; use sortmod
  implicit none
  logical,device :: cgifcalpot_d
  real*8,device,pointer :: cgcoor_d(:,:),cgforce_d(:,:),elecvdw_force_d(:,:),cgvel_d(:,:)
  real*8,device,allocatable :: cgcharge_d(:),cgmass_d(:)
  real*8,device :: cgevdw_d,cgeelec_d,cgtotforce_d(3),cgepot_d,evdwcorr_d
  real*8,device :: cgebond_d,cgedihedral_d,cgedihedral1_d,cgedihedral2_d,cgedihedral3_d,cgedihedral4_d
  real*8,device :: cgeangle_d,cgeangle2_d,cgeangle10_d,cgeangle1_d,cgeexclude_d
  real,device :: krf_d,crf_d,eleccoef_d,rcut_d,rcutsq_d,cgcellinv_d(3),cgcell_d(3)

  integer,device :: cgnatom_d,cgnmol_d,cgnbiomol_d
  integer,device :: cgnatomtype_d,cgnexcludepair_d
  integer,device,allocatable :: cgnonbondedparmindex_d(:), cgifformvirtualatom(:),cgatomtype_d(:)
  real,device,allocatable :: cgnonbondedparms_d(:,:)

  integer,device,private :: bimaxnexc_d,cgipb_d
  integer,device,dimension(:),allocatable,private :: cgatommol_d
  real,device,dimension(:),allocatable,private :: halfqq_d,cg_dt_inv_mass_d

  real,device,private :: cellvolume_d,hfskinsq_d
  real,device,private :: cosgamma_d,singamma_d,cosbeta_d,latticeterm1_d,latticeterm2_d,latticeterm3_d

  ! variables for direct space

  integer :: cgnblockatom
  integer,device :: cgnblockatom_d

  integer,private :: nmaxblockdirec,nblocknl,hashtable(4,4,4),cgnbox,nblockbox,cgnblockmol
  integer,device,private :: ifactivebox_d,nmaxblockdirec_d,nblockdirec_d,hashtable_d(4,4,4),cgnbox_d,maxtiles_d,maxijpairs_d
  real*8,private :: cginivir(3)
  real,device,private :: fullcut_d,fullcutsq_d,inievdwcorr_d,inicellvolume_d,cginivir_d(3)

  integer,device,dimension(:),allocatable,private :: boxatom_d,cgbinatom_d,cgmolbin_d,cgmolmol_d,cgresindex_d,cgmolindex_d,cgnatompermol_d,cgmolgroupstartatom_d,molgroupstartmol_d,cgmolgroupindex_d,boxsorted2box_d
  real,device,dimension(:),allocatable,private :: box2size_d
  real,device,dimension(:,:),allocatable,private :: boxinfo_d,boxsortedinfo_d
  real,device,dimension(:,:),allocatable,private :: cgboxcoor_d

  integer,private :: nsharedfornlbox
  integer,device,private :: maxbiexcboxnum_d
  integer,device,dimension(:),allocatable,private :: biexcludedboxlist_d,biexcludedboxlistindex_d
  integer,device,dimension(:,:),allocatable,private :: biexcludedtilelist_d,biencodedexcludedtilelist_d

  integer,private :: gexcltilenum
  integer,device,private :: gnlj32num_d,gijbinnum_d,gexcltilenum_d,ijpairsize_d
  integer,device,dimension(:),allocatable,private :: gnliboxlist_d,gnljbinlist_d
  integer,device,dimension(:,:),allocatable,target,private :: gijbinlist_d

  real,device,private :: mat_frac2car_d(3,3),mat_car2frac_d(3,3),ewaldalpha_d,inimat_frac2car_d(3,3),inimat_car2frac_d(3,3)
  real,device,private :: inicgcell_d(3)

  ! variables for npt ensemble

  integer :: cgnblocksolventmol
  real,device,private :: nptcoeff_d(3),cgpressure0_d,cgrealpressure_d,nptfactor_d,lastmat_car2frac_d(3,3)
  real*8,device,private :: cgmolekin_d(3),cgvir_d(3)
  real,device,dimension(:,:),allocatable,private :: molcom_d,molmove_d
  real,device,dimension(:),allocatable,private :: cgmolmass_d,cgmolmassinv_d


  !=======================================

  integer :: cgpbmethod,cgmaxatomperbox,cgmaxnlperatom
  real,private :: boxcrd(3,27)
  real,device,private :: boxcrd_d(3,27)

  integer,private :: bimaxencodedexcl
  integer,device,private :: cgmaxatomperbox_d,nboxvec_d(3),cgmaxnlperatom_d,bimaxencodedexcl_d,boxnlindex_d
  integer,device,dimension(:),allocatable,private :: boxboxid_d,boxnlatoms_d
  integer,device,dimension(:,:),allocatable,private :: boxnlpos_d

  integer,device,dimension(:),allocatable,private :: biencodedexcludedatomlist_d,biencodedexcludedatomlistpos_d,biencodedexcludedatomlistmax_d
  integer,device,dimension(:),allocatable,private :: boxnlboxindex_d,boxnlboxcsidx_d,boxnlboxes_d
  integer,device,dimension(:),allocatable,private :: boxatomindex_d,boxatomnum_d

  real,device,dimension(:,:),allocatable,private :: cgsavecoor_d

contains

subroutine cudacgpb_initialize()
  if ( cgpbmethod == 1 ) then
     call cudacgpb_initialize_bin()
  else if ( cgpbmethod == 2 ) then
     call cudacgpb_initialize_box()
  end if
end subroutine

subroutine cudacgpb_potforce()
  if ( cgpbmethod == 1 ) then
     call cudacgpb_potforce_bin()
  else if ( cgpbmethod == 2 ) then
     call cudacgpb_potforce_box()
  end if
end subroutine

subroutine cudacgpb_initialize_bin()
  integer :: iatom,jatom,tpi,tpnum,i,j,k,maxijpairs,maxtiles,gnlj32num,gijbinnum
  integer :: jres,ibox,jbox,ijstride,tpadnum,i1,i2,i3,j1,j2,j3,i1l,i1r,i2l,i2r,i3l,i3r,csidx,igrid,jgrid,kgrid
  integer :: tpl,tpr,ibin,imol,ires,imolgroup,iatompermol,imolbegin,imolend,molpos,atompos,realmol,binvec(3)
  integer :: iaxis,ibegin,iend,jbegin,jend,encodedtile(32),maxbiexcboxnum
  real*8 :: avgcoor(3),tpvec(3),tpatomarray(cgnatom),temp
  integer,dimension(:),allocatable :: cgbinatom,molbin,molmol,molgroupstartatom,molgroupstartmol
  logical,dimension(:),allocatable :: ifexclbox
  integer,dimension(:),allocatable :: biexcludedboxlist,biexcludedboxlistindex
  integer,dimension(:,:),allocatable :: biexcludedtilelist,biencodedexcludedtilelist

  if (procid==0) print "(a)","Divide the periodic system into bins"
  allocate(cg_dt_inv_mass_d(cgnatom)); cg_dt_inv_mass_d=cgdeltatime*timescale/cgmass

  cosgamma_d=cos(cgcellgamma); singamma_d=sin(cgcellgamma); cosbeta_d=cos(cgcellbeta)
  temp = ( cos(cgcellalpha) - cos(cgcellbeta)*cos(cgcellgamma) )/sin(cgcellgamma)
  latticeterm1_d = temp
  latticeterm2_d = sqrt(sin(cgcellbeta)**2 - temp**2)
  latticeterm3_d = cos(cgcellgamma)*temp - cos(cgcellbeta)*sin(cgcellgamma)

  hashtable(1:4,1,1) = [34,35,60,61]; hashtable(1:4,2,1) = [33,32,63,62]
  hashtable(1:4,3,1) = [30,31, 0, 1]; hashtable(1:4,4,1) = [29,28, 3, 2]

  hashtable(1:4,1,2) = [37,36,59,58]; hashtable(1:4,2,2) = [38,39,56,57]
  hashtable(1:4,3,2) = [25,24, 7, 6]; hashtable(1:4,4,2) = [26,27, 4, 5]

  hashtable(1:4,1,3) = [42,43,54,53]; hashtable(1:4,2,3) = [41,40,55,52]
  hashtable(1:4,3,3) = [20,23, 8, 9]; hashtable(1:4,4,3) = [21,22,11,10]

  hashtable(1:4,1,4) = [45,44,49,50]; hashtable(1:4,2,4) = [46,47,48,51]
  hashtable(1:4,3,4) = [19,16,15,14]; hashtable(1:4,4,4) = [18,17,12,13]

  hashtable_d = hashtable

  cgipb_d=cgipb
  cgpressure0_d=cgpressure0; nptfactor_d = isocompress*bar2pascal*cgdeltatime/cgtaup

  allocate(halfqq_d(cgnatom))
  do i=1,cgnatom; tpatomarray(i) = 0.5*cgcharge(i)**2; end do
  halfqq_d = tpatomarray

  cgnbox = (cgnatom-1)/32+1; cgnbox_d = cgnbox
  allocate(cgmolmass_d(cgnmol),cgmolmassinv_d(cgnmol),molcom_d(3,cgnmol),cgatommol_d(cgnatom))
  cgmolmass_d = cgmolmass; cgmolmassinv_d=1.0/cgmolmass; molcom_d = 0.0d0; cgatommol_d = 0
  cgatommol_d = cgatommol

  allocate(molmove_d(3,cgnmol)); molmove_d=0.0

  nblockbox = (cgnbox-1)/32+1; cgnblockmol = (cgnmol-1)/32+1; cgnblocksolventmol = (cgnmol-cgnbiomol-1)/32+1

  inievdwcorr_d = inievdwcorr; inicellvolume_d = inicellvolume; cginivir_d = cginivir
  evdwcorr_d = inievdwcorr
  inicgcell_d = inicgcell; inimat_frac2car_d=inimat_frac2car; inimat_car2frac_d=inimat_car2frac

  bimaxnexc_d = bimaxnexc; fullcut_d=rcut+skin; fullcutsq_d=fullcutsq; hfskinsq_d = hfskinsq

  ifactivebox_d=.false.; 
  mat_frac2car_d=mat_frac2car; mat_car2frac_d=mat_car2frac
  ewaldalpha_d=ewaldalpha; cellvolume_d=cellvolume

  allocate(cgmolgroupindex_d(cgnmolgroup+1)); cgmolgroupindex_d=cgmolgroupindex
  allocate(molbin(cgnmol),molmol(cgnmol)); molbin = 0; molmol = 0
  allocate(cgbinatom(cgnatom),cgbinatom_d(cgnatom)); cgbinatom = 0; cgbinatom_d = 0
  allocate(cgnatompermol_d(cgnmol)); cgnatompermol_d=cgnatompermol
  allocate(cgresindex_d(cgnres+1),cgmolindex_d(cgnmol+1)); cgresindex_d=cgresindex; cgmolindex_d=cgmolindex
  allocate(cgmolbin_d(cgnmol),cgmolmol_d(cgnmol)); cgmolbin_d = 0; cgmolmol_d = 0

  allocate(molgroupstartmol(cgnmol),molgroupstartatom(cgnmol)); molgroupstartmol=0; molgroupstartatom=0
  allocate(molgroupstartmol_d(cgnmol),cgmolgroupstartatom_d(cgnmol)); molgroupstartmol_d=0; cgmolgroupstartatom_d=0

  molpos = 0; atompos = 0
  do imolgroup=1,cgnmolgroup
     imolbegin = cgmolgroupindex(imolgroup) + 1; imolend = cgmolgroupindex(imolgroup+1)
     molgroupstartmol(imolbegin:imolend) = molpos
     molgroupstartatom(imolbegin:imolend) = atompos
     if ( imolgroup == cgnmolgroup ) exit
     molpos = molpos + imolend - imolbegin + 1
     atompos = atompos + cgnatompermol(imolbegin)*(imolend-imolbegin+1)
  end do
  cgmolgroupstartatom_d=molgroupstartatom; molgroupstartmol_d=molgroupstartmol 

  imolgroup=1
  do imol=cgmolgroupindex(imolgroup) + 1, cgmolgroupindex(imolgroup+1)
     do iatom=cgresindex(cgmolindex(imol)+1)+1, cgresindex(cgmolindex(imol+1)+1)
        cgbinatom(iatom) = iatom
     end do
  end do

  do imolgroup=1,cgnmolgroup
     imolbegin = cgmolgroupindex(imolgroup) + 1; imolend = cgmolgroupindex(imolgroup+1)

     do imol=imolbegin,imolend
        avgcoor = 0.0d0
        do ires=cgmolindex(imol)+1,cgmolindex(imol+1)
           do iatom=cgresindex(ires)+1,cgresindex(ires+1)
              avgcoor(:) = avgcoor(:) + cgcoor(:,iatom)
           end do
        end do
        avgcoor = avgcoor/dble(cgnatompermol(imol))
        do iaxis = 1,3
           tpvec(iaxis) = dot_product(avgcoor,mat_car2frac(iaxis,:))
           tpvec(iaxis) = tpvec(iaxis) - floor(tpvec(iaxis))
           if ( (tpvec(iaxis) > -1d-3) .and. (tpvec(iaxis) < 1d-3) ) tpvec(iaxis) = 1d-3
           if ( (tpvec(iaxis) > 0.999d0) .and. (tpvec(iaxis) < 1.001d0) ) tpvec(iaxis) = 0.999d0
        end do
        avgcoor = tpvec*4d0
        binvec = int(avgcoor+1)
        if ( binvec(1) < 1 .or. binvec(1) > 4 .or. &
             binvec(2) < 1 .or. binvec(2) > 4 .or. &
             binvec(3) < 1 .or. binvec(3) > 4 ) then
           print "(a,3i6)","molecule is out of the central periodic box ",imol,binvec(:)
           print "(a,3f8.3)","mol avgcoor ",avgcoor(:)
           stop
        end if

        ibin = hashtable(binvec(1),binvec(2),binvec(3))
        binvec = int( (avgcoor - real(binvec-1))*4.0 + 1 )
        ibin = (ibin-1)*64 + hashtable(binvec(1),binvec(2),binvec(3))

        molbin(imol) = ibin; molmol(imol) = imol
     end do

     call sort_by_keys(imolend-imolbegin+1,molbin(imolbegin:imolend),molmol(imolbegin:imolend))

     do imol=imolbegin, imolend
        realmol = molmol(imol)
        atompos = molgroupstartatom(imol) + (imol-molgroupstartmol(imol)-1)*cgnatompermol(imol)
        ibegin = cgresindex(cgmolindex(realmol)+1)+1; iend = cgresindex(cgmolindex(realmol+1)+1)
        do iatom=ibegin,iend
           cgbinatom(atompos + iatom - ibegin + 1) = iatom
        end do
     end do

  end do

  cgbinatom_d = cgbinatom

  allocate(cgboxcoor_d(3,cgnatom))
  call cudacgpb_set_bincoor<<<cgnblockatom,32>>>()

  allocate(boxsorted2box_d(cgnbox)); boxsorted2box_d = 0
  allocate(box2size_d(cgnbox)); box2size_d = 0.0
  allocate(boxinfo_d(7,cgnbox),boxsortedinfo_d(7,cgnbox)); boxinfo_d = 0.0; boxsortedinfo_d = 0.0

  call cudacgpb_set_box<<<(cgnbox-1)/32+1,32>>>()
  call thrustsort(box2size_d,boxsorted2box_d,cgnbox)

  allocate(biexcludedboxlistindex(cgnbox+1),biexcludedboxlistindex_d(cgnbox+1)); biexcludedboxlistindex = 0
  tpnum = 0

  allocate(ifexclbox(cgnbox)); ifexclbox = .false.

  do ibox = 1,cgnbox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,cgnatom); tpl = ibegin; tpr = iend
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = cgbiexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .true.
           tpl = min(tpl,jatom); tpr = max(tpr,jatom)
        end do
     end do
     do jbox = ibox+1,(tpr+31)/32
        if(ifexclbox(jbox)==.true.) tpnum = tpnum + 1
     end do
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = cgbiexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .false.
        end do
     end do
  end do

  gexcltilenum = cgnbox+tpnum; gexcltilenum_d = gexcltilenum
  allocate(biexcludedboxlist(cgnbox+2*tpnum),biexcludedboxlist_d(cgnbox+2*tpnum)); biexcludedboxlist = 0
  allocate(biexcludedtilelist(2,cgnbox+tpnum),biexcludedtilelist_d(2,cgnbox+tpnum)); biexcludedtilelist = 0
  allocate(biencodedexcludedtilelist(32,cgnbox+tpnum),biencodedexcludedtilelist_d(32,cgnbox+tpnum)); biencodedexcludedtilelist = 0

  tpnum = 0; maxbiexcboxnum = 0
  do ibox = 1,cgnbox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,cgnatom); tpl = ibegin; tpr = iend
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = cgbiexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .true.
           tpl = min(tpl,jatom); tpr = max(tpr,jatom)
        end do
     end do
     ifexclbox(ibox) = .true.

     do jbox = (tpl+31)/32,(tpr+31)/32
        if (ifexclbox(jbox)==.true.) then
           tpnum = tpnum + 1; biexcludedboxlist(tpnum) = jbox
        end if
     end do

     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = cgbiexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .false.
        end do
     end do
     ifexclbox(ibox) = .false.
     biexcludedboxlistindex(ibox+1) = tpnum

     i = biexcludedboxlistindex(ibox+1) - biexcludedboxlistindex(ibox)
     if ( i > maxbiexcboxnum ) maxbiexcboxnum = i
  end do
  biexcludedboxlistindex_d = biexcludedboxlistindex; biexcludedboxlist_d = biexcludedboxlist
  maxbiexcboxnum_d = maxbiexcboxnum

  do ibox = 1,cgnbox
     biexcludedtilelist(1,ibox) = ibox; biexcludedtilelist(2,ibox) = ibox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,cgnatom); encodedtile = 0
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = cgbiexcludedatomlist(j)
           if (jatom==0) cycle
           if ((jatom>=ibegin) .and. (jatom<=iend)) then
              encodedtile(iatom-ibegin+1) = ibset(encodedtile(iatom-ibegin+1),jatom-ibegin)
           end if
        end do
     end do
     biencodedexcludedtilelist(:,ibox) = encodedtile(:)
  end do

  tpnum = 0
  do ibox = 1,cgnbox
     ibegin = (ibox-1)*32+1; iend = min(ibox*32,cgnatom); tpl = ibegin; tpr = iend
     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = cgbiexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .true.
           tpl = min(tpl,jatom); tpr = max(tpr,jatom)
        end do
     end do

     do jbox = ibox+1,(tpr+31)/32
        if (ifexclbox(jbox)==.true.) then
           tpnum = tpnum + 1
           biexcludedtilelist(1,cgnbox+tpnum) = ibox; biexcludedtilelist(2,cgnbox+tpnum) = jbox
           jbegin = (jbox-1)*32+1; jend = min(jbox*32,cgnatom); encodedtile = 0
           do iatom = ibegin,iend
              do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
                 jatom = cgbiexcludedatomlist(j)
                 if (jatom==0) cycle
                 if ((jatom>=jbegin) .and. (jatom<=jend)) then
                    encodedtile(iatom-ibegin+1) = ibset(encodedtile(iatom-ibegin+1),jatom-jbegin)
                 end if
              end do
           end do
           biencodedexcludedtilelist(:,cgnbox+tpnum) = encodedtile(:)
        end if
     end do

     do iatom = ibegin,iend
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           jatom = cgbiexcludedatomlist(j)
           if (jatom==0) cycle
           jbox = (jatom+31)/32; ifexclbox(jbox) = .false.
        end do
     end do
  end do
  biexcludedtilelist_d = biexcludedtilelist; biencodedexcludedtilelist_d = biencodedexcludedtilelist

  if ( cgipb > 1 ) then
     maxtiles = cgnbox*200; maxtiles_d=maxtiles
  else
     maxtiles = cgnbox*200; maxtiles_d=maxtiles
  end if
  allocate(gnliboxlist_d(maxtiles)); gnliboxlist_d=0
  allocate(gnljbinlist_d(maxtiles*32)); gnljbinlist_d=0

  ijpairsize_d=2; maxijpairs = cgnatom*ijpairsize_d*20; maxijpairs_d=maxijpairs
  allocate(gijbinlist_d(2,maxijpairs)); gijbinlist_d=0

  nmaxblockdirec=0.8*(gexcltilenum+maxtiles+(maxijpairs-1)/32+1); nmaxblockdirec_d=nmaxblockdirec

  gnlj32num_d = 0; gijbinnum_d = 0; nsharedfornlbox = 7*32*4+2*256*4+5*4+maxbiexcboxnum*4
  call cudacgpb_set_nlbox<<<cgnbox,32,nsharedfornlbox>>>()
  call cudacgpb_check_exceedarray<<<3,1>>>()

  if ( cgipb > 1 ) then
     call cudacgpb_npt_com_biomol<<<cgnbiomol,32>>>()
     call cudacgpb_npt_com_ionwat<<<cgnblocksolventmol,32>>>()
  end if
end subroutine

subroutine cudacgpb_potforce_bin()
  integer,save :: isortstep
  real*8 :: tpvalue

  if ( ifactivebox .eqv. .true. ) then
     ifactivebox_d = .true.; isortstep = -10000
     if ( cgipb > 1 ) then
        call cudacgpb_npt_prepare_cell<<<16,1>>>()
     end if
  end if

  call cudacgpb_clear_force<<<cgnblockatom,32>>>()

  if ( ifactivebox .eqv. .false. ) ifactivebox = ifactivebox_d

  if ( ifactivebox .eqv. .true. ) then
     ifactivebox = .false.
     if ( (cgnowstep-isortstep) >= 100 ) then
        isortstep = cgnowstep
        call cudacgpb_set_molbin<<<cgnblockmol,32>>>()
        call thrustsort(cgmolbin_d,cgmolmol_d,cgmolgroupindex_d,cgnmolgroup)
        call cudacgpb_set_atombin<<<cgnblockmol,32>>>()
     end if
     call cudacgpb_set_bincoor<<<cgnblockatom,32>>>()
     call cudacgpb_set_box<<<nblockbox,32>>>()
     call thrustsort(box2size_d,boxsorted2box_d,cgnbox)
     call cudacgpb_set_nlbox<<<cgnbox,32,nsharedfornlbox>>>()
     call cudacgpb_check_exceedarray<<<3,1>>>()
  end if

  call cudacgpb_potforce_direct_bin<<<nmaxblockdirec,32>>>()
  cgnowstep = cgnowstep + 1

  if ( cgipb > 1 ) call cudacgpb_npt_vir_mol<<<cgnblockatom,32>>>()
end subroutine

attributes(global) subroutine cudacgpb_check_exceedarray()
  integer :: i
  select case (blockidx%x)
  case (1)
     if ( gnlj32num_d >= maxtiles_d ) then
        print *,"tile number exceeds the limit!",gnlj32num_d,maxtiles_d; stop
     end if
  case (2)
     if ( gijbinnum_d >= maxijpairs_d ) then
        print *,"single pair number exceeds the limit!",gijbinnum_d,maxijpairs_d; stop
     end if
  case (3)
     i = gexcltilenum_d + gnlj32num_d + (gijbinnum_d-1)/32+1; nblockdirec_d = i
     if ( i > nmaxblockdirec_d ) then
        print *,"nblockdirec exceeds the limit!",i,nmaxblockdirec_d; stop
     end if
  end select
end subroutine

attributes(global) subroutine cudacgpb_clear_force()
  integer :: iatom,i,igrid,jgrid,kgrid,ihalf
  real :: tpvec(3),insradius

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > cgnatom_d ) return

  elecvdw_force_d(:,iatom) = 0.0d0
  if ( blockidx%x == 1 .and. threadidx%x == 1 ) then

     if ( cgifcalpot_d ) then
        cgebond_d = 0d0; cgeangle2_d = 0d0; cgeangle10_d = 0d0
        cgedihedral1_d = 0d0; cgedihedral2_d = 0d0; cgedihedral3_d = 0d0; cgedihedral4_d = 0d0
        cgeelec_d = 0d0; cgevdw_d = 0d0; cgeexclude_d = 0d0; evdwcorr_d = 0d0
     end if

     cgtotforce_d=0d0

     if ( cgipb_d > 1 ) then
        tpvec(1) = inicellvolume_d/cellvolume_d
        cgvir_d = cginivir_d*tpvec(1)
        evdwcorr_d = inievdwcorr_d*tpvec(1)
        cgrealpressure_d=0.0; cgmolekin_d=0.0

        insradius = 0.5*minval(cgcell_d)
        if ( fullcut_d >= insradius ) then
           print *,"cutoff must be smaller than the radius of inscribed sphere ",insradius,fullcut_d; stop
        end if
     end if
  end if

  if ( ifactivebox_d ) return

  tpvec(:) = cgcoor_d(:,cgbinatom_d(iatom)) - cgboxcoor_d(:,iatom)
  if ( dot_product(tpvec,tpvec) > hfskinsq_d ) then
     if ( .not. ifactivebox_d ) ifactivebox_d = .true.
  end if
end subroutine

! set bin index for molecules
attributes(global) subroutine cudacgpb_set_molbin()
  integer :: cgnatomicgnmol,imol,istart,iend,iatom,binvec(3)
  real :: avgcoor(3),tpvec(3),tpvalue

  imol = (blockidx%x-1)*blockdim%x + threadidx%x; if ( (imol <= cgnbiomol_d) .or. (imol > cgnmol_d) ) return

  istart = cgresindex_d(cgmolindex_d(imol)+1)+1; iend = cgresindex_d(cgmolindex_d(imol+1)+1)
  avgcoor(1) = sum(cgcoor_d(1,istart:iend))
  avgcoor(2) = sum(cgcoor_d(2,istart:iend))
  avgcoor(3) = sum(cgcoor_d(3,istart:iend))
  avgcoor = avgcoor/dble(cgnatompermol_d(imol))

  tpvec = avgcoor*cgcellinv_d

  do istart = 1, 3
     avgcoor(istart) = 4.0*( tpvec(istart) - floor(tpvec(istart)) )
     binvec(istart) = int(avgcoor(istart)+1)
     if ( binvec(istart) < 1 ) then
        binvec(istart)=1
     else if ( binvec(istart) > 4 ) then
        binvec(istart)=4
     end if
  end do

  iatom = hashtable_d(binvec(1),binvec(2),binvec(3))
  binvec = int( (avgcoor - real(binvec-1))*4.0 + 1 )
  do istart = 1, 3
     if ( binvec(istart) < 1 ) then
        binvec(istart)=1
     else if ( binvec(istart) > 4 ) then
        binvec(istart)=4
     end if
  end do
  iatom = iatom*64 + hashtable_d(binvec(1),binvec(2),binvec(3))

  cgmolbin_d(imol) = iatom; cgmolmol_d(imol) = imol
end subroutine

! set bin index for atoms
attributes(global) subroutine cudacgpb_set_atombin()
  integer :: imol,realmol,ibegin,iend,iatom,atompos

  imol = (blockidx%x-1)*blockdim%x + threadidx%x; if ( (imol <= cgnbiomol_d) .or. (imol > cgnmol_d) ) return
  realmol = cgmolmol_d(imol)
  atompos = cgmolgroupstartatom_d(imol) + (imol-molgroupstartmol_d(imol)-1)*cgnatompermol_d(imol)
  ibegin = cgresindex_d(cgmolindex_d(realmol)+1)+1; iend = cgresindex_d(cgmolindex_d(realmol+1)+1)

  atompos = atompos - ibegin + 1
  do iatom=ibegin,iend
     cgbinatom_d(atompos + iatom) = iatom
  end do
end subroutine

attributes(global) subroutine cudacgpb_potforce_compute_global_force()
  integer :: index,iatom
  real*8 :: tpx,tpy,tpz,tpvalue

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x; tpx = 0.0; tpy = 0.0; tpz = 0.0

  if ( iatom <= cgnatom_d ) then
     tpx = elecvdw_force_d(1,iatom); tpy = elecvdw_force_d(2,iatom); tpz = elecvdw_force_d(3,iatom)
  end if

  index = 1
  do while (index<=16)
     tpvalue = __shfl_xor(tpx,index); tpx = tpx + tpvalue
     tpvalue = __shfl_xor(tpy,index); tpy = tpy + tpvalue
     tpvalue = __shfl_xor(tpz,index); tpz = tpz + tpvalue
     index = index*2
  end do
  if ( threadidx%x == 1 ) then
     tpvalue = atomicadd(cgtotforce_d(1),tpx)
     tpvalue = atomicadd(cgtotforce_d(2),tpy)
     tpvalue = atomicadd(cgtotforce_d(3),tpz)
  end if
end subroutine

attributes(global) subroutine cudacgpb_potforce_remove_global_force()
  integer :: iatom
  iatom = (blockidx%x - 1)*blockdim%x + threadidx%x; if ( iatom > cgnatom_d ) return
  elecvdw_force_d(1:3,iatom) = elecvdw_force_d(1:3,iatom) - cgtotforce_d(1:3)/real(cgnatom_d)
end subroutine

attributes(global) subroutine cudacgpb_set_bincoor()
  integer :: ibin
  ibin=(blockidx%x-1)*blockdim%x+threadidx%x; if ( ibin > cgnatom_d ) return
  cgboxcoor_d(:,ibin) = cgcoor_d(:,cgbinatom_d(ibin))
  if ( blockidx%x==1 .and. threadidx%x==1 ) then
     gnlj32num_d=0; gijbinnum_d=0; ifactivebox_d=.false.
  end if
end subroutine

attributes(global) subroutine cudacgpb_set_box()
  integer :: ibox,ibin,ibegin,iend
  real :: minvec(3),maxvec(3),ctrvec(3),tpvec(3),dmax,cellvec(3),cellvecinv(3)

  ibox = (blockidx%x-1)*blockdim%x + threadidx%x
  ibegin = (ibox-1)*32+1; iend = min(ibox*32,cgnatom_d)

  cellvec=cgcell_d; cellvecinv=cgcellinv_d

  if (ibegin <= cgnatom_d) then
     tpvec = cgboxcoor_d(1:3,ibegin)
     tpvec = tpvec - floor(tpvec*cellvecinv)*cellvec

     minvec = tpvec; maxvec = tpvec; ctrvec = tpvec
     do ibin = ibegin+1,iend
        tpvec = cgboxcoor_d(1:3,ibin)
        tpvec = tpvec - floor((tpvec-ctrvec)*cellvecinv+0.5)*cellvec
        minvec = min(minvec,tpvec); maxvec = max(maxvec,tpvec); ctrvec = (minvec+maxvec)*0.5
     end do

     boxinfo_d(1:3,ibox) = ctrvec; boxinfo_d(4:6,ibox) = (maxvec-minvec)*0.5
     box2size_d(ibox) = sum(maxvec - minvec)*0.5

     dmax = 0.0
     do ibin = ibegin,iend
        tpvec = cgboxcoor_d(1:3,ibin) - ctrvec
        tpvec = tpvec - floor(tpvec*cellvecinv+0.5)*cellvec
        dmax = max(dmax,dot_product(tpvec,tpvec))
     end do
     boxsorted2box_d(ibox) = ibox; boxinfo_d(7,ibox) = sqrt(dmax)
  end if
end subroutine

attributes(device) subroutine cudacgpb_set_ijbin(ibox,nljbinlist,nlipacklist,nlistidx,ifclearup)
  integer,intent(in) :: ibox
  integer,intent(inout) :: nljbinlist(256),nlipacklist(256),nlistidx
  logical,intent(in) :: ifclearup
  integer,shared :: gnlj32num,tpnlistidx
  integer :: nlj32num,ithread,idx,ijnum,ipack,jbegin,jbinloop,i,jbin,tilejbin,votetilejbin

  ithread = threadidx%x
  if ( nlistidx > 32 ) then

     ijnum = 0; jbegin = 0; i = ijpairsize_d
     do jbinloop = ithread, nlistidx, 32
        idx = __popc(nlipacklist(jbinloop))
        if ( idx <= i ) ijnum = ijnum + idx
     end do
   
     i = 1
     do while ( i <= 16 )
        idx = __shfl_up(ijnum,i)
        if ( ithread > i ) ijnum = ijnum + idx
        i = i*2
     end do
   
     if ( ithread == 32 ) then
        tpnlistidx = 0
        idx = atomicadd(gijbinnum_d,ijnum)
     end if

     idx = __shfl(idx,32)
   
     i = __shfl_up(ijnum,1)
     if ( ithread > 1 ) idx = idx + i
   
     jbegin = 0
     do while (jbegin<nlistidx)
        jbinloop = jbegin + ithread; tilejbin = 0
        if (jbinloop<=nlistidx) then
   
           jbin = nljbinlist(jbinloop)  
           ipack = nlipacklist(jbinloop)
           i = __popc(ipack)            
   
           if ( i > ijpairsize_d ) then
   
              tilejbin = 1  
   
           else
   
              i = (ibox-1)*32
              do while ( ipack /= 0 )
                 idx = idx + 1
                 gijbinlist_d(1:2,idx) = [ i +__ffs(ipack), jbin ]
                 ipack = ibclr(ipack,__ffs(ipack)-1)
              end do
   
           end if
        end if
   
        votetilejbin = ballot(tilejbin)
        if (tilejbin/=0) then
           i = __popc(iand(votetilejbin,ior(ishft(1,ithread-1),ishft(1,ithread-1)-1)))
           nljbinlist(tpnlistidx+i) = jbin
           nlipacklist(tpnlistidx+i) = ipack
        end if
        if ( ithread == 1 ) tpnlistidx = tpnlistidx + __popc(votetilejbin)
        jbegin = jbegin + 32
     end do
     if ( ithread == 1 ) nlistidx = tpnlistidx
     call syncthreads()
  end if

  if ( ifclearup .eqv. .false. ) then

     nlj32num = nlistidx/32
     if (ithread==1) then
        gnlj32num = atomicadd(gnlj32num_d,nlj32num)
        nlistidx = nlistidx - nlj32num*32
     end if
     call syncthreads()
     if ( (gnlj32num+32) > maxtiles_d ) then
        print *,"maxtiles is too small!"; stop
     end if
     do i=ithread,nlj32num,32
        gnliboxlist_d(gnlj32num+i) = ibox
     end do
     ijnum = gnlj32num*32
     do i = 1,nlj32num
        idx = (i-1)*32+ithread
        gnljbinlist_d(ijnum+idx) = nljbinlist(idx)
     end do
     if ( ithread <= nlistidx ) then
        idx = nlj32num*32+ithread
        nljbinlist(ithread) = nljbinlist(idx)
        nlipacklist(ithread) = nlipacklist(idx)
     end if

  else if ( nlistidx > 0 ) then

     nlj32num = (nlistidx+31)/32
     if (ithread==1) then
        gnlj32num = atomicadd(gnlj32num_d,nlj32num)
     end if
     call syncthreads()
     if ( (gnlj32num+32) > maxtiles_d ) then
        print *,"maxtiles is too small!"; stop
     end if
     do i=ithread,nlj32num,32
        gnliboxlist_d(gnlj32num+i) = ibox
     end do
     ijnum = gnlj32num*32
     do i = 1,nlj32num
        idx = (i-1)*32+ithread
        if ( idx <= nlistidx ) then
           gnljbinlist_d(ijnum+idx) = nljbinlist(idx)
        else
           gnljbinlist_d(ijnum+idx) = 0
        end if
     end do

  end if

end subroutine

attributes(global) subroutine cudacgpb_set_nlbox()
  integer,shared :: nljbinlist(256),nlipacklist(256),nlistidx
  integer,shared :: biexclbox(maxbiexcboxnum_d),biexclboxpos,biexclboxnum
  real,shared :: ibincoor(3,32),jboxctr(3,32),jboxsize(32)
  integer :: ithread,ibox,jbox,jbegin,votenlbox,ibin,jbin,votenlibin,votenljbin
  integer :: ifnlbox,nlbin,idx,inum,cgnatom,cgnbox
  real :: iboxctr(3),iboxsizevec(3),iboxsize,dcoor(3),jbincoor(3),cellvec(3),cellvecinv(3),cellhalf(3),fullcutsq,fullcut
  logical :: ifvalidatom

  ! each block handles one box (32 atoms
  ithread=threadidx%x; ibox = boxsorted2box_d(blockidx%x)
  if (ithread==1) then
     biexclboxpos = biexcludedboxlistindex_d(ibox)
     biexclboxnum = biexcludedboxlistindex_d(ibox+1)-biexclboxpos
  end if
  call syncthreads()
  do inum = ithread,biexclboxnum,32
     biexclbox(inum) = biexcludedboxlist_d(biexclboxpos+inum)
  end do

  fullcut=fullcut_d; fullcutsq=fullcutsq_d; cgnatom=cgnatom_d; cgnbox=cgnbox_d
  cellvec=cgcell_d; cellvecinv=cgcellinv_d
  cellhalf = 0.5*cellvec - fullcut

  ibin = (ibox-1)*32+ithread; ifvalidatom=.false.
  if ( ibin <= cgnatom ) then
     ifvalidatom=.true.; ibincoor(:,ithread) = cgboxcoor_d(:,ibin)
  end if

  iboxctr(1:3) = boxinfo_d(1:3,ibox)

  iboxsizevec(1:3) = boxinfo_d(4:6,ibox); iboxsize = boxinfo_d(7,ibox)
  jbegin = blockidx%x; nlistidx = 0

  do while (jbegin<cgnbox)
    
     inum = jbegin+ithread; ifnlbox = 0
     if ( inum <= cgnbox ) then
        jbox = boxsorted2box_d(inum)

        do inum = 1,biexclboxnum
           if ( biexclbox(inum) == jbox ) goto 101
        end do

        jboxctr(1:3,ithread) = boxinfo_d(1:3,jbox); jboxsize(ithread) = fullcut+boxinfo_d(7,jbox)

        ifnlbox = 1 
        jbincoor(1) = iboxsizevec(1) + boxinfo_d(4,jbox)
        if ( jbincoor(1) > cellhalf(1) ) goto 101
        jbincoor(2) = iboxsizevec(2) + boxinfo_d(5,jbox)
        if ( jbincoor(2) > cellhalf(2) ) goto 101
        jbincoor(3) = iboxsizevec(3) + boxinfo_d(6,jbox)
        if ( jbincoor(3) > cellhalf(3) ) goto 101

        dcoor(1:3) = iboxctr(1:3) - jboxctr(1:3,ithread)
        dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec

        ifnlbox = 0 
        if ( dot_product(dcoor,dcoor) > (iboxsize+jboxsize(ithread))**2 ) goto 101

        dcoor = max(0.0,abs(dcoor)-jbincoor)
        if ( dot_product(dcoor,dcoor) > fullcutsq ) goto 101

        ifnlbox = 1
     end if
101 continue

     votenlbox = ballot(ifnlbox)

     do while (votenlbox/=0)

        inum = __ffs(votenlbox)
        votenlbox = ibclr(votenlbox,inum-1)
        jbox = boxsorted2box_d(jbegin+inum)

        nlbin = 0
        if ( ifvalidatom ) then
           dcoor = ibincoor(1:3,ithread)-jboxctr(1:3,inum)
           dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
           if ( dot_product(dcoor,dcoor) < jboxsize(inum)**2 ) nlbin = 1
        end if

        votenlibin = ballot(nlbin)

        if (votenlibin/=0) then

           jbin = (jbox-1)*32+ithread; nlbin = 0

           if (jbin<=cgnatom) then
              jbincoor = cgboxcoor_d(1:3,jbin)
              do while ( votenlibin /= 0 )
                 inum = __ffs(votenlibin)
                 dcoor = ibincoor(1:3,inum) - jbincoor
                 dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
                 if ( dot_product(dcoor,dcoor) < fullcutsq ) nlbin = ibset(nlbin,inum-1)
                 votenlibin = ibclr(votenlibin,inum-1)
              end do
           end if

           votenljbin = ballot(nlbin)

           if (nlbin/=0) then
              idx = nlistidx + __popc(iand(votenljbin,ior(ishft(1,ithread-1),ishft(1,ithread-1)-1)))
              nljbinlist(idx) = jbin; nlipacklist(idx) = nlbin
           end if

           if ( ithread == 1 ) nlistidx = nlistidx + __popc(votenljbin)
           call syncthreads()

           if ( nlistidx + 32 > 256 ) then
              call cudacgpb_set_ijbin(ibox,nljbinlist,nlipacklist,nlistidx, ifclearup=.false.)
           end if
        end if
     end do
     jbegin = jbegin + 32
  end do

  call syncthreads()
  call cudacgpb_set_ijbin(ibox,nljbinlist,nlipacklist,nlistidx,ifclearup=.true.)

end subroutine

attributes(global) subroutine cudacgpb_potforce_direct_bin()
  integer :: iblock

  iblock=blockidx%x; if ( iblock > nblockdirec_d ) return
  if ( iblock <= cgnbox_d ) then
     call cudacgpb_potforce_selfexcl(iblock)
  else
     if ( iblock <= gexcltilenum_d ) then
        call cudacgpb_potforce_interexcl(iblock)
     else
        iblock = iblock - gexcltilenum_d
        if ( iblock <= gnlj32num_d ) then
           call cudacgpb_potforce_tile(iblock)
        else
           iblock = iblock - gnlj32num_d
           call cudacgpb_potforce_ijbin(iblock)
        end if
     end if
  end if
end subroutine

attributes(device) subroutine cudacgpb_potforce_selfexcl(iblock)
  integer :: cgipb,cgnatom,ithread,iblock,iexcl,ibin,jbin,iatom,jloop,inext
  real :: rcutsqinv,cellvec(3),cellvecinv(3)
  real :: icoor(3),jcoor(3),dcoor(3),ifrc(3),jfrc(3),icharge,jcharge
  real :: dissqinv,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  logical :: ifcalpot
  integer :: tpi,itype,jtype
  real :: tpexc,eleccoef,krf,crf,sigmasq,eps4,coef2

  rcutsqinv=1.0/rcutsq_d; ifcalpot=cgifcalpot_d; cellvec=cgcell_d; cellvecinv=cgcellinv_d
  cgnatom = cgnatom_d; cgipb=cgipb_d
  eleccoef=eleccoef_d; krf = krf_d; crf = crf_d

  if ( cgipb_d > 1 ) vir=0.0

  ithread=threadidx%x; inext = ithread+1
  iexcl = ishftc(biencodedexcludedtilelist_d(ithread,iblock),-ithread)
  ibin = (iblock-1)*32+ithread; jbin=ibin
  if ( ibin <= cgnatom ) then
     iatom = cgbinatom_d(ibin); icharge = cgcharge_d(iatom)
     icoor(1:3) = cgcoor_d(1:3,iatom); itype = cgatomtype_d(iatom)
     jcharge = icharge; jcoor = icoor; jtype = itype
     itype = cgnatomtype_d*(itype - 1)
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpexc = 0.0
  end if
  ifrc = 0.0; jfrc = 0.0

  do jloop = 1, 16

     jbin = __shfl(jbin,inext)

     jcharge = __shfl(jcharge,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jtype = __shfl(jtype,inext)

     if ( ibin <= cgnatom ) then
     if ( jbin <= cgnatom ) then
     if ( ithread <= 16 .or. jloop < 16  ) then

         dcoor = icoor - jcoor
         dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
         dissqinv = 1.0/dot_product(dcoor,dcoor)

         if ( dissqinv > rcutsqinv ) then

            tpfrccoef = eleccoef*icharge*jcharge

            if (btest(iexcl,0)) then

               if ( ifcalpot ) tpexc = tpexc + tpfrccoef * (krf/dissqinv - crf)
               tpfrccoef = tpfrccoef * krf * 2.0

            else

               if ( ifcalpot ) tpelec = tpelec + tpfrccoef * (sqrt(dissqinv) + krf/dissqinv - crf)

               tpi = itype + jtype
               tpi = cgnonbondedparmindex_d(tpi)
               sigmasq = cgnonbondedparms_d(1,tpi) ! sigma*sigma
               eps4 = cgnonbondedparms_d(2,tpi)

               coef1 = sigmasq*rcutsqinv; coef1 = coef1*coef1*coef1
               coef2 = sigmasq*dissqinv; coef2 = coef2*coef2*coef2
               if ( ifcalpot ) tpvdw = tpvdw + eps4*(coef2*(coef2 - 1.0) - coef1*(coef1 - 1.0))
               tpfrccoef = tpfrccoef * (-sqrt(dissqinv)*dissqinv + 2.0 * krf) - (eps4*coef2*(12.0*coef2 - 6.0))*dissqinv

            end if

            if ( cgipb > 1 ) then
               vir(:) = vir(:) - dcoor(:)*dcoor(:)*tpfrccoef
            end if
            dcoor = dcoor*tpfrccoef
            ifrc = ifrc - dcoor(:)
            jfrc = jfrc + dcoor(:)

         end if

     end if; end if; end if

     iexcl = ishft(iexcl,-1)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)

  end do

  inext = ithread - 17
  jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
  if ( ibin <= cgnatom ) then
     coef1 = atomicadd(elecvdw_force_d(1,iatom),dble(ifrc(1)+jfrc(1)))
     coef1 = atomicadd(elecvdw_force_d(2,iatom),dble(ifrc(2)+jfrc(2)))
     coef1 = atomicadd(elecvdw_force_d(3,iatom),dble(ifrc(3)+jfrc(3)))
  end if

  if ( cgipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(cgvir_d(1),dble(vir(1)))
        coef1 = atomicadd(cgvir_d(2),dble(vir(2)))
        coef1 = atomicadd(cgvir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpexc,jloop); tpexc = tpexc + coef1
     jloop = jloop*2
  end do
  if (ithread==1) then
     coef1 = atomicadd(cgeelec_d,dble(tpelec))
     coef1 = atomicadd(cgevdw_d,dble(tpvdw))
     coef1 = atomicadd(cgeexclude_d,dble(tpexc))
  end if
end subroutine

attributes(device) subroutine cudacgpb_potforce_interexcl(iblock)
  integer :: cgipb,cgnatom,ithread,iblock,ibox,jbox,iexcl,iatom,jatom,jloop,inext
  real :: rcutsqinv,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),ifrc(3),jfrc(3),icharge,jcharge
  real :: dissqinv,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  logical :: ifcalpot
  integer :: tpi,itype,jtype
  real :: tpexc,eleccoef,krf,crf,sigmasq,eps4,coef2

  rcutsqinv=1.0/rcutsq_d; ifcalpot=cgifcalpot_d; cellvec=cgcell_d; cellvecinv=cgcellinv_d
  cgnatom = cgnatom_d; ewaldalpha = ewaldalpha_d; cgipb=cgipb_d
  eleccoef=eleccoef_d; krf = krf_d; crf = crf_d

  if ( cgipb > 1 ) vir=0.0

  ithread=threadidx%x; inext = ithread+1

  ibox = biexcludedtilelist_d(1,iblock); jbox = biexcludedtilelist_d(2,iblock)
  iexcl = ishftc(biencodedexcludedtilelist_d(ithread,iblock),-ithread+1)

  iatom = (ibox-1)*32+ithread
  if ( iatom <= cgnatom ) then
     iatom = cgbinatom_d(iatom); icharge = cgcharge_d(iatom)
     icoor(1:3) = cgcoor_d(1:3,iatom)
     itype = cgnatomtype_d*(cgatomtype_d(iatom) - 1)
  end if

  jatom = (jbox-1)*32+ithread
  if ( jatom <= cgnatom ) then
     jatom = cgbinatom_d(jatom); jcharge = cgcharge_d(jatom)
     jcoor(1:3) = cgcoor_d(1:3,jatom)
     jtype = cgatomtype_d(jatom)
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0; tpexc = 0.0
  end if
  ifrc = 0.0; jfrc = 0.0

  do jloop = 1,32

     if ( iatom <= cgnatom ) then
     if ( jatom <= cgnatom ) then

     dcoor = icoor - jcoor
     dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
     dissqinv = 1.0/dot_product(dcoor,dcoor)

     if ( dissqinv > rcutsqinv ) then

            tpfrccoef = eleccoef*icharge*jcharge

            if (btest(iexcl,0)) then

               if ( ifcalpot ) tpexc = tpexc + tpfrccoef * (krf / dissqinv - crf)
               tpfrccoef = tpfrccoef * krf * 2.0

            else

               if ( ifcalpot ) tpelec = tpelec + tpfrccoef * (sqrt(dissqinv) + krf / dissqinv - crf)

               tpi = itype + jtype
               tpi = cgnonbondedparmindex_d(tpi)
               sigmasq = cgnonbondedparms_d(1,tpi)
               eps4 = cgnonbondedparms_d(2,tpi)

               coef1 = sigmasq*rcutsqinv; coef1 = coef1*coef1*coef1
               coef2 = sigmasq*dissqinv; coef2 = coef2*coef2*coef2
               if ( ifcalpot ) tpvdw = tpvdw + eps4*(coef2*(coef2 - 1.0) - coef1*(coef1 - 1.0))
               tpfrccoef = tpfrccoef * (-sqrt(dissqinv)*dissqinv + 2.0 * krf) - (eps4*coef2*(12.0*coef2 - 6.0))*dissqinv

            end if

            if ( cgipb > 1 ) then
               vir(:) = vir(:) - dcoor(:)*dcoor(:)*tpfrccoef
            end if
            dcoor = dcoor*tpfrccoef
            ifrc = ifrc - dcoor(:)
            jfrc = jfrc + dcoor(:)

     end if

     end if; end if

     iexcl = ishft(iexcl,-1); jcharge = __shfl(jcharge,inext); jatom = __shfl(jatom,inext)

     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
     jtype = __shfl(jtype,inext)
  end do

  if ( iatom <= cgnatom ) then
     coef1 = atomicadd(elecvdw_force_d(1,iatom),dble(ifrc(1)))
     coef1 = atomicadd(elecvdw_force_d(2,iatom),dble(ifrc(2)))
     coef1 = atomicadd(elecvdw_force_d(3,iatom),dble(ifrc(3)))
  end if
  if ( jatom <= cgnatom ) then
     coef1 = atomicadd(elecvdw_force_d(1,jatom),dble(jfrc(1)))
     coef1 = atomicadd(elecvdw_force_d(2,jatom),dble(jfrc(2)))
     coef1 = atomicadd(elecvdw_force_d(3,jatom),dble(jfrc(3)))
  end if

  if ( cgipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(cgvir_d(1),dble(vir(1)))
        coef1 = atomicadd(cgvir_d(2),dble(vir(2)))
        coef1 = atomicadd(cgvir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     coef1 = __shfl_xor(tpexc,jloop); tpexc = tpexc + coef1
     jloop = jloop*2
  end do

  if (ithread==1) then
     coef1 = atomicadd(cgeelec_d,dble(tpelec))
     coef1 = atomicadd(cgevdw_d,dble(tpvdw))
     coef1 = atomicadd(cgeexclude_d,dble(tpexc))
  end if
end subroutine

attributes(device) subroutine cudacgpb_potforce_tile(iblock)
  integer :: cgipb,cgnatom,ithread,iblock,ibox,iatom,jatom,jloop,inext
  real :: rcutsqinv,cellvec(3),cellvecinv(3),ewaldalpha
  real :: icoor(3),jcoor(3),dcoor(3),icharge,jcharge,ifrc(3),jfrc(3)
  real :: dissqinv,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  logical :: ifcalpot
  integer :: tpi,itype,jtype
  real :: eleccoef,krf,crf,sigmasq,eps4,coef2

  rcutsqinv=1.0/rcutsq_d; ifcalpot=cgifcalpot_d; cellvec=cgcell_d; cellvecinv=cgcellinv_d
  cgnatom = cgnatom_d; ewaldalpha = ewaldalpha_d; cgipb=cgipb_d
  eleccoef=eleccoef_d; krf = krf_d; crf = crf_d
  if ( cgipb > 1 ) vir=0.0

  ithread=threadidx%x; ibox=gnliboxlist_d(iblock); iatom = (ibox-1)*32+ithread

  if ( iatom <= cgnatom ) then
     iatom = cgbinatom_d(iatom); icharge = cgcharge_d(iatom)
     icoor(1:3) = cgcoor_d(1:3,iatom); inext = ithread+1
     itype = cgnatomtype_d*(cgatomtype_d(iatom) - 1)
  end if

  jatom = gnljbinlist_d((iblock-1)*32+ithread)
  if ( jatom > 0 ) then
     jatom = cgbinatom_d(jatom); jcharge = cgcharge_d(jatom)
     jcoor(1:3) = cgcoor_d(1:3,jatom)
     jtype = cgatomtype_d(jatom)
  end if

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0
  end if
  ifrc=0.0; jfrc=0.0 
  do jloop = 1,32
     if ( iatom <= cgnatom ) then
     if ( jatom /= 0 ) then

        dcoor = icoor - jcoor
        dcoor = dcoor - floor(dcoor*cellvecinv+0.5)*cellvec
        dissqinv = 1.0/dot_product(dcoor,dcoor)

        if ( dissqinv > rcutsqinv ) then

            tpfrccoef = eleccoef*icharge*jcharge
            if ( ifcalpot ) tpelec = tpelec + tpfrccoef * (sqrt(dissqinv) + krf / dissqinv - crf)

            tpi = itype + jtype
            tpi = cgnonbondedparmindex_d(tpi)
            sigmasq = cgnonbondedparms_d(1,tpi)
            eps4 = cgnonbondedparms_d(2,tpi)
            coef1 = sigmasq*rcutsqinv; coef1 = coef1*coef1*coef1
            coef2 = sigmasq*dissqinv; coef2 = coef2*coef2*coef2
            if ( ifcalpot ) tpvdw = tpvdw + eps4*(coef2*(coef2 - 1.0) - coef1*(coef1 - 1.0))
            tpfrccoef = tpfrccoef * (-sqrt(dissqinv)*dissqinv + 2.0 * krf) - (eps4*coef2*(12.0*coef2 - 6.0))*dissqinv

            if ( cgipb > 1 ) then
               vir(:) = vir(:) - dcoor(:)*dcoor(:)*tpfrccoef
            end if
            dcoor = dcoor*tpfrccoef
            ifrc = ifrc - dcoor(:)
            jfrc = jfrc + dcoor(:)

        end if

     end if; end if

     jcharge = __shfl(jcharge,inext); jatom = __shfl(jatom,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)
     jtype = __shfl(jtype,inext)

  end do

  if ( iatom <= cgnatom ) then
     coef1 = atomicadd(elecvdw_force_d(1,iatom),dble(ifrc(1)))
     coef1 = atomicadd(elecvdw_force_d(2,iatom),dble(ifrc(2)))
     coef1 = atomicadd(elecvdw_force_d(3,iatom),dble(ifrc(3)))
  end if
  if ( jatom > 0 .and. jatom <= cgnatom ) then
     coef1 = atomicadd(elecvdw_force_d(1,jatom),dble(jfrc(1)))
     coef1 = atomicadd(elecvdw_force_d(2,jatom),dble(jfrc(2)))
     coef1 = atomicadd(elecvdw_force_d(3,jatom),dble(jfrc(3)))
  end if

  if ( cgipb > 1 ) then
     jloop = 1
     do while (jloop<=16)
        coef1 = __shfl_xor(vir(1),jloop); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),jloop); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),jloop); vir(3) = vir(3) + coef1
        jloop = jloop*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(cgvir_d(1),dble(vir(1)))
        coef1 = atomicadd(cgvir_d(2),dble(vir(2)))
        coef1 = atomicadd(cgvir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  jloop = 1
  do while (jloop<=16)
     coef1 = __shfl_xor(tpelec,jloop); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,jloop); tpvdw = tpvdw + coef1
     jloop = jloop*2
  end do
  if (ithread==1) then
     coef1 = atomicadd(cgeelec_d,dble(tpelec))
     coef1 = atomicadd(cgevdw_d,dble(tpvdw))
  end if
end subroutine

attributes(device) subroutine cudacgpb_potforce_ijbin(iblock)
  integer :: irec,iatom,jatom,iblock
  real :: dcoor(3),dissqinv,dissq,tpelec,tpvdw,tpfrccoef,coef1,vir(3)
  logical :: ifcalpot,cgipb
  integer :: tpi
  real :: eleccoef,krf,crf,sigmasq,eps4,coef2

  ifcalpot = cgifcalpot_d; cgipb = cgipb_d
  eleccoef=eleccoef_d; krf = krf_d; crf = crf_d

  if ( ifcalpot ) then
     tpelec = 0.0; tpvdw = 0.0
  end if
  if ( cgipb > 1 ) vir = 0.0

  irec = (iblock-1)*blockdim%x+threadidx%x

  if ( irec <= gijbinnum_d ) then

     iatom = cgbinatom_d(gijbinlist_d(1,irec)); jatom = cgbinatom_d(gijbinlist_d(2,irec))

     dcoor = cgcoor_d(1:3,iatom) - cgcoor_d(1:3,jatom)
     dcoor = dcoor - floor(dcoor*cgcellinv_d+0.5)*cgcell_d
     dissq = dot_product(dcoor,dcoor)

     if ( dissq <= rcutsq_d ) then

        dissqinv=1.0/dissq

        tpfrccoef = eleccoef*cgcharge_d(iatom)*cgcharge_d(jatom)
        if ( ifcalpot ) tpelec = tpelec + tpfrccoef * (sqrt(dissqinv) + krf * dissq - crf)

        tpi = cgnatomtype_d*(cgatomtype_d(iatom) - 1) + cgatomtype_d(jatom)
        tpi = cgnonbondedparmindex_d(tpi)
        sigmasq = cgnonbondedparms_d(1,tpi)
        eps4 = cgnonbondedparms_d(2,tpi)
        coef1 = sigmasq/rcutsq_d; coef1 = coef1*coef1*coef1
        coef2 = sigmasq*dissqinv; coef2 = coef2*coef2*coef2
        if ( ifcalpot ) tpvdw = tpvdw + eps4*(coef2*(coef2 - 1.0) - coef1*(coef1 - 1.0))
        tpfrccoef = tpfrccoef * (-sqrt(dissqinv)*dissqinv + 2.0 * krf) - (eps4*coef2*(12.0*coef2 - 6.0))*dissqinv

        if ( cgipb > 1 ) then
           vir(:) = - dcoor(:)*dcoor(:)*tpfrccoef
        end if
        dcoor = dcoor*tpfrccoef

        coef1 = atomicadd(elecvdw_force_d(1,iatom),dble(-dcoor(1)))
        coef1 = atomicadd(elecvdw_force_d(2,iatom),dble(-dcoor(2)))
        coef1 = atomicadd(elecvdw_force_d(3,iatom),dble(-dcoor(3)))
        coef1 = atomicadd(elecvdw_force_d(1,jatom),dble(dcoor(1)))
        coef1 = atomicadd(elecvdw_force_d(2,jatom),dble(dcoor(2)))
        coef1 = atomicadd(elecvdw_force_d(3,jatom),dble(dcoor(3)))
     end if

  end if

  if ( cgipb > 1 ) then
     irec = 1
     do while (irec<=16)
        coef1 = __shfl_xor(vir(1),irec); vir(1) = vir(1) + coef1
        coef1 = __shfl_xor(vir(2),irec); vir(2) = vir(2) + coef1
        coef1 = __shfl_xor(vir(3),irec); vir(3) = vir(3) + coef1
        irec = irec*2
     end do
     if ( threadidx%x == 1 ) then
        coef1 = atomicadd(cgvir_d(1),dble(vir(1)))
        coef1 = atomicadd(cgvir_d(2),dble(vir(2)))
        coef1 = atomicadd(cgvir_d(3),dble(vir(3)))
     end if
  end if

  if ( ifcalpot .eqv. .false. ) return

  irec = 1
  do while (irec<=16)
     coef1 = __shfl_xor(tpelec,irec); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,irec); tpvdw = tpvdw + coef1
     irec = irec*2
  end do
  if (threadidx%x==1) then
     coef1 = atomicadd(cgeelec_d,dble(tpelec))
     coef1 = atomicadd(cgevdw_d,dble(tpvdw))
  end if
end subroutine

!============================================= pressure coupling

attributes(global) subroutine cudacgpb_npt_prepare_cell()
  select case(blockidx%x)
  case (1)
    mat_frac2car_d(1,1) = cgcell_d(1)
  case (2)
    mat_frac2car_d(1,2) = cgcell_d(2)*cosgamma_d
  case (3)
    mat_frac2car_d(2,2) = cgcell_d(2)*singamma_d
  case (4)
    mat_frac2car_d(1,3) = cgcell_d(3)*cosbeta_d
  case (5)
    mat_frac2car_d(2,3) = cgcell_d(3)*latticeterm1_d
  case (6)
    mat_frac2car_d(3,3) = cgcell_d(3)*latticeterm2_d
  case (7)
    cellvolume_d = cgcell_d(1)*cgcell_d(2)*cgcell_d(3)*singamma_d*latticeterm2_d
  case (8)
    cgcellinv_d(1) = 1.0/cgcell_d(1)
  case (9)
    cgcellinv_d(2) = 1.0/cgcell_d(2)
  case (10)
    cgcellinv_d(3) = 1.0/cgcell_d(3)
  case (11)
    mat_car2frac_d(1,1) = 1.0/cgcell_d(1)
  case (12)
    mat_car2frac_d(1,2) = -cosgamma_d/(cgcell_d(1)*singamma_d)
  case (13)
    mat_car2frac_d(1,3) = latticeterm3_d / (cgcell_d(1)*singamma_d*latticeterm2_d)
  case (14)
    mat_car2frac_d(2,2) = 1.0/(cgcell_d(2)*singamma_d)
  case (15)
    mat_car2frac_d(2,3) = -latticeterm1_d/(cgcell_d(2)*singamma_d*latticeterm2_d)
  case (16)
    mat_car2frac_d(3,3) = 1.0/(cgcell_d(3)*latticeterm2_d)
  end select
end subroutine

attributes(global) subroutine cudacgpb_npt_com_biomol()
  integer :: i,imol,istartatom,iatom
  real :: avgcoor(3),tpa

  avgcoor = 0.0; imol = blockidx%x; istartatom = cgresindex_d(cgmolindex_d(imol)+1)
  do i=threadidx%x, cgnatompermol_d(imol), 32
     iatom = istartatom + i
     avgcoor(:) = avgcoor(:) + cgmass_d(iatom)*cgcoor_d(:,iatom)
  end do
  avgcoor(:) = avgcoor(:)*cgmolmassinv_d(imol)
  i = 1
  do while (i<=16)
     tpa = __shfl_xor(avgcoor(1),i); avgcoor(1) = avgcoor(1) + tpa
     tpa = __shfl_xor(avgcoor(2),i); avgcoor(2) = avgcoor(2) + tpa
     tpa = __shfl_xor(avgcoor(3),i); avgcoor(3) = avgcoor(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) molcom_d(:,imol) = avgcoor(:)
end subroutine

attributes(global) subroutine cudacgpb_npt_com_ionwat()
  integer :: imol,ires,iatom
  real :: avgcoor(3),vir(3)

  imol = (blockidx%x-1)*blockdim%x + threadidx%x + cgnbiomol_d; if ( imol > cgnmol_d ) return

  avgcoor = 0.0
  do ires=cgmolindex_d(imol)+1,cgmolindex_d(imol+1)
     do iatom=cgresindex_d(ires)+1,cgresindex_d(ires+1)
        avgcoor(:) = avgcoor(:) + cgmass_d(iatom)*cgcoor_d(:,iatom)
     end do
  end do
  molcom_d(:,imol)=avgcoor*cgmolmassinv_d(imol)
end subroutine

attributes(global) subroutine cudacgpb_npt_vir_mol()
  integer :: i
  real :: vir(3),tpa

  i = (blockidx%x-1)*blockdim%x + threadidx%x; vir = 0.0
  if ( i <= cgnatom_d ) then
     vir(:) = (molcom_d(:,cgatommol_d(i)) - cgcoor_d(:,i))*elecvdw_force_d(:,i)
  end if

  i = 1
  do while (i<=16)
     tpa = __shfl_xor(vir(1),i); vir(1) = vir(1) + tpa
     tpa = __shfl_xor(vir(2),i); vir(2) = vir(2) + tpa
     tpa = __shfl_xor(vir(3),i); vir(3) = vir(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) then
     tpa = atomicadd(cgvir_d(1),dble(vir(1)))
     tpa = atomicadd(cgvir_d(2),dble(vir(2)))
     tpa = atomicadd(cgvir_d(3),dble(vir(3)))
  end if
end subroutine

subroutine cudacgpb_npt_isobaric_Berendsen()
  call cudacgpb_npt_ekin_biomol<<<cgnbiomol,32>>>()
  call cudacgpb_npt_ekin_ionwat<<<cgnblocksolventmol,32>>>()
  call cudacgpb_npt_compute_pressure<<<1,1>>>()

  call cudacgpb_npt_scale_cell<<<8,1>>>()

  call cudacgpb_npt_com_biomol<<<cgnbiomol,32>>>()
  call cudacgpb_npt_com_ionwat<<<cgnblocksolventmol,32>>>()

  call cudacgpb_npt_mol_move<<<cgnblockmol,32>>>()
  call cudacgpb_npt_coupling<<<cgnblockatom,32>>>()
end subroutine

attributes(global) subroutine cudacgpb_npt_ekin_biomol()
  integer :: i,imol,iatom,istartatom
  real :: tpa,avgmom(3)

  avgmom = 0.0; imol = blockidx%x; istartatom = cgresindex_d(cgmolindex_d(imol)+1)
  do i=threadidx%x, cgnatompermol_d(imol), 32
     iatom = istartatom + i
     avgmom(:) = avgmom(:) + cgmass_d(iatom)*( cgvel_d(:,iatom) + 0.5*cg_dt_inv_mass_d(iatom)*elecvdw_force_d(:,iatom) )
  end do
  i = 1
  do while (i<=16)
     tpa = __shfl_xor(avgmom(1),i); avgmom(1) = avgmom(1) + tpa
     tpa = __shfl_xor(avgmom(2),i); avgmom(2) = avgmom(2) + tpa
     tpa = __shfl_xor(avgmom(3),i); avgmom(3) = avgmom(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) then
     avgmom = avgmom**2*cgmolmassinv_d(imol)
     imol = atomicadd(cgmolekin_d(1),dble(avgmom(1)))
     imol = atomicadd(cgmolekin_d(2),dble(avgmom(2)))
     imol = atomicadd(cgmolekin_d(3),dble(avgmom(3)))
  end if
end subroutine

attributes(global) subroutine cudacgpb_npt_ekin_ionwat()
  integer :: imol,ires,iatom,i
  real :: molp(3),tpa,tpekin(3)

  imol = (blockidx%x-1)*blockdim%x + threadidx%x + cgnbiomol_d; tpekin = 0.0
  if ( imol <= cgnmol_d ) then
     molp = 0.0
     do ires=cgmolindex_d(imol)+1,cgmolindex_d(imol+1)
        do iatom=cgresindex_d(ires)+1,cgresindex_d(ires+1)
           molp = molp + cgmass_d(iatom)*( cgvel_d(:,iatom) + 0.5*cg_dt_inv_mass_d(iatom)*elecvdw_force_d(:,iatom) )
        end do
     end do
     tpekin = molp**2*cgmolmassinv_d(imol)
  end if

  i = 1
  do while (i<=16)
     tpa = __shfl_xor(tpekin(1),i); tpekin(1) = tpekin(1) + tpa
     tpa = __shfl_xor(tpekin(2),i); tpekin(2) = tpekin(2) + tpa
     tpa = __shfl_xor(tpekin(3),i); tpekin(3) = tpekin(3) + tpa
     i = i*2
  end do
  if ( threadidx%x == 1 ) then
     tpa = atomicadd(cgmolekin_d(1),dble(tpekin(1)))
     tpa = atomicadd(cgmolekin_d(2),dble(tpekin(2)))
     tpa = atomicadd(cgmolekin_d(3),dble(tpekin(3)))
  end if
end subroutine

attributes(global) subroutine cudacgpb_npt_compute_pressure()
  real :: tppressure(3)

  tppressure = pressconvert*(cgmolekin_d+cgvir_d)/cellvolume_d
  cgrealpressure_d = sum(tppressure)/3.0
  if ( cgipb_d == 2 ) then
     nptcoeff_d = (1.0 - nptfactor_d*(cgpressure0_d - cgrealpressure_d))**(0.333333333)
  else if ( cgipb_d == 3 ) then
     nptcoeff_d = (1.0 - nptfactor_d*(cgpressure0_d - tppressure))**(0.333333333)
  end if
  cgcell_d = cgcell_d*nptcoeff_d
end subroutine

attributes(global) subroutine cudacgpb_npt_scale_cell()
  real :: nptcoeff(3)
  nptcoeff = cgcell_d/inicgcell_d
  select case (blockidx%x )
  case (1); cellvolume_d = inicellvolume_d*product(nptcoeff)
  case (2); cgcellinv_d = 1.0/cgcell_d
  case (3); mat_frac2car_d(1,:) = inimat_frac2car_d(1,:)*nptcoeff
  case (4); mat_frac2car_d(2,:) = inimat_frac2car_d(2,:)*nptcoeff
  case (5); mat_frac2car_d(3,:) = inimat_frac2car_d(3,:)*nptcoeff
  Case (6); 
     mat_car2frac_d(:,1) = inimat_car2frac_d(:,1)/nptcoeff
  case (7); 
     mat_car2frac_d(:,2) = inimat_car2frac_d(:,2)/nptcoeff
  case (8); 
     mat_car2frac_d(:,3) = inimat_car2frac_d(:,3)/nptcoeff
  end select
end subroutine

attributes(global) subroutine cudacgpb_npt_mol_move()
  integer :: imol
  real :: tpvec(3),tpcom(3)

  imol = (blockidx%x-1)*blockdim%x + threadidx%x; if ( imol > cgnmol_d ) return
  tpcom = molcom_d(1:3,imol)
  tpvec = nptcoeff_d*tpcom
  molmove_d(:,imol) = tpvec - tpcom
  molcom_d(:,imol) = tpvec
end subroutine

attributes(global) subroutine cudacgpb_npt_coupling()
  integer :: iatom
  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > cgnatom_d ) return
  cgcoor_d(:,iatom) = cgcoor_d(:,iatom) + molmove_d(:,cgatommol_d(iatom))
end subroutine

!=======================================================

subroutine cudacgpb_initialize_box()
  integer,dimension(:),allocatable :: biencodedexcludedatomlist,biencodedexcludedatomlistpos,biencodedexcludedatomlistmax
  integer :: maxnbox,iatom,jatom,i,j,k,l,tpl,tpr,i1,j1,tpnum,tpi
  real*8 :: ijkvec(3)

  if (procid==0) print "(a)","Divide the periodic system into boxes"

  inicgcell_d = inicgcell; cgcell_d = cgcell; cgcellinv_d = cgcellinv

  do k = 1,2; do j = 1,3; do i = 1,3
     l = (k-1)*9+(j-1)*3+i; ijkvec = dble((/i,j,k/))-2.d0
     boxcrd(:,l) = - ijkvec(:)*cgcell(:)
  end do; end do; end do

  cgipb_d=cgipb

  rcut_d=rcut; rcutsq_d=rcut**2; cellvolume_d=cellvolume

  bimaxnexc_d = bimaxnexc

  fullcutsq_d=fullcutsq; hfskinsq_d = hfskinsq; ifactivebox_d=.false.
  maxnbox = max(nboxvec(1),nboxvec(2),nboxvec(3))
  boxcrd_d = boxcrd; cgnbox_d = nbox; nboxvec_d = nboxvec

  allocate(boxatomindex_d(nbox)); boxatomindex_d=0

  allocate(boxatom_d(cgnatom),boxboxid_d(cgnatom))
  boxatom_d=0; boxboxid_d=0

  allocate(boxnlboxindex_d(nbox+1),boxnlboxes_d(size(boxnlboxes)),boxnlboxcsidx_d(size(boxnlboxes)))
  boxnlboxindex_d=boxnlboxindex; boxnlboxes_d = boxnlboxes; boxnlboxcsidx_d=boxnlboxcsidx

  allocate(biencodedexcludedatomlistpos(cgnatom+1),biencodedexcludedatomlistmax(cgnatom))
  biencodedexcludedatomlistpos=0; biencodedexcludedatomlistmax=0
  tpnum = 0; bimaxencodedexcl=0
  do iatom = 1,cgnatom
     tpl = 0; tpr = 0
     do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
        jatom = cgbiexcludedatomlist(j)
        if ( jatom==0 ) cycle
        if (jatom<iatom) then
           tpl = max(tpl,iatom-jatom)
        else
           tpr = max(tpr,jatom-iatom)
        end if
     end do
     biencodedexcludedatomlistmax(iatom) = max(tpl,tpr)
     bimaxencodedexcl = max(bimaxencodedexcl,(max(tpl,tpr)*2+1+31)/32)
     tpnum = tpnum + (max(tpl,tpr)*2+1+31)/32
     biencodedexcludedatomlistpos(iatom+1) = tpnum
  end do

  bimaxencodedexcl_d = bimaxencodedexcl
  allocate(biencodedexcludedatomlist(tpnum)); biencodedexcludedatomlist=0
  do iatom = 1,cgnatom
     i = biencodedexcludedatomlistpos(iatom)+1; tpi = iatom - biencodedexcludedatomlistmax(iatom)
     do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
        jatom = cgbiexcludedatomlist(j)
        if ( jatom==0 ) cycle
        k = jatom - tpi
        i1 = ishft(k,-5); j1 = iand(k,31)
        biencodedexcludedatomlist(i+i1) = ior(biencodedexcludedatomlist(i+i1),ishft(1,j1))
     end do
  end do
  allocate(biencodedexcludedatomlistpos_d(cgnatom+1),biencodedexcludedatomlistmax_d(cgnatom),biencodedexcludedatomlist_d(tpnum))
  biencodedexcludedatomlistpos_d=biencodedexcludedatomlistpos
  biencodedexcludedatomlistmax_d=biencodedexcludedatomlistmax
  biencodedexcludedatomlist_d=biencodedexcludedatomlist

  allocate(cgsavecoor_d(3,cgnatom)); cgsavecoor_d = 0.0
  allocate(cgboxcoor_d(3,cgnatom)); cgboxcoor_d = 0.0

  if ( cgmaxatomperbox == 0 ) then
     cgmaxatomperbox = cgnatom*10/nbox
     if ( cgmaxatomperbox < 10 ) cgmaxatomperbox = 10
  end if
  cgmaxatomperbox_d = cgmaxatomperbox
  allocate(boxatomnum_d(nbox),boxnlatoms_d(cgmaxatomperbox*nbox))
  if (procid==0) print "(a,i10)","Atom box list length      ",cgmaxatomperbox*nbox

  if ( cgmaxnlperatom == 0 ) then
     cgmaxnlperatom = int( 2.5d0*(4d0/3d0)*pi*fullcutsq**1.5*dble(cgnatom)/cellvolume )
     if ( cgmaxnlperatom < 10 ) cgmaxnlperatom = 10
  end if
  cgmaxnlperatom_d=cgmaxnlperatom

  call cudacgpb_set_boxatomandcoor0<<<(nbox-1)/32+1,32>>>()
  call cudacgpb_set_boxatomandcoor1<<<cgnblockatom,32>>>()
  call cudacgpb_set_boxatomandcoor2<<<nbox,32>>>()

  boxnlindex_d = 0
  call cudacgpb_set_boxatomandcoor3_prepare<<<cgnatom,63,bimaxencodedexcl*4+8+cgmaxnlperatom*4>>>()
  i = boxnlindex_d*1.1
  if ( i > size(boxnlatoms_d) ) then
     deallocate(boxnlatoms_d); allocate(boxnlatoms_d(i))
  end if
  if (procid==0) print "(a,i10)","Atom neighbor list length ",i
  boxnlindex_d = 0; allocate(boxnlpos_d(2,cgnatom))
  call cudacgpb_set_boxatomandcoor3<<<cgnatom,63,bimaxencodedexcl*4+8+cgmaxnlperatom*4>>>()
end subroutine

subroutine cudacgpb_potforce_box()
  logical :: ifactivebox

  ifactivebox_d = .false.
  call cudacgpb_clear_force_and_check_ifactivebox<<<cgnblockatom,32>>>() 
  ifactivebox = ifactivebox_d

  if ( ifactivebox .eqv. .true. ) then
     call cudacgpb_set_boxatomandcoor0<<<(nbox-1)/32+1,32>>>()
     call cudacgpb_set_boxatomandcoor1<<<cgnblockatom,32>>>()
     call cudacgpb_set_boxatomandcoor2<<<nbox,32>>>()
     boxnlindex_d = 0
     call cudacgpb_set_boxatomandcoor3<<<cgnatom,63,bimaxencodedexcl*4+8+cgmaxnlperatom*4>>>()
  end if

  call cudacgpb_potforce_direct_box<<<cgnatom,32>>>()
end subroutine

attributes(global) subroutine cudacgpb_set_boxatomandcoor0()
  integer :: ibox
  ibox = (blockidx%x-1)*blockdim%x + threadidx%x; if ( ibox > cgnbox_d ) return
  boxatomnum_d(ibox) = 0
end subroutine

attributes(global) subroutine cudacgpb_set_boxatomandcoor1()
  integer :: i,j,iatom,tpgridvec(3)
  real :: tpvec(3)

  iatom = (blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > cgnatom_d ) return

  tpvec(:) = cgcoor_d(:,iatom)
  tpvec(:) = tpvec(:) - floor(tpvec(:)*cgcellinv_d(:))*cgcell_d(:)
  cgboxcoor_d(:,iatom) = tpvec(:)
  tpgridvec(:) = min(int(tpvec(:)*cgcellinv_d(:)*real(nboxvec_d(:)))+1, nboxvec_d(:))
  i = tpgridvec(1) + (tpgridvec(2)-1)*nboxvec_d(1) + (tpgridvec(3)-1)*nboxvec_d(1)*nboxvec_d(2)
  j = atomicadd(boxatomnum_d(i),1)

  if ( (j+1) > cgmaxatomperbox_d ) then
     print *,"Too many atoms contained in a single box (cgmaxatomperbox=",cgmaxatomperbox_d,")"; stop
  end if

  j = (i-1)*cgmaxatomperbox_d+j+1
  if ( j > size(boxnlatoms_d) ) then
     print *,"The neighbor list is too short!"; stop
  end if
  boxnlatoms_d(j) = iatom
end subroutine

attributes(global) subroutine cudacgpb_set_boxatomandcoor2()
  integer :: ibox,ipos,tpnum,i

  ibox = blockidx%x;
  if ( boxatomnum_d(ibox) == 0 ) then
     if ( threadidx%x == 1 ) boxatomindex_d(ibox) = 0
     return
  end if

  if ( ibox > 1 ) then
     tpnum = 0
     do ipos = threadidx%x, ibox-1, 32
        tpnum = tpnum + boxatomnum_d(ipos)
     end do
     ipos = 1
     do while (ipos<=16)
        i = __shfl_xor(tpnum,ipos); tpnum = tpnum + i
        ipos = ipos*2
     end do
     tpnum = tpnum + 1
     if ( threadidx%x == 1 ) boxatomindex_d(ibox) = tpnum
  else
     tpnum = 1
     if ( threadidx%x == 1 ) boxatomindex_d(ibox) = tpnum
  end if
  tpnum = tpnum - 1
  do ipos = threadidx%x, boxatomnum_d(ibox), 32
     boxatom_d(ipos+tpnum) = boxnlatoms_d((ibox-1)*cgmaxatomperbox_d+ipos)
     boxboxid_d(ipos+tpnum) = ibox
  end do
end subroutine

attributes(global) subroutine cudacgpb_set_boxatomandcoor3_prepare()
  integer,shared :: threadbiencodedlist(bimaxencodedexcl_d),threadencodedmax,nlindex
  integer :: ibox,jbox,csidx,i,j,k,iatom,jatom
  real :: tpvec(3),fullcutsq,iboxcoor(3)

  i = blockidx%x; if ( threadidx%x == 1 ) nlindex = 0
  iatom=boxatom_d(i); ibox=boxboxid_d(i); fullcutsq=fullcutsq_d

  j = biencodedexcludedatomlistpos_d(iatom)
  do k = threadidx%x, biencodedexcludedatomlistpos_d(iatom+1) - j, blockdim%x
     threadbiencodedlist(k) = biencodedexcludedatomlist_d(k+j)
  end do
  threadencodedmax = biencodedexcludedatomlistmax_d(iatom)
  call syncthreads()

  if ( threadidx%x < 63 ) then
     k = boxnlboxindex_d(ibox) + threadidx%x
     jbox = boxnlboxes_d(k); csidx = boxnlboxcsidx_d(k)
  else if ( threadidx%x == 63 ) then
     jbox = ibox; csidx = 14
  end if

  iboxcoor(1:3) = cgboxcoor_d(1:3,iatom) + boxcrd_d(1:3,csidx)

  csidx = boxatomindex_d(jbox) + boxatomnum_d(jbox) - 1
  if ( threadidx%x == 63 ) csidx = blockidx%x - 1

  i = cgnatomtype_d*(cgatomtype_d(iatom)-1)
  do j = boxatomindex_d(jbox), csidx
     jatom=boxatom_d(j); k = jatom - iatom
     if ( abs(k) <= threadencodedmax ) then
        k = k + threadencodedmax
        if ( iand(threadbiencodedlist(ishft(k,-5)+1),ishft(1,iand(k,31)))/=0 ) cycle
     end if
     tpvec(1:3) = iboxcoor(1:3) - cgboxcoor_d(1:3,jatom)
     if ( dot_product(tpvec,tpvec) <= fullcutsq ) k = atomicadd(nlindex, 1)
  end do
  call syncthreads()
  if ( threadidx%x == 1 ) i = atomicadd(boxnlindex_d, nlindex)
end subroutine

attributes(global) subroutine cudacgpb_set_boxatomandcoor3()
  integer,shared :: threadbiencodedlist(bimaxencodedexcl_d),threadencodedmax,nlindex
  integer,shared :: atomlist(cgmaxnlperatom_d)
  integer :: ibox,jbox,csidx,i,j,k,iatom,jatom
  real :: tpvec(3),fullcutsq,iboxcoor(3)

  i = blockidx%x; if ( threadidx%x == 1 ) nlindex = 0
  iatom=boxatom_d(i); ibox=boxboxid_d(i); fullcutsq=fullcutsq_d
 
  j = biencodedexcludedatomlistpos_d(iatom)
  do k = threadidx%x, biencodedexcludedatomlistpos_d(iatom+1) - j, blockdim%x
     threadbiencodedlist(k) = biencodedexcludedatomlist_d(k+j)
  end do
  threadencodedmax = biencodedexcludedatomlistmax_d(iatom)

  if ( threadidx%x < 63 ) then
     k = boxnlboxindex_d(ibox) + threadidx%x
     jbox = boxnlboxes_d(k); csidx = boxnlboxcsidx_d(k)
  else if ( threadidx%x == 63 ) then
     jbox = ibox; csidx = 14
  end if

  iboxcoor(1:3) = cgboxcoor_d(1:3,iatom) + boxcrd_d(1:3,csidx)

  csidx = boxatomindex_d(jbox) + boxatomnum_d(jbox) - 1
  if ( threadidx%x == 63 ) csidx = blockidx%x - 1

  i = cgnatomtype_d*(cgatomtype_d(iatom)-1)

  call syncthreads()

  do j = boxatomindex_d(jbox), csidx
     jatom=boxatom_d(j); k = jatom - iatom
     if ( abs(k) <= threadencodedmax ) then
        k = k + threadencodedmax
        if ( iand(threadbiencodedlist(ishft(k,-5)+1),ishft(1,iand(k,31)))/=0 ) cycle
     end if

     tpvec(1:3) = iboxcoor(1:3) - cgboxcoor_d(1:3,jatom)

     if ( dot_product(tpvec,tpvec) <= fullcutsq ) then
        k = atomicadd(nlindex, 1)

        jbox = i + cgatomtype_d(jatom)
        jbox = cgnonbondedparmindex_d(jbox)
        jatom= ior(jatom,ishft(jbox,20))

        atomlist(k+1) = jatom
     end if
  end do

  call syncthreads()

  if ( threadidx%x == 1 ) then
     if ( nlindex > cgmaxnlperatom_d ) then
        print *,"Too many neighbors for a single atom (cgmaxnlperatom=",cgmaxnlperatom_d,")"; stop
     end if
     cgsavecoor_d(1:3,iatom) = cgcoor_d(1:3,iatom)

     i = atomicadd(boxnlindex_d, nlindex)
     j = i + nlindex
     if ( j > size(boxnlatoms_d) ) then
        print *,"The neighbor list is too short!"; stop
     end if
     boxnlpos_d(1:2,iatom) = [i+1,j]
     threadencodedmax = i
  end if

  call syncthreads()

  do k = threadidx%x, nlindex, blockdim%x
     boxnlatoms_d(threadencodedmax+k) = atomlist(k)
  end do
end subroutine

attributes(global) subroutine cudacgpb_potforce_direct_box()
  integer :: k,iatom,jatom,idx,ivdwtype
  real :: tpcoorvec(3),icharge,icoor(3),tpifrc(3)
  real :: tpelec,tpvdw,tpfrccoef,dissq,coef1,dissqinv
  real :: sigmasq,eps4,eleccoef,rcutsqinv,coef2,krf,crf,cgcellinv(3),cgcell(3)
  logical :: ifcalpot

  ifcalpot = cgifcalpot_d; eleccoef = eleccoef_d
  tpelec = 0.0; tpvdw = 0.0; tpifrc(:) = 0.0; cgcell = cgcell_d; cgcellinv = cgcellinv_d
  rcutsqinv = 1.0/rcutsq_d; krf = krf_d; crf = crf_d

  iatom = blockidx%x; icharge = cgcharge_d(iatom); icoor(:) = cgcoor_d(:, iatom)
  !ivdwtype = cgnatomtype_d*(cgatomtype_d(iatom)-1)

  do idx = boxnlpos_d(1,iatom)+threadidx%x-1, boxnlpos_d(2,iatom), 32
    
     !jatom = boxnlatoms_d(idx)

     k = boxnlatoms_d(idx)
     jatom = iand(Z"FFFFF",k)
     k = ishft(k,-20); k = iand(Z"FFF",k)

     tpcoorvec = icoor(:) - cgcoor_d(:,jatom)
     tpcoorvec = tpcoorvec - floor(tpcoorvec*cgcellinv+0.5)*cgcell

     dissqinv = 1.0/dot_product(tpcoorvec,tpcoorvec)

     if ( dissqinv > rcutsqinv ) then

        tpfrccoef = eleccoef*icharge*cgcharge_d(jatom)

        if ( ifcalpot ) tpelec = tpelec + tpfrccoef * (sqrt(dissqinv) + krf/dissqinv - crf)

        !k = ivdwtype + cgatomtype_d(jatom)
        !k = cgnonbondedparmindex_d(k)
        sigmasq = cgnonbondedparms_d(1,k)
        eps4 = cgnonbondedparms_d(2,k)

        coef1 = sigmasq*rcutsqinv; coef1 = coef1*coef1*coef1
        coef2 = sigmasq*dissqinv; coef2 = coef2*coef2*coef2
        if ( ifcalpot ) tpvdw = tpvdw + eps4*(coef2*(coef2 - 1.0) - coef1*(coef1 - 1.0))
        tpfrccoef = tpfrccoef * (-sqrt(dissqinv)*dissqinv + 2.0 * krf) - (eps4*coef2*(12.0*coef2 - 6.0))*dissqinv

        tpcoorvec(:) = tpcoorvec(:)*tpfrccoef

        tpifrc(:) = tpifrc(:) - tpcoorvec(:)

        k = atomicadd(elecvdw_force_d(1,jatom),dble(tpcoorvec(1)))
        k = atomicadd(elecvdw_force_d(2,jatom),dble(tpcoorvec(2)))
        k = atomicadd(elecvdw_force_d(3,jatom),dble(tpcoorvec(3)))

     end if

  end do

  k = atomicadd(elecvdw_force_d(1,iatom),dble(tpifrc(1)))
  k = atomicadd(elecvdw_force_d(2,iatom),dble(tpifrc(2)))
  k = atomicadd(elecvdw_force_d(3,iatom),dble(tpifrc(3)))

  if ( .not. ifcalpot ) return

  k = 1
  do while (k<=16)
     coef1 = __shfl_xor(tpelec,k); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,k); tpvdw = tpvdw + coef1
     k = k*2
  end do

  if ( threadidx%x == 1 ) then
      k = atomicadd(cgeelec_d,dble(tpelec))
      k = atomicadd(cgevdw_d,dble(tpvdw))
  end if
end subroutine

attributes(global) subroutine cudacgpb_clear_force_and_check_ifactivebox()
  integer :: iatom
  real :: tpcoorvec(3)

  iatom=(blockidx%x-1)*blockdim%x+threadidx%x; if ( iatom > cgnatom_d ) return
  elecvdw_force_d(:,iatom) = 0.0d0

  if ( blockidx%x == 1 ) then
     if ( (threadidx%x == 1) .and. (cgifcalpot_d) ) then
        cgebond_d = 0d0; cgeangle2_d = 0d0; cgeangle10_d = 0d0
        cgedihedral1_d = 0d0; cgedihedral2_d = 0d0; cgedihedral3_d = 0d0; cgedihedral4_d = 0d0
        cgeelec_d = 0d0; cgevdw_d = 0d0; cgeexclude_d = 0d0; evdwcorr_d = 0d0
        cgtotforce_d = 0d0
     end if
  end if

  if ( ifactivebox_d .eqv. .true. ) return

  tpcoorvec(:) = cgcoor_d(:,iatom) - cgsavecoor_d(:,iatom)
  if ( dot_product(tpcoorvec,tpcoorvec) > hfskinsq_d ) then
     if ( ifactivebox_d .eqv. .false. ) ifactivebox_d = .true.
  end if
end subroutine

end module
