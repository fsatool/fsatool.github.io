module itp_reader
    use utils
    implicit none

    real*8,parameter,public :: rcut = 11.0d0

    real*8,public :: cgcell(3),cgcellalpha,cgcellbeta,cgcellgamma

    real*8,public :: cgeelec,cgevdw,krf,crf,cgeself,cgeexclude,cgepot

    integer,public :: cgnowstep=0,cgprintcvstep,cgnmolgroup,cgipb,cgnbiomol,cgnatomtype,cgnatom,cgnmol,cgnres,cgnbond,cgicuda,ncst
    integer,allocatable,public :: cgmolgroupindex(:),cgnonbondedparmindex(:),cgatomtype(:),cgatommol(:),cgresmol(:)
    real*8,allocatable,public :: cgnonbondedparms(:,:)
    real*8,pointer,public :: cgcoor(:,:),cgvel(:,:),cgprecoor(:,:),cgforce(:,:)

    real*8,public :: cgcsttol
    integer,public,allocatable :: jacobicstindex(:),jacobicstlist(:)
    real*8,allocatable,public :: cst_reduced_mass(:), cgmassinv(:), jacobicstval(:),cgmass(:),cgcharge(:)
    real*8,allocatable,public :: cgrescharge(:),cgmolcharge(:),cgmolmass(:),cgmolcom(:,:)
    character(len=4),allocatable,public :: cgresname(:),cgname(:)
    integer,public :: cgnexcludepair
    integer,allocatable,public :: cgnexcludedatoms(:),cgexcludedatomlist(:)

    logical,public :: cgifcalpot, nobond, noconstraint_bond, noangle, noconstraint, nodihedral, noexclusion, nocgnatomtype

    type virtualsitetype
        integer :: siteatom, sitetype  
        integer,allocatable :: atomlist(:)  
        real*8,allocatable :: weights(:)    
        real*8,allocatable :: weightdx(:)   
        real*8 :: weightp                   
    end type virtualsitetype

    type(virtualsitetype),allocatable,public :: virtualsites(:)
    integer,public :: nvirtualsite, nvirtualsite_outofplane 

    real*8,parameter,public :: restraint_force_const = 100000*KJ_TO_KCAL

    integer, allocatable, public :: cgresindex(:), cgnatompermol(:), cgmolindex(:)

    type itp_info
        integer :: atom_num, res_num, bond_num, angle_num, dihedral_num, exclusion_num, all_atom_type_num
        !dihedral
        integer :: periodic_num,improper_num,rb_num,combined_num
        integer :: constraint_num, constraint_bond_num
        character(len=100) :: data_path
        ! ==iatomnfo vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        ! atom_type, res_id, res_type, pos_type, charge
        integer, dimension(:), pointer :: res_id
        real*8 , dimension(:), pointer :: charge, mass
        !real*8, dimension(:,:), pointer :: coor
        character*4, dimension(:), pointer :: res_type, pos_type
        integer, dimension(:), pointer :: atom_type
        ! ==iatomnfo ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

        ! ==bond_info vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        ! iatom, jatom, func_type, equil_value, force_const
        integer, dimension(:), pointer :: iatom, jatom, func_type
        real*8,  dimension(:), pointer :: equil_value, force_const
        ! ==bond_info ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

        ! ==constraint_bond_info vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        ! iatom, jatom, func_type, equil_value, force_const
        integer, dimension(:), pointer :: constraint_iatom, constraint_jatom, constraint_func_type
        real*8,  dimension(:), pointer :: constraint_equil_value, constraint_force_const
        ! ==constraint_bond_info ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

        ! ==angle_info vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        ! iatom, jatom, katom, func_type, equil_value, force_const
        integer, dimension(:), pointer :: angle_iatom, angle_jatom, angle_katom, angle_func_type
        real*8,  dimension(:), pointer :: angle_equil_value, angle_force_const
        ! ==angle_info ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

        ! ==dihedral_info vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        ! atom_0,1,2,3, func_type, equil_value, force_const
        integer, dimension(:), pointer :: dihedral_atom_0, dihedral_atom_1, dihedral_atom_2, dihedral_atom_3, dihedral_func_type
        real*8,  dimension(:), pointer :: dihedral_equil_value, dihedral_force_const
        integer, dimension(:), pointer :: dihedral_extra_int      
        real*8,  dimension(:,:), pointer :: dihedral_extra_real   
        ! ==dihedral_info ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

        ! LJ_params
        real*8, dimension(:,:,:), pointer :: LJ_params

        logical, dimension(:,:), pointer :: exclude

        integer, dimension(:,:), pointer :: virtualSitesN
        integer :: virtualSitesN_num, virtualSites2_num, virtualSites3_num
        integer, dimension(:,:), pointer :: virtualSites2_atoms, virtualSites3_atoms
        real*8, dimension(:,:), pointer :: virtualSites2_weights, virtualSites3_weights
        ! (contraint_num, 2)
        integer, dimension(:,:), pointer :: constraint
        real*8, dimension(:), pointer :: constraint_length
        ! periodic_box_vec
        real*8, dimension(3) :: periodic_box_vec

        contains
        PROCEDURE :: init => init
        PROCEDURE :: read_top_file => read_top_file
        PROCEDURE :: get_LJ_C12C6_coef => get_LJ_C12C6_coef
    end type

    private
    public :: itp_info
    public :: virtualsitetype
contains

subroutine get_LJ_C12C6_coef(self, C12_C6, i, j)
    class(itp_info) :: self
    integer :: i, j
    real*8, dimension(2) :: C12_C6, sigma_epsilon
    real*8 :: sigma__6
    sigma_epsilon(:) = self%LJ_params(i, j, :)
    if (sigma_epsilon(1) == 0 .or. sigma_epsilon(2) == 0) then
        sigma_epsilon(:) = self%LJ_params(j, i, :)
    end if
    if (sigma_epsilon(1) == 0 .or. sigma_epsilon(2) == 0) then
        print *, "get_LJ_C12C6_coef error !!!! get 0 value"
        print *, i, j
        print *, "==========================="
    end if
    sigma__6 = sigma_epsilon(1)**6
    C12_C6(1) = 4*sigma_epsilon(2) * sigma__6**2
    C12_C6(2) = 4*sigma_epsilon(2) * sigma__6
end subroutine

subroutine allocate_arrays(self)
    class(itp_info) :: self

    ! atom_type, res_id, res_type, pos_type, charge, mass
    allocate(self%atom_type(self%atom_num), self%res_id(self%atom_num), &
        self%res_type(self%atom_num), self%pos_type(self%atom_num), self%charge(self%atom_num), &
        self%mass(self%atom_num))

    !allocate(self%coor(self%atom_num, 3))

    allocate(self%iatom(self%bond_num), self%jatom(self%bond_num), self%func_type(self%bond_num), &
    self%equil_value(self%bond_num), self%force_const(self%bond_num))

    allocate(self%constraint_iatom(self%constraint_bond_num), self%constraint_jatom(self%constraint_bond_num), &
    self%constraint_func_type(self%constraint_bond_num), self%constraint_equil_value(self%constraint_bond_num), &
    self%constraint_force_const(self%constraint_bond_num))

    allocate(self%angle_iatom(self%angle_num), self%angle_jatom(self%angle_num), &
        self%angle_katom(self%angle_num), self%angle_func_type(self%angle_num), &
        self%angle_equil_value(self%angle_num), self%angle_force_const(self%angle_num))

    allocate(self%dihedral_atom_0(self%dihedral_num), self%dihedral_atom_1(self%dihedral_num), &
        self%dihedral_atom_2(self%dihedral_num), self%dihedral_atom_3(self%dihedral_num), &
        self%dihedral_func_type(self%dihedral_num), self%dihedral_equil_value(self%dihedral_num), &
        self%dihedral_force_const(self%dihedral_num))
    allocate(self%dihedral_extra_int(self%dihedral_num))
    allocate(self%dihedral_extra_real(6, self%dihedral_num)) 

    allocate(self%LJ_params(self%all_atom_type_num, self%all_atom_type_num, 2))

    allocate(self%virtualSitesN(self%virtualSitesN_num, 6))
    allocate(self%virtualSites2_atoms(self%virtualSites2_num, 4), self%virtualSites2_weights(self%virtualSites2_num, 1))  
    allocate(self%virtualSites3_atoms(self%virtualSites3_num, 5), self%virtualSites3_weights(self%virtualSites3_num, 3))

    allocate(self%constraint(self%constraint_num, 2), self%constraint_length(self%constraint_num))
end subroutine allocate_arrays

subroutine pick_arrays(iotop, tplabel, tpformat, ifexist, skip_data)
    integer, intent(in) :: iotop
    character(len=*),intent(in) :: tplabel
    character(len=*), intent(out) :: tpformat   
    logical,intent(out),optional :: ifexist  
    logical,intent(in),optional :: skip_data  
    logical :: iffound, do_skip
    integer :: ierr
    character(len=256) :: tpstring, test_line
    integer :: line_len
    
    iffound = .false.
    do_skip = .false.
    if (present(skip_data)) do_skip = skip_data
    
    do  
        read(iotop,"(a)",iostat=ierr) tpstring 
        if ( ierr < 0 ) exit     
        
        if ( trim(tpstring) == trim(tplabel) ) then
            iffound = .true.       
            read(iotop,"(a)",iostat=ierr) tpformat
            if (ierr == 0) then
                tpformat = adjustl(tpformat)
                if (len_trim(tpformat) >= 8 .and. tpformat(1:7) == "%FORMAT") then
                    tpformat = tpformat(8:)
                else
                    tpformat = ""
                end if
                
                if (do_skip) then
                    do
                        read(iotop,"(a)",iostat=ierr) test_line
                        if (ierr /= 0) exit
                        
                        test_line = adjustl(test_line)
                        line_len = len_trim(test_line)
                        
                        if (line_len > 0 .and. test_line(1:1) == "%") then
                            backspace(iotop)
                            exit
                        else
                            cycle
                        end if
                    end do
                end if
                
            else
                tpformat = ""
            end if
            exit  
        end if
    end do
    
    if ( iffound .eqv. .false. ) then
        print "(a,a,a)","Keyword ",trim(tplabel)," is not found in the topology file"
        rewind(iotop)
    end if
    
    if ( present(ifexist) ) ifexist=iffound 
end subroutine



subroutine read_top_file(self, topfilename)
    class(itp_info) :: self
    character(len=*),intent(in) :: topfilename
    integer :: io_unit, i, j, k, l, idihe, iatom, index, itype, iangle, ibond
    integer, dimension(:,:), allocatable :: tparray
    real*8, dimension(:,:), allocatable :: tpweights  
    character(len=50) :: tpformat
    logical :: ifexist, iffound
    integer :: total_params, ptr, max_param_index, idx
    integer :: start_atom, end_atom
    integer, allocatable :: residue_pointers(:)
    character(len=4), allocatable :: residue_labels(:)
    integer :: offset = 0
    integer :: start_idx, end_idx, coeff_idx
    real*8, dimension(:), allocatable :: tmp_coeffs

    inquire(file=topfilename, exist=ifexist)
    if (.not. ifexist) then
        print *, "Topology file does not exist: ", trim(topfilename)
        stop
    end if

    io_unit = m_get_unit()
    open(io_unit, file=topfilename, action="read")

    call pick_arrays(io_unit, "%FLAG NUM_INFO", tpformat, iffound)
    if (iffound) then
        read(io_unit, tpformat) self%atom_num, self%res_num, self%bond_num, &
                                self%constraint_bond_num, self%angle_num, &
                                self%periodic_num, self%improper_num, self%rb_num,&
                                self%combined_num, self%exclusion_num, &
                                self%all_atom_type_num, self%virtualSitesN_num, &
                                self%virtualSites2_num, self%virtualSites3_num, &
                                self%constraint_num
    
        self%dihedral_num = self%periodic_num + self%improper_num + self%rb_num + self%combined_num
    
        nobond = (self%bond_num == 0)
        noconstraint_bond = (self%constraint_bond_num == 0)
        noangle = (self%angle_num == 0)
        noconstraint = (self%constraint_num == 0)
        nodihedral = (self%dihedral_num == 0)
        noexclusion = (self%exclusion_num == 0)
        nocgnatomtype = (self%all_atom_type_num ==0)
    else
        print *, "Error: NUM_INFO flag not found in topology file"
        close(io_unit)
        return
    end if

    call allocate_arrays(self)

    call pick_arrays(io_unit, "%FLAG ATOM_TYPE_INDEX", tpformat, iffound)
    if (iffound) read(io_unit, tpformat) self%atom_type(1:self%atom_num)

    allocate(residue_pointers(self%res_num))
    call pick_arrays(io_unit, "%FLAG RESIDUE_POINTER", tpformat, iffound)
    if (iffound) read(io_unit, tpformat) residue_pointers(1:self%res_num)

    allocate(residue_labels(self%res_num))
    call pick_arrays(io_unit, "%FLAG RESIDUE_LABEL", tpformat, iffound)
    if (iffound) read(io_unit, tpformat) residue_labels(1:self%res_num)

    do i = 1, self%res_num
        if (i < self%res_num) then
            start_atom = residue_pointers(i)
            end_atom = residue_pointers(i+1) - 1
            self%res_id(start_atom:end_atom) = i
            self%res_type(start_atom:end_atom) = residue_labels(i)
        else
            start_atom = residue_pointers(i)
            end_atom = self%atom_num
            self%res_id(start_atom:end_atom) = i
            self%res_type(start_atom:end_atom) = residue_labels(i)
        end if
    end do

    cgnres = self%res_num
    allocate(cgresname(cgnres)); cgresname = residue_labels
    allocate(cgresindex(self%res_num + 1))
    cgresindex(1) = 0
    do i = 1, self%res_num - 1
       cgresindex(i+1) = residue_pointers(i+1) - 1
    end do
    cgresindex(self%res_num+1) = self%atom_num

    deallocate(residue_labels,residue_pointers)

    call pick_arrays(io_unit, "%FLAG TREE_CHAIN_CLASSIFICATION", tpformat, iffound)
    if (iffound) read(io_unit, tpformat) self%pos_type(1:self%atom_num)

    call pick_arrays(io_unit, "%FLAG CHARGE", tpformat, iffound)
    if (iffound) read(io_unit, tpformat) self%charge(1:self%atom_num)

    call pick_arrays(io_unit, "%FLAG MASS", tpformat, iffound)
    if (iffound) read(io_unit, tpformat) self%mass(1:self%atom_num)

    if (self%bond_num > 0) then
        call pick_arrays(io_unit, "%FLAG BONDS_WITHOUT_HYDROGEN", tpformat, iffound)
        if (iffound) then
            allocate(tparray(3, self%bond_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,3), j=1,self%bond_num)
            do i = 1, self%bond_num
                self%iatom(i) = tparray(1,i)
                self%jatom(i) = tparray(2,i)
                self%func_type(i) = tparray(3,i)
            end do
            deallocate(tparray)
        end if

        call pick_arrays(io_unit, "%FLAG BOND_EQUIL_VALUE", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%equil_value(1:self%bond_num)
        self%equil_value = self%equil_value * NM_TO_ANG

        call pick_arrays(io_unit, "%FLAG BOND_FORCE_CONSTANT", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%force_const(1:self%bond_num)
        self%force_const = self%force_const * KJ_TO_KCAL / (NM_TO_ANG**2)
    else
        call pick_arrays(io_unit, "%FLAG BONDS_WITHOUT_HYDROGEN", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG BOND_EQUIL_VALUE", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG BOND_FORCE_CONSTANT", tpformat, iffound, skip_data=.true.)
    end if

    if (self%constraint_bond_num > 0) then
        call pick_arrays(io_unit, "%FLAG CONSTRAINT_BONDS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(3, self%constraint_bond_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,3), j=1,self%constraint_bond_num)
            do i = 1, self%constraint_bond_num
                self%constraint_iatom(i) = tparray(1,i)
                self%constraint_jatom(i) = tparray(2,i)
                self%constraint_func_type(i) = tparray(3,i)
            end do
            deallocate(tparray)
        end if

        call pick_arrays(io_unit, "%FLAG CONSTRAINT_BOND_EQUIL_VALUE", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%constraint_equil_value(1:self%constraint_bond_num)
        self%constraint_equil_value = self%constraint_equil_value * NM_TO_ANG

        call pick_arrays(io_unit, "%FLAG CONSTRAINT_BOND_FORCE_CONSTANT", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%constraint_force_const(1:self%constraint_bond_num)
        self%constraint_force_const = self%constraint_force_const * KJ_TO_KCAL / (NM_TO_ANG**2)
    else
        call pick_arrays(io_unit, "%FLAG CONSTRAINT_BONDS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG CONSTRAINT_BOND_EQUIL_VALUE", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG CONSTRAINT_BOND_FORCE_CONSTANT", tpformat, iffound, skip_data=.true.)
    end if

    if (self%angle_num > 0) then
        call pick_arrays(io_unit, "%FLAG ANGLES_WITHOUT_HYDROGEN", tpformat, iffound)
        if (iffound) then
            allocate(tparray(4, self%angle_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,4), j=1,self%angle_num)
            do i = 1, self%angle_num
                self%angle_iatom(i) = tparray(1,i)
                self%angle_jatom(i) = tparray(2,i)
                self%angle_katom(i) = tparray(3,i)
                self%angle_func_type(i) = tparray(4,i)
            end do
            deallocate(tparray)
        end if

        call pick_arrays(io_unit, "%FLAG ANGLE_EQUIL_VALUE", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%angle_equil_value(1:self%angle_num)

        call pick_arrays(io_unit, "%FLAG ANGLE_FORCE_CONSTANT", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%angle_force_const(1:self%angle_num)
        self%angle_force_const = self%angle_force_const * KJ_TO_KCAL 
    else
        call pick_arrays(io_unit, "%FLAG ANGLES_WITHOUT_HYDROGEN", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG ANGLE_EQUIL_VALUE", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG ANGLE_FORCE_CONSTANT", tpformat, iffound, skip_data=.true.)
    end if

    if (self%periodic_num > 0) then
        call pick_arrays(io_unit, "%FLAG PERIODIC_DIHEDRALS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(5, self%periodic_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,5), j=1,self%periodic_num)
            do i = 1, self%periodic_num
                idx = offset + i
                self%dihedral_atom_0(idx) = tparray(1,i)
                self%dihedral_atom_1(idx) = tparray(2,i)
                self%dihedral_atom_2(idx) = tparray(3,i)
                self%dihedral_atom_3(idx) = tparray(4,i)
                self%dihedral_func_type(idx) = tparray(5,i)
            end do
            deallocate(tparray)
        end if

        start_idx = offset + 1
        offset = offset + self%periodic_num
        end_idx = offset
        call pick_arrays(io_unit, "%FLAG PERIODIC_PHASE", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%dihedral_equil_value(start_idx:end_idx)
        
        call pick_arrays(io_unit, "%FLAG PERIODIC_FORCE_CONSTANT", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%dihedral_force_const(start_idx:end_idx)
        self%dihedral_force_const(start_idx:end_idx) = self%dihedral_force_const(start_idx:end_idx) * KJ_TO_KCAL
        
        call pick_arrays(io_unit, "%FLAG PERIODIC_PERIODICITY", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%dihedral_extra_int(start_idx:end_idx)
    else
        call pick_arrays(io_unit, "%FLAG PERIODIC_DIHEDRALS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG PERIODIC_PHASE", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG PERIODIC_FORCE_CONSTANT", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG PERIODIC_PERIODICITY", tpformat, iffound, skip_data=.true.)   
    end if

    if (self%improper_num > 0) then    
        call pick_arrays(io_unit, "%FLAG IMPROPER_DIHEDRALS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(5, self%improper_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,5), j=1,self%improper_num)
            do i = 1, self%improper_num
                idx = offset + i
                self%dihedral_atom_0(idx) = tparray(1,i)
                self%dihedral_atom_1(idx) = tparray(2,i)
                self%dihedral_atom_2(idx) = tparray(3,i)
                self%dihedral_atom_3(idx) = tparray(4,i)
                self%dihedral_func_type(idx) = tparray(5,i)
            end do
            deallocate(tparray)
        end if
        start_idx = offset + 1
        offset = offset + self%improper_num
        end_idx = offset

        call pick_arrays(io_unit, "%FLAG IMPROPER_PHASE", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%dihedral_equil_value(start_idx:end_idx)
        
        call pick_arrays(io_unit, "%FLAG IMPROPER_FORCE_CONSTANT", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%dihedral_force_const(start_idx:end_idx)
        self%dihedral_force_const(start_idx:end_idx) = self%dihedral_force_const(start_idx:end_idx) * KJ_TO_KCAL
    else 
        call pick_arrays(io_unit, "%FLAG IMPROPER_DIHEDRALS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG IMPROPER_PHASE", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG IMPROPER_FORCE_CONSTANT", tpformat, iffound, skip_data=.true.) 
    end if 

    if (self%rb_num > 0) then      
        call pick_arrays(io_unit, "%FLAG RB_DIHEDRALS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(5, self%rb_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,5), j=1,self%rb_num)
            do i = 1, self%rb_num
                idx = offset + i
                self%dihedral_atom_0(idx) = tparray(1,i)
                self%dihedral_atom_1(idx) = tparray(2,i)
                self%dihedral_atom_2(idx) = tparray(3,i)
                self%dihedral_atom_3(idx) = tparray(4,i)
                self%dihedral_func_type(idx) = tparray(5,i)
            end do
            deallocate(tparray)
        end if
        
        start_idx = offset + 1
        offset = offset + self%rb_num
        end_idx = offset
        call pick_arrays(io_unit, "%FLAG RB_COEFFICIENTS", tpformat, iffound)
        if (iffound) then
            allocate(tmp_coeffs(self%rb_num * 6))
            read(io_unit, tpformat) tmp_coeffs(1:self%rb_num*6)
            do i = 1, self%rb_num
                idx = start_idx - 1 + i  
                coeff_idx = (i-1)*6 + 1  
                self%dihedral_extra_real(1:6,idx) = tmp_coeffs(coeff_idx:coeff_idx+5) * KJ_TO_KCAL  ! C0-C5
            end do
            deallocate(tmp_coeffs)
        end if
    else 
        call pick_arrays(io_unit, "%FLAG RB_DIHEDRALS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG RB_COEFFICIENTS", tpformat, iffound, skip_data=.true.)
    end if     
    
    if (self%combined_num > 0) then
        call pick_arrays(io_unit, "%FLAG COMBINED_DIHEDRALS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(5, self%combined_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,5), j=1,self%combined_num)
            do i = 1, self%combined_num
                idx = offset + i
                self%dihedral_atom_0(idx) = tparray(1,i)
                self%dihedral_atom_1(idx) = tparray(2,i)
                self%dihedral_atom_2(idx) = tparray(3,i)
                self%dihedral_atom_3(idx) = tparray(4,i)
                self%dihedral_func_type(idx) = tparray(5,i)
            end do
            deallocate(tparray)
        end if
        
        start_idx = offset + 1
        offset = offset + self%combined_num
        end_idx = offset
    
        call pick_arrays(io_unit, "%FLAG COMBINED_COEFFICIENTS", tpformat, iffound)
        if (iffound) then
            allocate(tmp_coeffs(self%combined_num * 6))
            read(io_unit, tpformat) tmp_coeffs(1:self%combined_num*6)
            do i = 1, self%combined_num
                idx = start_idx - 1 + i  
                coeff_idx = (i-1)*6 + 1  
                self%dihedral_extra_real(1,idx) = tmp_coeffs(coeff_idx) * KJ_TO_KCAL 
                self%dihedral_extra_real(2:6,idx) = tmp_coeffs(coeff_idx+1:coeff_idx+5)  
            end do
            deallocate(tmp_coeffs)
        end if        
    else
        call pick_arrays(io_unit, "%FLAG COMBINED_DIHEDRALS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG COMBINED_COEFFICIENTS", tpformat, iffound, skip_data=.true.)
    end if

    if (self%exclusion_num > 0) then
        call pick_arrays(io_unit, "%FLAG NUMBER_EXCLUDED_ATOMS", tpformat, iffound)
        if (iffound) then
            allocate(cgnexcludedatoms(self%atom_num))
            read(io_unit, tpformat) cgnexcludedatoms
        else
            print *, "Warning: NUMBER_EXCLUDED_ATOMS flag not found"
        end if

        cgnexcludepair = sum(cgnexcludedatoms)
        call pick_arrays(io_unit, "%FLAG EXCLUDED_ATOMS_LIST", tpformat, iffound)
        if (iffound .and. cgnexcludepair > 0) then
            allocate(cgexcludedatomlist(cgnexcludepair))
            read(io_unit, tpformat) cgexcludedatomlist
        else
            print *, "Warning: EXCLUDED_ATOMS_LIST flag not found"
        end if
    else
        allocate(cgnexcludedatoms(self%atom_num))
        cgnexcludedatoms = 0
        allocate(cgexcludedatomlist(0))  
        cgnexcludepair = 0
        call pick_arrays(io_unit, "%FLAG NUMBER_EXCLUDED_ATOMS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG EXCLUDED_ATOMS_LIST", tpformat, iffound, skip_data=.true.)
    end if

    
    cgnatomtype = self%all_atom_type_num

    if (cgnatomtype > 0) then
        call pick_arrays(io_unit, "%FLAG NONBONDED_PARM_INDEX", tpformat, iffound)
        if (iffound) then
            total_params = cgnatomtype * cgnatomtype
        
            if (.not. allocated(cgnonbondedparmindex)) then
                allocate(cgnonbondedparmindex(total_params))
            end if
            read(io_unit, tpformat) cgnonbondedparmindex(1:total_params)
 
            max_param_index = maxval(cgnonbondedparmindex)
        else
            print *, "Error: NONBONDED_PARM_INDEX flag not found"
            close(io_unit)
            return
        end if
    
        call pick_arrays(io_unit, "%FLAG LENNARD_JONES_SIGMA", tpformat, iffound)
        if (iffound) then
            if (.not. allocated(cgnonbondedparms)) then
                allocate(cgnonbondedparms(2, max_param_index))
            end if
        
            read(io_unit, tpformat) cgnonbondedparms(1, 1:max_param_index)  
        else
            print *, "Error: LENNARD_JONES_SIGMA flag not found"
            close(io_unit)
            return
        end if
    
        call pick_arrays(io_unit, "%FLAG LENNARD_JONES_EPSILON", tpformat, iffound)
        if (iffound) then
            read(io_unit, tpformat) cgnonbondedparms(2, 1:max_param_index)  
        else
            print *, "Error: LENNARD_JONES_EPSILON flag not found"
            close(io_unit)
            return
        end if
        cgnonbondedparms(1, :) = cgnonbondedparms(1, :) * NM_TO_ANG
        cgnonbondedparms(2, :) = cgnonbondedparms(2, :) * KJ_TO_KCAL

        do i = 1, cgnatomtype
            do j = 1, cgnatomtype
                idx = (i - 1) * cgnatomtype + j
                ptr = cgnonbondedparmindex(idx)
            
                if (ptr > 0 .and. ptr <= max_param_index) then
                    self%LJ_params(i, j, 1) = cgnonbondedparms(1, ptr)  ! sigma
                    self%LJ_params(i, j, 2) = cgnonbondedparms(2, ptr)  ! epsilon
                else
                    self%LJ_params(i, j, 1) = 0.0d0
                    self%LJ_params(i, j, 2) = 0.0d0
                end if
            end do
        end do
    else 
        call pick_arrays(io_unit, "%FLAG NONBONDED_PARM_INDEX", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG LENNARD_JONES_SIGMA", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG LENNARD_JONES_EPSILON", tpformat, iffound, skip_data=.true.)
    
        if (.not. allocated(cgnonbondedparmindex)) then
            allocate(cgnonbondedparmindex(0))
        end if
        if (.not. allocated(cgnonbondedparms)) then
            allocate(cgnonbondedparms(2, 0))
        end if
    
    end if    
    
    if (self%virtualSitesN_num > 0) then
        call pick_arrays(io_unit, "%FLAG virtualSitesN", tpformat, iffound)
        if (iffound) then
            allocate(tparray(6, self%virtualSitesN_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,6), j=1,self%virtualSitesN_num)
            do i = 1, self%virtualSitesN_num
                self%virtualSitesN(i,:) = tparray(:,i)
            end do
            deallocate(tparray)
        end if
    else
        call pick_arrays(io_unit, "%FLAG virtualSitesN", tpformat, iffound, skip_data=.true.)
    end if

    if (self%virtualSites2_num > 0) then
        call pick_arrays(io_unit, "%FLAG virtualSites2_ATOMS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(4, self%virtualSites2_num))  
            read(io_unit, tpformat) ((tparray(i,j), i=1,4), j=1,self%virtualSites2_num)
            do i = 1, self%virtualSites2_num
                self%virtualSites2_atoms(i,:) = tparray(:,i)
            end do
        end if

        call pick_arrays(io_unit, "%FLAG virtualSites2_WEIGHTS", tpformat, iffound)
        if (iffound) then
            allocate(tpweights(1, self%virtualSites2_num))  
            read(io_unit, tpformat) ((tpweights(i,j), i=1,1), j=1,self%virtualSites2_num)

            do i = 1, self%virtualSites2_num
                if (tparray(2,i) == 2) then  
                    self%virtualSites2_weights(i,:) = tpweights(:,i) * 10d0
                else
                    self%virtualSites2_weights(i,:) = tpweights(:,i)
                end if
            end do
            deallocate(tparray)
            deallocate(tpweights)
        end if
    else
        call pick_arrays(io_unit, "%FLAG virtualSites2_ATOMS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG virtualSites2_WEIGHTS", tpformat, iffound, skip_data=.true.)
    end if

    if (self%virtualSites3_num > 0) then
        call pick_arrays(io_unit, "%FLAG virtualSites3_ATOMS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(5, self%virtualSites3_num))  
            read(io_unit, tpformat) ((tparray(i,j), i=1,5), j=1,self%virtualSites3_num)
            do i = 1, self%virtualSites3_num
                self%virtualSites3_atoms(i,:) = tparray(:,i)
            end do
        end if

        call pick_arrays(io_unit, "%FLAG virtualSites3_WEIGHTS", tpformat, iffound)
        if (iffound) then
            allocate(tpweights(3, self%virtualSites3_num)) 
            read(io_unit, tpformat) ((tpweights(i,j), i=1,3), j=1,self%virtualSites3_num)
            tpweights(3,:) = 0.1d0*tpweights(3,:)
            do i = 1, self%virtualSites3_num
                if (tparray(2,i) == 2) then  
                    self%virtualSites3_weights(i,2) = tpweights(2,i) * 10d0
                    self%virtualSites3_weights(i,1) = tpweights(1,i)
                    self%virtualSites3_weights(i,3) = tpweights(3,i)  
                else
                    self%virtualSites3_weights(i,:) = tpweights(:,i)
                end if
            end do
            deallocate(tparray)
            deallocate(tpweights)
        end if
    else
        call pick_arrays(io_unit, "%FLAG virtualSites3_ATOMS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG virtualSites3_WEIGHTS", tpformat, iffound, skip_data=.true.)
    end if


    if (self%constraint_num > 0) then
        call pick_arrays(io_unit, "%FLAG CONSTRAINT_PAIRS", tpformat, iffound)
        if (iffound) then
            allocate(tparray(2, self%constraint_num))
            read(io_unit, tpformat) ((tparray(i,j), i=1,2), j=1,self%constraint_num)
            do i = 1, self%constraint_num
                self%constraint(i,1) = tparray(1,i)
                self%constraint(i,2) = tparray(2,i)
            end do
            deallocate(tparray)
        end if

        call pick_arrays(io_unit, "%FLAG CONSTRAINT_LENGTH", tpformat, iffound)
        if (iffound) read(io_unit, tpformat) self%constraint_length(1:self%constraint_num)
        self%constraint_length = self%constraint_length * NM_TO_ANG 
        
    else
        call pick_arrays(io_unit, "%FLAG CONSTRAINT_PAIRS", tpformat, iffound, skip_data=.true.)
        call pick_arrays(io_unit, "%FLAG CONSTRAINT_LENGTH", tpformat, iffound, skip_data=.true.)
    end if

    call pick_arrays(io_unit, "%FLAG BOX_DIMENSIONS", tpformat, iffound)
    if (iffound) then
       read(io_unit, tpformat) cgcellalpha, cgcell(1:3)
       cgcellbeta = cgcellalpha; cgcellgamma = cgcellalpha
    end if

    close(io_unit)
end subroutine read_top_file

subroutine init(self, data_path, topfilename)
    use public
    class(itp_info) :: self
    character(len=*), intent(in) :: data_path
    character(len=*), intent(in), optional :: topfilename

    integer :: tpmol, vs_index, sub_index, ires, jres, imol, tpnum 
    real*8 :: w1, w2, w3, mass_sum  
    integer, allocatable :: raw_atoms(:), valid_atoms(:) 

    integer :: i,j,iatom,jatom,latom,index,tpindex,tpindex2
    integer ::icst,jcst,kcst,icst2,jcst2,iangle,iatom2,jatom2,katom,angleiatom,anglejatom,anglekatom,maxcstinatom,maxangleinatom
    integer,allocatable ::tpcgatomtype(:),tpcstcount(:),tpatom2cst(:,:),tpanglecount(:),tpatom2angle(:,:)

    real*8,allocatable :: tpmatrix(:,:),tpjacobimat(:,:)
    real*8 :: tpvalue,dis1,dis2,dis3,tpsigma,tpeps
    logical :: ifclosedcst,iffound

    character(len=256) :: full_topfilename
    integer,allocatable :: tpatommark(:),tpbondatom(:)
    
    self%data_path = data_path
    full_topfilename = trim(data_path) 

    call self%read_top_file(full_topfilename)

    cgnatom = self%atom_num; cgcsttol = 0.001d0 
    ncst = self%constraint_num
    allocate(cgprecoor(3,self%atom_num)); cgprecoor = 0d0
    allocate(cgmass(cgnatom)); cgmass = self%mass
    allocate(cgmassinv(cgnatom)); cgmassinv = 1d0/cgmass

    if (ncst > 0) then
        allocate(cst_reduced_mass(self%constraint_num)); cst_reduced_mass = 0d0
        do index = 1, self%constraint_num
            iatom = self%constraint(index, 1)
            jatom = self%constraint(index, 2)
            cst_reduced_mass(index) = 1d0/(cgmassinv(iatom) + cgmassinv(jatom))
        end do

    
        allocate(tpcstcount(self%atom_num)); tpcstcount(:) = 0
        do index = 1, self%constraint_num
            iatom = self%constraint(index, 1)
            jatom = self%constraint(index, 2)
            tpcstcount(iatom) = tpcstcount(iatom) + 1 
            tpcstcount(jatom) = tpcstcount(jatom) + 1 
        end do
        maxcstinatom = maxval(tpcstcount) 

        allocate(tpatom2cst(maxcstinatom,self%atom_num))
        tpcstcount(:) = 0; tpatom2cst(:,:) = 0  
        do index = 1, self%constraint_num
            iatom = self%constraint(index, 1)
            jatom = self%constraint(index, 2)
            tpcstcount(iatom) = tpcstcount(iatom) + 1
            tpcstcount(jatom) = tpcstcount(jatom) + 1
       
            tpatom2cst(tpcstcount(iatom),iatom) = index
            tpatom2cst(tpcstcount(jatom),jatom) = index
        end do
    else
        allocate(cst_reduced_mass(0))
        allocate(tpcstcount(0), tpatom2cst(0,0))
        maxcstinatom = 0
    end if
   
    if (self%angle_num > 0) then
        allocate(tpanglecount(self%atom_num)); tpanglecount(:) = 0
        do index = 1, self%angle_num
            jatom = self%angle_jatom(index) 
            tpanglecount(jatom) = tpanglecount(jatom) + 1
        end do
        maxangleinatom = maxval(tpanglecount)  
    
        allocate(tpatom2angle(maxangleinatom,self%atom_num))
        tpanglecount(:) = 0; tpatom2angle(:,:) = 0
        do index = 1, self%angle_num
            jatom = self%angle_jatom(index)
            tpanglecount(jatom) = tpanglecount(jatom) + 1
            tpatom2angle(tpanglecount(jatom),jatom) = index
        end do
    else
        allocate(tpanglecount(0), tpatom2angle(0,0))
        maxangleinatom = 0
    end if

    if (ncst > 0) then
        allocate(tpmatrix(self%constraint_num,self%constraint_num)); tpmatrix =0d0
        do icst = 1, self%constraint_num
            iatom = self%constraint(icst, 1) 
            jatom = self%constraint(icst, 2) 
            do jcst = 1,  self%constraint_num
                iatom2 = self%constraint(jcst, 1) 
                jatom2 = self%constraint(jcst, 2) 
            
                if ( icst == jcst ) then
                    tpmatrix(icst,jcst) = 1d0; cycle
                end if
    
    
                angleiatom = 0; anglejatom = 0; anglekatom = 0       
                if ( iatom2 == iatom ) then
                    anglejatom = iatom; angleiatom = jatom; anglekatom = jatom2
                else if ( iatom2 == jatom ) then
                    anglejatom = jatom; angleiatom = iatom; anglekatom = jatom2
                else if ( jatom2 == iatom ) then
                    anglejatom = iatom; angleiatom = jatom; anglekatom = iatom2
                else if ( jatom2 == jatom ) then
                    anglejatom = jatom; angleiatom = iatom; anglekatom = iatom2
                else
                    cycle
                end if
    
                tpvalue = cgmassinv(anglejatom)/(cgmassinv(anglejatom)+cgmassinv(angleiatom))

                ifclosedcst = .false.
                do index = 1, tpcstcount(angleiatom)
                    kcst = tpatom2cst(index, angleiatom)
                    if ( anglekatom == self%constraint(kcst, 1) .or.  anglekatom == self%constraint(kcst, 2) ) then
                        dis1 = self%constraint_length(icst) 
                        dis2 = self%constraint_length(jcst) 
                        dis3 = self%constraint_length(kcst) 
                        tpmatrix(icst,jcst) = tpvalue * (dis1*dis1+dis2*dis2-dis3*dis3)/(2.0*dis1*dis2)
                        ifclosedcst = .true.; exit
                    end if
                end do
            
                if ( ifclosedcst .eqv. .false. ) then
                    if (self%angle_num > 0 .and. tpanglecount(anglejatom) > 0) then
                        do index = 1, tpanglecount(anglejatom)
                            iangle = tpatom2angle(index,anglejatom) 
                
                            if ( ( (self%angle_iatom(iangle) == angleiatom) .and. (self%angle_katom(iangle) == anglekatom) ) .or. &
                                 ( (self%angle_iatom(iangle) == anglekatom) .and. (self%angle_katom(iangle) == angleiatom) ) ) then
                                tpmatrix(icst,jcst) = tpvalue * cos(self%angle_equil_value(iangle) )
                                exit
                            end if
                        end do
                    end if
                end if

            end do
        end do

        allocate(tpjacobimat(self%constraint_num,self%constraint_num)); tpjacobimat = 0d0

        call matrixinverse(tpmatrix, tpjacobimat)
    
        do icst = 1, self%constraint_num
            do jcst = 1, self%constraint_num
                if ( abs(tpjacobimat(icst,jcst)) < 0.1d0 ) tpjacobimat(icst,jcst) = 0d0
            end do
        end do

    
        allocate(jacobicstindex(ncst+1)); jacobicstindex = 0; index = 0
        do icst = 1, self%constraint_num
            do jcst = 1, self%constraint_num
                if ( abs(tpjacobimat(icst,jcst)) < 0.1d0 ) then
                    tpjacobimat(icst,jcst) = 0d0
                else
                    index = index + 1
                end if
            end do
            jacobicstindex(icst+1) = index
        end do
        allocate(jacobicstlist(index),jacobicstval(index))
        index = 0; jacobicstlist = 0; jacobicstval = 0d0
        do icst = 1, self%constraint_num
            do jcst = 1, self%constraint_num
                if ( tpjacobimat(icst,jcst) == 0d0 ) cycle
                index = index + 1
                jacobicstlist(index) = jcst    
                jacobicstval(index) = tpjacobimat(icst,jcst)
            end do
        end do
    else
        allocate(tpmatrix(0,0), tpjacobimat(0,0))
        allocate(jacobicstindex(1)); jacobicstindex = 0
        allocate(jacobicstlist(0), jacobicstval(0))
    end if

    nvirtualsite_outofplane = 0
    do sub_index = 1, self%virtualSites3_num
        if (self%virtualSites3_atoms(sub_index, 2) == 4) then  
            nvirtualsite_outofplane = nvirtualsite_outofplane + 1
        end if
    end do

    nvirtualsite = nvirtualsite_outofplane + self%virtualSitesN_num + self%virtualSites2_num + &
                   (self%virtualSites3_num - nvirtualsite_outofplane)

    if (nvirtualsite > 0) then
        allocate(virtualsites(nvirtualsite))
        vs_index = 0
        if (nvirtualsite_outofplane > 0) then
            do sub_index = 1, self%virtualSites3_num
                if (self%virtualSites3_atoms(sub_index, 2) /= 4) cycle  
                vs_index = vs_index + 1
                virtualsites(vs_index)%siteatom = self%virtualSites3_atoms(sub_index, 1)  
                virtualsites(vs_index)%sitetype = 4  
                allocate(virtualsites(vs_index)%atomlist(3))
                virtualsites(vs_index)%atomlist = self%virtualSites3_atoms(sub_index, 3:5)
                allocate(virtualsites(vs_index)%weights(3))
                virtualsites(vs_index)%weights = self%virtualSites3_weights(sub_index, :)
                allocate(virtualsites(vs_index)%weightdx(0))
                virtualsites(vs_index)%weightp = 0.0d0  
            end do
        end if

        ! virtualSitesN
        if (self%virtualSitesN_num > 0) then
            do sub_index = 1, self%virtualSitesN_num
                vs_index = vs_index + 1
                virtualsites(vs_index)%siteatom = self%virtualSitesN(sub_index, 1)  
                virtualsites(vs_index)%sitetype = self%virtualSitesN(sub_index, 2) 
                raw_atoms = self%virtualSitesN(sub_index, 3:6)
                valid_atoms = pack(raw_atoms, raw_atoms > 0)
                allocate(virtualsites(vs_index)%atomlist(size(valid_atoms)))
                virtualsites(vs_index)%atomlist = valid_atoms
                allocate(virtualsites(vs_index)%weights(size(valid_atoms)))
                
                mass_sum = sum(self%mass(virtualsites(vs_index)%atomlist))
                virtualsites(vs_index)%weights = self%mass(virtualsites(vs_index)%atomlist) / mass_sum
                allocate(virtualsites(vs_index)%weightdx(0))
                virtualsites(vs_index)%weightp = 0.0d0
            end do
        end if

        ! virtualSites2（2原子，TwoParticleAverageSite）
        if (self%virtualSites2_num > 0) then
            do sub_index = 1, self%virtualSites2_num
                vs_index = vs_index + 1
                virtualsites(vs_index)%siteatom = self%virtualSites2_atoms(sub_index, 1)  
                virtualsites(vs_index)%sitetype = self%virtualSites2_atoms(sub_index, 2)  
                allocate(virtualsites(vs_index)%atomlist(2))
                virtualsites(vs_index)%atomlist = self%virtualSites2_atoms(sub_index, 3:4)
                w1 = self%virtualSites2_weights(sub_index, 1)

                select case(virtualsites(vs_index)%sitetype)
                    case(1)  ! weights = [1-w1, w1]
                        allocate(virtualsites(vs_index)%weights(2))
                        virtualsites(vs_index)%weights = [1.0d0 - w1, w1]
                        allocate(virtualsites(vs_index)%weightdx(0))
                        virtualsites(vs_index)%weightp = 0.0d0
                    case(2)  ! weights = [1,0], weightdx = [-0.5,0.5], weightp = w1
                        allocate(virtualsites(vs_index)%weights(2))
                        virtualsites(vs_index)%weights = [1.0d0, 0.0d0]
                        allocate(virtualsites(vs_index)%weightdx(2))
                        virtualsites(vs_index)%weightdx = [-0.5d0, 0.5d0]
                        virtualsites(vs_index)%weightp = w1
                    case default
                        print *,"uncognized virtualSites2 type ",sub_index,virtualsites(vs_index)%sitetype
                        stop
                end select
            end do
        end if


        ! virtualSites3（非平面外位点，sitetype=1/2，ThreeParticleAverageSite）
        if (self%virtualSites3_num > 0) then
            do sub_index = 1, self%virtualSites3_num
                if (self%virtualSites3_atoms(sub_index, 2) == 4) cycle  
                vs_index = vs_index + 1
                virtualsites(vs_index)%siteatom = self%virtualSites3_atoms(sub_index, 1)  
                virtualsites(vs_index)%sitetype = self%virtualSites3_atoms(sub_index, 2)  
                allocate(virtualsites(vs_index)%atomlist(3))
                virtualsites(vs_index)%atomlist = self%virtualSites3_atoms(sub_index, 3:5)
                w1 = self%virtualSites3_weights(sub_index, 1)
                w2 = self%virtualSites3_weights(sub_index, 2)
                w3 = self%virtualSites3_weights(sub_index, 3)  

                select case(virtualsites(vs_index)%sitetype)
                    case(1)  ! weights = [1-w1-w2, w1, w2]
                        allocate(virtualsites(vs_index)%weights(3))
                        virtualsites(vs_index)%weights = [1.0d0 - w1 - w2, w1, w2]
                        allocate(virtualsites(vs_index)%weightdx(0))
                        virtualsites(vs_index)%weightp = 0.0d0
                    case(2)  ! weights = [1,0,0], weightdx = [-1,1-w1,w1], weightp = w2
                        allocate(virtualsites(vs_index)%weights(3))
                        virtualsites(vs_index)%weights = [1.0d0, 0.0d0, 0.0d0]
                        allocate(virtualsites(vs_index)%weightdx(3))
                        virtualsites(vs_index)%weightdx = [-1.0d0, 1.0d0 - w1, w1]
                        virtualsites(vs_index)%weightp = w2

                    case default
                        print *,"uncognized virtualSites3 type ",sub_index,virtualsites(vs_index)%sitetype
                        stop
                end select
            end do
        end if

        do vs_index = 1, nvirtualsite
            tpindex = virtualsites(vs_index)%siteatom  
            cgmass(tpindex) = 1d0

            do icst = 1, ncst
                iatom = self%constraint(icst, 1)
                jatom = self%constraint(icst, 2)
                if ((iatom == tpindex) .or. (jatom == tpindex)) then
                    print *,"virtual site atom is in the constraint list ",vs_index,tpindex,iatom,jatom
                    stop
                end if
            end do

            !do i = 1, self%bond_num
            !    iatom = self%iatom(i)
            !    jatom = self%jatom(i)
            !    if ((iatom == tpindex) .or. (jatom == tpindex)) then
            !        print *,"virtual site atom is in the bond list ",vs_index,tpindex,iatom,jatom
            !        stop
            !    end if
            !end do

            !do i = 1, self%angle_num
            !    iatom = self%angle_iatom(i)
            !    jatom = self%angle_jatom(i)
            !    katom = self%angle_katom(i)
            !    if ((iatom == tpindex) .or. (jatom == tpindex) .or. (katom == tpindex)) then
            !        print *,"virtual site atom is in the angle list ",vs_index,tpindex,iatom,jatom,katom
            !        stop
            !    end if
            !end do

            !do i = 1, self%dihedral_num
            !    iatom = self%dihedral_atom_0(i)
            !    jatom = self%dihedral_atom_1(i)
            !    katom = self%dihedral_atom_2(i)
            !    latom = self%dihedral_atom_3(i)
            !    if ((iatom == tpindex) .or. (jatom == tpindex) .or. &
            !        (katom == tpindex) .or. (latom == tpindex)) then
            !        print *,"virtual site atom is in the dihedral list ",vs_index,tpindex,iatom,jatom,katom,latom
            !        stop
            !    end if
            !end do
        end do
    else 
        allocate(virtualsites(0))
    end if

    allocate(cgcoor(3,cgnatom),cgforce(3,cgnatom),cgvel(3,cgnatom))

    krf = 1d0 / (2d0 * rcut**3)
    crf = 1d0 / rcut + krf * rcut**2
    if ( rcut > 10000.0d0 ) then
       krf = 0d0; crf = 0d0
    end if

    cgeself = 0d0
    do i = 1, cgnatom
       tpvalue = self%charge(i); if ( tpvalue == 0d0 ) cycle
       cgeself = cgeself + eleccoef/epsilon_r*tpvalue*tpvalue*0.5d0 * ( - crf)
    end do

    cgnbond = self%bond_num

    tpnum = cgnbond + ncst
    do index = 1, nvirtualsite
       tpnum = tpnum + size(virtualsites(index)%atomlist)
    end do
    allocate(tpatommark(cgnatom),tpbondatom(3*tpnum))

    if ( tpnum > 0 ) then
       do index = 1, cgnbond
          tpbondatom(3*index-2) = self%iatom(index)
          tpbondatom(3*index-1) = self%jatom(index)
       end do
       do index = 1, ncst
          i = cgnbond + index
          tpbondatom(3*i-2) = self%constraint(index, 1)
          tpbondatom(3*i-1) = self%constraint(index, 2)
       end do
       i = cgnbond + ncst
       do index = 1, nvirtualsite
          do j = 1, size(virtualsites(index)%atomlist)
             i = i + 1
             tpbondatom(3*i-2) = virtualsites(index)%siteatom
             tpbondatom(3*i-1) = virtualsites(index)%atomlist(j)
          end do
       end do

       !call public_divide_mol_by_disjoint_set_union(tpatommark, cgnmol, cgnatom, tpnum, tpbondatom)
       call public_divide_mol_by_deep_first_search(tpatommark, cgnmol, cgnatom, tpnum, tpbondatom)

       allocate(cgnatompermol(cgnmol)); cgnatompermol=0
       do iatom = 1, cgnatom
          i = tpatommark(iatom)
          if ( i == 0 ) then
             print *,"unmarked bond atom ",iatom; stop
          end if
          cgnatompermol(i) = cgnatompermol(i) + 1
       end do

    else

       if ( cgnres /= cgnatom ) then
          print *,"bond, cst and virtual site number ",cgnbond,ncst,nvirtualsite      
          stop "residue number and atom atom number are not consistent!"
       end if
       !cgnmol = cgnatom/3
       !allocate(cgnatompermol(cgnmol)); cgnatompermol=3

       cgnmol = cgnatom
       allocate(cgnatompermol(cgnmol)); cgnatompermol=1

    end if

    iatom=0; ires=0; jres = 1; imol=1; tpnum=cgnatompermol(imol)
    allocate(cgmolindex(cgnmol+1)); cgmolindex=0
    do imol = 1, cgnmol
       iatom = iatom + cgnatompermol(imol)
       do
          ires = ires + 1
          if ( iatom == cgresindex(ires+1) ) then
             cgmolindex(imol+1) = ires
             exit
          end if
       end do
     end do

     allocate(cgatommol(cgnatom),cgresmol(cgnres)); cgatommol=0; cgresmol=0
     allocate(cgcharge(cgnatom),cgrescharge(cgnres),cgmolcharge(cgnmol),cgmolmass(cgnmol),cgmolcom(3,cgnmol))
     cgcharge=self%charge
     allocate(cgname(self%atom_num)); cgname = self%pos_type
     cgrescharge=0d0; cgmolcharge=0d0; cgmolmass=0d0; cgmolcom=0d0
     cgnbiomol = 0
     do imol=1, cgnmol
        do ires=cgmolindex(imol)+1, cgmolindex(imol+1)
           cgresmol(ires) = imol
           if ( cgnbiomol == 0 ) then
              if ( cgresname(ires) == "W   " ) cgnbiomol = imol - 1
           end if
           do iatom = cgresindex(ires)+1, cgresindex(ires+1)
              cgatommol(iatom) = imol
              cgrescharge(ires) = cgrescharge(ires) + cgcharge(iatom)
              cgmolmass(imol) = cgmolmass(imol) + cgmass(iatom)
           end do
        end do
        cgmolcharge(imol) = sum(cgrescharge(cgmolindex(imol)+1:cgmolindex(imol+1)))
     end do
     allocate(cgatomtype(cgnatomtype)); cgatomtype = self%atom_type

     cgnmolgroup = 1; tpmol = 1; tpnum = cgnatompermol(tpmol)
     allocate(cgmolgroupindex(cgnmol+1)); cgmolgroupindex = [0]

     do imol = 2, cgnmol
        if ( (cgnatompermol(imol) /= tpnum) .or. &
             (cgmolindex(imol+1)-cgmolindex(imol)/=cgmolindex(tpmol+1)-cgmolindex(tpmol)) ) then
           cgnmolgroup = cgnmolgroup + 1; tpmol = imol; tpnum = cgnatompermol(imol)
           cgmolgroupindex = [cgmolgroupindex,imol-1]
        else
           if ( cgnatompermol(imol) == 1 ) cycle
           jres = cgmolindex(tpmol)+1
           do ires = cgmolindex(imol)+1, cgmolindex(imol+1)
              if (cgresname(ires) /= cgresname(jres)) then
                 cgnmolgroup = cgnmolgroup + 1; tpmol = imol; tpnum = cgnatompermol(imol)
                 cgmolgroupindex = [cgmolgroupindex,imol-1]
                 exit
              end if
              jres = jres + 1
           end do
        end if
     end do
     cgmolgroupindex = [cgmolgroupindex,cgnmol]

     if  ( procid == 0 ) then
         write(iosiminfo,"(/,20x,a)") "MARTINI System Info"
         write(iosiminfo,"(a)") "============================================================="

         write(iosiminfo,"(a)") "Sequence Info"
         write(iosiminfo,"(20(a4))") cgresname(1:cgmolindex(cgnbiomol+1))
         write(iosiminfo,*)
    
         write(iosiminfo,"(a)") "Residue Info"
         do imol = 1, cgnmol
            if ( cgnatompermol(imol) == 1 ) cycle
            ires = cgmolindex(imol)+1; jres = cgmolindex(imol+1)
            if ( (jres-ires+1) == 1 ) cycle
            write(iosiminfo,"(3(a,i6,3x),a,f10.3)") "mol   ",imol," nres",cgmolindex(imol+1)-cgmolindex(imol),"natom ",cgnatompermol(imol),"charge",cgmolcharge(imol)
         end do

         write(iosiminfo,*); write(iosiminfo,"(a)") "Overall Info"
         write(iosiminfo,"(4(a,i6,3x),a,f10.3)") "nmol ",cgnmol,"nres ",cgnres,  &
                 "natom ",cgnatom,"virtual site ",nvirtualsite, &
                 "total charge ",sum(cgmolcharge)
         write(iosiminfo,"(a,3f10.3)") "Box Size  ",cgcell(:)    
         flush(iosiminfo)
     end if

end subroutine

end module
