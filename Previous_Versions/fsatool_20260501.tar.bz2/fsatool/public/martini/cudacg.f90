module cudacg
    use itp_reader
    use utils
    use martini
    use cudacgpb
    implicit none

    real*8,device :: KJ_TO_KCAL_d,PI_d,cgeself_d,restraint_force_const_d

    real*8,device,pointer :: cgprecoor_d(:,:)

    integer,private :: njacobicst
    integer,device,private :: ncst_d, njacobicst_d
    real*8,device,private :: cgcsttol_d,cgcstlowtol_d,cgcstuptol_d
    real*8,device,allocatable,private :: cgmassinv_d(:),jacobicstval_d(:),cgcstlength_d(:),cgcstdelta_d(:),cgcstsumdelta_d(:),cst_reduced_mass_d(:)
    integer,device,allocatable,private :: cgcstatoms_d(:,:),jacobicstindexij_d(:,:),cgexcludepairs_d(:,:)
    logical,device,private :: cstifconverged_d
    
    real*8,device :: box_size_d(3), half_box_d(3)

    type gpuvirtualsitetype
        integer :: siteatom, sitetype, natoms
        real*8 :: weightp
        integer,allocatable,device :: atomlist(:)
        real*8,allocatable,device :: weights(:)
        real*8,allocatable,device :: weightdx(:)
    end type
    type(gpuvirtualsitetype),allocatable,managed :: virtualsites_d(:)
    integer,device,private :: nvirtualsite_d, nvirtualsite_outofplane_d

    integer,private :: cgnbondedblock,cgnbondblock,cgnangle1block,cgnangle2block,cgnangle10block,cgndihedral1block,cgndihedral2block,cgndihedral3block,cgndihedral4block
    integer,device,private :: cgnbondblock_d,cgnangle1block_d,cgnangle2block_d,cgnangle10block_d,cgndihedral1block_d,cgndihedral2block_d,cgndihedral3block_d,cgndihedral4block_d

    ! bond variables
    real*8 :: cgebond
    integer,private,device :: cgnbond_d
    integer,private,device,allocatable :: cgbondatoms_d(:,:),cgbondfunctype_d(:)
    real,private,device,allocatable :: cgbondforceconst_d(:),cgbondeqval_d(:)

    ! angle variables
    integer,private :: cgnangle,cgnangle2,cgnangle10,cgnangle1
    real*8 :: cgeangle,cgeangle2,cgeangle10,cgeangle1
    integer,private,device :: cgnangle_d,cgnangle2_d,cgnangle10_d,cgnangle1_d
    integer,private,device,allocatable :: cgangleatoms_d(:,:),cganglefunctype_d(:)
    real,private,device,allocatable :: cgangleforceconst_d(:),cgangleeqval_d(:)
    integer,private,device,allocatable :: cgangletype2_index_d(:),cgangletype10_index_d(:),cgangletype1_index_d(:)

    ! dihedral variables
    integer :: cgndihedral,cgndihedral1,cgndihedral2,cgndihedral3,cgndihedral4,idx
    real*8 :: cgedihedral,cgedihedral1,cgedihedral2,cgedihedral3,cgedihedral4
    integer,device :: cgndihedral_d,cgndihedral1_d,cgndihedral2_d,cgndihedral3_d,cgndihedral4_d
    integer,device,allocatable :: cgdihedralatoms_d(:,:),cgdihedralfunctype_d(:)
    real,device,allocatable :: cgdihedralforceconst_d(:),cgdihedraleqval_d(:)
    integer,device,allocatable :: cgdihedraltype1_index_d(:),cgdihedraltype2_index_d(:),cgdihedraltype3_index_d(:),cgdihedraltype4_index_d(:)
    integer,device,allocatable :: cgdihedralcoefn_d(:)
    real,device,allocatable :: cgdihedral_extra_real_d(:,:) 

    ! nonbond variables
    integer,private :: cgblocknbdim,cgnblocknb
    integer,device,private :: cgblocknbdim_d,cgnblocknb_d
    integer,device,dimension(:),allocatable,private :: cgexcludedatomindex_d,cgnexcludedatoms_d,cgexcludedatomlist_d
    integer,device,dimension(:,:),allocatable,private :: cgblocknbskip_d,cgblocknbpos_d

    real*8, device, private :: DISCUT_INV_d

    ! force variables for debug
    REAL*8, device, DIMENSION(:,:), POINTER :: total_force_d
    REAL*8, device, DIMENSION(:,:), POINTER :: bond_force_d, angle_force_1_d, angle_force_2_d, angle_force_10_d, dihedral_force_1_d, dihedral_force_2_d, dihedral_force_3_d, dihedral_force_4_d, elecS_exclude_force_d

contains

subroutine cudacg_initialize(the_data)
    type(itp_info) :: the_data
    integer :: i,icst,index,iatom,jatom,ibond,iangle,idihedral,isite, max_atoms, natoms
    integer,allocatable :: cgangletype1_index(:),cgangletype2_index(:),cgangletype10_index(:),cgdihedraltype1_index(:),cgdihedraltype2_index(:),cgdihedraltype3_index(:),cgdihedraltype4_index(:)
    integer,allocatable :: cgexcludedatomindex(:), cgblocknbpos(:,:), jacobicstindexij(:,:)
    real*8 :: tpvalue

    ! initialize global parameters
    cgcell_d = cgcell; cgcellinv_d = cgcellinv

    KJ_TO_KCAL_d = KJ_TO_KCAL; PI_d = PI; cgifcalpot_d = .true.
    cgnatom_d = cgnatom; cgeself_d = cgeself
    krf_d = krf; crf_d = crf
    rcut_d=rcut; rcutsq_d=rcut**2

    DISCUT_INV_d = 1d0 / rcut

    cgnblockatom = (cgnatom-1)/32 + 1; cgnblockatom_d=cgnblockatom

    box_size_d(1:3) = cgcell(1:3); half_box_d(1:3) = cgcell(1:3) * 0.5d0

    cgcoor_d = cgcoor; cgforce_d = cgforce; cgvel_d = cgvel
    allocate(cgcharge_d(cgnatom)); cgcharge_d = cgcharge
    allocate(cgatomtype_d(cgnatom)); cgatomtype_d = cgatomtype 

    total_force_d => cgforce_d
    bond_force_d => cgforce_d;
    angle_force_1_d => cgforce_d;
    angle_force_2_d => cgforce_d;
    angle_force_10_d => cgforce_d;
    dihedral_force_1_d => cgforce_d;
    dihedral_force_2_d => cgforce_d;
    dihedral_force_3_d => cgforce_d;
    dihedral_force_4_d => cgforce_d;
    elecvdw_force_d => cgforce_d;
    elecS_exclude_force_d => cgforce_d;

  cgnatomtype_d = cgnatomtype
  allocate(cgnonbondedparmindex_d(cgnatomtype*cgnatomtype)); cgnonbondedparmindex_d = cgnonbondedparmindex
  allocate(cgnonbondedparms_d(2,size(cgnonbondedparms,2)))
  do i = 1, size(cgnonbondedparms,2)
     cgnonbondedparms_d(1,i) = cgnonbondedparms(1,i)**2
     cgnonbondedparms_d(2,i) = 4d0*cgnonbondedparms(2,i)
  end do

  ncst_d = ncst
  allocate(cgmassinv_d(cgnatom)); cgmassinv_d = cgmassinv
  
  if (ncst > 0) then
    restraint_force_const_d = restraint_force_const
    allocate(cgcstatoms_d(2,ncst))  
    do i = 1, ncst
       cgcstatoms_d(1:2,i) = the_data%constraint(i, 1:2)
    end do    
    allocate(cgcstlength_d(ncst)); cgcstlength_d = the_data%constraint_length
    allocate(cgcstdelta_d(ncst),cgcstsumdelta_d(ncst)); cgcstdelta_d = 0d0; cgcstsumdelta_d = 0d0
    allocate(cst_reduced_mass_d(ncst));cst_reduced_mass_d = cst_reduced_mass
  endif
  cgcstlowtol_d = 1d0 - 2d0*cgcsttol + cgcsttol*cgcsttol
  cgcstuptol_d = 1d0 + 2d0*cgcsttol + cgcsttol*cgcsttol
  cgcsttol_d = cgcsttol
  njacobicst = size(jacobicstlist); njacobicst_d = njacobicst
  if (njacobicst > 0) then
    allocate(jacobicstval_d(njacobicst));jacobicstval_d = jacobicstval
    allocate(jacobicstindexij(2,njacobicst),jacobicstindexij_d(2,njacobicst))    
    do icst = 1, ncst
       do index = jacobicstindex(icst)+1, jacobicstindex(icst+1)
          jacobicstindexij(1,index) = icst;jacobicstindexij(2,index) = jacobicstlist(index)
       enddo
    end do
    jacobicstindexij_d = jacobicstindexij
  end if
  eleccoef_d = eleccoef/epsilon_r

  nvirtualsite_d = nvirtualsite
  nvirtualsite_outofplane_d = nvirtualsite_outofplane
 
  if (nvirtualsite > 0) then  
    allocate(virtualsites_d(nvirtualsite))
  
    do isite = 1, nvirtualsite
      virtualsites_d(isite)%siteatom = virtualsites(isite)%siteatom
      virtualsites_d(isite)%sitetype = virtualsites(isite)%sitetype
      virtualsites_d(isite)%natoms = size(virtualsites(isite)%atomlist)
      virtualsites_d(isite)%weightp = virtualsites(isite)%weightp
    
      natoms = virtualsites_d(isite)%natoms
 
      allocate(virtualsites_d(isite)%atomlist(natoms))
      allocate(virtualsites_d(isite)%weights(natoms))
      allocate(virtualsites_d(isite)%weightdx(natoms))
    
      virtualsites_d(isite)%atomlist(:) = virtualsites(isite)%atomlist(:)
    
      if (allocated(virtualsites(isite)%weights)) then
        virtualsites_d(isite)%weights(:) = virtualsites(isite)%weights(:)
      else
        virtualsites_d(isite)%weights(:) = 0.0d0
      end if
    
      if (allocated(virtualsites(isite)%weightdx)) then
        if (size(virtualsites(isite)%weightdx) == natoms) then
          virtualsites_d(isite)%weightdx(:) = virtualsites(isite)%weightdx(:)
        else
          virtualsites_d(isite)%weightdx(:) = 0.0d0
        end if
      else
        virtualsites_d(isite)%weightdx(:) = 0.0d0
      end if
    end do
  end if

  ! prepare bond variables

  cgnbond = the_data%bond_num;
  cgnbond_d = cgnbond
  if (cgnbond > 0) then
    allocate(cgbondatoms_d(2,cgnbond),cgbondfunctype_d(cgnbond))
    allocate(cgbondforceconst_d(cgnbond),cgbondeqval_d(cgnbond))
    cgbondfunctype_d(:) = the_data%func_type(:)
    cgbondeqval_d(:) = the_data%equil_value(:)
    cgbondforceconst_d(:) = the_data%force_const(:)
    do ibond = 1, cgnbond
       cgbondatoms_d(1:2,ibond) = [the_data%iatom(ibond),the_data%jatom(ibond)]
    end do
  end if

  ! prepare angle variables

  cgnangle = the_data%angle_num; cgnangle_d = cgnangle
  if (cgnangle > 0) then
    allocate(cgangleatoms_d(3,cgnangle),cganglefunctype_d(cgnangle))
    cganglefunctype_d = the_data%angle_func_type(:)

    cgnangle2 = 0; cgnangle10 = 0; cgnangle1 = 0
    do iangle = 1, cgnangle
       select case(the_data%angle_func_type(iangle))
       case(1)
         cgnangle1 = cgnangle1 + 1
       case(2)
         cgnangle2 = cgnangle2 + 1
       case(10)
         cgnangle10 = cgnangle10 + 1
       case default
         stop "angle type error!"
       end select
    end do
    cgnangle2_d = cgnangle2; cgnangle10_d = cgnangle10; cgnangle1_d = cgnangle1

    if (cgnangle1 > 0) then
      allocate(cgangletype1_index(cgnangle1))
      allocate(cgangletype1_index_d(cgnangle1))
    endif
    if (cgnangle2 > 0) then
      allocate(cgangletype2_index(cgnangle2))
      allocate(cgangletype2_index_d(cgnangle2))
    endif
    if (cgnangle10 > 0) then
      allocate(cgangletype10_index(cgnangle10))
      allocate(cgangletype10_index_d(cgnangle10))
    endif

    cgnangle2 = 0; cgnangle10 = 0;cgnangle1 = 0
    do iangle = 1, cgnangle
       select case(the_data%angle_func_type(iangle))
       case(1)
         cgnangle1 = cgnangle1 + 1;
         if (allocated(cgangletype1_index)) cgangletype1_index(cgnangle1) = iangle
       case(2)
         cgnangle2 = cgnangle2 + 1; 
         if (allocated(cgangletype2_index)) cgangletype2_index(cgnangle2) = iangle
       case(10)
         cgnangle10 = cgnangle10 + 1; 
         if (allocated(cgangletype10_index)) cgangletype10_index(cgnangle10) = iangle
       end select
    end do

    if (cgnangle1 > 0) then
      cgangletype1_index_d = cgangletype1_index
    endif

    if (cgnangle2 > 0) then
      cgangletype2_index_d = cgangletype2_index
    endif
    
    if (cgnangle10 > 0) then
      cgangletype10_index_d = cgangletype10_index
    endif
    
    allocate(cgangleforceconst_d(cgnangle),cgangleeqval_d(cgnangle))
    cgangleforceconst_d = the_data%angle_force_const
    cgangleeqval_d = the_data%angle_equil_value
    
    do iangle = 1, cgnangle
       cgangleatoms_d(1,iangle) = the_data%angle_iatom(iangle)
       cgangleatoms_d(2,iangle) = the_data%angle_jatom(iangle)
       cgangleatoms_d(3,iangle) = the_data%angle_katom(iangle)
    end do
  endif 

  ! prepare dihedral variables
  cgndihedral = the_data%dihedral_num; cgndihedral_d = cgndihedral
  
  if (cgndihedral > 0) then
    allocate(cgdihedralatoms_d(4,cgndihedral),cgdihedralfunctype_d(cgndihedral))
    cgdihedralfunctype_d = the_data%dihedral_func_type(:)

    cgndihedral1 = 0; cgndihedral2 = 0; cgndihedral3 = 0; cgndihedral4 = 0
    do idihedral = 1, cgndihedral
      select case(the_data%dihedral_func_type(idihedral))
      case(1)
        cgndihedral1 = cgndihedral1 + 1
      case(2)
        cgndihedral2 = cgndihedral2 + 1
      case(3)
        cgndihedral3 = cgndihedral3 + 1
      case(4)
        cgndihedral4 = cgndihedral4 + 1
      case default
        stop "dihedral type error!"
      end select
    end do
    
    cgndihedral1_d = cgndihedral1; cgndihedral2_d = cgndihedral2
    cgndihedral3_d = cgndihedral3; cgndihedral4_d = cgndihedral4
    
    if (cgndihedral1 > 0) then
      allocate(cgdihedraltype1_index(cgndihedral1))
      allocate(cgdihedraltype1_index_d(cgndihedral1))
    endif
    
    if (cgndihedral2 > 0) then
      allocate(cgdihedraltype2_index(cgndihedral2))
      allocate(cgdihedraltype2_index_d(cgndihedral2))
    endif
    
    if (cgndihedral3 > 0) then
      allocate(cgdihedraltype3_index(cgndihedral3))
      allocate(cgdihedraltype3_index_d(cgndihedral3))
    endif
    
    if (cgndihedral4 > 0) then
      allocate(cgdihedraltype4_index(cgndihedral4))
      allocate(cgdihedraltype4_index_d(cgndihedral4))
    endif

    cgndihedral1 = 0; cgndihedral2 = 0; cgndihedral3 = 0; cgndihedral4 = 0
    do idihedral = 1, cgndihedral
      select case(the_data%dihedral_func_type(idihedral))
      case(1)
        cgndihedral1 = cgndihedral1 + 1
        if (allocated(cgdihedraltype1_index)) then
          cgdihedraltype1_index(cgndihedral1) = idihedral
        endif
      case(2)
        cgndihedral2 = cgndihedral2 + 1
        if (allocated(cgdihedraltype2_index)) then
          cgdihedraltype2_index(cgndihedral2) = idihedral
        endif
      case(3)
        cgndihedral3 = cgndihedral3 + 1
        if (allocated(cgdihedraltype3_index)) then
          cgdihedraltype3_index(cgndihedral3) = idihedral
        endif
      case(4)
        cgndihedral4 = cgndihedral4 + 1
        if (allocated(cgdihedraltype4_index)) then
          cgdihedraltype4_index(cgndihedral4) = idihedral
        endif
      end select
    end do
    
    if (cgndihedral1 > 0 .and. allocated(cgdihedraltype1_index_d)) then
      cgdihedraltype1_index_d = cgdihedraltype1_index
    endif
    
    if (cgndihedral2 > 0 .and. allocated(cgdihedraltype2_index_d)) then
      cgdihedraltype2_index_d = cgdihedraltype2_index
    endif
    
    if (cgndihedral3 > 0 .and. allocated(cgdihedraltype3_index_d)) then
      cgdihedraltype3_index_d = cgdihedraltype3_index
    endif
    
    if (cgndihedral4 > 0 .and. allocated(cgdihedraltype4_index_d)) then
      cgdihedraltype4_index_d = cgdihedraltype4_index
    endif

    if (cgndihedral1 + cgndihedral2 > 0) then
      allocate(cgdihedralforceconst_d(cgndihedral1+cgndihedral2))
      allocate(cgdihedraleqval_d(cgndihedral1+cgndihedral2))
      cgdihedralforceconst_d = the_data%dihedral_force_const
      cgdihedraleqval_d = the_data%dihedral_equil_value
    endif
    
    if (cgndihedral1 > 0) then
      allocate(cgdihedralcoefn_d(cgndihedral1))
      cgdihedralcoefn_d = the_data%dihedral_extra_int(:)
    endif
    
    if (cgndihedral3 + cgndihedral4 > 0) then
      allocate(cgdihedral_extra_real_d(6, cgndihedral3+cgndihedral4))
      cgdihedral_extra_real_d = the_data%dihedral_extra_real(1:6,:)
    endif

    do idihedral = 1, cgndihedral
      cgdihedralatoms_d(1,idihedral) = the_data%dihedral_atom_0(idihedral)
      cgdihedralatoms_d(2,idihedral) = the_data%dihedral_atom_1(idihedral)
      cgdihedralatoms_d(3,idihedral) = the_data%dihedral_atom_2(idihedral)
      cgdihedralatoms_d(4,idihedral) = the_data%dihedral_atom_3(idihedral)
    end do
    
  else
    cgndihedral1_d = 0; cgndihedral2_d = 0
    cgndihedral3_d = 0; cgndihedral4_d = 0
  end if

  cgnbondblock = (cgnbond-1)/32+1; cgnbondblock_d = cgnbondblock
  cgnangle1block = (cgnangle1-1)/32+1; cgnangle1block_d = cgnangle1block
  cgnangle2block = (cgnangle2-1)/32+1; cgnangle2block_d = cgnangle2block
  cgnangle10block = (cgnangle10-1)/32+1; cgnangle10block_d = cgnangle10block
  cgndihedral1block = (cgndihedral1-1)/32+1; cgndihedral1block_d = cgndihedral1block
  cgndihedral2block = (cgndihedral2-1)/32+1; cgndihedral2block_d = cgndihedral2block
  cgndihedral3block = (cgndihedral3-1)/32+1; cgndihedral3block_d = cgndihedral3block
  cgndihedral4block = (cgndihedral4-1)/32+1; cgndihedral4block_d = cgndihedral4block
  cgnbondedblock = cgnbondblock + cgnangle1block + cgnangle2block + cgnangle10block + &
                   cgndihedral1block + cgndihedral2block + cgndihedral3block + cgndihedral4block

  ! prepare nonbond variables

  cgnexcludepair_d = cgnexcludepair
  if (cgnexcludepair > 0) then
     allocate(cgblocknbpos(2,cgnexcludepair)); cgblocknbpos = 0
     index = 0
     do iatom = 1, the_data%atom_num
        do i = 1, cgnexcludedatoms(iatom)
           index = index + 1
           jatom = cgexcludedatomlist(index)
           cgblocknbpos(1:2,index) = [iatom,jatom]
        end do
     end do
     if ( cgnexcludepair /= index ) stop "exclude list error!"
     allocate(cgexcludepairs_d(2,cgnexcludepair))
     cgexcludepairs_d(1:2,1:cgnexcludepair) = cgblocknbpos(1:2,1:cgnexcludepair)
     deallocate(cgblocknbpos)
  endif

  if ( cgipb == 0 ) then

     cgblocknbdim=(cgnatom-1)/32+1; cgblocknbdim_d=cgblocknbdim
     cgnblocknb=cgblocknbdim*(1+cgblocknbdim)/2; cgnblocknb_d=cgnblocknb
     allocate(cgblocknbpos(2,cgnblocknb)); cgblocknbpos=1
     allocate(cgblocknbpos_d(2,cgnblocknb))
   
     do i = 2, cgnblocknb
        cgblocknbpos(1,i) = cgblocknbpos(1,i-1); cgblocknbpos(2,i) = cgblocknbpos(2,i-1) + 32
        if ( cgblocknbpos(2,i) > cgnatom ) then
           cgblocknbpos(1,i) = cgblocknbpos(1,i-1) + 32; cgblocknbpos(2,i) = cgblocknbpos(1,i)
           if ( cgblocknbpos(1,i) > cgnatom ) exit
        end if
     end do
     cgblocknbpos_d = cgblocknbpos
     
     if (cgnexcludepair > 0) then
       allocate(cgnexcludedatoms_d(cgnatom)); cgnexcludedatoms_d = cgnexcludedatoms
       allocate(cgexcludedatomlist_d(size(cgexcludedatomlist))); cgexcludedatomlist_d = cgexcludedatomlist
       allocate(cgexcludedatomindex(cgnatom+1)); cgexcludedatomindex = 0; i=0
       do iatom = 1, cgnatom
          i = i + cgnexcludedatoms(iatom)
          cgexcludedatomindex(iatom+1) = i
       end do
       allocate(cgexcludedatomindex_d(cgnatom+1)); cgexcludedatomindex_d = cgexcludedatomindex
   
     else
       allocate(cgnexcludedatoms_d(cgnatom)); cgnexcludedatoms_d = 0
       allocate(cgexcludedatomlist_d(1)); cgexcludedatomlist_d = 0
       allocate(cgexcludedatomindex(cgnatom+1)); cgexcludedatomindex = 0
       allocate(cgexcludedatomindex_d(cgnatom+1)); cgexcludedatomindex_d = 0
     end if
     allocate(cgblocknbskip_d(3,cgnblocknb*32)); cgblocknbskip_d=0
     if (cgnexcludepair > 0) then
       call cudacg_potforce_nonbond_init<<<cgnblocknb_d,32>>>()
     end if 
   
  else

     call cudacgpb_initialize()

  end if
end subroutine

attributes(global) subroutine cudacg_sum_force()
    integer :: i_coor, i_atom
    i_atom = (blockidx%x-1)*blockdim%x + threadidx%x
    if ( i_atom > cgnatom_d ) return
    do i_coor = 1, 3
       total_force_d(i_coor, i_atom) = bond_force_d(i_coor, i_atom) + angle_force_1_d(i_coor, i_atom) + angle_force_2_d(i_coor, i_atom) + angle_force_10_d(i_coor, i_atom) + dihedral_force_1_d(i_coor, i_atom) + dihedral_force_2_d(i_coor, i_atom) + dihedral_force_3_d(i_coor, i_atom) + dihedral_force_4_d(i_coor, i_atom) + elecvdw_force_d(i_coor, i_atom) + elecS_exclude_force_d(i_coor, i_atom)
    end do
end subroutine

subroutine cudacg_potforce(check)
  logical,intent(in),optional :: check

  if ( present(check) ) then
     allocate(bond_force_d(3,cgnatom), angle_force_1_d(3,cgnatom), angle_force_2_d(3,cgnatom), &
           angle_force_10_d(3,cgnatom), dihedral_force_1_d(3,cgnatom), dihedral_force_2_d(3,cgnatom), &
           dihedral_force_3_d(3,cgnatom), dihedral_force_4_d(3,cgnatom), elecvdw_force_d(3,cgnatom), &
           elecS_exclude_force_d(3,cgnatom))
     call cudacg_debug_cgforce_zero<<<(cgnatom-1)/32+1,32>>>()
  end if

    if ( cgipb == 0 ) then
       call cudacg_potforce_zero<<<(cgnatom-1)/32+1,32>>>()
       call cudacg_potforce_elecvdw<<<cgnblocknb,32>>>()
    else
       call cudacgpb_potforce()
    end if

    call cudacg_potforce_bondedterms<<<cgnbondedblock,32>>>()

    if ( cgnexcludepair > 0 ) then
        if ( (cgipb == 0) .or. ((cgipb > 0) .and. (cgpbmethod == 2) ) ) then
            call cudacg_potforce_excludepairs<<<(cgnexcludepair-1)/32+1,32>>>()
        end if
    end if

    if ( present(check) ) call cudacg_sum_force<<<(cgnatom-1)/32+1,32>>>()

    if ( cgifcalpot ) call cudacg_sum_pot<<<1,1>>>()

    if ( nvirtualsite > 0 ) then
        call cudacg_virtualsite_distribute_force<<<(nvirtualsite-1)/32+1,32>>>()
    end if

end subroutine

attributes(global) subroutine cudacg_debug_cgforce_zero()
    integer :: iatom

    iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > cgnatom_d ) return
    bond_force_d(:,iatom) = 0d0; angle_force_1_d(:,iatom) = 0d0; angle_force_2_d(:,iatom) = 0d0; angle_force_10_d(:,iatom) = 0d0;
    dihedral_force_1_d(:,iatom) = 0d0; dihedral_force_2_d(:,iatom) = 0d0; dihedral_force_3_d(:,iatom) = 0d0; dihedral_force_4_d(:,iatom) = 0d0;
    elecvdw_force_d(:,iatom) = 0d0; elecS_exclude_force_d(:,iatom) = 0d0
end subroutine

attributes(global) subroutine cudacg_potforce_zero()
  integer :: iatom
  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > cgnatom_d ) return
  total_force_d(:,iatom) = 0.0d0
  if ( blockidx%x == 1 .and. threadidx%x == 1 ) then
      cgebond_d = 0d0; cgeangle2_d = 0d0; cgeangle10_d = 0d0
      cgedihedral1_d = 0d0; cgedihedral2_d = 0d0; cgedihedral3_d = 0d0; cgedihedral4_d = 0d0
      cgeelec_d = 0d0; cgevdw_d = 0d0; cgeexclude_d = 0d0
  end if
end subroutine

attributes(global) subroutine cudacg_sum_pot()
  cgepot_d = cgeself_d + cgeexclude_d + cgebond_d + cgeangle1_d + cgeangle2_d + cgeangle10_d + cgedihedral1_d + cgedihedral2_d + cgedihedral3_d + cgedihedral4_d + cgeelec_d + cgevdw_d
end subroutine

attributes(global) subroutine cudacg_potforce_bondedterms()
  integer :: iblock
  iblock = blockidx%x

  if ( iblock <= cgnbondblock_d ) then
     call cudacg_potforce_bond(iblock)
  else
     iblock = iblock - cgnbondblock_d
     if ( iblock <= cgnangle1block_d ) then
        call cudacg_potforce_angle1(iblock)
     else
        iblock = iblock - cgnangle1block_d
        if ( iblock <= cgnangle2block_d ) then
           call cudacg_potforce_angle2(iblock)
        else
           iblock = iblock - cgnangle2block_d
           if ( iblock <= cgnangle10block_d ) then
              call cudacg_potforce_angle10(iblock)
           else
              iblock = iblock - cgnangle10block_d
              if ( iblock <= cgndihedral1block_d ) then
                 call cudacg_potforce_dihedral1(iblock)
              else
                 iblock = iblock - cgndihedral1block_d
                 if ( iblock <= cgndihedral2block_d ) then
                    call cudacg_potforce_dihedral2(iblock)
                 else
                    iblock = iblock - cgndihedral2block_d
                    if ( iblock <= cgndihedral3block_d ) then
                       call cudacg_potforce_dihedral3(iblock)
                    else
                       iblock = iblock - cgndihedral3block_d
                       if ( iblock <= cgndihedral4block_d ) then
                          call cudacg_potforce_dihedral4(iblock)
                       end if
                    end if
                 end if
              end if
           end if
        end if
     end if
  end if
end subroutine

attributes(device) subroutine cudacg_potforce_bond(iblock)
    integer :: iblock,ibond,iatom,jatom
    real :: ebond,tpvec(3),rij,coef

    ibond = (iblock-1)*blockdim%x + threadidx%x; ebond = 0.0

    if ( ibond <= cgnbond_d ) then

        iatom = cgbondatoms_d(1,ibond); jatom = cgbondatoms_d(2,ibond)
        tpvec(1:3) = cgcoor_d(1:3,iatom) - cgcoor_d(1:3,jatom)
        rij = sqrt(dot_product(tpvec,tpvec))
        coef = 0.5 * cgbondforceconst_d(ibond) * (rij - cgbondeqval_d(ibond))

        if ( cgifcalpot_d ) then
            ebond = coef * (rij - cgbondeqval_d(ibond))
        end if

        tpvec(:) = -2.0 * coef / rij * tpvec(:)
        coef = atomicadd(bond_force_d(1,iatom), dble(tpvec(1)))
        coef = atomicadd(bond_force_d(2,iatom), dble(tpvec(2)))
        coef = atomicadd(bond_force_d(3,iatom), dble(tpvec(3)))
        coef = atomicadd(bond_force_d(1,jatom), dble(-tpvec(1)))
        coef = atomicadd(bond_force_d(2,jatom), dble(-tpvec(2)))
        coef = atomicadd(bond_force_d(3,jatom), dble(-tpvec(3)))

    end if

    if ( .not. cgifcalpot_d ) return

    ibond = 1
    do while (ibond<=16)
        coef = __shfl_xor(ebond,ibond); ebond = ebond + coef
        ibond = ibond*2
    end do

    if ( threadidx%x == 1 ) then
        coef = atomicadd(cgebond_d, dble(ebond))
    end if
end subroutine

attributes(device) subroutine cudacg_potforce_angle1(iblock)
    integer :: i,j,k,iangle,iblock
    real, dimension(3) :: rij_vec3, rkj_vec3, dcos_drij_vec3, dcos_drkj_vec3
    real :: temp, rij_sq, rkj_sq, rij_mul_rkj, rij_dot_rkj, cos_theta
    real :: delta_theta, eangle

    iangle = (iblock-1)*blockdim%x + threadidx%x; eangle = 0.0

    if ( iangle <= cgnangle1_d ) then

       iangle = cgangletype1_index_d(iangle)
       i = cgangleatoms_d(1,iangle); j = cgangleatoms_d(2,iangle); k = cgangleatoms_d(3,iangle)

       rij_vec3(:) = cgcoor_d(:, i) - cgcoor_d(:, j)
       rij_sq = dot_product(rij_vec3, rij_vec3)
       rkj_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, j)
       rkj_sq = dot_product(rkj_vec3, rkj_vec3)

       rij_mul_rkj = sqrt(rij_sq*rkj_sq)
       rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
       cos_theta = rij_dot_rkj / rij_mul_rkj
       cos_theta = min(0.9999999, max(-0.9999999, cos_theta))

       delta_theta = acos(cos_theta) - cgangleeqval_d(iangle)  

       if ( cgifcalpot_d ) then
           eangle = 0.5 * cgangleforceconst_d(iangle) * delta_theta * delta_theta
       end if

       temp = 1.0 / rij_mul_rkj
       dcos_drij_vec3(:) = temp * (rkj_vec3(:) - rij_vec3(:) * rij_dot_rkj / rij_sq)
       dcos_drkj_vec3(:) = temp * (rij_vec3(:) - rkj_vec3(:) * rij_dot_rkj / rkj_sq)

       temp = (cgangleforceconst_d(iangle) * delta_theta) / sqrt(1.0 - cos_theta*cos_theta)
       
       dcos_drij_vec3 = temp * dcos_drij_vec3 
       ! angle_force_1_d
       delta_theta = atomicadd(angle_force_1_d(1,i), dble(dcos_drij_vec3(1)))
       delta_theta = atomicadd(angle_force_1_d(2,i), dble(dcos_drij_vec3(2)))
       delta_theta = atomicadd(angle_force_1_d(3,i), dble(dcos_drij_vec3(3)))
       
       dcos_drkj_vec3 = temp * dcos_drkj_vec3
       delta_theta = atomicadd(angle_force_1_d(1,k), dble(dcos_drkj_vec3(1)))
       delta_theta = atomicadd(angle_force_1_d(2,k), dble(dcos_drkj_vec3(2)))
       delta_theta = atomicadd(angle_force_1_d(3,k), dble(dcos_drkj_vec3(3)))
       
       rij_vec3 = - (dcos_drij_vec3 + dcos_drkj_vec3) 
       delta_theta = atomicadd(angle_force_1_d(1,j), dble(rij_vec3(1)))
       delta_theta = atomicadd(angle_force_1_d(2,j), dble(rij_vec3(2)))
       delta_theta = atomicadd(angle_force_1_d(3,j), dble(rij_vec3(3)))

    end if

    if ( .not. cgifcalpot_d ) return

    iangle = 1
    do while (iangle<=16)
        delta_theta = __shfl_xor(eangle,iangle); eangle = eangle + delta_theta
        iangle = iangle*2
    end do

  if ( threadidx%x == 1 ) then
     delta_theta = atomicadd(cgeangle1_d, dble(eangle))
  end if

end subroutine

attributes(device) subroutine cudacg_potforce_angle2(iblock)
  integer :: i,j,k,iangle,iblock
  real, dimension(3) :: rij_vec3, rkj_vec3, dcos_ddcoor, dcos_drkj_vec3
  real :: temp, rij_sq, rkj_sq, rij_mul_rkj, rij_dot_rkj, cos_theta
  real :: bracket, k_mul_bracket, eangle

  iangle = (iblock-1)*blockdim%x + threadidx%x; eangle = 0.0

  if ( iangle <= cgnangle2_d ) then

     iangle = cgangletype2_index_d(iangle)
     i = cgangleatoms_d(1,iangle); j = cgangleatoms_d(2,iangle); k = cgangleatoms_d(3,iangle)

     rij_vec3(:) = cgcoor_d(:, i) - cgcoor_d(:, j)
     rij_sq = dot_product(rij_vec3, rij_vec3)
     rkj_vec3(:) = cgcoor_d(:, k ) - cgcoor_d(:, j)
     rkj_sq = dot_product(rkj_vec3, rkj_vec3)

     rij_mul_rkj = sqrt(rij_sq*rkj_sq)
     rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
     cos_theta = rij_dot_rkj / rij_mul_rkj
     cos_theta = min(0.9999999, max(-0.9999999, cos_theta))

     bracket = cos_theta - cos(cgangleeqval_d(iangle)); k_mul_bracket = cgangleforceconst_d(iangle)*bracket
     if ( cgifcalpot_d ) eangle = k_mul_bracket * bracket * 0.5

     temp = 1.0 / rij_mul_rkj
     dcos_ddcoor(:) = temp * (rkj_vec3(:) - rij_vec3(:) * rij_dot_rkj / (rij_sq))
     dcos_drkj_vec3(:) = temp * (rij_vec3(:) - rkj_vec3(:) * rij_dot_rkj / (rkj_sq))

     dcos_ddcoor = - k_mul_bracket * dcos_ddcoor

     bracket = atomicadd(angle_force_2_d(1,i), dble(dcos_ddcoor(1)))
     bracket = atomicadd(angle_force_2_d(2,i), dble(dcos_ddcoor(2)))
     bracket = atomicadd(angle_force_2_d(3,i), dble(dcos_ddcoor(3)))

     dcos_drkj_vec3 = - k_mul_bracket * dcos_drkj_vec3

     bracket = atomicadd(angle_force_2_d(1,k), dble(dcos_drkj_vec3(1)))
     bracket = atomicadd(angle_force_2_d(2,k), dble(dcos_drkj_vec3(2)))
     bracket = atomicadd(angle_force_2_d(3,k), dble(dcos_drkj_vec3(3)))

     dcos_ddcoor = - ( dcos_ddcoor + dcos_drkj_vec3 )

     bracket = atomicadd(angle_force_2_d(1,j), dble(dcos_ddcoor(1)))
     bracket = atomicadd(angle_force_2_d(2,j), dble(dcos_ddcoor(2)))
     bracket = atomicadd(angle_force_2_d(3,j), dble(dcos_ddcoor(3)))

  end if

  if ( .not. cgifcalpot_d ) return

  iangle = 1
  do while (iangle<=16)
     bracket = __shfl_xor(eangle,iangle); eangle = eangle + bracket
     iangle = iangle*2
  end do

  if ( threadidx%x == 1 ) then
     bracket = atomicadd(cgeangle2_d, dble(eangle))
  end if

end subroutine

attributes(device) subroutine cudacg_potforce_angle10(iblock)
    integer :: i,j,k,iangle,iblock
    real*8, dimension(3) :: r_ij_Vec3, r_kj_Vec3
    real*8 :: cos_theta, r_ij_mul_r_kj, r_ij_dot_r_kj, r_ij_sq, r_kj_sq
    real :: bracket, k_mul_bracket, potential, temp, dcos_dr_ij_vec3(3), dcos_dr_kj_vec3(3)

    iangle = (iblock-1)*blockdim%x + threadidx%x
    potential = 0.0

    if ( iangle <= cgnangle10_d ) then

        iangle = cgangletype10_index_d(iangle)
        i = cgangleatoms_d(1,iangle)
        j = cgangleatoms_d(2,iangle)
        k = cgangleatoms_d(3,iangle)

        r_ij_Vec3(:) = cgcoor_d(:, i) - cgcoor_d(:, j)
        r_ij_sq = dot_product(r_ij_Vec3, r_ij_Vec3)
        r_kj_Vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, j)
        r_kj_sq = dot_product(r_kj_Vec3, r_kj_Vec3)

        r_ij_mul_r_kj = sqrt(r_ij_sq*r_kj_sq)
        r_ij_dot_r_kj = dot_product(r_ij_Vec3, r_kj_Vec3)
        cos_theta = r_ij_dot_r_kj / r_ij_mul_r_kj
        cos_theta = min(0.9999999d0, max(-0.9999999d0, cos_theta))

        ! cos_theta - cos_theta_0
        bracket = cos_theta - cos(cgangleeqval_d(iangle))
        ! cgangleforceconst_d(iangle) is k;
        ! k_mul_bracket = k * bracket
        k_mul_bracket = cgangleforceconst_d(iangle) * bracket

        ! force related calculating
        temp = 1.0 / r_ij_mul_r_kj
        dcos_dr_ij_vec3(:) = temp * (r_kj_Vec3(:) - r_ij_Vec3(:) * r_ij_dot_r_kj / (r_ij_sq))
        dcos_dr_kj_vec3(:) = temp * (r_ij_Vec3(:) - r_kj_Vec3(:) * r_ij_dot_r_kj / (r_kj_sq))

        temp = 1.0/(1.0 - cos_theta**2)
        if ( cgifcalpot_d ) then
            potential = k_mul_bracket * bracket * 0.5 * temp
        end if

        ! temp is dV/dcos_theta
        temp = k_mul_bracket * temp * (1.0 + bracket * temp * cos_theta) 
    
        ! temp is dV/dcos_theta
        dcos_dr_ij_vec3 = - temp * dcos_dr_ij_vec3
    
        bracket = atomicadd(angle_force_10_d(1,i), dble(dcos_dr_ij_vec3(1)))
        bracket = atomicadd(angle_force_10_d(2,i), dble(dcos_dr_ij_vec3(2)))
        bracket = atomicadd(angle_force_10_d(3,i), dble(dcos_dr_ij_vec3(3)))

        ! temp is dV/dcos_theta
        dcos_dr_kj_vec3 = - temp * dcos_dr_kj_vec3

        bracket = atomicadd(angle_force_10_d(1,k), dble(dcos_dr_kj_vec3(1)))
        bracket = atomicadd(angle_force_10_d(2,k), dble(dcos_dr_kj_vec3(2)))
        bracket = atomicadd(angle_force_10_d(3,k), dble(dcos_dr_kj_vec3(3)))

        dcos_dr_ij_vec3 = - ( dcos_dr_ij_vec3 + dcos_dr_kj_vec3 )

        bracket = atomicadd(angle_force_10_d(1,j), dble(dcos_dr_ij_vec3(1)))
        bracket = atomicadd(angle_force_10_d(2,j), dble(dcos_dr_ij_vec3(2)))
        bracket = atomicadd(angle_force_10_d(3,j), dble(dcos_dr_ij_vec3(3)))

    end if

    if ( .not. cgifcalpot_d ) return

    iangle = 1
    do while (iangle<=16)
        bracket = __shfl_xor(potential,iangle); potential = potential + bracket
        iangle = iangle*2
    end do

    if ( threadidx%x == 1 ) then
        bracket = atomicadd(cgeangle10_d, dble(potential))
    end if

end subroutine

attributes(device) subroutine cudacg_potforce_dihedral1(iblock)
  integer :: i,j,k,l,idihedral,coef_n,iblock
  real, dimension(3) :: rij_vec3, rkj_vec3, rkl_vec3, tpvec, n1, n2
  real :: temp,theta,n1sqinv,n2sqinv, dV_dTheta, rkj_sq, rij_dot_rkj, rkl_dot_rkj, edihedral

  idihedral = (iblock-1)*blockdim%x + threadidx%x; edihedral = 0.0

    if ( idihedral <= cgndihedral1_d ) then

        idihedral = cgdihedraltype1_index_d(idihedral)
        i = cgdihedralatoms_d(1,idihedral); j = cgdihedralatoms_d(2,idihedral); k = cgdihedralatoms_d(3,idihedral); l = cgdihedralatoms_d(4,idihedral)
    
        coef_n = cgdihedralcoefn_d(idihedral)

        rij_vec3(:) = cgcoor_d(:, i) - cgcoor_d(:, j)
        rkj_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, j)
        rkl_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, l)
        
        n1(1) = rij_vec3(2)*rkj_vec3(3) - rij_vec3(3)*rkj_vec3(2)
        n1(2) = rij_vec3(3)*rkj_vec3(1) - rij_vec3(1)*rkj_vec3(3)
        n1(3) = rij_vec3(1)*rkj_vec3(2) - rij_vec3(2)*rkj_vec3(1)
        
        n2(1) = rkj_vec3(2)*rkl_vec3(3) - rkj_vec3(3)*rkl_vec3(2)
        n2(2) = rkj_vec3(3)*rkl_vec3(1) - rkj_vec3(1)*rkl_vec3(3)
        n2(3) = rkj_vec3(1)*rkl_vec3(2) - rkj_vec3(2)*rkl_vec3(1)

        n1sqinv = 1.0/dot_product(n1, n1)
        n2sqinv = 1.0/dot_product(n2, n2)
        theta = dot_product(n1,n2)*sqrt(n1sqinv*n2sqinv)

        theta = min(1.0, max(-1.0, theta))  
        theta = sign(1.0, dot_product(rij_vec3, n2)) * acos(theta)

        rij_dot_rkj = dot_product(rij_vec3,rkj_vec3)
        rkl_dot_rkj = dot_product(rkl_vec3,rkj_vec3)
        rkj_sq = dot_product(rkj_vec3,rkj_vec3)

        temp = cos(coef_n*theta - cgdihedraleqval_d(idihedral))

        if ( cgifcalpot_d ) edihedral = cgdihedralforceconst_d(idihedral) * (1.0 + temp)
    
        temp = sin(coef_n*theta - cgdihedraleqval_d(idihedral))
        dV_dTheta = cgdihedralforceconst_d(idihedral) * temp *coef_n* sqrt(rkj_sq)
            
        n1(:) = dV_dTheta * n1(:) * n1sqinv
        n2(:) = -dV_dTheta * n2(:) * n2sqinv
        tpvec(:) = (rij_dot_rkj * n1(:) - rkl_dot_rkj * n2(:)) / rkj_sq

        theta = atomicadd(dihedral_force_1_d(1,i), dble(n1(1)))
        theta = atomicadd(dihedral_force_1_d(2,i), dble(n1(2)))
        theta = atomicadd(dihedral_force_1_d(3,i), dble(n1(3)))

        theta = atomicadd(dihedral_force_1_d(1,j), dble(-n1(1) + tpvec(1)))
        theta = atomicadd(dihedral_force_1_d(2,j), dble(-n1(2) + tpvec(2)))
        theta = atomicadd(dihedral_force_1_d(3,j), dble(-n1(3) + tpvec(3)))
        theta = atomicadd(dihedral_force_1_d(1,k), dble(-n2(1) - tpvec(1)))
        theta = atomicadd(dihedral_force_1_d(2,k), dble(-n2(2) - tpvec(2)))
        theta = atomicadd(dihedral_force_1_d(3,k), dble(-n2(3) - tpvec(3)))

        theta = atomicadd(dihedral_force_1_d(1,l), dble(n2(1)))
        theta = atomicadd(dihedral_force_1_d(2,l), dble(n2(2)))
        theta = atomicadd(dihedral_force_1_d(3,l), dble(n2(3)))
    end if

  if ( .not. cgifcalpot_d ) return

  idihedral = 1
  do while (idihedral<=16)
     theta = __shfl_xor(edihedral,idihedral); edihedral = edihedral + theta
     idihedral = idihedral*2
  end do

  if ( threadidx%x == 1 ) then
     theta = atomicadd(cgedihedral1_d, dble(edihedral))
  end if
end subroutine

attributes(device) subroutine cudacg_potforce_dihedral2(iblock)
  integer :: i,j,k,l,idihedral,iblock
  real, dimension(3) :: rij_vec3, rkj_vec3, rkl_vec3, tpvec, n1, n2
  real :: theta, rkj_sq, dV_dTheta, rij_dot_rkj, rkl_dot_rkj, edihedral,n1sqinv,n2sqinv

  idihedral = (iblock-1)*blockdim%x + threadidx%x; edihedral = 0.0

    if ( idihedral <= cgndihedral2_d ) then

        idihedral = cgdihedraltype2_index_d(idihedral)
        i = cgdihedralatoms_d(1,idihedral); j = cgdihedralatoms_d(2,idihedral); k = cgdihedralatoms_d(3,idihedral); l = cgdihedralatoms_d(4,idihedral)
        
        rij_vec3(:) = cgcoor_d(:, i) - cgcoor_d(:, j)
        rkj_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, j)
        rkl_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, l)
    
        n1(1) = rij_vec3(2)*rkj_vec3(3) - rij_vec3(3)*rkj_vec3(2)
        n1(2) = rij_vec3(3)*rkj_vec3(1) - rij_vec3(1)*rkj_vec3(3)
        n1(3) = rij_vec3(1)*rkj_vec3(2) - rij_vec3(2)*rkj_vec3(1)
        
        n2(1) = rkj_vec3(2)*rkl_vec3(3) - rkj_vec3(3)*rkl_vec3(2)
        n2(2) = rkj_vec3(3)*rkl_vec3(1) - rkj_vec3(1)*rkl_vec3(3)
        n2(3) = rkj_vec3(1)*rkl_vec3(2) - rkj_vec3(2)*rkl_vec3(1)

        n1sqinv = 1.0/dot_product(n1, n1)
        n2sqinv = 1.0/dot_product(n2, n2)
        theta = dot_product(n1,n2)*sqrt(n1sqinv*n2sqinv)

        theta = min(1.0, max(-1.0, theta))  
        theta = sign(1.0, dot_product(rij_vec3, n2)) * acos(theta)

        rij_dot_rkj = dot_product(rij_vec3,rkj_vec3)
        rkl_dot_rkj = dot_product(rkl_vec3,rkj_vec3)
        rkj_sq = dot_product(rkj_vec3,rkj_vec3)

        theta = theta - cgdihedraleqval_d(idihedral)
        if (theta > PI_d) then
            theta = theta - 2.0*PI_d
        else if (theta < -PI_d) then
            theta = theta + 2.0*PI_d
        end if
        if ( cgifcalpot_d ) edihedral = 0.5 * cgdihedralforceconst_d(idihedral) * theta**2

        dV_dTheta = -cgdihedralforceconst_d(idihedral) * theta * sqrt(rkj_sq)

        n1(:) = dV_dTheta * n1(:) * n1sqinv
        n2(:) = -dV_dTheta * n2(:) * n2sqinv
        tpvec(:) = (rij_dot_rkj * n1(:) - rkl_dot_rkj * n2(:)) / rkj_sq

        theta = atomicadd(dihedral_force_2_d(1,i), dble(n1(1)))
        theta = atomicadd(dihedral_force_2_d(2,i), dble(n1(2)))
        theta = atomicadd(dihedral_force_2_d(3,i), dble(n1(3)))

        theta = atomicadd(dihedral_force_2_d(1,j), dble(-n1(1) + tpvec(1)))
        theta = atomicadd(dihedral_force_2_d(2,j), dble(-n1(2) + tpvec(2)))
        theta = atomicadd(dihedral_force_2_d(3,j), dble(-n1(3) + tpvec(3)))

        theta = atomicadd(dihedral_force_2_d(1,k), dble(-n2(1) - tpvec(1)))
        theta = atomicadd(dihedral_force_2_d(2,k), dble(-n2(2) - tpvec(2)))
        theta = atomicadd(dihedral_force_2_d(3,k), dble(-n2(3) - tpvec(3)))

        theta = atomicadd(dihedral_force_2_d(1,l), dble(n2(1)))
        theta = atomicadd(dihedral_force_2_d(2,l), dble(n2(2)))
        theta = atomicadd(dihedral_force_2_d(3,l), dble(n2(3)))

    end if

  if ( .not. cgifcalpot_d ) return

  idihedral = 1
  do while (idihedral<=16)
     theta = __shfl_xor(edihedral,idihedral); edihedral = edihedral + theta
     idihedral = idihedral*2
  end do

  if ( threadidx%x == 1 ) then
     theta = atomicadd(cgedihedral2_d, dble(edihedral))
  end if

end subroutine

attributes(device) subroutine cudacg_potforce_dihedral3(iblock)
  integer :: i,j,k,l,idihedral,iblock
  real, dimension(3) :: rij_vec3, rkj_vec3, rkl_vec3, tpvec, n1, n2
  real :: theta, n1sqinv, n2sqinv, dV_dTheta, rkj_sq, rij_dot_rkj, rkl_dot_rkj, edihedral
  real :: params(6), temp

  idihedral = (iblock-1)*blockdim%x + threadidx%x; edihedral = 0.0

    if ( idihedral <= cgndihedral3_d ) then

        idihedral = cgdihedraltype3_index_d(idihedral)
        i = cgdihedralatoms_d(1,idihedral); j = cgdihedralatoms_d(2,idihedral); k = cgdihedralatoms_d(3,idihedral); l = cgdihedralatoms_d(4,idihedral)
        params(1:6) = cgdihedral_extra_real_d(1:6, idihedral)
        
        rij_vec3(:) = cgcoor_d(:, i) - cgcoor_d(:, j)
        rkj_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, j)
        rkl_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, l)
        
        n1(1) = rij_vec3(2)*rkj_vec3(3) - rij_vec3(3)*rkj_vec3(2)
        n1(2) = rij_vec3(3)*rkj_vec3(1) - rij_vec3(1)*rkj_vec3(3)
        n1(3) = rij_vec3(1)*rkj_vec3(2) - rij_vec3(2)*rkj_vec3(1)
        
        n2(1) = rkj_vec3(2)*rkl_vec3(3) - rkj_vec3(3)*rkl_vec3(2)
        n2(2) = rkj_vec3(3)*rkl_vec3(1) - rkj_vec3(1)*rkl_vec3(3)
        n2(3) = rkj_vec3(1)*rkl_vec3(2) - rkj_vec3(2)*rkl_vec3(1)

        n1sqinv = 1.0/dot_product(n1, n1)
        n2sqinv = 1.0/dot_product(n2, n2)
        theta = dot_product(n1,n2)*sqrt(n1sqinv*n2sqinv)

        theta = min(1.0, max(-1.0, theta))  
        theta = sign(1.0, dot_product(rij_vec3, n2)) * acos(theta)

        rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
        rkl_dot_rkj = dot_product(rkl_vec3, rkj_vec3)
        rkj_sq = dot_product(rkj_vec3, rkj_vec3)

        temp = cos(theta - PI_d)
        IF ( cgifcalpot_d ) THEN
            edihedral = params(1) + params(2) * temp + params(3) * temp**2 + params(4) * temp**3 + params(5) * temp**4 + params(6) * temp**5    
        END IF
        dV_dTheta = params(2) + (2 * params(3) * temp) + (3 * params(4) * temp**2) + (4 * params(5) * temp**3) + (5 * params(6) * temp**4)
        temp = sin(theta - PI_d)
        dV_dTheta = dV_dTheta * temp * sqrt(rkj_sq) 
        n1(:) = dV_dTheta * n1(:) * n1sqinv
        n2(:) = -dV_dTheta * n2(:) * n2sqinv
        tpvec(:) = (rij_dot_rkj * n1(:) - rkl_dot_rkj * n2(:)) / rkj_sq

        theta = atomicadd(dihedral_force_3_d(1,i), dble(n1(1)))
        theta = atomicadd(dihedral_force_3_d(2,i), dble(n1(2)))
        theta = atomicadd(dihedral_force_3_d(3,i), dble(n1(3)))

        theta = atomicadd(dihedral_force_3_d(1,j), dble(-n1(1) + tpvec(1)))
        theta = atomicadd(dihedral_force_3_d(2,j), dble(-n1(2) + tpvec(2)))
        theta = atomicadd(dihedral_force_3_d(3,j), dble(-n1(3) + tpvec(3)))

        theta = atomicadd(dihedral_force_3_d(1,k), dble(-n2(1) - tpvec(1)))
        theta = atomicadd(dihedral_force_3_d(2,k), dble(-n2(2) - tpvec(2)))
        theta = atomicadd(dihedral_force_3_d(3,k), dble(-n2(3) - tpvec(3)))

        theta = atomicadd(dihedral_force_3_d(1,l), dble(n2(1)))
        theta = atomicadd(dihedral_force_3_d(2,l), dble(n2(2)))
        theta = atomicadd(dihedral_force_3_d(3,l), dble(n2(3)))
        
    end if

    if ( .not. cgifcalpot_d ) return

    idihedral = 1
    do while (idihedral<=16)
        temp = __shfl_xor(edihedral,idihedral); edihedral = edihedral + temp
        idihedral = idihedral*2
    end do

  if ( threadidx%x == 1 ) then
     temp = atomicadd(cgedihedral3_d, dble(edihedral))
  end if
end subroutine

attributes(device) subroutine cudacg_potforce_dihedral4(iblock)
    integer :: i,j,k,l,idihedral,iblock
    real, dimension(3) :: rij_vec3, rkj_vec3, rkl_vec3, n1, n2
    real, dimension(3) :: dcos_drij_vec3, dcos_drkl_vec3
    real :: theta, n1sqinv, n2sqinv, dV_dTheta, rij_sq, rkj_sq, rkl_sq, rij_dot_rkj, rkj_dot_rkl, edihedral
    real :: cos_temp, params(6), temp, temp1, temp2, temp_sum, sin_1, sin_2
    real :: rij, rkj, rkl,rij_mul_rkj, rkj_mul_rkl
    real :: tpfrc(3,4)

    idihedral = (iblock-1)*blockdim%x + threadidx%x; edihedral = 0.0

    if ( idihedral <= cgndihedral4_d ) then

        idihedral = cgdihedraltype4_index_d(idihedral)
        i = cgdihedralatoms_d(1,idihedral); j = cgdihedralatoms_d(2,idihedral); k = cgdihedralatoms_d(3,idihedral); l = cgdihedralatoms_d(4,idihedral)
        
        ! params(1:6) = cgdihedral_extra_real_d(1:6, cgndihedral3_d + idihedral)
        params(1:6) = cgdihedral_extra_real_d(1:6,idihedral)    
        rij_vec3(:) = cgcoor_d(:, i) - cgcoor_d(:, j)
        rkj_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, j)
        rkl_vec3(:) = cgcoor_d(:, k) - cgcoor_d(:, l)
        
        n1(1) = rij_vec3(2)*rkj_vec3(3) - rij_vec3(3)*rkj_vec3(2)
        n1(2) = rij_vec3(3)*rkj_vec3(1) - rij_vec3(1)*rkj_vec3(3)
        n1(3) = rij_vec3(1)*rkj_vec3(2) - rij_vec3(2)*rkj_vec3(1)
        
        n2(1) = rkj_vec3(2)*rkl_vec3(3) - rkj_vec3(3)*rkl_vec3(2)
        n2(2) = rkj_vec3(3)*rkl_vec3(1) - rkj_vec3(1)*rkl_vec3(3)
        n2(3) = rkj_vec3(1)*rkl_vec3(2) - rkj_vec3(2)*rkl_vec3(1)

        n1sqinv = 1.0/dot_product(n1, n1)
        n2sqinv = 1.0/dot_product(n2, n2)
        theta = dot_product(n1,n2)*sqrt(n1sqinv*n2sqinv)

        theta = min(1.0, max(-1.0, theta))  
        theta = sign(1.0, dot_product(rij_vec3, n2)) * acos(theta)

        rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
        rkj_dot_rkl = dot_product(rkj_vec3, rkl_vec3)
        rkj_sq = dot_product(rkj_vec3, rkj_vec3)
        rkl_sq = dot_product(rkl_vec3, rkl_vec3)
        rij_sq = dot_product(rij_vec3, rij_vec3)
        rij = sqrt(rij_sq)
        rkj = sqrt(rkj_sq)
        rkl = sqrt(rkl_sq) 
        rij_mul_rkj = rij*rkj
        rkj_mul_rkl = rkj*rkl
        
        temp1 = rij_dot_rkj / rij_mul_rkj
        sin_1 = sin(acos(temp1))   
        temp1 = -temp1 / (rij_mul_rkj * sin_1)

        temp2 = rkj_dot_rkl / rkj_mul_rkl
        sin_2 = sin(acos(temp2))  
        temp2 = -temp2 / (rkj_mul_rkl * sin_2)
        
        cos_temp = cos(theta)
        temp_sum = params(2) + params(3) * cos_temp + params(4) * cos_temp**2 + params(5) * cos_temp**3 + params(6) * cos_temp**4

        if ( cgifcalpot_d ) then
            edihedral = temp_sum * params(1) * sin_1**3 * sin_2**3
        end if
        temp = params(1) * sin_1*sin_1 * sin_2*sin_2
        temp_sum = temp * temp_sum * 3.0
    
        ! ================== sin_1 term ============================
        dcos_drij_vec3(:) = temp1 * (rkj_vec3(:) - rij_vec3(:) * rij_dot_rkj / rij_sq)
        dcos_drkl_vec3(:) = temp1 * (rij_vec3(:) - rkj_vec3(:) * rij_dot_rkj / rkj_sq)
        temp1 = sin_2 * temp_sum

        tpfrc(:,1) = -temp1 * dcos_drij_vec3(:)
        tpfrc(:,2) = temp1 * (dcos_drij_vec3(:) + dcos_drkl_vec3(:))
        tpfrc(:,3) = -temp1 * dcos_drkl_vec3(:)
    
        ! ================== sin_2 term ============================
        dcos_drij_vec3(:) = temp2 * (-rkl_vec3(:) + rkj_vec3(:) * rkj_dot_rkl / rkj_sq)
        dcos_drkl_vec3(:) = temp2 * (-rkj_vec3(:) + rkl_vec3(:) * rkj_dot_rkl / rkl_sq)
        temp2 = sin_1 * temp_sum
        
        tpfrc(:,2) = tpfrc(:,2) + -temp2 * dcos_drij_vec3(:)
        tpfrc(:,3) = tpfrc(:,3) + temp2 * (dcos_drij_vec3(:) + dcos_drkl_vec3(:))
        tpfrc(:,4) = -temp2 * dcos_drkl_vec3(:)

        ! ================== dihedral term ============================
        temp1 = -sin(theta) * (params(3) + 2*params(4) * cos_temp + &
                        3.0*params(5) * cos_temp**2 + 4.0*params(6) * cos_temp**3)
        dV_dTheta = - temp * sin_2 * sin_1 * temp1 * rkj 

        n1(:) = dV_dTheta * n1(:) * n1sqinv
        n2(:) = -dV_dTheta * n2(:) * n2sqinv
        rkl_vec3 = (rij_dot_rkj * n1(:) - rkj_dot_rkl * n2(:)) / rkj_sq

        tpfrc(:,1) = tpfrc(:,1) + n1(:)
        tpfrc(:,2) = tpfrc(:,2) - n1(:) + rkl_vec3(:)
        tpfrc(:,3) = tpfrc(:,3) - n2(:) - rkl_vec3(:)
        tpfrc(:,4) = tpfrc(:,4) + n2(:)

        theta = atomicadd(dihedral_force_4_d(1,i), dble(tpfrc(1,1)))
        theta = atomicadd(dihedral_force_4_d(2,i), dble(tpfrc(2,1)))
        theta = atomicadd(dihedral_force_4_d(3,i), dble(tpfrc(3,1)))

        theta = atomicadd(dihedral_force_4_d(1,j), dble(tpfrc(1,2)))
        theta = atomicadd(dihedral_force_4_d(2,j), dble(tpfrc(2,2)))
        theta = atomicadd(dihedral_force_4_d(3,j), dble(tpfrc(3,2)))

        theta = atomicadd(dihedral_force_4_d(1,k), dble(tpfrc(1,3)))
        theta = atomicadd(dihedral_force_4_d(2,k), dble(tpfrc(2,3)))
        theta = atomicadd(dihedral_force_4_d(3,k), dble(tpfrc(3,3)))

        theta = atomicadd(dihedral_force_4_d(1,l), dble(tpfrc(1,4)))
        theta = atomicadd(dihedral_force_4_d(2,l), dble(tpfrc(2,4)))
        theta = atomicadd(dihedral_force_4_d(3,l), dble(tpfrc(3,4)))

    end if

    if ( .not. cgifcalpot_d ) return

    idihedral = 1
    do while (idihedral<=16)
        theta = __shfl_xor(edihedral,idihedral); edihedral = edihedral + theta
        idihedral = idihedral*2
    end do

    if ( threadidx%x == 1 ) then
        theta = atomicadd(cgedihedral4_d, dble(edihedral))
    end if
end subroutine

attributes(global) subroutine cudacg_potforce_excludepairs()
    integer :: iexc,iatom,jatom
    real :: tppot,coef,iq,jq,tpvec(3),dissq

    iexc = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iexc > cgnexcludepair_d ) return 
    iatom = cgexcludepairs_d(1,iexc); jatom = cgexcludepairs_d(2,iexc)
    iq = cgcharge_d(iatom); jq = cgcharge_d(jatom); tppot = 0.0

    if ( iq /= 0.0 .and. jq /= 0.0 ) then
        tpvec = cgcoor_d(:, iatom) - cgcoor_d(:,jatom)
        tpvec = tpvec - floor(tpvec*cgcellinv_d+0.5)*cgcell_d
        dissq = dot_product(tpvec,tpvec)
        if ( dissq < rcutsq_d ) then
            coef = eleccoef_d*iq*jq
            if ( cgifcalpot_d ) then
                tppot = coef * (krf_d * dissq - crf_d)
            end if
            tpvec(:) = tpvec(:) * coef * krf_d * 2.0
            iq = atomicadd(elecS_exclude_force_d(1, iatom), dble(-tpvec(1)))
            iq = atomicadd(elecS_exclude_force_d(2, iatom), dble(-tpvec(2)))
            iq = atomicadd(elecS_exclude_force_d(3, iatom), dble(-tpvec(3)))

            iq = atomicadd(elecS_exclude_force_d(1, jatom), dble(tpvec(1)))
            iq = atomicadd(elecS_exclude_force_d(2, jatom), dble(tpvec(2)))
            iq = atomicadd(elecS_exclude_force_d(3, jatom), dble(tpvec(3)))
        end if
    end if

  if ( .not. cgifcalpot_d ) return

  iexc = 1
  do while (iexc<=16)
     coef = __shfl_xor(tppot,iexc); tppot = tppot + coef
     iexc = iexc*2
  end do

  if ( threadidx%x == 1 ) then
     coef = atomicadd(cgeexclude_d, dble(tppot))
  end if

end subroutine

attributes(global) subroutine cudacg_potforce_nonbond_init()
  integer :: i,j,iatom,jatom,iatomstart,iatomend,jatomstart,jatomend,ithread,iblock,index
  integer :: iskip,tpindex,nskip,iskipstart,iskipend

  ithread=threadidx%x; iblock=blockidx%x
  i = cgblocknbpos_d(1,iblock); iatomstart = i; iatomend = i + blockdim%x - 1
  i = cgblocknbpos_d(2,iblock); jatomstart = i; jatomend = i + blockdim%x - 1
  iatom = iatomstart + ithread - 1; iskip = 0
  if ( iatom >= cgnatom_d ) return

  index = cgnexcludedatoms_d(iatom); iskip=0; iskipstart=0
  if ( index > 0 ) then
     i = cgexcludedatomindex_d(iatom)
     do tpindex = 1, index
        jatom = cgexcludedatomlist_d(i+tpindex)
        if ( (jatom >= jatomstart) .and. (jatom <= jatomend) .and. (jatom <= cgnatom_d) ) then
           if ( iskipstart == 0 ) iskipstart = i + tpindex
           iskipend = i + tpindex
           if ( (jatom >= (jatomstart + ithread - 1)) .and. (iskip == 0) ) iskip = i + tpindex
        end if
     end do
     if ( (iskip == 0) .and. (iskipstart > 0) ) iskip = iskipstart
  end if
  cgblocknbskip_d(1:3,(iblock-1)*blockdim%x+ithread) = (/iskip,iskipstart,iskipend/)
end subroutine

attributes(global) subroutine cudacg_virtualsite_set_coordinate()
  integer :: isite, v_idx, i, natoms, sitetype
  real :: coor1(3), coor2(3), coor3(3), tpvec12(3), tpvec13(3), tpvec(3)
  real :: tpcoor(3), tpsize
  
  isite = (blockidx%x-1)*blockdim%x + threadidx%x
  if (isite > nvirtualsite_d) return
  
  v_idx = virtualsites_d(isite)%siteatom          
  sitetype = virtualsites_d(isite)%sitetype      
  natoms = virtualsites_d(isite)%natoms         
  
  if (sitetype == 4) then
    coor1(1:3) = cgcoor_d(1:3, virtualsites_d(isite)%atomlist(1))
    coor2(1:3) = cgcoor_d(1:3, virtualsites_d(isite)%atomlist(2))
    coor3(1:3) = cgcoor_d(1:3, virtualsites_d(isite)%atomlist(3))
    
    tpvec12 = coor2 - coor1
    tpvec13 = coor3 - coor1
    
    tpvec(1) = tpvec12(2)*tpvec13(3) - tpvec12(3)*tpvec13(2)
    tpvec(2) = tpvec12(3)*tpvec13(1) - tpvec12(1)*tpvec13(3)
    tpvec(3) = tpvec12(1)*tpvec13(2) - tpvec12(2)*tpvec13(1)
    
    cgcoor_d(1:3, v_idx) = coor1 + &
                           virtualsites_d(isite)%weights(1) * tpvec12 + &
                           virtualsites_d(isite)%weights(2) * tpvec13 + &
                           virtualsites_d(isite)%weights(3) * tpvec
  else
    tpcoor = 0.0
    
    do i = 1, natoms
       tpcoor(1:3) = tpcoor(1:3) + virtualsites_d(isite)%weights(i) * &
                     cgcoor_d(1:3, virtualsites_d(isite)%atomlist(i))
    end do
    
    if (virtualsites_d(isite)%weightp /= 0.0) then
       tpsize = 0.0; tpvec = 0.0
       
       do i = 1, natoms
          tpvec(1:3) = tpvec(1:3) + virtualsites_d(isite)%weightdx(i) * &
                       cgcoor_d(1:3, virtualsites_d(isite)%atomlist(i))
       end do
       
       tpsize = sqrt(dot_product(tpvec, tpvec))    
       tpcoor = tpcoor + virtualsites_d(isite)%weightp * tpvec / tpsize
    end if
    
    cgcoor_d(1:3, v_idx) = tpcoor
  end if
end subroutine

attributes(global) subroutine cudacg_virtualsite_distribute_force()
    integer :: isite, v_idx, i, natoms, sitetype
    real :: virtual_force(3), coor1(3), coor2(3), coor3(3)
    real :: w_sum, w1, w2, w3, tpvec(3), tpsize
    real :: cross_xy, cross_xz, cross_yz
    real :: volumn_inv

    isite = (blockidx%x-1)*blockdim%x + threadidx%x

    if (isite > nvirtualsite_d) then
        return
    end if

    v_idx = virtualsites_d(isite)%siteatom
    sitetype = virtualsites_d(isite)%sitetype
    natoms = virtualsites_d(isite)%natoms
    virtual_force(1:3) = total_force_d(1:3, v_idx)

    if (sitetype == 4) then

        coor1(1:3) = cgcoor_d(1:3, virtualsites_d(isite)%atomlist(1))
        coor2(1:3) = cgcoor_d(1:3, virtualsites_d(isite)%atomlist(2))
        coor3(1:3) = cgcoor_d(1:3, virtualsites_d(isite)%atomlist(3))

        w_sum = virtualsites_d(isite)%weights(1) + virtualsites_d(isite)%weights(2)
        w1 = virtualsites_d(isite)%weights(1)
        w2 = virtualsites_d(isite)%weights(2)
        w3 = virtualsites_d(isite)%weights(3)

        tpvec(1) = w1 * virtual_force(1) + w3 * ((coor1(3)-coor3(3))*virtual_force(2) + (coor3(2)-coor1(2))*virtual_force(3))
        tpvec(2) = w3 * ((coor3(3)-coor1(3))*virtual_force(1)) + w1 * virtual_force(2) + w3 * ((coor1(1)-coor3(1))*virtual_force(3))
        tpvec(3) = w3 * ((coor1(2)-coor3(2))*virtual_force(1)) + w3 * ((coor3(1)-coor1(1))*virtual_force(2)) + w1 * virtual_force(3)

        w1 = atomicadd(total_force_d(1,virtualsites_d(isite)%atomlist(2)),dble(tpvec(1)))
        w1 = atomicadd(total_force_d(2,virtualsites_d(isite)%atomlist(2)),dble(tpvec(2)))
        w1 = atomicadd(total_force_d(3,virtualsites_d(isite)%atomlist(2)),dble(tpvec(3)))

        w1 = w2 * virtual_force(1) + w3*((coor2(3)-coor1(3))*virtual_force(2) + (coor1(2)-coor2(2))*virtual_force(3))
        w_sum = w3 * ((coor1(3)-coor2(3))*virtual_force(1)) + w2*virtual_force(2) + w3 * ((coor2(1)-coor1(1))*virtual_force(3))
        w3 = w3 * ((coor2(2)-coor1(2))*virtual_force(1)) +w3*((coor1(1)-coor2(1))*virtual_force(2)) + w2 * virtual_force(3)

        w2 = atomicadd(total_force_d(1,virtualsites_d(isite)%atomlist(3)),dble(w1))
        w2 = atomicadd(total_force_d(2,virtualsites_d(isite)%atomlist(3)),dble(w_sum))
        w2 = atomicadd(total_force_d(3,virtualsites_d(isite)%atomlist(3)),dble(w3))

        w2 = atomicadd(total_force_d(1,virtualsites_d(isite)%atomlist(1)),dble(virtual_force(1)-tpvec(1)-w1))
        w2 = atomicadd(total_force_d(2,virtualsites_d(isite)%atomlist(1)),dble(virtual_force(2)-tpvec(2)-w_sum))
        w2 = atomicadd(total_force_d(3,virtualsites_d(isite)%atomlist(1)),dble(virtual_force(3)-tpvec(3)-w3))

    else

        do i = 1, natoms
            w1 = atomicadd(total_force_d(1, virtualsites_d(isite)%atomlist(i)),&
                        virtualsites_d(isite)%weights(i) *virtual_force(1))
            w1 = atomicadd(total_force_d(2, virtualsites_d(isite)%atomlist(i)),&
                        virtualsites_d(isite)%weights(i) *virtual_force(2))
            w1 = atomicadd(total_force_d(3, virtualsites_d(isite)%atomlist(i)),&
                        virtualsites_d(isite)%weights(i) *virtual_force(3))
        end do

        if ( virtualsites_d(isite)%weightp /= 0.0 ) then
           tpvec = 0.0
           do i = 1, natoms
               tpvec(1:3) = tpvec(1:3) + virtualsites_d(isite)%weightdx(i) * &
                               cgcoor_d(1:3, virtualsites_d(isite)%atomlist(i))
           end do
           tpsize = sqrt(dot_product(tpvec, tpvec))
           volumn_inv = tpsize ** (-3)

           do i = 1, natoms

              w2 = virtualsites_d(isite)%weightp *virtualsites_d(isite)%weightdx(i)
              coor1(:) = virtual_force(:) * w2 * (1.0 / tpsize -tpvec(:)*tpvec(:) * volumn_inv)

              cross_xy = - tpvec(1)*tpvec(2) * volumn_inv * w2
              cross_xz = - tpvec(1)*tpvec(3) * volumn_inv * w2
              cross_yz = - tpvec(2)*tpvec(3) * volumn_inv * w2

              w1 = atomicadd(total_force_d(1,virtualsites_d(isite)%atomlist(i)),&
                              dble(coor1(1) + cross_xy*virtual_force(2) + cross_xz*virtual_force(3)))

              w1 = atomicadd(total_force_d(2,virtualsites_d(isite)%atomlist(i)),&
                              dble(cross_xy *virtual_force(1) + coor1(2) + cross_yz*virtual_force(3)))

              w1 = atomicadd(total_force_d(3,virtualsites_d(isite)%atomlist(i)),&
                              dble(cross_xz *virtual_force(1) + cross_yz*virtual_force(2) + coor1(3)))
           end do
        end if
    end if
end subroutine


attributes(global) subroutine cudacg_potforce_elecvdw()
    integer :: natom,ithread,inext,iatom,jatom,jatomstart,jatomend,iblock
    integer :: tpindex,itype,jtype,index,skipatom,iskip,iskipstart,iskipend
    real :: icoor(3),jcoor(3),ifrc(3),jfrc(3),iq,jq,dcoor(3)
    real :: sigmasq,eps4,tpelec,tpvdw,dissq,disinv,eleccoef,ES_coef,coef1,coef2
    real :: krf,crf,rcutsq,corr,discutinv

    ithread=threadidx%x; iblock=blockidx%x; inext=ithread+1
    tpelec=0.0; tpvdw=0.0; ifrc=0.0; jfrc=0.0
    rcutsq = rcutsq_d
    ! MARK
    discutinv = DISCUT_INV_d
    krf = krf_d
    crf = crf_d

  natom=cgnatom_d; eleccoef = eleccoef_d

  jatomstart = cgblocknbpos_d(2,iblock); jatomend = jatomstart + 32 - 1
  jatom = jatomstart+ithread-1; jq = 0.0
  if ( jatom <= natom ) then
     jcoor(1:3) = cgcoor_d(1:3,jatom); jq = cgcharge_d(jatom)
     jtype = cgatomtype_d(jatom)
  end if

  skipatom = 0; iq = 0.0
  iatom = cgblocknbpos_d(1,iblock) + ithread - 1
  if ( iatom <= natom ) then
     itype = cgatomtype_d(iatom)
     index=(iblock-1)*32+ithread; iskip = cgblocknbskip_d(1,index)
     iskipstart = cgblocknbskip_d(2,index); iskipend = cgblocknbskip_d(3,index)
     iq= cgcharge_d(iatom); icoor(1:3) = cgcoor_d(1:3,iatom)
     if ( iskip > 0 ) skipatom=cgexcludedatomlist_d(iskip)
  end if

  do index = 1, 32

     if ( iatom < jatom .and. jatom <= natom ) then

     if ( jatom == skipatom ) then

        iskip = iskip + 1; if ( iskip > iskipend ) iskip=iskipstart
        skipatom = cgexcludedatomlist_d(iskip)

     else

        dcoor = icoor(:) - jcoor(:)

        ! PBC
        if (dcoor(1) > half_box_d(1)) then
          dcoor(1) = dcoor(1) - box_size_d(1)
        else if (dcoor(1) < -half_box_d(1)) then
          dcoor(1) = dcoor(1) + box_size_d(1)
        end if
        
        if (dcoor(2) > half_box_d(2)) then
          dcoor(2) = dcoor(2) - box_size_d(2)
        else if (dcoor(2) < -half_box_d(2)) then
          dcoor(2) = dcoor(2) + box_size_d(2)
        end if
        
        if (dcoor(3) > half_box_d(3)) then
          dcoor(3) = dcoor(3) - box_size_d(3)
        else if (dcoor(3) < -half_box_d(3)) then
          dcoor(3) = dcoor(3) + box_size_d(3)
        end if
        
        dissq = dot_product(dcoor,dcoor)

        if ( dissq < rcutsq ) then

           tpindex= cgnatomtype_d*(itype-1) + jtype
           tpindex = cgnonbondedparmindex_d(tpindex)
           sigmasq = cgnonbondedparms_d(1,tpindex)
           eps4 = cgnonbondedparms_d(2,tpindex)

           disinv = 1.0/sqrt(dissq)

           ES_coef = eleccoef*iq*jq

           if ( krf > 0.0 ) then

              if ( cgifcalpot_d ) tpelec = tpelec + ES_coef * (disinv + krf * dissq - crf)
              coef1 = sigmasq*(discutinv**2); coef1 = coef1*coef1*coef1; coef2 = coef1*eps4
              corr = coef2*(coef1 - 1.0)
              coef1 = sigmasq*(disinv**2); coef1 = coef1*coef1*coef1; coef2 = coef1*eps4
              if ( cgifcalpot_d ) tpvdw = tpvdw + coef2*(coef1 - 1.0) - corr
              coef1 = (ES_coef * (-disinv + 2.0*dissq*krf) - (coef2*(12.0*coef1 - 6.0)))*disinv*disinv

           else

              if ( cgifcalpot_d ) &
                tpelec = tpelec + ES_coef * disinv

              coef1 = sigmasq*(disinv)**2; coef1 = coef1*coef1*coef1; coef2 = coef1*eps4
              if ( cgifcalpot_d ) &
                tpvdw = tpvdw + coef2*(coef1 - 1.0)

              coef1 = (ES_coef * (-disinv) - (coef2*(12.0*coef1 - 6.0)))*disinv*disinv

           end if

           ifrc = ifrc - dcoor * coef1
           jfrc = jfrc + dcoor * coef1

        end if

     end if

     end if

     jatom = __shfl(jatom,inext); jtype = __shfl(jtype,inext); jq = __shfl(jq,inext)
     jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
     jfrc(1) = __shfl(jfrc(1),inext); jfrc(2) = __shfl(jfrc(2),inext); jfrc(3) = __shfl(jfrc(3),inext)

  end do

  call syncthreads()

    if ( iatom <= natom ) then
        if ( ((jatomstart - cgblocknbpos_d(1,iblock))/32 + 1) == 1 ) then
            if ( iatom <= natom ) then
                coef1 = atomicadd(elecvdw_force_d(1,iatom),dble(ifrc(1)+jfrc(1)))
                coef1 = atomicadd(elecvdw_force_d(2,iatom),dble(ifrc(2)+jfrc(2)))
                coef1 = atomicadd(elecvdw_force_d(3,iatom),dble(ifrc(3)+jfrc(3)))
            end if
        else
            if ( iatom <= natom ) then
                coef1 = atomicadd(elecvdw_force_d(1,iatom),dble(ifrc(1)))
                coef1 = atomicadd(elecvdw_force_d(2,iatom),dble(ifrc(2)))
                coef1 = atomicadd(elecvdw_force_d(3,iatom),dble(ifrc(3)))
            end if
            jatom = jatomstart + ithread-1
            if ( jatom <= natom ) then
                coef1 = atomicadd(elecvdw_force_d(1,jatom),dble(jfrc(1)))
                coef1 = atomicadd(elecvdw_force_d(2,jatom),dble(jfrc(2)))
                coef1 = atomicadd(elecvdw_force_d(3,jatom),dble(jfrc(3)))
            end if
        end if
    end if

  if ( .not. cgifcalpot_d ) return

  index = 1
  do while (index<=16)
     coef1 = __shfl_xor(tpelec,index); tpelec = tpelec + coef1
     coef1 = __shfl_xor(tpvdw,index); tpvdw = tpvdw + coef1
     index = index*2
  end do

  if ( ithread == 1 ) then
     coef1 = atomicadd(cgeelec_d,dble(tpelec))
     coef1 = atomicadd(cgevdw_d,dble(tpvdw))
  end if

end subroutine

attributes(global) subroutine cudacg_constraint_bond()
    integer :: icst,iatom,jatom
    real :: eqval,tpvec(3),tpdis

    icst = (blockidx%x-1)*blockdim%x + threadidx%x; if ( icst > ncst_d ) return
    iatom = cgcstatoms_d(1,icst)
    jatom = cgcstatoms_d(2,icst)
    eqval = cgcstlength_d(icst)
    tpvec = cgcoor_d(:,iatom) - cgcoor_d(:,jatom)
    tpdis = sqrt(dot_product(tpvec,tpvec))
    tpvec = - restraint_force_const_d * ( tpdis - eqval ) * tpvec / tpdis

    ! this term would not be added into force check
    icst = atomicadd(cgforce_d(1, iatom),dble(tpvec(1)))
    icst = atomicadd(cgforce_d(2, iatom),dble(tpvec(2)))
    icst = atomicadd(cgforce_d(3, iatom),dble(tpvec(3)))

    icst = atomicadd(cgforce_d(1, jatom),-dble(tpvec(1)))
    icst = atomicadd(cgforce_d(2, jatom),-dble(tpvec(2)))
    icst = atomicadd(cgforce_d(3, jatom),-dble(tpvec(3)))
end subroutine

subroutine cudacg_ccma_execute(ifdovel)
  logical,intent(in),optional :: ifdovel
  integer :: iter,maxiter
  logical :: ifconverged

  if ( ncst == 0 ) return

  maxiter = 100; iter = 0
  do while ( (ifconverged .eqv. .false.) .and. (iter < maxiter) )
     iter = iter + 1

     cstifconverged_d = .true.

     if ( .not. present(ifdovel) ) then
        call cudacg_ccma_cstdelta_coor<<<(ncst-1)/32+1,32>>>()
     else
        call cudacg_ccma_cstdelta_vel<<<(ncst-1)/32+1,32>>>()
     end if
     ifconverged = cstifconverged_d

     if ( ifconverged ) exit

     cgcstsumdelta_d = 0d0
     call cudacg_ccma_cstsumdelta<<<(njacobicst-1)/32+1,32>>>()

     if ( .not. present(ifdovel) ) then
        call cudacg_ccma_udpatecoor<<<(ncst-1)/32+1,32>>>()
     else
        call cudacg_ccma_udpatevel<<<(ncst-1)/32+1,32>>>()
     end if

  end do

  if ( ifconverged ) then
     !print *,"CCMA converged, iteration step is ",iter
  else
     print *,"CCMA not converged!"
  end if

  if ( (nvirtualsite > 0) .and. (.not. present(ifdovel)) ) then
     call cudacg_virtualsite_set_coordinate<<<(nvirtualsite-1)/32+1,32>>>()
  end if

end subroutine

attributes(global) subroutine cudacg_ccma_cstdelta_coor()
  integer :: icst,iatom,jatom
  real :: eqvalsq,tpvec(3),dissq,tpprevec(3)

  icst = (blockidx%x-1)*blockdim%x + threadidx%x; if ( icst > ncst_d ) return
  iatom = cgcstatoms_d(1,icst); jatom = cgcstatoms_d(2,icst)
  tpvec = cgcoor_d(:,iatom) - cgcoor_d(:,jatom)
  tpprevec = cgprecoor_d(:,iatom) - cgprecoor_d(:,jatom)
  dissq = dot_product(tpvec,tpvec)
  eqvalsq = cgcstlength_d(icst)**2
  cgcstdelta_d(icst) = 0.5*cst_reduced_mass_d(icst)*(eqvalsq - dissq)/dot_product(tpvec,tpprevec)

  if ( cstifconverged_d .eqv. .true. ) then
     if ( (dissq < cgcstlowtol_d*eqvalsq) .or. (dissq > cgcstuptol_d*eqvalsq) ) cstifconverged_d = .false.
  end if
end subroutine

attributes(global) subroutine cudacg_ccma_cstdelta_vel()
  integer :: icst,iatom,jatom
  real :: sigma,tpvalue,tpvec(3),tpprevec(3)

  icst = (blockidx%x-1)*blockdim%x + threadidx%x; if ( icst > ncst_d ) return
  iatom = cgcstatoms_d(1,icst); jatom = cgcstatoms_d(2,icst)

  tpprevec = cgcoor_d(:, iatom) - cgcoor_d(:, jatom)
  tpvec = cgvel_d(:, iatom) - cgvel_d(:, jatom)
  sigma = dot_product(tpvec,tpprevec)
  tpvalue = dot_product(tpprevec,tpprevec)
  cgcstdelta_d(icst) = -cst_reduced_mass_d(icst)*sigma/tpvalue

  if ( cstifconverged_d .eqv. .true. ) then
     if ( abs(cgcstdelta_d(icst)) > cgcsttol_d ) cstifconverged_d = .false.
  end if
end subroutine

attributes(global) subroutine cudacg_ccma_cstsumdelta()
  integer :: icst,jcst,index
  real :: tpvalue

  index = (blockidx%x-1)*blockdim%x + threadidx%x; if ( index > njacobicst_d ) return
  icst = jacobicstindexij_d(1,index); jcst = jacobicstindexij_d(2,index)
  tpvalue = atomicadd(cgcstsumdelta_d(icst), cgcstdelta_d(jcst)*jacobicstval_d(index))
end subroutine

attributes(global) subroutine cudacg_ccma_udpatecoor()
  integer :: icst,iatom,jatom
  real :: tp,tpprevec(3),tpcgmassinv

  icst = (blockidx%x-1)*blockdim%x + threadidx%x; if ( icst > ncst_d ) return
  iatom = cgcstatoms_d(1,icst); jatom = cgcstatoms_d(2,icst)
  tpprevec = (cgprecoor_d(:,iatom) - cgprecoor_d(:,jatom))*cgcstsumdelta_d(icst)

  tpcgmassinv = cgmassinv_d(iatom)
  tp = atomicadd(cgcoor_d(1,iatom), dble(tpprevec(1)*tpcgmassinv))
  tp = atomicadd(cgcoor_d(2,iatom), dble(tpprevec(2)*tpcgmassinv))
  tp = atomicadd(cgcoor_d(3,iatom), dble(tpprevec(3)*tpcgmassinv))
  tpcgmassinv = cgmassinv_d(jatom)
  tp = atomicadd(cgcoor_d(1,jatom), dble(-tpprevec(1)*tpcgmassinv))
  tp = atomicadd(cgcoor_d(2,jatom), dble(-tpprevec(2)*tpcgmassinv))
  tp = atomicadd(cgcoor_d(3,jatom), dble(-tpprevec(3)*tpcgmassinv))
end subroutine

attributes(global) subroutine cudacg_ccma_udpatevel()
  integer :: icst,iatom,jatom
  real :: tp,tpprevec(3),tpcgmassinv

  icst = (blockidx%x-1)*blockdim%x + threadidx%x; if ( icst > ncst_d ) return
  iatom = cgcstatoms_d(1,icst); jatom = cgcstatoms_d(2,icst)
  tpprevec = (cgcoor_d(:,iatom) - cgcoor_d(:,jatom))*cgcstsumdelta_d(icst)

  tpcgmassinv = cgmassinv_d(iatom)
  tp = atomicadd(cgvel_d(1,iatom), dble(tpprevec(1)*tpcgmassinv))
  tp = atomicadd(cgvel_d(2,iatom), dble(tpprevec(2)*tpcgmassinv))
  tp = atomicadd(cgvel_d(3,iatom), dble(tpprevec(3)*tpcgmassinv))
  tpcgmassinv = cgmassinv_d(jatom)
  tp = atomicadd(cgvel_d(1,jatom), dble(-tpprevec(1)*tpcgmassinv))
  tp = atomicadd(cgvel_d(2,jatom), dble(-tpprevec(2)*tpcgmassinv))
  tp = atomicadd(cgvel_d(3,jatom), dble(-tpprevec(3)*tpcgmassinv))
end subroutine

end module
