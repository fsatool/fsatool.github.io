module martini
    use itp_reader
    use utils
    use public
    implicit none

    type MartiniClass
        type(itp_info) :: data

        real*8 :: total_potential
        ! bond terms potential
        real*8 :: bond_potential,angle_1_potential, angle_2_potential, angle_10_potential, dihedral_1_potential, dihedral_2_potential, dihedral_3_potential, dihedral_4_potential
        ! non-bonded terms potential
        real*8 :: LJ_potential, elec_static_potential, elec_self_potential, elec_exclude_potential

        real*8, dimension(:,:), pointer :: total_force
        ! bond terms force
        real*8, dimension(:,:), pointer :: bond_force, angle_force_1, angle_force_2, angle_force_10, dihedral_force_1, dihedral_force_2, dihedral_force_3, dihedral_force_4
        ! non-bonded terms force
        real*8, dimension(:,:), pointer :: LJ_force, elecS_exclude_force
        contains
        PROCEDURE :: bond => bond
        PROCEDURE :: constraint_bond => constraint_bond
        PROCEDURE :: angle => angle
        PROCEDURE :: dihedral => dihedral
        ! static electric and VDW
        PROCEDURE :: elecS_VDW => elecS_VDW
        PROCEDURE :: elec_exclude_pot => elec_exclude_pot

        PROCEDURE :: virtual_site_distribute_force => virtual_site_distribute_force

        PROCEDURE :: init => init

        PROCEDURE :: potforce => potforce
        PROCEDURE :: print_single_pointe_info => print_single_pointe_info
        PROCEDURE :: force_pointer => force_pointer
    end type

    public :: MartiniClass
    private :: m_get_vec_by_coor_periodic, m_get_sin_from_vec3_p

contains

subroutine init(self, itp_reader)
    class(MartiniClass) :: self
    type(itp_info) :: itp_reader
    self%data = itp_reader
    self%elec_self_potential = cgeself
end subroutine

subroutine force_pointer(self)
    class(MartiniClass) :: self

    self%total_force => cgforce
    self%bond_force => self%total_force
    self%angle_force_1 => self%total_force
    self%angle_force_2 => self%total_force
    self%angle_force_10 => self%total_force
    self%dihedral_force_1 => self%total_force
    self%dihedral_force_2 => self%total_force
    self%dihedral_force_3 => self%total_force
    self%dihedral_force_4 => self%total_force
    self%LJ_force => self%total_force
    self%elecS_exclude_force => self%total_force
end subroutine

real*8 function m_get_sin_from_vec3_p(rij_vec3, rkj_vec3) result(res)
    real*8, dimension(:) :: rij_vec3, rkj_vec3

    real*8 :: rij_sq, rij, rkj_sq, rkj
    real*8 :: cos_thta

    rij_sq = dot_product(rij_vec3, rij_vec3)
    rij = sqrt(rij_sq)
    rkj_sq = dot_product(rkj_vec3, rkj_vec3)
    rkj = sqrt(rkj_sq)
    cos_thta = dot_product(rij_vec3, rkj_vec3) / (rij*rkj)
    res = sin(acos(cos_thta))
end function

real*8 function m_get_vec_by_coor_periodic(coor_i, coor_j, rij_vec3, periodic_vec) result(r_ij_sq)
    real*8, dimension(3) :: coor_i, coor_j, rij_vec3
    real*8, dimension(3) :: periodic_vec

    integer :: i_x
    real*8, dimension(3) :: fix_coor_j

    rij_vec3(:) = coor_i(:) - coor_j(:)
    fix_coor_j(:) = coor_j(:)

    do i_x = 1, 3
        if (rij_vec3(i_x) > 0.5d0*periodic_vec(i_x)) then
            fix_coor_j(i_x) = coor_j(i_x) + periodic_vec(i_x)
        elseif (rij_vec3(i_x) < -0.5d0*periodic_vec(i_x)) then
            fix_coor_j(i_x) = coor_j(i_x) - periodic_vec(i_x)
        end if
    end do
    rij_vec3(:) = coor_i(:) - fix_coor_j(:)
    r_ij_sq = dot_product(rij_vec3, rij_vec3)
end function

subroutine print_single_pointe_info(self)
    class(MartiniClass) :: self
    integer :: atom_num
    atom_num = self%data%atom_num

    PRINT *, "vvv===================================================vvv"

    CALL m_format_print("All", self%total_potential, scaled_force(self%total_force, atom_num))

    CALL m_format_print("bond", self%bond_potential, scaled_force(self%bond_force, atom_num))

    CALL m_format_print("angle_1", self%angle_1_potential, scaled_force(self%angle_force_1, atom_num))

    CALL m_format_print("angle_2", self%angle_2_potential, scaled_force(self%angle_force_2, atom_num))

    CALL m_format_print("angle_10", self%angle_10_potential, scaled_force(self%angle_force_10, atom_num))

    CALL m_format_print("dihedral_1", self%dihedral_1_potential, scaled_force(self%dihedral_force_1, atom_num))

    CALL m_format_print("dihedral_2", self%dihedral_2_potential, scaled_force(self%dihedral_force_2, atom_num))

    CALL m_format_print("dihedral_3", self%dihedral_3_potential, scaled_force(self%dihedral_force_3, atom_num))

    CALL m_format_print("dihedral_4", self%dihedral_4_potential, scaled_force(self%dihedral_force_4, atom_num))

    CALL m_format_print("LJ_force", self%LJ_potential, scaled_force(self%LJ_force, atom_num))

    CALL m_format_print("elec_static", self%elec_static_potential, scaled_force(self%LJ_force, atom_num))

    CALL m_format_print("elec_self", self%elec_self_potential, scaled_force(self%elecS_exclude_force, atom_num))

    CALL m_format_print("elec_exclude", self%elec_exclude_potential, scaled_force(self%elecS_exclude_force, atom_num))
end subroutine

subroutine potforce(self, check)
    use cgpb
    class(MartiniClass) :: self
    logical,intent(in),optional :: check
    type(itp_info) :: the_data
    integer :: i,_atom_num

    the_data = self%data; _atom_num = self%data%atom_num

    if ( present(check) ) then
        allocate(self%bond_force(3, _atom_num), self%angle_force_1(3, _atom_num), self%angle_force_2(3, _atom_num), self%angle_force_10(3, _atom_num), self%dihedral_force_1(3, _atom_num), self%dihedral_force_2(3, _atom_num), self%dihedral_force_3(3, _atom_num), self%dihedral_force_4(3, _atom_num), self%LJ_force(3, _atom_num), self%elecS_exclude_force(3, _atom_num))
        self%bond_force = 0d0; self%angle_force_1 = 0d0; self%angle_force_2 = 0d0; self%angle_force_10 = 0d0
        self%dihedral_force_1 = 0d0; self%dihedral_force_2 = 0d0; self%dihedral_force_3 = 0d0; self%dihedral_force_4 = 0d0
        self%LJ_force = 0d0; self%elecS_exclude_force = 0d0; self%total_force = 0d0
        call cgpb_elecvdw_force_pointer(self%LJ_force)
    else
        self%total_force = 0d0
    end if

    if (.not. nocgnatomtype) then
        if ( cgipb == 0 ) then
            call self%elecS_VDW()
        else
            call cgpb_potforce()
        end if
    end if

    if (.not. nobond) call self%bond()
  
    if (.not. noangle) call self%angle()

    if (.not. nodihedral) call self%dihedral()

    if (.not. noexclusion) call self%elec_exclude_pot()

    if ( present(check) ) then
        self%total_force = self%bond_force + self%angle_force_1 + self%angle_force_2 + self%angle_force_10 + self%dihedral_force_1 + self%dihedral_force_2 + self%dihedral_force_3 + self%dihedral_force_4 + self%LJ_force + self%elecS_exclude_force
    end if

    if ( cgifcalpot ) then
       self%LJ_potential = cgevdw
       self%elec_static_potential = cgeelec
       self%total_potential = self%bond_potential + self%angle_1_potential +  &
                              self%angle_2_potential + self%angle_10_potential + self%dihedral_1_potential + &
                              self%dihedral_2_potential + self%dihedral_3_potential + self%dihedral_4_potential + &
                              self%elec_static_potential + self%LJ_potential + cgeself +  self%elec_exclude_potential
    end if
 
    if (nvirtualsite > 0) then
        call self%virtual_site_distribute_force()
    end if

    if ( present(check) ) call self%print_single_pointe_info()

end subroutine

subroutine bond(self)
    class(MartiniClass) :: self
    type(itp_info) :: the_data
    integer :: ibond, iatom, jatom, func_type
    real*8 :: bij, kij, rij_vec3(3), rij, potential_coef
    real*8 :: total_potential, potential, force(3)

    ! temp pointer
    real*8, dimension(:,:), pointer :: bond_force
    bond_force => self%bond_force

    total_potential = 0d0
    the_data = self%data

    do ibond = 1, the_data%bond_num
        iatom = the_data%iatom(ibond)
        jatom = the_data%jatom(ibond)
        func_type = the_data%func_type(ibond)

        bij = the_data%equil_value(ibond)
        kij = the_data%force_const(ibond)
        rij = get_vec_by_coor(cgcoor(:, iatom), cgcoor(:, jatom), rij_vec3)        

        potential_coef = 0.5d0 * kij * (rij-bij)
        potential = potential_coef * (rij-bij)
        total_potential = total_potential + potential

        ! force calculation
        force(:) = -2d0 * potential_coef / rij * rij_vec3(:)
        bond_force(:, iatom) = bond_force(:, iatom) + force
        bond_force(:, jatom) = bond_force(:, jatom) - force
    end do
    self%bond_potential = total_potential
end subroutine

subroutine constraint_bond(self)
    class(MartiniClass) :: self
    integer :: i_constraint, iatom, jatom
    real*8 :: bij, kij, rij_vec3(3), rij, potential_coef, force(3)
    real*8, pointer, dimension(:) :: restraint_dis
    real*8, pointer, dimension(:,:) :: atom_coor
    integer, dimension(:,:), pointer :: restraint_pairs

    restraint_pairs => self%data%constraint
    restraint_dis => self%data%constraint_length
    kij = restraint_force_const

    do i_constraint = 1, self%data%constraint_num
        iatom = restraint_pairs(i_constraint, 1)
        jatom = restraint_pairs(i_constraint, 2)
        bij = restraint_dis(i_constraint)
        rij = get_vec_by_coor(cgcoor(:, iatom), cgcoor(:, jatom), rij_vec3)
        potential_coef = 0.5 * kij * (rij - bij)

        force(:) = -2d0 * potential_coef / rij * rij_vec3(:)
        cgforce(:, iatom) = cgforce(:, iatom) + force
        cgforce(:, jatom) = cgforce(:, jatom) - force
    end do
end subroutine 

subroutine angle(self)
    class(MartiniClass) :: self
    type(itp_info) :: the_data
    integer :: i,j,k, i_angle
    real*8, dimension(3) :: rij_vec3, rkj_vec3
    real*8 :: dV_dcos_theta, temp
    real*8 :: rij_sq, rkj_sq, rij_mul_rkj, rij_dot_rkj, cos_theta
    real*8 :: bracket, coef_k, coef_theta_0, k_mul_bracket
    real*8 :: single_potential,potential_1, potential_2, potential_10, cos_theta_0
    real*8, dimension(3) :: dcos_drij_vec3, dcos_drkj_vec3
    real*8 :: theta, delta_theta

    ! temp pointer
    real*8, dimension(:,:), pointer :: angle_force_1, angle_force_2, angle_force_10
    angle_force_1 => self%angle_force_1
    angle_force_2 => self%angle_force_2
    angle_force_10 => self%angle_force_10

    the_data = self%data
    potential_2 = 0d0
    single_potential = 0d0
    potential_10 = 0d0
    potential_1 = 0d0

    do i_angle = 1, the_data%angle_num
        coef_k = the_data%angle_force_const(i_angle)
        coef_theta_0 = the_data%angle_equil_value(i_angle)
        i = the_data%angle_iatom(i_angle)
        j = the_data%angle_jatom(i_angle)
        k = the_data%angle_katom(i_angle)
        rij_vec3(:) = cgcoor(:, i) - cgcoor(:, j)
        rij_sq = dot_product(rij_vec3, rij_vec3)
        rkj_vec3(:) = cgcoor(:, k) - cgcoor(:, j)
        rkj_sq = dot_product(rkj_vec3, rkj_vec3)

        rij_mul_rkj = sqrt(rij_sq*rkj_sq)
        rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
        cos_theta = rij_dot_rkj / rij_mul_rkj
        cos_theta = min(0.9999999d0, max(-0.9999999d0, cos_theta))
        cos_theta_0 = cos(coef_theta_0)

        bracket = cos_theta-cos_theta_0
        k_mul_bracket = coef_k*bracket
        single_potential = k_mul_bracket * bracket * 0.5

        !if (self%get_force) then 
            temp = 1 / rij_mul_rkj
            dcos_drij_vec3(:) = temp * (rkj_vec3(:) - rij_vec3(:) * rij_dot_rkj / (rij_sq))
            dcos_drkj_vec3(:) = temp * (rij_vec3(:) - rkj_vec3(:) * rij_dot_rkj / (rkj_sq))
        !end if
  
        if (the_data%angle_func_type(i_angle) == 1) then
            theta = acos(cos_theta)           
            delta_theta = theta - coef_theta_0  
            single_potential = 0.5d0 * coef_k * delta_theta * delta_theta
            potential_1 = potential_1 + single_potential

            !if (self%get_force) then
                dV_dcos_theta = (coef_k * delta_theta) / sqrt(1.0d0 - cos_theta*cos_theta)                
                angle_force_1(:, i) = angle_force_1(:, i) + dV_dcos_theta * dcos_drij_vec3(:)
                angle_force_1(:, k) = angle_force_1(:, k) + dV_dcos_theta * dcos_drkj_vec3(:)
                angle_force_1(:, j) = angle_force_1(:, j) - dV_dcos_theta * dcos_drij_vec3(:) - dV_dcos_theta * dcos_drkj_vec3(:)
            !end if

        elseif (the_data%angle_func_type(i_angle) == 2) then
            potential_2 = potential_2 + single_potential

            !if (self%get_force) then
                angle_force_2(:, i) = angle_force_2(:, i) - k_mul_bracket * (dcos_drij_vec3(:))
                angle_force_2(:, j) = angle_force_2(:, j) - k_mul_bracket * -(dcos_drij_vec3(:) + dcos_drkj_vec3(:))
                angle_force_2(:, k) = angle_force_2(:, k) - k_mul_bracket * (0 + dcos_drkj_vec3(:))
            !end if

        elseif (the_data%angle_func_type(i_angle) == 10) then
            ! 1 / sin_theta**2
            temp = 1d0/(1.0d0 - cos_theta**2)
            single_potential = single_potential * temp
            potential_10 = potential_10 + single_potential

            dV_dcos_theta = k_mul_bracket * temp * (1 + bracket * temp * cos_theta)
            angle_force_10(:, i) = angle_force_10(:, i) - dV_dcos_theta * (dcos_drij_vec3(:))
            angle_force_10(:, j) = angle_force_10(:, j) - dV_dcos_theta * -(dcos_drij_vec3(:) + dcos_drkj_vec3(:))
            angle_force_10(:, k) = angle_force_10(:, k) - dV_dcos_theta * (dcos_drkj_vec3(:))
        else
            print *, "angle_func_type error!"
        end if

    end do
    self%angle_1_potential = potential_1
    self%angle_2_potential = potential_2
    self%angle_10_potential = potential_10

end subroutine

subroutine get_sin_angle_derivative(atom_0, atom_1, atom_2, atom_coor, dcos_dr_01_vec3, dcos_dr_21_vec3, sin_angle)
    integer :: atom_0, atom_1, atom_2
    real*8, dimension(:,:) :: atom_coor
    real*8, dimension(:), intent(inout) :: dcos_dr_01_vec3, dcos_dr_21_vec3

    real*8, dimension(3) :: r_01_vec3, r_21_vec3
    real*8 :: r_01_sq, r_01, r_21_sq, r_21

    real*8 :: temp, r_01_mul_r_21, r_01_dot_r_21
    real*8 :: cos_angle, sin_angle

    r_01_vec3(:) = atom_coor(:, atom_0) - atom_coor(:, atom_1)
    r_01_sq = dot_product(r_01_vec3, r_01_vec3)
    r_01 = sqrt(r_01_sq)
    r_21_vec3(:) = atom_coor(:, atom_2) - atom_coor(:, atom_1)
    r_21_sq = dot_product(r_21_vec3, r_21_vec3)
    r_21 = sqrt(r_21_sq)
    r_01_mul_r_21 = r_01*r_21
    r_01_dot_r_21 = dot_product(r_01_vec3, r_21_vec3)

    cos_angle = r_01_dot_r_21 / r_01_mul_r_21
    temp = -cos_angle / (r_01_mul_r_21*sin_angle)
    dcos_dr_01_vec3(:) = temp * (r_21_vec3(:) - r_01_vec3(:) * r_01_dot_r_21 / (r_01_sq))
    dcos_dr_21_vec3(:) = temp * (r_01_vec3(:) - r_21_vec3(:) * r_01_dot_r_21 / (r_21_sq))
end subroutine

subroutine dihedral(self)
    class(MartiniClass) :: self
    type(itp_info) :: the_data

    real*8 :: normal_p, improper_p, rb_p, combined_p

    integer :: atom_0, atom_1, atom_2, atom_3, coef_n  
    real*8 :: k_theta, theta_0, theta, theta_p
    real*8, dimension(3) :: rij_vec3, rkj_vec3, rkl_vec3
    real*8, dimension(3) :: n_1_vec3, n_2_vec3
    real*8 :: n_1, n_2, n_1_sq, n_2_sq

    real*8, dimension(6) :: params       
    real*8 :: temp_sum, first_temp                    
    real*8 :: sin_1, sin_2                
    real*8, dimension(3) :: dcos_drij_vec3, dcos_drkl_vec3
    real*8 :: temp

    integer :: i_dihedral, func_type  

    real*8 :: rij_dot_rkj, rkj_sq, rkj
    real*8 :: rkl_dot_rkj
    real*8 :: cos_temp, sin_temp, temp_vec3(3), temp_1_vec3(3), temp_2_vec3(3)
    real*8 :: dV_dTheta
    real*8 :: dTheta_dCosTheta

    real*8, dimension(:,:), pointer :: dihedral_force_1, dihedral_force_2, dihedral_force_3, dihedral_force_4
    dihedral_force_1 => self%dihedral_force_1
    dihedral_force_2 => self%dihedral_force_2
    dihedral_force_3 => self%dihedral_force_3
    dihedral_force_4 => self%dihedral_force_4

    the_data = self%data

    normal_p = 0d0; improper_p = 0d0; rb_p = 0d0; combined_p = 0d0

    do i_dihedral = 1, the_data%dihedral_num
        func_type = the_data%dihedral_func_type(i_dihedral)
        atom_0 = the_data%dihedral_atom_0(i_dihedral)
        atom_1 = the_data%dihedral_atom_1(i_dihedral)
        atom_2 = the_data%dihedral_atom_2(i_dihedral)
        atom_3 = the_data%dihedral_atom_3(i_dihedral)

        ! vvv===========get_phi_parameters=====vvvvvvvv
        rij_vec3(:) = cgcoor(:, atom_0) - cgcoor(:, atom_1)
        rkj_vec3(:) = cgcoor(:, atom_2) - cgcoor(:, atom_1)
        rkl_vec3(:) = cgcoor(:, atom_2) - cgcoor(:, atom_3)
        call m_cross_product(rij_vec3, rkj_vec3, n_1_vec3)
        call m_cross_product(rkj_vec3, rkl_vec3, n_2_vec3)
        n_1_sq = dot_product(n_1_vec3, n_1_vec3)
        n_2_sq = dot_product(n_2_vec3, n_2_vec3)
        n_1 = sqrt(n_1_sq)
        n_2 = sqrt(n_2_sq)
        ! ^^^==========get_phi_parameters======^^^^^^^^^

        theta = m_get_phi(rij_vec3, n_1_vec3, n_2_vec3, n_1, n_2)

        if ( func_type == 1 ) then
            k_theta = the_data%dihedral_force_const(i_dihedral)
            theta_0 = the_data%dihedral_equil_value(i_dihedral)
            coef_n = the_data%dihedral_extra_int(i_dihedral)
            cos_temp = cos(coef_n*theta - theta_0)
            normal_p = normal_p + k_theta * (1.0d0 + cos_temp)

            !if (self%get_force) then
                sin_temp = sin(coef_n*theta - theta_0)
                dV_dTheta = (- k_theta * sin_temp * coef_n) * (-1)

                dTheta_dCosTheta = -1d0 / sin(theta)

                rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
                rkj_sq = dot_product(rkj_vec3, rkj_vec3)
                rkj = sqrt(rkj_sq)
                rkl_dot_rkj = dot_product(rkl_vec3, rkj_vec3)
                dV_dTheta = dV_dTheta * rkj

                temp_1_vec3(:) = dV_dTheta * n_1_vec3(:) / n_1_sq
                temp_2_vec3(:) = -dV_dTheta * n_2_vec3(:) / n_2_sq
                temp_vec3(:) = (rij_dot_rkj * temp_1_vec3(:) - rkl_dot_rkj * temp_2_vec3(:)) / rkj_sq
                
                dihedral_force_1(:, atom_0) = dihedral_force_1(:, atom_0) + temp_1_vec3(:)
                dihedral_force_1(:, atom_1) = dihedral_force_1(:, atom_1) - temp_1_vec3(:) + temp_vec3(:)
                dihedral_force_1(:, atom_2) = dihedral_force_1(:, atom_2) - temp_2_vec3(:) - temp_vec3(:)
                dihedral_force_1(:, atom_3) = dihedral_force_1(:, atom_3) + temp_2_vec3(:)
            !end if

        elseif ( func_type == 2 ) then
            k_theta = the_data%dihedral_force_const(i_dihedral)
            theta_0 = the_data%dihedral_equil_value(i_dihedral)

            theta_p = theta-theta_0
            if (theta_p > PI) then
                theta_p = theta_p - 2d0*PI
            elseif (theta_p < -PI) then
                theta_p = theta_p + 2d0*PI
            end if

            improper_p = improper_p + 0.5*k_theta*(theta_p)**2

            !if (self%get_force) then
                dV_dTheta = -1d0* k_theta * theta_p

                rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
                rkj_sq = dot_product(rkj_vec3, rkj_vec3)
                rkj = sqrt(rkj_sq)
                rkl_dot_rkj = dot_product(rkl_vec3, rkj_vec3)
                dV_dTheta = dV_dTheta * rkj

                temp_1_vec3(:) = dV_dTheta * n_1_vec3(:) / n_1_sq
                temp_2_vec3(:) = -dV_dTheta * n_2_vec3(:) / n_2_sq
                temp_vec3(:) = (rij_dot_rkj * temp_1_vec3(:) - rkl_dot_rkj * temp_2_vec3(:)) / rkj_sq
                
                dihedral_force_2(:, atom_0) = dihedral_force_2(:, atom_0) + temp_1_vec3(:)
                dihedral_force_2(:, atom_1) = dihedral_force_2(:, atom_1) - temp_1_vec3(:) + temp_vec3(:)
                dihedral_force_2(:, atom_2) = dihedral_force_2(:, atom_2) - temp_2_vec3(:) - temp_vec3(:)
                dihedral_force_2(:, atom_3) = dihedral_force_2(:, atom_3) + temp_2_vec3(:)
            !end if
        
        elseif ( func_type == 3 ) then

            params = the_data%dihedral_extra_real(1:6, i_dihedral)
            cos_temp = cos(theta-PI)

            rb_p = rb_p + params(1) + params(2) * cos_temp + params(3) * cos_temp**2 + params(4) * cos_temp**3 + params(5) * cos_temp**4 + params(6) * cos_temp**5

            !if (self%get_force) then
                sin_temp = sin(theta-PI)
                dV_dTheta = params(2) + (2 * params(3) * cos_temp) + (3 * params(4) * cos_temp**2) + (4 * params(5) * cos_temp**3) + (5 * params(6) * cos_temp**4)
                dV_dTheta = dV_dTheta * sin_temp
                
                rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
                rkj_sq = dot_product(rkj_vec3, rkj_vec3)
                rkj = sqrt(rkj_sq)
                rkl_dot_rkj = dot_product(rkl_vec3, rkj_vec3)
                dV_dTheta = dV_dTheta * rkj  

                temp_1_vec3(:) = dV_dTheta * n_1_vec3(:) / n_1_sq
                temp_2_vec3(:) = -dV_dTheta * n_2_vec3(:) / n_2_sq
                temp_vec3(:) = (rij_dot_rkj * temp_1_vec3(:) - rkl_dot_rkj * temp_2_vec3(:)) / rkj_sq

                dihedral_force_3(:, atom_0) = dihedral_force_3(:, atom_0) + temp_1_vec3(:)
                dihedral_force_3(:, atom_1) = dihedral_force_3(:, atom_1) - temp_1_vec3(:) + temp_vec3(:)
                dihedral_force_3(:, atom_2) = dihedral_force_3(:, atom_2) - temp_2_vec3(:) - temp_vec3(:)
                dihedral_force_3(:, atom_3) = dihedral_force_3(:, atom_3) + temp_2_vec3(:)
            !end if

        elseif (func_type == 4) then

            params = the_data%dihedral_extra_real(1:6, i_dihedral)
            cos_temp = cos(theta)
            temp_sum = params(2) + params(3) * cos_temp + params(4) * cos_temp**2 + params(5) * cos_temp**3 + params(6) * cos_temp**4

            sin_1 = m_get_sin_from_vec3_p(rij_vec3, rkj_vec3)
            sin_2 = m_get_sin_from_vec3_p(rkj_vec3, rkl_vec3)

            combined_p = combined_p + temp_sum * params(1) * sin_1**3 * sin_2**3
            !if (self%get_force) then
                temp = params(1) * sin_1**2 * sin_2**2

                ! ================== first ============================
                first_temp = temp * sin_2 * temp_sum * 3d0
                call get_sin_angle_derivative(atom_0, atom_1, atom_2, cgcoor, dcos_drij_vec3, dcos_drkl_vec3, sin_1)

                dihedral_force_4(:, atom_0) = dihedral_force_4(:, atom_0) - first_temp * dcos_drij_vec3(:)
                dihedral_force_4(:, atom_1) = dihedral_force_4(:, atom_1) + first_temp * (dcos_drij_vec3(:) + dcos_drkl_vec3(:))
                dihedral_force_4(:, atom_2) = dihedral_force_4(:, atom_2) - first_temp * dcos_drkl_vec3(:)

                ! ================== second ============================
                call get_sin_angle_derivative(atom_1, atom_2, atom_3, cgcoor, dcos_drij_vec3, dcos_drkl_vec3, sin_2)
                first_temp = temp * sin_1 * temp_sum * 3d0

                dihedral_force_4(:, atom_1) = dihedral_force_4(:, atom_1) - first_temp * dcos_drij_vec3(:)
                dihedral_force_4(:, atom_2) = dihedral_force_4(:, atom_2) + first_temp * (dcos_drij_vec3(:) + dcos_drkl_vec3(:))
                dihedral_force_4(:, atom_3) = dihedral_force_4(:, atom_3) - first_temp * dcos_drkl_vec3(:)

                ! ================== third ============================
                sin_temp = sin(theta)
                first_temp = -sin_temp * (params(3) + 2d0*params(4) * cos_temp + 3d0*params(5) * cos_temp**2 + 4d0*params(6) * cos_temp**3)
                dV_dTheta = temp * sin_2 * sin_1 * first_temp * (-1d0)

                rij_dot_rkj = dot_product(rij_vec3, rkj_vec3)
                rkj_sq = dot_product(rkj_vec3, rkj_vec3)
                rkj = sqrt(rkj_sq)
                rkl_dot_rkj = dot_product(rkl_vec3, rkj_vec3)
                dV_dTheta = dV_dTheta * rkj

                temp_1_vec3(:) = dV_dTheta * n_1_vec3(:) / n_1_sq
                temp_2_vec3(:) = -dV_dTheta * n_2_vec3(:) / n_2_sq
                temp_vec3(:) = (rij_dot_rkj * temp_1_vec3(:) - rkl_dot_rkj * temp_2_vec3(:)) / rkj_sq

                dihedral_force_4(:, atom_0) = dihedral_force_4(:, atom_0) + temp_1_vec3(:)
                dihedral_force_4(:, atom_1) = dihedral_force_4(:, atom_1) - temp_1_vec3(:) + temp_vec3(:)
                dihedral_force_4(:, atom_2) = dihedral_force_4(:, atom_2) - temp_2_vec3(:) - temp_vec3(:)
                dihedral_force_4(:, atom_3) = dihedral_force_4(:, atom_3) + temp_2_vec3(:)
            !end if
        else
            print *, "unknown dihedral index: ", i_dihedral
        end if
    end do

    self%dihedral_1_potential = normal_p
    self%dihedral_2_potential = improper_p
    self%dihedral_3_potential = rb_p
    self%dihedral_4_potential = combined_p
end subroutine

subroutine elecS_VDW(self)
    class(MartiniClass) :: self
    type(itp_info) :: the_data

    integer :: i, j, iatom_type, jatom_type
    real*8 :: rij_vec3(3), dis, qi,qj, corr, sigma, eps
    real*8 :: r_ij, r_ij_sq
    real*8, dimension(3) :: icoor
    integer :: tpnexc,lastiexc
    logical :: ifskipatoms(self%data%atom_num)
    real*8 :: dissq,rcutsq,coef1,coef2,dis_inv,dis_0_inv,ES_coef

    real*8 :: single_potential, elec_static_potential, LJ_potential
    real*8, dimension(:,:), pointer :: LJ_force
    LJ_force => self%LJ_force

    the_data = self%data
    the_data%periodic_box_vec = cgcell

    elec_static_potential = 0d0
    LJ_potential = 0d0
    lastiexc = 0

    dis_0_inv = 1d0/rcut
    rcutsq = rcut*rcut

    do i = 1, the_data%atom_num

        ifskipatoms(i+1:the_data%atom_num)=.false.
        tpnexc = cgnexcludedatoms(i)
        ifskipatoms(cgexcludedatomlist(lastiexc+1:lastiexc+tpnexc))=.true.
        lastiexc = lastiexc + tpnexc
        qi = the_data%charge(i)
        icoor = cgcoor(:, i)

        do j = i+1, the_data%atom_num

            if ( ifskipatoms(j) ) then
                cycle
            end if

            r_ij_sq = m_get_vec_by_coor_periodic(icoor(:), cgcoor(:,j), rij_vec3, the_data%periodic_box_vec)

            if (r_ij_sq > rcutsq) then
                cycle
            end if
            r_ij = sqrt(r_ij_sq)

            dis_inv = 1d0 / r_ij
            qj = the_data%charge(j)
            
            ES_coef = eleccoef/epsilon_r*qi*qj
            elec_static_potential = elec_static_potential + ES_coef * (dis_inv + krf * r_ij_sq - crf)

            iatom_type = the_data%atom_type(i)
            jatom_type = the_data%atom_type(j)

            tpnexc = cgnatomtype*(iatom_type-1) + jatom_type
            tpnexc = cgnonbondedparmindex(tpnexc)
            sigma = cgnonbondedparms(1,tpnexc)
            eps = cgnonbondedparms(2,tpnexc)

            coef1 = (sigma*dis_0_inv)**6
            coef2 = coef1*eps*4d0
            corr = coef2*(coef1 - 1.0d0)

            coef1 = (sigma*dis_inv)**6
            coef2 = coef1*eps*4d0
            LJ_potential = LJ_potential + coef2*(coef1 - 1.0d0) - corr

            coef1 = ES_coef * (-dis_inv/(r_ij_sq) + 2d0 * krf) - (coef2*(12.0*coef1 - 6.0))*dis_inv*dis_inv
            
            rij_vec3(:) = rij_vec3(:) * coef1
            LJ_force(:, i) = LJ_force(:, i) - rij_vec3(:)
            LJ_force(:, j) = LJ_force(:, j) + rij_vec3(:)

        end do
    end do

    self%LJ_potential = LJ_potential
    self%elec_static_potential = elec_static_potential
    cgevdw = LJ_potential
    cgeelec = elec_static_potential

end subroutine

subroutine virtual_site_set_coordinate(the_data)
    use itp_reader
    type(itp_info) :: the_data
    integer :: isite, iatom, tpnatom, i
    real*8 :: coor1(3), coor2(3), coor3(3)
    real*8 :: tpvec12(3), tpvec13(3), tpvec(3)
    real*8 :: tpcoor(3), tpsize

    if (nvirtualsite_outofplane > 0) then
        do isite = 1, nvirtualsite_outofplane
            coor1 = cgcoor(:, virtualsites(isite)%atomlist(1))
            coor2 = cgcoor(:, virtualsites(isite)%atomlist(2))
            coor3 = cgcoor(:, virtualsites(isite)%atomlist(3))

            tpvec12 = coor2 - coor1
            tpvec13 = coor3 - coor1
            call m_cross_product(tpvec12, tpvec13, tpvec)
            cgcoor(:, virtualsites(isite)%siteatom) = coor1 + &
                    virtualsites(isite)%weights(1) * tpvec12 + &
                    virtualsites(isite)%weights(2) * tpvec13 + &
                    virtualsites(isite)%weights(3) * tpvec
        end do
    end if

    if (nvirtualsite > nvirtualsite_outofplane) then
        do isite = nvirtualsite_outofplane + 1, nvirtualsite
            iatom = virtualsites(isite)%siteatom
            tpnatom = size(virtualsites(isite)%atomlist)
            tpcoor = 0d0
            tpvec = 0d0

            do i = 1, 3
                tpcoor(i) = dot_product(virtualsites(isite)%weights(1:tpnatom), &
                                        cgcoor(i, virtualsites(isite)%atomlist(1:tpnatom)))
            end do

            if (allocated(virtualsites(isite)%weightdx)) then
                if (size(virtualsites(isite)%weightdx) == tpnatom) then
                    do i = 1, 3
                        tpvec(i) = dot_product(virtualsites(isite)%weightdx(1:tpnatom), &
                                               cgcoor(i, virtualsites(isite)%atomlist(1:tpnatom)))
                    end do


                    tpsize = sqrt(dot_product(tpvec, tpvec))
                    if (tpsize > 1.0d-10) then
                        tpvec = tpvec / tpsize
                        tpcoor = tpcoor + virtualsites(isite)%weightp * tpvec

                    end if
                end if
            end if

            cgcoor(:, virtualsites(isite)%siteatom) = tpcoor
        end do
    end if
end subroutine 

subroutine virtual_site_distribute_force(self)
    class(MartiniClass) :: self
    
    type(itp_info) :: the_data  
    integer :: isite, iatom, tpnatom, i  
    real*8 :: virtual_force(3)   
    real*8 :: coor1(3), coor2(3), coor3(3)
    real*8 :: tpvec12(3), tpvec13(3), tpvec(3)
    ! real*8 :: temp_vec3(3), temp_1_vec3(3)
    real*8 :: force_1(3), force_2(3), force_3(3)
    real*8 :: w1,w2,w3,w_sum 
    real*8 :: tpcoor(3), deriv_vec(3), tpsize  

    real*8 :: w11_i, wp_wx1
    real*8 :: term_x, term_y, term_z
    real*8 :: cross_xy, cross_xz, cross_yx, cross_yz, cross_zx, cross_zy
    real*8 :: tpsize3

    real*8, dimension(3) :: temp_vec3
    real*8, dimension(:,:), pointer :: total_force

    total_force => self%total_force
    the_data = self%data

    if (nvirtualsite_outofplane > 0) then
        ! out_of_plane
        do isite = 1, nvirtualsite_outofplane
            coor1 = cgcoor(:, virtualsites(isite)%atomlist(1))
            coor2 = cgcoor(:, virtualsites(isite)%atomlist(2))
            coor3 = cgcoor(:, virtualsites(isite)%atomlist(3))
            tpvec12 = coor2 - coor1 
            tpvec13 = coor3 - coor1  
            
            iatom = virtualsites(isite)%siteatom
            virtual_force = total_force(:, iatom)

            w_sum = virtualsites(isite)%weights(1) + virtualsites(isite)%weights(2)
            w1 = virtualsites(isite)%weights(1)
            w2 = virtualsites(isite)%weights(2)
            w3 = virtualsites(isite)%weights(3)

            force_2(1) = w1 * virtual_force(1) + w3 *((coor1(3)-coor3(3))*virtual_force(2) + (coor3(2)-coor1(2))*virtual_force(3))
            force_2(2) = w3 * ((coor3(3)-coor1(3))*virtual_force(1)) + w1 *virtual_force(2) + w3 * ((coor1(1)-coor3(1))*virtual_force(3))
            force_2(3) = w3 * ((coor1(2)-coor3(2))*virtual_force(1)) + w3 *((coor3(1)-coor1(1))*virtual_force(2)) + w1 * virtual_force(3)

            force_3(1) = w2 * virtual_force(1) + w3 *((coor2(3)-coor1(3))*virtual_force(2) + (coor1(2)-coor2(2))*virtual_force(3))
            force_3(2) = w3 * ((coor1(3)-coor2(3))*virtual_force(1)) + w2 *virtual_force(2) + w3 * ((coor2(1)-coor1(1))*virtual_force(3))
            force_3(3) = w3 * ((coor2(2)-coor1(2))*virtual_force(1)) + w3 *((coor1(1)-coor2(1))*virtual_force(2)) + w2 * virtual_force(3)

            force_1(:) = virtual_force - force_2(:) - force_3(:)

            total_force(:, virtualsites(isite)%atomlist(1)) = total_force(:,virtualsites(isite)%atomlist(1)) + force_1
            total_force(:, virtualsites(isite)%atomlist(2)) = total_force(:,virtualsites(isite)%atomlist(2)) + force_2
            total_force(:, virtualsites(isite)%atomlist(3)) = total_force(:,virtualsites(isite)%atomlist(3)) + force_3

        end do
    end if


    if (nvirtualsite > nvirtualsite_outofplane) then
        do isite = nvirtualsite_outofplane + 1, nvirtualsite
            iatom = virtualsites(isite)%siteatom
            tpnatom = size(virtualsites(isite)%atomlist)

            virtual_force = total_force(:, iatom)

            do i = 1, tpnatom
                total_force(:, virtualsites(isite)%atomlist(i)) = total_force(:,virtualsites(isite)%atomlist(i)) &
                + virtualsites(isite)%weights(i) * virtual_force
                force_1 = virtualsites(isite)%weights(i) * virtual_force
            end do
            if (allocated(virtualsites(isite)%weightdx)) then
                if (size(virtualsites(isite)%weightdx) == tpnatom) then
                    do i = 1, 3
                        tpvec(i)=dot_product(virtualsites(isite)%weightdx(1:tpnatom), &
                                        cgcoor(i,virtualsites(isite)%atomlist(1:tpnatom)))
                    end do
                    tpsize = sqrt(dot_product(tpvec, tpvec))
                    tpsize3 = tpsize**3

                    do i = 1, tpnatom
                        w11_i = virtualsites(isite)%weights(i)  ! w11,i
                        wp_wx1 = virtualsites(isite)%weightp*virtualsites(isite)%weightdx(i)  ! wp*wx1,i

                        temp_vec3(:) = wp_wx1 * (1.0d0 / tpsize - (tpvec(:)**2) / tpsize3)

                        cross_xy = -wp_wx1 * (tpvec(1)*tpvec(2)) / tpsize3
                        cross_xz = -wp_wx1 * (tpvec(1)*tpvec(3)) / tpsize3
                        cross_yz = -wp_wx1 * (tpvec(2)*tpvec(3)) / tpsize3

                        total_force(1, virtualsites(isite)%atomlist(i)) =total_force(1,virtualsites(isite)%atomlist(i)) &
                                + temp_vec3(1) * virtual_force(1) + cross_xy*virtual_force(2) + cross_xz * virtual_force(3)
                        total_force(2, virtualsites(isite)%atomlist(i)) =total_force(2,virtualsites(isite)%atomlist(i)) &
                            + cross_xy * virtual_force(1) + temp_vec3(2)*virtual_force(2) + cross_yz * virtual_force(3)
                        total_force(3, virtualsites(isite)%atomlist(i)) =total_force(3,virtualsites(isite)%atomlist(i)) &
                            + cross_xz * virtual_force(1) + cross_yz*virtual_force(2)  + temp_vec3(3) * virtual_force(3)
                    end do
                end if
            end if
        end do
    end if

end subroutine

subroutine elec_exclude_pot(self)
    class(MartiniClass) :: self
    type(itp_info) :: the_data
    integer :: i, iatom, jatom, ipos
    real*8 :: iq, jq, icoor(3), ES, tpvec(3), dissq, dis, coef
    real*8 :: rcutsq
    real*8 :: rij  
    real*8, dimension(3) :: rij_vec3
    real*8, dimension(:,:), pointer :: elecS_exclude_force

    elecS_exclude_force => self%elecS_exclude_force
    

    the_data = self%data
    the_data%periodic_box_vec = cgcell  
    ipos = 0

    rcutsq = rcut*rcut
    self%elec_exclude_potential = 0d0

    do iatom = 1, the_data%atom_num
        iq = the_data%charge(iatom); 
        if (iq == 0d0) then
            ipos = ipos + cgnexcludedatoms(iatom)
            cycle
        end if
        icoor = cgcoor(:, iatom)

        do i = 1, cgnexcludedatoms(iatom)
            ipos = ipos + 1
            jatom = cgexcludedatomlist(ipos)
            jq = the_data%charge(jatom)
            if (jq == 0d0) then
                cycle
            end if

            dissq = m_get_vec_by_coor_periodic(icoor(:), cgcoor(:,jatom), rij_vec3, the_data%periodic_box_vec)
            rij = sqrt(dissq)
            tpvec(:) = rij_vec3(:)

            if (dissq > rcutsq) then
                cycle
            end if

            coef = eleccoef/epsilon_r*iq*jq
            ES = coef * (krf * dissq - crf)
            self%elec_exclude_potential = self%elec_exclude_potential + ES
            !if (self%get_force) then
                dis = sqrt(dissq)
                coef = coef * krf * dis * 2d0
                tpvec(:) = tpvec(:) / dis
                elecS_exclude_force(:, iatom) = elecS_exclude_force(:, iatom) - tpvec(:) * coef
                elecS_exclude_force(:, jatom) = elecS_exclude_force(:, jatom) + tpvec(:) * coef
            !end if
        end do
    end do

end subroutine

! Ryckaert, J. P.; Ciccotti, G.; Berendsen, H. J. C.
! Numerical Integration of the Cartesian Equations of Motion of a System with Constraints: Molecular Dynamics of N-Alkanes.
! J. Comput. Phys. 1977, 23: 327?341.

! Peter Eastman and Vijay S. Pande
! Constant Constraint Matrix Approximation: A Robust, Parallelizable Constraint Method for Molecular Simulations.
! J. Chem. Theory Comput. 2010, 6: 434-437
subroutine martini_ccma_execute(itp_reader,ifdovel)
  type(itp_info) :: itp_reader
  logical,optional,intent(in) :: ifdovel
  integer :: iter,maxiter,icst,jcst,iatom,jatom,index
  real*8 :: error,tpvalue,cstdelta(ncst),tpdelta(ncst),dissq,sigma,lowtol,uptol,tpvec(3),tpprevec(3),eqvalsq
  logical :: ifconverged

  lowtol = 1d0 - 2d0*cgcsttol + cgcsttol*cgcsttol
  uptol = 1d0 + 2d0*cgcsttol + cgcsttol*cgcsttol

  maxiter = 100; cstdelta = 0d0; ifconverged = .false.; iter = 0
  do while ( (ifconverged .eqv. .false.) .and. (iter < maxiter) )
     iter = iter + 1
     ifconverged = .true.

     if ( .not. present(ifdovel) ) then
        do icst = 1, ncst
           iatom = itp_reader%constraint(icst, 1)
           jatom = itp_reader%constraint(icst, 2)

           tpvec = cgcoor(:, iatom) - cgcoor(:, jatom)
           tpprevec = cgprecoor(:, iatom) - cgprecoor(:, jatom)
           dissq = dot_product(tpvec,tpvec)
           eqvalsq = itp_reader%constraint_length(icst)**2

           sigma = eqvalsq - dissq
           tpvalue = dot_product(tpvec,tpprevec)
           cstdelta(icst) = 0.5d0*cst_reduced_mass(icst)*sigma/tpvalue 

           if ( (dissq < lowtol*eqvalsq) .or. (dissq > uptol*eqvalsq) ) ifconverged = .false.
        end do

     else

        do icst = 1, ncst
           iatom = itp_reader%constraint(icst, 1)
           jatom = itp_reader%constraint(icst, 2)

           tpprevec = cgcoor(:, iatom) - cgcoor(:, jatom)
           tpvec = cgvel(:, iatom) - cgvel(:, jatom)
           sigma = dot_product(tpvec,tpprevec)
           tpvalue = dot_product(tpprevec,tpprevec)
           cstdelta(icst) = -cst_reduced_mass(icst)*sigma/tpvalue

           if ( abs(cstdelta(icst)) > cgcsttol ) ifconverged = .false. 
        end do

     end if

     if ( ifconverged ) exit

     do icst = 1, ncst
        tpvalue = 0d0
        do index = jacobicstindex(icst)+1, jacobicstindex(icst+1) 
           jcst = jacobicstlist(index)
           tpvalue = tpvalue + cstdelta(jcst)*jacobicstval(index)
        enddo
        tpdelta(icst) = tpvalue
     end do
     do icst = 1, ncst
        iatom = itp_reader%constraint(icst, 1)
        jatom = itp_reader%constraint(icst, 2)

        if ( .not. present(ifdovel) ) then
           tpprevec = (cgprecoor(:, iatom) - cgprecoor(:, jatom))*tpdelta(icst)
           cgcoor(:, iatom) = cgcoor(:, iatom) + tpprevec*cgmassinv(iatom)
           cgcoor(:, jatom) = cgcoor(:, jatom) - tpprevec*cgmassinv(jatom)
        else
           tpprevec = (cgcoor(:, iatom) - cgcoor(:, jatom))*tpdelta(icst)
           cgvel(:, iatom) = cgvel(:, iatom) + tpprevec*cgmassinv(iatom)
           cgvel(:, jatom) = cgvel(:, jatom) - tpprevec*cgmassinv(jatom)
        end if
     end do
  end do

  if ( ifconverged ) then
     !print *,"CCMA converged, iteration step is ",iter
  else
     print *,"CCMA not converged!"
  end if

  if ( (nvirtualsite > 0) .and. (.not. present(ifdovel)) ) call virtual_site_set_coordinate(itp_reader)
end subroutine

end module
