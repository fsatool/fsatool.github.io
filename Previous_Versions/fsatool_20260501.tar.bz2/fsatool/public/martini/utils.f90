module utils
    real*8, parameter :: KJ_TO_KCAL = 1d0/4.184d0 ! 0.23884589663  ! 0.239005736
    real*8, parameter :: KCAL_TO_KJ = 4.184d0
    REAL*8, PARAMETER :: NM_TO_A = 10
    REAL*8, PARAMETER :: NM = 1
    REAL*8, PARAMETER :: ANG = 10
    REAL*8, PARAMETER :: KJ = 4.184d0
    REAL*8, PARAMETER :: KCAL = 1
    REAL*8, PARAMETER :: MOL = 1

    REAL*8, PARAMETER :: TIME_SCALE = 0.001d0  ! 20.455d0
    REAL*8, PARAMETER :: GAS_CONST = 8.31441d0  ! KJ（mol*K）

    real*8, PARAMETER :: INFINITESIMAL = 0.001d0

    real*8,parameter,public :: eleccoef = 138.935458d0*KJ_TO_KCAL, epsilon_r = 1.5d0
    real*8,parameter,public :: NM_TO_ANG = 10.0d0
contains

! NEW, FOR FORMAT PRINT
subroutine m_format_print(string, num, num1)
    character(len=*) :: string
    real*8 :: num, num1
    if (num > 1d10) then
        if (num1 > 1d10) then
            print "(a10, 2E25.16)", string, num, num1
        else
            print "(a10, E25.16, f25.16)", string, num, num1
        end if
    else if (num > 1d10) then
        print "(a10, f25.16, E25.16)", string, num, num1
    else
        print "(a10, 2f25.16)", string, num, num1
    end if
end subroutine


real*8 function get_vec_by_coor(coor_i, coor_j, r_ij_vec3) result(r_ij)
    real*8, dimension(3) :: coor_i, coor_j, r_ij_vec3
    r_ij_vec3(:) = coor_i(:) - coor_j(:)
    r_ij = sqrt(dot_product(r_ij_vec3, r_ij_vec3))
end function

subroutine gauss_box_muller(sigma,mean,rand)
  real*8,intent(in) :: sigma,mean
  real*8,intent(out) :: rand
  real*8,parameter :: pi = 3.141592653589793d0
  real*8 :: r1,r2

  call random_number(r1); call random_number(r2)
  rand = sqrt(-2d0*log(r1))*cos(2d0*pi*r2)
  rand = rand*sigma + mean
end subroutine

integer function m_get_unit() result(unit)
    logical :: if_used
    unit = 10; if_used = .true.
    do
        unit = unit + 1
        inquire(unit=unit, opened=if_used)
        if ( if_used .eqv. .false. ) return
    end do
end function

real*8 function cross_product_val_sq(in_a, in_b) result(res)
    real*8, dimension(3) :: in_a, in_b, c
    c(1) = in_a(2) * in_b(3) - in_a(3) * in_b(2)
    c(2) = in_a(3) * in_b(1) - in_a(1) * in_b(3)
    c(3) = in_a(1) * in_b(2) - in_a(2) * in_b(1)
    res = dot_product(c, c)
end function

real*8 function norm(vec) result(res)
    real*8, dimension(3) :: vec
    res = sqrt(dot_product(vec, vec))
end function

subroutine m_cross_product(vec1, vec2, res_vec)
    implicit none
    real*8, dimension(1:3), intent(in) :: vec1, vec2
    real*8, dimension(1:3), intent(out) :: res_vec

    res_vec(1) = vec1(2) * vec2(3) - vec1(3) * vec2(2)
    res_vec(2) = vec1(3) * vec2(1) - vec1(1) * vec2(3)
    res_vec(3) = vec1(1) * vec2(2) - vec1(2) * vec2(1)
end subroutine

real*8 function m_get_phi(r_ij_vec3, n_1_vec3, n_2_vec3, n_1, n_2) result(phi)
    real*8, dimension(3) :: r_ij_vec3
    real*8, dimension(3) :: n_1_vec3, n_2_vec3
    real*8 :: n_1, n_2

    real*8, dimension(3) :: norm_n_1_vec3, norm_n_2_vec3

    norm_n_1_vec3(1:3) = n_1_vec3(1:3) / n_1
    norm_n_2_vec3(1:3) = n_2_vec3(1:3) / n_2

    phi = dot_product(norm_n_1_vec3, norm_n_2_vec3)
    phi = min(1.0d0, max(-1.0d0, phi))
    phi = sign(1.0d0, dot_product(r_ij_vec3, n_2_vec3)) * acos(phi)
end function

real*8 function scaled_force(force, len)
    integer :: len
    real*8 :: force(len, 3)
    integer i, j;

    scaled_force = 0
    do i = 1, len
        do j = 1, 3
            scaled_force = scaled_force + abs(force(i, j))
        end do
    end do
end function

end module
