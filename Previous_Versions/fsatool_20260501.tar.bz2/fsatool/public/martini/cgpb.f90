module cgpb
  use itp_reader; use utils; use public
  implicit none

  integer,parameter :: iadgrid=1

  integer :: bimaxnexc,nbox,nboxvec(3),maxnnl
  real*8 :: evdwcorr
  real*8 :: inicgcell(3),cgcellinv(3),savecell(3),mat_frac2car(3,3),mat_car2frac(3,3)
  real*8 :: inimat_frac2car(3,3),inimat_car2frac(3,3)
  real*8 :: vir(3),inivir(3),inicellvolume,inievdwcorr,cgrealpressure,ewaldalpha
  logical :: ifactivebox

  real*8 :: skin,hfskinsq,fullcutsq,settlewatparm(6)

  integer,dimension(:),allocatable :: atombox,cgboxatomtype,boxnl

  real*8 :: pbcrd(3,18),cellvolume,cgpressure0,cgtaup,cgdeltatime

  integer,dimension(:),allocatable :: boxatom,boxatomindex
  integer,dimension(:),allocatable :: bilastnexc,bicgnexcludedatoms,cgbiexcludedatomlist
  integer,dimension(:),allocatable :: boxnlindex,boxnlboxindex,boxnlboxes,boxnlboxcsidx
  integer,dimension(:,:),allocatable :: pbidx

  real*8,dimension(:),allocatable :: boxcharge
  real*8,dimension(:,:),allocatable :: boxcoor,boxfrc,savecoor,saveboxcoor,unitcoor

  logical,dimension(:),allocatable :: cgvdwskip

  real*8,dimension(:,:),pointer,private :: elecvdw_force

contains

subroutine cgpb_initialize(tppointer)
  real*8,dimension(:,:),pointer :: tppointer
  integer :: i
  real*8 :: tpbound(2,3)

  elecvdw_force => tppointer

  call cgpb_prepare_cell()

  call cgpb_prepare_direct()

  call cgpb_molecule_com()

  do i=1,3
     tpbound(1,i) = minval(cgcoor(i,:)); tpbound(2,i) = maxval(cgcoor(i,:))
  end do

  if ( procid == 0 ) then
     write(iosiminfo,"(/,20x,a)") "Simulation Model"
     write(iosiminfo,"(a)") "============================================================="
     if ( cgipb == 1 ) then
        write(iosiminfo,"(a)") "NVT simulation in a rectangular periodic box"
     else if ( cgipb > 1 ) then
        write(iosiminfo,"(a)") "NPT simulation in a rectangular periodic box"
     end if
     write(iosiminfo,"(a,1x,2f8.3,4x,2f8.3,4x,2f8.3)") "Coordinate Borders ",tpbound(1:2,1),tpbound(1:2,2),tpbound(1:2,3)
     write(iosiminfo,"(a,3f8.3,5x,a,3f8.3)") "Cell length ",cgcell(1),cgcell(2),cgcell(3),"Cell angle ",cgcellalpha*180d0/pi,cgcellbeta*180d0/pi,cgcellgamma*180d0/pi
     write(iosiminfo,"(a,f8.3)") "Distance cutoff ",rcut
     write(iosiminfo,"(a,3i5)") "Boxes in direct space     ",nboxvec
  end if
end subroutine

subroutine cgpb_elecvdw_force_pointer(tppointer)
  real*8,pointer :: tppointer(:,:)
  elecvdw_force => tppointer
end subroutine

subroutine cgpb_prepare_cell(nptcoeff)
  real*8,intent(in),optional :: nptcoeff(3)
  integer :: i,j,k,l,iaxis
  real*8 :: tpterm,ijkvec(3),tpterm2,tpcut,insradius

  savecell = cgcell
  if ( present(nptcoeff) ) then
     cgcell = cgcell*nptcoeff; cgcellinv = 1d0/cgcell
     do i=1,18
        pbcrd(:,i) = pbcrd(:,i)*nptcoeff
     end do
     do i=1,3
        mat_frac2car(i,:) = inimat_frac2car(i,:)*cgcell/inicgcell
        mat_car2frac(:,i) = inimat_car2frac(:,i)*inicgcell/cgcell
     end do
     cellvolume = inicellvolume*product(cgcell)/product(inicgcell)

     insradius = 1000.0d0
     do i=1,3
        tpcut = 1.0d0/sqrt( dot_product(mat_car2frac(i,:),mat_car2frac(i,:) ) )
        insradius = min(insradius,tpcut)
     end do
     insradius = 0.5d0*insradius

     if ( procid == 0 ) then
        if (rcut+skin>=insradius) call errormsg("extended cutoff distance (rcut+skin) must be smaller than the radius of inscribed sphere",real1=insradius, real2=rcut, real3=rcut+skin)
     end if
     return
  end if

  inicgcell = cgcell; cgcellinv(:) = 1.d0/cgcell

  tpterm = ( dcos(cgcellalpha) - dcos(cgcellbeta)*dcos(cgcellgamma) )/dsin(cgcellgamma)
  tpterm2 = cgcell(3)*dsqrt(dsin(cgcellbeta)**2 - tpterm**2)
  mat_frac2car(1,:)=(/cgcell(1), 0.0d0, 0.0d0/)
  mat_frac2car(2,:)=(/cgcell(2)*dcos(cgcellgamma), cgcell(2)*dsin(cgcellgamma), 0d0/)
  mat_frac2car(3,:)=(/cgcell(3)*dcos(cgcellbeta), cgcell(3)*tpterm, tpterm2/)
  cellvolume = mat_frac2car(1,1)*mat_frac2car(2,2)*mat_frac2car(3,3)
  if ( inicellvolume == 0d0) inicellvolume=cellvolume
  mat_frac2car = transpose(mat_frac2car)

  mat_car2frac = mat_frac2car; call inversematrix(3,mat_car2frac)

  inimat_car2frac=mat_car2frac; inimat_frac2car = mat_frac2car

  do k = 1,2; do j = 1,3; do i = 1,3
     l = (k-1)*9+(j-1)*3+i; ijkvec = dble((/i,j,k/))-2.d0
     pbcrd(:,l) = - ijkvec(:)*cgcell(:)
  end do; end do; end do

end subroutine

subroutine cgpb_prepare_direct()
  integer :: i,l

  allocate(cgvdwskip(cgnatomtype*cgnatomtype)); cgvdwskip = .false.
  do i = 1,cgnatomtype*cgnatomtype
     l = cgnonbondedparmindex(i)
     if ( cgnonbondedparms(2,l) < 1d-10 ) cgvdwskip(i) = .true.
  end do
  call cgpb_prepare_cgbiexcludedatomlist()
  call cgpb_prepare_box()
  call cgpb_calculate_vdwcorr()
end subroutine

subroutine cgpb_prepare_cgbiexcludedatomlist()
  integer :: biidx(cgnatom),tpnexc,iatom,jatom,j

  allocate(bilastnexc(cgnatom+1),bicgnexcludedatoms(cgnatom))

  bicgnexcludedatoms(:) = cgnexcludedatoms(:); tpnexc = 0

  do iatom = 1,cgnatom
     do j = tpnexc+1,tpnexc+cgnexcludedatoms(iatom)
        jatom = cgexcludedatomlist(j)
        if ( jatom .ne. 0 ) then
           bicgnexcludedatoms(jatom) = bicgnexcludedatoms(jatom) + 1
        end if
     end do
     tpnexc = tpnexc + cgnexcludedatoms(iatom)
  end do
  allocate(cgbiexcludedatomlist(2*tpnexc))

  bilastnexc(1) = 0
  do iatom = 1,cgnatom
     biidx(iatom) = bilastnexc(iatom) + 1
     bilastnexc(iatom+1) = bilastnexc(iatom) + bicgnexcludedatoms(iatom)
  end do

  tpnexc = 0
  do iatom = 1,cgnatom
     do j = tpnexc+1,tpnexc+cgnexcludedatoms(iatom)
        jatom = cgexcludedatomlist(j)    ! excluded pair iatom-jatom
        cgbiexcludedatomlist(biidx(iatom)) = jatom; biidx(iatom) = biidx(iatom) + 1
        if ( jatom == 0 ) cycle
        cgbiexcludedatomlist(biidx(jatom)) = iatom; biidx(jatom) = biidx(jatom) + 1
     end do
     tpnexc = tpnexc + cgnexcludedatoms(iatom)
  end do

  bimaxnexc = 0
  do iatom=1, cgnatom
     j = bilastnexc(iatom+1) - bilastnexc(iatom)
     if ( j > bimaxnexc )  bimaxnexc = j
  end do
end subroutine

subroutine cgpb_prepare_box()
  real*8 :: tpdis,insradius
  integer :: i,j,k,l
  integer :: ijstride,tpadnum,ibox,jbox,maxnbox,csidx,i1,i2,i3,j1,j2,j3,i1l,i1r,i2l,i2r,i3l,i3r
  integer,dimension(:,:),allocatable :: boxidx

  skin = 1.0d0; hfskinsq = skin*skin/4.0d0; fullcutsq = (rcut+skin)**2
  insradius = minval(cgcell)
  nboxvec(1:3) = max(int(cgcell(1:3)/((rcut+skin)/dble(iadgrid+1)+1d-4)),1)

  insradius = 0.5d0*insradius  
  if (rcut+skin>=insradius) call errormsg("cutoff must be smaller than the radius of inscribed sphere",real1=insradius, real2=rcut+skin)

  nbox = nboxvec(1)*nboxvec(2)*nboxvec(3)
  allocate(boxatom(cgnatom),boxatomindex(nbox+1))
  boxatom = 0; boxatomindex = 0

  allocate(boxcharge(cgnatom),cgboxatomtype(cgnatom))
  boxcharge = 0.d0; cgboxatomtype = 0

  maxnnl=cgnatom*int( 1.1d0*(4d0/3d0)*pi*fullcutsq**1.5*dble(cgnatom)/cellvolume )
  if ( maxnnl < cgnatom*4 ) maxnnl = cgnatom*4
  allocate(boxnl(maxnnl),boxnlindex(cgnatom+1))
  boxnl = 0; boxnlindex = 0

  maxnbox = max(nboxvec(1),nboxvec(2),nboxvec(3))
  allocate(pbidx(3,3*maxnbox),boxidx(3,3*maxnbox))
  pbidx = 0; boxidx = 0
  do i = 1,3*nboxvec(1)
     pbidx(1,i) = int((i-1)/nboxvec(1)) + 1; boxidx(1,i) = mod(i-1,nboxvec(1)) + 1
  end do
  do i = 1,3*nboxvec(2)
     pbidx(2,i) = int((i-1)/nboxvec(2))*3; boxidx(2,i) = mod(i-1,nboxvec(2)) + 1
  end do
  do i = 1,3*nboxvec(3)
     pbidx(3,i) = int((i-1)/nboxvec(3))*9; boxidx(3,i) = mod(i-1,nboxvec(3)) + 1
  end do

  allocate(atombox(cgnatom),boxcoor(3,cgnatom),boxfrc(3,cgnatom),savecoor(3,cgnatom),saveboxcoor(3,cgnatom),unitcoor(3,cgnatom))
  atombox = 0; boxcoor = 0.d0; saveboxcoor = 0.d0; boxfrc = 0.d0; unitcoor = 0d0
  ijstride = nboxvec(1)*nboxvec(2); tpadnum = iadgrid + 1
  k = ( (2*tpadnum+1)**3 - 1 )*nbox/2

  allocate(boxnlboxindex(nbox+1),boxnlboxcsidx(k)); boxnlboxindex=0; boxnlboxcsidx=0
  allocate(boxnlboxes(k)); boxnlboxes=0; k = 0
  do i3=1,nboxvec(3); do i2=1,nboxvec(2); do i1=1,nboxvec(1)
     ibox = i1 + (i2-1)*nboxvec(1) + (i3-1)*ijstride
     i1l = i1 - tpadnum + nboxvec(1); i1r = i1 + tpadnum + nboxvec(1)
     i2l = i2 - tpadnum + nboxvec(2); i2r = i2 + tpadnum + nboxvec(2)
     i3l = i3 - tpadnum + nboxvec(3); i3r = i3 + nboxvec(3)
     do j3=i3l,i3r; do j2=i2l,i2r; do j1=i1l,i1r
        jbox = boxidx(1,j1) + (boxidx(2,j2)-1)*nboxvec(1) + (boxidx(3,j3)-1)*ijstride
        csidx = pbidx(1,j1)+pbidx(2,j2)+pbidx(3,j3)
        if ( jbox .eq. ibox ) goto 1002
        k = k + 1; boxnlboxes(k) = jbox; boxnlboxcsidx(k)=csidx
     end do; end do; end do
1002 continue
     boxnlboxindex(ibox+1) = k
  end do; end do; end do
  deallocate(boxidx)

end subroutine

subroutine cgpb_calculate_vdwcorr()
  integer :: itype,jtype,index,i,tpvdwatom(cgnatomtype)
  real*8 :: tpsum,sigma,eps

  evdwcorr = 0.d0; tpvdwatom = 0
  do i = 1, cgnatom
     itype = cgatomtype(i); tpvdwatom(itype) = tpvdwatom(itype) + 1
  end do
  do itype = 1, cgnatomtype
     tpsum = 0d0
     do jtype = 1,cgnatomtype
        index = cgnonbondedparmindex(cgnatomtype*(itype-1) + jtype)
        sigma = cgnonbondedparms(1,index); eps = cgnonbondedparms(2,index)
        tpsum = tpsum + tpvdwatom(jtype)*4d0*eps*(sigma**6)
     end do
     evdwcorr = evdwcorr + tpsum*tpvdwatom(itype)
  end do

  evdwcorr = (-2.d0*pi/(3.d0*cellvolume*rcut**3.d0))*evdwcorr
  inievdwcorr = evdwcorr

  if ( cgipb > 1 ) inivir(:) = 2.d0*inievdwcorr
end subroutine

subroutine cgpb_potforce()
  integer :: i,j,iatom
  real*8 :: tpvec(3)

  if ( (ifactivebox == .true.) .and. (cgipb > 1) ) then
     call cgpb_prepare_cell()
  end if

  evdwcorr = inievdwcorr*inicellvolume/cellvolume

  if ( cgipb > 1 ) vir = inivir*inicellvolume/cellvolume

  call cgpb_transform_coordinates_to_unitcoor()

  call cgpb_potforce_direct()

  if ( cgipb > 1 ) call cgpb_npt_vir_mol()

  tpvec(1:3) = sum(elecvdw_force,2)/dble(cgnatom)
  do i = 1, cgnatom
     elecvdw_force(:,i) = elecvdw_force(:,i) - tpvec(:)
  end do

end subroutine

subroutine cgpb_potforce_direct()
  integer :: iatom,jatom,ibox,jbox,i,j,idx,tpi,iaxis,index,xpos,ivdwtype,csidx,lexcluded,rexcluded
  real*8 :: tpcoorvec(3),tpfrccoef,tpifrc(3),tpfrcvec(3),dis,disinv,dis6inv,dissqinv,coef1,coef2,coef12,expdij,ewalddis,xdis
  real*8 :: iboxcoor(3,0:18),rcutsq,dissq,tpvec(4),tpvalue,ES_coef,qi,qj,sigma,eps,discutinv

  if ( cgipb > 1 ) then
     tpcoorvec(:) = cgcell(:)/savecell(:)
     do iatom = 1,cgnatom
        savecoor(:,iatom) = savecoor(:,iatom)*tpcoorvec(:)
        saveboxcoor(:,iatom) = saveboxcoor(:,iatom)*tpcoorvec(:)
     end do
  end if

  if ( ifactivebox .eqv. .false. ) then
     do iatom = 1,cgnatom
        tpvec(:) = cgcoor(:,iatom) - savecoor(:,iatom)
        if ( dot_product(tpvec,tpvec) > hfskinsq ) then
           ifactivebox = .true.; exit
        end if
     end do
  end if

  if ( ifactivebox .eqv. .true. ) then
     call cgpb_set_boxcoor_and_neighborlist(); ifactivebox=.false.
  else
     do i = 1, cgnatom
        iatom = boxatom(i)
        boxcoor(:,i) = saveboxcoor(:,i) + cgcoor(:,iatom) - savecoor(:,iatom)
     end do
  end if

  discutinv = 1d0/rcut
  cgeelec = 0.d0; cgevdw= 0.d0; boxfrc = 0.d0; rcutsq = rcut**2.d0

  do ibox=1,nbox
     do i=boxatomindex(ibox)+1,boxatomindex(ibox+1)
        iatom = boxatom(i); ivdwtype = cgnatomtype*(cgboxatomtype(i) - 1)
        qi = boxcharge(i)
        do j = 1,18
           iboxcoor(:,j) = boxcoor(:,i) + pbcrd(:,j)
        end do
        tpifrc(:) = 0.d0
        do idx = boxnlindex(i)+1,boxnlindex(i+1)
           tpi=boxnl(idx); j=iand(Z"FFFFF",tpi); csidx = ishft(tpi,-20)
           jatom = boxatom(j)
           tpcoorvec(:) = iboxcoor(:,csidx) - boxcoor(:,j)

           dissq = dot_product(tpcoorvec,tpcoorvec)

           if ( dissq > rcutsq ) cycle
           dis = sqrt(dissq); disinv = 1d0/dis; qj = boxcharge(j)

           ES_coef = eleccoef/epsilon_r*qi*qj
           cgeelec = cgeelec + ES_coef * (disinv + krf * dissq - crf)

           tpi = ivdwtype + cgboxatomtype(j);
           tpi = cgnonbondedparmindex(tpi)
           sigma = cgnonbondedparms(1,tpi)
           eps = cgnonbondedparms(2,tpi)

           coef1 = (sigma*discutinv)**2; coef1 = coef1*coef1*coef1; coef2 = coef1*eps*4d0
           tpvalue = coef2*(coef1 - 1.0d0)

           coef1 = (sigma*disinv)**2; coef1 = coef1*coef1*coef1; coef2 = coef1*eps*4d0
           cgevdw = cgevdw + coef2*(coef1 - 1.0d0) - tpvalue

           coef1 = ES_coef * (-disinv/dissq + 2d0 * krf) - (coef2*(12.0*coef1 - 6.0))*disinv*disinv

           tpfrcvec(:) = tpcoorvec(:) * coef1

           if ( cgipb > 1 ) then
              vir(:) = vir(:) - tpcoorvec(:)*tpfrcvec(:)
           end if
           tpifrc(:) = tpifrc(:) - tpfrcvec(:)
           boxfrc(:,j) = boxfrc(:,j) + tpfrcvec(:)
        end do
        boxfrc(:,i) = boxfrc(:,i) + tpifrc(:)
     end do
  end do

  do i = 1,cgnatom
     iatom = boxatom(i)
     elecvdw_force(:,iatom) = elecvdw_force(:,iatom) + boxfrc(:,i)
  end do
end subroutine

subroutine cgpb_set_boxcoor_and_neighborlist()
  integer :: iaxis,iatom,jatom,ibox,jbox,tpboxvec(3),ijstride,i,j,idx,jboxpos,tpidx,csidx,index
  integer :: nextatom(cgnatom),firstatom(nbox),lastatom(nbox)
  real*8 :: tpcoorvec(3),tpvec(3),dis,iboxcoor(3,0:18)
  logical :: ifskipatoms(0:cgnatom),ifskip

  nextatom = 0; firstatom = 0; lastatom = 0
  ijstride = nboxvec(1)*nboxvec(2)

  do iatom=1,cgnatom
     tpboxvec(1:3) = int(unitcoor(1:3,iatom)*dble(nboxvec(1:3)))+1
     savecoor(1:3,iatom) = unitcoor(1:3,iatom)*cgcell(1:3)
     ibox = tpboxvec(1) + (tpboxvec(2)-1)*nboxvec(1) + (tpboxvec(3)-1)*ijstride
     if ( lastatom(ibox) == 0 ) then
        firstatom(ibox) = iatom; lastatom(ibox) = iatom
     else
        nextatom(lastatom(ibox)) = iatom; lastatom(ibox) = iatom
     end if
  end do

  boxatom = 0; boxatomindex = 0; idx = 0
  do ibox = 1,nbox
     if ( firstatom(ibox) .ne. 0 ) then
        idx = idx + 1; iatom = firstatom(ibox); boxatom(idx) = iatom; atombox(iatom) = idx
        do while ( nextatom(iatom) .ne. 0 )
           idx = idx + 1; iatom = nextatom(iatom); boxatom(idx) = iatom; atombox(iatom) = idx
        end do
     end if
     boxatomindex(ibox+1) = idx
  end do

  do i = 1,cgnatom
     iatom = boxatom(i)
     boxcharge(i) = cgcharge(iatom); cgboxatomtype(i) = cgatomtype(iatom)
     boxcoor(:,i) = savecoor(:,iatom)
  end do
  savecoor = cgcoor; saveboxcoor = boxcoor

  idx = 0; ifskipatoms = .false.; boxnlindex(1) = 0
  do ibox=1,nbox
     do i=boxatomindex(ibox)+1,boxatomindex(ibox+1)
        iatom = boxatom(i)
        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           ifskipatoms(atombox(cgbiexcludedatomlist(j))) = .true.
        end do
        do j=boxatomindex(ibox)+1,i-1
           if ( ifskipatoms(j) .eq. .false. ) then
              tpcoorvec(:) = boxcoor(:,i) - boxcoor(:,j)
              if ( dot_product(tpcoorvec,tpcoorvec) <= fullcutsq ) then
                 idx = idx + 1; boxnl(idx) = ior(j,ishft(14,20))
              end if
           end if
        end do

        do csidx = 1,18
           iboxcoor(:,csidx) = boxcoor(:,i) + pbcrd(:,csidx)
        end do

        do jboxpos=boxnlboxindex(ibox)+1,boxnlboxindex(ibox+1)
           jbox = boxnlboxes(jboxpos); csidx = boxnlboxcsidx(jboxpos)
           do j=boxatomindex(jbox)+1,boxatomindex(jbox+1)
              if ( ifskipatoms(j) .eq. .false. ) then
                 tpcoorvec(:) = iboxcoor(:,csidx) - boxcoor(:,j)
                 if ( dot_product(tpcoorvec,tpcoorvec) <= fullcutsq ) then
                    idx = idx + 1; boxnl(idx) = ior(j,ishft(csidx,20))
                 end if
              end if
           end do
        end do

        do j = bilastnexc(iatom)+1,bilastnexc(iatom+1)
           ifskipatoms(atombox(cgbiexcludedatomlist(j))) = .false.
        end do

        boxnlindex(i+1) = idx
     end do
  end do

  if ( procid == 0 .and. idx > maxnnl) then
     call errormsg("neighbor list exceeds the array bound! ",int1=maxnnl,int2=idx)
  end if
end subroutine

subroutine cgpb_transform_coordinates_to_unitcoor()
  integer :: iatom,iaxis
  real*8 :: tpvec(3)

  do iatom = 1, cgnatom
     do iaxis = 1,3
        tpvec(iaxis) = cgcoor(iaxis,iatom)*cgcellinv(iaxis)
        tpvec(iaxis) = tpvec(iaxis)-dnint(tpvec(iaxis))+0.5d0
        if ( tpvec(iaxis) < 0.d0 ) then
           tpvec(iaxis) = tpvec(iaxis) + 1.d0
        else if ( tpvec(iaxis) >= 1.d0 ) then
           tpvec(iaxis) = tpvec(iaxis) - 1.d0
        end if
     end do
     unitcoor(1:3,iatom) = tpvec(1:3)
  end do
end subroutine

subroutine cgpb_npt_vir_mol()
  integer :: iatom,ires,imol
  real*8 :: avgcoor(3)

  do imol = 1, cgnmol
     do ires=cgmolindex(imol)+1,cgmolindex(imol+1)
        do iatom=cgresindex(ires)+1,cgresindex(ires+1)
           vir(:) = vir(:) + (cgmolcom(:,imol)-cgcoor(:,iatom))*elecvdw_force(:,iatom)
        end do
     end do
  end do
end subroutine

subroutine cgpb_npt_isobaric_Berendsen()
  integer :: iatom,ires,imol
  real*8 :: tpcoeff(3),tppressure(3),tpekin(3),molp(3),tpmat_car2frac(3,3),tpvec(3),tpvec2(3)

  tpekin = 0d0
  do imol=1,cgnmol
     molp(:) = 0d0
     do ires=cgmolindex(imol)+1,cgmolindex(imol+1)
        do iatom=cgresindex(ires)+1,cgresindex(ires+1)
           tpcoeff = 0.5d0*cgdeltatime*timescale/cgmass(iatom)
           molp(:) = molp(:) + cgmass(iatom)*( cgvel(:,iatom) + tpcoeff*elecvdw_force(:,iatom) )
        end do
     end do
     tpekin(:) = tpekin(:) + molp(:)**2/cgmolmass(imol)
  end do

  tppressure(:) = pressconvert*(tpekin(:)+vir(:))/cellvolume
  cgrealpressure = sum(tppressure)/3d0

  if ( cgipb == 2 ) then
     tpcoeff(1:3) = (1.d0 - isocompress*(cgpressure0 - cgrealpressure)*bar2pascal*cgdeltatime/cgtaup)**(1.d0/3.d0)
  else if ( cgipb == 3 ) then
     tpcoeff(1:3) = (1.d0 - isocompress*(cgpressure0 - tppressure(:))*bar2pascal*cgdeltatime/cgtaup)**(1.d0/3.d0)
  end if

  tpmat_car2frac = mat_car2frac
  call cgpb_prepare_cell(nptcoeff=tpcoeff)

  call cgpb_molecule_com()

  do imol=1,cgnmol
     tpvec(:) = tpcoeff*cgmolcom(1:3,imol)
     do ires=cgmolindex(imol)+1,cgmolindex(imol+1)
        do iatom=cgresindex(ires)+1,cgresindex(ires+1)
           cgcoor(:,iatom) = cgcoor(:,iatom) + tpvec(:) - cgmolcom(:,imol)
        end do
     end do
     cgmolcom(:,imol) = tpvec(:)
  end do
end subroutine

subroutine cgpb_molecule_com()
  integer :: imol,ires,iatom
  real*8 :: avgcoor(3)

  do imol=1, cgnmol
     avgcoor(:) = 0.d0
     do ires = cgmolindex(imol)+1, cgmolindex(imol+1)
        do iatom = cgresindex(ires)+1, cgresindex(ires+1)
           avgcoor(:) = avgcoor(:) + cgmass(iatom)*cgcoor(:,iatom)
        end do
     end do
     cgmolcom(1:3,imol) = avgcoor(:)/cgmolmass(imol)
  end do
end subroutine

end module
