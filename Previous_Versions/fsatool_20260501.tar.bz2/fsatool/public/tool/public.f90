module public
  implicit none

  integer,parameter :: iosiminfo=6
  integer :: sharenum, shareid, shared_comm_world, procid, procnum=1
  character*100 :: parmfile

  real*8,parameter :: pi=3.141592653589793d0
  real*8,parameter :: boltzmann=1.380649d-23, planck=6.626070d-34, joule2kcal=1.0d0/4184.0d0

  ! E_si = kcal/mol, E_mu = (mu*Ang^2/ps^2)*NA/4.184d3 = 1/4.184d2 kcal/mol
  ! E_si/E_mu = 418.4
  ! timescale = sqrt(E_si/E_mu) = 20.455  :  time step convert factor
  ! time = ps*timescale, velocity = Ang/(ps*timescale), R = 8.31441 J/mol/K = 8.31441/4.184d3 kcal/mol/K

  real*8,parameter :: timescale=20.455d0, gasconst=8.31441d0/4.184d3 !, pi=3.141592653589793d0
  real*8,parameter :: atm2pascal=1.01325d5, Avogadro=6.02214076d23, cal2joule=4.184d0

  ! pressconvert = pressure unit convert factor from kcal/mol/Ang^3 to bar
  real*8,parameter :: pressconvert = cal2joule*1d3*1d30/(Avogadro*0.987d0*atm2pascal)
  real*8,parameter :: bar2pascal = 0.987d0*atm2pascal

  ! constant isothermal compressibility of water, 4.46*10^-10 Pa^-1
  real*8,parameter :: isocompress = 4.46d-10

contains

subroutine errormsg(msg,real1,real2,real3,int1,int2,int3,str1,str2,str3,log1,log2,log3,ifwarning)
  include 'mpif.h'
  character(len=*),intent(in) :: msg
  real*8,intent(in),optional :: real1,real2,real3
  integer,intent(in),optional :: int1,int2,int3
  logical,intent(in),optional :: log1,log2,log3,ifwarning
  character(len=*),intent(in),optional :: str1,str2,str3
  integer :: ierr,iosiminfo

  iosiminfo=6; ierr=1
  if ( present(ifwarning) ) then
     if ( ifwarning .eqv. .true. ) ierr=0
  end if
  if ( ierr == 0 ) then
     write (iosiminfo, "(a,a)") "Warning: ",msg
  else if (ierr == 1) then
     write (iosiminfo, "(a,a)") "Error: ",msg
  endif

  write (iosiminfo, "(a,a)") "Error: ",msg
  if ( present(real1) ) write(iosiminfo,"(a,f10.3)") "real1= ",real1
  if ( present(real2) ) write(iosiminfo,"(a,f10.3)") "real2= ",real2
  if ( present(real3) ) write(iosiminfo,"(a,f10.3)") "real3= ",real3
  if ( present(int1) ) write(iosiminfo,"(a,i10)") "int1= ",int1
  if ( present(int2) ) write(iosiminfo,"(a,i10)") "int2= ",int2
  if ( present(int3) ) write(iosiminfo,"(a,i10)") "int3= ",int3
  if ( present(str1) ) write(iosiminfo,"(a,a)") "str1= ",trim(str1)
  if ( present(str2) ) write(iosiminfo,"(a,a)") "str2= ",trim(str2)
  if ( present(str3) ) write(iosiminfo,"(a,a)") "str3= ",trim(str3)
  if ( present(log1) ) write(iosiminfo,"(a,l6)") "log1= ",log1
  if ( present(log2) ) write(iosiminfo,"(a,l6)") "log2= ",log2
  if ( present(log3) ) write(iosiminfo,"(a,l6)") "log3= ",log3
  flush(iosiminfo)
  if ( ierr == 1 ) then
     if ( mpi_comm_world > 0 ) call mpi_finalize(ierr)
     stop
  end if
end subroutine

subroutine InitalizeSharedMemory()
  use mpi
  use, intrinsic :: iso_c_binding, only : c_ptr, c_f_pointer
  integer :: ierr
  call mpi_comm_split_type(mpi_comm_world, mpi_comm_type_shared, 0, mpi_info_null, shared_comm_world, ierr)
  call mpi_comm_rank(shared_comm_world, shareid, ierr)
  call mpi_comm_size(shared_comm_world, sharenum, ierr)
end subroutine

subroutine MPISharedMemoryAllocate(shared_win,dimreal1d,dimreal2d,dimreal3d, &
        sharereal1d,sharereal2d,sharereal3d,dimint1d,dimint2d,dimint3d,shareint1d,shareint2d,shareint3d)
  use mpi
  use, intrinsic :: iso_c_binding, only : c_ptr, c_f_pointer
  integer, intent(out) :: shared_win
  integer, intent(in), optional :: dimreal1d(1),dimreal2d(2),dimreal3d(3)
  real*8, pointer, intent(out), optional :: sharereal1d(:),sharereal2d(:,:),sharereal3d(:,:,:)
  integer, intent(in), optional :: dimint1d(1),dimint2d(2),dimint3d(3)
  integer, pointer, intent(out), optional :: shareint1d(:),shareint2d(:,:),shareint3d(:,:,:)

  type(C_PTR) :: baseptr
  integer :: ierr, disp_unit
  integer(kind=mpi_address_kind) :: windowsize

  if ( shareid == 0) then
     if ( present(dimreal1d) ) then
        windowsize = int(dimreal1d(1), MPI_ADDRESS_KIND)*8_MPI_ADDRESS_KIND
     else if ( present(dimreal2d) ) then
        windowsize = int(dimreal2d(1)*dimreal2d(2), MPI_ADDRESS_KIND)*8_MPI_ADDRESS_KIND
     else if ( present(dimreal3d) ) then
        windowsize = int(dimreal3d(1)*dimreal3d(2)*dimreal3d(3), MPI_ADDRESS_KIND)*8_MPI_ADDRESS_KIND
     else if ( present(dimint1d) ) then
        windowsize = int(dimint1d(1), MPI_ADDRESS_KIND)*4_MPI_ADDRESS_KIND
     else if ( present(dimint1d) ) then
        windowsize = int(dimint2d(1)*dimint2d(2), MPI_ADDRESS_KIND)*4_MPI_ADDRESS_KIND
     else if ( present(dimint1d) ) then
        windowsize = int(dimint3d(1)*dimint2d(2)*dimint3d(3), MPI_ADDRESS_KIND)*4_MPI_ADDRESS_KIND
     end if
  else
     windowsize = 0_MPI_ADDRESS_KIND
  end if
  disp_unit = 1

  call mpi_win_allocate_shared(windowsize, disp_unit, mpi_info_null, shared_comm_world, &
             baseptr, shared_win, ierr)
  if ( shareid /= 0) then
     call mpi_win_shared_query(shared_win, 0, windowsize, disp_unit, baseptr, ierr)
  end if

  if ( present(dimreal1d) ) then
     call c_f_pointer(baseptr, sharereal1d, dimreal1d)
  else if ( present(dimreal2d) ) then
     call c_f_pointer(baseptr, sharereal2d, dimreal2d)
  else if ( present(dimreal3d) ) then
     call c_f_pointer(baseptr, sharereal3d, dimreal3d)
  else if ( present(dimint1d) ) then
     call c_f_pointer(baseptr, shareint1d, dimint1d)
  else if ( present(dimint2d) ) then
     call c_f_pointer(baseptr, shareint2d, dimint2d)
  else if ( present(dimint3d) ) then
     call c_f_pointer(baseptr, shareint3d, dimint3d)
  end if
end subroutine

subroutine MPISharedMemoryDeallocate(sharewin)
  use mpi
  use, intrinsic :: iso_c_binding, only : c_ptr, c_f_pointer
  integer,intent(inout) :: sharewin
  integer :: ierr
  call mpi_win_free(sharewin, ierr)
  call mpi_comm_free(shared_comm_world, ierr)
end subroutine

! merge sort
subroutine sort_int(array,low,high)
  integer,intent(inout) :: array(:)
  integer,intent(in) :: low,high
  integer :: tparray(size(array))

  call sort(array, tparray, low, high)

contains
recursive subroutine sort(array, subarray, low, high)
  integer, intent(inout) :: array(:), subarray(:)
  integer :: low, high, mid

  if (high <= low) return
  mid = low + (high - low)/2
  call sort(array, subarray, low, mid)
  call sort(array, subarray, mid + 1, high)
  call merge(array, subarray, low, mid, high)
end subroutine
subroutine merge(array, subarray, low, mid, high)
  integer, intent(inout) :: array(:), subarray(:)
  integer :: low, high, mid, i, j, k
  do i = low, high
     subarray(i) = array(i)
  end do
  i = low; j = mid + 1;
  do k = low, high
     if (i > mid) then
        array(k) = subarray(j); j = j + 1
     else if (j > high) then
        array(k) = subarray(i); i = i + 1
     else if (subarray(j) < subarray(i)) then
        array(k) = subarray(j); j = j + 1
     else
        array(k) = subarray(i); i = i + 1
     end if
  end do
end subroutine
end subroutine

subroutine subspace_gridindex(ndim,cvngrid,gridvec,gridindex)
  implicit none
  integer,intent(in) :: ndim,gridvec(ndim),cvngrid(ndim)
  integer,intent(out) :: gridindex
  integer :: idim,tpstride

  gridindex=0
  do idim=1,ndim
     if ( (gridvec(idim)<1) .or. (gridvec(idim)>cvngrid(idim)) ) then
        print *,"gridvec error 1 ",gridvec(:)
     end if
  end do
  tpstride=1; gridindex=gridvec(1)
  do idim=2,ndim
     tpstride=tpstride*cvngrid(idim-1)
     gridindex = gridindex + tpstride*(gridvec(idim)-1)
  end do
end subroutine

subroutine subspace_gridvec(ndim,cvngrid,gridindex,gridvec)
  implicit none
  integer,intent(in) :: ndim,gridindex,cvngrid(ndim)
  integer,intent(out) :: gridvec(ndim)
  integer :: idim,stride,tpindex

  stride=product(cvngrid); tpindex=gridindex
  do idim=ndim,1,-1
     stride=stride/cvngrid(idim)
     gridvec(idim)=(tpindex-1)/stride + 1
     if ( (gridvec(idim)<1) .or. (gridvec(idim)>cvngrid(idim)) ) then
        print *,"gridindex error! ",gridvec; stop
     end if
     tpindex = tpindex - (gridvec(idim)-1)*stride
  end do
end subroutine

subroutine norm2d(tpnum,tparray,tpnorm)
  implicit none
  integer,intent(in) :: tpnum
  real*8,intent(in) :: tparray(tpnum)
  real*8,intent(out) :: tpnorm
  tpnorm = sqrt(dot_product(tparray,tparray))
end subroutine

subroutine rotateVector(vector, direction, angle)
  implicit none
  real*8,intent(in) :: direction(3),angle
  real*8,intent(inout) :: vector(3)
  real*8 :: matrix(3,3)
  real*8 n1,n2,n3,ct,st,temp

  n1 = direction(1); n2 = direction(2); n3 = direction(3)
  ct=cos(angle); st=sin(angle)

  matrix(1,1)=n1**2 + (1.0-n1**2)*ct
  matrix(1,2)=n1*n2*(1.0 - ct) + n3*st
  matrix(1,3)=n1*n3*(1.0 - ct) - n2*st

  matrix(2,1)=n1*n2*(1.0 - ct) - n3*st
  matrix(2,2)=n2**2 + (1.0-n2**2)*ct
  matrix(2,3)=n2*n3*(1.0 - ct) + n1*st

  matrix(3,1)=n1*n3*(1.0 - ct) + n2*st
  matrix(3,2)=n2*n3*(1.0 - ct) - n1*st
  matrix(3,3)=n3**2 + (1.0-n3**2)*ct

  call MatrixDotVector(3,matrix, vector)
end subroutine

subroutine cross_product ( vec1, vec2, vec3)
  implicit none
  real*8, dimension(1:3), intent(in) :: vec1, vec2
  real*8, dimension(1:3), intent(out) :: vec3

  vec3(1) = vec1(2) * vec2(3) - vec1(3) * vec2(2)
  vec3(2) = vec1(3) * vec2(1) - vec1(1) * vec2(3)
  vec3(3) = vec1(1) * vec2(2) - vec1(2) * vec2(1)
end subroutine

! https://gcc.gnu.org/onlinedocs/gcc-4.2.1/gfortran/RANDOM_005fSEED.html
subroutine random_init(iseed)
  implicit none
  integer,intent(in) :: iseed
  integer :: i,randsize,clock
  integer,dimension(:),allocatable :: randseed
  real*8 :: tprand,clock2

  randsize=32; call random_seed(size=randsize); allocate(randseed(randsize))
  if ( iseed < 0 ) then

     !call system_clock(count=clock)
     !randseed = clock + iseed  + 37 * (/ (i - 1, i = 1, randsize) /)

     call time_from_1970(clock2)
     do while ( clock2 > 2147483647 )
        clock2 = clock2 - 2147483647
     end do
     clock = int(clock2)
     randseed = clock + iseed  + 37 * (/ (i - 1, i = 1, randsize) /)

     call random_seed(put=randseed)
  else
     do i=1,randsize; randseed(i) = (iseed+1)*i; end do
     call random_seed(put=randseed)
  end if
  do i=1,200
     call random_number(tprand)
  end do
end subroutine

subroutine inversematrix(n,optmatrix)
  implicit none
  integer,intent(in) :: n
  real*8,intent(inout) :: optmatrix(n,n)
  integer :: i,j,k
  real*8 :: tpmatrix(n,2*n),mij
  
  do i=1,n
     tpmatrix(i,1:n)=optmatrix(i,1:n)
     tpmatrix(i,n+1:n+n)=0.0d0; tpmatrix(i,n+i)=1.0d0
  end do

  do i=1,n
     tpmatrix(i,i:2*n)=tpmatrix(i,i:2*n)/tpmatrix(i,i)
     do j=i+1,n
        mij=tpmatrix(j,i)/tpmatrix(i,i)
        do k=i,2*n
           tpmatrix(j,k)=tpmatrix(j,k)-mij*tpmatrix(i,k)
        end do
     end do
     do j=i-1,1,-1
        mij=tpmatrix(j,i)/tpmatrix(i,i)
        do k=i,2*n
           tpmatrix(j,k)=tpmatrix(j,k)-mij*tpmatrix(i,k)
        end do
     end do
  end do
 
  do i=1,n
     optmatrix(i,1:n)=tpmatrix(i,n+1:2*n)
  end do
end subroutine

subroutine matrixinverse(A, Ainv)
  implicit none
  real*8, dimension(:, :), intent(in) :: A
  real*8, dimension(size(A, 1), size(A, 1)) :: Ainv
  real*8, dimension(size(A, 1)) :: work  ! work array for LAPACK
  integer, dimension(size(A, 1)) :: ipiv   ! pivot indices
  integer :: n, info

  ! Store A in Ainv to prevent it from being overwritten by LAPACK
  Ainv = A
  n = size(A, 1)

  ! DGETRF computes an LU factorization of a general M-by-N matrix A
  ! using partial pivoting with row interchanges.
  call DGETRF(n, n, Ainv, n, ipiv, info)

  if (info /= 0) then
     stop 'Matrix is numerically singular!'
  end if

  ! DGETRI computes the inverse of a matrix using the LU factorization
  ! computed by DGETRF.
  call DGETRI(n, Ainv, n, ipiv, work, n, info)

  if (info /= 0) then
     stop 'Matrix inversion failed!'
  end if
end subroutine

! code from http://goodluck1982.blog.sohu.com/113355265.html
subroutine time_from_1970(msec)
  implicit none
  real*8 :: msec
  integer ::timevec(8)
  integer,parameter :: inityear=1970
  integer :: monthdays(12)
  integer :: i,j,nleapyear
  data monthdays /31,28,31,30,31,30,31,31,30,31,30,31/
  call date_and_time(values=timevec)
  !timevec(1):year(xxxx)    !timevec(2):month(1~12)   !timevec(3):date(1~31)              !timevec(5):hour(0~23)
  !timevec(6):miniute(0~59) !timevec(7):second(0~59)  !timevec(4):timezone(unit:miniute)  !timevec(8):millisecond(0~999)
  nleapyear=0
  do i=inityear,timevec(1)-1
     if( isleapyear(i)) nleapyear=nleapyear+1
  enddo
  if(isleapyear(timevec(1))) then
    monthdays(2)=29
  else
    monthdays(2)=28
  endif
  msec = ((timevec(1)-inityear)*365 + nleapyear + sum(monthdays(1:timevec(2)-1)) + timevec(3) - 1 )*24*3.6d3 - timevec(4)*60
  msec = msec + timevec(5)*3.6d3 + timevec(6)*60 + timevec(7) 
  msec = msec*1000d0 + timevec(8)
contains
function isleapyear(year)
  logical::isleapyear
  integer::year
  if( mod(year,4)/=0) then
     isleapyear=.false.
  else if(mod(year,100)/=0) then
     isleapyear=.true.
  else if(mod(year,400)==0) then
     isleapyear=.true.
  else
     isleapyear=.false.
  endif
end function
end subroutine

subroutine print_time(iofile,cputime,mdtime,timepercent)
  implicit none
  integer,intent(in) :: iofile
  real*8,intent(in) :: cputime    ! milliseconds
  real*8,intent(in) :: mdtime     ! ps
  real*8,intent(in) :: timepercent
  integer :: nday,nhour,nminute,nsecond,nmillisec
  real*8  :: realdays,remainingtime

  realdays = (0.001d0*cputime)/dble(3600*24)
  write(iofile,"(/,a27,f9.3,a13,f8.3,a)") "      MD Simulation time: ",mdtime," ns   Speed: ",mdtime/realdays," ns/day"

  nsecond=int(cputime*0.001d0); nmillisec=cputime-nsecond
  nhour=nsecond/3600; nday=nhour/24; nhour=mod(nhour,24) 
  nsecond=mod(nsecond,3600); nminute=nsecond/60; nsecond=mod(nsecond,60)

  write(iofile,"(a27,i8,a,i4,a,i4,a,i4,a)") "         Elapsed Time: ",nday," day",nhour," hour", &
             nminute," min",nsecond," sec" ! ,nmillisec," msec"

  remainingtime = cputime*(1d0 - timepercent)/timepercent
  nsecond=int(remainingtime*0.001d0); nmillisec=remainingtime-nsecond
  nhour=nsecond/3600; nday=nhour/24; nhour=mod(nhour,24)
  nsecond=mod(nsecond,3600); nminute=nsecond/60; nsecond=mod(nsecond,60)
  
  write(iofile,"(a27,i8,a,i4,a,i4,a,i4,a)") "       Remaining Time: ",nday," day",nhour," hour", &
             nminute," min",nsecond," sec" ! ,nmillisec," msec"
end subroutine

subroutine MatrixDotVector(ndim,matrix,vector)
  implicit none
  integer,intent(in) :: ndim
  real*8,intent(in):: matrix(ndim,ndim)
  real*8,intent(inout):: vector(ndim)
  real*8 :: temp,tempvector(ndim)
  integer i,j
  tempvector=vector
  do i=1,ndim
     temp=0.0
     do j=1,ndim
        temp = temp + matrix(i,j)*tempvector(j)
     end do
     vector(i) = temp
  end do
end subroutine

subroutine searchnamelist(tpunit,tpname,iffind)
  implicit none
  integer,intent(in) :: tpunit
  character(len=*),intent(in) :: tpname
  logical,intent(out) :: iffind
  integer :: tplen,i,ierr
  character*80 :: tpstring

  tplen = len(tpname); iffind=.false.
  do 
     read(tpunit,"(a80)",iostat=ierr) tpstring
     if ( ierr /= 0 ) exit
     do i=1,80
        if ( tpstring(i:i) == " " ) cycle
        if ( tpstring(i:i) == "&" ) then
           if ( tpstring(i+1:i+tplen) == tpname ) then
              iffind = .true.; exit
           end if
        end if
     end do
     if ( iffind .eqv. .true. ) exit
  end do
  if ( iffind .eqv. .true. ) backspace(tpunit)
end subroutine

! Complementary Error Function, erfc(x) = 1 - erf(x) = 1 - (2/sqrt(pi))*In(0,x)(dt*exp-t^2)
! https://en.wikipedia.org/wiki/Error_function
subroutine erfc_fast(x,erfc,deriv)
  implicit none
  real*8,intent(in) :: x
  real*8,intent(out) :: erfc,deriv
  real*8 :: p0,p1,p2,p3,p4,p5,pi
  parameter (p0=0.3275911d0, p1=0.254829592d0, p2=-0.284496736d0)
  parameter (p3=1.421413741d0, p4=-1.453152027d0, p5=1.061405429d0)
  parameter (pi = 3.141592653589793d0)
  real*8 :: tp,exp_xsq

  tp=1.0d0/(1.0d0+p0*x); exp_xsq=dexp(-x**2)
  erfc=((((p5*tp+p4)*tp+p3)*tp+p2)*tp+p1)*tp*exp_xsq
  deriv = -2d0/sqrt(pi)*exp_xsq
end subroutine

! Complementary Error Function, erfc(x) = 1 - erf(x) = 1 - (2/sqrt(pi))*In(0,x)(dt*exp-t^2)
! The codes are from the Frenkel and Smit's molecular simulation course
subroutine erfc_function(x,erfc,deriv)
  implicit none
  real*8,intent(in) :: x
  real*8,intent(out) :: erfc
  real*8,intent(out),optional :: deriv
  real*8 :: Pa,P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,T,U,Y,exp_xsq
  Parameter (Pa=3.97886080735226000d+00,P0=2.75374741597376782d-01,P1=4.90165080585318424d-01)
  Parameter (P2=7.74368199119538609d-01,P3=1.07925515155856677d+00,P4=1.31314653831023098d+00)
  Parameter (P5=1.37040217682338167d+00,P6=1.18902982909273333d+00,P7=8.05276408752910567d-01)
  Parameter (P8=3.57524274449531043d-01,P9=1.66207924969367356d-02,P10=-1.19463959964325415d-01)
  Parameter (P11=-8.38864557023001992d-02,P12=2.49367200053503304d-03,P13=3.90976845588484035d-02)
  Parameter (P14=1.61315329733252248d-02,P15=-1.33823644533460069d-02,P16=-1.27223813782122755d-02)
  Parameter (P17=3.83335126264887303d-03,P18=7.73672528313526668d-03,P19=-8.70779635317295828d-04)
  Parameter (P20=-3.96385097360513500d-03,P21=1.19314022838340944d-04,P22=1.27109764952614092d-03)
  real*8,parameter :: pi = -2d0/sqrt(3.141592653589793d0)

  t = Pa/(Pa+abs(x)); u = t - 0.5d0; exp_xsq=exp(-X*X)
  y = (((((((((P22*U+P21)*U+P20)*U+P19)*U+P18)*U+P17)*U+P16)*U+P15)*U+P14)*U+P13)*U + P12
  y = ((((((((((((Y*U+P11)*U+P10)*U+P9)*U+P8)*U+P7)*U+P6)*U+P5)*U+P4)*U+P3)*U+P2)*U+P1)*U+P0)*T*exp_xsq
  if ( x < 0.0d0 ) y = 2.0d0 - y

  erfc = y
  if ( present(deriv) ) deriv = pi*exp_xsq
end subroutine

! cosnphi = cos(n*phi) = fun(n, cosphi, cosphi^2)     (note that phi is not a necessary parameter)
! dcosnphi = -n*sin(n*phi) = fun(n, cosphi, cosphi^2)
subroutine multiple_angle_formulas(n,cosphi,cosphi2,cosnphi,dcosnphi)
  integer,intent(in) :: n
  real*8,intent(in) :: cosphi,cosphi2
  real*8,intent(out) :: cosnphi,dcosnphi
  real*8 :: tpcos,tpdcos
  integer :: i,j,tpn
  if ( mod(n,2)==1) then
     cosnphi=1d0; dcosnphi=1d0; tpcos=1d0
     do i=1,n-2,2
        tpcos = - tpcos * cosphi2 * ((n+i)*(n-i)) / ((i+1)*(i+2))
        cosnphi = cosnphi + tpcos
        dcosnphi = dcosnphi + tpcos*(i+2)
     end do
     i = n*(-1)**((n-1)/2)
     cosnphi = cosnphi * i * cosphi
     dcosnphi = dcosnphi * i
  else
     dcosnphi=-cosphi*n*n; cosnphi=dcosnphi/2; tpcos=cosnphi
     do i=2,n-2,2
        tpcos = - tpcos * cosphi2 * ((n+i)*(n-i)) / ((i+1)*(i+2))
        cosnphi = cosnphi + tpcos
        dcosnphi = dcosnphi + tpcos*(i+2)
     end do
     i=(-1)**(n/2)
     cosnphi = (cosnphi * cosphi + 1d0) * i
     dcosnphi = dcosnphi * i
  end if
end subroutine

subroutine gauss_box_muller(sigma,mean,rand)
  real*8,intent(in) :: sigma,mean
  real*8,intent(out) :: rand
  real*8,parameter :: pi = 3.141592653589793d0
  real*8 :: r1,r2

! Box-Muller algorithm
  call random_number(r1); call random_number(r2)
  rand = sqrt(-2d0*log(r1))*cos(2d0*pi*r2)
  rand = rand*sigma + mean
end subroutine

subroutine randint(nintlen,intdata,npick,intpick)
  implicit none
  integer,intent(in) :: nintlen,intdata(nintlen)
  integer,intent(in) :: npick
  integer,intent(out) :: intpick(npick)
  integer :: i, j, tpint
  integer :: dataTemp(nintlen),tempArray(npick)
  real*8 :: tpvalue

  dataTemp = intdata
  do i = nintlen, 1, -1
     call random_number(tpvalue); j  = int(ceiling(tpvalue*i))
     tpint = dataTemp(i); dataTemp(i) = dataTemp(j); dataTemp(j) = tpint
  end do
  intpick(1:npick)  = dataTemp(1:npick)
end subroutine

subroutine getMatrixDeterminant(ndim,amatrix,determinant)
  implicit none
  integer,intent(in):: ndim
  real*8,intent(in),dimension(ndim,ndim):: amatrix
  real*8,intent(out) :: determinant
  integer:: idim,jdim
  real*8:: mij,tpmatrix(ndim,ndim)
  tpmatrix=amatrix
  do jdim=1,ndim
     do idim=jdim+1,ndim
        if ( tpmatrix(jdim,jdim) == 0.0d0 ) cycle
        mij=tpmatrix(idim,jdim)/tpmatrix(jdim,jdim)
        tpmatrix(idim,jdim:ndim) = tpmatrix(idim,jdim:ndim) - mij*tpmatrix(jdim,jdim:ndim)
     end do
  end do
  determinant=1.0d0
  do idim=1,ndim
     determinant=determinant*tpmatrix(idim,idim)
  end do
end subroutine

subroutine checkfile(filename)
  character(len=*),intent(in) :: filename
  logical :: ifexist
  inquire(file=filename,exist=ifexist)
  if ( ifexist .eqv. .false. ) then
     print "(a,a,a)","The file ",trim(filename)," does not exist!"; stop
  end if
end subroutine

subroutine getfreeunit(tpunit)
  integer,intent(out) :: tpunit
  logical :: ifused
  tpunit = 10; ifused = .true.
  do
     if ( ifused .eqv. .false. ) exit
     tpunit = tpunit + 1
     inquire(unit=tpunit, opened=ifused)
  end do
end subroutine

! B-spline
! Input x falls into the normalized interval [0,1) between two nerghbouring control points
! x=0 and 1 are the left and right control points, respectively
! Input norder is the order of the B-spline
! Output basisfunc and deriv are the values and derivatives on the control points related to x (norder elements)
subroutine getbspline(x,norder,basisfunc,deriv)
  implicit none
  real*8,intent(in) :: x
  integer,intent(in) :: norder ! norder must be larger than 2 (Lagrange interpolation)
  real*8,intent(out) :: basisfunc(norder)
  real*8,intent(out) :: deriv(norder)
  integer :: iorder,i
  real*8 :: tpfactor

  basisfunc(1)=1d0
  do iorder=2, norder
     tpfactor = 1.0d0/dble(iorder-1)
     basisfunc(iorder) = x*basisfunc(iorder-1)*tpfactor   ! compute the basis function on the last control point
     do i=iorder-1, 2, -1
        basisfunc(i) = ( (x+dble(iorder-i))*basisfunc(i-1) + &
                                (dble(i)-x)*basisfunc(i) )*tpfactor
     end do
     basisfunc(1) = (1.0d0-x)*basisfunc(1)*tpfactor       ! compute the basis function on the first control point

     if ( iorder /= (norder-1) ) cycle
     deriv(1) = -basisfunc(1)                     ! compute the derivative on the first control point
     do i=2, norder-1
        deriv(i) = basisfunc(i-1) - basisfunc(i)  ! compute the derivative on the i-th control point
     end do
     deriv(norder) = basisfunc(norder-1)          ! compute the derivative on the last control point
  end do
end subroutine

subroutine getbspline_order4(xi,basisfunc,basisdev)
  implicit none
  real*8 :: xi,basisfunc(4),basisdev(4)
  real*8 :: xi_2, one_xi, one_xi_2

  xi_2 = xi**2*0.5; one_xi = 1.0d0 - xi; one_xi_2 = one_xi**2*0.5

  basisfunc(1) = one_xi*one_xi_2/3d0
  basisfunc(2) = xi_2*(xi-2.0d0) + 2d0/3d0
  basisfunc(3) = one_xi_2*(one_xi-2.0d0) + 2d0/3d0
  basisfunc(4) = xi*xi_2/3d0

  basisdev(1) = -one_xi_2
  basisdev(2) = xi*(xi-2.0d0) + xi_2
  basisdev(3) = -one_xi*(one_xi-2.0d0) - one_xi_2
  basisdev(4) = xi_2
end subroutine

subroutine singular_value_decomposition(ndim,matrix,umat,vmat)
  implicit none
  integer :: ndim
  real*8 :: matrix(ndim,ndim),umat(ndim,ndim),vmat(ndim,ndim),u(ndim),t(ndim)
  integer::i,j,k,icycle,downindex,upindex
  real*8 :: tpvec1(3),tpvec2(3),c,s,tpvalue
  real*8,parameter :: benchmark=1d-6

  ! QR decomposition
  umat=0d0; vmat=0d0
  do i=1,ndim
     umat(i,i)=1d0; vmat(i,i)=1d0
  end do
  do k = 1, ndim-1
     ! Prepare the U vector
     s=sign(sqrt(dot_product(matrix(k:ndim,k),matrix(k:ndim,k))), matrix(k,k))
     c = s*(s + matrix(k,k))
     u(k) = s + matrix(k,k); u(k+1:ndim) = matrix(k+1:ndim,k)
     ! Transform to the upper diagonal matrix A
     do j=k,ndim
        t(j)=dot_product(u(k:ndim),matrix(k:ndim,j))/c
        matrix(k:ndim,j) = matrix(k:ndim,j) - t(j)*u(k:ndim)
     end do
     ! Compute the left matrix umat
     do i=1,ndim
        t(i)=dot_product(umat(i,k:ndim),u(k:ndim))/c
        umat(i,k:ndim) = umat(i,k:ndim) - t(i)*u(k:ndim)
     end do
     if ( k == ndim-1 ) exit
     ! Prepare the U vector
     s=sign(sqrt(dot_product(matrix(k,k+1:ndim),matrix(k,k+1:ndim))),matrix(k,k+1))
     c=s*(s+matrix(k,k+1))
     u(k+1) = s + matrix(k,k+1); u(k+2:ndim) = matrix(k,k+2:ndim)
     ! Transform to the lower triangular matrix R
     do i=k,ndim
        t(i) = dot_product(u(k+1:ndim),matrix(i,k+1:ndim))/c
        matrix(i,k+1:ndim) = matrix(i,k+1:ndim) - t(i)*u(k+1:ndim)
     end do
    ! Compute the right matrix vmat
    do j=1,ndim
       t(j) = dot_product(vmat(k+1:ndim,j),u(k+1:ndim))/c
       vmat(k+1:ndim,j) = vmat(k+1:ndim,j) - t(j)*u(k+1:ndim)
    end do
  end do

  ! diagonalization
  icycle=1; upindex=1; downindex=ndim-1
  do
     i=1
     do i=upindex,ndim-1
        if (abs(matrix(i,i+1)) > benchmark*(abs(matrix(i,i))+abs(matrix(i+1,i+1)))) then
           exit
        else
           matrix(i,i+1)=0d0
        end if
     end do
     upindex=i; if ( upindex == ndim ) exit
     do i=downindex,upindex+1,-1
        if (abs(matrix(i,i+1)) > benchmark*(abs(matrix(i,i))+abs(matrix(i+1,i+1)))) then
           exit
        else
           matrix(i,i+1)=0d0
        end if
     end do
     downindex=i

     do k=upindex,downindex

        if (k==upindex) then 
           tpvec1(:)=[matrix(k,k),matrix(k+1,k),0d0]; tpvec2(:)=[matrix(k,k+1),matrix(k+1,k+1),0d0]
           call ColumnRow_transformation(tpvec1,tpvec2)
           matrix(k:k+1,k)=tpvec1(1:2); matrix(k:k+1,k+1)=tpvec2(1:2)
        else
           call ColumnRow_transformation(matrix(k-1:k+1,k),matrix(k-1:k+1,k+1))
        end if
        do i=1,ndim
           tpvalue=vmat(k+1,i); vmat(k+1,i)=vmat(k,i)*(-s)+vmat(k+1,i)*c; vmat(k,i)=vmat(k,i)*c+tpvalue*s
        end do
        call opt_matrix(matrix,vmat)

        if (k==downindex) then
           tpvec1(:)=[matrix(k,k),matrix(k,k+1),0d0]; tpvec2(:)=[matrix(k+1,k),matrix(k+1,k+1),0d0]
           call ColumnRow_transformation(tpvec1,tpvec2)
           matrix(k,k:k+1)=tpvec1(1:2); matrix(k+1,k:k+1)=tpvec2(1:2)
        else 
           call ColumnRow_transformation(matrix(k,k:k+2),matrix(k+1,k:k+2))
        end if
        do i=1,ndim
           tpvalue=umat(i,k+1); umat(i,k+1)=(-s)*umat(i,k)+c*umat(i,k+1); umat(i,k)=c*umat(i,k)+s*tpvalue
        end do
        call opt_matrix(matrix,vmat)
     end do
     icycle = icycle + 1; if ( icycle > 1000 ) exit
  end do

contains
subroutine ColumnRow_transformation(vector1,vector2)
  implicit none
  real*8 :: vector1(3),vector2(3)
  real*8 :: tpvec(3)
  if (abs(vector1(1))>abs(vector2(1))) then
    s=vector2(1)/vector1(1); c=1.0d0/sqrt(1d0+s**2)
    s=sign(s*c,vector2(1)); c=sign(c,vector1(1))
  else
    c=vector1(1)/vector2(1); s=1.0d0/sqrt(1d0+c**2)
    c=sign(c*s,vector1(1)); s=sign(s,vector2(1))
  end if 
  tpvec=vector2
  vector2=vector1*(-s)+vector2*c
  vector1=vector1*c+tpvec*s
end subroutine

! M = U**Sigma*Q*Q^-1*V
! add Q matrix to ensure all the diagonal elements in matrix Sigma positive.
subroutine opt_matrix(matrix,vmat)
  implicit none
  real*8 :: matrix(3,3),vmat(3,3)
  integer :: i,j
  do i = 1, 3
     if ( matrix(i,i) < 0d0 ) then
        matrix(:,i) = -matrix(:,i); vmat(i,:) = -vmat(i,:)
     end if
  enddo
end subroutine

end subroutine

! merge sort
subroutine sort_by_keys(num,list,inivalue)
  integer :: num,list(num),inivalue(num)
  integer :: tplst(num),tpatomlst(num),i,lens,lfirst,rfirst,lpos,rpos,lend,rend,tppos
  lens = 1
  do while ( lens<=num )
     tppos = 1
     do lfirst = 1,num,2*lens
        rfirst = lfirst + lens; lend = min(num,rfirst-1); rend = min(num,rfirst + lens - 1)
        lpos = lfirst; rpos = rfirst
        do while ( (lpos<=lend) .or. (rpos<=rend) )
           if ( (lpos<=lend) .and. ( (rpos>rend) .or. (list(lpos)<=list(rpos)) ) ) then
              tplst(tppos) = list(lpos); tpatomlst(tppos) = inivalue(lpos); lpos = lpos + 1
           else
              tplst(tppos) = list(rpos); tpatomlst(tppos) = inivalue(rpos); rpos = rpos + 1
           end if
           tppos = tppos + 1
        end do
     end do
     do i = 1,num
        list(i) = tplst(i); inivalue(i) = tpatomlst(i)
     end do
     lens = 2*lens
  end do
end subroutine

! merge sort
subroutine sort_by_keys_double(direction,num,array,sortindex)
  integer,intent(in) :: num,direction
  real*8,intent(inout) :: array(num)
  integer,intent(out) :: sortindex(num)
  real*8 :: tparray(num)
  integer :: tpindex(num),i,lens,lfirst,rfirst,lpos,rpos,lend,rend,tppos

  do i=1,num; sortindex(i)=i; end do
  lens = 1
  do while ( lens<=num )
     tppos = 1
     do lfirst = 1,num,2*lens
        rfirst = lfirst + lens; lend = min(num,rfirst-1); rend = min(num,rfirst + lens - 1)
        lpos = lfirst; rpos = rfirst
        do while ( (lpos<=lend) .or. (rpos<=rend) )
           if ( (lpos<=lend) .and. ( (rpos>rend) .or. ((array(lpos)-array(rpos))*direction<=0d0)) ) then
              tparray(tppos) = array(lpos); tpindex(tppos) = sortindex(lpos); lpos = lpos + 1
           else
              tparray(tppos) = array(rpos); tpindex(tppos) = sortindex(rpos); rpos = rpos + 1
           end if
           tppos = tppos + 1
        end do
     end do
     do i = 1,num
        array(i) = tparray(i); sortindex(i) = tpindex(i)
     end do
     lens = 2*lens
  end do
end subroutine

subroutine tica_accumulate_data(data, npoint, nfeature, lagstep, datatrajindex, selecteigens, eigenval, eigenvec, datamean)
  real*8,intent(in) :: data(nfeature,npoint)
  integer,intent(in) :: npoint, nfeature, lagstep, datatrajindex(npoint)
  integer,intent(in),optional :: selecteigens(:)
  real*8,intent(out),optional :: eigenval(size(selecteigens)),eigenvec(nfeature,size(selecteigens))
  real*8,intent(out),optional :: datamean(nfeature,1)

  integer :: i, j, k, info, component_index(nfeature)
  real*8 :: cov(nfeature, nfeature), cov_tau(nfeature, nfeature), cov_inv(nfeature, nfeature)
  real*8 :: eigenValue_img(nfeature), eigenVector(nfeature, nfeature), work(4*nfeature)
  real*8 :: eigenvalues(nfeature),dataavg(nfeature,1)
  integer,save :: nvaliddata
  integer,dimension(:),allocatable,save :: pretrajindex
  real*8,dimension(:),allocatable,save :: sum_mean0, sum_mean1
  real*8,dimension(:,:),allocatable,save :: sum_cov, sum_cov_tau, predata

  if ( .not. allocated(sum_mean0) ) then
     nvaliddata = 0
     allocate(sum_mean0(nfeature),sum_mean1(nfeature)); sum_mean0 = 0d0; sum_mean1 = 0d0
     allocate(sum_cov(nfeature,nfeature), sum_cov_tau(nfeature,nfeature)); sum_cov = 0d0; sum_cov_tau = 0d0
     allocate(pretrajindex(lagstep)); pretrajindex = 0
     allocate(predata(nfeature,lagstep)); predata = 0d0
  end if

  if ( nvaliddata == 0 ) then
     do i = 1, lagstep
        pretrajindex(i) = datatrajindex(npoint-lagstep+i)
        predata(:,i) = data(:,npoint-lagstep+i)
     end do
  else
     do i = 1, lagstep
        if ( datatrajindex(i) /= pretrajindex(i) ) cycle
        nvaliddata = nvaliddata + 1
        sum_mean0 = sum_mean0 + predata(:,i); sum_mean1 = sum_mean1 + data(:,i)
        do j = 1, nfeature
           do k = 1,nfeature
               sum_cov(j,k) = sum_cov(j,k) + predata(j,i)*predata(k,i) + data(j,i)*data(k,i)
               sum_cov_tau(j,k) = sum_cov_tau(j,k) + predata(j,i)*data(k,i) + data(j,i)*predata(k,i)
           end do
        end do
     end do
  end if

  do i = 1, npoint - lagstep
     if ( datatrajindex(i) /= datatrajindex(i+lagstep) ) cycle
     nvaliddata = nvaliddata + 1
     sum_mean0 = sum_mean0 + data(:,i); sum_mean1 = sum_mean1 + data(:,i+lagstep)
     do j = 1, nfeature
        do k = 1,nfeature
            sum_cov(j,k) = sum_cov(j,k) + data(j,i)*data(k,i) + data(j,i+lagstep)*data(k,i+lagstep)
            sum_cov_tau(j,k) = sum_cov_tau(j,k) + data(j,i)*data(k,i+lagstep) + data(j,i+lagstep)*data(k,i)
        end do
     end do
  end do

  dataavg(:,1) = (sum_mean0 + sum_mean1)/dble(2*nvaliddata)
  do k = 1, nfeature
     cov(:,k) = sum_cov(:,k)/dble(2*nvaliddata) - dataavg(:,1)*dataavg(k,1)
     cov_tau(:,k) = sum_cov_tau(:,k)/dble(2*nvaliddata) - dataavg(:,1)*dataavg(k,1)
  end do

  call dpotrf("L", nfeature, cov, nfeature, info)
  if (info .gt. 0) call errormsg("TICA covariance matrix is not a positive definite matrix")

  do i = 1, nfeature
     do j = i + 1, nfeature
        cov(i, j) = 0.0d0
     end do
  end do

  call MatrixInverse(cov, cov_inv)
  cov = matmul(cov_inv, matmul(cov_tau, transpose(cov_inv)))

  call dgeev("N", "V", nfeature, cov, nfeature, eigenvalues, eigenValue_img, &
             cov_tau, nfeature, eigenVector, nfeature, work, 4*nfeature, info)
  if ( info > 0 ) call errormsg("lapack DGEEV error!")

  eigenVector = matmul(transpose(cov_inv), eigenVector)
  call sort_by_keys_double(-1,nfeature,eigenvalues,component_index)

  if ( present(datamean) ) datamean = dataavg
  if ( present(eigenvec) ) then
     do i = 1, size(selecteigens)
        eigenvec(:,i) = eigenVector(:, component_index(selecteigens(i)))
     end do
  end if
  if ( present(eigenval) ) then
     do i = 1, size(selecteigens)
        eigenval(i) = eigenvalues(i)
     end do
  end if

end subroutine

subroutine rotate_coordinates(tpinput,tpoutput,tpingrad,tpoutgrad)
   real*8,intent(in) :: tpinput(:)
   real*8,intent(out) :: tpoutput(:)
   real*8,intent(in),optional :: tpingrad(:)
   real*8,intent(out),optional :: tpoutgrad(:)
   integer :: i,j,k,tpnatom,imat
   real*8 :: incoor(3, size(tpinput)/3), rot_angle, tpvec(3)
   real*8 :: mat_rx(3,3), ccenter(3), mat_24(3,3,24), tpmat(3,3)

   if ( mod(size(tpinput),3) /= 0  ) then
      print *,"input size error!"; stop
   end if

   tpnatom = size(tpinput)/3; incoor(:,:) = reshape(tpinput,[3,tpnatom])
   ccenter = (minval(incoor,dim=2)+maxval(incoor,dim=2))/2d0

   imat = 0
   do i = 1, 6
      select case (i)
         case (1)
            tpmat = axis_rotation('y', 0.0d0)
         case (2)
            tpmat = axis_rotation('y', 90.0d0)
         case (3)
            tpmat = axis_rotation('y', 180.0d0)
         case (4)
            tpmat = axis_rotation('y', 270.0d0)
         case (5)
            tpmat = axis_rotation('z', 90.0d0)
         case (6)
            tpmat = axis_rotation('z', -90.0d0)
      end select
      do j = 1, 4
         rot_angle = 90d0*dble(j-1)
         mat_rx = axis_rotation('x', rot_angle)
         tpmat = matmul(mat_rx, tpmat)
         imat = imat + 1

         do k = 1, tpnatom
            tpoutput(3*k-2:3*k) = matmul(tpmat, incoor(:,k) - ccenter)
         end do

         if ( present(tpingrad) ) then
            do k = 1, tpnatom
               tpoutgrad(3*k-2:3*k) = matmul(tpmat, tpingrad)
            end do
         end if

      end do
   end do

   if ( imat /= 24 ) stop "imat error!"

contains

   ! https://zhuanlan.zhihu.com/p/183973440
   function axis_rotation(axis, angle) result(mat_r)
      character(len=*), intent(in) :: axis
      real*8, intent(in) :: angle
      real*8 :: mat_r(3, 3), cos_beta, sin_beta

      cos_beta = cosd(angle); sin_beta = sind(angle)
      select case(trim(axis))
         case('x')
            mat_r = reshape([1d0,0d0,0d0, 0d0,cos_beta,sin_beta, 0d0,-sin_beta,cos_beta],[3,3])
         case('y')
            mat_r = reshape([cos_beta,0d0,-sin_beta, 0d0,1d0,0d0, sin_beta,0d0,cos_beta],[3,3])
         case('z')
            mat_r = reshape([cos_beta,sin_beta,0d0, -sin_beta,cos_beta,0d0, 0d0,0d0,1d0],[3,3])
         case default
            stop 'error case'
      end select

   end function axis_rotation

end subroutine

! https://zhuanlan.zhihu.com/p/90907170
subroutine public_divide_mol_by_deep_first_search(atommark, nmol, natom, nbond, bondatom)
   integer, intent(inout) :: atommark(:), nmol,natom,nbond,bondatom(:)

   type atom_neighbor
      integer :: idx
      type(atom_neighbor), pointer :: next
   end type atom_neighbor

   type atom_info
      type(atom_neighbor), pointer :: head_neighbor
      type(atom_neighbor), pointer :: tail_neighbor
   end type atom_info

   type(atom_info), target :: atom_vec(natom)
   integer :: imol, ibond, i, j, iatom

   do iatom = 1, natom
      nullify (atom_vec(iatom)%head_neighbor, atom_vec(iatom)%tail_neighbor)
   end do

   ! construct a chain table for each atom. that is, all bonded atoms on a atom form an independent chain table
   do ibond = 1, nbond
      i = bondatom(3*ibond-2); j = bondatom(3*ibond-1)
      call moldata_insert_neighbor(atom_vec(i), atom_vec(j), i, j)
   end do

   atommark = 0; imol = 0
   do iatom = 1, natom
      if (atommark(iatom) /= 0) cycle
      ! if atommark(iatom) = 0, it has not been visited in the subroutine "set_atommark" yet, start a new imol index
      imol = imol + 1
      ! first search iatom's bonded atoms(neighbors), then search its neighbors' bonded atoms
      ! all visited atoms shall have the same imol index in the recursive subroutine "set_atommark"
      call set_atommark(iatom)
   end do
   nmol = imol

   ! deallocate chain table
   do iatom = 1, natom
      call moldata_deallocate_chain_table(atom_vec(iatom))
   end do

contains

   subroutine moldata_insert_neighbor(atm1, atm2, i, j)
      type(atom_info) :: atm1, atm2
      integer :: i, j
      type(atom_neighbor), pointer :: new_neighbor1, new_neighbor2
   
      nullify(new_neighbor1, new_neighbor2)
      allocate(new_neighbor1, new_neighbor2)
      nullify(new_neighbor1%next, new_neighbor2%next)
   
      new_neighbor1%idx = j; new_neighbor2%idx = i
   
      ! set atom i's head and tail to atom j at the beginning
      ! set atom i's tail to atom j and assume atom j is the end, so atom j's tail is itself
      ! if atom j finds a new neighbor later, its tail will be updated subsequently
      if (.not. associated(atm1%head_neighbor)) then
         atm1%head_neighbor => new_neighbor1
         atm1%tail_neighbor => new_neighbor1
      else
         ! here construct a chain table only for atom i
         ! let atom i's current tail point to atom j
         atm1%tail_neighbor%next => new_neighbor1
         ! move atom i's current tail to atom j
         atm1%tail_neighbor => new_neighbor1
      end if
   
      if (.not. associated(atm2%head_neighbor)) then
         atm2%head_neighbor => new_neighbor2
         atm2%tail_neighbor => new_neighbor2
      else
         atm2%tail_neighbor%next => new_neighbor2
         atm2%tail_neighbor => new_neighbor2
      end if
   
   end subroutine moldata_insert_neighbor

   recursive subroutine set_atommark(idx)
      integer :: idx
      integer :: inbor
      type(atom_neighbor), pointer :: iter_neighbor

      nullify(iter_neighbor)

      ! current atom belongs to imol
      atommark(idx) = imol

      ! search the chain table on atom idx from its head to its next and then next bonded neighbors
      ! if one of atom idx's neighbor is an unvisited atom (unmarked atom, atommark(neighbor)=0), start a new search for the neighbor's neighbors
      iter_neighbor => atom_vec(idx)%head_neighbor
      do while(associated(iter_neighbor))
         inbor = iter_neighbor%idx
         ! if inbor is an unvisited atom, start a new search on a new chain table
         if (atommark(inbor) == 0) call set_atommark(inbor)
         iter_neighbor => iter_neighbor%next
      end do
   end subroutine set_atommark

   subroutine moldata_deallocate_chain_table(atm)
      type(atom_info) :: atm

      type(atom_neighbor), pointer :: iter_neighbor, deallocate_neighbor

      nullify(iter_neighbor, deallocate_neighbor)

      iter_neighbor => atm%head_neighbor
      do while(associated(iter_neighbor))
         deallocate_neighbor => iter_neighbor
         iter_neighbor => iter_neighbor%next
         deallocate(deallocate_neighbor)
      end do

   end subroutine moldata_deallocate_chain_table

end subroutine public_divide_mol_by_deep_first_search

! https://zhuanlan.zhihu.com/p/90907170
subroutine public_divide_mol_by_disjoint_set_union(atommark, nmol, natom, nbond, bondatom)
   integer, intent(inout) :: atommark(:), nmol, natom, nbond, bondatom(:)

   integer :: fa(natom), hash(natom)
   integer :: imol, iroot, ibond, i, j, iatom

   do iatom = 1, natom
      fa(iatom) = iatom
   end do

   do ibond = 1, nbond
      i = bondatom(3*ibond-2); j = bondatom(3*ibond-1)
      ! find atom j's root node and let its root be atom i's root node
      ! i.e., let atom i and atom j share the same root node
      fa(find_root(j)) = find_root(i)
   end do

   imol = 0; hash = 0; atommark = 0
   do iatom = 1, natom
      ! if iatom's root node is itself, the atom is the root atom in the molecule
      if ( fa(iatom) == iatom ) then
         imol = imol + 1
         hash(iatom) = imol
      end if
   end do
   nmol = imol

   ! cycle over the atoms in a molecule and mark them by the same root atoms
   do iatom = 1, natom
      iroot = find_root(iatom)
      atommark(iatom) = hash(iroot)
   end do

contains

   recursive function find_root(idx) result(fout)
      integer :: idx
      integer :: fout

      ! if atom idx's root is not itself, find its parent atom and save it to atom idx
      if ( fa(idx) /= idx ) then
         fa(idx) = find_root(fa(idx))
      end if
      fout = fa(idx)
   end function find_root

end subroutine public_divide_mol_by_disjoint_set_union

subroutine copyright
  integer,parameter :: iosiminfo=6

write(iosiminfo,"(/,a)") &
"######################################################################################################"
write(iosiminfo,"(a)") &
"#                                                                                                    #"
write(iosiminfo,"(a)") &
"#                   CA                                                                               #"
write(iosiminfo,"(a)") &
"#                   /                      ***  FSATOOL 2.0  ***                                     #"
write(iosiminfo,"(a)") &
"#              H - N                                                                                 #"
write(iosiminfo,"(a)") &
"#                   \\               Developed by Changjun Chen\'s group                               #"
write(iosiminfo,"(a)") &
"#                    C = O                          in                                               #"
write(iosiminfo,"(a)") &
"#                   /          Huazhong University of Science and Technology                         #"
write(iosiminfo,"(a)") &
"#                  CA                                                                                #"
write(iosiminfo,"(a)") &
"#                                                                                                    #"
write(iosiminfo,"(a)") &
"# Web site:   https://github.com/fsatool/fsatool.github.io                                           #"
write(iosiminfo,"(a)") &
"#                                                                                                    #"
write(iosiminfo,"(a)") &
"# Recommended Citations:                                                                             #"

write(iosiminfo,"(a)") &
"# [1] Zirui Shu, Mincong Wu, Jun Liao and Changjun Chen*                                             #"
write(iosiminfo,"(a)") &
"#     FSATOOL 2.0: An integrated molecular dynamics simulation and trajectory data analysis program. #"
write(iosiminfo,"(a)") &
"#     J. Comput. Chem. 2022, 43: 215-224                                                             #"

write(iosiminfo,"(a)") &
"# [2] Haomiao Zhang, Qiankun Gong, Haozhe Zhang, and Changjun Chen*                                  #"
write(iosiminfo,"(a)") &
"#     FSATOOL: A useful tool to do the conformational sampling and trajectory analysis work          #"
write(iosiminfo,"(a)") &
"#     for biomolecules.                                                                              #"
write(iosiminfo,"(a)") &
"#     J. Comput. Chem. 2020, 41: 156-164                                                             #"

write(iosiminfo,"(a)") &
"#                                                                                                    #"
write(iosiminfo,"(a)") &
"######################################################################################################"
write(iosiminfo,*)
flush(iosiminfo)
end subroutine

end module
