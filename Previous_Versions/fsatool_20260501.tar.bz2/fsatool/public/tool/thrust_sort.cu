#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/sort.h>
extern "C" {
  void thrust_sort_int_by_keys_wrapper( int data[], int values[],int N){
    thrust::device_ptr <int> data_ptr(data);
    thrust::device_ptr <int> values_ptr(values);
    thrust::sort_by_key(data_ptr,data_ptr+N,values_ptr);
}
  void thrust_sort_float_by_keys_wrapper( float data[], int values[],int N){
    thrust::device_ptr <float> data_ptr(data);
    thrust::device_ptr <int> values_ptr(values);
    thrust::sort_by_key(data_ptr,data_ptr+N,values_ptr);
}
  void thrust_sort_double_by_keys_wrapper( double data[], int values[],int N){
    thrust::device_ptr <double> data_ptr(data);
    thrust::device_ptr <int> values_ptr(values);
    thrust::sort_by_key(data_ptr,data_ptr+N,values_ptr);
}
  void thrust_sort_int_by_keys_group_wrapper( int data[], int values[], int groupindex[], int ngroup){
    thrust::device_ptr <int> data_ptr(data);
    thrust::device_ptr <int> values_ptr(values);
    thrust::device_ptr <int> group_ptr(groupindex);
    for(int i=0; i<ngroup; i++)
        thrust::sort_by_key(data_ptr+*(group_ptr+i),data_ptr+*(group_ptr+i+1),values_ptr+*(group_ptr+i));
}
}
