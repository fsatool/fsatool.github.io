module sortmod
  interface thrustsort
    subroutine thrust_sort_int_by_keys(input,values,N) bind(C,name="thrust_sort_int_by_keys_wrapper")
      use iso_c_binding
      integer(c_int),device:: input(*)
      integer(c_int),device:: values(*)
      integer(c_int),value:: N
    end subroutine

    subroutine thrust_sort_float_by_keys(input,values,N) bind(C,name="thrust_sort_float_by_keys_wrapper")
      use iso_c_binding
      real,device:: input(*)
      integer(c_int),device:: values(*)
      integer(c_int),value:: N
    end subroutine

    subroutine thrust_sort_double_by_keys(input,values,N) bind(C,name="thrust_sort_double_by_keys_wrapper")
      use iso_c_binding
      real*8,device:: input(*)
      integer(c_int),device:: values(*)
      integer(c_int),value:: N
    end subroutine

    subroutine thrust_sort_int_by_keys_group(input,values,groupindex,ngroup) bind(C,name="thrust_sort_int_by_keys_group_wrapper")
      use iso_c_binding
      integer(c_int),device:: input(*)
      integer(c_int),device:: values(*)
      integer(c_int),device:: groupindex(*)
      integer(c_int),value:: ngroup
    end subroutine
  end interface

end module
