module netcdf_func
  use public
  use netcdf
  implicit none
  real*8 :: length(3), angle(3)
  logical :: ifprintNetcdferror = .true.
  double precision, parameter :: velocityScale = 20.455d0

  interface netcdf_ReadVariables
     module procedure netcdf_ReadVariable, netcdf_ReadVariables1D, netcdf_ReadVariables2D
  end interface

  interface netcdf_WriteVariables
     module procedure netcdf_WriteVariable, netcdf_WriteVariables1D, netcdf_WriteVariables2D
  end interface

  private :: netcdf_warningmsg, length, angle, ifprintNetcdferror, velocityScale

contains

! Creat Netcdf File
! For sim module
! call netcdf_CreateFile(file, title, "sim", isRestart, hasBox, atomNumber, ncid, &
!               coorVID, velocityVID, timeVID, frameDID, cellAngleVID, cellLengthVID, overwrite='C')
! For msm module
! call netcdf_CreateFile(file, title, "msm", .false. , hasBox, atomNumber, ncid, &
!               coorVID, velocityVID, timeVID, frameDID, cellAngleVID, cellLengthVID, overwrite)
subroutine netcdf_CreateFile(file, title, modname, isRestart, hasBox, atomNumber, ncid, coorVID, &
                            velocityVID, timeVID, frameDID, cellAngleVID, cellLengthVID, overwrite)
  character(*), intent(in) :: file, title, modname
  character(*), intent(in), optional :: overwrite
  logical, intent(in) :: isRestart, hasBox
  integer, intent(in) :: atomNumber
  integer, intent(out), optional :: ncid, coorVID, velocityVID, timeVID, frameDID, cellAngleVID, cellLengthVID

  integer :: tpncid, tpcoorVID, tptimeVID, tpframeDID, tpvelocityVID, tpcellAngleVID, tpcellLengthVID
  integer :: spatialDID, cell_spatialDID, cell_angularDID, atomDID, labelDID
  integer :: spatialVID, cell_spatialVID, cell_angularVID
  integer :: cmode, dataType, stat

  cmode = nf90_64bit_offset
  if (present(overwrite)) then
     ! ior used for nf90_64bit_offset(512) + nf90_noclobber(4) or nf90_64bit_offset + nf90_clobber(0)
     if (overwrite == 'N') cmode = ior(cmode, nf90_noclobber)
     if (overwrite == 'C') cmode = ior(cmode, nf90_clobber)
  end if

  stat = nf90_create(file, cmode, tpncid)
  call netcdf_warningmsg(stat, "Creating File.")

  ! Frame and Time
  if (.not. isRestart) then
     dataType = NF90_FLOAT
     call netcdf_warningmsg(nf90_def_dim(tpncid, "frame", NF90_UNLIMITED, tpframeDID), "Defining frame dimension.")
     call netcdf_warningmsg(nf90_def_var(tpncid, "time", dataType, tpframeDID, tptimeVID), "Defining time variable.")
  else
     dataType = NF90_DOUBLE
     call netcdf_warningmsg(nf90_def_var(tpncid, "time", dataType, varid=tptimeVID), "Defining time variable.")
  end if
  call netcdf_warningmsg(nf90_put_att(tpncid, tptimeVID, "unit", "nanosecond"), "Putting time unit.")

  ! spatial
  call netcdf_warningmsg(nf90_def_dim(tpncid, "spatial", 3, spatialDID), "Defining spatial dimension.")
  call netcdf_warningmsg(nf90_def_var(tpncid, "spatial", NF90_CHAR, spatialDID, spatialVID), "Defining spatial variable.")

  ! AtomNumber
  call netcdf_warningmsg(nf90_def_dim(tpncid, "atom", atomNumber, atomDID), "Defining atom dimension.")

  ! Coordinate and Velocity
  if (isRestart) then ! Here default only restart file has velocity
     call netcdf_warningmsg(nf90_def_var(tpncid, "coordinates", dataType, (/ spatialDID, &
                           atomDID/), tpcoorVID), "Defining coordinates variable.")
     call netcdf_warningmsg(nf90_put_att(tpncid, tpcoorVID, "units", "angstrom"), "Putting coordinates units.")
     ! if (hasVelocity) then
     call netcdf_warningmsg(nf90_def_var(tpncid, "velocities", dataType, (/spatialDID, &
                           atomDID/), tpvelocityVID), "Defining velocities variable.")
     call netcdf_warningmsg(nf90_put_att(tpncid, tpvelocityVID, "units", "angstrom/picosecond"), &
                           "Putting velocities units.")
     call netcdf_warningmsg(nf90_put_att(tpncid, tpvelocityVID, "scale_factor", &
                           velocityScale), "Putting velocities scale factor.")
     ! end if
  else
     call netcdf_warningmsg(nf90_def_var(tpncid, "coordinates", dataType, (/spatialDID, atomDID, &
                           tpframeDID/), tpcoorVID), "Defining coordinates variable.")
     call netcdf_warningmsg(nf90_put_att(tpncid, tpcoorVID, "units", "angstrom"), "Putting coordinates units.")
     ! if (hasVelocity) then
     ! call netcdf_warningmsg(nf90_def_var(tpncid, "velocities", dataType, (/ spatialDID, atomDID, &
                           ! tpframeDID/), tpvelocityVID), "Defining velocities variable.")
     ! call netcdf_warningmsg(nf90_put_att( tpncid, tpvelocityVID, "units", "angstrom/picosecond"), &
                           ! "Putting velocities units.")
     ! call netcdf_warningmsg(nf90_put_att( tpncid, tpvelocityVID, "scale_factor", &
                           ! velocityScale), "Putting velocities scale factor.")
     ! end if
  end if

  ! Box
  if (hasBox) then
     call netcdf_warningmsg(nf90_def_dim(tpncid, "cell_spatial", 3, cell_spatialDID), "Defining cell spatial dimension.")
     call netcdf_warningmsg(nf90_def_var(tpncid, "cell_spatial", NF90_CHAR, (/cell_spatialDID/), &
                           cell_spatialVID), "Defining cell spatial variable.")
     call netcdf_warningmsg(nf90_def_dim(tpncid, "label", 5, labelDID), "Defining label dimension for cell angular.")
     call netcdf_warningmsg(nf90_def_dim(tpncid, "cell_angular", 3, cell_angularDID), "Defining cell angular dimension")
     call netcdf_warningmsg(nf90_def_var(tpncid, "cell_angular", NF90_CHAR, (/labelDID, cell_angularDID/), &
                           cell_angularVID), "Defining cell angular variable.")

     if (isRestart) then
        call netcdf_warningmsg(nf90_def_var(tpncid, "cell_lengths", NF90_DOUBLE, &
                              (/cell_spatialDID/), tpcellLengthVID), "Defining cell length.")
        call netcdf_warningmsg(nf90_def_var(tpncid, "cell_angles", NF90_DOUBLE, &
                              (/cell_angularDID/), tpcellAngleVID), "Defining cell angle.")
     else
        call netcdf_warningmsg(nf90_def_var(tpncid, "cell_lengths", NF90_DOUBLE, &
                              (/cell_spatialDID, tpframeDID/), tpcellLengthVID), "Defining cell length.")
        call netcdf_warningmsg(nf90_def_var(tpncid, "cell_angles", NF90_DOUBLE, &
                              (/cell_angularDID, tpframeDID/), tpcellAngleVID), "Defining cell angle.")
     end if
     call netcdf_warningmsg(nf90_put_att(tpncid, tpcellLengthVID, "units", "angstrom"), &
                           "Writing cell length units")
     call netcdf_warningmsg(nf90_put_att(tpncid, tpcellAngleVID, "units", "degree"), &
                           "Writing cell angle units.")
  end if

  ! Attributes
  call netcdf_warningmsg(nf90_put_att(tpncid, NF90_GLOBAL, "title", title), "Putting title.")
  call netcdf_warningmsg(nf90_put_att(tpncid, NF90_GLOBAL, "application", "FSATOOL"), "Putting application name.")
  call netcdf_warningmsg(nf90_put_att(tpncid, NF90_GLOBAL, "program", modname), "Putting program name.")
  call netcdf_warningmsg(nf90_put_att(tpncid, NF90_GLOBAL, "programVersion", "1.0"), "Putting program version.")

  ! AMBER Conventions
  if (isRestart) then
     call netcdf_warningmsg(nf90_put_att(tpncid, NF90_GLOBAL, "Conventions", &
                           "AMBERRESTART"), "Putting AMBER restart conventions.")
  else
     call netcdf_warningmsg(nf90_put_att(tpncid, NF90_GLOBAL, "Conventions", &
                           "AMBER"), "Putting AMBER trajectory conventions.")
  end if
  call netcdf_warningmsg(nf90_put_att(tpncid, NF90_GLOBAL, "ConventionVersion", &
                        "1.0"), "Putting AMBER conventions version.")

  ! Set fill mode
!  call netcdf_warningmsg(nf90_set_fill(tpncid, NF90_NOFILL, stat), "Setting fill value.")

  ! end Netcdf definitions
  call netcdf_warningmsg(nf90_enddef(tpncid), "Ending Definitions")

  ! Specify spatial dimension labels
  call netcdf_warningmsg(nf90_put_var(tpncid, spatialVID, (/'x', 'y', 'z'/), &
                        start=(/1/), count=(/3/)), "Writing spatial variable")

  if (hasBox) then
     call netcdf_warningmsg(nf90_put_var(tpncid, cell_spatialVID, (/'a', 'b', 'c'/), &
                           start=(/1/), count=(/3/)), "Writing cell cell spatial variable.")
     call netcdf_warningmsg(nf90_put_var(tpncid, cell_angularVID, (/'alpha', 'beta ', 'gamma'/), &
                           start=(/1, 1/), count=(/5, 3/)), "Writing cell angle variable.")
  end if

  if(present(ncid)) ncid = tpncid
  if(present(coorVID)) coorVID = tpcoorVID
  if(present(timeVID)) timeVID = tptimeVID
  if(present(frameDID)) frameDID = tpframeDID
  if(present(velocityVID)) velocityVID = tpvelocityVID
  if(present(cellAngleVID)) cellAngleVID = tpcellAngleVID
  if(present(cellLengthVID)) cellLengthVID = tpcellLengthVID
end subroutine

subroutine netcdf_OpenFile(file, ncid, title, frameNumber, atomNumber, coorVID, velocityVID, &
                          cellLengthVID, cellAngleVID, timeVID)
  character(*), intent(in) :: file
  integer, intent(out) :: ncid
  character(*), intent(out), optional :: title
  integer, intent(out), optional :: frameNumber, atomNumber, coorVID, velocityVID
  integer, intent(out), optional :: cellLengthVID, cellAngleVID, timeVID
  integer :: iostat, spatial
  ! character(256) :: title

  call netcdf_warningmsg(nf90_open(file, NF90_NOWRITE, ncid), "Opening Netcdf File")

  ! Inquire dimensions and varID
  if (present(title)) call netcdf_warningmsg(nf90_get_att(ncid, NF90_GLOBAL, "title", title), "Getting title")
  if (present(frameNumber)) call netcdf_GetDimension(ncid, "frame", frameNumber)
  if (present(atomNumber)) call netcdf_GetDimension(ncid, "atom", atomNumber)
  if (present(coorVID)) call netcdf_warningmsg(nf90_inq_varid(ncid, "coordinates", coorVID), "Inquiring coorVID")
  if (present(velocityVID)) call netcdf_warningmsg(nf90_inq_varid(ncid, "velocities", velocityVID), "Inquiring velocityVID")

  call netcdf_GetDimension(ncid, "spatial", spatial)
  if (spatial .ne. 3) write (*, *) "Netcdf Warning: spatial in Netcdf is not 3"

  if (present(cellLengthVID)) then
     iostat = nf90_inq_varid(ncid, "cell_lengths", cellLengthVID)
     if (iostat == nf90_enotvar) then
        cellLengthVID = -1
     else
        call netcdf_warningmsg(iostat, "Inquiring cellLengthVID")
     end if
  end if
  if (present(cellAngleVID)) then
     iostat = nf90_inq_varid(ncid, "cell_angles", cellAngleVID)
     if (iostat /= nf90_enotvar) call netcdf_warningmsg(iostat, "Inquiring cellLengthVID")
  end if

  if (present(timeVID)) call netcdf_warningmsg(nf90_inq_varid(ncid, "time", timeVID), "Inquiring timeVID")
  ! if (present(TempVID)) call netcdf_warningmsg(nf90_inq_varid(ncid,"remd_values",TempVID), "Inquiring TempVID")
end subroutine

subroutine netcdf_FinishWriting(ncid)
  integer :: ncid
  call netcdf_warningmsg(nf90_sync(ncid), "Syncing.")
end subroutine

subroutine netcdf_CloseFile(ncid)
  integer :: ncid
  call netcdf_warningmsg(nf90_close(ncid), "Closing Netcdf File")
end subroutine

subroutine netcdf_GetNetcdfInfo(files, numFile, hasBox, numFrame, atomNumber, skipinitdata, skipdata, timestep)
  character(*), intent(in) :: files(:)
  integer, intent(in) :: numFile
  logical, intent(out), optional :: hasBox
  integer, intent(out), optional :: numFrame, atomNumber
  integer,intent(in),optional :: skipdata,skipinitdata
  real*8,optional :: timestep
  integer :: i, temp, ncid, cellLengthVID, cellAngleVID, timeVID, frameNumber, atomnum

  frameNumber = 0
  do i = 1, numFile
     call checkfile(files(i))
     call netcdf_OpenFile(files(i), ncid=ncid, frameNumber=temp, atomNumber=atomnum, &
                         cellLengthVID=cellLengthVID, cellAngleVID=cellAngleVID, timeVID=timeVID)

     if ( present(timestep) ) call netcdf_ReadVariables(ncid, timeVID, timestep, 1, "time step")
     if ( present(skipinitdata) ) temp = temp - skipinitdata
     if ( present(skipdata) ) temp = temp/(skipdata+1)
     frameNumber = frameNumber + temp

     if (cellLengthVID == -1) then
        if(present(hasBox)) hasBox = .false.
     else
        if(present(hasBox)) hasBox = .true.
        call netcdf_ReadVariables(ncid, cellLengthVID, length, 1, "cell Length")
        call netcdf_ReadVariables(ncid, cellAngleVID, angle, 1, "cell Angle")
     end if
     call netcdf_CloseFile(ncid)
  end do
  if(present(numFrame)) numFrame = frameNumber
  if(present(atomNumber)) atomNumber = atomnum
end subroutine

subroutine netcdf_ReadCoordinate(datafile, num_file, traj, stride, skipinitdata, selectedatoms)
  integer, intent(in) :: num_file
  integer, intent(in) :: stride
  character(*), intent(in) :: datafile(num_file)
  real*8, intent(out) :: traj(:, :)
  integer, intent(in), optional :: skipinitdata
  integer, intent(in), optional :: selectedatoms(:)

  real*8, allocatable :: coor(:, :)
  integer :: frame_number_per_file(num_file)
  integer :: i, j, k, m, ncid, coorVID, cellLengthVID, cellAngleVID, iatom
  integer ::  cur_index, total_frame, atomNumber, tempFrameNumber

  cur_index = 0
  total_frame = 0

  do i = 1, num_file
     call netcdf_GetNetcdfInfo((/datafile(i)/), 1, numFrame=tempFrameNumber, atomNumber=atomNumber)
     frame_number_per_file(i) = tempFrameNumber
     if ( present(skipinitdata) ) tempFrameNumber=tempFrameNumber - skipinitdata
     total_frame = total_frame + tempFrameNumber/stride
  end do
  if ( total_frame > size(traj,2) ) total_frame = size(traj,2)

  write (*, "(A, I7)") "Number of trajectory frames: ", total_frame
  if ( present(selectedatoms) ) then
     write (*, "(A, I7)") "Number of degree: ", size(selectedatoms)*3
  else
     write (*, "(A, I7)") "Number of degree: ", atomNumber*3
  end if
  allocate (coor(3, atomNumber))

  do i = 1, num_file
     call netcdf_OpenFile(datafile(i), ncid, coorVID=coorVID, cellLengthVID=cellLengthVID, cellAngleVID=cellAngleVID)
     k=1; if ( present(skipinitdata) ) k=k+skipinitdata
     do j = k, frame_number_per_file(i)
        cur_index = cur_index + 1
        if (mod(cur_index, stride) == 0) then
           call netcdf_ReadVariables(ncid, coorVID, coor, j)
           if ( cur_index/stride > total_frame ) exit
           if ( present(selectedatoms) ) then
              do m = 1, size(selectedatoms)
                 iatom = selectedatoms(m)
                 traj(3*m-2:3*m,cur_index/stride) = coor(:,iatom)
              end do
           else
              traj(:, cur_index/stride) = pack(coor, .true.)
           end if
        end if
     end do
     if ( cur_index/stride > total_frame ) exit
     write (*, "(a)") "finished reading file  "//trim(datafile(i))
  end do
  deallocate (coor)
end subroutine

! Write cell length and angle
subroutine netcdf_WriteCell(ncid, cellLengthVID, cellAngleVID, frame)
  integer, intent(in) :: ncid, cellLengthVID, cellAngleVID, frame

  call netcdf_WriteVariables(ncid, cellLengthVID, length, frame, "cell Length")
  call netcdf_WriteVariables(ncid, cellAngleVID, angle, frame, "cell Angle")
end subroutine

subroutine netcdf_ReadVariable(ncid, tpvarid, tpvar, frame, location)
  integer, intent(in) :: ncid, tpvarid
  integer, intent(in),optional :: frame
  real*8, intent(out) :: tpvar
  character(len=*), optional, intent(in) :: location
  integer :: tpframe

  tpframe = 1; if ( present(frame) ) tpframe = frame
  call netcdf_warningmsg(nf90_get_var(ncid, tpvarid, tpvar, start=(/tpframe/)), &
                        "Reading Variable "//trim(location))
end subroutine

subroutine netcdf_ReadVariables1D(ncid, tpvarid, tpvar, frame, location)
  integer, intent(in) :: ncid, tpvarid
  integer, intent(in),optional :: frame
  real*8, dimension(:), intent(out) :: tpvar
  character(len=*), optional, intent(in) :: location
  integer :: tpframe

  tpframe = 1; if ( present(frame) ) tpframe = frame
  call netcdf_warningmsg(nf90_get_var(ncid, tpvarid, tpvar, start=(/1, tpframe/)), &
                        "Reading Variables "//trim(location))
end subroutine

subroutine netcdf_ReadVariables2D(ncid, tpvarid, tpvar, frame, location)
  integer, intent(in) :: ncid, tpvarid
  integer, intent(in), optional :: frame
  real*8, dimension(:, :), intent(out) :: tpvar
  character(len=*), optional, intent(in) :: location
  integer :: tpframe

  tpframe = 1; if ( present(frame) ) tpframe = frame
  call netcdf_warningmsg(nf90_get_var(ncid, tpvarid, tpvar, start=(/1, 1, tpframe/)), &
                        "Reading Variables "//trim(location))
end subroutine

subroutine netcdf_WriteVariable(ncid, tpvarid, tpvar, frame, location)
  integer, intent(in) :: ncid, tpvarid
  integer, intent(in), optional :: frame
  real*8, intent(in):: tpvar
  character(len=*), optional, intent(in) :: location
  integer :: tpframe

  tpframe = 1; if ( present(frame) ) tpframe = frame
  call netcdf_warningmsg(nf90_put_var(ncid, tpvarid, tpvar, start=(/tpframe/)), &
                        "Writing Variable "//trim(location))
end subroutine

subroutine netcdf_WriteVariables1D(ncid, tpvarid, tpvar, frame, location)
  integer, intent(in) :: ncid, tpvarid
  integer, intent(in),optional :: frame
  real*8, dimension(:), intent(out) :: tpvar
  character(len=*), optional, intent(in) :: location
  integer :: tpframe

  tpframe = 1; if ( present(frame) ) tpframe = frame
  call netcdf_warningmsg(nf90_put_var(ncid, tpvarid, tpvar, start=(/1, tpframe/)), &
                        "Writing Variables "//trim(location))
end subroutine

subroutine netcdf_WriteVariables2D(ncid, tpvarid, tpvar, frame, location)
  integer, intent(in) :: ncid, tpvarid
  integer, intent(in), optional :: frame
  real*8, dimension(:, :), intent(in):: tpvar
  character(len=*), optional, intent(in) :: location
  integer :: tpframe

  tpframe = 1; if ( present(frame) ) tpframe = frame
  call netcdf_warningmsg(nf90_put_var(ncid, tpvarid, tpvar, start=(/1, 1, tpframe/)), &
                        "Writing Variables "//trim(location))
end subroutine

subroutine netcdf_GetDimension(ncid, tpname, tplen)
  integer, intent(in) :: ncid
  character(len=*), intent(in) :: tpname
  integer, intent(out) :: tplen
  integer :: tpdimid

  call netcdf_warningmsg(nf90_inq_dimid(ncid, tpname, tpdimid), "Inquiring "//trim(tpname)//" dimID.")
  call netcdf_warningmsg(nf90_inquire_dimension(ncid, tpdimid, len=tplen), "Getting "//trim(tpname)//" dimensions.")
end subroutine

subroutine netcdf_warningmsg(ncerr, location)
  implicit none
  integer, intent(in) :: ncerr
  character(len=*), optional, intent(in) :: location

  if (ifprintNetcdferror .and. (ncerr .ne. nf90_noerr)) then
     write (*, *) "Warning: ", trim(nf90_strerror(ncerr)), ncerr
     if (present(location)) write (*, *) " at ", location
  end if
end subroutine

function netcdf_format(filename)
  character(len=*), intent(in) :: filename
  logical :: netcdf_format
  integer :: istat, ncid
  logical :: ifexist

  netcdf_format = .false.
  inquire(file=filename, exist=ifexist)
  if (ifexist .eq. .True.) then
     istat = nf90_open(filename, NF90_NOWRITE, ncid)
     if (istat == 0) then
        netcdf_format = .true.
     else if (istat == -51) then     ! not a standard netcdf file
        netcdf_format = .false.
     else
        call netcdf_warningmsg(istat,"netcdf_format")
     endif
     istat = nf90_close(ncid)
  ! else
     ! print*, "Warning: File ", trim(filename), " does not exist!"
  endif
  return
end function netcdf_format

subroutine netcdf_read_traj(tpfilename,tptotatomnum,tpcoor,status,tpcellLength,tpcellAngle,frame)
  character(len=*), intent(in) :: tpfilename
  integer, intent(in) :: tptotatomnum
  integer, intent(out) :: status
  real*8, intent(out) :: tpcoor(3,tptotatomnum)
  real*8,intent(out),optional :: tpcellLength(3),tpcellAngle(3)
  integer, intent(in), optional :: frame
  integer, save :: coorid, ncid, tpframe, nframe, cellLengthVID, cellAngleVID
  character*150, save :: prefilename
  integer :: tpnatom
  real*8 :: cellLength(3),cellAngle(3)
  logical :: ifexist

  if ( trim(tpfilename) /= trim(prefilename) ) then
     if ( ncid > 0 ) then
        call netcdf_CloseFile(ncid); ncid=0
     end if
     prefilename=trim(tpfilename)
     inquire(file=tpfilename,exist=ifexist); if ( ifexist .eqv. .false. ) return
     call netcdf_OpenFile(tpfilename, ncid, coorVID=coorid, frameNumber=nframe, atomNumber=tpnatom, &
                      cellLengthVID=cellLengthVID, cellAngleVID=cellAngleVID)
     tpcoor = 0d0; tpframe = 0
     if ( tpnatom /= tptotatomnum ) then 
        print "(a,2i8)","inconsistent atom number. ",tpnatom,tptotatomnum
     end if
  end if

  tpframe = tpframe + 1; status = 0
  if (present(frame)) tpframe = frame
  if ( tpframe > nframe) then
     status = -1; return
  end if
  call netcdf_ReadVariables(ncid, coorid, tpcoor, tpframe)

  if ( cellAngleVID > 0 ) then
     call netcdf_ReadVariables(ncid, cellLengthVID, cellLength,tpframe)
     call netcdf_ReadVariables(ncid, cellAngleVID, cellAngle,tpframe)
  end if
  if ( present(tpcellLength) ) tpcellLength=cellLength
  if ( present(tpcellAngle) ) tpcellAngle=cellAngle
end subroutine netcdf_read_traj

subroutine netcdf_read_multitraj(tpfilename,tptotatomnum,tpcoor,status,frame)
  character(len=*), intent(in) :: tpfilename(:)
  integer, intent(in) :: tptotatomnum
  integer, intent(out) :: status
  real*8, intent(out) :: tpcoor(3,tptotatomnum,size(tpfilename))
  integer,intent(in),optional :: frame
  integer,dimension(:),allocatable,save :: coorid, ncid, nframe, tpnatom
  integer, save :: tpframe
  character*150,dimension(:),allocatable,save :: prefilename
  integer :: ifile
  logical :: ifexist,ifopennew

  ifopennew = .false.
  if ( .not. allocated(prefilename) ) then
     ifopennew=.true.
  else
     if ( trim(tpfilename(1)) /= trim(prefilename(1)) ) ifopennew=.true.
  end if

  if ( ifopennew .eqv. .true. ) then
     if ( allocated(prefilename) ) then
        do ifile = 1, size(prefilename)
           if ( ncid(ifile) > 0 )  call netcdf_CloseFile(ncid(ifile))
        end do
        deallocate(prefilename,coorid,ncid,nframe,tpnatom)
     end if

     allocate(prefilename(size(tpfilename)),coorid(size(tpfilename)),ncid(size(tpfilename)),nframe(size(tpfilename)),tpnatom(size(tpfilename)))
     tpcoor = 0d0; tpframe = 0; prefilename = tpfilename
     do ifile = 1, size(tpfilename)
        inquire(file=tpfilename(ifile),exist=ifexist)
        if ( ifexist .eqv. .false. ) return
        call netcdf_OpenFile(tpfilename(ifile), ncid(ifile), coorVID=coorid(ifile),frameNumber=nframe(ifile),atomNumber=tpnatom(ifile))
     end do
  end if

  tpframe = tpframe + 1; status = 0
  if (present(frame)) tpframe = frame
  if ( any(tpframe > nframe(1:size(tpfilename))) ) then
     status = -1; return
  end if

  do ifile = 1, size(tpfilename)
     if ( tptotatomnum > tpnatom(ifile) ) then
        call netcdf_ReadVariables(ncid(ifile), coorid(ifile), tpcoor(1:3,1:tpnatom(ifile),ifile), tpframe)
     else
        call netcdf_ReadVariables(ncid(ifile), coorid(ifile), tpcoor(1:3,1:tptotatomnum,ifile), tpframe)
     end if
  end do
end subroutine

end module
