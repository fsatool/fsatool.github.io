module mlp0
  use curand_device
  use deeppub
  implicit none

  type :: mlptype
 
    integer :: id,batchsize
    logical :: ifbias,iflayernorm,ifbatchnorm
    type(mlplayer),dimension(maxnlayer),private :: mlplayers
    integer,private :: iflastactivation
    real*8,allocatable,dimension(:),private :: outputweight,batchnormmean,batchnormsqerror
    real*8,private :: batchnormfactor
    integer,private :: nlayer,noutput,ninput,ifclasses
  
    ! for gpu
    integer,dimension(:),allocatable :: hiddenstate_index
    integer,dimension(:),allocatable,private :: weights_l2l_index
    integer,dimension(:),allocatable,private :: weights_t2t_index
    integer,dimension(:),allocatable,private :: bias_index,grad_active_index,delta_layer_index
  
  end type

  integer,parameter :: MD = 6

  integer,private :: mlpnum = 0,tot_hiddenstate_index,tot_grad_active_index
  integer,private :: tot_layernorminout_index,tot_layernormmeansigma_index
  integer,private :: tot_weights_l2l_index,tot_bias_index
  integer,device,private :: tot_weights_l2l_index_d,tot_bias_index_d,jobtype_d
  integer,device,private :: tot_hiddenstate_index_d,tot_grad_active_index_d,tot_layernorminout_index_d,tot_layernormmeansigma_index_d

  integer,allocatable :: net_layernorminout_index(:),net_layernormmeansigma_index(:),net_grad_active_index(:),net_hiddenstate_index(:),net_delta_layer_index(:),net_mlplayers_index(:)

  integer,allocatable,dimension(:) :: net_batchsize,net_ninputgroup,net_ninputgroupstep,net_noutputgroup,net_noutputgroupstep,net_net_hiddenstate_index,net_net_grad_active_index

  integer,device,private :: mlpnum_d = 0
  type netinfotype
    integer :: batchsize_d,nlayer_d,ninput_d,noutput_d,ninputgroupstep_d,ninputgroup_d,noutputgroupstep_d,noutputgroup_d
    integer :: mlplayers_index_d, hiddenstate_index_d, delta_layer_index_d
    integer,private :: weights_l2l_index_d, weights_t2t_index_d, bias_index_d, grad_active_index_d
    integer,private :: ifbias_d,iflastactivation_d,iflayernorm_d
  end type

  type(netinfotype),allocatable,device :: net(:)

  type(curandStatePhilox4_32_10),device,allocatable,private,target :: curandState_d(:)

  integer,device,dimension(:),allocatable,private :: mlplayers_d
  integer,device,dimension(:),allocatable,target :: hiddenstate_index_d
  real(kind=SD),device,dimension(:),allocatable :: hiddenstate_d
  integer,device,dimension(:),allocatable,private :: delta_layer_index_d
  integer,device,dimension(:),allocatable,private :: weights_l2l_index_d
  real(kind=SD),device,dimension(:),allocatable,target :: weights_l2l_d,grad_weights_l2l_d,gradg_weights_l2l_d,gradgsq_weights_l2l_d
  integer,device,dimension(:),allocatable,private :: weights_t2t_index_d
  real(kind=SD),device,dimension(:),allocatable,private :: weights_t2t_d, grad_weights_t2t_d,gradg_weights_t2t_d, gradgsq_weights_t2t_d
  integer,device,dimension(:),allocatable,private :: bias_index_d
  real(kind=SD),device,dimension(:),allocatable,private,target :: bias_d,gradg_bias_d,gradgsq_bias_d,grad_bias_d
  integer,device,dimension(:),allocatable,private :: grad_active_index_d
  real(kind=SD),device,dimension(:),allocatable,private :: grad_active_d

  integer,device,dimension(:),allocatable,private :: layernorminout_index_d,layernormmeansigma_index_d
  real(kind=SD),device,dimension(:),allocatable,private :: layernorminout_d,layernormmeansigma_d
  real(kind=SD),device,dimension(:),allocatable,private :: layernormweightbias_d,grad_layernormweightbias_d,gradg_layernormweightbias_d,gradgsq_layernormweightbias_d

contains

subroutine mlp0_getweight(this,ilayer,i,j,w,gradw)
   class(mlptype), intent(in) :: this
   integer,intent(in) :: ilayer,i,j
   real*8,intent(out) :: w
   real*8,intent(out),optional :: gradw

   w = this%mlplayers(ilayer)%weights_l2l(i,j)
   if (present(gradw)) then
      gradw = this%mlplayers(ilayer)%grad_weights_l2l(i,j)
   end if
end subroutine

subroutine mlp0_setweight(this,ilayer,i,j,w)
   class(mlptype), intent(inout) :: this
   integer,intent(in) :: ilayer,i,j
   real*8,intent(in) :: w
   this%mlplayers(ilayer)%weights_l2l(i,j) = w
end subroutine

subroutine mlp0_getbias(this,ilayer,i,bias,gradbias)
   class(mlptype), intent(inout) :: this
   integer,intent(in) :: ilayer,i
   real*8,intent(out) :: bias
   real*8,intent(out),optional :: gradbias
   bias = this%mlplayers(ilayer)%bias(i)
   if (present(gradbias)) then
      gradbias = this%mlplayers(ilayer)%grad_bias(i)
   end if
end subroutine

subroutine mlp0_setbias(this,ilayer,i,bias)
   class(mlptype), intent(inout) :: this
   integer,intent(in) :: ilayer,i
   real*8,intent(in) :: bias
   this%mlplayers(ilayer)%bias(i) = bias
end subroutine

subroutine mlp0_getlayerinfo(this,tpnlayer,tplayers)
   class(mlptype), intent(inout) :: this
   integer,intent(out) :: tpnlayer
   integer,intent(out),allocatable :: tplayers(:)
   integer :: ilayer

   tpnlayer = this%nlayer
   allocate(tplayers(this%nlayer)); tplayers = 0
   do ilayer = 1, this%nlayer
      tplayers(ilayer) = this%mlplayers(ilayer)%neurons
   end do
end subroutine

subroutine mlp0_get_layernorm_weightbias(this,ilayer,layerweight,layerbias,gradlayerweight,gradlayerbias)
   class(mlptype), intent(inout) :: this
   integer,intent(in) :: ilayer
   real*8,intent(out) :: layerweight,layerbias
   real*8,intent(out),optional :: gradlayerweight,gradlayerbias
  
   layerweight = this%mlplayers(ilayer)%layerweight
   layerbias = this%mlplayers(ilayer)%layerbias
   if (present(gradlayerweight)) then
      gradlayerweight = this%mlplayers(ilayer)%grad_layerweight
   end if
   if (present(gradlayerbias)) then
      gradlayerbias = this%mlplayers(ilayer)%grad_layerbias
   end if
end subroutine

subroutine mlp0_set_layernorm_weightbias(this,ilayer,layerweight,layerbias)
   class(mlptype), intent(inout) :: this
   integer,intent(in) :: ilayer
   real*8,intent(in) :: layerweight,layerbias

   this%mlplayers(ilayer)%layerweight = layerweight
   this%mlplayers(ilayer)%layerbias = layerbias
end subroutine

subroutine mlp0_initialize(this,layers,totparms,tpoutputweight,tpifbatchnorm,tpiflastactivation,tpifbias,tpiflayernorm,tpifembedding)
  class(mlptype), intent(inout) :: this
  integer,intent(in) :: layers(:)
  integer,intent(inout) :: totparms
  real*8,intent(in),optional :: tpoutputweight(:)
  logical,intent(in),optional :: tpifbatchnorm,tpiflastactivation,tpifbias,tpiflayernorm,tpifembedding
  integer :: iweightl2l,iweightt2t,ibias,ilayer,istate,ideltalayer,iactive,i,j,k
  integer :: recstart,recend,cheight,cwidth
  real*8 :: rand
  real(kind=SD),device,allocatable :: c_d(:)
  real(kind=SD),device,pointer :: tparray1_d(:), tparray2_d(:), tparray3_d(:)

  mlpnum = mlpnum + 1; this%id = mlpnum

  this%ninput = layers(1)
  do ilayer=size(layers),1,-1; if ( layers(ilayer) /= 0 ) exit; end do
  this%nlayer = ilayer
  this%noutput = layers(this%nlayer)

  this%ifbias = .true.; if ( present(tpifbias) ) this%ifbias = tpifbias
  this%iflayernorm = .false.; if ( present(tpiflayernorm) ) this%iflayernorm = tpiflayernorm

  if ( present(tpoutputweight) ) then
     allocate(this%outputweight(this%noutput)); this%outputweight = tpoutputweight
  end if

  this%iflastactivation = .false.
  if ( present(tpiflastactivation) ) this%iflastactivation = tpiflastactivation
  iweightl2l = 0; iweightt2t = 0; ibias = 0
  do ilayer=1, this%nlayer

     this%mlplayers(ilayer)%neurons = layers(ilayer) 

     allocate(this%mlplayers(ilayer)%hiddenstate(layers(ilayer),batchsize,maxnsteps,netnum))
     this%mlplayers(ilayer)%hiddenstate(:,:,:,:) = 0d0
     if ( this%ifclasses == 1 .and. ilayer == this%nlayer ) then
        allocate(this%mlplayers(ilayer)%softmaxstate(layers(ilayer),batchsize,maxnsteps,netnum))
        this%mlplayers(ilayer)%softmaxstate(:,:,:,:) = 0d0
     end if

     allocate(this%mlplayers(ilayer)%delta_layer(layers(ilayer))); this%mlplayers(ilayer)%delta_layer = 0d0

     if ( (this%iflayernorm .eqv. .true.) .and. (ilayer < this%nlayer) ) then
        allocate(this%mlplayers(ilayer)%layernormin(layers(ilayer),batchsize,1,netnum))
        allocate(this%mlplayers(ilayer)%layernormout(layers(ilayer),batchsize,1,netnum))
        allocate(this%mlplayers(ilayer)%layermean(batchsize,1,netnum))
        this%mlplayers(ilayer)%layermean = 1d0
        allocate(this%mlplayers(ilayer)%layersigma(batchsize,1,netnum))
        this%mlplayers(ilayer)%layersigma = 0d0
 
        this%mlplayers(ilayer)%grad_layerweight = 0d0
        this%mlplayers(ilayer)%grad_layerbias = 0d0
 
!        if ( jobtype == TRAIN .or. jobtype == STREAM ) then
           this%mlplayers(ilayer)%layerweight = 1.0d0
           this%mlplayers(ilayer)%layerbias = 0.0d0
!           call random_number(rand); this%mlplayers(ilayer)%layerweight = rand
!           call random_number(rand); this%mlplayers(ilayer)%layerbias = rand
!        end if
     end if
 
     if ( ilayer == 1 ) cycle

     iweightl2l = iweightl2l + layers(ilayer)*layers(ilayer-1)
     allocate(this%mlplayers(ilayer)%weights_l2l(layers(ilayer),layers(ilayer-1)))
     totparms = totparms + layers(ilayer)*layers(ilayer-1)
     if ( jobtype == TRAIN .or. jobtype == STREAM ) then
        if (present(tpifembedding)) then
           if (tpifembedding) then
              call deeppub_normaldata_2d(this%mlplayers(ilayer)%weights_l2l, 0d0, 1d0)
           else
              call deeppub_uniformdata_2d(this%mlplayers(ilayer)%weights_l2l, -sqrt(3d0/dble(layers(ilayer-1))), sqrt(3d0/dble(layers(ilayer-1))))
           end if
        else
           call deeppub_uniformdata_2d(this%mlplayers(ilayer)%weights_l2l, -sqrt(3d0/dble(layers(ilayer-1))), sqrt(3d0/dble(layers(ilayer-1))))
        end if
     end if
     allocate(this%mlplayers(ilayer)%grad_weights_l2l(layers(ilayer),layers(ilayer-1)))
     this%mlplayers(ilayer)%grad_weights_l2l = 0d0
     if ( ioptmethod == 2 ) then
        allocate(this%mlplayers(ilayer)%gradg_weights_l2l(layers(ilayer),layers(ilayer-1)))
        this%mlplayers(ilayer)%gradg_weights_l2l=0.0d0
        allocate(this%mlplayers(ilayer)%gradgsq_weights_l2l(layers(ilayer),layers(ilayer-1)))
        this%mlplayers(ilayer)%gradgsq_weights_l2l=0.0d0
     end if

     if ( this%ifbias .eqv. .true. ) then
        ibias = ibias + layers(ilayer)
        allocate(this%mlplayers(ilayer)%bias(layers(ilayer)))
        totparms = totparms + layers(ilayer)
        if ( jobtype == TRAIN .or. jobtype == STREAM ) then
           this%mlplayers(ilayer)%bias = 0d0
        end if
        allocate(this%mlplayers(ilayer)%grad_bias(layers(ilayer))); this%mlplayers(ilayer)%grad_bias = 0d0
        if ( ioptmethod == 2 ) then
           allocate(this%mlplayers(ilayer)%gradg_bias(layers(ilayer)))
           this%mlplayers(ilayer)%gradg_bias=0.0d0
           allocate(this%mlplayers(ilayer)%gradgsq_bias(layers(ilayer)))
           this%mlplayers(ilayer)%gradgsq_bias=0.0d0
        end if
     end if

     if ( maxnsteps > 1 ) then
        iweightt2t = iweightt2t + layers(ilayer)*layers(ilayer)
        allocate(this%mlplayers(ilayer)%weights_t2t(layers(ilayer),layers(ilayer)))
        totparms = totparms + layers(ilayer)*layers(ilayer)
        if ( jobtype == TRAIN .or. jobtype == STREAM ) then
           call deeppub_normaldata_2d(this%mlplayers(ilayer)%weights_t2t, 0d0, 1d0)
           this%mlplayers(ilayer)%weights_t2t = this%mlplayers(ilayer)%weights_t2t*0.1d0
        end if
        allocate(this%mlplayers(ilayer)%grad_weights_t2t(layers(ilayer),layers(ilayer)))
        this%mlplayers(ilayer)%grad_weights_t2t = 0d0
     end if

     if ( ilayer < this%nlayer ) then

        allocate(this%mlplayers(ilayer)%grad_active(layers(ilayer),batchsize,maxnsteps,netnum))
        this%mlplayers(ilayer)%grad_active = 1d0

     else 

        if ( this%iflastactivation == .true. ) then
           allocate(this%mlplayers(ilayer)%grad_active(layers(ilayer),batchsize,maxnsteps,netnum))
           this%mlplayers(ilayer)%grad_active = 1d0
        end if

    end if

  end do

  this%ifbatchnorm = .false.; this%batchnormfactor = 1d0
  if ( present(tpifbatchnorm) ) then
     this%ifbatchnorm = tpifbatchnorm
     if ( this%ifbatchnorm .eqv. .true. ) then
        allocate(this%batchnormmean(this%ninput)); this%batchnormmean = 0d0
        allocate(this%batchnormsqerror(this%ninput)); this%batchnormsqerror = 0d0
     end if
  end if

  if ( icudagroup > 0 ) then
     jobtype_d = jobtype

     iweightl2l = 0; iweightt2t = 0; ibias = 0
     do ilayer=1, this%nlayer
        if ( ilayer == 1 ) cycle
        iweightl2l = iweightl2l + layers(ilayer)*layers(ilayer-1)
        if ( this%ifbias .eqv. .true. ) ibias = ibias + layers(ilayer)
        if ( maxnsteps > 1 ) iweightt2t = iweightt2t + layers(ilayer)*layers(ilayer)
     end do

     istate = 0; ideltalayer = 0; iactive = 0
     do ilayer=1, this%nlayer
        ideltalayer = ideltalayer + layers(ilayer)*icudagroup*maxnsteps*netnum
        istate = istate + layers(ilayer)*icudagroup*maxnsteps*netnum
        if ( ilayer == 1 ) cycle
        if ( ilayer < this%nlayer ) then
           iactive = iactive + layers(ilayer)*icudagroup*maxnsteps*netnum
        end if
     end do
  
     allocate(this%weights_l2l_index(this%nlayer+1)); this%weights_l2l_index = 0
  
     if ( maxnsteps > 1 ) then
        allocate(this%weights_t2t_index(this%nlayer+1)); this%weights_t2t_index = 0
     end if
   
     if ( this%ifbias .eqv. .true.) then
        allocate(this%bias_index(this%nlayer+1)); this%bias_index = 0
     end if
     allocate(this%grad_active_index(this%nlayer+1)); this%grad_active_index = 0
     allocate(this%hiddenstate_index(this%nlayer+1)); this%hiddenstate_index = 0
     allocate(this%delta_layer_index(this%nlayer+1)); this%delta_layer_index = 0
     iweightl2l = 0; iweightt2t = 0; istate = 0; ibias = 0; iactive = 0; ideltalayer = 0

     do ilayer=1, this%nlayer
   
        ideltalayer = ideltalayer + layers(ilayer)*icudagroup*maxnsteps*netnum
        this%delta_layer_index(ilayer+1) = ideltalayer
   
        istate = istate + layers(ilayer)*icudagroup*maxnsteps*netnum
        this%hiddenstate_index(ilayer+1) = istate
   
        if ( ilayer == 1 ) cycle
   
        iweightl2l = iweightl2l + layers(ilayer)*layers(ilayer-1)
        this%weights_l2l_index(ilayer+1) = iweightl2l
 
        if ( this%ifbias .eqv. .true. ) then
           ibias = ibias + layers(ilayer)
           this%bias_index(ilayer+1) = ibias
        end if

        if ( maxnsteps > 1 ) then
           iweightt2t = iweightt2t + layers(ilayer)*layers(ilayer)
           this%weights_t2t_index(ilayer+1) = iweightt2t
        end if

        if ( ilayer < this%nlayer ) then
           iactive = iactive + layers(ilayer)*icudagroup*maxnsteps*netnum
        else
           if ( this%iflastactivation == .true. ) then
              iactive = iactive + layers(ilayer)*icudagroup*maxnsteps*netnum
           end if
        end if
        this%grad_active_index(ilayer+1) = iactive
     end do
 
  end if

end subroutine

subroutine mlp0_initialize_cuda(tpnets)
  class(mlptype), intent(in) :: tpnets(:)
  integer :: inet,i,j,tpnlayer,ilen,istart,iend,ilayer,istart0
  integer :: tp_mlplayers_index, tp_hiddenstate_index, tp_delta_layer_index
  integer :: weights_l2l_index, weights_t2t_index, bias_index, tp_grad_active_index
  integer,allocatable :: tpintarray(:)
  real*8,allocatable :: tprealarray(:)

  if ( mlpnum /= size(tpnets) ) stop "incorrect mlpnum!"
  mlpnum_d = mlpnum; allocate(net(mlpnum+1))

  tp_mlplayers_index = 0; tp_hiddenstate_index = 0; tp_delta_layer_index = 0
  weights_l2l_index = 0; weights_t2t_index = 0; bias_index = 0; tp_grad_active_index = 0
  allocate(net_mlplayers_index(mlpnum+1)); net_mlplayers_index = 0
  allocate(net_batchsize(mlpnum),net_ninputgroup(mlpnum),net_ninputgroupstep(mlpnum),net_noutputgroup(mlpnum),net_noutputgroupstep(mlpnum))
  net_batchsize = 0; net_ninputgroup = 0; net_ninputgroupstep = 0; net_noutputgroup = 0; net_noutputgroupstep = 0
  allocate(net_net_hiddenstate_index(mlpnum+1),net_net_grad_active_index(mlpnum+1))
  net_net_hiddenstate_index = 0; net_net_grad_active_index = 0

  do inet = 1, mlpnum

     net(inet)%iflastactivation_d = tpnets(inet)%iflastactivation
     net(inet)%nlayer_d = tpnets(inet)%nlayer
     net(inet)%ninput_d = tpnets(inet)%ninput
     net(inet)%noutput_d = tpnets(inet)%noutput

     net(inet)%ninputgroup_d = tpnets(inet)%ninput*icudagroup
     net(inet)%ninputgroupstep_d = tpnets(inet)%ninput*icudagroup*maxnsteps
     net(inet)%noutputgroup_d = tpnets(inet)%noutput*icudagroup
     net(inet)%noutputgroupstep_d = tpnets(inet)%noutput*icudagroup*maxnsteps

     tpnlayer = tpnets(inet)%nlayer
     tp_mlplayers_index = tp_mlplayers_index + tpnlayer 
     net(inet+1)%mlplayers_index_d = tp_mlplayers_index
     net_mlplayers_index(inet+1) = tp_mlplayers_index

     tp_hiddenstate_index = tp_hiddenstate_index + tpnets(inet)%hiddenstate_index(tpnlayer+1)
     net(inet+1)%hiddenstate_index_d = tp_hiddenstate_index

     net(inet)%iflayernorm_d = tpnets(inet)%iflayernorm
     net(inet)%ifbias_d = tpnets(inet)%ifbias
     if ( tpnets(inet)%ifbias .eqv. .true. ) then
        bias_index = bias_index + tpnets(inet)%bias_index(tpnlayer+1)
     end if
     net(inet+1)%bias_index_d = bias_index

     tp_delta_layer_index = tp_delta_layer_index + tpnets(inet)%delta_layer_index(tpnlayer+1)
     net(inet+1)%delta_layer_index_d = tp_delta_layer_index

     tp_grad_active_index = tp_grad_active_index + tpnets(inet)%grad_active_index(tpnlayer+1)
     net(inet+1)%grad_active_index_d = tp_grad_active_index

     weights_l2l_index = weights_l2l_index + tpnets(inet)%weights_l2l_index(tpnlayer+1)
     net(inet+1)%weights_l2l_index_d = weights_l2l_index 

     if ( maxnsteps > 1 ) then
        weights_t2t_index = weights_t2t_index + tpnets(inet)%weights_t2t_index(tpnlayer+1)
        net(inet+1)%weights_t2t_index_d = weights_t2t_index
     end if

  end do

  tot_weights_l2l_index = weights_l2l_index; tot_weights_l2l_index_d = tot_weights_l2l_index
  tot_bias_index = bias_index; tot_bias_index_d = tot_bias_index

  allocate(mlplayers_d(tp_mlplayers_index)); mlplayers_d = 0

  allocate(hiddenstate_index_d(tp_mlplayers_index+mlpnum)); hiddenstate_index_d = 0
  allocate(hiddenstate_d(tp_hiddenstate_index)); hiddenstate_d = 0.0_SD
  allocate(net_hiddenstate_index(tp_mlplayers_index+mlpnum)); net_hiddenstate_index = 0

  if ( bias_index > 0 ) then
     allocate(bias_index_d(tp_mlplayers_index+mlpnum)); bias_index_d = 0
     allocate(bias_d(bias_index),grad_bias_d(bias_index))
     bias_d = 0.0_SD; grad_bias_d = 0.0_SD
  end if

  allocate(delta_layer_index_d(tp_mlplayers_index+mlpnum)); delta_layer_index_d = 0
  allocate(net_delta_layer_index(tp_mlplayers_index+mlpnum)); net_delta_layer_index = 0

  allocate(grad_active_index_d(tp_mlplayers_index+mlpnum)); grad_active_index_d = 0
  allocate(net_grad_active_index(tp_mlplayers_index+mlpnum)); net_grad_active_index = 0
  if ( tp_grad_active_index > 0 ) then
     allocate(grad_active_d(tp_grad_active_index)); grad_active_d = 0.0_SD
     if ( dropout > 0.0d0 ) allocate(curandState_d(tp_grad_active_index))
  end if

  allocate(weights_l2l_index_d(tp_mlplayers_index+mlpnum)); weights_l2l_index_d = 0
  allocate(weights_l2l_d(weights_l2l_index), grad_weights_l2l_d(weights_l2l_index))
  weights_l2l_d = 0.0_SD; grad_weights_l2l_d = 0.0_SD

  if ( ioptmethod == 2 ) then
     allocate(gradg_weights_l2l_d(weights_l2l_index), gradgsq_weights_l2l_d(weights_l2l_index))
     gradg_weights_l2l_d = 0.0_SD; gradgsq_weights_l2l_d = 0.0_SD

     if ( bias_index > 0 ) then
        allocate(gradg_bias_d(bias_index), gradgsq_bias_d(bias_index))
        gradg_bias_d = 0.0_SD; gradgsq_bias_d = 0.0_SD
     end if
  end if

  if ( maxnsteps > 1 ) then
     allocate(weights_t2t_index_d(tp_mlplayers_index+mlpnum)); weights_t2t_index_d = 0
     allocate(weights_t2t_d(weights_t2t_index), grad_weights_t2t_d(weights_t2t_index))
     weights_t2t_d = 0.0_SD; grad_weights_t2t_d = 0.0_SD
  end if

  tp_mlplayers_index = 0; tp_hiddenstate_index = 0; tp_delta_layer_index = 0
  weights_l2l_index = 0; weights_t2t_index = 0; bias_index = 0; tp_grad_active_index = 0

  do inet = 1, mlpnum

     tpnlayer = tpnets(inet)%nlayer
     if (allocated(tprealarray)) deallocate(tprealarray)
     allocate(tprealarray(1)); tprealarray = 0.0_SD
     if (allocated(tpintarray)) deallocate(tpintarray)
     allocate(tpintarray(tpnlayer)); tpintarray(1:tpnlayer) = tpnets(inet)%mlplayers(1:tpnlayer)%neurons  
     i = net(inet)%mlplayers_index_d + 1; j = net(inet+1)%mlplayers_index_d
     mlplayers_d(i:j) = tpintarray(1:tpnlayer)
     tpintarray(1:tpnlayer) = mlplayers_d(i:j)
     call mlp0_check_intdata("layers ",tpintarray,tpnets(inet)%mlplayers(1:tpnlayer)%neurons)


     deallocate(tpintarray)
     allocate(tpintarray(tpnlayer+1)); tpintarray(:) = tpnets(inet)%hiddenstate_index(:)
     i = net(inet)%mlplayers_index_d + inet; j = net(inet+1)%mlplayers_index_d + inet
     hiddenstate_index_d(i:j) = tpintarray(1:tpnlayer+1)
     tpintarray(1:tpnlayer+1) = hiddenstate_index_d(i:j)
     call mlp0_check_intdata("hiddenstate_index ",tpintarray,tpnets(inet)%hiddenstate_index(:))

     if ( tpnets(inet)%ifbias .eqv. .true. ) then
        deallocate(tpintarray)
        allocate(tpintarray(tpnlayer+1)); tpintarray(:) = tpnets(inet)%bias_index(:)
        i = net(inet)%mlplayers_index_d + inet; j = net(inet+1)%mlplayers_index_d + inet
        bias_index_d(i:j) = tpintarray(:)
        tpintarray(1:tpnlayer+1) = bias_index_d(i:j)

        call mlp0_check_intdata("bias_index ",tpintarray,tpnets(inet)%bias_index(:))

        if ( (jobtype == TRAIN) .and. (ifproceed .eqv. .false.) ) then

           deallocate(tprealarray); ilen = tpnets(inet)%bias_index(tpnlayer+1)
           allocate(tprealarray(ilen)); tprealarray = 0.0_SD
           istart = net(inet)%bias_index_d
           iend = net(inet+1)%bias_index_d
           if ( istart+ilen /= iend ) stop "incorrect bias dim0"
           do ilayer = 1, tpnets(inet)%nlayer
              i = tpnets(inet)%bias_index(ilayer)+1
              j = tpnets(inet)%bias_index(ilayer+1)
              if ( j-i+1 /= size(tpnets(inet)%mlplayers(ilayer)%bias(:)) ) stop "incorrect bias dim1"
              if ( j < i ) cycle
              tprealarray(i:j) = tpnets(inet)%mlplayers(ilayer)%bias(:)
           end do
           bias_d(istart+1:iend) = tprealarray(:)
           istart0 = net(inet)%mlplayers_index_d + inet
           istart = net(inet)%bias_index_d

           do ilayer = 1, tpnets(inet)%nlayer
              i = bias_index_d(istart0+ilayer-1)+1
              j = bias_index_d(istart0+ilayer)
              if ( j < i ) cycle
              tprealarray(1:j-i+1) = bias_d(istart+i:istart+j)
              call mlp0_check_realdata("bias ",tprealarray(1:j-i+1),tpnets(inet)%mlplayers(ilayer)%bias(:))
           end do
        end if
     end if

     deallocate(tpintarray)
     allocate(tpintarray(tpnlayer+1)); tpintarray(:) = tpnets(inet)%delta_layer_index(:)
     i = net(inet)%mlplayers_index_d + inet; j = net(inet+1)%mlplayers_index_d + inet
     delta_layer_index_d(i:j) = tpintarray(:)
     tpintarray(1:tpnlayer+1) = delta_layer_index_d(i:j)

     call mlp0_check_intdata("delta_layer_index ",tpintarray,tpnets(inet)%delta_layer_index(:))

     deallocate(tpintarray)
     allocate(tpintarray(tpnlayer+1)); tpintarray(:) = tpnets(inet)%grad_active_index(:)
     i = net(inet)%mlplayers_index_d + inet; j = net(inet+1)%mlplayers_index_d + inet
     grad_active_index_d(i:j) = tpintarray(:)
     tpintarray(1:tpnlayer+1) = grad_active_index_d(i:j)
     call mlp0_check_intdata("grad_active_index ",tpintarray,tpnets(inet)%grad_active_index(:))

     deallocate(tpintarray)
     allocate(tpintarray(tpnlayer+1)); tpintarray(:) = tpnets(inet)%weights_l2l_index(:)
     i = net(inet)%mlplayers_index_d + inet; j = net(inet+1)%mlplayers_index_d + inet
     weights_l2l_index_d(i:j) = tpintarray(:)
     tpintarray(1:tpnlayer+1) = weights_l2l_index_d(i:j)
     call mlp0_check_intdata("weights_l2l_index ",tpintarray,tpnets(inet)%weights_l2l_index(:))

     deallocate(tprealarray); ilen = tpnets(inet)%weights_l2l_index(tpnlayer+1)
     allocate(tprealarray(ilen)); tprealarray = 0.0_SD
     istart = net(inet)%weights_l2l_index_d
     iend = net(inet+1)%weights_l2l_index_d
     if ( istart+ilen /= iend ) stop "incorrect weight l2l dim0"

     if ( (jobtype == TRAIN) .and. (ifproceed .eqv. .false.) ) then

        do ilayer = 1, tpnets(inet)%nlayer
           i = tpnets(inet)%weights_l2l_index(ilayer)+1
           j = tpnets(inet)%weights_l2l_index(ilayer+1)
           if ( j-i+1 /= size(tpnets(inet)%mlplayers(ilayer)%weights_l2l,1)*size(tpnets(inet)%mlplayers(ilayer)%weights_l2l,2) ) stop "incorrect weight l2l dim1"
           tprealarray(i:j) = pack(tpnets(inet)%mlplayers(ilayer)%weights_l2l,.true.)
        end do
        weights_l2l_d(istart+1:iend) = tprealarray(:)
        istart0 = net(inet)%mlplayers_index_d + inet
        istart = net(inet)%weights_l2l_index_d

        do ilayer = 1, tpnets(inet)%nlayer
           !i = tpnets(inet)%weights_l2l_index(ilayer)+1
           !j = tpnets(inet)%weights_l2l_index(ilayer+1)
           i = weights_l2l_index_d(istart0+ilayer-1)+1
           j = weights_l2l_index_d(istart0+ilayer)
           if ( j < i ) cycle
           tprealarray(1:j-i+1) = weights_l2l_d(istart+i:istart+j)
           call mlp0_check_realdata("weight ",tprealarray(1:j-i+1),pack(tpnets(inet)%mlplayers(ilayer)%weights_l2l,.true.))
        end do

     end if

     if ( maxnsteps > 1 ) then
        deallocate(tpintarray)
        allocate(tpintarray(tpnlayer+1)); tpintarray(:) = tpnets(inet)%weights_t2t_index(:)
        i = net(inet)%mlplayers_index_d + inet; j = net(inet+1)%mlplayers_index_d + inet
        weights_t2t_index_d(i:j) = tpintarray(:)

        if ( (jobtype == TRAIN) .and. (ifproceed .eqv. .false.) ) then

        deallocate(tprealarray); ilen = tpnets(inet)%weights_t2t_index(tpnlayer+1)
        allocate(tprealarray(ilen)); tprealarray = 0.0_SD
        istart = net(inet)%weights_t2t_index_d
        iend = net(inet+1)%weights_t2t_index_d
        if ( istart+ilen /= iend ) stop "incorrect weight l2l dim0"
        do ilayer = 1, tpnets(inet)%nlayer
           i = tpnets(inet)%weights_t2t_index(ilayer)+1
           j = tpnets(inet)%weights_t2t_index(ilayer+1)
           if ( j-i+1 /= size(tpnets(inet)%mlplayers(ilayer)%weights_t2t,1)*size(tpnets(inet)%mlplayers(ilayer)%weights_t2t,2) ) stop "incorrect weight l2l dim1"
           tprealarray(istart+i:istart+j) = pack(tpnets(inet)%mlplayers(ilayer)%weights_t2t,.true.)
        end do
        weights_t2t_d(istart+1:iend) = tprealarray(:)
        end if

     end if

  end do

  allocate(layernormweightbias_d(mlpnum*2),grad_layernormweightbias_d(mlpnum*2))
  do inet = 1, mlpnum
     layernormweightbias_d(2*inet-1:2*inet) = [1.0_SD, 0.0_SD]
  end do
  grad_layernormweightbias_d = 0.0_SD

  if ( ioptmethod == 2 ) then
     allocate(gradg_layernormweightbias_d(mlpnum*2),gradgsq_layernormweightbias_d(mlpnum*2))
     gradg_layernormweightbias_d = 0.0_SD; gradgsq_layernormweightbias_d = 0.0_SD
  end if

  allocate(layernormmeansigma_index_d(mlpnum+1),layernormmeansigma_d(1))
  layernormmeansigma_index_d = 0; layernormmeansigma_d = 0.0_SD

  allocate(layernorminout_index_d(mlpnum+1),layernorminout_d(1))
  layernorminout_index_d = 1; layernorminout_d = 0.0_SD

  allocate(net_layernorminout_index(mlpnum+1),net_layernormmeansigma_index(mlpnum+1))
  net_layernorminout_index = 0; net_layernormmeansigma_index = 0

contains

subroutine mlp0_check_intdata(tpstring,int1,int2)
  character(len=*) :: tpstring
  integer :: int1(:),int2(:),idata
  if ( size(int1) /= size(int2) ) stop "error "//tpstring
  do idata = 1, size(int1)
     if ( int1(idata) /= int2(idata) ) stop "error "//tpstring
  end do
end subroutine
subroutine mlp0_check_realdata(tpstring,real1,real2)
  character(len=*) :: tpstring
  integer :: idata
  real*8 :: real1(:),real2(:)
  if ( size(real1) /= size(real2) ) then
     print *,"error "//tpstring," diff size ",size(real1),size(real2)
     stop
  end if
  do idata = 1, size(real1)
     if ( abs(real1(idata) - real2(idata)) > 1d-6 ) then
        print *,"error "//tpstring," diff value ",idata,real1(idata),real2(idata)
        stop
     end if
  end do
end subroutine
 
end subroutine

subroutine mlp0_initialize_for_dynamic_batchsize(this,tpbatchsize)
  class(mlptype), intent(inout) :: this
  integer,intent(in) :: tpbatchsize
  integer,save :: inet=0
  integer :: i,j,ilayer,istate,iactive

  if ( icudagroup == 0 ) then

     this%batchsize = tpbatchsize; istate = 0; iactive = 0
     do ilayer=1, this%nlayer

        if ( icudagroup > 0 ) then 
           istate = istate + this%mlplayers(ilayer)%neurons*tpbatchsize
           this%hiddenstate_index(ilayer+1) = istate
           this%delta_layer_index(ilayer+1) = istate
        end if

        deallocate(this%mlplayers(ilayer)%hiddenstate)
        allocate(this%mlplayers(ilayer)%hiddenstate(this%mlplayers(ilayer)%neurons,tpbatchsize,maxnsteps,netnum))
        this%mlplayers(ilayer)%hiddenstate(:,:,:,:) = 0d0

        if ( ifclasses == 1 .and. ilayer == this%nlayer ) then
           deallocate(this%mlplayers(ilayer)%softmaxstate)
           allocate(this%mlplayers(ilayer)%softmaxstate(this%mlplayers(ilayer)%neurons,tpbatchsize,maxnsteps,netnum))
           this%mlplayers(ilayer)%softmaxstate(:,:,:,:) = 0d0
        end if

        if ( (this%iflayernorm .eqv. .true.) .and. (ilayer < this%nlayer) ) then
           deallocate(this%mlplayers(ilayer)%layernormin,this%mlplayers(ilayer)%layernormout,this%mlplayers(ilayer)%layermean,this%mlplayers(ilayer)%layersigma)
           allocate(this%mlplayers(ilayer)%layernormin(this%mlplayers(ilayer)%neurons,tpbatchsize,1,netnum))
           allocate(this%mlplayers(ilayer)%layernormout(this%mlplayers(ilayer)%neurons,tpbatchsize,1,netnum))
           allocate(this%mlplayers(ilayer)%layermean(tpbatchsize,1,netnum)); this%mlplayers(ilayer)%layermean = 1d0
           allocate(this%mlplayers(ilayer)%layersigma(tpbatchsize,1,netnum)); this%mlplayers(ilayer)%layersigma = 0d0
        end if

        if ( ilayer == 1 ) cycle

        if ( ilayer < this%nlayer ) then

           iactive = iactive + this%mlplayers(ilayer)%neurons*tpbatchsize
           deallocate(this%mlplayers(ilayer)%grad_active)
           allocate(this%mlplayers(ilayer)%grad_active(this%mlplayers(ilayer)%neurons,tpbatchsize,maxnsteps,netnum))
           this%mlplayers(ilayer)%grad_active = 1d0

        else

           if ( this%iflastactivation == .true. ) then
              iactive = iactive + this%mlplayers(ilayer)%neurons*tpbatchsize
              deallocate(this%mlplayers(ilayer)%grad_active)
              allocate(this%mlplayers(ilayer)%grad_active(this%mlplayers(ilayer)%neurons,tpbatchsize,maxnsteps,netnum))
              this%mlplayers(ilayer)%grad_active = 1d0
           end if

        end if

        if ( icudagroup > 0 ) this%grad_active_index(ilayer+1) = iactive

     end do

  else

     this%batchsize = tpbatchsize; istate = 0; iactive = 0
     do ilayer=1, this%nlayer
        istate = istate + this%mlplayers(ilayer)%neurons*tpbatchsize
        this%hiddenstate_index(ilayer+1) = istate
        this%delta_layer_index(ilayer+1) = istate
        if ( ilayer == 1 ) cycle
        if ( ilayer < this%nlayer ) then
           iactive = iactive + this%mlplayers(ilayer)%neurons*tpbatchsize
        else
           if ( this%iflastactivation == .true. ) then
              iactive = iactive + this%mlplayers(ilayer)%neurons*tpbatchsize
           end if
        end if
        this%grad_active_index(ilayer+1) = iactive
     end do

     inet = inet + 1
     if ( inet == 1 ) then
        tot_hiddenstate_index = 0; tot_grad_active_index = 0
        tot_layernorminout_index = 0; tot_layernormmeansigma_index = 0
     end if

     net_batchsize(inet) = tpbatchsize
     net_ninputgroup(inet) = this%ninput*tpbatchsize
     net_ninputgroupstep(inet) = this%ninput*tpbatchsize
     net_noutputgroup(inet) = this%noutput*tpbatchsize
     net_noutputgroupstep(inet) = this%noutput*tpbatchsize

     tot_hiddenstate_index = tot_hiddenstate_index + this%hiddenstate_index(this%nlayer+1)
     !net(inet+1)%hiddenstate_index_d = tot_hiddenstate_index
     net_net_hiddenstate_index(inet+1) = tot_hiddenstate_index

     !i = net(inet)%mlplayers_index_d + inet; j = net(inet+1)%mlplayers_index_d + inet
     i = net_mlplayers_index(inet) + inet; j = net_mlplayers_index(inet+1) + inet
     net_hiddenstate_index(i:j) = this%hiddenstate_index(:)

     !net(inet+1)%delta_layer_index_d = tot_hiddenstate_index
     net_delta_layer_index(i:j) = this%delta_layer_index(:)

     tot_grad_active_index = tot_grad_active_index + this%grad_active_index(this%nlayer+1)
     !net(inet+1)%grad_active_index_d = tot_grad_active_index
     net_net_grad_active_index(inet+1) = tot_grad_active_index
     net_grad_active_index(i:j) = this%grad_active_index(:)

     tot_layernorminout_index = tot_layernorminout_index + this%ninput*2*tpbatchsize
     net_layernorminout_index(inet+1) = tot_layernorminout_index
     tot_layernormmeansigma_index = tot_layernormmeansigma_index + tpbatchsize*2
     net_layernormmeansigma_index(inet+1) = tot_layernormmeansigma_index

     if ( inet == mlpnum ) inet = 0
  end if
end subroutine

subroutine mlp0_initialize_for_dynamic_batchsize_cuda()
  integer :: i
  integer,save :: max_tot_hiddenstate_index=0,max_tot_grad_active_index=0,max_tot_layernorminout_index=0,max_tot_layernormmeansigma_index=0

  net(:)%batchsize_d = net_batchsize(:)
  net(:)%ninputgroup_d = net_ninputgroup(:)
  net(:)%ninputgroupstep_d = net_ninputgroupstep(:)
  net(:)%noutputgroup_d = net_noutputgroup(:)
  net(:)%noutputgroupstep_d = net_noutputgroupstep(:)

  net(:)%hiddenstate_index_d = net_net_hiddenstate_index(:)
  net(:)%delta_layer_index_d = net_net_hiddenstate_index(:)
  net(:)%grad_active_index_d = net_net_grad_active_index(:)

  layernorminout_index_d = net_layernorminout_index
  layernormmeansigma_index_d = net_layernormmeansigma_index
  grad_active_index_d = net_grad_active_index
  hiddenstate_index_d = net_hiddenstate_index
  delta_layer_index_d = net_delta_layer_index

  if ( tot_hiddenstate_index > max_tot_hiddenstate_index ) then
     max_tot_hiddenstate_index = tot_hiddenstate_index
     deallocate(hiddenstate_d); allocate(hiddenstate_d(tot_hiddenstate_index))
  end if

  !hiddenstate_d(1:tot_hiddenstate_index) = 0.0_SD

  if ( tot_grad_active_index > max_tot_grad_active_index ) then
     max_tot_grad_active_index = tot_grad_active_index
     deallocate(grad_active_d)
     allocate(grad_active_d(tot_grad_active_index))
     if ( dropout > 0.0d0 ) then
        deallocate(curandState_d)
        allocate(curandState_d(tot_grad_active_index))
     end if
  end if

  !grad_active_d(1:tot_grad_active_index) = 0.0_SD

  if ( dropout > 0.0d0 ) then
     call mlp0_curandinit<<<(tot_grad_active_index-1)/32+1,32>>>()
  end if

  if ( tot_layernorminout_index > max_tot_layernorminout_index ) then
     max_tot_layernorminout_index = tot_layernorminout_index
     deallocate(layernorminout_d); allocate(layernorminout_d(tot_layernorminout_index))
  end if
  !layernorminout_d(1:tot_layernorminout_index) = 0.0_SD
  if ( tot_layernormmeansigma_index > max_tot_layernormmeansigma_index ) then
     max_tot_layernormmeansigma_index = tot_layernormmeansigma_index
     deallocate(layernormmeansigma_d); allocate(layernormmeansigma_d(tot_layernormmeansigma_index))
  end if
  !layernormmeansigma_d(1:tot_layernormmeansigma_index) = 0.0_SD

  tot_hiddenstate_index_d = tot_hiddenstate_index
  tot_grad_active_index_d = tot_grad_active_index
  tot_layernorminout_index_d = tot_layernorminout_index
  tot_layernormmeansigma_index_d = tot_layernormmeansigma_index

  call mlp0_network_setzero<<<(tot_hiddenstate_index-1)/32+1,32>>>()
end subroutine

attributes(global) subroutine mlp0_network_setzero()
  integer :: i
  i = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( i <= tot_hiddenstate_index_d ) hiddenstate_d(i) = 0.0_SD
  if ( i <= tot_grad_active_index_d ) grad_active_d(i) = 0.0_SD
  if ( i <= tot_layernorminout_index_d ) layernorminout_d(i) = 0.0_SD
  if ( i <= tot_layernormmeansigma_index_d ) layernormmeansigma_d(i) = 0.0_SD
end subroutine

subroutine mlp0_network_prepare(tpnets)
  class(mlptype), intent(inout) :: tpnets(:)
  integer :: inet

  if ( size(tpnets) /= mlpnum ) then
     print *,"mlp number is incorrect in mlp0_network_prepare ",size(tpnets),mlpnum
     stop
  end if

  if ( icudagroup > 0 )  call mlp0_initialize_cuda(tpnets)
  if ( jobtype == PREDICT .or. jobtype == CHECK .or. (ifproceed .eqv. .true.) .or. jobtype == MD ) then
     call mlp0_network_reloadall(tpnets)
  else
     if ( icudagroup > 0 ) then
        do inet = 1, mlpnum
           call mlp0_network_upload(tpnets(inet))
        end do
     end if
  end if
end subroutine

subroutine mlp0_network_uploadall(tpnets)
  class(mlptype), intent(inout) :: tpnets(:)
  integer :: inet

  do inet = 1, mlpnum
     call mlp0_network_upload(tpnets(inet))
  end do
end subroutine

subroutine mlp0_network_downloadall(tpnets)
  class(mlptype), intent(inout) :: tpnets(:)
  integer :: inet

  do inet = 1, mlpnum
     call mlp0_network_download(tpnets(inet))
  end do
end subroutine

attributes(global) subroutine mlp0_curandinit()
  integer :: iactive
  iactive = (blockidx%x-1)*blockdim%x+threadidx%x; if ( iactive > net(mlpnum_d)%grad_active_index_d ) return
  call curand_init(int(iactive, 8), int(iactive, 8), 0_8, curandState_d(iactive))
end subroutine

subroutine mlp0_network_reloadall(tpnets,tpfile)
  class(mlptype), intent(inout) :: tpnets(:)
  character(len=*),intent(in),optional :: tpfile
  character*15 :: chara
  integer :: i,j,iofile,ilayer,ierr,inet
  logical :: iffound

  if ( present(tpfile) ) then
     open(newunit=iofile,file=tpfile,action="read")
  else
     open(newunit=iofile,file=networkfile,action="read")
  end if

  inet = 0
  do inet = 1, size(tpnets)
     iffound = .false.
     do
        read(iofile,"(a)",iostat=ierr) chara
        if ( ierr /= 0 ) exit
        if ( index(chara, "weights_l2l:") /= 0 ) then
           iffound = .true.; exit
        end if
     end do
     if ( iffound .eqv. .false. ) then
        print *, "can not find mlp parameters in network file: "//trim(networkfile),"for net ",inet
        stop
     end if

     print *,"begin to load net ",inet
     backspace(iofile)

     do ilayer = tpnets(inet)%nlayer, 2, -1
        read(iofile,*)
        do i = 1, tpnets(inet)%mlplayers(ilayer)%neurons
           read(iofile,*) tpnets(inet)%mlplayers(ilayer)%weights_l2l(i,:)
        end do
        if (tpnets(inet)%ifbias .eqv. .true.) then
           read(iofile,*)
           read(iofile,*) tpnets(inet)%mlplayers(ilayer)%bias
        end if
     end do
     if ( maxnsteps > 1 ) then
        do ilayer = tpnets(inet)%nlayer, 2, -1
           read(iofile,*)
           do i = 1, tpnets(inet)%mlplayers(ilayer)%neurons
              read(iofile,*) tpnets(inet)%mlplayers(ilayer)%weights_t2t(i,:)
           end do
        end do
     end if

     if ( icudagroup > 0 ) call mlp0_network_upload(tpnets(inet))
  end do
  close(iofile)
end subroutine

subroutine mlp0_network_reload(this,tpfile)
  class(mlptype),intent(inout) :: this
  character(len=*),intent(in) :: tpfile
  character*15 :: chara
  integer :: i,j,iofile,ilayer,ierr,inet
  logical :: iffound

  iffound = .false.; inet = 0
  open(newunit=iofile,file=tpfile,action="read")
  do 
     read(iofile,"(a)",iostat=ierr) chara
     if ( ierr /= 0 ) exit
     if ( index(chara, "weights_l2l:") /= 0 ) then
        iffound = .true.; inet = inet + 1
        exit
     end if 
  end do
  if ( iffound .eqv. .false. ) stop "can not find mlp parameters in network file: "//trim(networkfile)

  backspace(iofile)

  do ilayer = this%nlayer, 2, -1
     read(iofile,'(a,i8)'),chara,j
     do i = 1, this%mlplayers(ilayer)%neurons
        read(iofile,*) this%mlplayers(ilayer)%weights_l2l(i,:)
     end do
     if (this%ifbias .eqv. .true.) then
        read(iofile,'(a,i8)'),chara,j
        read(iofile,*) this%mlplayers(ilayer)%bias
     end if
  end do
  if ( maxnsteps > 1 ) then
     do ilayer = this%nlayer, 2, -1
        read(iofile,'(a,i8)') chara,j
        do i = 1, this%mlplayers(ilayer)%neurons
           read(iofile,*) this%mlplayers(ilayer)%weights_t2t(i,:)
        end do
     end do
  end if

  close(iofile)

  if ( icudagroup > 0 ) call mlp0_network_upload(this)
end subroutine

subroutine mlp0_network_upload(this)
  class(mlptype), intent(inout) :: this 
  integer :: ilayer,i,j,istart,istart0

  istart0 = net(this%id)%mlplayers_index_d + this%id
  istart = net(this%id)%weights_l2l_index_d
  do ilayer = 1, this%nlayer
     if ( ilayer == 1 ) cycle
     !i = this%weights_l2l_index(ilayer)+1
     !j = this%weights_l2l_index(ilayer+1)
     i = weights_l2l_index_d(istart0+ilayer-1)+1
     j = weights_l2l_index_d(istart0+ilayer)
     weights_l2l_d(istart+i:istart+j) = pack(this%mlplayers(ilayer)%weights_l2l,.true.)
  end do

  istart0 = net(this%id)%mlplayers_index_d + this%id

  if ( this%ifbias .eqv. .true. ) then
     istart = net(this%id)%bias_index_d
     do ilayer = 1, this%nlayer
!        i = this%bias_index(ilayer)+1; j = this%bias_index(ilayer+1)
        i = bias_index_d(istart0+ilayer-1)+1
        j = bias_index_d(istart0+ilayer)
        bias_d(istart+i:istart+j) = this%mlplayers(ilayer)%bias
     end do
  end if

  if ( maxnsteps > 1 ) then
     istart0 = net(this%id)%mlplayers_index_d + this%id
     istart = net(this%id)%weights_t2t_index_d
     do ilayer = 1, this%nlayer
        !i = this%weights_t2t_index(ilayer)+1
        !j = this%weights_t2t_index(ilayer+1)
        i = weights_t2t_index_d(istart0+ilayer-1)+1
        j = weights_t2t_index_d(istart0+ilayer)
        weights_t2t_d(i:j) = pack(this%mlplayers(ilayer)%weights_t2t,.true.)
     end do
  end if
end subroutine

subroutine mlp0_network_download(this)
  class(mlptype), intent(inout) :: this
  integer :: ilayer,index1,index2,tpnum,num,istart0,istart
  real(kind=SD),dimension(:),allocatable :: tparray

  istart0 = net(this%id)%mlplayers_index_d + this%id
  istart = net(this%id)%weights_l2l_index_d
  num = 0
  do ilayer = 2, this%nlayer
     index1 = weights_l2l_index_d(istart0+ilayer-1)+1
     index2 = weights_l2l_index_d(istart0+ilayer)
     tpnum = index2 - index1 + 1; if ( tpnum > num ) num = tpnum

     if ( maxnsteps == 1 ) cycle
     index1 = weights_t2t_index_d(istart0+ilayer-1)+1
     index2 = weights_t2t_index_d(istart0+ilayer)
     tpnum = index2 - index1 + 1; if ( tpnum > num ) num = tpnum
  end do
  allocate(tparray(num)); tparray = 0d0

  istart0 = net(this%id)%mlplayers_index_d + this%id
  istart = net(this%id)%weights_l2l_index_d
  do ilayer = 2, this%nlayer
     index1 = weights_l2l_index_d(istart0+ilayer-1)+1
     index2 = weights_l2l_index_d(istart0+ilayer)
     tparray(1:index2-index1+1) = weights_l2l_d(istart+index1:istart+index2)
     this%mlplayers(ilayer)%weights_l2l(:,:) = reshape(tparray(1:index2-index1+1),[this%mlplayers(ilayer)%neurons, this%mlplayers(ilayer-1)%neurons])
  end do

  istart0 = net(this%id)%mlplayers_index_d + this%id

  if ( this%ifbias .eqv. .true. ) then
     istart = net(this%id)%bias_index_d
     do ilayer = 2, this%nlayer
        index1 = bias_index_d(istart0+ilayer-1)+1
        index2 = bias_index_d(istart0+ilayer)
        tparray(1:index2-index1+1) = bias_d(istart+index1:istart+index2)
        this%mlplayers(ilayer)%bias(:) = tparray(1:index2-index1+1)
     end do
  end if

  if ( maxnsteps > 1 ) then
     istart0 = net(this%id)%mlplayers_index_d + this%id
     istart = net(this%id)%weights_t2t_index_d
     do ilayer = this%nlayer, 2, -1
        index1 = weights_t2t_index_d(istart0+ilayer-1)+1
        index2 = weights_t2t_index_d(istart0+ilayer)
        tparray(1:index2-index1+1) = weights_t2t_d(istart+index1:istart+index2)
        this%mlplayers(ilayer)%weights_t2t(:,:) = reshape(tparray(1:index2-index1+1),[this%mlplayers(ilayer)%neurons,this%mlplayers(ilayer)%neurons])
     end do
  end if
  deallocate(tparray)
end subroutine

subroutine mlp0_network_saveall(tpnets,tpnetworkfile)
  class(mlptype), intent(in) :: tpnets(:)
  character(len=*),intent(in),optional :: tpnetworkfile
  integer :: inet

  do inet = 1, mlpnum
     call mlp0_network_save(tpnets(inet),tpnetworkfile)
  end do
end subroutine

subroutine mlp0_network_save(this,tpnetworkfile)
  class(mlptype), intent(inout) :: this
  character(len=*),intent(in),optional :: tpnetworkfile
  integer :: i,j,iofile,ilayer

  if ( icudagroup > 0 ) call mlp0_network_download(this)

  if ( present(tpnetworkfile) ) then
     open(newunit=iofile,file=tpnetworkfile,action="write",access="append")
  else
     open(newunit=iofile,file=networkfile,action="write",access="append")
  end if
  do ilayer = this%nlayer,2,-1
     write(iofile,'(a,i8)'),'weights_l2l:',ilayer
     do i = 1, this%mlplayers(ilayer)%neurons
        write(iofile,'(*(f20.16))') this%mlplayers(ilayer)%weights_l2l(i,:)
     end do
     if ( this%ifbias .eqv. .true. ) then
        write(iofile,'(a,i8)'),'bias:',ilayer
        write(iofile,'(*(f20.16))') this%mlplayers(ilayer)%bias
     end if
  end do

  if ( maxnsteps > 1 ) then
     do ilayer = this%nlayer, 2, -1
        write(iofile,'(a,i8)'),'weights_t2t:',ilayer
        do i = 1, this%mlplayers(ilayer)%neurons
           write(iofile,'(*(f20.16))') this%mlplayers(ilayer)%weights_t2t(i,:)
        end do
     end do
  end if
  close(iofile)
end subroutine

!================================ network update

subroutine mlp0_network_update(tpnets)
  class(mlptype), intent(inout) :: tpnets(:)
  integer :: ierr,inet

  if ( size(tpnets) /= mlpnum ) stop "mlp number is incorrect in mlp0_network_update"
  if ( icudagroup == 0 ) then
     do inet = 1, size(tpnets)
        call mlp0_network_update_cpu(tpnets(inet))
     end do
  else
     if ( deepprocnum > 1 ) then
        call deeppub_ncclAllReduce_vector(grad_weights_l2l_d, tot_weights_l2l_index)
        call deeppub_ncclAllReduce_vector(grad_bias_d, tot_bias_index)
     end if
     call mlp0_network_update_weights_l2l_cuda<<<(tot_weights_l2l_index-1)/32+1,32>>>()
     call mlp0_network_update_bias_cuda<<<(tot_bias_index-1)/32+1,32>>>()

  end if
end subroutine

subroutine mlp0_network_update_cpu(this)
  class(mlptype), intent(inout) :: this
  integer :: ilayer,i,j
  real*8 :: tpg,tpgsq,tpstepsize

  !if ( iflayernorm .eqv. .true. ) then
  if ( .false. ) then
     i = 1; j = this%nlayer - 1

     do ilayer = i, j

        if ( ioptmethod == 1 ) then

           tpg = this%mlplayers(ilayer)%grad_layerweight
           if ( l1normfactor > 0.0d0 ) then
              tpg = tpg + l1normfactor*dsign(1.0d0, this%mlplayers(ilayer)%layerweight)
           else if ( l2normfactor > 0.0d0 ) then
              tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%layerweight
           end if
           this%mlplayers(ilayer)%layerweight = this%mlplayers(ilayer)%layerweight - learnrate*tpg

           tpg = this%mlplayers(ilayer)%grad_layerbias
           if ( l1normfactor > 0.0d0 ) then
              tpg = tpg + l1normfactor*dsign(1.0d0, this%mlplayers(ilayer)%layerbias)
           else if ( l2normfactor > 0.0d0 ) then
              tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%layerbias
           end if
           this%mlplayers(ilayer)%layerbias = this%mlplayers(ilayer)%layerbias - learnrate*tpg

        else if ( ioptmethod == 2 ) then

           tpg = this%mlplayers(ilayer)%grad_layerweight
           if ( l1normfactor > 0.0d0 ) then
              tpg = tpg + l1normfactor*dsign(1d0, this%mlplayers(ilayer)%layerweight)
           else if ( l2normfactor > 0.0d0 ) then
              tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%layerweight
           end if

           tpgsq = 0.999d0*this%mlplayers(ilayer)%gradgsq_layerweight + (1.0d0 - 0.999d0)*tpg*tpg
           tpg = 0.9d0*this%mlplayers(ilayer)%gradg_layerweight + (1.0d0 - 0.9d0)*tpg

           tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
           this%mlplayers(ilayer)%layerweight = this%mlplayers(ilayer)%layerweight - learnrate*tpstepsize
           this%mlplayers(ilayer)%gradg_layerweight = tpg
           this%mlplayers(ilayer)%gradgsq_layerweight = tpgsq

           tpg = this%mlplayers(ilayer)%grad_layerbias
           if ( l1normfactor > 0.0d0 ) then
              tpg = tpg + l1normfactor*dsign(1d0, this%mlplayers(ilayer)%layerbias)
           else if ( l2normfactor > 0.0d0 ) then
              tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%layerbias
           end if

           tpgsq = 0.999d0*this%mlplayers(ilayer)%gradgsq_layerbias + (1.0d0 - 0.999d0)*tpg*tpg
           tpg = 0.9d0*this%mlplayers(ilayer)%gradg_layerbias + (1.0d0 - 0.9d0)*tpg

           tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
           this%mlplayers(ilayer)%layerbias = this%mlplayers(ilayer)%layerbias - learnrate*tpstepsize
           this%mlplayers(ilayer)%gradg_layerbias = tpg
           this%mlplayers(ilayer)%gradgsq_layerbias = tpgsq

        end if

        this%mlplayers(ilayer)%grad_layerweight = 0d0
        this%mlplayers(ilayer)%grad_layerbias = 0d0

     end do

  end if

  do ilayer = 2, this%nlayer

     if ( ioptmethod == 1 ) then

        do i = 1, this%mlplayers(ilayer)%neurons
           do j = 1, this%mlplayers(ilayer-1)%neurons
              tpg = this%mlplayers(ilayer)%grad_weights_l2l(i,j)
              if ( l1normfactor > 0.0d0 ) then
                 tpg = tpg + l1normfactor*dsign(1.0d0, this%mlplayers(ilayer)%weights_l2l(i,j))
              else if ( l2normfactor > 0.0d0 ) then
                 tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%weights_l2l(i,j)
              end if
              this%mlplayers(ilayer)%grad_weights_l2l(i,j) = tpg
           end do
        end do           
        this%mlplayers(ilayer)%weights_l2l = this%mlplayers(ilayer)%weights_l2l - learnrate * this%mlplayers(ilayer)%grad_weights_l2l

        if ( this%ifbias .eqv. .true. ) then
           do i = 1, this%mlplayers(ilayer)%neurons
              tpg = this%mlplayers(ilayer)%grad_bias(i)
              if ( l1normfactor > 0.0d0 ) then
                 tpg = tpg + l1normfactor*dsign(1.0d0, this%mlplayers(ilayer)%bias(i))
              else if ( l2normfactor > 0.0d0 ) then
                 tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%bias(i)
              end if
              this%mlplayers(ilayer)%grad_bias(i) = tpg
           end do
           this%mlplayers(ilayer)%bias = this%mlplayers(ilayer)%bias - learnrate*this%mlplayers(ilayer)%grad_bias
        end if

        if ( maxnsteps /= 1 ) then
           this%mlplayers(ilayer)%weights_t2t = this%mlplayers(ilayer)%weights_t2t - learnrate * this%mlplayers(ilayer)%grad_weights_t2t
        end if

     else if ( ioptmethod == 2 ) then

       do i = 1, this%mlplayers(ilayer)%neurons
          do j = 1, this%mlplayers(ilayer-1)%neurons

             tpg = this%mlplayers(ilayer)%grad_weights_l2l(i,j)
             if ( l1normfactor > 0.0d0 ) then
                tpg = tpg + l1normfactor*dsign(1d0,this%mlplayers(ilayer)%weights_l2l(i,j))
             else if ( l2normfactor > 0.0d0 ) then
                tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%weights_l2l(i,j)
             end if

             tpgsq = 0.999d0*this%mlplayers(ilayer)%gradgsq_weights_l2l(i,j) + (1.0d0 - 0.999d0)*tpg*tpg
             tpg = 0.9d0*this%mlplayers(ilayer)%gradg_weights_l2l(i,j) + (1.0d0 - 0.9d0)*tpg

             tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
             this%mlplayers(ilayer)%weights_l2l(i,j) = this%mlplayers(ilayer)%weights_l2l(i,j) - learnrate*tpstepsize

             this%mlplayers(ilayer)%gradg_weights_l2l(i,j) = tpg
             this%mlplayers(ilayer)%gradgsq_weights_l2l(i,j) = tpgsq

          end do
       end do

       if ( this%ifbias .eqv. .true. ) then 
          do i = 1, this%mlplayers(ilayer)%neurons
             tpg = this%mlplayers(ilayer)%grad_bias(i)

             if ( l1normfactor > 0.0d0 ) then
                tpg = tpg + l1normfactor*dsign(1d0, this%mlplayers(ilayer)%bias(i))
             else if ( l2normfactor > 0.0d0 ) then
                tpg = tpg + l2normfactor*2d0*this%mlplayers(ilayer)%bias(i)
             end if

             tpgsq = 0.999d0*this%mlplayers(ilayer)%gradgsq_bias(i) + (1.0d0 - 0.999d0)*tpg*tpg
             tpg = 0.9d0*this%mlplayers(ilayer)%gradg_bias(i) + (1.0d0 - 0.9d0)*tpg

             tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
             this%mlplayers(ilayer)%bias(i) = this%mlplayers(ilayer)%bias(i) - learnrate*tpstepsize
             this%mlplayers(ilayer)%gradg_bias(i) = tpg
             this%mlplayers(ilayer)%gradgsq_bias(i) = tpgsq
          end do
       end if

     end if

     this%mlplayers(ilayer)%grad_weights_l2l(:,:) = 0d0
     if ( this%ifbias .eqv. .true. ) this%mlplayers(ilayer)%grad_bias(:) = 0d0
     if ( maxnsteps /= 1 ) then
        this%mlplayers(ilayer)%grad_weights_t2t(:,:) = 0d0
     end if
  end do

end subroutine

attributes(global) subroutine mlp0_network_update_weights_l2l_cuda()
  integer :: index
  real(kind=SD) :: tpg,tpgsq,tpstepsize

  index = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( index > tot_weights_l2l_index_d ) return

  tpg = grad_weights_l2l_d(index); tpgsq = weights_l2l_d(index)
  if ( l1normfactor_d > 0.0_SD ) then
     tpg = tpg + l1normfactor_d*sign(1.0, real(tpgsq))
  else if ( l2normfactor_d > 0.0_SD ) then
     tpg = tpg + l2normfactor_d*2_SD*tpgsq
  end if
  if ( ioptmethod_d == 1 ) then
     weights_l2l_d(index) = tpgsq - learnrate_d*tpg
  else if ( ioptmethod_d == 2 ) then
     tpgsq = 0.999_SD*gradgsq_weights_l2l_d(index) + (1.0_SD - 0.999_SD)*tpg*tpg
     tpg = 0.9_SD*gradg_weights_l2l_d(index) + (1.0_SD - 0.9_SD)*tpg
     tpstepsize = (tpg/(1.0_SD-0.9_SD))/(sqrt(tpgsq/(1.0_SD-0.999_SD)) + 0.00000001_SD)
     weights_l2l_d(index) = weights_l2l_d(index) - learnrate_d*tpstepsize
     gradg_weights_l2l_d(index) = tpg; gradgsq_weights_l2l_d(index) = tpgsq
  end if
  grad_weights_l2l_d(index) = 0.0_SD

  !if ( (iflayernorm_d .eqv. .true.) .and. (index <= 2*id)) then
  if ( .false. ) then
     tpg = grad_layernormweightbias_d(index); tpgsq = layernormweightbias_d(index)
     if ( l1normfactor_d > 0.0_SD ) then
        tpg = tpg + l1normfactor_d*sign(1.0, real(tpgsq))
     else if ( l2normfactor_d > 0.0_SD ) then
        tpg = tpg + l2normfactor_d*2.0_SD*tpgsq
     end if
     if ( ioptmethod_d == 1 ) then
        layernormweightbias_d(index) = tpgsq - learnrate_d*tpg
     else if ( ioptmethod_d == 2 ) then
        tpgsq = 0.999_SD*gradgsq_layernormweightbias_d(index) + (1.0_SD - 0.999_SD)*tpg*tpg
        tpg = 0.9_SD*gradg_layernormweightbias_d(index) + (1.0_SD - 0.9_SD)*tpg
        tpstepsize = (tpg/(1.0_SD-0.9_SD))/(sqrt(tpgsq/(1.0_SD-0.999_SD)) + 0.00000001_SD)
        layernormweightbias_d(index) = layernormweightbias_d(index) - learnrate_d*tpstepsize
        gradg_layernormweightbias_d(index) = tpg
        gradgsq_layernormweightbias_d(index) = tpgsq
     end if
     grad_layernormweightbias_d(index) = 0.0_SD
  end if
end subroutine

attributes(global) subroutine mlp0_network_update_bias_cuda()
  integer :: index
  real(kind=SD) :: tpg,tpgsq,tpstepsize

  index = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( index > tot_bias_index_d ) return

  tpg = grad_bias_d(index); tpgsq = bias_d(index)
  if ( l1normfactor_d > 0.0_SD ) then
     tpg = tpg + l1normfactor_d*sign(1.0, real(tpgsq))
  else if ( l2normfactor_d > 0.0_SD ) then
     tpg = tpg + l2normfactor_d*2.0_SD*tpgsq
  end if
  if ( ioptmethod_d == 1 ) then
     bias_d(index) = tpgsq - learnrate_d*tpg
  else if ( ioptmethod_d == 2 ) then
     tpgsq = 0.999_SD*gradgsq_bias_d(index) + (1.0_SD - 0.999_SD)*tpg*tpg
     tpg = 0.9_SD*gradg_bias_d(index) + (1.0_SD - 0.9_SD)*tpg
     tpstepsize = (tpg/(1.0_SD-0.9_SD))/(sqrt(tpgsq/(1.0_SD-0.999_SD)) + 0.00000001_SD)
     bias_d(index) = bias_d(index) - learnrate_d*tpstepsize
     gradg_bias_d(index) = tpg; gradgsq_bias_d(index) = tpgsq
  end if
  grad_bias_d(index) = 0.0_SD
end subroutine

!==================================================

!================ layer normalization
subroutine mlp0_layer_normalization_forward(invals,outvals,mean,sigma)
  real*8,dimension(:),intent(in) :: invals
  real*8,dimension(:),intent(out) :: outvals
  real*8,intent(inout) :: mean,sigma
  integer :: num
  real*8 :: meansq

  num = size(invals)
  mean = sum(invals(1:num))/dble(num)
  meansq = sum(invals(1:num)**2)/dble(num)
  sigma = meansq - mean*mean
  sigma = sqrt(sigma+1d-6)
  outvals(1:num) = (invals(1:num) - mean )/sigma
end subroutine

subroutine mlp0_layer_normalization_backward(invals,bvals,mean,sigma)
  real*8,dimension(:),intent(in) :: invals
  real*8,dimension(:),intent(inout) :: bvals
  real*8,intent(in) :: mean,sigma
  integer :: num,i
  real*8 :: tpsum1,tpsum2

  num = size(invals)
  tpsum1 = sum(bvals); tpsum2 = sum((invals-mean)*bvals)
  bvals = bvals/sigma - tpsum1/(dble(num)*sigma) - (invals-mean)*tpsum2/(dble(num)*sigma*sigma*sigma)
end subroutine

subroutine mlp0_layer_normalization_check()
  real*8,dimension(:),allocatable :: invals,outvals,bvals,orivals,outvals1,outvals2,tpvals
  real*8 :: mean,sigma,h,tpsum1,tpsum2,maxerr
  integer :: num,i,j,k

  num = 100; allocate(invals(num),outvals(num),bvals(num),orivals(num),outvals1(num),outvals2(num),tpvals(num))
  do i = 1,num
     invals(i) = sin(dble(i)); bvals(i) = cos(dble(i))
  end do
  orivals = invals
  call mlp0_layer_normalization_forward(invals,outvals,mean,sigma)
  tpvals = bvals
  call mlp0_layer_normalization_backward(invals,bvals,mean,sigma)
  h = 0.001d0; invals = orivals; maxerr = 0d0
  do i = 1,num
     invals(i) = orivals(i) + h
     call mlp0_layer_normalization_forward(invals,outvals1,mean,sigma)
     invals(i) = orivals(i) - h
     call mlp0_layer_normalization_forward(invals,outvals2,mean,sigma)
     invals(i) = orivals(i)
     maxerr = max(abs(sum(tpvals*(outvals1(:)-outvals2(:)))/(2d0*h)-bvals(i)),maxerr)
  end do
  write(6,'(a,f15.10)'),'Layer Normalization Error:',maxerr
end subroutine
!==============================================================

!================ Network Forward and Backward propagation

subroutine mlp0_network_forward(this,netidx,inputs,outputs,errormark)
  class(mlptype), intent(inout) :: this
  integer,intent(in) :: netidx
  real*8,dimension(:,:,:),intent(inout) :: inputs
  real*8,dimension(:,:,:),intent(out) :: outputs
  integer,dimension(:),intent(in),optional :: errormark
  integer :: idata,istep,ilayer,tpgroupsize,tpmaxnsteps,ineuron,nlayer
  real*8 :: tpvec(maxval(this%mlplayers(:)%neurons)),temp

  outputs = 0d0; tpgroupsize = size(inputs,2); tpmaxnsteps = size(inputs,3)
  nlayer = this%nlayer

  if ( this%ifbatchnorm .eqv. .true. ) then
     this%batchnormmean = 0d0; this%batchnormsqerror = 0d0
     do idata = 1, this%ninput
        this%batchnormmean(idata) = sum(inputs(idata,1:tpgroupsize,netidx))/dble(tpgroupsize)
        this%batchnormsqerror(idata) = sum(inputs(idata,1:tpgroupsize,netidx)**2)/dble(tpgroupsize)
     end do
     this%batchnormsqerror(1:this%ninput) = this%batchnormsqerror(1:this%ninput) - this%batchnormmean(1:this%ninput)**2 + 1d-10
     do idata = 1, this%ninput
        inputs(idata,1:tpgroupsize,netidx) = this%batchnormfactor*(inputs(idata,1:tpgroupsize,netidx) - this%batchnormmean(idata))/sqrt(this%batchnormsqerror(idata))
     end do
  end if

  do idata = 1, tpgroupsize
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     ! cycle on all the time steps
     do istep = 1, tpmaxnsteps

        ! initial input data of the neurons in the input layer
        this%mlplayers(1)%hiddenstate(:,idata,istep,netidx) = inputs(:,idata,istep)

        if ( this%iflayernorm .eqv. .true. ) then
           this%mlplayers(1)%layernormin(:,idata,istep,netidx) = inputs(:,idata,istep)
           call mlp0_layer_normalization_forward(                            &
                this%mlplayers(1)%layernormin(:,idata,istep,netidx),  &
                tpvec(1:this%mlplayers(1)%neurons),                      &
                this%mlplayers(1)%layermean(idata,istep,netidx),              &
                this%mlplayers(1)%layersigma(idata,istep,netidx) )
           this%mlplayers(1)%layernormout(:,idata,istep,netidx) = tpvec(1:this%mlplayers(1)%neurons)
           this%mlplayers(1)%hiddenstate(:,idata,istep,netidx) = this%mlplayers(1)%layerweight*tpvec(1:this%mlplayers(1)%neurons) + this%mlplayers(1)%layerbias

        end if

        ! Eq.3.16
        ! outputs depend on the neurons in previous layer and neurons at previous time step
        do ilayer=2, nlayer-1

           if ( this%ifbias .eqv. .true. ) then
              tpvec(1:this%mlplayers(ilayer)%neurons) = &
                     matmul(this%mlplayers(ilayer)%weights_l2l(:,:),                      &
                     this%mlplayers(ilayer-1)%hiddenstate(:,idata,istep,netidx)) +  &
                     this%mlplayers(ilayer)%bias(:)
           else
              tpvec(1:this%mlplayers(ilayer)%neurons) = &
                     matmul(this%mlplayers(ilayer)%weights_l2l(:,:),                      &
                     this%mlplayers(ilayer-1)%hiddenstate(:,idata,istep,netidx))
           end if
           if ( maxnsteps /= 1 ) then
              if ( istep > 1 ) then
                 tpvec(1:this%mlplayers(ilayer)%neurons) = tpvec(1:this%mlplayers(ilayer)%neurons) + &
                     matmul(this%mlplayers(ilayer)%weights_t2t(:,:),    &
                     this%mlplayers(ilayer)%hiddenstate(:,idata,istep-1,netidx))
              end if
           end if

           !if ( this%iflayernorm .eqv. .true. ) then
           !   this%mlplayers(ilayer)%layernormin(:,idata,istep,netidx) = tpvec(1:this%mlplayers(ilayer)%neurons)
           !   call mlp0_layer_normalization_forward(                            &
           !        this%mlplayers(ilayer)%layernormin(:,idata,istep,netidx),  &
           !        tpvec(1:this%mlplayers(ilayer)%neurons),                      &
           !        this%mlplayers(ilayer)%layermean(idata,istep,netidx),              &
           !        this%mlplayers(ilayer)%layersigma(idata,istep,netidx) )
           !   this%mlplayers(ilayer)%layernormout(:,idata,istep,netidx) = tpvec(1:this%mlplayers(ilayer)%neurons)
           !   tpvec(1:this%mlplayers(ilayer)%neurons) = this%mlplayers(ilayer)%layerweight*tpvec(1:this%mlplayers(ilayer)%neurons) + this%mlplayers(ilayer)%layerbias
           !end if

           ! calculate the activation function value and derivative
           call deeppub_activation_function(tpvec(1:this%mlplayers(ilayer)%neurons),this%mlplayers(ilayer)%hiddenstate(:,idata,istep,netidx),this%mlplayers(ilayer)%grad_active(:,idata,istep,netidx))

           if ( dropout > 0.0d0 ) then
              if ( jobtype == TRAIN ) then
                 do ineuron = 1, this%mlplayers(ilayer)%neurons
                    call random_number(temp)
                    if ( temp < dropout ) then
                       this%mlplayers(ilayer)%hiddenstate(ineuron,idata,istep,netidx) = 0d0
                       this%mlplayers(ilayer)%grad_active(ineuron,idata,istep,netidx) = 0d0
                    else
                       this%mlplayers(ilayer)%hiddenstate(ineuron,idata,istep,netidx) = this%mlplayers(ilayer)%hiddenstate(ineuron,idata,istep,netidx)/(1d0 - dropout)
                       this%mlplayers(ilayer)%grad_active(ineuron,idata,istep,netidx) = this%mlplayers(ilayer)%grad_active(ineuron,idata,istep,netidx)/(1d0 - dropout)
                    end if
                 end do
              else
                 do ineuron = 1, this%mlplayers(ilayer)%neurons
                    this%mlplayers(ilayer)%hiddenstate(ineuron,idata,istep,netidx) = this%mlplayers(ilayer)%hiddenstate(ineuron,idata,istep,netidx)*(1d0 - dropout)
                    this%mlplayers(ilayer)%grad_active(ineuron,idata,istep,netidx) = this%mlplayers(ilayer)%grad_active(ineuron,idata,istep,netidx)*(1d0 - dropout)
                 end do
              end if
           end if

        end do

        if ( this%ifbias .eqv. .true. ) then
           tpvec(1:this%mlplayers(nlayer)%neurons) = matmul(this%mlplayers(nlayer)%weights_l2l(:,:),this%mlplayers(nlayer-1)%hiddenstate(:,idata,istep,netidx)) + this%mlplayers(nlayer)%bias(:)
        else
           tpvec(1:this%mlplayers(nlayer)%neurons) = matmul(this%mlplayers(nlayer)%weights_l2l(:,:),this%mlplayers(nlayer-1)%hiddenstate(:,idata,istep,netidx))
        end if

        if ( this%iflastactivation .eqv. .false. ) then
           this%mlplayers(nlayer)%hiddenstate(:,idata,istep,netidx) = tpvec(1:this%mlplayers(nlayer)%neurons)
           outputs(:,idata,istep) = tpvec(1:this%mlplayers(nlayer)%neurons)
        else
           if ( ifclasses == 1 ) then
              call deeppub_activation_softmax(tpvec(1:this%mlplayers(nlayer)%neurons),this%mlplayers(nlayer)%hiddenstate(:,idata,istep,netidx))
              this%mlplayers(nlayer)%softmaxstate(:,idata,istep,netidx) = this%mlplayers(nlayer)%hiddenstate(:,idata,istep,netidx)
           else
              call deeppub_activation_function(tpvec(1:this%mlplayers(nlayer)%neurons),this%mlplayers(nlayer)%hiddenstate(:,idata,istep,netidx),this%mlplayers(nlayer)%grad_active(:,idata,istep,netidx))

           end if
           outputs(:,idata,istep) = this%mlplayers(nlayer)%hiddenstate(:,idata,istep,netidx)
        end if
     end do
  end do
end subroutine

! Back Propagation through time (BPTT) in Recurrent Neural Network
subroutine mlp0_network_backward_bptt(this,netidx,outputs,iflabel,errormark,tpfirstdeltalayer,ifdoflood)
  class(mlptype), intent(inout) :: this
  integer,intent(in) :: netidx
  real*8,intent(in),dimension(:,:,:) :: outputs
  logical,intent(in) :: iflabel
  integer,intent(in),dimension(:),optional :: errormark
  real*8,intent(out),dimension(:,:),optional :: tpfirstdeltalayer
  logical,intent(in),optional :: ifdoflood
  integer :: nlayer,bptt_step,idata,istep,ilayer,tpgroupsize,tpmaxnsteps
  real*8,dimension(maxval(this%mlplayers(:)%neurons)) :: tpdeltalayer
  real*8 :: tpsum

  if ( present(ifdoflood) ) then
     if ( ifdoflood .eqv. .true. ) then  
        call mlp0_flooding_backward(this, outputs, tpfirstdeltalayer)
        return
     end if
  end if

  nlayer = this%nlayer
  tpgroupsize = size(outputs,2); tpmaxnsteps = size(outputs,3)
  do idata = 1, tpgroupsize

     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     do istep = tpmaxnsteps, 1, -1

        if ( iflabel .eqv. .false. ) then
           this%mlplayers(nlayer)%delta_layer(:) = outputs(:,idata,istep)
        else
           ! delta^L = d(Loss)/d(S^L) = 2.0 * (S^t - y^t)

           if ( allocated(this%outputweight) ) then
              this%mlplayers(nlayer)%delta_layer(:) = 2d0*(this%mlplayers(nlayer)%hiddenstate(:,idata,istep,netidx)-outputs(:,idata,istep))*this%outputweight(:)
           else
              this%mlplayers(nlayer)%delta_layer(:) = 2d0*(this%mlplayers(nlayer)%hiddenstate(:,idata,istep,netidx)-outputs(:,idata,istep))
           end if
        end if

        if ( this%iflastactivation .eqv. .true. ) then
           if ( ifclasses == 1 ) then
              tpdeltalayer(1:this%mlplayers(nlayer)%neurons) = this%mlplayers(nlayer)%softmaxstate(:,idata,istep,netidx)*this%mlplayers(nlayer)%delta_layer(:)
              tpsum = sum(tpdeltalayer(1:this%mlplayers(nlayer)%neurons))
              this%mlplayers(nlayer)%delta_layer(:) = (this%mlplayers(nlayer)%delta_layer(:)-tpsum)*this%mlplayers(nlayer)%softmaxstate(:,idata,istep,netidx)
           else
              this%mlplayers(nlayer)%delta_layer(:) = &
                   this%mlplayers(nlayer)%grad_active(:,idata,istep,netidx)*   &
                   this%mlplayers(nlayer)%delta_layer(:)
           end if
        end if

        ! d(Loss)/d(U^L) = delta^L * d(f) * S^(L-1)(t)        Eq.3-21

        if ( jobtype == TRAIN ) then
           call deeppub_matmul_outer_product(this%mlplayers(nlayer)%grad_weights_l2l(:,:),  &
                   this%mlplayers(nlayer)%delta_layer(:),                  &
                   this%mlplayers(nlayer-1)%hiddenstate(:,idata,istep,netidx))

           ! d(Loss)/d(bias)                                     Eq.3-23
           if ( this%ifbias .eqv. .true. ) this%mlplayers(nlayer)%grad_bias = this%mlplayers(nlayer)%grad_bias + this%mlplayers(nlayer)%delta_layer(:)
        end if

        ! only go back for bptt_trun steps
        do bptt_step = istep, max(1,istep-bptt_trun+1), -1
           do ilayer = nlayer-1,1,-1

              ! Eq.3-24
              ! delta^i = d(Loss)/d(S^i) = U^i+1 * d(f(t))^i+1 * delta^i+1(t) + W^i * d(f(t))^i * delta^i(t+1)
              ! back propagation from next layer
              if ( bptt_step == istep ) then
                 this%mlplayers(ilayer)%delta_layer(:) = &
                          matmul(transpose(this%mlplayers(ilayer+1)%weights_l2l(:,:)),this%mlplayers(ilayer+1)%delta_layer(:))
                 if ( ilayer == 1 ) then


                    if ( this%iflayernorm .eqv. .true. ) then

                       this%mlplayers(ilayer)%grad_layerweight = this%mlplayers(ilayer)%grad_layerweight + dot_product(this%mlplayers(ilayer)%delta_layer(:),this%mlplayers(ilayer)%layernormout(:,idata,istep,netidx))
                       this%mlplayers(ilayer)%grad_layerbias = this%mlplayers(ilayer)%grad_layerbias + sum(this%mlplayers(ilayer)%delta_layer(:))
                       this%mlplayers(ilayer)%delta_layer(:) = this%mlplayers(ilayer)%layerweight*this%mlplayers(ilayer)%delta_layer(:)
                       call mlp0_layer_normalization_backward( &
                            this%mlplayers(ilayer)%layernormin(:,idata,bptt_step,netidx),   &
                            this%mlplayers(ilayer)%delta_layer(:),                   &
                            this%mlplayers(ilayer)%layermean(idata,bptt_step,netidx),               &
                            this%mlplayers(ilayer)%layersigma(idata,bptt_step,netidx) )
                    end if
                    if ( present(tpfirstdeltalayer) ) tpfirstdeltalayer(:,idata) = this%mlplayers(ilayer)%delta_layer(:)
                    exit
                 end if

              ! back propagation from next time step
              else if ( ilayer == nlayer-1 ) then
                 tpdeltalayer(1:this%mlplayers(ilayer)%neurons) = &
                       matmul(transpose(this%mlplayers(ilayer)%weights_t2t(:,:)),this%mlplayers(ilayer)%delta_layer(:))
                 this%mlplayers(ilayer)%delta_layer(:) = tpdeltalayer(1:this%mlplayers(ilayer)%neurons)

              ! back propagation from next layer and next time step
              else
                 tpdeltalayer(1:this%mlplayers(ilayer)%neurons) = &
                       matmul(transpose(this%mlplayers(ilayer+1)%weights_l2l(:,:)),this%mlplayers(ilayer+1)%delta_layer(:)) + &
                       matmul(transpose(this%mlplayers(ilayer)%weights_t2t(:,:)),this%mlplayers(ilayer)%delta_layer(:))
                 this%mlplayers(ilayer)%delta_layer(:) = tpdeltalayer(1:this%mlplayers(ilayer)%neurons)


              end if

              this%mlplayers(ilayer)%delta_layer(:) = &
                   this%mlplayers(ilayer)%grad_active(:,idata,bptt_step,netidx)*   &
                   this%mlplayers(ilayer)%delta_layer(:)

              !if ( this%iflayernorm .eqv. .true. ) then
              !   this%mlplayers(ilayer)%grad_layerweight = this%mlplayers(ilayer)%grad_layerweight + dot_product(this%mlplayers(ilayer)%delta_layer(:),this%mlplayers(ilayer)%layernormout(:,idata,istep,netidx))
              !   this%mlplayers(ilayer)%grad_layerbias = this%mlplayers(ilayer)%grad_layerbias + sum(this%mlplayers(ilayer)%delta_layer(:))

              !   this%mlplayers(ilayer)%delta_layer(:) = this%mlplayers(ilayer)%layerweight*this%mlplayers(ilayer)%delta_layer(:)
              !   call mlp0_layer_normalization_backward( &
              !        this%mlplayers(ilayer)%layernormin(:,idata,bptt_step,netidx),   &
              !        this%mlplayers(ilayer)%delta_layer(:),                   &
              !        this%mlplayers(ilayer)%layermean(idata,bptt_step,netidx),               &   
              !        this%mlplayers(ilayer)%layersigma(idata,bptt_step,netidx) )
              !end if

              if (  jobtype == TRAIN ) then
                 ! Eq.3-21
                 ! d(Loss)/d(U^L) = delta^L * d(f) * S^(L-1)(t)
                 call deeppub_matmul_outer_product(this%mlplayers(ilayer)%grad_weights_l2l(:,:),  &
                            this%mlplayers(ilayer)%delta_layer(:), &
                            this%mlplayers(ilayer-1)%hiddenstate(:,idata,bptt_step,netidx))

                 ! Eq.3-23              
                 ! d(Loss)/d(bias)
                 if ( this%ifbias .eqv. .true. ) this%mlplayers(ilayer)%grad_bias = this%mlplayers(ilayer)%grad_bias + this%mlplayers(ilayer)%delta_layer(:)

                 ! Eq.3-22
                 ! d(Loss)/d(W^L) = delta^L * d(f)* S^L(t-1)
                 if ( maxnsteps /= 1 ) then
                    if ( bptt_step > 1 ) then
                       call deeppub_matmul_outer_product(this%mlplayers(ilayer)%grad_weights_t2t(:,:),     &
                            this%mlplayers(ilayer)%delta_layer(:),  &
                            this%mlplayers(ilayer)%hiddenstate(:,idata,bptt_step-1,netidx))

                    end if
                 end if
              end if

           end do
        end do

     end do
  end do

  if ( present(tpfirstdeltalayer) .and. (this%ifbatchnorm .eqv. .true.) ) then
     do idata = 1, this%ninput
        tpfirstdeltalayer(idata,1:tpgroupsize) = this%batchnormfactor*tpfirstdeltalayer(idata,1:tpgroupsize)/sqrt(this%batchnormsqerror(idata))
     end do
  end if

end subroutine

!============================ GPU forward and backward propagation

subroutine mlp0_network_forward_cuda(this,tpoutputs)
  class(mlptype), intent(inout) :: this
  real*8,intent(out),optional :: tpoutputs(:,:,:)
  integer :: ilayer,i,j
  real*8,allocatable :: tpvec(:)

  call mlp0_network_forward_cuda_inputlayer<<<(icudagroup*this%ninput-1)/32+1,32>>>(this%id)

  if ( this%iflayernorm .eqv. .true. ) call mlp0_network_forward_cuda_layernorm<<<icudagroup,32>>>(this%id)

  do ilayer = 2, this%nlayer
     call mlp0_network_forward_cuda_layer<<<(icudagroup*this%mlplayers(ilayer)%neurons-1)/32+1,32>>>(this%id,ilayer)
     call mlp0_network_forward_cuda_biasact<<<(icudagroup*this%mlplayers(ilayer)%neurons-1)/32+1,32>>>(this%id,ilayer)
  end do

  if ( present(tpoutputs) ) then
     i = this%hiddenstate_index(this%nlayer)+1
     j = this%hiddenstate_index(this%nlayer+1)
     !ilayer = net(this%id)%mlplayers_index_d + this%id
     !i = hiddenstate_index_d(ilayer+this%nlayer-1)+1
     !j = hiddenstate_index_d(ilayer+this%nlayer)

     ilayer = net(this%id)%hiddenstate_index_d
     allocate(tpvec(this%hiddenstate_index(this%nlayer+1)-this%hiddenstate_index(this%nlayer)))
     tpvec = hiddenstate_d(ilayer+i:ilayer+j)
     tpoutputs(:,:,:) = reshape(tpvec,[this%noutput,icudagroup,1])
  end if
end subroutine

attributes(global) subroutine mlp0_network_forward_cuda_inputlayer(id)
  integer,intent(in),value :: id
  integer :: istate,irec

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/net(id)%ninput_d+1
  if ( irec > icudagroup_d ) return
  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1) return
  end if

  hiddenstate_d( net(id)%hiddenstate_index_d + istate) = batchdata_d(istate)
end subroutine

attributes(global) subroutine mlp0_network_forward_cuda_layernorm(id)
  integer,intent(in),value :: id
  integer :: idata,istate,istart
  real(kind=SD) :: tpsum,tpsumsq,tpvalue

  idata = blockidx%x; tpsum = 0.0_SD; tpsumsq = 0.0_SD

  istart = net(id)%mlplayers_index_d + id
  istart = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart) + (idata-1)*net(id)%ninput_d

  do istate = threadidx%x, net(id)%ninput_d, 32
     tpvalue = hiddenstate_d( istart + istate)
     tpsum = tpsum + tpvalue
     tpsumsq = tpsumsq + tpvalue*tpvalue
  end do
  call syncthreads()

  istate = 1
  do while (istate<=16)
     tpvalue = __shfl_xor(tpsum,istate); tpsum = tpsum + tpvalue
     tpvalue = __shfl_xor(tpsumsq,istate); tpsumsq = tpsumsq + tpvalue
     istate = istate*2
  end do

  if ( threadidx%x == 1 ) then
     tpsum = tpsum/real(net(id)%ninput_d,kind=SD)
     tpsumsq = tpsumsq/real(net(id)%ninput_d,kind=SD)
     istate = layernormmeansigma_index_d(id) + 2*idata-1
     tpsumsq = sqrt(tpsumsq - tpsum*tpsum + 0.000001_SD)
     layernormmeansigma_d(istate:istate+1) = [tpsum,tpsumsq]
  end if

  tpsum = __shfl(tpsum,1); tpsumsq = __shfl(tpsumsq,1)

  idata = layernorminout_index_d(id) + (idata-1)*net(id)%ninput_d*2; tpsumsq = 1.0_SD/tpsumsq
  do istate = threadidx%x, net(id)%ninput_d, 32
     tpvalue = (hiddenstate_d(istart+istate) - tpsum)*tpsumsq
     layernorminout_d(idata+2*istate-1:idata+2*istate) = [hiddenstate_d(istart+istate), tpvalue]
     hiddenstate_d(istart+istate) = layernormweightbias_d(2*id-1)*tpvalue + layernormweightbias_d(2*id)
  end do

end subroutine

attributes(global) subroutine mlp0_network_forward_cuda_layer(id,ilayer)
  integer,intent(in),value :: id,ilayer
  integer :: istart,ileftstate,irightstate,nleftneuron,nrightneuron,ibias,il2l,irec
  real(kind=SD) :: tpstate,tpvalue

  nleftneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer-1)
  nrightneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer)
  irightstate = (blockidx%x-1)*blockdim%x+threadidx%x

  irec = (irightstate-1)/nrightneuron+1
  if ( irec > icudagroup_d ) return

  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1 ) return
  end if

  irightstate = irightstate - (irec-1)*nrightneuron

  istart = net(id)%mlplayers_index_d + id - 1
  ibias = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer-1) + (irec-1)*nleftneuron
  il2l = net(id)%weights_l2l_index_d + weights_l2l_index_d(istart+ilayer) - nrightneuron + irightstate

  tpstate = 0.0_SD
  do ileftstate = 1, nleftneuron
     tpstate = tpstate + hiddenstate_d(ibias+ileftstate)*weights_l2l_d(il2l + ileftstate*nrightneuron)
  end do
  ibias = (irec-1)*nrightneuron + irightstate
  hiddenstate_d( net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer) + ibias) = tpstate
end subroutine

attributes(global) subroutine mlp0_network_forward_cuda_biasact(id,ilayer)
  integer,intent(in),value :: id,ilayer
  integer :: istart,istate,nstate,ibias,irec
  real(kind=SD) :: tpstate,tpvalue,tpgrad

  istart = net(id)%mlplayers_index_d + id - 1
  nstate = mlplayers_d(net(id)%mlplayers_index_d + ilayer)
  ibias = (blockidx%x-1)*32+threadidx%x; irec = (ibias-1)/nstate+1; if ( irec > icudagroup_d ) return
  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1) return
  end if

  istate = ibias - (irec-1)*nstate
  tpstate = hiddenstate_d( net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer) + ibias)

  if ( net(id)%ifbias_d .eqv. .true. ) then
     tpstate = tpstate + bias_d(net(id)%bias_index_d + bias_index_d(istart+ilayer) + istate)
  end if
  if ( (ilayer < net(id)%nlayer_d) .or. (net(id)%iflastactivation_d .eqv. .true.) ) then
     tpvalue = tpstate
     call mlp0_activation_function_cuda(tpvalue,tpstate,tpgrad)

     if ( dropout_d > 0.0_SD ) then
        if ( deepntotdata_d > 0 ) then
           tpvalue = curand_uniform(curandState_d( net(id)%grad_active_index_d + grad_active_index_d(istart+ilayer) + ibias))
           if ( tpvalue < dropout_d ) then
              tpstate = 0.0_SD; tpgrad = 0.0_SD
           else
              tpstate = tpstate/(1.0_SD - dropout_d)
              tpgrad = tpgrad/(1.0_SD - dropout_d)
           end if
        else
           tpstate = tpstate*(1.0_SD - dropout_d); tpgrad = tpgrad*(1.0_SD - dropout_d)
        end if
     end if
     grad_active_d( net(id)%grad_active_index_d + grad_active_index_d(istart+ilayer) + ibias) = tpgrad
  end if
  hiddenstate_d( net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer) + ibias) = tpstate

end subroutine

subroutine mlp0_network_backward_cuda(this,ifcalloss,tpoutputs)
  class(mlptype), intent(inout) :: this
  logical,intent(in) :: ifcalloss
  real*8,intent(out),optional :: tpoutputs(:,:)
  integer :: ilayer,i,j
  real*8,allocatable :: tpvec(:)

  call mlp0_network_backward_cuda_outputlayer<<<(icudagroup*this%noutput-1)/32+1,32>>>(this%id,ifcalloss)

  do ilayer = this%nlayer-1, 1, -1
     if ( jobtype == TRAIN ) call mlp0_network_backward_cuda_gradweight<<<(this%mlplayers(ilayer)%neurons*this%mlplayers(ilayer+1)%neurons-1)/32+1,32>>>(this%id,ilayer)
     call mlp0_network_backward_cuda_layer<<<icudagroup*this%mlplayers(ilayer)%neurons,32>>>(this%id,ilayer)
     if ( ilayer > 1 ) call mlp0_network_backward_cuda_biasact<<<(icudagroup*this%mlplayers(ilayer)%neurons-1)/32+1,32>>>(this%id,ilayer)
  end do

  if ( this%iflayernorm .eqv. .true. ) call mlp0_network_backward_cuda_layernorm<<<icudagroup,32>>>(this%id)

  if ( present(tpoutputs) .eqv. .true. ) then
     i = this%hiddenstate_index(1)+1; j = this%hiddenstate_index(2)
     ilayer = net(this%id)%hiddenstate_index_d
     allocate(tpvec(this%delta_layer_index(2)-this%delta_layer_index(1)))
     tpvec = hiddenstate_d(ilayer+i:ilayer+j)    ! delta_layer
     tpoutputs(:,:) = reshape(tpvec,[this%ninput,icudagroup])
  end if

end subroutine

attributes(global) subroutine mlp0_network_backward_cuda_outputlayer(id,ifcalloss)
  integer,intent(in),value :: id
  logical,intent(in),value :: ifcalloss
  integer :: istate,index,irec,istart,hiddenpos
  real(kind=SD) :: tpvalue

  index = (blockidx%x-1)*32+threadidx%x
  irec = (index-1)/net(id)%noutput_d+1; if ( irec > icudagroup_d ) return

  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1 ) return
  end if

  istate = index - (irec-1)*net(id)%noutput_d
  istart = net(id)%mlplayers_index_d + id - 1 + net(id)%nlayer_d
  hiddenpos = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart) + index

  tpvalue = batchlabel_d(index)

  if ( ifcalloss .eqv. .true. ) then
     tpvalue = hiddenstate_d(hiddenpos) - tpvalue
     if ( lossfunctype_d == RMSE ) then
        irec = atomicadd(totloss_d, tpvalue**2)
     else if ( lossfunctype_d == MAE ) then
        irec = atomicadd(totloss_d,abs(tpvalue))
     end if
     tpvalue = 2_SD*tpvalue*labelcvweight_d(istate)
  end if

  if ( deepntotdata_d > 0 ) then
     if ( net(id)%iflastactivation_d .eqv. .true. ) then
        tpvalue = grad_active_d(net(id)%grad_active_index_d + grad_active_index_d(istart) + index)*tpvalue
     end if
     if ( jobtype_d == TRAIN ) then
        if ( net(id)%ifbias_d .eqv. .true. ) then
           irec = atomicadd( grad_bias_d( net(id)%bias_index_d + bias_index_d(istart) + istate), tpvalue)
        end if
     end if
     hiddenstate_d(hiddenpos) = tpvalue   ! delta_layer
  end if
end subroutine

attributes(global) subroutine mlp0_network_backward_cuda_gradweight(id,ilayer)
  integer,intent(in),value :: id,ilayer
  integer :: ileftstate,irightstate,nleftneuron,nrightneuron
  integer :: istart,istate,idelta,irec
  real(kind=SD) :: tpstate

  nleftneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer)
  nrightneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer+1)

  istate = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( istate > nleftneuron*nrightneuron ) return

  ileftstate = (istate-1)/nrightneuron + 1
  irightstate = istate - (ileftstate-1)*nrightneuron
  istart = net(id)%mlplayers_index_d + id - 1

  idelta = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer+1) + irightstate
  istate =  net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer) + ileftstate
  tpstate = 0.0_SD
  do irec = 1, icudagroup_d
     if ( allocated(errormark_d) ) then
        if ( errormark_d(irec) == 1 ) cycle
     end if
     tpstate = tpstate + hiddenstate_d(istate+(irec-1)*nleftneuron)*hiddenstate_d(idelta+(irec-1)*nrightneuron) ! delta_layer
  end do

  if ( jobtype_d == TRAIN ) then
     istate = net(id)%weights_l2l_index_d + weights_l2l_index_d(istart+ilayer+1) + (ileftstate-1)*nrightneuron
     ileftstate = atomicadd(grad_weights_l2l_d(istate + irightstate),tpstate)
  end if
end subroutine

attributes(global) subroutine mlp0_network_backward_cuda_layer(id,ilayer)
  integer,intent(in),value :: id,ilayer
  integer :: ileftstate,irightstate,nleftneuron,nrightneuron
  integer :: istart,istate,ibias,idelta,irec
  real(kind=SD) :: tpstate,tpvalue

  nleftneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer)
  nrightneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer+1)

  ileftstate = blockidx%x; irec = (ileftstate-1)/nleftneuron+1
  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1 ) return
  end if

  ileftstate = ileftstate - (irec-1)*nleftneuron
  istart = net(id)%mlplayers_index_d + id - 1
  idelta = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer+1) + (irec-1)*nrightneuron
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer) + (irec-1)*nleftneuron + ileftstate
  tpvalue = hiddenstate_d(istate)
  ibias = net(id)%weights_l2l_index_d + weights_l2l_index_d(istart+ilayer+1) + (ileftstate-1)*nrightneuron

  tpstate = 0.0_SD
  do irightstate = threadidx%x, nrightneuron, 32
     tpstate = tpstate + weights_l2l_d(ibias + irightstate)*hiddenstate_d(idelta+irightstate)                   ! delta_layer
  end do

  ibias = 1
  do while (ibias<=16)
     tpvalue = __shfl_xor(tpstate,ibias); tpstate = tpstate + tpvalue
     ibias = ibias*2
  end do

  if ( threadidx%x == 1 ) then
     hiddenstate_d(istate) = tpstate          ! delta_layer
  end if

end subroutine

attributes(global) subroutine mlp0_network_backward_cuda_biasact(id,ilayer)
  integer,intent(in),value :: id,ilayer
  integer :: istart,istate,nstate,ibias,irec
  real(kind=SD) :: tpstate

  istart = net(id)%mlplayers_index_d + id - 1
  nstate = mlplayers_d(net(id)%mlplayers_index_d + ilayer)
  ibias = (blockidx%x-1)*32+threadidx%x; irec = (ibias-1)/nstate+1; if ( irec > icudagroup_d ) return
  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1) return
  end if

  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart+ilayer) + ibias
  tpstate = hiddenstate_d(istate)    ! delta_layer
  tpstate = grad_active_d(net(id)%grad_active_index_d + grad_active_index_d(istart+ilayer) + ibias)*tpstate
  hiddenstate_d(istate) = tpstate    ! delta_layer

  if ( jobtype_d == TRAIN ) then
     if ( net(id)%ifbias_d .eqv. .true. ) then
        ibias = ibias - (irec-1)*nstate
        istate = atomicadd(grad_bias_d( net(id)%bias_index_d + bias_index_d(istart+ilayer) + ibias),tpstate)
     end if
  end if
end subroutine

attributes(global) subroutine mlp0_network_backward_cuda_layernorm(id)
  integer,intent(in),value :: id
  integer :: idata,istate,istart,inorminoutindex
  real(kind=SD) :: tpsum,tpsumsq,tpvalue,mean,sigma

  idata = blockidx%x

  istart = net(id)%mlplayers_index_d + id
  istart = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart) + (idata-1)*net(id)%ninput_d
  inorminoutindex = layernorminout_index_d(id)+(idata-1)*net(id)%ninput_d*2

  istate = layernormmeansigma_index_d(id) + 2*idata-1
  mean = layernormmeansigma_d(istate) 
  sigma = layernormmeansigma_d(istate+1)

  tpsum = 0.0_SD; tpsumsq = 0.0_SD
  do istate = threadidx%x, net(id)%ninput_d, 32
     tpvalue = hiddenstate_d(istart + istate)     ! delta_layer
     tpsum = tpsum + tpvalue
     tpsumsq = tpsumsq + tpvalue*(layernorminout_d(inorminoutindex+2*istate))   ! delta_layer
  end do
  
  istate = 1
  do while (istate<=16)
     tpvalue = __shfl_xor(tpsum,istate); tpsum = tpsum + tpvalue
     tpvalue = __shfl_xor(tpsumsq,istate); tpsumsq = tpsumsq + tpvalue
     istate = istate*2
  end do

  call syncthreads()

  sigma = 1.0_SD/(real(net(id)%ninput_d,SD)*sigma)
  do istate = threadidx%x, net(id)%ninput_d, 32
     tpvalue = sigma*(hiddenstate_d(istart+istate)*real(net(id)%ninput_d,SD) - tpsum - layernorminout_d(inorminoutindex+2*istate)*tpsumsq)
     hiddenstate_d(istart+istate) = tpvalue    ! delta_layer
  end do

end subroutine

attributes(global) subroutine mlp0_network_backward_cuda_layernorm_nolayerweightbias(id)
  integer,intent(in),value :: id
  integer :: idata,istate,istart,inorminoutindex
  real(kind=SD) :: tpsum,tpsumsq,tpvalue,mean,sigma

  idata = blockidx%x

  istart = net(id)%mlplayers_index_d + id
  istart = net(id)%hiddenstate_index_d + hiddenstate_index_d(istart) + (idata-1)*net(id)%ninput_d
  inorminoutindex = layernorminout_index_d(id)+(idata-1)*net(id)%ninput_d*2

  istate = layernormmeansigma_index_d(id) + 2*idata-1
  mean = layernormmeansigma_d(istate)
  sigma = layernormmeansigma_d(istate+1)

  tpsum = 0.0_SD
  tpsumsq = 0.0_SD
  do istate = threadidx%x, net(id)%ninput_d, 32
     tpvalue = hiddenstate_d(istart + istate)     ! delta_layer
     tpsum = tpsum + tpvalue
     tpsumsq = tpsumsq + tpvalue*layernorminout_d(inorminoutindex+2*istate)
     hiddenstate_d(istart + istate) = tpvalue*layernormweightbias_d(2*id-1)    ! delta_layer
  end do

  istate = 1
  do while (istate<=16)
     tpvalue = __shfl_xor(tpsum,istate); tpsum = tpsum + tpvalue
     tpvalue = __shfl_xor(tpsumsq,istate); tpsumsq = tpsumsq + tpvalue
     istate = istate*2
  end do

  call syncthreads()

  if ( jobtype_d == TRAIN ) then
     if ( threadidx%x == 1 ) then
        tpvalue = atomicadd( grad_layernormweightbias_d(2*id-1), tpsumsq)
        tpvalue = atomicadd( grad_layernormweightbias_d(2*id), tpsum)
     end if
  end if

  tpsumsq = 0.0_SD
  do istate = threadidx%x, net(id)%ninput_d, 32
     tpsumsq = tpsumsq + hiddenstate_d(istart + istate)*( layernorminout_d(inorminoutindex+2*istate-1) - mean )   ! delta_layer
  end do

  istate = 1
  do while (istate<=16)
     tpvalue = __shfl_xor(tpsumsq,istate); tpsumsq = tpsumsq + tpvalue
     istate = istate*2
  end do

  call syncthreads()

  tpsumsq = tpsumsq/(sigma*sigma)
  sigma = 1.0_SD/(real(net(id)%ninput_d,SD)*sigma)
  do istate = threadidx%x, net(id)%ninput_d, 32
     tpvalue = sigma* &
           ( hiddenstate_d(istart+istate)*real(net(id)%ninput_d,SD) - tpsum -               &     ! delta_layer
               (layernorminout_d(inorminoutindex+2*istate-1) - mean)*tpsumsq )
     if ( abs(tpvalue) < 0.0000001_SD ) tpvalue = 0.0_SD
     hiddenstate_d(istart+istate) = tpvalue    ! delta_layer
  end do

end subroutine

!========================================================================

!======================================= mlp flooding ==============================

subroutine mlp0_flooding_backward(this, bout, bin, errormark)
  class(mlptype), intent(inout) :: this
  real*8 :: bout(:,:,:), bin(:,:)
  integer,dimension(:),optional :: errormark
  integer :: ilayer,idata

  do idata = 1, size(bout,2)
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     this%mlplayers(this%nlayer)%hiddenstate(:,idata,1,1) = bout(:,idata,1)
     do ilayer = this%nlayer-1,1,-1
        this%mlplayers(ilayer)%hiddenstate(:,idata,1,1) = matmul(transpose(this%mlplayers(ilayer+1)%weights_l2l(:,:)),this%mlplayers(ilayer+1)%hiddenstate(:,idata,1,1))
        if ( ilayer >= 2 ) then
            this%mlplayers(ilayer)%hiddenstate(:,idata,1,1) = this%mlplayers(ilayer)%hiddenstate(:,idata,1,1)*this%mlplayers(ilayer)%grad_active(:,idata,1,1)
        end if
     end do
     bin(:,idata) = this%mlplayers(1)%hiddenstate(:,idata,1,1)
  end do

end subroutine

subroutine mlp0_flooding_forward(this, bin, errormark)
  class(mlptype), intent(inout) :: this
  real*8,dimension(:,:,:) :: bin
  integer,dimension(:),optional :: errormark
  integer :: ilayer,idata,istate,tpnum
  real*8 :: tpsum,tpsigma,tpmean,tpnormin

  do idata = 1, size(bin,2)
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     this%mlplayers(1)%delta_layer(:) = 0.0d0
     this%mlplayers(1)%delta_layer(1:this%ninput) = 2.0d0*gradcvweight*(this%mlplayers(1)%hiddenstate(1:this%ninput,idata,1,1)-bin(1:this%ninput,idata,1))
     do ilayer = 2, this%nlayer
        call deeppub_matmul_outer_product(this%mlplayers(ilayer)%grad_weights_l2l(:,:),  &
             this%mlplayers(ilayer)%hiddenstate(:,idata,1,1),this%mlplayers(ilayer-1)%delta_layer(:))
        this%mlplayers(ilayer)%delta_layer(:) = &
             matmul(this%mlplayers(ilayer)%weights_l2l(:,:),this%mlplayers(ilayer-1)%delta_layer(:))
        if ( ilayer == this%nlayer ) exit
        this%mlplayers(ilayer)%delta_layer(:) = this%mlplayers(ilayer)%delta_layer(:)*this%mlplayers(ilayer)%grad_active(:,idata,1,1)
     end do
  end do
end subroutine

subroutine mlp0_flooding_backward_cuda(this,tpgrads)
  class(mlptype), intent(inout) :: this
  real*8,intent(out),optional :: tpgrads(:,:,:)
  integer :: ilayer,i,j
  real*8 :: tpvec(this%hiddenstate_index(2)-this%hiddenstate_index(1))

  call mlp0_flooding_backward_cuda_outputlayer<<<(icudagroup*this%noutput-1)/32+1,32>>>(this%id)

  do ilayer = this%nlayer-1, 1, -1
     call mlp0_flooding_backward_cuda_layer<<<icudagroup*this%mlplayers(ilayer)%neurons,32>>>(this%id,ilayer)
  end do

  if ( present(tpgrads) ) then
     i = this%hiddenstate_index(1)+1
     j = this%hiddenstate_index(2)
     ilayer = net(this%id)%hiddenstate_index_d
     tpvec = hiddenstate_d(ilayer+i:ilayer+j)
     tpgrads(:,:,:) = reshape(tpvec,[this%ninput,icudagroup,1])
  end if
end subroutine

attributes(global) subroutine mlp0_flooding_backward_cuda_outputlayer(id)
  integer,intent(in),value :: id
  integer :: istate,irec

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/net(id)%noutput_d+1; if ( irec > icudagroup_d ) return

  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1 ) return
  end if
  irec = net(id)%mlplayers_index_d + id - 1
  hiddenstate_d(net(id)%delta_layer_index_d + delta_layer_index_d(irec+net(id)%nlayer_d) + istate) = 1.0_SD
end subroutine

attributes(global) subroutine mlp0_flooding_backward_cuda_layer(id,ilayer)
  integer,intent(in),value :: ilayer,id
  integer :: ileftstate,irightstate,nleftneuron,nrightneuron
  integer :: istart,istate,ibias,idelta,nlayer,irec
  real(kind=SD) :: tpstate,tpvalue

  nlayer = net(id)%nlayer_d; tpstate = 0.0_SD

  nleftneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer)
  nrightneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer+1)

  ileftstate = blockidx%x; irec = (ileftstate-1)/nleftneuron+1
  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1 ) return
  end if
  ileftstate = ileftstate - (irec-1)*nleftneuron
  istart = net(id)%mlplayers_index_d + id - 1

  if ( ileftstate <= nleftneuron ) then
     idelta = net(id)%delta_layer_index_d + delta_layer_index_d(istart+ilayer+1) + (irec-1)*nrightneuron
     ibias = net(id)%weights_l2l_index_d + weights_l2l_index_d(istart+ilayer+1) + (ileftstate-1)*nrightneuron
     do irightstate = threadidx%x, nrightneuron, 32
        tpstate = tpstate + weights_l2l_d(ibias + irightstate)*hiddenstate_d(idelta+irightstate)
     end do
  end if

  ibias = 1
  do while (ibias<=16)
     tpvalue = __shfl_xor(tpstate,ibias); tpstate = tpstate + tpvalue
     ibias = ibias*2
  end do

  if ( threadidx%x == 1 ) then
     idelta = (irec-1)*nleftneuron + ileftstate
     if ( ilayer > 1 ) then
        istate = net(id)%grad_active_index_d + grad_active_index_d(istart+ilayer) + idelta
        tpstate = tpstate*grad_active_d(istate)
     end if
     hiddenstate_d( net(id)%delta_layer_index_d + delta_layer_index_d(istart+ilayer) + idelta) = tpstate
  end if
end subroutine

subroutine mlp0_flooding_forward_cuda(this)
  class(mlptype), intent(inout) :: this
  integer :: ilayer

  call mlp0_flooding_forward_cuda_inputlayer<<<(icudagroup*this%ninput-1)/32+1,32>>>(this%id)

  do ilayer = 2, this%nlayer
     call mlp0_flooding_forward_cuda_layer<<<icudagroup*this%mlplayers(ilayer)%neurons,32>>>(this%id,ilayer)
  end do
end subroutine

attributes(global) subroutine mlp0_flooding_forward_cuda_inputlayer(id)
  integer,intent(in),value :: id
  integer :: istart,istate,index,irec,ninput
  real(kind=SD) :: netinput,tpvalue

  ninput = net(id)%ninput_d
  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/ninput+1; if ( irec > icudagroup_d ) return
  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1 ) return
  end if
  index = istate; istate = istate - (irec-1)*ninput; if ( istate > ninput ) return

  istart = net(id)%mlplayers_index_d + id - 1
  istart = net(id)%delta_layer_index_d + delta_layer_index_d(istart+1) + index
  netinput = hiddenstate_d(istart)

  tpvalue = 0.0_SD
  if ( istate <= ngradcv_d ) then
     tpvalue = netinput - batchgraddata_d((irec-1)*ninput + istate)
  end if

  if ( deepntotdata_d > 0 ) then
     hiddenstate_d(istart) = 2_SD*tpvalue*gradcvweight_d
  end if

  if ( istate > ngradcv_d ) return

  if ( lossfunctype_d == RMSE ) then
     irec = atomicadd(gradtotloss_d,tpvalue*tpvalue)
  else if ( lossfunctype_d == MAE ) then
     irec = atomicadd(gradtotloss_d,abs(tpvalue))
  end if
end subroutine

attributes(global) subroutine mlp0_flooding_forward_cuda_layer(id,ilayer)
  integer,intent(in),value :: ilayer,id
  integer :: istart,istate,ileftstate,irightstate,nleftneuron,nrightneuron,idelta,il2l,irec
  real(kind=SD) :: tpstate,tpvalue,tpgrad

  nleftneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer-1)
  nrightneuron = mlplayers_d(net(id)%mlplayers_index_d + ilayer)
  tpstate = 0.0_SD

  irightstate = blockidx%x; irec = (irightstate-1)/nrightneuron+1
  if ( allocated(errormark_d) ) then
     if ( errormark_d(irec) == 1 ) return
  end if
  irightstate = irightstate - (irec-1)*nrightneuron

  istart = net(id)%mlplayers_index_d + id - 1
  idelta = net(id)%delta_layer_index_d + delta_layer_index_d(istart+ilayer-1) + (irec-1)*nleftneuron
  il2l = net(id)%weights_l2l_index_d + weights_l2l_index_d(istart+ilayer) - nrightneuron + irightstate

  tpgrad = hiddenstate_d(net(id)%delta_layer_index_d + delta_layer_index_d(istart+ilayer) + (irec-1)*nrightneuron + irightstate)
  do ileftstate = threadidx%x, nleftneuron, 32
     tpvalue = hiddenstate_d(idelta+ileftstate)
     istate = il2l + ileftstate*nrightneuron
     tpstate = tpstate + tpvalue*weights_l2l_d(istate)
     tpvalue = atomicadd( grad_weights_l2l_d(istate), tpvalue*tpgrad )
  end do

  istate = 1
  do while (istate<=16)
     tpvalue = __shfl_xor(tpstate,istate); tpstate = tpstate + tpvalue
     istate = istate*2
  end do

  if ( threadidx%x == 1 ) then
     istate = (irec-1)*nrightneuron + irightstate
     if ( ilayer < net(id)%nlayer_d ) then
        tpstate = tpstate*grad_active_d(net(id)%grad_active_index_d + grad_active_index_d(istart+ilayer) + istate)
     end if
     hiddenstate_d(net(id)%delta_layer_index_d + delta_layer_index_d(istart+ilayer) + istate) = tpstate
  end if

end subroutine

attributes(device) subroutine mlp0_activation_function_cuda(x,y,dy)
  real(kind=SD),intent(in) :: x
  real(kind=SD),intent(out) :: y
  real(kind=SD),intent(out),optional :: dy
  select case(activefunctype_d)
    case (SIGM)
       y = 1_SD/(1_SD+exp(-x)); if ( present(dy) ) dy = y*(1_SD-y)
    case (TANH)
       y = 1_SD - 2_SD/(1_SD+exp(2_SD*x)); if ( present(dy) ) dy = 1_SD - y*y
    case (RELU)
       y = 0.5_SD*(x+abs(x)); if ( present(dy) ) dy = abs(x>0.0_SD)
    case (LEAKYRELU) ! Leaky ReLU
       y = 0.01_SD*x
       if (x > 0_SD) y = x
       if ( present(dy) ) then
          dy = 0.01_SD
          if (x > 0_SD) dy = 1_SD
       end if
    case (SELU)
       y = 1.75809933988_SD*(exp(x) - 1_SD)
       if ( x > 0_SD ) y = 1.050700987_SD*x
       if ( present(dy) ) then
          dy = y + 1.75809933988_SD
          if (x > 0_SD ) dy = 1.050700987_SD
       end if
    case (ARCTAN) ! Tan-1(x)
       y = atan(x)
       if ( present(dy) ) dy = 1_SD/(x*x + 1_SD)
    case (SYMSIGM) ! Symmetrical Sigmoid
       y = 1_SD - 2_SD/(1_SD+exp(x))
       if ( present(dy) ) dy = 0.5_SD*(1_SD-y*y)
    case (LOGLOG)
       y = 1_SD - exp(-exp(x))
       if ( present(dy) ) dy = exp(x - exp(x))
    case (GAUSSIAN)
       y = exp(-x*x)
       if ( present(dy) ) dy = -2_SD*x*y
    case (SILU)
       y = 1_SD/(1_SD+exp(-x))
       if ( present(dy) ) dy = y + x*y*(1_SD-y)
       y = x*y
  end select
end subroutine

end module
