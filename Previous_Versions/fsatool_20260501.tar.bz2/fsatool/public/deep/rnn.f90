module rnn
  use deeppub
  use deep
  use mlp
  implicit none

contains

subroutine rnn_go(parmfile)
  character(len=*),intent(in) :: parmfile
  integer :: ilen,iofile,ierr
  character*100 :: task
  namelist / deep / task

  open(newunit=iofile,file=parmfile,action="read")
  read(iofile, nml=deep, iostat=ierr); if ( ierr < 0 ) stop "Cannot find the deep namelist!"
  close(iofile)

  ilen = len(trim(task))
  if ( task(ilen-4:ilen) == "train" ) then
     jobtype = TRAIN
  else if ( task(ilen-6:ilen) == "predict" ) then
     jobtype = PREDICT
  else if ( task(ilen-4:ilen) == "check" ) then
     jobtype = CHECK
  end if

  maxnsteps = 0
  call deep_initialize(parmfile)

  call mlp_initialize(ninput,noutput,nlayer,layers,totparms,tpoutputweight=labelcvweight)
  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms

  if ( noutput /= ninput ) stop "RNN error, noutput /= niniput!"
  if ( bptt_trun == 1 ) then
     bptt_trun = maxnsteps
  else if ( bptt_trun > maxnsteps ) then
     stop "bptt_trun cannot be larger than time steps!"
  end if

  select case(jobtype)
  case (TRAIN)
     call rnn_train()
  case (PREDICT)
     call rnn_predict()
  case (CHECK)
     call rnn_check_grad()
  end select
end subroutine

!========================= RNN Network Training and Prediction ====================================

! Train the RNN network by the mini-batch gradient descent method
subroutine rnn_train()
  integer,dimension(:),allocatable :: shuffleidx
  integer :: index,ibatch,iepoch,idata,istep,realidata,errormark(batchsize),tpgroupindex,tpbatchindex
  real*8 :: loss,totloss,tpinputs(ninput,batchsize,maxnsteps),tpoutputs(noutput,batchsize,maxnsteps),tptrueoutputs(noutput,batchsize,maxnsteps),time1,time2
  real*8 :: initime,endtime
  real :: rand

  print "(/,a)","RNN Training Data"

  allocate(shuffleidx(deepntotdata-ntau))
  do idata = 1,deepntotdata-ntau
     shuffleidx(idata) = idata
  end do

  call deeppub_time_from_1970(initime)
  do iepoch = 1,nepoch

     ! shuffling the data
     do idata = deepntotdata-ntau, 2, -1
        call random_number(rand); index = int(rand * idata) + 1
        realidata = shuffleidx(index); shuffleidx(index) = shuffleidx(idata); shuffleidx(idata) = realidata
     end do

     totloss =  0d0; ibatch = 0; tpbatchindex = 0; tpgroupindex = 0; errormark = 0
     do idata = 1, deepntotdata

        tpbatchindex = tpbatchindex + 1
        tpgroupindex = tpgroupindex + 1

        realidata = shuffleidx(idata)

        do istep = 1, maxnsteps
           if ( realidata+istep > deepntotdata ) then
              errormark(tpgroupindex)=1; exit
           end if
           if ( deeptrajindex(realidata+istep-1) /= deeptrajindex(realidata+istep) ) then
              errormark(tpgroupindex)=1; exit
           end if
           tpinputs(:,tpgroupindex,istep) = deeptrajcoor(:,realidata+istep-1)
           tptrueoutputs(:,tpgroupindex,istep) = deeptrajcoor(:,realidata+istep)
        end do

        if ( tpgroupindex == batchsize .or. idata == deepntotdata ) then
           if ( tpgroupindex < batchsize ) errormark(tpgroupindex+1:batchsize) = 1
           call mlp_network_forward(1,tpinputs,tpoutputs,errormark=errormark)
           call mlp_network_backward_bptt(1,tptrueoutputs,.true.,errormark=errormark)
           loss = 0d0
           do index = 1, batchsize
              if ( errormark(index) == 1 ) cycle
              do istep=1, maxnsteps
                 loss = loss + sum((tptrueoutputs(:,index,istep) - tpoutputs(:,index,istep))**2)
              end do
           end do
           totloss = totloss + loss
           errormark = 0; tpgroupindex = 0
        end if

        if ( tpbatchindex == batchsize .or. idata == deepntotdata ) then
           call mlp_network_update(); tpbatchindex = 0
           ibatch = ibatch + 1; if ( ibatch == batchnum ) exit
        end if

     end do

     index = min(batchsize*batchnum, deepntotdata)

     ! print "(a,i8,1000f15.8)","Epoch ",iepoch,sqrt(totloss/dble(index))
     call deeppub_time_from_1970(endtime)
     if (mod(iepoch,20)==0) call deeppub_print_time(6,(endtime-initime),iepoch,dble(iepoch)/dble(nepoch))

  end do

  print "(/,a,f20.15)","Final Loss Function ",sqrt(totloss/dble(index))
  call deep_network_save()
  call mlp_network_save()
end subroutine

subroutine rnn_predict()
  integer :: iofile,istart,iend,idata,istep,index
  real*8 :: tpinputs(ninput,1,maxnsteps),tpoutputs(noutput,1,maxnsteps)

  print "(/,a)","RNN Testing Data"

  do istep = 1, maxnsteps
     tpinputs(:,1,istep) = deeptrajcoor(:,istep)
  end do

  open(newunit=iofile,file="predict.txt",action="write")
  do idata = 1, deepntotdata - maxnsteps
     istart = idata; iend = idata + maxnsteps - 1
     if ( .false. .and. idata > maxnsteps ) then
        tpinputs(:,1,1:maxnsteps) = tpoutputs(:,1,1:maxnsteps)
     else
        do istep = istart, iend
           tpinputs(:,1,istep-istart+1) = deeptrajcoor(:,istep)
        end do
     end if
     call mlp_network_forward(1,tpinputs,tpoutputs)
     write(iofile,'(f12.3,10f15.8)') dble(iend+1)*timestepsize,deeptrajcoor(:,iend+1),tpoutputs(:,1,maxnsteps)
  end do
  close(iofile)
end subroutine

subroutine rnn_check_grad()
  integer :: ilayer,idata,istep,i,j,ipos
  real*8 :: upv,downv,h,originv,refgrad,maxerr
  real*8 :: tpinputs(ninput,batchsize,maxnsteps),tpoutputs(ninput,batchsize,maxnsteps),tptrueoutputs(ninput,batchsize,maxnsteps)

  ! set the inputs and calculate the output values of neurons in all the layers
  do idata = 1, batchsize
     do istep = 1, maxnsteps
        tpinputs(:,idata,istep) = deeptrajcoor(:,idata+istep-1)
     end do
  end do
  call mlp_network_forward(1,tpinputs,tpoutputs)
  ! calculate the gradients in all the layers, gradients, grad_weights_l2l, grad_weights_t2t, grad_bias
  do idata = 1, batchsize
     do istep = 1, maxnsteps
        tpoutputs(:,idata,istep) = deeptrajcoor(:,idata+istep)
     end do
  end do
  call mlp_network_backward_bptt(1,tpoutputs,.true.)

  ! set the inputs again
  do idata = 1, batchsize
     do istep = 1, maxnsteps
        tpinputs(:,idata,istep) = deeptrajcoor(:,idata+istep-1)
        tptrueoutputs(:,idata,istep) = deeptrajcoor(:,idata+istep)
     end do
  end do
  h = 0.001d0; maxerr = 0d0
  do ilayer = nlayer,2,-1

     do i = 1, mlplayers(ilayer)%neurons
        do j = 1, mlplayers(ilayer-1)%neurons
           originv = mlplayers(ilayer)%weights_l2l(i,j)
           mlplayers(ilayer)%weights_l2l(i,j) = originv + h
           call get_loss(upv)
           mlplayers(ilayer)%weights_l2l(i,j) = originv - h
           call get_loss(downv)
           refgrad = (upv-downv)/(2d0*h)
           maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_weights_l2l(i,j)-refgrad))
           mlplayers(ilayer)%weights_l2l(i,j) = originv
        end do
     end do

     do i = 1,mlplayers(ilayer)%neurons
        originv = mlplayers(ilayer)%bias(i)
        mlplayers(ilayer)%bias(i) = originv + h
        call get_loss(upv)
        mlplayers(ilayer)%bias(i) = originv - h
        call get_loss(downv)
        refgrad = (upv-downv)/(2d0*h)
        maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_bias(i)-refgrad))
        mlplayers(ilayer)%bias(i) = originv
     end do

     do i = 1, mlplayers(ilayer)%neurons
        do j = 1, mlplayers(ilayer)%neurons
           originv = mlplayers(ilayer)%weights_t2t(i,j)
           mlplayers(ilayer)%weights_t2t(i,j) = originv + h
           call get_loss(upv)
           mlplayers(ilayer)%weights_t2t(i,j) = originv - h
           call get_loss(downv)
           mlplayers(ilayer)%weights_t2t(i,j) = originv
           refgrad = (upv-downv)/(2d0*h)
           maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_weights_t2t(i,j)-refgrad))
           mlplayers(ilayer)%weights_t2t(i,j) = originv
        end do
     end do

  end do

  print "(a,f20.15)","RNN Network Gradient Error:" ,maxerr

contains

subroutine get_loss(tploss)
  real*8,intent(out) :: tploss

  call mlp_network_forward(1,tpinputs,tpoutputs)
  tploss = 0d0
  do idata = 1, batchsize
     do istep=1, maxnsteps
        tploss = tploss + sum((tptrueoutputs(:,idata,istep) - tpoutputs(:,idata,istep))**2)
     end do
  end do
end subroutine
end subroutine

end module
