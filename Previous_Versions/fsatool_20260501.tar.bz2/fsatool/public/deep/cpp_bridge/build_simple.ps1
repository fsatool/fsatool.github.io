try {
    gcc -c src/cJSON.c -o cJSON.o -Isrc -Wall -O2
    g++ -c src/http_bridge.cpp -o http_bridge.o -Isrc -std=c++11 -Wall -O2
    ar rcs build/libhttp_bridge.a http_bridge.o cJSON.o
    Remove-Item *.o -ErrorAction SilentlyContinue
} catch {
    Write-Host "`nBuild failed." -ForegroundColor Red
    exit 1
}