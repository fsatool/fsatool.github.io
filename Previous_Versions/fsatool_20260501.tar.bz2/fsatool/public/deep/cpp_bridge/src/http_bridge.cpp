// http_bridge.cpp - 实现文件
#include "http_bridge.h"
#include <iostream>
#include <cstring>
#include <vector>
#include <sstream>
#include <curl/curl.h>
#include "cJSON.h" 

// 内存回调结构体，用于存储HTTP响应
struct MemoryStruct {
    char* memory;
    size_t size;
};

// 回调函数，用于libcurl写入响应数据
static size_t WriteMemoryCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t realsize = size * nmemb;
    struct MemoryStruct* mem = (struct MemoryStruct*)userp;
    
    char* ptr = (char*)realloc(mem->memory, mem->size + realsize + 1);
    if (!ptr) {
        std::cerr << "memory allocation failed!" << std::endl;
        return 0;
    }
    
    mem->memory = ptr;
    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;
    
    return realsize;
}

/**
 * @brief 内部函数：构建JSON请求体
 */
static std::string build_json_request(
    const int* z, int z_len,
    const double* pos,
    const int* edge_index, int edge_len,
    const int* batch
) {
    std::stringstream ss;
    
    // 开始构建JSON
    ss << "{";
    
    // 1. 添加原子类型数组 z
    ss << "\"z\":[";
    for (int i = 0; i < z_len; ++i) {
        ss << z[i];
        if (i < z_len - 1) ss << ",";
    }
    ss << "],";
    
    // 2. 添加原子坐标数组 pos
    ss << "\"pos\":[";
    for (int i = 0; i < z_len; ++i) {
        ss << "[";
        ss << pos[i * 3] << "," << pos[i * 3 + 1] << "," << pos[i * 3 + 2];
        ss << "]";
        if (i < z_len - 1) ss << ",";
    }
    ss << "],";
    
    // 3. 添加边索引数组 edge_index
    // 注意：Python端期望的是[[源节点列表], [目标节点列表]]格式
    ss << "\"edge_index\":[";
    
    // 第一维：源节点
    ss << "[";
    for (int i = 0; i < edge_len; ++i) {
        ss << edge_index[i];  // 源节点
        if (i < edge_len - 1) ss << ",";
    }
    ss << "],";
    
    // 第二维：目标节点
    ss << "[";
    for (int i = 0; i < edge_len; ++i) {
        ss << edge_index[edge_len + i];  // 目标节点
        if (i < edge_len - 1) ss << ",";
    }
    ss << "]";
    
    ss << "],";
    
    // 4. 添加批次数组 batch
    ss << "\"batch\":[";
    for (int i = 0; i < z_len; ++i) {
        ss << batch[i];
        if (i < z_len - 1) ss << ",";
    }
    ss << "]";
    
    ss << "}";
    
    return ss.str();
}

/**
 * @brief 内部函数：解析JSON响应
 */
static int parse_json_response(
    const char* response,
    double* force_output,
    double* energy_output,
    int z_len,
    int max_molecules
) {
    cJSON* root = cJSON_Parse(response);
    if (!root) {
        std::cerr << "JSON parse failed: " << cJSON_GetErrorPtr() << std::endl;
        return -1;
    }
    
    // 检查状态
    cJSON* status = cJSON_GetObjectItem(root, "status");
    if (!status || strcmp(status->valuestring, "success") != 0) {
        std::cerr << "API returned error status: " << status->valuestring << std::endl;
        cJSON_Delete(root);
        return -2;
    }
    
    // 解析力数组
    cJSON* force_array = cJSON_GetObjectItem(root, "force");
    if (!force_array || !cJSON_IsArray(force_array)) {
        std::cerr << "cannot parse force array" << std::endl;
        cJSON_Delete(root);
        return -3;
    }
    
    int force_size = cJSON_GetArraySize(force_array);
    if (force_size != z_len) {
        std::cerr << "force array size mismatch: expected " << z_len << ", got " << force_size << std::endl;
        cJSON_Delete(root);
        return -4;
    }
    
    // 提取力数据
    for (int i = 0; i < force_size; ++i) {
        cJSON* force_vec = cJSON_GetArrayItem(force_array, i);
        if (!force_vec || !cJSON_IsArray(force_vec) || cJSON_GetArraySize(force_vec) != 3) {
            std::cerr << "force vector format error at index " << i << std::endl;
            cJSON_Delete(root);
            return -5;
        }
        
        cJSON* fx = cJSON_GetArrayItem(force_vec, 0);
        cJSON* fy = cJSON_GetArrayItem(force_vec, 1);
        cJSON* fz = cJSON_GetArrayItem(force_vec, 2);
        
        force_output[i * 3] = fx->valuedouble;
        force_output[i * 3 + 1] = fy->valuedouble;
        force_output[i * 3 + 2] = fz->valuedouble;
    }
    
    // 解析能量数组（期望 server 返回每项为 number，若是单元素数组也支持）
    cJSON* energy_array = cJSON_GetObjectItem(root, "energy");

    if (!energy_array || !cJSON_IsArray(energy_array)) {
        std::cerr << "cannot parse energy array: " << std::endl;
        cJSON_Delete(root);
        return -6;
    }

    int energy_size = cJSON_GetArraySize(energy_array);
    if (energy_size > max_molecules) {
        std::cerr << "energy array size out of range: " << energy_size << " > " << max_molecules << std::endl;
        cJSON_Delete(root);
        return -7;
    }

    // 提取能量数据（优先处理 number；若元素为单元素数组则取其第0项；若为string则 atof）
    for (int i = 0; i < energy_size; ++i) {
        cJSON* energy_val = cJSON_GetArrayItem(energy_array, i);
        double val = 0.0;

        if (energy_val == NULL) {
            val = 0.0;
        } else if (cJSON_IsNumber(energy_val)) {
            val = energy_val->valuedouble;
        } else if (cJSON_IsArray(energy_val) && cJSON_GetArraySize(energy_val) > 0) {
            cJSON* inner0 = cJSON_GetArrayItem(energy_val, 0);
            if (inner0) {
                if (cJSON_IsNumber(inner0)) {
                    val = inner0->valuedouble;
                } else if (cJSON_IsString(inner0) && inner0->valuestring) {
                    val = atof(inner0->valuestring);
                }
            }
        } else if (cJSON_IsString(energy_val) && energy_val->valuestring) {
            val = atof(energy_val->valuestring);
        } else {
            val = 0.0;
        }

        energy_output[i] = val;
    }
    
    cJSON_Delete(root);
    return energy_size;  // 返回实际分子数量
}

/**
 * @brief 主预测函数
 */
int predict_molecules(
    const char* url,
    const int* z, int z_len,
    const double* pos,
    const int* edge_index, int edge_len,
    const int* batch, int batch_len,
    double* force_output,
    double* energy_output,
    int max_molecules
) {
    // 参数检查
    if (z_len <= 0 || edge_len <= 0 || batch_len != z_len) {
        std::cerr << "parameter error: z_len=" << z_len 
                  << ", edge_len=" << edge_len 
                  << ", batch_len=" << batch_len << std::endl;
        return -1;
    }
    
    CURL* curl;
    CURLcode res;
    struct MemoryStruct chunk;
    
    // 初始化内存结构
    chunk.memory = (char*)malloc(1);
    chunk.size = 0;
    
    if (!chunk.memory) {
        std::cerr << "memory allocation failed!" << std::endl;
        return -2;
    }
    
    // 初始化libcurl
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    
    if (!curl) {
        std::cerr << "cannot initialize libcurl" << std::endl;
        free(chunk.memory);
        return -3;
    }
    
    // 构建JSON请求体
    std::string json_body = build_json_request(z, z_len, pos, edge_index, edge_len, batch);
    
    // 调试：打印请求体（生产环境应移除）
//    std::cout << "sending request to: " << url << std::endl;
//    std::cout << "request json size: " << json_body.size() << " bytes" << std::endl;
    
    // 设置HTTP头
    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    
    // 设置libcurl选项
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, json_body.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)&chunk);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);  // 30秒超时
    
    // 执行请求
    res = curl_easy_perform(curl);
    
    int ret_code = 0;
    
    if (res != CURLE_OK) {
        std::cerr << "HTTP request failed: " << curl_easy_strerror(res) << std::endl;
        ret_code = -4;
    } else {
        // 获取HTTP状态码
        long http_code = 0;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
        
        if (http_code != 200) {
            std::cerr << "HTTP error: " << http_code << std::endl;
            std::cerr << "response: " << chunk.memory << std::endl;
            ret_code = -5;
        } else {
            // 解析响应
            int num_molecules = parse_json_response(
                chunk.memory, force_output, energy_output, z_len, max_molecules
            );
            
            if (num_molecules < 0) {
                ret_code = num_molecules;  // 解析错误
            } else {
//                std::cout << "prediction success! num_molecules: " << num_molecules << std::endl;
                ret_code = num_molecules;  // 返回分子数量
            }
        }
    }
    
    // 清理
    curl_easy_cleanup(curl);
    curl_slist_free_all(headers);
    free(chunk.memory);
    curl_global_cleanup();
    
    return ret_code;
}