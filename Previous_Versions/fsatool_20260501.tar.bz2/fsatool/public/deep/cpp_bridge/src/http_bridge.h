// http_bridge.h - 头文件
#ifndef HTTP_BRIDGE_H
#define HTTP_BRIDGE_H

#include <string>
#include <vector>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 调用Python微服务进行分子模拟预测
 * 
 * @param url Python微服务的URL（例如："http://localhost:8000/predict"）
 * @param z 原子类型数组（原子序数）
 * @param z_len 原子类型数组长度
 * @param pos 原子坐标数组，形状为[z_len * 3]，按[x1,y1,z1, x2,y2,z2, ...]顺序
 * @param edge_index 边索引数组，形状为[2 * edge_len]，按[src1,src2,..., dst1,dst2,...]顺序
 * @param edge_len 边的数量（注意：edge_index的长度是2 * edge_len）
 * @param batch 批次数组，指示每个原子属于哪个分子
 * @param batch_len 批次数组长度（应等于z_len）
 * @param force_output 输出：力数组，形状与pos相同[z_len * 3]
 * @param energy_output 输出：能量数组，每个分子一个能量值
 * @param max_molecules 最大分子数（用于分配energy_output）
 * @return int 成功返回0，失败返回错误码
 */
int predict_molecules(
    const char* url,
    const int* z, int z_len,
    const double* pos,  // 形状: [z_len * 3]
    const int* edge_index, int edge_len,  // edge_index实际长度: 2 * edge_len
    const int* batch, int batch_len,
    double* force_output,  // 输出，形状: [z_len * 3]
    double* energy_output,  // 输出，长度: 分子数量
    int max_molecules
);

#ifdef __cplusplus
}
#endif

#endif // HTTP_BRIDGE_H