module cnn
  use deep; use deeppub; use mlp
  implicit none

contains

subroutine cnn_go(parmfile)
  character(len=*),intent(in) :: parmfile
  integer :: ilen,iofile,ierr
  character*100 :: task
  namelist / deep / task

  if ( nlabelcv /= noutput ) stop "CNN error: nlabelcv /= noutput!"

  open(newunit=iofile,file=parmfile,action="read")
  read(iofile, nml=deep, iostat=ierr); if ( ierr < 0 ) stop "Cannot find the deep namelist!"
  close(iofile)

  ilen = len(trim(task))
  if ( task(ilen-4:ilen) == "train" ) then
     jobtype = TRAIN
  else if ( task(ilen-6:ilen) == "predict" ) then
     jobtype = PREDICT
  else if ( task(ilen-4:ilen) == "check" ) then
     jobtype = CHECK
  end if

  call deep_initialize(parmfile)

  call mlp_initialize(ninput,noutput,nlayer,layers,totparms,tpoutputweight=labelcvweight)

  if ( jobtype == PREDICT .or. jobtype == CHECK .or. ifproceed .eqv. .true. ) then
     call mlp_network_reload()
  else
     if ( icudagroup > 0 ) call mlp_network_upload()
  end if

  select case(jobtype)
  case (TRAIN)
     call cnn_train()
  case (PREDICT)
!     call cnn_predict()
  case (CHECK)
!     call cnn_check_grad()
!     call cnn_check_flood()
  end select
end subroutine

subroutine cnn_train()
  use mpi
  integer,dimension(:),pointer :: shuffleidx
  integer :: i,j,ibatch,index,iepoch,idata,realidata,istart,ipos,ilayer,igroup
  integer :: ierr,istream,errormark(batchsize)
  real*8 :: loss,totloss,checktotloss
  real*8,allocatable :: tpinputs(:,:,:,:),tpoutputs(:,:),tptrueoutputs(:,:)
  real*8 :: initime,endtime,time1,time2
  real :: rand

  errormark = 0
  allocate(tpinputs(nconvheight,nconvwidth,nconvchannel,batchsize)); tpinputs = 0d0
  call deeppub_normaldata_4d(tpinputs, 0d0, 1d0)

  allocate(tpoutputs(convlayers(nconvlayer)%poolstateheight*convlayers(nconvlayer)%poolstatewidth,batchsize))
  call deep_network_convforward(tpinputs,tpoutputs,errormark)
  print *; print *,"output data"
  print "(1000f6.2)",tpoutputs(:,1)
end subroutine

subroutine deep_network_convforward(inputs,outputs,errormark)
  real*8,dimension(:,:,:,:),intent(in) :: inputs
  real*8,dimension(:,:),intent(out) :: outputs
  integer,dimension(:),intent(in),optional :: errormark
  integer :: idata,ilayer,tpgroupsize,tpfilterheight,tpfilterwidth,tpstride
  integer :: iheight,iwidth,iheight2,iwidth2,i,j,k,tploc(2),tpheight,tpwidth,ifilter,tpchannel
  real*8,dimension(:,:,:),allocatable :: tppadstates
  real*8 :: tpvalue

  outputs = 0d0
  tpheight = size(inputs,1); if ( tpheight /= nconvheight ) stop "tpheight error!"
  tpwidth = size(inputs,2); if ( tpwidth /= nconvwidth ) stop "tpwidth error!"
  tpchannel = size(inputs,3); if ( tpchannel /= nconvchannel ) stop "tpchannel error!"
  tpgroupsize = size(inputs,4); if ( tpgroupsize /= batchsize ) stop "tpgroupsize error!"

  do idata = 1, tpgroupsize
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     print "(/,a)","=================================================="
     print *,"forward propagation for data ",idata

     do ilayer = 1, nconvlayer

        print *; print *,"layer ",ilayer

        print *; print *,"input data "
        if ( ilayer == 1 ) then
           tpheight = nconvheight; tpwidth = nconvwidth

           do k = 1, tpchannel
              print *,"data in channel ",k
              do i = 1, tpheight
                 print "(1000f6.2)",inputs(i,:,k,idata)
              end do
           end do

        else
           tpheight = convlayers(ilayer-1)%poolstateheight; tpwidth = convlayers(ilayer-1)%poolstatewidth

           do k = 1, convlayers(ilayer-1)%nfilter
              print *,"data in channel ",k
              do i = 1, tpheight
                 print "(1000f6.2)",convlayers(ilayer-1)%poolstate(i,:,idata)
              end do
           end do

        end if
        tpfilterheight = convlayers(ilayer)%filterheight
        tpfilterwidth = convlayers(ilayer)%filterwidth
        tpstride = convlayers(ilayer)%filterstride
        tpchannel = convlayers(ilayer)%nchannel

        print *; print *,"filter info"
        print "(a,f6.2)"," bias ",convlayers(ilayer)%filterbias(idata)
        do k = 1, tpchannel
           print *,"weights for channel ",k
           do i = 1, tpfilterheight
              print "(1000f6.2)",convlayers(ilayer)%filterweight(i,:,k,idata)
           end do
        end do

        allocate(tppadstates(-tpfilterheight+2:tpheight+tpfilterheight-1, &
                             -tpfilterwidth+2:tpwidth+tpfilterwidth-1,tpchannel))
        tppadstates = 0d0

        if ( ilayer == 1 ) then
           tppadstates(1:tpheight,1:tpwidth,1:tpchannel) = inputs(:,:,:,idata)
        else
           tppadstates(1:tpheight,1:tpwidth,1:tpchannel) = convlayers(ilayer-1)%poolstate(:,:,:)
        end if

        do ifilter = 1, convlayers(ilayer)%nfilter
           do i = 1, convlayers(ilayer)%filterstateheight
              iheight = (i-1)*tpstride + 1
              do j = 1, convlayers(ilayer)%filterstatewidth
                 iwidth = (j-1)*tpstride + 1
                 tpvalue = 0d00
                 do k = 1, convlayers(ilayer)%nchannel
                    tpvalue = tpvalue + sum( convlayers(ilayer)%filterweight(:,:,k,ifilter)*tppadstates(i-tpfilterheight+1:i,j-tpfilterwidth+1:j,k) )
                 end do
                 convlayers(ilayer)%filterstate(i,j,ifilter) = tpvalue + convlayers(ilayer)%filterbias(ifilter)
              end do
           end do
        end do

        print *; print *,"convstate "
        do i = 1, tpfilterheight
           print "(1000f6.2)",convlayers(ilayer)%filterstate(i,:,idata)
        end do

        deallocate(tppadstates)
        tpstride = convlayers(ilayer)%poolstride; tpheight = convlayers(ilayer)%poolheight; tpwidth = convlayers(ilayer)%poolwidth
        do ifilter = 1, convlayers(ilayer)%nfilter
           do i = 1, convlayers(ilayer)%poolstateheight
              iheight = (i-1)*tpstride + 1; iheight2 = min(iheight+tpheight-1,convlayers(ilayer)%filterstateheight)
              do j = 1, convlayers(ilayer)%poolstatewidth
                 iwidth = (j-1)*tpstride + 1; iwidth2 = min(iwidth+tpwidth-1,convlayers(ilayer)%filterstatewidth)

                 if ( ipoolmethod == MAXPOOL ) then
                    tpvalue = maxval(convlayers(ilayer)%filterstate(iheight:iheight2,iwidth:iwidth2,ifilter))
                    convlayers(ilayer)%poolmaxloc(:,ifilter) = maxloc(convlayers(ilayer)%filterstate(iheight:iheight2,iwidth:iwidth2,ifilter)) 
                 else if ( ipoolmethod == MEANPOOL ) then
                    k = (iheight2-iheight+1)*(iwidth2-iwidth+1)
                    tpvalue = sum(convlayers(ilayer)%filterstate(iheight:iheight2,iwidth:iwidth2,ifilter))/dble(k)
                 end if
                 convlayers(ilayer)%poolstate(iheight,iwidth,ifilter) = tpvalue
              end do
           end do
        end do

        print *; print *,"pool state before activation"
        do i = 1, convlayers(ilayer)%poolstateheight
           print "(1000f6.2)",convlayers(ilayer)%poolstate(i,:,idata)
        end do

        call deeppub_activation_function3d(convlayers(ilayer)%poolstate,convlayers(ilayer)%grad_active)

        print *; print *,"hidden state"
        do i = 1, convlayers(ilayer)%poolstateheight
           print "(1000f6.2)",convlayers(ilayer)%poolstate(i,:,idata)
        end do
        print *,"activation function gradients "
        do i = 1, convlayers(ilayer)%poolstateheight
           print "(1000f6.2)",convlayers(ilayer)%grad_active(i,:,idata)
        end do

     end do

     outputs(:,idata) = pack(convlayers(ilayer)%poolstate(:,:,idata),.true.)

     print *,"output data"
     print "(1000f6.2)",outputs(:,idata)

  end do

end subroutine


end module
