module cpugnn
 use deeppub; use mlp0; use gnnpub

implicit none

  real*8,dimension(:,:),allocatable :: batchsnapatomforces

  real*8,dimension(:),allocatable,private :: edgeembmeans,edgeembbetas
  real*8,dimension(:,:),allocatable,private :: batchatomembeddings,batchedgeembeddings,batchedgedirections
  real*8,dimension(:,:),allocatable,private :: largeedgeembeddings,largeedgeembeddings_for_edge,nodefeatures_of_first_layer
  real*8,dimension(:,:,:),allocatable,private :: grad_attenactiv,headattentions,batchmessagevm,batchmessageangle,batchmijvec,batchmijdir,batchedgedih
  real*8,dimension(:,:,:,:),allocatable,private :: batchnodequery,batchnodekey,batchnodevalue,batchedgekey,batchedgevalue
  real*8,dimension(:,:,:,:),allocatable,private :: batchvect,batchvecs,batchvecv,batchvecdiht,batchvecdihs
  real*8,dimension(:,:,:,:),allocatable,private :: vecfeatures
  real*8,dimension(:,:,:,:),allocatable,private :: vecfeatures_normed
  real*8,allocatable :: grad_decay2dis(:),grad_dirij2coordi(:,:,:),delta_coors(:,:,:)
  real*8,allocatable :: batchupdate12(:,:), batchvecoutput1(:,:,:), batchvecoutput2(:,:,:)
  real*8,allocatable,private :: delta_nf(:,:),delta_ef_for_check(:,:),delta_check(:,:),message_for_test3(:,:,:),message_for_test2(:,:),message_for_test1(:)
  real*8,allocatable,private :: delta_vf(:,:,:),delta_af(:,:,:),delta_force(:,:),delta_decay(:)
  real*8,allocatable,private :: vecfeatures_normsigma1(:,:),vecfeatures_normlength_sq1(:,:,:)
  real*8,allocatable,private :: vecfeatures_normsigma2(:,:),vecfeatures_normlength_sq2(:,:,:)

contains

   subroutine cpugnn_prepare_batchdata()
     integer :: tpnatom,tpnedge

     tpnatom = batchsnapnatom; tpnedge = batchsnapnedge
      if ( allocated(batchatomembeddings) ) then
         deallocate(vecfeatures_normsigma1,vecfeatures_normlength_sq1)
         deallocate(vecfeatures_normsigma2,vecfeatures_normlength_sq2)
         deallocate(batchatomembeddings,batchedgeembeddings,batchatomenergies)
         deallocate(batchnodequery,batchnodekey,batchnodevalue,batchedgekey,batchedgevalue)
         deallocate(batchvect,batchvecs,batchvecv,batchvecdiht,batchvecdihs)
         deallocate(batchmessagevm,batchmessageangle,batchmijvec,batchmijdir,batchedgedih)
         deallocate(headattentions,grad_attenactiv)
         deallocate(vecfeatures,largeedgeembeddings,largeedgeembeddings_for_edge,nodefeatures_of_first_layer,edgeembmeans,edgeembbetas)
         deallocate(vecfeatures_normed,batchsnapatomforces)
         deallocate(delta_nf,message_for_test3,message_for_test2,message_for_test1,delta_force,delta_vf,delta_ef_for_check,delta_af,delta_check)
         deallocate(delta_decay)
         deallocate(batchupdate12, batchvecoutput1, batchvecoutput2)
      end if
      allocate(vecfeatures_normsigma1(batchsnapnatom,nattention),vecfeatures_normlength_sq1(atomembeddinglength,batchsnapnatom,nattention))
      allocate(vecfeatures_normsigma2(batchsnapnatom,nattention),vecfeatures_normlength_sq2(atomembeddinglength,batchsnapnatom,nattention))

      allocate(batchatomembeddings(atomembeddinglength*2,tpnatom)); batchatomembeddings = 0d0
      allocate(batchatomenergies(tpnatom)); batchatomenergies = 0d0
      allocate(batchedgeembeddings(edgeembeddinglength,tpnedge)); batchedgeembeddings = 0d0
      allocate(batchnodequery(headsize,headnum,tpnatom,nattention),batchnodekey(headsize,headnum,tpnatom,nattention),batchnodevalue(headsize,headnum,tpnatom,nattention))
      allocate(batchedgekey(headsize,headnum,tpnedge,nattention),batchedgevalue(headsize,headnum,tpnedge,nattention))
      allocate(headattentions(headnum,tpnedge,nattention))
      allocate(batchvect(atomembeddinglength,8,tpnatom,nattention),batchvecs(atomembeddinglength,8,tpnatom,nattention), &
               batchvecv(atomembeddinglength,8,tpnatom,nattention),batchvecdiht(atomembeddinglength,8,tpnatom,nattention-1),batchvecdihs(atomembeddinglength,8,tpnatom,nattention-1))
      allocate(batchmessagevm(atomembeddinglength,tpnatom,nattention),batchmessageangle(atomembeddinglength,tpnatom,nattention))
      allocate(batchmijvec(atomembeddinglength,tpnedge,nattention),batchmijdir(atomembeddinglength,tpnedge,nattention), &
               batchedgedih(atomembeddinglength,tpnedge,nattention-1))
      allocate(grad_attenactiv(headnum,tpnedge,nattention))
      allocate(vecfeatures(atomembeddinglength, 8, batchsnapnatom,0:nattention)); vecfeatures = 0d0
      allocate(vecfeatures_normed(atomembeddinglength, 8, batchsnapnatom,0:nattention)); vecfeatures_normed = 0d0
      allocate(edgeembmeans(edgeembeddinglength),edgeembbetas(edgeembeddinglength))
      allocate(largeedgeembeddings(atomembeddinglength,batchsnapnedge),largeedgeembeddings_for_edge(atomembeddinglength,batchsnapnedge),nodefeatures_of_first_layer(atomembeddinglength,batchsnapnatom))
      allocate(batchsnapatomforces(3,batchsnapnatom))
      allocate(batchupdate12(atomembeddinglength/2,batchsnapnatom))
      allocate(batchvecoutput1(atomembeddinglength+atomembeddinglength/2,8,batchsnapnatom),batchvecoutput2(atomembeddinglength/2+1,8,batchsnapnatom))
      allocate(delta_nf(atomembeddinglength,batchsnapnatom),delta_ef_for_check(atomembeddinglength,batchsnapnedge),delta_af(headsize,headnum,batchsnapnedge)); delta_nf=0d0; delta_ef_for_check=0d0; delta_af=0d0
      allocate(message_for_test3(atomembeddinglength,8,batchsnapnatom),message_for_test2(atomembeddinglength,batchsnapnatom),message_for_test1(batchsnapnedge),delta_force(atomembeddinglength,batchsnapnedge),delta_vf(atomembeddinglength,8,batchsnapnatom),delta_check(atomembeddinglength,batchsnapnedge));delta_vf=0d0; delta_check = 0d0
      allocate(delta_decay(batchsnapnedge)); delta_decay = 0d0
   end subroutine

   subroutine cpugnn_calculate_batch_edge_info(tpshuffleidx,tpibatch)
      integer,intent(in) :: tpibatch,tpshuffleidx(:)
      integer :: tpnatom,tpnedge,idata,isnap,imol,iedge,iatom,jatom,istart,iatomstart
      real*8 :: tpvec(3),tpdis,sq3,tpdiscutsq,tpdissq

      if ( ifbuildedgeatruntime .eqv. .false. ) then
         if (allocated(batchsnapedges)) deallocate(batchsnapedges,batchedgedistance,batchedgedisdecays,grad_decay2dis,batchedgedirections,grad_dirij2coordi) 
         allocate(batchsnapedges(2,batchsnapnedge)); batchsnapedges = 0
         allocate(batchedgedistance(batchsnapnedge)); batchedgedistance = 0d0
         allocate(batchedgedisdecays(batchsnapnedge)); batchedgedisdecays = 0d0
         allocate(grad_decay2dis(batchsnapnedge)); grad_decay2dis = 0d0
         allocate(batchedgedirections(8,batchsnapnedge)); batchedgedirections = 0d0
         allocate(grad_dirij2coordi(8,3,batchsnapnedge)); grad_dirij2coordi = 0d0
      else
         if ( .not. allocated(batchsnapedges) ) then
            allocate(batchsnapedges(2,maxbatchsnapnedge)); batchsnapedges = 0
            allocate(batchedgedistance(maxbatchsnapnedge)); batchedgedistance = 0d0
            allocate(batchedgedisdecays(maxbatchsnapnedge)); batchedgedisdecays = 0d0
            allocate(grad_decay2dis(maxbatchsnapnedge)); grad_decay2dis = 0d0
            allocate(batchedgedirections(8,maxbatchsnapnedge)); batchedgedirections = 0d0
            allocate(grad_dirij2coordi(8,3,maxbatchsnapnedge)); grad_dirij2coordi = 0d0
         end if
      end if

      tpnatom = 0; tpnedge = 0; tpdiscutsq = edgediscut**2
      istart = (tpibatch-1)*batchsize; sq3 = sqrt(3d0)
      do idata = 1, batchsnapnmol
         isnap = tpshuffleidx(istart + idata); imol = snap2mol(isnap)
         iatomstart = snapatomindex(isnap)

         if ( ifbuildedgeatruntime .eqv. .false. ) then

            do iedge = 1, snapedgenums(isnap)
               ! snapedgeindex(isnap) : start edge index of isnap
               iatom = snapedges(1,snapedgeindex(isnap)+iedge); jatom = snapedges(2,snapedgeindex(isnap)+iedge)
               ! pick the coordinates and calculate the edge length
               tpvec(1:3) = snapatomcoors(:,iatomstart+iatom) - snapatomcoors(:,iatomstart+jatom)
               tpdis = sqrt(dot_product(tpvec,tpvec)); tpvec = tpvec/tpdis
               call cpugnn_add_new_edge()
               batchsnapedges(1:2,tpnedge+iedge) = [tpnatom+iatom,tpnatom+jatom]
            end do
            iedge = snapedgenums(isnap)

         else

            iedge = 0
            do iatom = 1, molatomnums(imol)
               do jatom = iatom+1, molatomnums(imol)
                  tpvec(1:3) = snapatomcoors(1:3,iatomstart+iatom) - snapatomcoors(1:3,iatomstart+jatom)
                  tpdissq = dot_product(tpvec,tpvec)
                  if ( tpdissq < tpdiscutsq ) then
                     tpdis = sqrt(tpdissq); tpvec = tpvec/tpdis

                     iedge = iedge + 1
                     call cpugnn_add_new_edge()
                     batchsnapedges(1:2,tpnedge+iedge) = [tpnatom+iatom,tpnatom+jatom]

                     iedge = iedge + 1; tpvec = -tpvec
                     call cpugnn_add_new_edge()
                     batchsnapedges(1:2,tpnedge+iedge) = [tpnatom+jatom,tpnatom+iatom]

                     batchatomdegree(tpnatom+iatom) = batchatomdegree(tpnatom+iatom) + 2
                     batchatomdegree(tpnatom+jatom) = batchatomdegree(tpnatom+jatom) + 2
                  end if
               end do
            end do

         end if

         tpnedge = tpnedge + iedge
         batchsnapedgeindex(idata+1) = tpnedge
         tpnatom = tpnatom + molatomnums(imol)

      end do

      batchsnapnedge = tpnedge

   contains

   subroutine cpugnn_add_new_edge()

            if ( tpnedge+iedge > maxbatchsnapnedge ) then
               print *,"maxbatchsnapnedge is too small! ",maxbatchsnapnedge; stop
            end if

            batchedgedistance(tpnedge+iedge) = tpdis
            ! rescale the distance tpdis to [0,1] by a decaying function
            batchedgedisdecays(tpnedge+iedge) = 0.5d0*(cos(tpdis*pi/edgediscut) + 1.0d0)
            grad_decay2dis(tpnedge+iedge) = - 0.5d0*(pi/edgediscut)*sin(tpdis*pi/edgediscut)
            ! sphere harmonic function
            batchedgedirections(1:8,tpnedge+iedge) = [tpvec(1), tpvec(2), tpvec(3), &
                     sq3*tpvec(1)*tpvec(3), sq3*tpvec(1)*tpvec(2), 0.5d0*(3d0*tpvec(2)*tpvec(2) - 1d0), &
                     sq3*tpvec(2)*tpvec(3), sq3*0.5d0*(tpvec(3)**2- tpvec(1)**2)]

            grad_dirij2coordi(:,:,tpnedge+iedge) = transpose(reshape([1d0-tpvec(1)**2, -tpvec(1)*tpvec(2), -tpvec(1)*tpvec(3), &
                  -tpvec(1)*tpvec(2), 1d0-tpvec(2)**2, -tpvec(2)*tpvec(3), &
                  -tpvec(1)*tpvec(3), -tpvec(2)*tpvec(3), 1d0-tpvec(3)**2, &
                  sq3*tpvec(3)*(1d0-2d0*tpvec(1)**2), -2d0*sq3*tpvec(1)*tpvec(2)*tpvec(3), sq3*tpvec(1)*(1d0-2d0*tpvec(3)**2), &
                  sq3*tpvec(2)*(1d0-2d0*tpvec(1)**2), sq3*tpvec(1)*(1d0-2d0*tpvec(2)**2), -2d0*sq3*tpvec(1)*tpvec(2)*tpvec(3), &
                  -3d0*tpvec(1)*tpvec(2)**2, 3d0*tpvec(2)*(1d0-tpvec(2)**2), -3d0*tpvec(3)*tpvec(2)**2, &
                  -2d0*sq3*tpvec(1)*tpvec(2)*tpvec(3), sq3*tpvec(3)*(1d0-2d0*tpvec(2)**2), sq3*tpvec(2)*(1d0-2d0*tpvec(3)**2), &
                  -sq3*tpvec(1)*(tpvec(2)**2+2d0*tpvec(3)**2), sq3*tpvec(2)*(tpvec(1)**2-tpvec(3)**2), sq3*tpvec(3)*(tpvec(2)**2+2d0*tpvec(1)**2)],[3,8]))
            grad_dirij2coordi(:,:,tpnedge+iedge) = grad_dirij2coordi(:,:,tpnedge+iedge) / tpdis
   end subroutine
   end subroutine

   subroutine cpugnn_network_forward(calloss,tptotloss,energy_prediction,ifcheck,ifpredict,printinfo) 
      real*8,intent(out),optional :: tptotloss,energy_prediction
      logical,intent(in),optional :: ifcheck, ifpredict,calloss,printinfo
      Character(len=100) :: name1,name2,name3,name4
      integer :: i,iemb,ihead,iatom,jatom,isnap,idata,imol,tpnatom,iedge,tpindex,iatomstart,iatomstop,iedgestart,iedgestop,dim,iatt
      real*8 :: tptotforceloss,tpvec(3),tploss,tpvalue,tpgradvalue,tpheadvec(headsize),tpheadgradvec(headsize),headvec(headnum),headgradvec(headnum),tpactiv(atomembeddinglength)
      real*8,dimension(:,:,:),allocatable :: tpinputs,tpoutputs,delta_vec,vecmessage

      real*8,dimension(:,:),allocatable :: batchmessageres,mij,edgefeatures,nodefeatures,delta_edge,delta_node,message
      real*8,dimension(:,:,:),allocatable :: forces, tpinputs1, tpoutputs1, tpinputs2, tpoutputs2, tpinputs3, tpoutputs3
      real*8,dimension(:,:),allocatable :: tpforces
      real*8,allocatable ::batchoutputx(:,:),batchoutputv(:,:,:)
      real*8,allocatable :: tptestmessage(:)

      allocate(tpinputs(maxatomtype,maxatomtype,1),tpoutputs(atomembeddinglength*2,maxatomtype,1));tpinputs = 0d0; tpoutputs = 0d0

      forall (i=1:maxatomtype) 
         tpinputs(i,i,1) = 1d0
      end forall
      call mlp0_network_forward(gnetatomemb,1,tpinputs,tpoutputs)
      do iatom = 1, batchsnapnatom
         batchatomembeddings(:,iatom) = tpoutputs(:,batchatomtype(iatom)+1,1)
      end do

      deallocate(tpinputs,tpoutputs)
      allocate(tpinputs(1, 1, 1)); tpinputs(1,1,1) = 1d0
      allocate(tpoutputs(edgeembeddinglength*2, 1, 1)); tpoutputs = 0d0
      call mlp0_network_forward(gnetedgeemb,1,tpinputs,tpoutputs)
      edgeembmeans = tpoutputs(1:edgeembeddinglength,1,1)
      edgeembbetas = tpoutputs(edgeembeddinglength+1:edgeembeddinglength*2,1,1)

      do iedge = 1, batchsnapnedge
         do i = 1, edgeembeddinglength
            batchedgeembeddings(i,iedge) = batchedgedisdecays(iedge)* exp(-(exp(-batchedgedistance(iedge)) - edgeembmeans(i))**2 * edgeembbetas(i))
         end do
      end do

      deallocate(tpinputs,tpoutputs)

      allocate(edgefeatures(atomembeddinglength, batchsnapnedge))
      allocate(nodefeatures(atomembeddinglength, batchsnapnatom))
      allocate(delta_vec(atomembeddinglength, 8, batchsnapnatom))
      allocate(delta_node(atomembeddinglength, batchsnapnatom))
      allocate(delta_edge(atomembeddinglength, batchsnapnedge))
      allocate(vecmessage(atomembeddinglength,8,batchsnapnatom))
      allocate(message(atomembeddinglength,batchsnapnatom))
      allocate(mij(atomembeddinglength,batchsnapnedge))
      allocate(batchmessageres(atomembeddinglength,batchsnapnatom))

      message = 0d0; vecmessage = 0d0; mij = 0d0; headattentions = 0d0
      vecfeatures = 0d0

      delta_node = 0d0; delta_edge = 0d0; delta_vec = 0d0

      allocate(tpinputs(edgeembeddinglength, batchsnapnedge, 1)); tpinputs = 0d0
      allocate(tpoutputs(atomembeddinglength, batchsnapnedge, 1)); tpoutputs = 0d0
      tpinputs(1:edgeembeddinglength,1:batchsnapnedge,1) = batchedgeembeddings(1:edgeembeddinglength,1:batchsnapnedge)
      call mlp0_network_forward(gnetmain(1),1,tpinputs,tpoutputs)
      largeedgeembeddings(:,:) = tpoutputs(:,:,1)
      call mlp0_network_forward(gnetmain(4),1,tpinputs,tpoutputs)
      largeedgeembeddings_for_edge(:,:) = tpoutputs(:,:,1)

      deallocate(tpinputs)
      allocate(tpinputs(atomembeddinglength*2,batchsnapnatom,1)); tpinputs = 0d0

      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         tpinputs(1:atomembeddinglength,jatom,1) = tpinputs(1:atomembeddinglength,jatom,1) + &
               largeedgeembeddings(:,iedge)*batchedgedisdecays(iedge)*batchatomembeddings(:atomembeddinglength,iatom)
      end do
      do iatom = 1, batchsnapnatom
         tpinputs(1:atomembeddinglength,iatom,1) = tpinputs(1:atomembeddinglength,iatom,1)
         tpinputs(atomembeddinglength+1:atomembeddinglength*2,iatom,1) = batchatomembeddings(atomembeddinglength+1:atomembeddinglength*2,iatom)
      end do
      deallocate(tpoutputs)
      allocate(tpoutputs(atomembeddinglength,batchsnapnatom,1))

      call mlp0_network_forward(gnetmain(2),1,tpinputs,tpoutputs); nodefeatures(:,:) = tpoutputs(:,:,1)
      nodefeatures_of_first_layer(:,:) = nodefeatures(:,:)

      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         edgefeatures(:,iedge) = largeedgeembeddings_for_edge(:,iedge)*   &
                                 (nodefeatures(:,iatom) + nodefeatures(:,jatom))
      end do

      vecfeatures(:,:,:,0) = 0d0
      do iatt = 1, nattention
         deallocate(tpinputs)
         allocate(tpinputs(atomembeddinglength,batchsnapnatom,1)); tpinputs(:,:,1) = nodefeatures(:,:)

         deallocate(tpoutputs)
         allocate(tpoutputs(atomembeddinglength,batchsnapnatom,1))
         tpoutputs = 0d0

         call mlp0_network_forward(gnetnodequery(iatt),1,tpinputs,tpoutputs)
         batchnodequery(:,:,:,iatt) = reshape(tpoutputs,[headsize,headnum,batchsnapnatom])
         call mlp0_network_forward(gnetnodekey(iatt),1,tpinputs,tpoutputs)
         batchnodekey(:,:,:,iatt) = reshape(tpoutputs,[headsize,headnum,batchsnapnatom])
         call mlp0_network_forward(gnetnodevalue(iatt),1,tpinputs,tpoutputs)
         batchnodevalue(:,:,:,iatt) = reshape(tpoutputs,[headsize,headnum,batchsnapnatom])

         deallocate(tpinputs,tpoutputs)

         ! modified on 2026.01.27
         if ( iatt > 1 ) then

            allocate(tpinputs(atomembeddinglength,batchsnapnatom*8,1))
            tpinputs(:,:,1) = reshape(vecfeatures_normed(:,:,:,iatt-1),[atomembeddinglength,batchsnapnatom*8])

            if (iatt /= nattention) then
               allocate(tpoutputs(atomembeddinglength,batchsnapnatom*8,1))
               call mlp0_network_forward(gnetwtrgproj(iatt),1,tpinputs,tpoutputs)
               batchvecdiht(:,:,:,iatt) = reshape(tpoutputs(:,:,1),[atomembeddinglength,8,batchsnapnatom])
               call mlp0_network_forward(gnetwsrcproj(iatt),1,tpinputs,tpoutputs)
               batchvecdihs(:,:,:,iatt) = reshape(tpoutputs(:,:,1),[atomembeddinglength,8,batchsnapnatom])
               deallocate(tpoutputs)
            end if

            allocate(tpoutputs(atomembeddinglength*3,batchsnapnatom*8,1))
            call mlp0_network_forward(gnetvecproj(iatt),1,tpinputs,tpoutputs)

            batchvect(:,:,:,iatt) = reshape(tpoutputs(:atomembeddinglength,:,1),[atomembeddinglength,8,batchsnapnatom])
            batchvecs(:,:,:,iatt) = reshape(tpoutputs(atomembeddinglength+1:atomembeddinglength*2,:,1),[atomembeddinglength,8,batchsnapnatom])
            batchvecv(:,:,:,iatt) = reshape(tpoutputs(atomembeddinglength*2+1:atomembeddinglength*3,:,1),[atomembeddinglength,8,batchsnapnatom])

            deallocate(tpinputs,tpoutputs)

         else

            if (iatt /= nattention) then
               batchvecdiht(:,:,:,iatt) = 0d0; batchvecdihs(:,:,:,iatt) = 0d0
            end if
            batchvect(:,:,:,iatt) = 0d0; batchvecs(:,:,:,iatt) = 0d0; batchvecv(:,:,:,iatt) = 0d0

         end if

         allocate(tpinputs(atomembeddinglength,batchsnapnedge,1)); tpinputs(:,:,1) = edgefeatures(:,:)
         allocate(tpoutputs(atomembeddinglength,batchsnapnedge,1)); tpoutputs = 0

         call mlp0_network_forward(gnetedgekey(iatt),1,tpinputs,tpoutputs)
         batchedgekey(:,:,:,iatt) = reshape(tpoutputs,[headsize,headnum,batchsnapnedge])

         call mlp0_network_forward(gnetedgevalue(iatt),1,tpinputs,tpoutputs)
         batchedgevalue(:,:,:,iatt) = reshape(tpoutputs,[headsize,headnum,batchsnapnedge])

         if (iatt /= nattention) then
            call mlp0_network_forward(gnetfproj(iatt),1,tpinputs,tpoutputs)
            batchedgedih(:,:,iatt) = tpoutputs(:,:,1)
         end if

         message = 0.0d0

         do iedge = 1, batchsnapnedge
            iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge); headvec = 0d0

            if (gnnmode == 2 .or. gnnmode == 4 ) then

               do ihead = 1, headnum
                     tpheadvec(:) = batchnodequery(:,ihead,jatom,iatt)*batchnodekey(:,ihead,iatom,iatt)*  &
                                     batchedgekey(:,ihead,iedge,iatt)
                  headvec(ihead) = sum(tpheadvec)
               end do

               call deeppub_activation_function(headvec,headattentions(:,iedge,iatt),grad_attenactiv(:,iedge,iatt))
               headattentions(:,iedge,iatt) = headattentions(:,iedge,iatt)*batchedgedisdecays(iedge)

               do ihead=1,headnum
                  mij(headsize*(ihead-1)+1:headsize*ihead,iedge)=headattentions(ihead,iedge,iatt)*batchedgevalue(:,ihead,iedge,iatt)*batchnodevalue(:,ihead,iatom,iatt)
               end do

            else if ( gnnmode == 3 ) then

               do ihead = 1, headnum
                  mij(headsize*(ihead-1)+1:headsize*ihead,iedge) = batchedgevalue(:,ihead,iedge,iatt)*batchnodevalue(:,ihead,iatom,iatt)
               end do

            end if

            message(:,jatom) = message(:,jatom)+mij(:,iedge)
         end do

         if (gnnmode == 2) then
            nodefeatures(:,:) = nodefeatures(:,:) + message(:,:)
            cycle
         end if

         deallocate(tpinputs,tpoutputs)

         allocate(tpinputs(atomembeddinglength,batchsnapnedge,1),tpoutputs(atomembeddinglength*2,batchsnapnedge,1)); tpoutputs = 0d0
         tpinputs(:,:batchsnapnedge,1) = mij(:,:)

         call mlp0_network_forward(gnetsproj(iatt),1,tpinputs,tpoutputs)

         batchmijdir(:,:,iatt) = tpoutputs(1:atomembeddinglength,:batchsnapnedge,1)
         batchmijvec(:,:,iatt) = tpoutputs(atomembeddinglength+1:atomembeddinglength*2,:batchsnapnedge,1)

         vecmessage(:,:,:) = 0d0
         do iedge = 1, batchsnapnedge
            iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
            do i = 1, atomembeddinglength
               vecmessage(i,:,jatom)=vecmessage(i,:,jatom)+batchmijdir(i,iedge,iatt)*batchedgedirections(:,iedge)+ &
                                 batchmijvec(i,iedge,iatt)*vecfeatures_normed(i,:,iatom,iatt-1)
            end do
         end do

         deallocate(tpinputs,tpoutputs)
         allocate(tpinputs(atomembeddinglength,batchsnapnatom,1))
         allocate(tpoutputs(atomembeddinglength*3,batchsnapnatom,1))
         tpinputs(:,:,1) = message(:,:)

         call mlp0_network_forward(gnetoproj(iatt),1,tpinputs,tpoutputs)
         batchmessagevm(:,:,iatt) = tpoutputs(1:atomembeddinglength,:,1)
         batchmessageangle(:,:,iatt) = tpoutputs(atomembeddinglength+1:atomembeddinglength*2,:,1)
         batchmessageres(:,:) = tpoutputs(atomembeddinglength*2+1:atomembeddinglength*3,:,1)

         delta_node(:,:) = batchmessageangle(:,:,iatt)*sum(batchvect(:,:,:,iatt)*batchvecs(:,:,:,iatt),dim=2)+batchmessageres(:,:)
         nodefeatures(:,:) = nodefeatures(:,:) + delta_node(:,:)

         do dim = 1, 8
            delta_vec(:,dim,:) = vecmessage(:,dim,:) + batchmessagevm(:,:,iatt)*batchvecv(:,dim,:,iatt)
         end do
         vecfeatures(:,:,:,iatt) = vecfeatures(:,:,:,iatt-1) + delta_vec(:,:,:)

         if ( ifuselayernorm ) then
            vecfeatures_normlength_sq1(:,:,iatt) = sum(vecfeatures(:,:3,:,iatt)*vecfeatures(:,:3,:,iatt), dim=2)
            vecfeatures_normsigma1(:,iatt) = sqrt(sum(vecfeatures_normlength_sq1(:,:,iatt),dim=1)/dble(atomembeddinglength) + 1d-16)
            vecfeatures_normlength_sq2(:,:,iatt) = sum(vecfeatures(:,4:8,:,iatt)*vecfeatures(:,4:8,:,iatt), dim=2)
            vecfeatures_normsigma2(:,iatt) = sqrt(sum(vecfeatures_normlength_sq2(:,:,iatt),dim=1)/dble(atomembeddinglength) + 1d-16)
            do iatom = 1, batchsnapnatom
               vecfeatures_normed(:,:3,iatom,iatt) = vecfeatures(:,:3,iatom,iatt) / vecfeatures_normsigma1(iatom,iatt) / 2d0
               vecfeatures_normed(:,4:8,iatom,iatt) = vecfeatures(:,4:8,iatom,iatt) / vecfeatures_normsigma2(iatom,iatt) / 2d0
            end do
         end if

         if ( (iatt /= nattention) .and. (iatt /= 1) ) then
            delta_edge(:,:) = 0d0
            do iedge= 1,batchsnapnedge
               iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
               do dim = 1,8 
                  delta_edge(:,iedge) = delta_edge(:,iedge) + batchvecdiht(:,dim,jatom,iatt)* &
                                    batchvecdihs(:,dim,iatom,iatt)* batchedgedih(:,iedge,iatt)
               end do
            end do
            edgefeatures(:,:) = edgefeatures(:,:) + delta_edge(:,:)
         end if

      end do

      deallocate(tpinputs,tpoutputs)
      allocate(tpinputs(atomembeddinglength,batchsnapnatom*8,1))
      allocate(tpoutputs(atomembeddinglength+atomembeddinglength/2,batchsnapnatom*8,1))
      tpinputs(:,:,1) = reshape(vecfeatures_normed(:,:,:,nattention),[atomembeddinglength,batchsnapnatom*8])
      call mlp0_network_forward(gnetvecoutput(1),1,tpinputs,tpoutputs)

      batchvecoutput1 = reshape(tpoutputs(:,:,1),[atomembeddinglength+atomembeddinglength/2,8,batchsnapnatom])
      deallocate(tpinputs,tpoutputs)
      allocate(tpinputs(atomembeddinglength*2,batchsnapnatom,1))
      allocate(tpoutputs(atomembeddinglength/2,batchsnapnatom,1))
      allocate(batchoutputx(atomembeddinglength/2,batchsnapnatom),batchoutputv(atomembeddinglength/2,8,batchsnapnatom))
      tpinputs(1:atomembeddinglength,:,1) = nodefeatures
      tpinputs(atomembeddinglength+1:atomembeddinglength*2,:,1) = sqrt(sum(batchvecoutput1(1:atomembeddinglength,:,:)**2, dim = 2))
      call mlp0_network_forward(gnetupdate(1,1),1,tpinputs,tpoutputs)
      batchoutputx = tpoutputs(:,:,1)
      call mlp0_network_forward(gnetupdate(1,2),1,tpinputs,tpoutputs)
      batchupdate12 = reshape(tpoutputs(:,:,1),[atomembeddinglength/2,batchsnapnatom])
      do dim = 1, 8
         batchoutputv(:,dim,:) = batchupdate12(:,:) * batchvecoutput1(atomembeddinglength+1:atomembeddinglength+atomembeddinglength/2,dim,:)
      end do
      deallocate(tpinputs,tpoutputs)
      allocate(tpinputs(atomembeddinglength/2,batchsnapnatom*8,1))
      allocate(tpoutputs(atomembeddinglength/2+1,batchsnapnatom*8,1))
      tpinputs(:,:,1) = reshape(batchoutputv(:,:,:),[atomembeddinglength/2,batchsnapnatom*8])
      call mlp0_network_forward(gnetvecoutput(2),1,tpinputs,tpoutputs)
      batchvecoutput2 = reshape(tpoutputs(:,:,1),[atomembeddinglength/2+1,8,batchsnapnatom])
      deallocate(tpinputs,tpoutputs)
      allocate(tpinputs(atomembeddinglength,batchsnapnatom,1))
      allocate(tpoutputs(1,batchsnapnatom,1))
      tpinputs(1:atomembeddinglength/2,:,1) = batchoutputx
      tpinputs(atomembeddinglength/2+1:atomembeddinglength,:,1) = sqrt(sum(batchvecoutput2(:atomembeddinglength/2,:,:)**2, dim = 2))
      deallocate(batchoutputx, batchoutputv)
      allocate(batchoutputx(1,batchsnapnatom),batchoutputv(1,8,batchsnapnatom))
      call mlp0_network_forward(gnetupdate(2,1),1,tpinputs,tpoutputs)
      batchoutputx = tpoutputs(:,:,1)
      call mlp0_network_forward(gnetupdate(2,2),1,tpinputs,tpoutputs)
      batchoutputv(1,:,:) = tpoutputs(:,:,1) * batchvecoutput2(atomembeddinglength/2+1,:,:)
      tpoutputs(:,:,1) = batchoutputx + sum(batchoutputv,dim=2) * 0d0

      if ( present(tptotloss) ) tptotloss = 0d0

      batchsnapenergies = 0d0
      do idata = 1, batchsnapnmol
         iatomstart = batchsnapatomindex(idata)+1
         iatomstop = batchsnapatomindex(idata+1)
         batchsnapenergies(idata) = sum(tpoutputs(1,iatomstart:iatomstop,1))

         if ( present(calloss) ) then
            select case (lossfunctype)
               case (RMSE)
                  tploss = (batchsnapenergies(idata) - batchrefsnapenergies(idata))**2
               case (MAE)
                  tploss = abs(batchsnapenergies(idata) - batchrefsnapenergies(idata))
            end select
            totenergyloss = totenergyloss + tploss
            if ( present(tptotloss) ) tptotloss = tptotloss + tploss * (1d0 - forceweight)
            if ( present(energy_prediction) ) energy_prediction = batchsnapenergies(1)
         end if
      end do
      deallocate(tpinputs,tpoutputs,edgefeatures,nodefeatures)

      if ( present(printinfo) ) then
         open(unit=1000, file="energy_prediction_result.txt", status='old', position='append')
         if ( present(calloss) ) then
            do i = 1, size(batchrefsnapenergies)
               imol = batchsnap2mol(i)
               write(1000,'(f15.3,a,f15.3)') batchsnapenergies(i) + molavgene(imol),"\t", batchrefsnapenergies(i) + molavgene(imol)
            end do
         else
            do i = 1, size(batchrefsnapenergies)
               imol = batchsnap2mol(i)
               write(1000,'(f15.3)') batchsnapenergies(i) + molavgene(imol)
            end do
         end if
         close(1000)
      end if

   end subroutine
   
   subroutine cpugnn_network_backward(calloss,printinfo)
      logical,intent(in),optional :: calloss,printinfo
      integer :: idata,iatom,jatom,iedge,iatomstart,iatomstop,k,iatt,dim,i,j
      real*8 :: tpsnapenergy, tprefsnapenergy
      real*8,allocatable:: tpinputs(:,:,:),tpoutputs(:,:),delta_grad_L2nf(:,:),delta_grad_L2ef(:,:),delta_grad_L2vf(:,:)
      real*8,allocatable:: delta_grad_L2vf_notnormed(:,:,:)
      real*8,allocatable:: grad_L2nf(:,:),grad_L2ef(:,:),grad_L2vf(:,:,:),upper_grad_L2vf(:,:,:)
      real*8,allocatable:: grad_L2DenseV(:,:,:),grad_L2DenseK(:,:,:),grad_L2attn(:,:)
      real*8,allocatable:: grad_L2Q(:,:,:),grad_L2V(:,:,:),grad_L2K(:,:,:)
      real*8,allocatable:: grad_L2sproj(:,:),grad_L2fproj(:,:),grad_L2vecproj(:,:,:)
      real*8,allocatable:: grad_L2wsrcproj(:,:,:),grad_L2wtrgproj(:,:,:)
      real*8,allocatable:: grad_L2oproj(:,:)
      real*8,allocatable:: grad_L2mij(:,:),grad_L2message(:,:)
      real*8,allocatable:: rejmatrix(:,:)
      real*8,allocatable:: grad_L2atomemb(:,:),grad_L2edgeemb(:,:)
      real*8,allocatable:: grad_L2intatomemb(:,:),grad_L2meanbeta(:,:),grad_L2atomenergy(:),grad_L2decay(:)
      real*8,allocatable:: grad_L2batchsnapatomforces(:,:),grad_L2forces(:,:,:)
      real*8,allocatable:: grad_L2nodeforce(:,:), grad_L2vecforce(:,:,:), grad_L2edgeforce(:,:)
      real*8,allocatable :: grad_L2outx2(:,:),grad_L2outx1(:,:),grad_L2outx(:,:)
      real*8,allocatable :: grad_L2outv2(:,:,:),grad_L2outv1(:,:,:),grad_L2outv(:,:,:)
      real*8,allocatable :: grad_L2outvecnorm2head(:,:),grad_L2outvecnorm1head(:,:)
      real*8,allocatable :: grad_L2vecout2(:,:,:),grad_L2vecout1(:,:,:)
      real*8:: ones(8,8),tpvalue,tpsum,tploss

      ones = 0d0; forall (i=1:8) ones(i,i) = 1d0

      batchsnapatomforces = 0d0
      allocate(grad_L2atomenergy(batchsnapnatom),grad_L2decay(batchsnapnedge))
      grad_L2decay = 0d0

      allocate(grad_L2nf(atomembeddinglength,batchsnapnatom),grad_L2ef(atomembeddinglength,batchsnapnedge),grad_L2vf(atomembeddinglength,8,batchsnapnatom),upper_grad_L2vf(atomembeddinglength,8,batchsnapnatom))
      allocate(delta_grad_L2nf(atomembeddinglength,batchsnapnatom))
      allocate(delta_grad_L2ef(atomembeddinglength,batchsnapnedge))
      allocate(delta_grad_L2vf(atomembeddinglength,batchsnapnatom*8))
      allocate(delta_grad_L2vf_notnormed(atomembeddinglength,8,batchsnapnatom)); delta_grad_L2vf_notnormed = 0d0
      delta_grad_L2ef = 0d0; delta_grad_L2vf = 0d0; delta_grad_L2nf = 0d0

      allocate(tpinputs(1,batchsnapnatom,1))
      if (present(calloss)) then
         do idata = 1, batchsnapnmol
            iatomstart = batchsnapatomindex(idata)+1
            iatomstop = batchsnapatomindex(idata+1)
            tpinputs(1,iatomstart:iatomstop,1) = (1d0-forceweight)*2d0*(batchsnapenergies(idata) - batchrefsnapenergies(idata))
            grad_L2atomenergy(iatomstart:iatomstop) = tpinputs(1,iatomstart:iatomstop,1)
         end do
      else
         tpinputs(1, :, 1) = 1d0
         grad_L2atomenergy(:) = 1d0
      end if

      allocate(grad_L2outx2(1,batchsnapnatom),grad_L2outv2(1,8,batchsnapnatom))
      allocate(grad_L2outx1(atomembeddinglength/2,batchsnapnatom),grad_L2outvecnorm2head(atomembeddinglength/2,batchsnapnatom))
      allocate(grad_L2vecout2(atomembeddinglength/2+1,8,batchsnapnatom),grad_L2outv1(atomembeddinglength/2,8,batchsnapnatom))
      allocate(grad_L2outx(atomembeddinglength,batchsnapnatom),grad_L2outvecnorm1head(atomembeddinglength,batchsnapnatom))
      allocate(grad_L2vecout1(atomembeddinglength+atomembeddinglength/2,8,batchsnapnatom),grad_L2outv(atomembeddinglength,8,batchsnapnatom))
      
      grad_L2outx2(1,:) = grad_L2atomenergy(:)!grad_L2outx2 shape: [1,batchsnapnatom]
      grad_L2outv2(:,:,:) = 0d0!grad_L2outv2 shape: [1,8,batchsnapnatom]
      deallocate(tpinputs)
      allocate(tpoutputs(atomembeddinglength,batchsnapnatom),tpinputs(1,batchsnapnatom,1)); tpoutputs = 0d0
      tpinputs(1,:,1) = grad_L2outx2(1,:)
!if (ical==2) stop
      call mlp0_network_backward_bptt(gnetupdate(2,1),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)
      grad_L2outx1 = tpoutputs(:atomembeddinglength/2,:)!grad_L2outx1 shape: [atomembeddinglength/2,batchsnapnatom]
      grad_L2outvecnorm2head = tpoutputs(atomembeddinglength/2+1:atomembeddinglength,:) !grad_L2outvecnorm2head shape: [atomembeddinglength/2,batchsnapnatom]

      tpinputs = 0d0
      call mlp0_network_backward_bptt(gnetupdate(2,2),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)
      grad_L2outx1 = grad_L2outx1 + tpoutputs(:atomembeddinglength/2,:)
      grad_L2outvecnorm2head = grad_L2outvecnorm2head + tpoutputs(atomembeddinglength/2+1:atomembeddinglength,:)
      grad_L2vecout2 = 0d0!grad_L2vecout2 shape: [atomembeddinglength/2+1,8,batchsnapnatom]
      do dim = 1, 8
         grad_L2vecout2(:atomembeddinglength/2,dim,:) = grad_L2outvecnorm2head * batchvecoutput2(:atomembeddinglength/2,dim,:) / sqrt(sum(batchvecoutput2(:atomembeddinglength/2,:,:)**2, dim = 2))
      end do

      deallocate(tpinputs,tpoutputs)
      allocate(tpinputs(atomembeddinglength/2+1,batchsnapnatom*8,1),tpoutputs(atomembeddinglength/2,batchsnapnatom*8)); tpoutputs = 0d0
      tpinputs(:,:,1) = reshape(grad_L2vecout2(:,:,:),[atomembeddinglength/2+1,batchsnapnatom*8])
      call mlp0_network_backward_bptt(gnetvecoutput(2),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)
      grad_L2outv1 = reshape(tpoutputs(:,:),[atomembeddinglength/2,8,batchsnapnatom])!grad_L2outv1 shape: [atomembeddinglength/2,8,batchsnapnatom]

      deallocate(tpinputs,tpoutputs)
      allocate(tpoutputs(atomembeddinglength*2,batchsnapnatom),tpinputs(atomembeddinglength/2,batchsnapnatom,1)); tpoutputs = 0d0
      tpinputs(:,:,1) = grad_L2outx1
      call mlp0_network_backward_bptt(gnetupdate(1,1),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)
      grad_L2outx = tpoutputs(:atomembeddinglength,:)!grad_L2outx shape: [atomembeddinglength,batchsnapnatom]
      grad_L2outvecnorm1head = tpoutputs(atomembeddinglength+1:atomembeddinglength*2,:) !grad_L2outvecnorm1head shape: [atomembeddinglength,batchsnapnatom]
      tpinputs(:,:,1) = sum(grad_L2outv1 * batchvecoutput1(atomembeddinglength+1:atomembeddinglength+atomembeddinglength/2,:,:), dim = 2)
      call mlp0_network_backward_bptt(gnetupdate(1,2),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)
      grad_L2outx = grad_L2outx + tpoutputs(:atomembeddinglength,:)
      grad_L2outvecnorm1head = grad_L2outvecnorm1head + tpoutputs(atomembeddinglength+1:atomembeddinglength*2,:)
      do dim = 1, 8
         grad_L2vecout1(atomembeddinglength+1:atomembeddinglength+atomembeddinglength/2,dim,:) = grad_L2outv1(:,dim,:)*batchupdate12(:,:)!grad_L2vecout1 shape: [atomembeddinglength+atomembeddinglength/2,8,batchsnapnatom]
         grad_L2vecout1(:atomembeddinglength,dim,:) = grad_L2outvecnorm1head * batchvecoutput1(:atomembeddinglength,dim,:) / sqrt(sum(batchvecoutput1(:atomembeddinglength,:,:)**2, dim = 2))
      end do
      deallocate(tpinputs,tpoutputs)
      allocate(tpinputs(atomembeddinglength+atomembeddinglength/2,batchsnapnatom*8,1),tpoutputs(atomembeddinglength,batchsnapnatom*8)); tpoutputs = 0d0
      tpinputs(:,:,1) = reshape(grad_L2vecout1(:,:,:),[atomembeddinglength+atomembeddinglength/2,batchsnapnatom*8])
      call mlp0_network_backward_bptt(gnetvecoutput(1),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)
      grad_L2outv = reshape(tpoutputs(:,:),[atomembeddinglength,8,batchsnapnatom])!grad_L2outv shape: [atomembeddinglength,8,batchsnapnatom]

      grad_L2nf = grad_L2outx
      delta_grad_L2vf_notnormed = grad_L2outv

      if ( ifuselayernorm ) then
         do iatom = 1,batchsnapnatom
            delta_grad_L2vf_notnormed(:,:3,iatom) = delta_grad_L2vf_notnormed(:,:3,iatom) / vecfeatures_normsigma1(iatom,nattention) / 2d0
            tpvalue = sum(delta_grad_L2vf_notnormed(:,:3,iatom) * vecfeatures_normed(:,:3,iatom,nattention))
            delta_grad_L2vf_notnormed(:,:3,iatom) = delta_grad_L2vf_notnormed(:,:3,iatom) - tpvalue*vecfeatures_normed(:,:3,iatom,nattention)/dble(atomembeddinglength)*4d0
         end do
         do iatom = 1,batchsnapnatom
            delta_grad_L2vf_notnormed(:,4:8,iatom) = delta_grad_L2vf_notnormed(:,4:8,iatom) / vecfeatures_normsigma2(iatom,nattention) / 2d0
            tpvalue = sum(delta_grad_L2vf_notnormed(:,4:8,iatom) * vecfeatures_normed(:,4:8,iatom,nattention))
            delta_grad_L2vf_notnormed(:,4:8,iatom) = delta_grad_L2vf_notnormed(:,4:8,iatom) - tpvalue*vecfeatures_normed(:,4:8,iatom,nattention)/dble(atomembeddinglength)*4d0
         end do
      end if

      grad_L2vf = delta_grad_L2vf_notnormed
      grad_L2ef = 0d0

      deallocate(grad_L2outx2,grad_L2outx1,grad_L2outx)
      deallocate(grad_L2outv2,grad_L2outv1,grad_L2outv)
      deallocate(grad_L2outvecnorm2head,grad_L2outvecnorm1head)
      deallocate(grad_L2vecout2,grad_L2vecout1)

      deallocate(tpinputs)
      allocate(tpinputs(atomembeddinglength,3,batchsnapnatom))
      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         tpinputs = 0d0
         forall (i = 1:atomembeddinglength)
            tpinputs(i:i,:,iatom) = matmul(grad_L2vf(i:i,:,jatom)*batchmijdir(i,iedge,nattention),grad_dirij2coordi(:,:,iedge))/grad_L2atomenergy(iatom)
         end forall
         forall (i=1:3)
            batchsnapatomforces(i,iatom) = batchsnapatomforces(i,iatom) + sum(tpinputs(:,i,iatom))
            batchsnapatomforces(i,jatom) = batchsnapatomforces(i,jatom) - sum(tpinputs(:,i,iatom))
         end forall
      end do

      allocate(grad_L2DenseK(headsize,headnum,batchsnapnedge),grad_L2DenseV(headsize,headnum,batchsnapnedge),grad_L2attn(headnum,batchsnapnedge))
      allocate(grad_L2K(headsize,headnum,batchsnapnatom),grad_L2V(headsize,headnum,batchsnapnatom),grad_L2Q(headsize,headnum,batchsnapnatom))
      allocate(grad_L2vecproj(atomembeddinglength*3,8,batchsnapnatom),grad_L2oproj(atomembeddinglength*3,batchsnapnatom))
      allocate(grad_L2fproj(atomembeddinglength,batchsnapnedge),grad_L2wsrcproj(atomembeddinglength,8,batchsnapnatom),grad_L2wtrgproj(atomembeddinglength,8,batchsnapnatom))
      allocate(grad_L2mij(atomembeddinglength,batchsnapnedge),grad_L2message(atomembeddinglength,batchsnapnatom))
      allocate(grad_L2sproj(atomembeddinglength*2,batchsnapnedge))

      if( gnnmode == 1 ) goto 102

      do iatt = nattention, 1, -1

         grad_L2fproj = 0d0; grad_L2wsrcproj = 0d0; grad_L2wtrgproj = 0d0
         grad_L2K = 0d0; grad_L2V = 0d0; grad_L2Q = 0d0
         grad_L2DenseK = 0d0; grad_L2DenseV = 0d0; grad_L2attn = 0d0
         grad_L2sproj = 0d0; grad_L2vecproj = 0d0; grad_L2oproj = 0d0
         grad_L2mij = 0d0; grad_L2message = 0d0

         if (gnnmode == 2) then
            do iedge=1,batchsnapnedge
               iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
               grad_L2mij(:,iedge) = grad_L2nf(:,jatom)
            end do
            go to 101
         end if

         !delta_node part
         do iatom = 1, batchsnapnatom
            do dim = 1, 8
               grad_L2vecproj(1:atomembeddinglength,dim,iatom) = grad_L2nf(:,iatom)*batchmessageangle(:,iatom,iatt)*batchvecs(:,dim,iatom,iatt)
               grad_L2vecproj(atomembeddinglength+1:atomembeddinglength*2,dim,iatom) = grad_L2nf(:,iatom)*batchmessageangle(:,iatom,iatt)*batchvect(:,dim,iatom,iatt)
               grad_L2vecproj(atomembeddinglength*2+1:atomembeddinglength*3,dim,iatom)=grad_L2vf(:,dim,iatom)*batchmessagevm(:,iatom,iatt)
            end do
            grad_L2oproj(1:atomembeddinglength,iatom)=sum(grad_L2vf(:,:,iatom)*batchvecv(:,:,iatom,iatt),dim=2)
            grad_L2oproj(atomembeddinglength+1:atomembeddinglength*2,iatom) = grad_L2nf(:,iatom)*sum(batchvect(:,:,iatom,iatt)*batchvecs(:,:,iatom,iatt),dim=2)
            grad_L2oproj(atomembeddinglength*2+1:atomembeddinglength*3,iatom) = grad_L2nf(:,iatom)
         end do

         ! modified on 2026.01.27
         !delta_edge part
         if ( (iatt /= nattention) .and. (iatt /= 1) ) then
            do iedge=1,batchsnapnedge
               iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
               do dim=1,8
                  grad_L2wtrgproj(:,dim,jatom) = grad_L2wtrgproj(:,dim,jatom)+grad_L2ef(:,iedge)*batchedgedih(:,iedge,iatt)*batchvecdihs(:,dim,iatom,iatt)
                  grad_L2wsrcproj(:,dim,iatom) = grad_L2wsrcproj(:,dim,iatom)+grad_L2ef(:,iedge)*batchedgedih(:,iedge,iatt)*batchvecdiht(:,dim,jatom,iatt)
                  grad_L2fproj(:,iedge) = grad_L2fproj(:,iedge) + grad_L2ef(:,iedge)* batchvecdiht(:,dim,jatom,iatt)* batchvecdihs(:,dim,iatom,iatt)
               end do
            end do
         end if 

         !delta_vec part
         delta_grad_L2vf_notnormed = 0d0
         upper_grad_L2vf(:,:,:) = grad_L2vf(:,:,:)

         do iedge=1,batchsnapnedge
            iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
            grad_L2sproj(1:atomembeddinglength,iedge:iedge) = matmul(upper_grad_L2vf(:,:,jatom),batchedgedirections(:,iedge:iedge))
            grad_L2sproj(atomembeddinglength+1:atomembeddinglength*2,iedge) = sum(upper_grad_L2vf(:,:,jatom)*vecfeatures_normed(:,:,iatom,iatt-1),dim=2)
            do dim=1,8
               delta_grad_L2vf_notnormed(:,dim,iatom) = delta_grad_L2vf_notnormed(:,dim,iatom)+upper_grad_L2vf(:,dim,jatom)*batchmijvec(:,iedge,iatt)
            end do
         end do

         if ( ifuselayernorm .and. (iatt /= 1) ) then
            do iatom = 1,batchsnapnatom
               delta_grad_L2vf_notnormed(:,:3,iatom) = delta_grad_L2vf_notnormed(:,:3,iatom) / vecfeatures_normsigma1(iatom,iatt-1) / 2d0
               tpvalue = sum(delta_grad_L2vf_notnormed(:,:3,iatom) * vecfeatures_normed(:,:3,iatom,iatt-1))
               delta_grad_L2vf_notnormed(:,:3,iatom) = delta_grad_L2vf_notnormed(:,:3,iatom) - tpvalue*vecfeatures_normed(:,:3,iatom,iatt-1)/dble(atomembeddinglength)*4d0
            end do
            do iatom = 1,batchsnapnatom
               delta_grad_L2vf_notnormed(:,4:8,iatom) = delta_grad_L2vf_notnormed(:,4:8,iatom) / vecfeatures_normsigma2(iatom,iatt-1) / 2d0
               tpvalue = sum(delta_grad_L2vf_notnormed(:,4:8,iatom) * vecfeatures_normed(:,4:8,iatom,iatt-1))
               delta_grad_L2vf_notnormed(:,4:8,iatom) = delta_grad_L2vf_notnormed(:,4:8,iatom) - tpvalue*vecfeatures_normed(:,4:8,iatom,iatt-1)/dble(atomembeddinglength)*4d0
            end do
         end if
         grad_L2vf = grad_L2vf + delta_grad_L2vf_notnormed

         !message part
         deallocate(tpoutputs)

         allocate(tpoutputs(atomembeddinglength,batchsnapnedge))
         call mlp0_network_backward_bptt(gnetsproj(iatt),1,reshape(grad_L2sproj,[atomembeddinglength*2,batchsnapnedge,1]),.false.,tpfirstdeltalayer=tpoutputs)
         grad_L2mij(:,:)=tpoutputs(1:atomembeddinglength,1:batchsnapnedge)

         deallocate(tpoutputs)
         allocate(tpoutputs(atomembeddinglength,batchsnapnatom))
         call mlp0_network_backward_bptt(gnetoproj(iatt),1,reshape(grad_L2oproj,[atomembeddinglength*3,batchsnapnatom,1]),.false.,tpfirstdeltalayer=tpoutputs)
         grad_L2message(:,:)=tpoutputs(:,:)
         do iedge = 1, batchsnapnedge
            iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
            grad_L2mij(:,iedge)=grad_L2mij(:,iedge)+grad_L2message(:,jatom)
         end do

         !attention part
         101 continue

         if ( gnnmode == 3 ) then

            do k=1,headnum
               do iedge=1,batchsnapnedge
                  iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)

                  grad_L2V(:,k,iatom)=grad_L2V(:,k,iatom)+ &
                     grad_L2mij((k-1)*headsize+1:k*headsize,iedge)* &
                     batchedgevalue(:,k,iedge,iatt)

                  grad_L2DenseV(:,k,iedge) = &
                     grad_L2mij((k-1)*headsize+1:k*headsize,iedge)* &
                     batchnodevalue(:,k,iatom,iatt)

               end do
            end do

            call mlp0_network_backward_bptt(gnetnodevalue(iatt),1,reshape(grad_L2V,[atomembeddinglength,batchsnapnatom,1]),.false.,tpfirstdeltalayer=delta_grad_L2nf)
            grad_L2nf(:,:) = grad_L2nf(:,:) + delta_grad_L2nf
               
         else if ( gnnmode == 2 .or. gnnmode == 4 ) then

            do k=1,headnum
               do iedge=1,batchsnapnedge
                  iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)

                  grad_L2DenseV(:,k,iedge)= &
                     grad_L2mij((k-1)*headsize+1:k*headsize,iedge)*headattentions(k,iedge,iatt)* &
                     batchnodevalue(:,k,iatom,iatt)
                  grad_L2V(:,k,iatom)=grad_L2V(:,k,iatom)+ &
                     grad_L2mij((k-1)*headsize+1:k*headsize,iedge)*headattentions(k,iedge,iatt)* &
                     batchedgevalue(:,k,iedge,iatt)
                  grad_L2attn(k,iedge) = &
                     dot_product(grad_L2mij((k-1)*headsize+1:k*headsize,iedge),batchedgevalue(:,k,iedge,iatt)* &
                     batchnodevalue(:,k,iatom,iatt))
                  grad_L2DenseK(:,k,iedge)= &
                     grad_L2attn(k,iedge)*batchedgedisdecays(iedge)*grad_attenactiv(k,iedge,iatt)* &
                     ( batchnodequery(:,k,jatom,iatt)*batchnodekey(:,k,iatom,iatt) )
                  grad_L2K(:,k,iatom)=grad_L2K(:,k,iatom)+ &
                     grad_L2attn(k,iedge)*batchedgedisdecays(iedge)*grad_attenactiv(k,iedge,iatt)* &
                     batchnodequery(:,k,jatom,iatt)*batchedgekey(:,k,iedge,iatt)
                  grad_L2Q(:,k,jatom)=grad_L2Q(:,k,jatom)+ &
                     grad_L2attn(k,iedge)*batchedgedisdecays(iedge)*grad_attenactiv(k,iedge,iatt)* &
                     batchnodekey(:,k,iatom,iatt)*batchedgekey(:,k,iedge,iatt)
               end do
            end do

            forall (iedge=1:batchsnapnedge)
               grad_L2decay(iedge) = grad_L2decay(iedge) + sum(grad_L2attn(:,iedge)*headattentions(:,iedge,iatt)/batchedgedisdecays(iedge))
            end forall

            call mlp0_network_backward_bptt(gnetnodevalue(iatt),1,reshape(grad_L2V,[atomembeddinglength,batchsnapnatom,1]),.false.,tpfirstdeltalayer=delta_grad_L2nf)
            grad_L2nf(:,:) = grad_L2nf(:,:) + delta_grad_L2nf

            call mlp0_network_backward_bptt(gnetnodequery(iatt),1,reshape(grad_L2Q,[atomembeddinglength,batchsnapnatom,1]),.false.,tpfirstdeltalayer=delta_grad_L2nf)
            grad_L2nf(:,:) = grad_L2nf(:,:) + delta_grad_L2nf

            call mlp0_network_backward_bptt(gnetnodekey(iatt),1,reshape(grad_L2K,[atomembeddinglength,batchsnapnatom,1]),.false.,tpfirstdeltalayer=delta_grad_L2nf)
            grad_L2nf(:,:) = grad_L2nf(:,:) + delta_grad_L2nf

            call mlp0_network_backward_bptt(gnetedgekey(iatt),1,reshape(grad_L2DenseK,[atomembeddinglength,batchsnapnedge,1]),.false.,tpfirstdeltalayer=delta_grad_L2ef)
            grad_L2ef(:,:) = grad_L2ef(:,:) + delta_grad_L2ef

         end if

         call mlp0_network_backward_bptt(gnetedgevalue(iatt),1,reshape(grad_L2DenseV,[atomembeddinglength,batchsnapnedge,1]),.false.,tpfirstdeltalayer=delta_grad_L2ef)
         grad_L2ef(:,:) = grad_L2ef(:,:) + delta_grad_L2ef

         ! modified on 2026.01.27
         if ( (iatt /= nattention) .and. (iatt /= 1) ) then
            call mlp0_network_backward_bptt(gnetfproj(iatt),1,reshape(grad_L2fproj,[atomembeddinglength,batchsnapnedge,1]),.false.,tpfirstdeltalayer=delta_grad_L2ef)
            grad_L2ef(:,:) = grad_L2ef(:,:) + delta_grad_L2ef
         end if

         delta_grad_L2vf_notnormed = 0d0

         ! modified on 2026.01.27
         if ( iatt > 1 ) then

            if (iatt /= nattention) then
               call mlp0_network_backward_bptt(gnetwsrcproj(iatt),1,reshape(grad_L2wsrcproj,[atomembeddinglength,batchsnapnatom*8,1]),.false.,tpfirstdeltalayer=delta_grad_L2vf(:,:))
               delta_grad_L2vf_notnormed = delta_grad_L2vf_notnormed + reshape(delta_grad_L2vf,[atomembeddinglength,8,batchsnapnatom])
               call mlp0_network_backward_bptt(gnetwtrgproj(iatt),1,reshape(grad_L2wtrgproj,[atomembeddinglength,batchsnapnatom*8,1]),.false.,tpfirstdeltalayer=delta_grad_L2vf(:,:))
               delta_grad_L2vf_notnormed = delta_grad_L2vf_notnormed + reshape(delta_grad_L2vf,[atomembeddinglength,8,batchsnapnatom])
            end if

            call mlp0_network_backward_bptt(gnetvecproj(iatt),1,reshape(grad_L2vecproj,[atomembeddinglength*3,batchsnapnatom*8,1]),.false.,tpfirstdeltalayer=delta_grad_L2vf(:,:))
            delta_grad_L2vf_notnormed = delta_grad_L2vf_notnormed + reshape(delta_grad_L2vf,[atomembeddinglength,8,batchsnapnatom])

         end if

         if ( ifuselayernorm .and. (iatt /= 1) ) then
            do iatom = 1,batchsnapnatom
               delta_grad_L2vf_notnormed(:,:3,iatom) = delta_grad_L2vf_notnormed(:,:3,iatom) / vecfeatures_normsigma1(iatom,iatt-1) / 2d0
               tpvalue = sum(delta_grad_L2vf_notnormed(:,:3,iatom) * vecfeatures_normed(:,:3,iatom,iatt-1))
               delta_grad_L2vf_notnormed(:,:3,iatom) = delta_grad_L2vf_notnormed(:,:3,iatom) - tpvalue*vecfeatures_normed(:,:3,iatom,iatt-1)/dble(atomembeddinglength)*4d0
            end do
            do iatom = 1,batchsnapnatom
               delta_grad_L2vf_notnormed(:,4:8,iatom) = delta_grad_L2vf_notnormed(:,4:8,iatom) / vecfeatures_normsigma2(iatom,iatt-1) / 2d0
               tpvalue = sum(delta_grad_L2vf_notnormed(:,4:8,iatom) * vecfeatures_normed(:,4:8,iatom,iatt-1))
               delta_grad_L2vf_notnormed(:,4:8,iatom) = delta_grad_L2vf_notnormed(:,4:8,iatom) - tpvalue*vecfeatures_normed(:,4:8,iatom,iatt-1)/dble(atomembeddinglength)*4d0
            end do
         end if
         grad_L2vf = grad_L2vf + delta_grad_L2vf_notnormed

         if ( iatt /= 1 ) then
            deallocate(tpinputs)
            allocate(tpinputs(atomembeddinglength,3,batchsnapnatom),rejmatrix(8,8))
!            if (iatt /= nattention) then
!               do iedge = 1, batchsnapnedge
!                  iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
!                  rejmatrix(:,:) = ones-matmul(reshape(batchedgedirections(:,iedge),[8,1]),reshape(batchedgedirections(:,iedge),[1,8]))
!                 tpinputs = 0d0
!                  forall (i = 1:atomembeddinglength)
!                     tpinputs(i:i,:,iatom)=-grad_L2ef(i,iedge)*batchedgedih(i,iedge,iatt-1)*matmul(transpose(matmul(matmul(matmul(batchvecdiht(i,:,iatom:iatom,iatt-1),batchvecdihs(i:i,:,jatom,iatt-1))+ &
!                     matmul(batchvecdihs(i,:,jatom:jatom,iatt-1),batchvecdiht(i:i,:,iatom,iatt-1)),rejmatrix)+matmul(rejmatrix,matmul(batchvecdiht(i,:,iatom:iatom,iatt-1),batchvecdihs(i:i,:,jatom,iatt-1))+ &
!                     matmul(batchvecdihs(i,:,jatom:jatom,iatt-1),batchvecdiht(i:i,:,iatom,iatt-1))),batchedgedirections(:,iedge:iedge))),grad_dirij2coordi(:,:,iedge))/grad_L2atomenergy(iatom)
!                  end forall
!                  forall (i=1:3)
!                     batchsnapatomforces(i,iatom) = batchsnapatomforces(i,iatom) + sum(tpinputs(:,i,iatom))
!                     batchsnapatomforces(i,jatom) = batchsnapatomforces(i,jatom) - sum(tpinputs(:,i,iatom))
!                  end forall
!               end do
!            end if
            deallocate(rejmatrix)
            do iedge = 1, batchsnapnedge
               iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
               tpinputs = 0d0
               forall (i = 1:atomembeddinglength)
                  tpinputs(i:i,:,iatom) = matmul(grad_L2vf(i:i,:,jatom)*batchmijdir(i,iedge,iatt-1),grad_dirij2coordi(:,:,iedge))/grad_L2atomenergy(iatom)
               end forall
               forall (i=1:3)
                  batchsnapatomforces(i,iatom) = batchsnapatomforces(i,iatom) + sum(tpinputs(:,i,iatom))
                  batchsnapatomforces(i,jatom) = batchsnapatomforces(i,jatom) - sum(tpinputs(:,i,iatom))
               end forall
            end do
         end if

      end do

      102 continue
      deallocate(delta_grad_L2vf_notnormed)
      deallocate(grad_L2DenseK,grad_L2DenseV,grad_L2attn,grad_L2Q,grad_L2V,grad_L2K,delta_grad_L2nf,delta_grad_L2ef,delta_grad_L2vf)
      deallocate(grad_L2sproj,grad_L2fproj,grad_L2wsrcproj,grad_L2wtrgproj)
      deallocate(grad_L2vecproj,grad_L2oproj)
      deallocate(grad_L2vf)

      deallocate(tpinputs)
      allocate(tpinputs(atomembeddinglength,batchsnapnatom,1))
      tpinputs(:,:,1) = grad_L2nf(:,:)
      do iedge =1,batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         tpinputs(:,iatom,1)=tpinputs(:,iatom,1)+grad_L2ef(:,iedge)*largeedgeembeddings_for_edge(:,iedge)
         tpinputs(:,jatom,1)=tpinputs(:,jatom,1)+grad_L2ef(:,iedge)*largeedgeembeddings_for_edge(:,iedge)
      end do
      deallocate(tpoutputs)

      allocate(tpoutputs(atomembeddinglength*2,batchsnapnatom)); tpoutputs = 0d0
      call mlp0_network_backward_bptt(gnetmain(2),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)

      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         grad_L2decay(iedge) = grad_L2decay(iedge) + sum(largeedgeembeddings(:,iedge)*batchatomembeddings(:atomembeddinglength,iatom)*tpoutputs(:atomembeddinglength,jatom))
      end do

      allocate(grad_L2atomemb(atomembeddinglength*2,batchsnapnatom)); grad_L2atomemb=0d0
      grad_L2atomemb(atomembeddinglength+1:atomembeddinglength*2,:)=tpoutputs(atomembeddinglength+1:atomembeddinglength*2,:)
      do iedge =1,batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         grad_L2atomemb(:atomembeddinglength,iatom)=grad_L2atomemb(:atomembeddinglength,iatom)+tpoutputs(:atomembeddinglength,jatom)*batchedgedisdecays(iedge)*largeedgeembeddings(:,iedge)
      end do

      deallocate(tpinputs)
      allocate(tpinputs(atomembeddinglength, batchsnapnedge,1)); tpinputs = 0d0
      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         tpinputs(1:atomembeddinglength,iedge,1) = &
               tpoutputs(1:atomembeddinglength,jatom)*batchedgedisdecays(iedge)*batchatomembeddings(:,iatom)
      end do

      allocate(grad_L2edgeemb(edgeembeddinglength,batchsnapnedge))
      call mlp0_network_backward_bptt(gnetmain(1),1,tpinputs,.false.,tpfirstdeltalayer=grad_L2edgeemb)

      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         tpinputs(1:atomembeddinglength,iedge,1) = &
               grad_L2ef(:,iedge)*(nodefeatures_of_first_layer(:,iatom)+nodefeatures_of_first_layer(:,jatom))
      end do

      deallocate(tpoutputs); allocate(tpoutputs(edgeembeddinglength,batchsnapnedge))
      call mlp0_network_backward_bptt(gnetmain(4),1,tpinputs,.false.,tpfirstdeltalayer=tpoutputs)
      grad_L2edgeemb = grad_L2edgeemb + tpoutputs
      deallocate(tpinputs,tpoutputs,grad_L2nf,grad_L2ef)

      do iedge = 1, batchsnapnedge
         grad_L2decay(iedge) = grad_L2decay(iedge) + sum(grad_L2edgeemb(:,iedge)*batchedgeembeddings(:,iedge)/batchedgedisdecays(iedge))
      end do

      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         do i = 1, 3
            batchsnapatomforces(i,iatom) = batchsnapatomforces(i,iatom) + grad_L2decay(iedge)*grad_decay2dis(iedge)*batchedgedirections(i,iedge)/grad_L2atomenergy(iatom)
            batchsnapatomforces(i,jatom) = batchsnapatomforces(i,jatom) - grad_L2decay(iedge)*grad_decay2dis(iedge)*batchedgedirections(i,iedge)/grad_L2atomenergy(iatom) 
         end do
      end do

      allocate(grad_L2meanbeta(edgeembeddinglength*2,1)); grad_L2meanbeta = 0d0
      allocate(grad_L2intatomemb(atomembeddinglength*2,maxatomtype)); grad_L2intatomemb = 0d0

      do iatom = 1, batchsnapnatom
         grad_L2intatomemb(:,batchatomtype(iatom)+1)=grad_L2intatomemb(:,batchatomtype(iatom)+1) + grad_L2atomemb(:,iatom)
      end do

      call mlp0_network_backward_bptt(gnetatomemb,1,reshape(grad_L2intatomemb,[atomembeddinglength*2,maxatomtype,1]),.false.)

      do iedge = 1,batchsnapnedge
         do i = 1, edgeembeddinglength
            grad_L2meanbeta(i,1)=grad_L2meanbeta(i,1)+ &
               2d0*edgeembbetas(i)*(exp(-batchedgedistance(iedge))-edgeembmeans(i))* &
               batchedgeembeddings(i,iedge)*grad_L2edgeemb(i,iedge)
            grad_L2meanbeta(edgeembeddinglength+i,1)=grad_L2meanbeta(edgeembeddinglength+i,1)- &
               (exp(-batchedgedistance(iedge))-edgeembmeans(i))**2*batchedgeembeddings(i,iedge)*grad_L2edgeemb(i,iedge)
         end do
      end do

      do iedge = 1, batchsnapnedge
         iatom = batchsnapedges(1,iedge); jatom = batchsnapedges(2,iedge)
         do i = 1, 3
            batchsnapatomforces(i,iatom) = batchsnapatomforces(i,iatom) + sum(2d0*edgeembbetas(:)*(exp(-batchedgedistance(iedge))-edgeembmeans(:))* &
                  batchedgeembeddings(:,iedge)*grad_L2edgeemb(:,iedge)*exp(-batchedgedistance(iedge)))*batchedgedirections(i,iedge)/grad_L2atomenergy(iatom)
            batchsnapatomforces(i,jatom) = batchsnapatomforces(i,jatom) - sum(2d0*edgeembbetas(:)*(exp(-batchedgedistance(iedge))-edgeembmeans(:))* &
                  batchedgeembeddings(:,iedge)*grad_L2edgeemb(:,iedge)*exp(-batchedgedistance(iedge)))*batchedgedirections(i,iedge)/grad_L2atomenergy(iatom)
         end do

      end do

      batchsnapatomforces=-batchsnapatomforces

      if ( present(printinfo) ) then
         open(unit=100, file="force_prediction_result.txt", position='append')
         do i = 1, batchsnapnatom
            if ( present(calloss) ) then
               write(100,'(3f10.3,a,3f10.3)') batchsnapatomforces(1:3,i),"\t", batchrefsnapatomforces(1:3,i)
            else
               write(100,'(3f10.3)') batchsnapatomforces(1:3,i)
            end if
         end do
         close(100)
      end if

      if ( present(calloss) ) then

         do idata = 1, batchsnapnmol
            iatomstart = batchsnapatomindex(idata)+1
            iatomstop = batchsnapatomindex(idata+1)
            do i = iatomstart, iatomstop
               select case (lossfunctype)
                  case (RMSE)
                     tploss = sum((batchsnapatomforces(:,i) - batchrefsnapatomforces(:,i))**2)/3d0
                  case (MAE)
                     tploss = sum(abs(batchsnapatomforces(:,i) - batchrefsnapatomforces(:,i)))/3d0
               end select
               totforceloss = totforceloss + tploss
            end do
         end do

      end if

      call mlp0_network_backward_bptt(gnetedgeemb,1,reshape(grad_L2meanbeta,[edgeembeddinglength*2,1,1]),.false.)
      deallocate(grad_L2atomemb,grad_L2edgeemb,grad_L2intatomemb,grad_L2meanbeta)

   end subroutine

   subroutine check_message_distribution(message1,name1,message2,name2,message3,name3,message4,name4)
      real*8, intent(in),optional :: message1(:), message2(:,:), message3(:,:,:), message4(:,:,:,:)
      Character(len=*), intent(in), optional :: name1, name2, name3, name4
      real*8 :: mean, std, max, min
      if ( present(message1) ) then
         mean = sum(message1)/dble(size(message1))
         std = sqrt( sum( (message1 - mean)**2 ) / dble(size(message1)) )
         max = maxval(message1); min = minval(message1)
         print "(A15,a,e10.3,a,e10.3,a,e10.3,a,e10.3)" ,name1,": mean=",mean," std=",std," max=",max," min=",min
      end if
      if ( present(message2) ) then
         mean = sum(message2)/dble(size(message2))
         std = sqrt( sum( (message2 - mean)**2 ) / dble(size(message2)) )
         max = maxval(message2); min = minval(message2)
         print "(A15,a,e10.3,a,e10.3,a,e10.3,a,e10.3)" ,name2,": mean=",mean," std=",std," max=",max," min=",min
      end if
      if ( present(message3) ) then
         mean = sum(message3)/dble(size(message3))
         std = sqrt( sum( (message3 - mean)**2 ) / dble(size(message3)) )
         max = maxval(message3); min = minval(message3)
         print "(A15,a,e10.3,a,e10.3,a,e10.3,a,e10.3)" ,name3,": mean=",mean," std=",std," max=",max," min=",min
      end if
      if ( present(message4) ) then
         mean = sum(message4)/dble(size(message4))
         std = sqrt( sum( (message4 - mean)**2 ) / dble(size(message4)) )
         max = maxval(message4); min = minval(message4)
         print "(A15,a,e10.3,a,e10.3,a,e10.3,a,e10.3)" ,name4,": mean=",mean," std=",std," max=",max," min=",min
      end if
   end subroutine

   subroutine cpugnn_check_grads()
      integer :: ilayer,i,j,iedge,iatom,imol,isnap,dim,nlayer, maxerrorposi=1, maxerrorposj=1, maxerrorposilayer=2
      integer, allocatable :: layers(:)
      real*8 :: tpvalue, delta, maxerror, refoutput, newoutput, maxnewoutput, w0, gradw, bias0, gradbias, finitediff, maxerrorfinitediff
      real*8 :: refene, newene, totdiff, totamount
      if ( lossfunctype /= RMSE ) stop "lossfunctype has to be RMSE"

      !networklist(1:3) = [gnetmain(1), gnetmain(2), gnetmain(3)(1E-7)]
      !do iatt = 1, nattention
      !   networklist(3+iatt*11-10:3+iatt*11) = &
      !        [gnetnodequery(iatt)(37), gnetnodekey(iatt)(38), gnetnodevalue(iatt)(39), gnetedgekey(iatt)(40), gnetedgevalue(iatt)(41), &
      !        gnetsproj(iatt)(42), gnetvecproj(iatt)(43), gnetfproj(iatt)(44), gnetwsrcproj(iatt)(45), gnetwtrgproj(iatt)(46), gnetoproj(iatt)(47)]
      !end do

      delta = 0.000001d0; maxerror = -1d0

      call mlp0_network_reloadall(networklist)

      call gnnpub_prepare_batchsize([1],1,1)
      call gnnpub_initialize_for_dynamic_batchsize()
      call cpugnn_prepare_batchdata()
      !call cpugnn_calculate_batch_atom_info([1],1)
      call cpugnn_calculate_batch_edge_info([1],1)
      call cpugnn_network_forward(tptotloss=refoutput,energy_prediction=refene,ifcheck=.true.)
      print *,"refoutput: ",refoutput, " refene: ",refene
      call cpugnn_network_backward()

      if(.false.)then
         totdiff = 0d0; totamount = 0d0
         do iatom=1,batchsnapnatom
            do i=1,3
               delta_coors(1,i,iatom)=delta
               call cpugnn_calculate_batch_edge_info([1],1)
               call cpugnn_network_forward(energy_prediction=newene,ifcheck=.true.)
               finitediff = - (newene - refene) / delta
               print "(a,E12.4,a,E12.4)","finitediff ",finitediff,", force ",batchsnapatomforces(i,iatom)
               totdiff = totdiff + abs(finitediff - batchsnapatomforces(i,iatom))
               totamount = totamount + abs(batchsnapatomforces(i,iatom))
               if(abs(finitediff-batchsnapatomforces(i,iatom))>maxerror)then
                  maxerror = abs(finitediff - batchsnapatomforces(i,iatom))
                  maxerrorfinitediff=finitediff
               end if
               delta_coors = 0d0
            end do
         end do
         print *,"maxerror of force",maxerror,maxerrorfinitediff
         print "(a,E14.6,a,E14.6)","totdiff: ",totdiff," totamount: ",totamount
         call cpugnn_calculate_batch_edge_info([1],1)
         call cpugnn_network_forward(energy_prediction=newene,ifcheck=.true.)
         print *,"finalene: ",newene
      end if

      if(.false.)then
         do iatom=1,batchsnapnatom
            do i=1,atomembeddinglength
               do dim=1,8
                  delta_vf(i,dim,iatom)=delta
                  call cpugnn_network_forward(tptotloss=newoutput,ifcheck=.true.)
                  finitediff=(newoutput-refoutput)/delta
                  print *,i,dim,iatom,"message_for_test3 " ,message_for_test3(i,dim,iatom), " finitediff ",finitediff
                  if(abs(finitediff-message_for_test3(i,dim,iatom))>maxerror)then
                     maxerror = abs(finitediff - message_for_test3(i,dim,iatom))
                     maxerrorfinitediff=finitediff
                  end if
                  delta_vf=0d0
               end do
            end do
         end do
         print *,"maxerror of grad_L2vf",maxerror," value:",maxerrorfinitediff
         call cpugnn_calculate_batch_edge_info([1],1)
      end if

      if(.false.)then
         do iatom=1,batchsnapnedge
            do i=1,atomembeddinglength
               do dim=1,3
                  delta_check(i,iatom)=delta
                  call cpugnn_network_forward(tptotloss=newoutput,ifcheck=.true.)
                  finitediff=(newoutput-refoutput)/delta
                  print *,i,iatom,"message_for_test2 ",message_for_test2(i,iatom)," finitediff ",finitediff
                  if(abs(finitediff-message_for_test2(i,iatom))>maxerror)then
                     maxerror = abs(finitediff - message_for_test2(i,iatom))
                     maxerrorfinitediff=finitediff
                  end if
                  delta_check=0d0
               end do
            end do
         end do
         print *,"maxerror of grad_L2nf",maxerror,maxerrorfinitediff
         call cpugnn_calculate_batch_edge_info([1],1)
      end if
      
      if(.false.)then
         do iedge=1,batchsnapnedge
            delta_decay(iedge)=delta
            call cpugnn_calculate_batch_edge_info([1],1)
            call cpugnn_network_forward(tptotloss=newoutput,ifcheck=.true.)
            finitediff=(newoutput-refoutput)/(delta+1d-14)
            print "(a,E14.6,a,E14.6)","message_for_test1 ",message_for_test1(iedge)," finitediff ",finitediff
            if(abs(finitediff-message_for_test1(iedge))>maxerror)then
               maxerror = abs(finitediff - message_for_test1(iedge))
               maxerrorfinitediff=finitediff
            end if
            delta_decay=0d0
         end do
         print *,"maxerror of grad_L2nf",maxerror,maxerrorfinitediff
         call cpugnn_calculate_batch_edge_info([1],1)
      end if

      call mlp0_getlayerinfo(networklist(net_for_checking), nlayer, layers)
      finitediff = 0d0; maxerror = -1d0; maxerrorfinitediff = 0d0
      do ilayer = 2, nlayer
         do i = 1, layers(ilayer-1)       ! cycle over neurons in ilayer
            do j = 1, layers(ilayer)   ! cycle over neurons in ilayer-1
            !do j = layers(ilayer), 1, -1 

               call mlp0_getweight(networklist(net_for_checking),ilayer,j,i,w0,gradw)
               call mlp0_setweight(networklist(net_for_checking),ilayer,j,i,w0 + delta)
               call cpugnn_network_forward(tptotloss=newoutput,ifcheck=.false.)
               finitediff = (newoutput - refoutput) / delta
               !finitediff = (newoutput - refoutput) / (delta + 0.0001d0)
               !print *,"newoutput , refoutput ",ilayer,i,j,newoutput , refoutput
               !print *,"gradw, finitediff ",gradw, finitediff
               
               if ( abs(finitediff - gradw) > maxerror ) then
                  maxerror = abs(finitediff - gradw)
                  maxnewoutput = newoutput
                  if (abs(finitediff)<1E-10)then
                     finitediff=1E-10
                  end if
                  maxerrorfinitediff = finitediff
                  maxerrorposilayer = ilayer; maxerrorposi = i; maxerrorposj = j
               end if
               call mlp0_setweight(networklist(net_for_checking),ilayer,j,i,w0)

            end do
         end do
      end do
      call mlp0_getweight(networklist(net_for_checking),maxerrorposilayer,maxerrorposj,maxerrorposi,w0,gradw)
      if (abs(gradw)<1E-10)then
         gradw=1E-10
      end if
      !print *,"weight gradient relative error (to finitediff) ",maxerror/maxerrorfinitediff," (to gradw)",maxerror/gradw
      print *,"maxerror ,maxerrorfinitediff ,gradw ",maxerror,maxerrorfinitediff,gradw

      if (networklist(net_for_checking)%ifbias) then
         maxerror = -1d0
         do ilayer = 2, nlayer

            do i = 1, layers(ilayer)       ! cycle over neurons in ilayer
            !do i = layers(ilayer), 1, -1 
                  call mlp0_getbias(networklist(net_for_checking),ilayer,i,bias0,gradbias=gradbias)
                  call mlp0_setbias(networklist(net_for_checking),ilayer,i,bias0 + delta)
                  call cpugnn_network_forward(tptotloss=newoutput)
                  finitediff = (newoutput - refoutput) / delta
                  !finitediff = (newoutput - refoutput) / (delta + 0.0001d0)
                  !print *,"newoutput , refoutput ",newoutput , refoutput
                  print *,"gradbias, finitediff ",gradbias, finitediff
                  if ( abs(finitediff - gradbias) > maxerror ) then
                     maxerror = abs(finitediff - gradbias)
                     if (abs(finitediff)<1E-10)then
                        finitediff=1E-10
                     end if
                     maxerrorfinitediff = finitediff
                     maxerrorposilayer = ilayer; maxerrorposi = i
                  end if
                  call mlp0_setbias(networklist(net_for_checking),ilayer,i,bias0)
            end do
         end do
         call mlp0_getbias(networklist(net_for_checking),maxerrorposilayer,maxerrorposi,bias0,gradbias=gradbias)
         if (abs(gradbias)<1E-10)then
            gradbias=1E-10
         end if
         !print *,"bias gradient relative error (to finitediff) ",maxerror/maxerrorfinitediff," (to gradbias)",maxerror/gradbias
         print *,"maxerror ,maxerrorfinitediff ,gradbias ",maxerror,maxerrorfinitediff,gradbias
      end if
      deallocate(layers)

      !if ( iflayernorm .eqv. .true. ) then
         maxerror = 0d0
         do ilayer = 1, nlayer-1
            call mlp0_get_layernorm_weightbias(networklist(net_for_checking),ilayer,w0,tpvalue,gradlayerweight=gradw)
            call mlp0_set_layernorm_weightbias(networklist(net_for_checking),ilayer,w0+delta,tpvalue)
            call cpugnn_network_forward(tptotloss=newoutput)

            call mlp0_get_layernorm_weightbias(networklist(net_for_checking),ilayer,w0,tpvalue,gradlayerweight=gradw)
            finitediff = (newoutput - refoutput) / delta
            maxerror = max(maxerror,abs(finitediff-gradw))
            call mlp0_set_layernorm_weightbias(networklist(net_for_checking),ilayer,w0,tpvalue)
         end do
         print *,"max layernorm weight error ",maxerror
         maxerror = 0d0
         do ilayer = 1, nlayer-1
            call mlp0_get_layernorm_weightbias(networklist(net_for_checking),ilayer,tpvalue,bias0,gradlayerbias=gradbias)
            call mlp0_set_layernorm_weightbias(networklist(net_for_checking),ilayer,tpvalue,bias0+delta)
            call cpugnn_network_forward(tptotloss=newoutput)
            finitediff = (newoutput - refoutput) / delta
            maxerror = max(maxerror,abs(finitediff-gradbias))
            call mlp0_set_layernorm_weightbias(networklist(net_for_checking),ilayer,tpvalue,bias0)
         end do
         print *,"max layernorm bias error ",maxerror
      !end if
   end subroutine

   end module
