module torch
    use, intrinsic :: iso_c_binding
    implicit none
    
    interface
        ! C函数接口
        function predict_molecules_c( &
            url, &
            z, z_len, &
            pos, &
            edge_index, edge_len, &
            batch, batch_len, &
            force_output, &
            energy_output, &
            max_molecules &
        ) bind(C, name="predict_molecules")
            use, intrinsic :: iso_c_binding
            character(kind=c_char), intent(in) :: url(*)
            integer(c_int), intent(in), value :: z_len
            integer(c_int), intent(in) :: z(z_len)
            real(c_double), intent(in) :: pos(*)
            integer(c_int), intent(in), value :: edge_len
            integer(c_int), intent(in) :: edge_index(2*edge_len)
            integer(c_int), intent(in), value :: batch_len
            integer(c_int), intent(in) :: batch(batch_len)
            real(c_double), intent(out) :: force_output(*)
            real(c_double), intent(out) :: energy_output(*)
            integer(c_int), intent(in), value :: max_molecules
            integer(c_int) :: predict_molecules_c
        end function predict_molecules_c
    end interface
    
contains
    
    subroutine fortran_predict_molecules( &
        url, &
        atomic_numbers, &
        positions, &
        edge_indices, &
        batch_indices, &
        forces, &
        energies, &
        num_molecules, &
        status &
    )
        character(len=*), intent(in) :: url
        integer, intent(in) :: atomic_numbers(:)
        real(8), intent(in) :: positions(:, :)  ! 形状: [3, num_atoms]
        integer, intent(in) :: edge_indices(:, :)  ! 形状: [2, num_edges]
        integer, intent(in) :: batch_indices(:)
        real(8), intent(out) :: forces(:, :)  ! 形状: [3, num_atoms]
        real(8), intent(out) :: energies(:)   ! 长度: num_molecules
        integer, intent(out) :: num_molecules
        integer, intent(out) :: status
        
        integer :: num_atoms, num_edges, i, j
        real(8), allocatable :: pos_flat(:), force_flat(:)
        integer, allocatable :: edge_flat(:)
        character(len=:), allocatable :: c_url
        
        num_atoms = size(atomic_numbers)
        num_edges = size(edge_indices, 2)
        
        ! 检查维度
        if (size(positions, 1) /= 3 .or. size(positions, 2) /= num_atoms) then
            print *, "error: positions array dimension mismatch, expacted (3,", num_atoms, ") but got (", size(positions, 1), ",", size(positions, 2), ")"
            status = -1
            return
        end if
        
        if (size(forces, 1) /= 3 .or. size(forces, 2) /= num_atoms) then
            print *, "error: forces array dimension mismatch, expacted (3,", num_atoms, ") but got (", size(forces, 1), ",", size(forces, 2), ")"
            status = -2
            return
        end if
        
        ! 展平位置数组 (Fortran是列优先)
        allocate(pos_flat(3*num_atoms))
        do i = 1, num_atoms
            do j = 1, 3
                pos_flat((i-1)*3 + j) = positions(j, i)
            end do
        end do
        
        ! 展平边索引数组
        allocate(edge_flat(2*num_edges))
        do i = 1, num_edges
            edge_flat(i) = edge_indices(1, i) - 1  ! 转换为0-based索引
            edge_flat(num_edges + i) = edge_indices(2, i) - 1
        end do
        
        ! 准备输出数组
        allocate(force_flat(3*num_atoms))
        
        ! 准备C字符串
        c_url = trim(url) // C_NULL_CHAR
        
        ! 调用C函数
        status = predict_molecules_c( &
            c_url, &
            atomic_numbers, num_atoms, &
            pos_flat, &
            edge_flat, num_edges, &
            batch_indices, size(batch_indices), &
            force_flat, &
            energies, &
            size(energies) &
        )
        
        if (status > 0) then
            num_molecules = status
            
            ! 将展平的力数组转换回二维形式
            do i = 1, num_atoms
                do j = 1, 3
                    forces(j, i) = force_flat((i-1)*3 + j)
                end do
            end do
        else
            num_molecules = 0
            print *, "prediction failed with status: ", status
        end if
        
        ! 清理
        deallocate(pos_flat, edge_flat, force_flat)
    end subroutine fortran_predict_molecules
    
    subroutine torch_potforce(z, pos, energy, force)
        character(len=256) :: url
        integer, intent(in) :: z(:)
        real(8), intent(in) :: pos(:, :)
        real(8), intent(out) :: energy
        real(8), intent(out) :: force(:, :)
        integer, allocatable :: edge_index(:, :)
        integer :: tpedgeindex = 0, iatom, jatom, snapedges(2, 10000)
        real(8) :: tpdissq
        integer, allocatable :: batch(:)
        real(8), allocatable :: forces(:, :)
        real(8) :: energies(1)
        integer :: num_molecules, num_atom, status
        integer :: i
        real(8), parameter :: tpdiscutsq = 5.0d0**2
        
        ! 设置URL (确保Python服务正在运行)
        url = "http://localhost:8000/predict"

        tpedgeindex = 0
        num_atom = size(z)
        num_molecules = 1
        do iatom = 1, num_atom
            do jatom = iatom+1, num_atom
                tpdissq = sum((pos(1:3,iatom) - pos(1:3,jatom))**2)
                if ( tpdissq < tpdiscutsq ) then
                    tpedgeindex = tpedgeindex + 2
                    snapedges(1:2,tpedgeindex-1) = [iatom,jatom]
                    snapedges(1:2,tpedgeindex) = [jatom,iatom]
                end if
            end do
        end do
        allocate(forces(3,num_atom))
        allocate(edge_index(2,tpedgeindex))
        edge_index = snapedges(:,1:tpedgeindex)
        allocate(batch(num_atom)); batch = 0

        ! 调用预测函数
        call fortran_predict_molecules( &
            url, &
            z, &
            pos, &
            edge_index, &
            batch, &
            forces, &
            energies, &
            num_molecules, &
            status &
        )
        if ( status <= 0 ) then
            print *, "Error in prediction, status: ", status
            energy = 0.0d0
            force = 0.0d0
        else
            energy = energies(1)
            force = forces
        end if

        if (status > 0) then
!            print *, "energies: ", energies(1:num_molecules)
!            print *, "forces:"
!            do i = 1, num_atom*num_molecules
!                print "(A,I2,A,3F12.6)", "  atom ", i, ": ", forces(:, i)
!            end do
        else
            print *, "prediction failed with status: ", status
        end if
    end subroutine torch_potforce
end module torch