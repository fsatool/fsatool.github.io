module mlp1
  use curand_device
  use deeppub
  implicit none

  type(mlplayer),dimension(:),allocatable,public :: mlplayers1
  integer,private :: iflastactivation
  integer,dimension(:),allocatable,private :: hiddenstate_index
  real*8,allocatable,dimension(:),private :: outputweight

  integer,private :: nlayer,noutput,ninput

!===================== variables on GPU

  type(curandStatePhilox4_32_10),device,allocatable,private :: curandState_d(:)

  integer,device,private :: nlayer_d,ninput_d,noutput_d,ninputgroupstep_d,ninputgroup_d,noutputgroupstep_d,noutputgroup_d

  integer,dimension(:),allocatable,device,private :: mlplayers1_d

  integer,dimension(:),allocatable,device,private :: hiddenstate_index_d
  real(kind=SD),dimension(:),allocatable,device,private :: hiddenstate_d

  integer,dimension(:),allocatable,device,private :: delta_layer_index_d
  real(kind=SD),dimension(:),allocatable,device,private :: delta_layer_d

  integer,dimension(:),allocatable,private :: weights_l2l_index
  integer,dimension(:),allocatable,device,private :: weights_l2l_index_d
  real(kind=SD),dimension(:),allocatable,device,private :: weights_l2l_d, grad_weights_l2l_d,gradg_weights_l2l_d,gradgsq_weights_l2l_d

  integer,dimension(:),allocatable,private :: weights_t2t_index
  integer,dimension(:),allocatable,device,private :: weights_t2t_index_d
  real(kind=SD),dimension(:),allocatable,device,private :: weights_t2t_d, grad_weights_t2t_d,gradg_weights_t2t_d, gradgsq_weights_t2t_d

  integer,dimension(:),allocatable,private :: bias_index
  integer,dimension(:),allocatable,device,private :: bias_index_d
  real(kind=SD),dimension(:),allocatable,device,private :: bias_d,grad_bias_d,gradg_bias_d,gradgsq_bias_d

  integer,dimension(:),allocatable,device,private :: grad_active_index_d
  real(kind=SD),dimension(:),allocatable,device,private :: grad_active_d

contains

subroutine mlp1_initialize(tpninput,tpnoutput,tpnlayer,layers,totparms,tpoutputweight)
  integer,intent(in) :: tpninput,tpnoutput,tpnlayer,layers(:)
  integer,intent(inout) :: totparms
  real*8,intent(in),optional :: tpoutputweight(:)
  integer :: iweightl2l,iweightt2t,ibias,ilayer,istate,ideltalayer,iactive,i,j,k
  integer :: recstart,recend,cheight,cwidth
  real*8 :: rand
  real(kind=SD),device,allocatable :: c_d(:)

  ninput = tpninput; noutput = tpnoutput; nlayer = tpnlayer
  if ( present(tpoutputweight) ) then
     allocate(outputweight(noutput)); outputweight = tpoutputweight
  end if

  if ( allocated(mlplayers1) ) deallocate(mlplayers1)
  allocate(mlplayers1(nlayer))

!  allocate(layers(nlayer)); layers = tplayers
  iweightl2l = 0; iweightt2t = 0; ibias = 0
  do ilayer=1,nlayer

     mlplayers1(ilayer)%neurons = layers(ilayer) 

     allocate(mlplayers1(ilayer)%hiddenstate(layers(ilayer),batchsize,maxnsteps,netnum))
     mlplayers1(ilayer)%hiddenstate(:,:,:,:) = 0d0
     if ( ifclasses == 1 .and. ilayer == nlayer ) then
        allocate(mlplayers1(ilayer)%softmaxstate(layers(ilayer),batchsize,maxnsteps,netnum))
        mlplayers1(ilayer)%softmaxstate(:,:,:,:) = 0d0
     end if

     allocate(mlplayers1(ilayer)%delta_layer(layers(ilayer))); mlplayers1(ilayer)%delta_layer = 0d0
 
     if ( ilayer == 1 ) cycle

     iweightl2l = iweightl2l + layers(ilayer)*layers(ilayer-1)
     allocate(mlplayers1(ilayer)%weights_l2l(layers(ilayer),layers(ilayer-1)))
     totparms = totparms + layers(ilayer)*layers(ilayer-1)
     if ( jobtype == TRAIN .or. jobtype == STREAM ) then
        call deeppub_normaldata_2d(mlplayers1(ilayer)%weights_l2l, 0d0, 1d0)
        mlplayers1(ilayer)%weights_l2l = mlplayers1(ilayer)%weights_l2l*0.1d0
     end if
     allocate(mlplayers1(ilayer)%grad_weights_l2l(layers(ilayer),layers(ilayer-1)))
     mlplayers1(ilayer)%grad_weights_l2l = 0d0
     if ( ioptmethod == 2 ) then
        allocate(mlplayers1(ilayer)%gradg_weights_l2l(layers(ilayer),layers(ilayer-1))); mlplayers1(ilayer)%gradg_weights_l2l=0.0d0
        allocate(mlplayers1(ilayer)%gradgsq_weights_l2l(layers(ilayer),layers(ilayer-1))); mlplayers1(ilayer)%gradgsq_weights_l2l=0.0d0
     end if

     ibias = ibias + layers(ilayer)
     allocate(mlplayers1(ilayer)%bias(layers(ilayer)))
     totparms = totparms + layers(ilayer)
     if ( jobtype == TRAIN .or. jobtype == STREAM ) then
        call deeppub_normaldata_1d(mlplayers1(ilayer)%bias, 0d0, 1d0)
        mlplayers1(ilayer)%bias = mlplayers1(ilayer)%bias*0.1d0
     end if
     allocate(mlplayers1(ilayer)%grad_bias(layers(ilayer))); mlplayers1(ilayer)%grad_bias = 0d0
     if ( ioptmethod == 2 ) then
        allocate(mlplayers1(ilayer)%gradg_bias(layers(ilayer))); mlplayers1(ilayer)%gradg_bias=0.0d0
        allocate(mlplayers1(ilayer)%gradgsq_bias(layers(ilayer))); mlplayers1(ilayer)%gradgsq_bias=0.0d0
     end if

     if ( maxnsteps > 1 ) then
        iweightt2t = iweightt2t + layers(ilayer)*layers(ilayer)
        allocate(mlplayers1(ilayer)%weights_t2t(layers(ilayer),layers(ilayer)))
        totparms = totparms + layers(ilayer)*layers(ilayer)
        if ( jobtype == TRAIN .or. jobtype == STREAM ) then
           call deeppub_normaldata_2d(mlplayers1(ilayer)%weights_t2t, 0d0, 1d0)
           mlplayers1(ilayer)%weights_t2t = mlplayers1(ilayer)%weights_t2t*0.1d0
        end if
        allocate(mlplayers1(ilayer)%grad_weights_t2t(layers(ilayer),layers(ilayer)))
        mlplayers1(ilayer)%grad_weights_t2t = 0d0
     end if

     if ( ilayer < nlayer ) then
        allocate(mlplayers1(ilayer)%grad_active(layers(ilayer),batchsize,maxnsteps,netnum))
        mlplayers1(ilayer)%grad_active = 1d0

        if ( ifuselayernorm .eqv. .true. ) then
           allocate(mlplayers1(ilayer)%layernormin(layers(ilayer),batchsize,1,netnum))
           allocate(mlplayers1(ilayer)%layernormout(layers(ilayer),batchsize,1,netnum))
           allocate(mlplayers1(ilayer)%layermean(batchsize,1,netnum)); mlplayers1(ilayer)%layermean = 1d0
           allocate(mlplayers1(ilayer)%layersigma(batchsize,1,netnum)); mlplayers1(ilayer)%layersigma = 0d0

           mlplayers1(ilayer)%grad_layerweight = 0d0
           mlplayers1(ilayer)%grad_layerbias = 0d0

           if ( jobtype == TRAIN .or. jobtype == STREAM ) then
              call random_number(rand); mlplayers1(ilayer)%layerweight = rand
              call random_number(rand); mlplayers1(ilayer)%layerbias = rand
           end if 
        end if
     end if

     if ( iflastactivation == 1 .and. ilayer == nlayer ) then
        allocate(mlplayers1(ilayer)%grad_active(layers(ilayer),batchsize,maxnsteps,netnum))
        mlplayers1(ilayer)%grad_active = 1d0
     end if

  end do

  if ( icudagroup > 0 ) then

     iweightl2l = 0; iweightt2t = 0; ibias = 0
     do ilayer=1,nlayer
        if ( ilayer == 1 ) cycle
        iweightl2l = iweightl2l + layers(ilayer)*layers(ilayer-1)
        ibias = ibias + layers(ilayer)
        if ( maxnsteps > 1 ) then
           iweightt2t = iweightt2t + layers(ilayer)*layers(ilayer)
        end if
     end do
   
     istate = 0; ideltalayer = 0; iactive = 0
     do ilayer=1,nlayer
        ideltalayer = ideltalayer + layers(ilayer)*icudagroup*maxnsteps*netnum
        istate = istate + layers(ilayer)*icudagroup*maxnsteps*netnum
        if ( ilayer == 1 ) cycle
        if ( ilayer < nlayer ) then
           iactive = iactive + layers(ilayer)*icudagroup*maxnsteps*netnum
        end if
     end do
   
     nlayer_d = nlayer; ninput_d = ninput; noutput_d = noutput
     allocate(mlplayers1_d(nlayer));  mlplayers1_d = layers
     allocate(weights_l2l_index(nlayer+1)); weights_l2l_index = 0
     allocate(weights_l2l_index_d(nlayer+1)); weights_l2l_index_d = 0
     allocate(weights_l2l_d(iweightl2l), grad_weights_l2l_d(iweightl2l))
     weights_l2l_d = 0.0_SD; grad_weights_l2l_d = 0.0_SD
   
     if ( ioptmethod == 2 ) then
        allocate(gradg_weights_l2l_d(iweightl2l), gradgsq_weights_l2l_d(iweightl2l))
        gradg_weights_l2l_d = 0.0_SD; gradgsq_weights_l2l_d = 0.0_SD
     end if
   
     if ( maxnsteps > 1 ) then
        allocate(weights_t2t_index(nlayer+1)); weights_t2t_index = 0
        allocate(weights_t2t_index_d(nlayer+1)); weights_t2t_index_d = 0
        allocate(weights_t2t_d(iweightt2t), grad_weights_t2t_d(iweightt2t))
        weights_t2t_d = 0.0_SD; grad_weights_t2t_d = 0.0_SD
     end if
   
     allocate(bias_index(nlayer+1)); bias_index = 0
     allocate(bias_index_d(nlayer+1)); bias_index_d = 0
     allocate(bias_d(ibias), grad_bias_d(ibias)); bias_d = 0.0_SD; grad_bias_d = 0.0_SD
   
     if ( ioptmethod == 2 ) then
        allocate(gradg_bias_d(ibias), gradgsq_bias_d(ibias)); gradg_bias_d = 0.0_SD; gradgsq_bias_d = 0.0_SD
     end if
   
     allocate(grad_active_index_d(nlayer+1)); grad_active_index_d = 0
     allocate(grad_active_d(iactive)); grad_active_d = 0.0_SD
   
     allocate(hiddenstate_index(nlayer+1)); hiddenstate_index = 0
     allocate(hiddenstate_index_d(nlayer+1)); hiddenstate_index_d = 0
     allocate(hiddenstate_d(istate)); hiddenstate_d = 0.0_SD
   
     allocate(delta_layer_index_d(nlayer+1)); delta_layer_index_d = 0
     allocate(delta_layer_d(ideltalayer)); delta_layer_d = 0.0_SD
   
     iweightl2l = 0; iweightt2t = 0; istate = 0; ibias = 0; iactive = 0; ideltalayer = 0
   
     do ilayer=1,nlayer
   
        ideltalayer = ideltalayer + layers(ilayer)*icudagroup*maxnsteps*netnum
        delta_layer_index_d(ilayer+1) = ideltalayer
   
        istate = istate + layers(ilayer)*icudagroup*maxnsteps*netnum
        hiddenstate_index(ilayer+1) = istate
   
        if ( ilayer == 1 ) cycle
   
        iweightl2l = iweightl2l + layers(ilayer)*layers(ilayer-1)
        weights_l2l_index(ilayer+1) = iweightl2l
   
        ibias = ibias + layers(ilayer)
        bias_index(ilayer+1) = ibias
   
        if ( maxnsteps > 1 ) then
           iweightt2t = iweightt2t + layers(ilayer)*layers(ilayer)
           weights_t2t_index_d(ilayer+1) = iweightt2t
   !        i = weights_t2t_index_d(ilayer)+1; j = weights_t2t_index_d(ilayer+1)
   !        weights_t2t_d(i:j) = pack(mlplayers1(ilayer)%weights_t2t,.true.)
        end if
   
        if ( ilayer < nlayer ) then
           iactive = iactive + layers(ilayer)*icudagroup*maxnsteps*netnum
           grad_active_index_d(ilayer+1) = iactive
           i = grad_active_index_d(ilayer)+1; j = grad_active_index_d(ilayer+1)
           grad_active_d(i:j) = pack(mlplayers1(ilayer)%grad_active,.true.)
        else
           grad_active_index_d(ilayer+1) = iactive
        end if
   
     end do
   
     hiddenstate_index_d = hiddenstate_index
     ninputgroupstep_d = ninput*icudagroup*maxnsteps; ninputgroup_d = ninput*icudagroup
     noutputgroupstep_d = noutput*icudagroup*maxnsteps; noutputgroup_d = noutput*icudagroup
     weights_l2l_index_d = weights_l2l_index; bias_index_d = bias_index
   
     allocate(curandState_d(iactive)); call mlp1_curandinit<<<(iactive-1)/32+1,32>>>()
   
  end if

  if ( jobtype == PREDICT .or. jobtype == CHECK .or. ifproceed .eqv. .true. ) then
     call mlp1_network_reload()
  else
     if ( icudagroup > 0 ) call mlp1_network_upload()
  end if

end subroutine

subroutine mlp1_layer_normalization_forward(invals,outvals,mean,sigma)
  real*8,dimension(:),intent(in) :: invals
  real*8,dimension(:),intent(out) :: outvals
  real*8,intent(inout) :: mean,sigma
  integer :: num

  num = size(invals)
  mean = sum(invals(1:num))/dble(num)
  sigma = sqrt( sum( (invals(1:num) - mean)**2 ) / dble(num) )
  outvals(1:num) = ( invals(1:num) - mean )/sigma
end subroutine

subroutine mlp1_layer_normalization_backward(invals,bvals,mean,sigma)
  real*8,dimension(:),intent(in) :: invals
  real*8,dimension(:),intent(inout) :: bvals
  real*8,intent(in) :: mean,sigma
  integer :: num
  real*8 :: tpsum1,tpsum2

  num = size(invals)
  tpsum1 = sum(bvals); tpsum2 = sum((invals-mean)*bvals)
  bvals = bvals/sigma - tpsum1/(dble(num)*sigma) - (invals-mean)*tpsum2/(dble(num)*sigma**3d0)
end subroutine

subroutine mlp1_layer_normalization_check()
  real*8,dimension(:),allocatable :: invals,outvals,bvals,orivals,outvals1,outvals2,tpvals
  real*8 :: mean,sigma,h,tpsum1,tpsum2,maxerr
  integer :: num,i,j,k

  num = 100; allocate(invals(num),outvals(num),bvals(num),orivals(num),outvals1(num),outvals2(num),tpvals(num))
  do i = 1,num
     invals(i) = sin(dble(i)); bvals(i) = cos(dble(i))
  end do
  orivals = invals
  call mlp1_layer_normalization_forward(invals,outvals,mean,sigma)
  tpvals = bvals
  call mlp1_layer_normalization_backward(invals,bvals,mean,sigma)
  h = 0.001d0; invals = orivals; maxerr = 0d0
  do i = 1,num
     invals(i) = orivals(i) + h
     call mlp1_layer_normalization_forward(invals,outvals1,mean,sigma)
     invals(i) = orivals(i) - h
     call mlp1_layer_normalization_forward(invals,outvals2,mean,sigma)
     invals(i) = orivals(i)
     maxerr = max(abs(sum(tpvals*(outvals1(:)-outvals2(:)))/(2d0*h)-bvals(i)),maxerr)
  end do
  write(6,'(a,f15.10)'),'Layer Normalization Error:',maxerr
end subroutine

!========================= Network Forward and Backward propagation ====================================

subroutine mlp1_network_forward(netidx,inputs,outputs,errormark)
  integer,intent(in) :: netidx
  real*8,dimension(:,:,:),intent(in) :: inputs
  real*8,dimension(:,:,:),intent(out) :: outputs
  integer,dimension(:),intent(in),optional :: errormark
  integer :: idata,istep,ilayer,tpgroupsize,tpmaxnsteps,ineuron
  real*8 :: tpvec(maxval(mlplayers1(:)%neurons)),temp

  outputs = 0d0; tpgroupsize = size(inputs,2); tpmaxnsteps = size(inputs,3)

  do idata = 1, tpgroupsize
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     ! cycle on all the time steps
     do istep = 1, tpmaxnsteps

        ! initial input data of the neurons in the input layer
        mlplayers1(1)%hiddenstate(:,idata,istep,netidx) = inputs(:,idata,istep)

        ! Eq.3.16
        ! outputs depend on the neurons in previous layer and neurons at previous time step
        do ilayer=2, nlayer-1

           tpvec(1:mlplayers1(ilayer)%neurons) = &
                  matmul(mlplayers1(ilayer)%weights_l2l(:,:),                      &
                  mlplayers1(ilayer-1)%hiddenstate(:,idata,istep,netidx)) +  &
                  mlplayers1(ilayer)%bias(:)

           if ( maxnsteps /= 1 ) then
              if ( istep > 1 ) then
                 tpvec(1:mlplayers1(ilayer)%neurons) = tpvec(1:mlplayers1(ilayer)%neurons) + &
                     matmul(mlplayers1(ilayer)%weights_t2t(:,:),    &
                     mlplayers1(ilayer)%hiddenstate(:,idata,istep-1,netidx))
              end if
           end if

           if ( ifuselayernorm .eqv. .true. ) then
              mlplayers1(ilayer)%layernormin(:,idata,istep,netidx) = tpvec(1:mlplayers1(ilayer)%neurons)
              call mlp1_layer_normalization_forward(                            &
                   mlplayers1(ilayer)%layernormin(:,idata,istep,netidx),  &
                   tpvec(1:mlplayers1(ilayer)%neurons),                      &
                   mlplayers1(ilayer)%layermean(idata,istep,netidx),              &
                   mlplayers1(ilayer)%layersigma(idata,istep,netidx) )
              mlplayers1(ilayer)%layernormout(:,idata,istep,netidx) = tpvec(1:mlplayers1(ilayer)%neurons)
              tpvec(1:mlplayers1(ilayer)%neurons) = mlplayers1(ilayer)%layerweight*tpvec(1:mlplayers1(ilayer)%neurons) + mlplayers1(ilayer)%layerbias
           end if

           ! calculate the activation function value and derivative
           call deeppub_activation_function(tpvec(1:mlplayers1(ilayer)%neurons),mlplayers1(ilayer)%hiddenstate(:,idata,istep,netidx),mlplayers1(ilayer)%grad_active(:,idata,istep,netidx))

           if ( dropout > 0.0d0 ) then
              if ( jobtype == TRAIN ) then
                 do ineuron = 1, mlplayers1(ilayer)%neurons
                    call random_number(temp)
                    if ( temp < dropout ) then
                       mlplayers1(ilayer)%hiddenstate(ineuron,idata,istep,netidx) = 0d0
                       mlplayers1(ilayer)%grad_active(ineuron,idata,istep,netidx) = 0d0
                    else
                       mlplayers1(ilayer)%hiddenstate(ineuron,idata,istep,netidx) = mlplayers1(ilayer)%hiddenstate(ineuron,idata,istep,netidx)/(1d0 - dropout)
                       mlplayers1(ilayer)%grad_active(ineuron,idata,istep,netidx) = mlplayers1(ilayer)%grad_active(ineuron,idata,istep,netidx)/(1d0 - dropout)
                    end if
                 end do
              else
                 do ineuron = 1, mlplayers1(ilayer)%neurons
                    mlplayers1(ilayer)%hiddenstate(ineuron,idata,istep,netidx) = mlplayers1(ilayer)%hiddenstate(ineuron,idata,istep,netidx)*(1d0 - dropout)
                    mlplayers1(ilayer)%grad_active(ineuron,idata,istep,netidx) = mlplayers1(ilayer)%grad_active(ineuron,idata,istep,netidx)*(1d0 - dropout)
                 end do
              end if
           end if

        end do

        tpvec(1:mlplayers1(nlayer)%neurons) = matmul(mlplayers1(nlayer)%weights_l2l(:,:),mlplayers1(nlayer-1)%hiddenstate(:,idata,istep,netidx)) + mlplayers1(nlayer)%bias(:)
        if ( iflastactivation == 0 .and. ifclasses == 0 ) then
           mlplayers1(nlayer)%hiddenstate(:,idata,istep,netidx) = tpvec(1:mlplayers1(nlayer)%neurons)
           outputs(:,idata,istep) = tpvec(1:mlplayers1(nlayer)%neurons)
        else
           if ( ifclasses == 1 ) then
              call deeppub_activation_softmax(tpvec(1:mlplayers1(nlayer)%neurons),mlplayers1(nlayer)%hiddenstate(:,idata,istep,netidx))
              mlplayers1(nlayer)%softmaxstate(:,idata,istep,netidx) = mlplayers1(nlayer)%hiddenstate(:,idata,istep,netidx)
              outputs(:,idata,istep) = mlplayers1(nlayer)%hiddenstate(:,idata,istep,netidx)
           end if
        end if
     end do
  end do
end subroutine

! Back Propagation through time (BPTT) in Recurrent Neural Network
subroutine mlp1_network_backward_bptt(netidx,outputs,iflabel,errormark)
  integer,intent(in) :: netidx
  real*8,intent(in),dimension(:,:,:) :: outputs
  logical,intent(in) :: iflabel
  integer,intent(in),dimension(:),optional :: errormark
  integer :: bptt_step,idata,istep,ilayer,tpgroupsize,tpmaxnsteps
  real*8,dimension(maxval(mlplayers1(:)%neurons)) :: tpdeltalayer
  real*8 :: tpsum

  tpgroupsize = size(outputs,2); tpmaxnsteps = size(outputs,3)
  do idata = 1, tpgroupsize

     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     do istep = tpmaxnsteps, 1, -1

        if ( iflabel .eqv. .false. ) then
           mlplayers1(nlayer)%delta_layer(:) = outputs(:,idata,istep)
        else
           ! delta^L = d(Loss)/d(S^L) = 2.0 * (S^t - y^t)

           if ( allocated(outputweight) ) then
              mlplayers1(nlayer)%delta_layer(:) = 2d0*(mlplayers1(nlayer)%hiddenstate(:,idata,istep,netidx)-outputs(:,idata,istep))*outputweight(:)
           else
              mlplayers1(nlayer)%delta_layer(:) = 2d0*(mlplayers1(nlayer)%hiddenstate(:,idata,istep,netidx)-outputs(:,idata,istep))
           end if
        end if

        if ( ifclasses == 1 ) then
           tpdeltalayer(1:mlplayers1(nlayer)%neurons) = mlplayers1(nlayer)%softmaxstate(:,idata,istep,netidx)*mlplayers1(nlayer)%delta_layer(:)
           tpsum = sum(tpdeltalayer(1:mlplayers1(nlayer)%neurons))
           mlplayers1(nlayer)%delta_layer(:) = (mlplayers1(nlayer)%delta_layer(:)-tpsum)*mlplayers1(nlayer)%softmaxstate(:,idata,istep,netidx)
        end if

        ! d(Loss)/d(U^L) = delta^L * d(f) * S^(L-1)(t)        Eq.3-21
        call deeppub_matmul_outer_product(mlplayers1(nlayer)%grad_weights_l2l(:,:),  &
                mlplayers1(nlayer)%delta_layer(:),                  &
                mlplayers1(nlayer-1)%hiddenstate(:,idata,istep,netidx))

        ! d(Loss)/d(bias)                                     Eq.3-23
        mlplayers1(nlayer)%grad_bias = mlplayers1(nlayer)%grad_bias + mlplayers1(nlayer)%delta_layer(:)

        ! only go back for bptt_trun steps
        do bptt_step = istep, max(1,istep-bptt_trun+1), -1
           do ilayer = nlayer-1,2,-1

              ! Eq.3-24
              ! delta^i = d(Loss)/d(S^i) = U^i+1 * d(f(t))^i+1 * delta^i+1(t) + W^i * d(f(t))^i * delta^i(t+1)
              ! back propagation from next layer
              if ( bptt_step == istep ) then
                 mlplayers1(ilayer)%delta_layer(:) = &
                          matmul(transpose(mlplayers1(ilayer+1)%weights_l2l(:,:)),mlplayers1(ilayer+1)%delta_layer(:))

              ! back propagation from next time step
              else if ( ilayer == nlayer-1 ) then
                 tpdeltalayer(1:mlplayers1(ilayer)%neurons) = &
                       matmul(transpose(mlplayers1(ilayer)%weights_t2t(:,:)),mlplayers1(ilayer)%delta_layer(:))
                 mlplayers1(ilayer)%delta_layer(:) = tpdeltalayer(1:mlplayers1(ilayer)%neurons)

              ! back propagation from next layer and next time step
              else
                 tpdeltalayer(1:mlplayers1(ilayer)%neurons) = &
                       matmul(transpose(mlplayers1(ilayer+1)%weights_l2l(:,:)),mlplayers1(ilayer+1)%delta_layer(:)) + &
                       matmul(transpose(mlplayers1(ilayer)%weights_t2t(:,:)),mlplayers1(ilayer)%delta_layer(:))
                 mlplayers1(ilayer)%delta_layer(:) = tpdeltalayer(1:mlplayers1(ilayer)%neurons)


              end if

              mlplayers1(ilayer)%delta_layer(:) = &
                   mlplayers1(ilayer)%grad_active(:,idata,bptt_step,netidx)*   &
                   mlplayers1(ilayer)%delta_layer(:)

              if ( ifuselayernorm .eqv. .true. ) then
                 mlplayers1(ilayer)%grad_layerweight = mlplayers1(ilayer)%grad_layerweight + dot_product(mlplayers1(ilayer)%delta_layer(:),mlplayers1(ilayer)%layernormout(:,idata,istep,netidx))
                 mlplayers1(ilayer)%grad_layerbias = mlplayers1(ilayer)%grad_layerbias + sum(mlplayers1(ilayer)%delta_layer(:))

                 mlplayers1(ilayer)%delta_layer(:) = mlplayers1(ilayer)%layerweight*mlplayers1(ilayer)%delta_layer(:)
                 call mlp1_layer_normalization_backward( &
                      mlplayers1(ilayer)%layernormin(:,idata,bptt_step,netidx),   &
                      mlplayers1(ilayer)%delta_layer(:),                   &
                      mlplayers1(ilayer)%layermean(idata,bptt_step,netidx),               &   
                      mlplayers1(ilayer)%layersigma(idata,bptt_step,netidx) )
              end if

              ! Eq.3-21
              ! d(Loss)/d(U^L) = delta^L * d(f) * S^(L-1)(t)
              call deeppub_matmul_outer_product(mlplayers1(ilayer)%grad_weights_l2l(:,:),  &
                         mlplayers1(ilayer)%delta_layer(:), &
                         mlplayers1(ilayer-1)%hiddenstate(:,idata,bptt_step,netidx))

              ! Eq.3-23              
              ! d(Loss)/d(bias)
              mlplayers1(ilayer)%grad_bias = mlplayers1(ilayer)%grad_bias + mlplayers1(ilayer)%delta_layer(:)

              ! Eq.3-22
              ! d(Loss)/d(W^L) = delta^L * d(f)* S^L(t-1)
              if ( maxnsteps /= 1 ) then
                 if ( bptt_step > 1 ) then
                    call deeppub_matmul_outer_product(mlplayers1(ilayer)%grad_weights_t2t(:,:),     &
                         mlplayers1(ilayer)%delta_layer(:),  &
                         mlplayers1(ilayer)%hiddenstate(:,idata,bptt_step-1,netidx))

                 end if
              end if
           end do
        end do

     end do
  end do
end subroutine

attributes(global) subroutine mlp1_network_forward_cuda_inputlayer(inet,igroup)
  integer,intent(in),value :: inet,igroup
  integer :: istate,irec

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/ninput_d+1
  if ( irec > icudagroup_d ) return

  istate = istate - (irec-1)*ninput_d
  if ( istate == 1 ) then
     if ( errormark_d(irec) == 1) return
  end if
  
  if ( deepntotdata_d > 0 ) then
     hiddenstate_d((inet-1)*ninputgroup_d + (irec-1)*ninput_d + istate) = &
          batchdata_d((irec-1)*ninput_d + istate)
  else
     hiddenstate_d((irec-1)*ninput_d + istate) = batchdata_d((irec-1)*ninput_d + istate)
  end if

end subroutine

subroutine mlp1_network_forward_cuda(tpoutputs)
  real*8,intent(out),optional :: tpoutputs(:,:,:)
  integer :: ilayer,i,j
  real*8 :: tpvec(hiddenstate_index(nlayer+1)-hiddenstate_index(nlayer))

  do ilayer = 2, nlayer
     call mlp1_network_forward_cuda_layer<<<icudagroup*mlplayers1(ilayer)%neurons,32>>>(1,ilayer)
  end do

  if ( present(tpoutputs) ) then
     i = hiddenstate_index_d(nlayer)+1; j = hiddenstate_index_d(nlayer+1)
     tpvec = hiddenstate_d(i:j)
     tpoutputs(:,:,:) = reshape(tpvec,[noutput,icudagroup,1])
  end if
end subroutine

subroutine mlp1_network_backward_cuda()
  integer :: ilayer

  do ilayer = nlayer-1, 2, -1
     call mlp1_network_backward_cuda_layer<<<icudagroup*mlplayers1(ilayer)%neurons,32>>>(1,ilayer)
  end do
end subroutine

attributes(global) subroutine mlp1_network_forward_cuda_layer(inet,ilayer)
  integer,intent(in),value :: ilayer,inet
  integer :: ileftstate,irightstate,groupsize,groupstep,nleftneuron,nrightneuron,ibias,il2l,irec
  real(kind=SD) :: tpstate,tpvalue,tpgrad

  nleftneuron = mlplayers1_d(ilayer-1); nrightneuron = mlplayers1_d(ilayer); groupsize = icudagroup_d
  tpstate = 0.0_SD

  irightstate = blockidx%x; irec = (irightstate-1)/nrightneuron+1; if ( errormark_d(irec) == 1 ) return
  irightstate = irightstate - (irec-1)*nrightneuron
  ibias = hiddenstate_index_d(ilayer-1) + (inet-1)*groupsize*nleftneuron + (irec-1)*nleftneuron
  il2l = weights_l2l_index_d(ilayer) - nrightneuron + irightstate
  do ileftstate = threadidx%x, nleftneuron, 32
     tpstate = tpstate + hiddenstate_d(ibias+ileftstate)*weights_l2l_d(il2l + ileftstate*nrightneuron)
  end do

  ibias = 1
  do while (ibias<=16)
     tpvalue = __shfl_xor(tpstate,ibias); tpstate = tpstate + tpvalue
     ibias = ibias*2
  end do

  if ( threadidx%x == 1 ) then
     tpstate = tpstate + bias_d(bias_index_d(ilayer) + irightstate)
     ibias = (inet-1)*groupsize*nrightneuron + (irec-1)*nrightneuron + irightstate
     if ( ilayer < nlayer_d ) then
        tpvalue = tpstate
        call mlp1_activation_function_cuda(tpvalue,tpstate,tpgrad)

        if ( dropout_d > 0.0_SD ) then
           if ( deepntotdata_d > 0 ) then
              tpvalue = curand_uniform(curandState_d(grad_active_index_d(ilayer) + ibias))
              if ( tpvalue < dropout_d ) then
                 tpstate = 0.0_SD; tpgrad = 0.0_SD
              else
                 tpstate = tpstate/(1.0_SD - dropout_d)
                 tpgrad = tpgrad/(1.0_SD - dropout_d)
              end if
           else
              tpstate = tpstate*(1.0_SD - dropout_d); tpgrad = tpgrad*(1.0_SD - dropout_d)
           end if
        end if
        grad_active_d(grad_active_index_d(ilayer) + ibias) = tpgrad
     end if
     hiddenstate_d(hiddenstate_index_d(ilayer) + ibias) = tpstate
  end if

end subroutine


attributes(device) subroutine mlp1_activation_function_cuda(x,y,dy)
  real(kind=SD),intent(in) :: x
  real(kind=SD),intent(out) :: y
  real(kind=SD),intent(out),optional :: dy
  select case(activefunctype_d)
    case (SIGM)
       y = 1_SD/(1_SD+exp(-x)); if ( present(dy) ) dy = y*(1_SD-y)
    case (TANH)
       y = 1_SD - 2_SD/(1_SD+exp(2_SD*x)); if ( present(dy) ) dy = 1_SD - y*y
    case (RELU)
       y = 0.5_SD*(x+abs(x)); if ( present(dy) ) dy = abs(x>0.0_SD)
    case (LEAKYRELU) ! Leaky ReLU
       y = 0.01_SD*x
       if (x > 0_SD) y = x
       if ( present(dy) ) then
          dy = 0.01_SD
          if (x > 0_SD) dy = 1_SD
       end if
    case (SELU)
       y = 1.75809933988_SD*(exp(x) - 1_SD)
       if ( x > 0_SD ) y = 1.050700987_SD*x
       if ( present(dy) ) then
          dy = y + 1.75809933988_SD
          if (x > 0_SD ) dy = 1.050700987_SD
       end if
    case (ARCTAN) ! Tan-1(x)
       y = atan(x)
       if ( present(dy) ) dy = 1_SD/(x*x + 1_SD)
    case (SYMSIGM) ! Symmetrical Sigmoid
       y = 1_SD - 2_SD/(1_SD+exp(x))
       if ( present(dy) ) dy = 0.5_SD*(1_SD-y*y)
    case (LOGLOG)
       y = 1_SD - exp(-exp(x))
       if ( present(dy) ) dy = exp(x - exp(x))
    case (GAUSSIAN)
       y = exp(-x*x)
       if ( present(dy) ) dy = -2_SD*x*y
    case (SILU)
       y = 1d0/(1d0+exp(-x))
       if ( present(dy) ) dy = y + x*y*(1d0-y)
       y = x*y
  end select
end subroutine

attributes(global) subroutine mlp1_network_backward_cuda_outputlayer(inet,igroup,ifcalloss)
  integer,intent(in),value :: inet,igroup
  logical,intent(in),value :: ifcalloss
  integer :: istate,index,irec
  real(kind=SD) :: netoutput,tpvalue

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/noutput_d+1; if ( irec > icudagroup_d ) return
  if ( errormark_d(irec) == 1 ) return

  istate = istate - (irec-1)*noutput_d; if ( istate > noutput_d ) return

  index = (inet-1)*noutputgroup_d + (irec-1)*noutput_d + istate
  netoutput = hiddenstate_d(hiddenstate_index_d(nlayer_d) + index)

  if ( ifcalloss .eqv. .false. ) then
     tpvalue = netoutput
  else if ( ifcalloss .eqv. .true. ) then
     tpvalue = netoutput - batchlabel_d((irec-1)*noutput_d + istate)
     if ( lossfunctype_d == RMSE ) then
        irec = atomicadd(totloss_d, tpvalue**2)
     else if ( lossfunctype_d == MAE ) then
        irec = atomicadd(totloss_d,abs(tpvalue))
     end if
     tpvalue = 2_SD*tpvalue*labelcvweight_d(istate)
  end if

  if ( deepntotdata_d > 0 ) then
     irec = atomicadd( grad_bias_d(bias_index_d(nlayer_d) + istate), tpvalue)
     delta_layer_d(delta_layer_index_d(nlayer_d) + index) = tpvalue
  end if
end subroutine

attributes(global) subroutine mlp1_network_backward_cuda_layer(inet,ilayer)
  integer,intent(in),value :: ilayer,inet
  integer :: ileftstate,irightstate,groupsize,groupstep,nleftneuron,nrightneuron
  integer :: istate,ibias,idelta,nlayer,irec
  real(kind=SD) :: tpstate,tpvalue

  groupsize = icudagroup_d; groupstep = groupsize*maxnsteps_d; nlayer = nlayer_d; tpstate = 0.0_SD
  nleftneuron = mlplayers1_d(ilayer); nrightneuron = mlplayers1_d(ilayer+1)

  ileftstate = blockidx%x; irec = (ileftstate-1)/nleftneuron+1; if ( errormark_d(irec) == 1 ) return 
  ileftstate = ileftstate - (irec-1)*nleftneuron

  if ( ileftstate <= nleftneuron ) then

     if ( ilayer+1 == nlayer ) then
        istate = hiddenstate_index_d(ilayer) + (inet-1)*groupsize*nleftneuron + (irec-1)*nleftneuron + ileftstate
        tpvalue = hiddenstate_d(istate)
        idelta = delta_layer_index_d(nlayer) + (inet-1)*groupsize*nrightneuron + (irec-1)*nrightneuron
        ibias = weights_l2l_index_d(nlayer) + (ileftstate-1)*nrightneuron
        do irightstate = threadidx%x, nrightneuron, 32
           istate = atomicadd( grad_weights_l2l_d(ibias + irightstate), tpvalue*delta_layer_d(idelta+irightstate) )
        end do
     end if

     idelta = delta_layer_index_d(ilayer+1) + (inet-1)*groupsize*nrightneuron + (irec-1)*nrightneuron
     ibias = weights_l2l_index_d(ilayer+1) + (ileftstate-1)*nrightneuron
     do irightstate = threadidx%x, nrightneuron, 32
        tpstate = tpstate + weights_l2l_d(ibias + irightstate)*delta_layer_d(idelta+irightstate)
     end do

  end if

  ibias = 1
  do while (ibias<=16)
     tpvalue = __shfl_xor(tpstate,ibias); tpstate = tpstate + tpvalue
     ibias = ibias*2
  end do

  if ( threadidx%x == 1 ) then
     idelta = (inet-1)*groupsize*nleftneuron + (irec-1)*nleftneuron + ileftstate
     istate = grad_active_index_d(ilayer) + idelta
     idelta = delta_layer_index_d(ilayer) + idelta

     tpstate = grad_active_d(istate)*tpstate
     delta_layer_d(idelta) = tpstate
     tpvalue = atomicadd(grad_bias_d(bias_index_d(ilayer) + ileftstate),tpstate)
  end if

  tpstate = __shfl(tpstate,1)

  nrightneuron = nleftneuron; nleftneuron = mlplayers1_d(ilayer-1)
  irightstate = ileftstate

  if ( irightstate <= nrightneuron ) then
     istate = hiddenstate_index_d(ilayer-1) + (inet-1)*groupsize*nleftneuron + (irec-1)*nleftneuron
     ibias = weights_l2l_index_d(ilayer) - nrightneuron + irightstate
     do ileftstate = threadidx%x, nleftneuron, 32
        tpvalue = atomicadd( grad_weights_l2l_d(ibias + ileftstate*nrightneuron), tpstate*hiddenstate_d(istate+ileftstate) )
     end do
  end if

end subroutine

attributes(global) subroutine mlp1_curandinit()
  integer :: iactive,nactive

  nactive = grad_active_index_d(nlayer_d+1)
  iactive = (blockidx%x-1)*blockdim%x+threadidx%x; if ( iactive > nactive ) return
  call curand_init(int(iactive, 8), int(iactive, 8), 0_8, curandState_d(iactive))
end subroutine

subroutine mlp1_network_download()
  integer :: ilayer,index1,index2,tpnum,num
  real(kind=SD),dimension(:),allocatable :: tparray

  num = 0
  do ilayer = 2, nlayer
     index1 = weights_l2l_index_d(ilayer)+1; index2 = weights_l2l_index_d(ilayer+1)
     tpnum = index2 - index1 + 1; if ( tpnum > num ) num = tpnum
     if ( maxnsteps == 1 ) cycle
     index1 = weights_t2t_index_d(ilayer)+1; index2 = weights_t2t_index_d(ilayer+1)
     tpnum = index2 - index1 + 1; if ( tpnum > num ) num = tpnum
  end do
  allocate(tparray(num)); tparray = 0d0

  do ilayer = 2, nlayer
     index1 = weights_l2l_index_d(ilayer)+1; index2 = weights_l2l_index_d(ilayer+1)
     tparray(1:index2-index1+1) = weights_l2l_d(index1:index2)
     mlplayers1(ilayer)%weights_l2l(:,:) = reshape(tparray(1:index2-index1+1),[mlplayers1(ilayer)%neurons,mlplayers1(ilayer-1)%neurons])
     index1 = bias_index_d(ilayer)+1; index2 = bias_index_d(ilayer+1)
     tparray(1:index2-index1+1) = bias_d(index1:index2)
     mlplayers1(ilayer)%bias(:) = tparray(1:index2-index1+1)
  end do

  if ( maxnsteps > 1 ) then
     do ilayer=nlayer,2,-1
        index1 = weights_t2t_index_d(ilayer)+1; index2 = weights_t2t_index_d(ilayer+1)
        tparray(1:index2-index1+1) = weights_t2t_d(index1:index2)
        mlplayers1(ilayer)%weights_t2t(:,:) = reshape(tparray(1:index2-index1+1),[mlplayers1(ilayer)%neurons,mlplayers1(ilayer)%neurons])
     end do
  end if
  deallocate(tparray)
end subroutine

subroutine mlp1_network_upload()
  integer :: ilayer,i,j

  do ilayer=1,nlayer
     if ( ilayer == 1 ) cycle
     i = weights_l2l_index(ilayer)+1; j = weights_l2l_index(ilayer+1)
     weights_l2l_d(i:j) = pack(mlplayers1(ilayer)%weights_l2l,.true.)
     i = bias_index(ilayer)+1; j = bias_index(ilayer+1)
     bias_d(i:j) = mlplayers1(ilayer)%bias

     if ( maxnsteps > 1 ) then
        i = weights_t2t_index_d(ilayer)+1; j = weights_t2t_index_d(ilayer+1)
        weights_t2t_d(i:j) = pack(mlplayers1(ilayer)%weights_t2t,.true.)
     end if
  end do
end subroutine

subroutine mlp1_network_update()
  if ( icudagroup == 0 ) then
     call mlp1_network_update_cpu()
  else
     if ( deepprocnum > 1 ) then
        call deeppub_ncclAllReduce_vector(grad_weights_l2l_d,weights_l2l_index(nlayer+1))
        call deeppub_ncclAllReduce_vector(grad_bias_d,bias_index(nlayer+1))
     end if
     call mlp1_network_update_cuda<<<(weights_l2l_index(nlayer+1)-1)/32+1,32>>>()
  end if
end subroutine

subroutine mlp1_network_update_cpu()
  integer :: ilayer,i,j
  real*8 :: tpg,tpgsq,tpstepsize

  do ilayer = 2, nlayer

     if ( ioptmethod == 1 ) then

        if ( (ifuselayernorm .eqv. .true.) .and. (ilayer < nlayer) ) then
           tpg = mlplayers1(ilayer)%layerweight
           if ( l1normfactor > 0.0d0 ) then
              tpg = tpg + l1normfactor*dsign(1.0d0, mlplayers1(ilayer)%layerweight)
           else if ( l2normfactor > 0.0d0 ) then
              tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%layerweight
           end if
           mlplayers1(ilayer)%layerweight = tpg
           tpg = mlplayers1(ilayer)%layerbias
           if ( l1normfactor > 0.0d0 ) then
              tpg = tpg + l1normfactor*dsign(1.0d0, mlplayers1(ilayer)%layerbias)
           else if ( l2normfactor > 0.0d0 ) then
              tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%layerbias
           end if
           mlplayers1(ilayer)%layerbias = tpg
        end if

        do i = 1, mlplayers1(ilayer)%neurons
           do j = 1, mlplayers1(ilayer-1)%neurons
              tpg = mlplayers1(ilayer)%grad_weights_l2l(i,j)
              if ( l1normfactor > 0.0d0 ) then
                 tpg = tpg + l1normfactor*dsign(1.0d0, mlplayers1(ilayer)%weights_l2l(i,j))
              else if ( l2normfactor > 0.0d0 ) then
                 tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%weights_l2l(i,j)
              end if
              mlplayers1(ilayer)%grad_weights_l2l(i,j) = tpg
           end do
        end do           

        do i = 1, mlplayers1(ilayer)%neurons
           tpg = mlplayers1(ilayer)%grad_bias(i)
           if ( l1normfactor > 0.0d0 ) then
              tpg = tpg + l1normfactor*dsign(1.0d0, mlplayers1(ilayer)%bias(i))
           else if ( l2normfactor > 0.0d0 ) then
              tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%bias(i)
           end if
           mlplayers1(ilayer)%grad_bias(i) = tpg
        end do

        mlplayers1(ilayer)%weights_l2l = mlplayers1(ilayer)%weights_l2l - learnrate * mlplayers1(ilayer)%grad_weights_l2l
        mlplayers1(ilayer)%bias = mlplayers1(ilayer)%bias - learnrate*mlplayers1(ilayer)%grad_bias

        if ( maxnsteps /= 1 ) then
           mlplayers1(ilayer)%weights_t2t = mlplayers1(ilayer)%weights_t2t - learnrate * mlplayers1(ilayer)%grad_weights_t2t
        end if

     else if ( ioptmethod == 2 ) then

       do i = 1, mlplayers1(ilayer)%neurons
          do j = 1, mlplayers1(ilayer-1)%neurons

             tpg = mlplayers1(ilayer)%grad_weights_l2l(i,j)
             if ( l1normfactor > 0.0d0 ) then
                tpg = tpg + l1normfactor*dsign(1d0,mlplayers1(ilayer)%weights_l2l(i,j))
             else if ( l2normfactor > 0.0d0 ) then
                tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%weights_l2l(i,j)
             end if

             tpgsq = 0.999d0*mlplayers1(ilayer)%gradgsq_weights_l2l(i,j) + (1.0d0 - 0.999d0)*tpg*tpg
             tpg = 0.9d0*mlplayers1(ilayer)%gradg_weights_l2l(i,j) + (1.0d0 - 0.9d0)*tpg

             tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
             mlplayers1(ilayer)%weights_l2l(i,j) = mlplayers1(ilayer)%weights_l2l(i,j) - learnrate*tpstepsize

             mlplayers1(ilayer)%gradg_weights_l2l(i,j) = tpg
             mlplayers1(ilayer)%gradgsq_weights_l2l(i,j) = tpgsq

          end do
       end do

       do i = 1, mlplayers1(ilayer)%neurons
          tpg = mlplayers1(ilayer)%grad_bias(i)

          if ( l1normfactor > 0.0d0 ) then
             tpg = tpg + l1normfactor*dsign(1d0, mlplayers1(ilayer)%bias(i))
          else if ( l2normfactor > 0.0d0 ) then
             tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%bias(i)
          end if

          tpgsq = 0.999d0*mlplayers1(ilayer)%gradgsq_bias(i) + (1.0d0 - 0.999d0)*tpg*tpg
          tpg = 0.9d0*mlplayers1(ilayer)%gradg_bias(i) + (1.0d0 - 0.9d0)*tpg

          tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
          mlplayers1(ilayer)%bias(i) = mlplayers1(ilayer)%bias(i) - learnrate*tpstepsize
          mlplayers1(ilayer)%gradg_bias(i) = tpg
          mlplayers1(ilayer)%gradgsq_bias(i) = tpgsq
       end do

       if ( (ifuselayernorm .eqv. .true.) .and. (nlayer < nlayer) ) then
          tpg = mlplayers1(ilayer)%layerweight
          if ( l1normfactor > 0.0d0 ) then
             tpg = tpg + l1normfactor*dsign(1d0, mlplayers1(ilayer)%layerweight)
          else if ( l2normfactor > 0.0d0 ) then
             tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%layerweight
          end if

          tpgsq = 0.999d0*mlplayers1(ilayer)%gradgsq_layerweight + (1.0d0 - 0.999d0)*tpg*tpg
          tpg = 0.9d0*mlplayers1(ilayer)%gradg_layerweight + (1.0d0 - 0.9d0)*tpg

          tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
          mlplayers1(ilayer)%layerweight = mlplayers1(ilayer)%layerweight - learnrate*tpstepsize
          mlplayers1(ilayer)%gradg_layerweight = tpg
          mlplayers1(ilayer)%gradgsq_layerweight = tpgsq

          tpg = mlplayers1(ilayer)%layerbias
          if ( l1normfactor > 0.0d0 ) then
             tpg = tpg + l1normfactor*dsign(1d0, mlplayers1(ilayer)%layerbias)
          else if ( l2normfactor > 0.0d0 ) then
             tpg = tpg + l2normfactor*2d0*mlplayers1(ilayer)%layerbias
          end if

          tpgsq = 0.999d0*mlplayers1(ilayer)%gradgsq_layerbias + (1.0d0 - 0.999d0)*tpg*tpg
          tpg = 0.9d0*mlplayers1(ilayer)%gradg_layerbias + (1.0d0 - 0.9d0)*tpg

          tpstepsize = (tpg/(1.0d0-0.9d0))/(sqrt(tpgsq/(1.0d0-0.999d0)) + 0.00000001d0)
          mlplayers1(ilayer)%layerbias = mlplayers1(ilayer)%layerbias - learnrate*tpstepsize
          mlplayers1(ilayer)%gradg_layerbias = tpg
          mlplayers1(ilayer)%gradgsq_layerbias = tpgsq
       end if

     end if

     mlplayers1(ilayer)%grad_weights_l2l(:,:) = 0.d0
     mlplayers1(ilayer)%grad_bias(:) = 0.d0
     if ( maxnsteps /= 1 ) then
        mlplayers1(ilayer)%grad_weights_t2t(:,:) = 0d0
     end if
     if ( (ifuselayernorm .eqv. .true.) .and. (ilayer < nlayer) ) then
        mlplayers1(ilayer)%grad_layerweight = 0d0
        mlplayers1(ilayer)%grad_layerbias = 0d0
     end if
  end do

end subroutine

attributes(global) subroutine mlp1_network_update_cuda()
  integer :: index
  real(kind=SD) :: tpg,tpgsq,tpstepsize

  index = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( index > weights_l2l_index_d(nlayer_d+1) ) return

  tpg = grad_weights_l2l_d(index); tpgsq = weights_l2l_d(index)
  if ( l1normfactor_d > 0.0_SD ) then
     tpg = tpg + l1normfactor_d*sign(1.0, real(tpgsq))
  else if ( l2normfactor_d > 0.0_SD ) then
     tpg = tpg + l2normfactor_d*2_SD*tpgsq
  end if
  if ( ioptmethod_d == 1 ) then
     weights_l2l_d(index) = tpgsq - learnrate_d*tpg
  else if ( ioptmethod_d == 2 ) then
     tpgsq = 0.999_SD*gradgsq_weights_l2l_d(index) + (1.0_SD - 0.999_SD)*tpg*tpg
     tpg = 0.9_SD*gradg_weights_l2l_d(index) + (1.0_SD - 0.9_SD)*tpg
     tpstepsize = (tpg/(1.0_SD-0.9_SD))/(sqrt(tpgsq/(1.0_SD-0.999_SD)) + 0.00000001_SD)
     weights_l2l_d(index) = weights_l2l_d(index) - learnrate_d*tpstepsize
     gradg_weights_l2l_d(index) = tpg; gradgsq_weights_l2l_d(index) = tpgsq
  end if
  grad_weights_l2l_d(index) = 0.0_SD

  if ( index > bias_index_d(nlayer_d+1) ) return

  tpg = grad_bias_d(index); tpgsq = bias_d(index)
  if ( l1normfactor_d > 0.0_SD ) then
     tpg = tpg + l1normfactor_d*sign(1.0, real(tpgsq))
  else if ( l2normfactor_d > 0.0_SD ) then
     tpg = tpg + l2normfactor_d*2.0_SD*tpgsq
  end if
  if ( ioptmethod_d == 1 ) then
     bias_d(index) = tpgsq - learnrate_d*tpg
  else if ( ioptmethod_d == 2 ) then
     tpgsq = 0.999_SD*gradgsq_bias_d(index) + (1.0_SD - 0.999_SD)*tpg*tpg
     tpg = 0.9_SD*gradg_bias_d(index) + (1.0_SD - 0.9_SD)*tpg
     tpstepsize = (tpg/(1.0_SD-0.9_SD))/(sqrt(tpgsq/(1.0_SD-0.999_SD)) + 0.00000001_SD)
     bias_d(index) = bias_d(index) - learnrate_d*tpstepsize
     gradg_bias_d(index) = tpg; gradgsq_bias_d(index) = tpgsq
  end if
  grad_bias_d(index) = 0.0_SD
end subroutine

subroutine mlp1_network_save(tpnetworkfile)
  character(len=*),intent(in),optional :: tpnetworkfile
  integer :: i,j,iofile,ilayer

  if ( icudagroup > 0 ) call mlp1_network_download()

  if ( present(tpnetworkfile) ) then
     open(newunit=iofile,file=tpnetworkfile,action="write",access="append")
  else
     open(newunit=iofile,file=networkfile,action="write",access="append")
  end if
  do ilayer=nlayer,2,-1
     write(iofile,'(a,i8)'),'weights_l2l:',ilayer
     do i = 1,mlplayers1(ilayer)%neurons
        write(iofile,'(*(f15.6))'),mlplayers1(ilayer)%weights_l2l(i,:)
     end do
     write(iofile,'(a,i8)'),'bias:',ilayer
     write(iofile,'(*(f15.6))'),mlplayers1(ilayer)%bias
  end do

  if ( maxnsteps > 1 ) then
     do ilayer=nlayer,2,-1
        write(iofile,'(a,i8)'),'weights_t2t:',ilayer
        do i = 1,mlplayers1(ilayer)%neurons
           write(iofile,'(*(f15.6))'),mlplayers1(ilayer)%weights_t2t(i,:)
        end do
     end do
  end if
  close(iofile)
end subroutine

subroutine mlp1_network_reload()
  character*15 :: chara
  integer :: i,j,iofile,ilayer,ierr
  logical :: iffound

  iffound = .false.
  open(newunit=iofile,file=networkfile,action="read")
  do 
     read(iofile,"(a)",iostat=ierr) chara
     if ( ierr /= 0 ) exit
     if ( trim(chara) == "weights_l2l:" ) then
        iffound = .true.; exit
     end if 
  end do
  if ( iffound .eqv. .false. ) stop "can not find mlp parameters in network file: "//trim(networkfile)

  backspace(iofile)
  do ilayer=nlayer,2,-1
     read(iofile,'(a,i8)'),chara,j
     do i = 1,mlplayers1(ilayer)%neurons
        read(iofile,'(*(f15.6))'),mlplayers1(ilayer)%weights_l2l(i,:)
     end do
     read(iofile,'(a,i8)'),chara,j
     read(iofile,'(*(f15.6))'),mlplayers1(ilayer)%bias
  end do
  if ( maxnsteps > 1 ) then
     do ilayer=nlayer,2,-1
        read(iofile,'(a,i8)'),chara,j
        do i = 1,mlplayers1(ilayer)%neurons
           read(iofile,'(*(f15.6))'),mlplayers1(ilayer)%weights_t2t(i,:)
        end do
     end do
  end if
  close(iofile)

  if ( icudagroup > 0 ) call mlp1_network_upload()
end subroutine

!======================================= mlp flooding ==============================

subroutine mlp1_flooding_backward(bout, bin, errormark)
  real*8,dimension(:,:,:) :: bout,bin
  integer,dimension(:),optional :: errormark
  integer :: ilayer,idata

  do idata = 1, size(bout,2)
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     mlplayers1(nlayer)%hiddenstate(:,idata,1,1) = bout(:,idata,1)
     do ilayer = nlayer-1,1,-1
        mlplayers1(ilayer)%hiddenstate(:,idata,1,1) = matmul(transpose(mlplayers1(ilayer+1)%weights_l2l(:,:)),mlplayers1(ilayer+1)%hiddenstate(:,idata,1,1))
        if ( ilayer >= 2 ) then
            mlplayers1(ilayer)%hiddenstate(:,idata,1,1) = mlplayers1(ilayer)%hiddenstate(:,idata,1,1)*mlplayers1(ilayer)%grad_active(:,idata,1,1)
        end if
     end do
     bin(:,idata,1) = mlplayers1(1)%hiddenstate(:,idata,1,1)
  end do

end subroutine

subroutine mlp1_flooding_forward(bin,errormark)
  real*8,dimension(:,:,:) :: bin
  integer,dimension(:),optional :: errormark
  integer :: ilayer,idata,istate,tpnum
  real*8 :: tpsum,tpsigma,tpmean,tpnormin

  do idata = 1, size(bin,2)
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     mlplayers1(1)%delta_layer(:) = 0.0d0
     mlplayers1(1)%delta_layer(1:ninput) = 2.0d0*gradcvweight*(mlplayers1(1)%hiddenstate(1:ninput,idata,1,1)-bin(1:ninput,idata,1))
     do ilayer = 2, nlayer
        call deeppub_matmul_outer_product(mlplayers1(ilayer)%grad_weights_l2l(:,:),  &
             mlplayers1(ilayer)%hiddenstate(:,idata,1,1),mlplayers1(ilayer-1)%delta_layer(:))
        mlplayers1(ilayer)%delta_layer(:) = &
             matmul(mlplayers1(ilayer)%weights_l2l(:,:),mlplayers1(ilayer-1)%delta_layer(:))
        if ( ilayer == nlayer ) exit
        mlplayers1(ilayer)%delta_layer(:) = mlplayers1(ilayer)%delta_layer(:)*mlplayers1(ilayer)%grad_active(:,idata,1,1)
     end do
  end do
end subroutine

attributes(global) subroutine mlp1_flooding_backward_cuda_outputlayer()
  integer :: istate,irec

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/noutput_d+1; if ( irec > icudagroup_d ) return
  if ( errormark_d(irec) == 1 ) return
  delta_layer_d(delta_layer_index_d(nlayer_d) + istate) = 1.0_SD
end subroutine

subroutine mlp1_flooding_backward_cuda(tpgrads)
  real*8,intent(out),optional :: tpgrads(:,:,:)
  integer :: ilayer,i,j
  real*8 :: tpvec(hiddenstate_index(2)-hiddenstate_index(1))
real*8 :: tparray(6)

  do ilayer = nlayer-1, 1, -1
     call mlp1_flooding_backward_cuda_layer<<<icudagroup*mlplayers1(ilayer)%neurons,32>>>(ilayer)
  end do

  if ( present(tpgrads) ) then
     i = hiddenstate_index(1)+1; j = hiddenstate_index(2)
     tpvec = delta_layer_d(i:j)
     tpgrads(:,:,:) = reshape(tpvec,[ninput,icudagroup,1])
  end if
end subroutine

attributes(global) subroutine mlp1_flooding_backward_cuda_layer(ilayer)
  integer,intent(in),value :: ilayer
  integer :: ileftstate,irightstate,nleftneuron,nrightneuron
  integer :: istate,ibias,idelta,nlayer,irec
  real(kind=SD) :: tpstate,tpvalue

  nlayer = nlayer_d; tpstate = 0.0_SD
  nleftneuron = mlplayers1_d(ilayer); nrightneuron = mlplayers1_d(ilayer+1)

  ileftstate = blockidx%x; irec = (ileftstate-1)/nleftneuron+1; if ( errormark_d(irec) == 1 ) return
  ileftstate = ileftstate - (irec-1)*nleftneuron

  if ( ileftstate <= nleftneuron ) then
     idelta = delta_layer_index_d(ilayer+1) + (irec-1)*nrightneuron
     ibias = weights_l2l_index_d(ilayer+1) + (ileftstate-1)*nrightneuron
     do irightstate = threadidx%x, nrightneuron, 32
        tpstate = tpstate + weights_l2l_d(ibias + irightstate)*delta_layer_d(idelta+irightstate)
     end do
  end if

  ibias = 1
  do while (ibias<=16)
     tpvalue = __shfl_xor(tpstate,ibias); tpstate = tpstate + tpvalue
     ibias = ibias*2
  end do

  if ( threadidx%x == 1 ) then
     idelta = (irec-1)*nleftneuron + ileftstate
     if ( ilayer > 1 ) then
        istate = grad_active_index_d(ilayer) + idelta
        tpstate = tpstate*grad_active_d(istate)
     end if
     delta_layer_d(delta_layer_index_d(ilayer) + idelta) = tpstate
  end if
end subroutine

attributes(global) subroutine mlp1_flooding_forward_cuda_inputlayer(ibatch,igroup)
  integer,intent(in),value :: ibatch,igroup
  integer :: istate,index,irec
  real(kind=SD) :: netinput,tpvalue

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/ninput_d+1; if ( irec > icudagroup_d ) return
  if ( errormark_d(irec) == 1 ) return

  index = istate; istate = istate - (irec-1)*ninput_d; if ( istate > ninput_d ) return
  netinput = delta_layer_d(delta_layer_index_d(1) + index)

  tpvalue = 0.0_SD
  if ( istate <= ngradcv_d ) then
     tpvalue = netinput - batchgraddata_d((irec-1)*ninput_d + istate)
  end if

  if ( deepntotdata_d > 0 ) then
     delta_layer_d(delta_layer_index_d(1) + index) = 2_SD*tpvalue*gradcvweight_d
  end if

  if ( istate > ngradcv_d ) return

  if ( lossfunctype_d == RMSE ) then
     irec = atomicadd(gradtotloss_d,tpvalue*tpvalue)
  else if ( lossfunctype_d == MAE ) then
     irec = atomicadd(gradtotloss_d,abs(tpvalue))
  end if
end subroutine

subroutine mlp1_flooding_forward_cuda()
  integer :: ilayer

  do ilayer = 2, nlayer
     call mlp1_flooding_forward_cuda_layer<<<icudagroup*mlplayers1(ilayer)%neurons,32>>>(ilayer)
  end do
end subroutine

attributes(global) subroutine mlp1_flooding_forward_cuda_layer(ilayer)
  integer,intent(in),value :: ilayer
  integer :: istate,ileftstate,irightstate,nleftneuron,nrightneuron,idelta,il2l,irec
  real(kind=SD) :: tpstate,tpvalue,tpgrad

  nleftneuron = mlplayers1_d(ilayer-1); nrightneuron = mlplayers1_d(ilayer); tpstate = 0.0_SD

  irightstate = blockidx%x; irec = (irightstate-1)/nrightneuron+1; if ( errormark_d(irec) == 1 ) return
  irightstate = irightstate - (irec-1)*nrightneuron
  idelta = delta_layer_index_d(ilayer-1) + (irec-1)*nleftneuron
  il2l = weights_l2l_index_d(ilayer) - nrightneuron + irightstate
  tpgrad = delta_layer_d(delta_layer_index_d(ilayer) + (irec-1)*nrightneuron + irightstate)
  do ileftstate = threadidx%x, nleftneuron, 32
     tpvalue = delta_layer_d(idelta+ileftstate)
     istate = il2l + ileftstate*nrightneuron
     tpstate = tpstate + tpvalue*weights_l2l_d(istate)
     tpvalue = atomicadd( grad_weights_l2l_d(istate), tpvalue*tpgrad )
  end do

  istate = 1
  do while (istate<=16)
     tpvalue = __shfl_xor(tpstate,istate); tpstate = tpstate + tpvalue
     istate = istate*2
  end do

  if ( threadidx%x == 1 ) then
     istate = (irec-1)*nrightneuron + irightstate
     if ( ilayer < nlayer_d ) then
        tpstate = tpstate*grad_active_d(grad_active_index_d(ilayer) + istate)
     end if
     delta_layer_d(delta_layer_index_d(ilayer) + istate) = tpstate
  end if

end subroutine

end module
