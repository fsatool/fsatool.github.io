module dnn
  use deeppub
  use deep
  use mlp
  implicit none

contains

subroutine dnn_go(parmfile)
  character(len=*),intent(in) :: parmfile
  integer :: ilen,iofile,ierr
  character*100 :: task
  namelist / deep / task

  open(newunit=iofile,file=parmfile,action="read")
  read(iofile, nml=deep, iostat=ierr); if ( ierr < 0 ) stop "Cannot find the deep namelist!"
  close(iofile)

  ilen = len(trim(task))
  if ( task(ilen-4:ilen) == "train" ) then
     jobtype = TRAIN
  else if ( task(ilen-6:ilen) == "predict" ) then
     jobtype = PREDICT
  else if ( task(ilen-4:ilen) == "check" ) then
     jobtype = CHECK
  end if

  call deep_initialize(parmfile)
  call mlp_initialize(ninput,noutput,nlayer,layers,totparms,tpoutputweight=labelcvweight)
  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms

  if ( nlabelcv /= noutput ) stop "DNN error: nlabelcv /= noutput!"

  select case(jobtype)
  case (TRAIN)
     call dnn_train()
  case (PREDICT)
     call dnn_predict()
  case (CHECK)
     call dnn_check_grad()
     call dnn_check_flood()
     call mlp_layer_normalization_check()
  end select
end subroutine

!========================= DNN Network Training and Prediction ====================================
subroutine dnn_classes_ifcorrect(ncorrectclass,outp,labeloutp)
  integer,intent(inout) :: ncorrectclass
  real*8,dimension(:),intent(in) :: outp,labeloutp
  integer :: ipos(1)
  logical :: ifcorrect

  ipos = maxloc(outp)
  ifcorrect = dabs(labeloutp(ipos(1))-1.d0) < 1d-3
  if ( ifcorrect ) then
     ncorrectclass = ncorrectclass + 1
  end if
end subroutine

subroutine dnn_train()
  use mpi; use cudablas
  implicit none

  integer,dimension(:),pointer :: shuffleidx
  integer :: i,j,k,ibatch,index,iepoch,idata,realidata,istart,ipos,ilayer,igroup
  integer :: ierr,istream,errormark(batchsize)
  real*8 :: loss,totloss,checktotloss,gradtotloss,checkgradtotloss
  real*8,dimension(:,:,:),allocatable :: tpinputs,tpoutputs,tptrueoutputs,tptruegrads
  real*8 :: initime,endtime,time1,time2
  real :: rand
  integer :: system,weighti,weightj,weightk,statei,statej,statek
  real(kind=SD),device,allocatable :: c_d(:),tparray1d_d(:)
  integer,dimension(nlayer+1) :: tpweights_l2l_index,tphiddenstate_index,tpdelta_layer_index 
  real*8 :: mintotloss,pretotloss,totlossflood,batchloss,addpotcoef,maxaccu,curaccu,learnratecoolminloss
  integer :: ncorrectclass, learnratecoolminstep,minlossepoch,learnratewarmpeakepoch
  logical :: iflearnratewarm,ifstartrecordnetwork
  character*150 :: tpstring,tpfilename,lastnetworkfilename
integer :: iofile,iofile2

  if ( deepprocnum > 0 ) then
     call deeppub_MPISharedMemoryAllocate(i, dimint1d=(/deepntotdata/), shareint1d=shuffleidx)
  else
     allocate(shuffleidx(deepntotdata))
  end if

  if ( deepprocid == 0 ) then
      call deeppub_time_from_1970(initime)
      print "(/,a)","DNN Training Data"
      shuffleidx = [(idata,idata=1,deepntotdata)]
  end if

  if ( icudagroup == 0 ) then
     allocate(tpinputs(ninput,batchsize,1),tpoutputs(noutput,batchsize,1),tptrueoutputs(noutput,batchsize,1))
     allocate(tptruegrads(ngradcv,batchsize,1))
  end if

  lastnetworkfilename=""; mintotloss = huge(1.0); pretotloss = huge(1.0); minlossepoch = 0
  if ( learnratewarmsteps > 0 ) then
     iflearnratewarm = .true.; learnrate = minlearnrate; learnratecoolminstep = 0
     if ( icudagroup > 0 ) learnrate_d = learnrate
  end if

  do iepoch = 1,nepoch

     if ( deepprocid == 0 ) then
        do idata = deepntotdata, 2, -1
           call random_number(rand); index = int(rand * idata) + 1
           realidata = shuffleidx(index); shuffleidx(index) = shuffleidx(idata); shuffleidx(idata) = realidata
        end do
     end if
     call mpi_barrier(mpi_comm_world,ierr)
   
     if ( icudagroup == 0 ) then
        totloss = 0d0; gradtotloss = 0d0
     else
        totloss_d = 0.0_SD; shuffleidx_d = shuffleidx
        if ( ngradcv > 0 ) gradtotloss_d = 0.0_SD
     end if

     do ibatch = 1, batchnum

        if ( icudagroup == 0 ) then

           call deep_get_batchdata(shuffleidx,ibatch,tpinputs(:,:,1),tptrueoutputs(:,:,1),tptruegrads=tptruegrads(:,:,1),tperrormark=errormark)

           call mlp_network_forward(1,tpinputs,tpoutputs,errormark=errormark)

           call deeppub_loss_function(tptrueoutputs(1:noutput,:,1),tpoutputs(1:noutput,:,1),totloss,tperrormark=errormark)

           call mlp_network_backward_bptt(1,tptrueoutputs,.true.,errormark=errormark)

           if ( ngradcv > 0 ) then
               tpoutputs(:,:,1)=1d0
               call dnn_flooding_backward(tpoutputs, tpinputs, errormark=errormark)

               call deeppub_loss_function_grad(tptruegrads(:,:,1),tpinputs(:,:,1),gradtotloss,tperrormark=errormark)

               call dnn_flooding_forward(tptruegrads,errormark=errormark)
           end if

        else

           do igroup = 1, (batchsize-1)/(icudagroup*deepprocnum)+1

              call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,ibatch,igroup,ninput)
              call mlp_network_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(1,igroup)

              call mlp_network_forward_cuda()

              call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,ibatch,igroup,noutput)

              call mlp_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(1,igroup,.true.)

              call mlp_network_backward_cuda()

              if ( ngradcv > 0 ) then

                 call dnn_flooding_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>()
                 do ilayer = nlayer-1, 1, -1

                    call dnn_flooding_backward_cuda<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(ilayer)

                 end do

                 call dnn_flooding_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(ibatch,igroup)

                 do ilayer = 2, nlayer

                    call dnn_flooding_forward_cuda<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(ilayer)

                 end do

              end if

           end do

        end if

        call mlp_network_update()

     end do

     if ( icudagroup > 0 ) then
        call deeppub_ncclAllReduce_scalar(totloss_d); totloss = totloss_d
        if ( ngradcv > 0 ) then
           call deeppub_ncclAllReduce_scalar(gradtotloss_d); gradtotloss = gradtotloss_d
        end if
     end if

     index = min(batchsize*batchnum, deepntotdata)
     call deeppub_loss_function_end(index*nlabelcv, totloss)
     if ( ngradcv > 0 ) call deeppub_loss_function_end(index*ngradcv, gradtotloss)

     if ( checkdeepntotdata > 0 ) then

        if ( icudagroup == 0 ) then
           checktotloss = 0.0d0; checkgradtotloss = 0.0d0
           if ( ifclasses == 1 ) ncorrectclass = 0
        else 
           deepntotdata_d = 0; totloss_d = 0.0_SD
           if ( ngradcv > 0 ) gradtotloss_d = 0.0_SD
        end if

        do ibatch = 1, (checkdeepntotdata-1)/batchsize+1
   
           if ( icudagroup == 0 ) then

              call deep_get_batchdata_check(ibatch,tpinputs(:,:,1),tptrueoutputs(:,:,1),tptruegrads=tptruegrads(:,:,1),tperrormark=errormark)
   
              call mlp_network_forward(1,tpinputs,tpoutputs,errormark=errormark)
   
              call deeppub_loss_function(tptrueoutputs(:,:,1),tpoutputs(:,:,1),checktotloss,tperrormark=errormark)

              if ( ifclasses == 1 ) then
                 do idata = 1, batchsize
                    if ( errormark(idata) == 1 ) cycle
                    call dnn_classes_ifcorrect(ncorrectclass,tpoutputs(1:noutput,idata,1),tptrueoutputs(1:nlabelcv,idata,1))
                 end do
              end if
  
              if ( ngradcv > 0 ) then
                  tpoutputs(:,:,1)=1d0
                  call dnn_flooding_backward(tpoutputs, tpinputs, errormark=errormark)
                  call deeppub_loss_function_grad(tptruegrads(:,:,1),tpinputs(:,:,1),checkgradtotloss,tperrormark=errormark)
              end if

           else

              do igroup = 1, (batchsize-1)/(icudagroup*deepprocnum)+1
                 call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,ibatch,igroup,ninput)

                 call mlp_network_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(1,igroup)

                 call mlp_network_forward_cuda()

                 call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,ibatch,igroup,noutput)
                 call mlp_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(1,igroup,.true.)

                 if ( ngradcv > 0 ) then
                    call dnn_flooding_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>()
                    do ilayer = nlayer-1, 1, -1
                       call dnn_flooding_backward_cuda<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(ilayer)
                    end do
                    call dnn_flooding_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(ibatch,igroup)
                 end if

              end do

           end if
   
        end do

        if ( icudagroup > 0 ) then
           call deeppub_ncclAllReduce_scalar(totloss_d); checktotloss = totloss_d
           if ( ngradcv > 0 ) then
              call deeppub_ncclAllReduce_scalar(gradtotloss_d); checkgradtotloss = gradtotloss_d
           end if
           deepntotdata_d = deepntotdata
        end if

        call deeppub_loss_function_end(checkdeepntotdata*nlabelcv, checktotloss)
        if ( ngradcv > 0 ) call deeppub_loss_function_end(checkdeepntotdata*ngradcv, checkgradtotloss)

     end if


     if ( deepprocid == 0 ) then
 
        if ( checkdeepntotdata == 0 ) then
           if ( ngradcv == 0 ) then
              print "(a,i6,5x,a,f12.6,5x,a,f12.8)","Epoch ",iepoch,"Loss ",totloss,"Learnrate ",learnrate
           else
              print "(a,i6,5(5x,a,f12.6))","Epoch ",iepoch,"Loss ",totloss,"GradLoss ",gradtotloss
           end if       
        else
           if ( ngradcv == 0 ) then
              if ( ifclasses == 0 ) then
                 print "(a,i6,5(5x,a,f12.6,5x,a,f12.8))","Epoch ",iepoch,"Loss ",totloss,"ValidLoss ",checktotloss,"Learnrate ",learnrate
              else
                 curaccu = dble(ncorrectclass)/dble(checkdeepntotdata)
                 print "(a,i6,5(5x,a,f12.6))","Epoch ",iepoch,"Loss ",totloss,"ValidLoss ",checktotloss,"ValidAccu ",curaccu
              end if
           else
              print "(a,i6,5(5x,a,f12.6))","Epoch ",iepoch,"Loss ",totloss,"GradLoss ",gradtotloss,"ValidLoss ",checktotloss, "ValidGradLoss ",checkgradtotloss
           end if
        end if

        call deeppub_time_from_1970(endtime)
        if (mod(iepoch,20)==0 .and. deepprocid==0) call deeppub_print_time(6,(endtime-initime),iepoch,dble(iepoch)/dble(nepoch))

        if ( learnratewarmsteps > 0 ) then
           if ( iflearnratewarm .eqv. .true. ) then
              learnrate = learnrate + (maxlearnrate-minlearnrate)/dble(learnratewarmsteps)
              if ( (iepoch-learnratecoolminstep) >= learnratewarmsteps ) then
                 iflearnratewarm = .false.; learnratecoolminstep = iepoch; learnratecoolminloss = huge(1.0)
                 learnratewarmpeakepoch = 0
              end if
           else
              if ( totloss > pretotloss .and. learnrate > minlearnrate ) then
                 if ( learnratewarmpeakepoch == 0 ) learnratewarmpeakepoch = iepoch
                 if ( learnratedecay > 0.0d0 ) then
                    learnrate = learnrate*learnratedecay
                 else
                    ! Sigmoid Decay with Warmup (sig+) (Eq.3)
                    ! https://doi.org/10.3390/electronics10162029
                    learnrate = minlearnrate + (maxlearnrate-minlearnrate)/(1d0+exp(abs(learnratedecay)*(2d0*dble(iepoch-learnratewarmpeakepoch)-1d0))) 
                 end if
              end if
              if ( totloss < learnratecoolminloss ) then
                 learnratecoolminloss = totloss; learnratecoolminstep = iepoch
              else if ( (iepoch - learnratecoolminstep) > learnratepatientsteps ) then
                 iflearnratewarm = .true.; learnrate = minlearnrate
                 learnratecoolminstep = iepoch
              end if
           end if
        end if

        if ( totloss < mintotloss ) then
           if ( (ifsaveminlossnetwork .eqv. .true.) .and. (mod(iepoch,10) == 0) ) then
              if ( totloss > pretotloss ) ifstartrecordnetwork = .true.
              if ( ifstartrecordnetwork .eqv. .true. ) then
                 write(tpstring,*) iepoch; write(tpfilename,"(f10.5)") totloss
                 write(tpfilename,"(a)") "network_epoch"//trim(adjustl(tpstring))//"_loss"//trim(adjustl(tpfilename))//".txt"
                 if ( lastnetworkfilename /= "" ) ierr = system("rm "//lastnetworkfilename) 
                 call deep_network_save(tpfilename)
                 call mlp_network_save(tpfilename)
                 lastnetworkfilename = tpfilename
              end if
           end if
           mintotloss = totloss; minlossepoch = iepoch
        end if
        pretotloss = totloss

     end if

     call mpi_bcast(learnrate,1,mpi_double_precision,0, mpi_comm_world,ierr)
     if ( icudagroup > 0 ) learnrate_d = learnrate

  end do

  call mpi_barrier(mpi_comm_world, ierr)

  if ( icudagroup == 0 ) then

     totloss = 0.0d0; shuffleidx = [(i,i=1,deepntotdata)]
     do ibatch = 1, batchnum

        call deep_get_batchdata(shuffleidx,ibatch,tpinputs(:,:,1),tptrueoutputs(:,:,1),tptruegrads=tptruegrads(:,:,1),tperrormark=errormark)
 
        call mlp_network_forward(1,tpinputs,tpoutputs,errormark=errormark)

        call deeppub_loss_function(tptrueoutputs(1:noutput,:,1),tpoutputs(1:noutput,:,1),totloss,tperrormark=errormark)

    end do

  else

     totloss_d = 0.0_SD; shuffleidx_d = [(idata,idata=1,deepntotdata)]
     do ibatch = 1, batchnum
        do igroup = 1, (batchsize-1)/(icudagroup*deepprocnum)+1
           call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,ibatch,igroup,ninput)
           call mlp_network_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(1,igroup)
           call mlp_network_forward_cuda()
           call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,ibatch,igroup,noutput)
           call mlp_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(1,igroup,.true.)

        end do
     end do
     call deeppub_ncclAllReduce_scalar(totloss_d); totloss = totloss_d

  end if

  call mpi_barrier(mpi_comm_world, ierr)

  if ( deepprocid == 0 ) then
     index = min(batchsize*batchnum, deepntotdata)
     call deeppub_loss_function_end(index*nlabelcv, totloss)
     print "(/,a,f15.8)",   " Final Loss Function ",totloss
     print "(a,f15.8,a,i8)","Minmum Loss Function ",mintotloss," at epoch ",minlossepoch
     call deeppub_time_from_1970(endtime)
     print "(a,f15.1)",     " Cost time (seconds) ",(endtime - initime)/1000d0
   
     call deep_network_save()
     call mlp_network_save()
  end if
end subroutine

subroutine dnn_predict()
  integer :: iofile,istart,iend,idata,istep,index,i,j,k,ilayer
  real*8 :: tptruegrads(ninput,1,1),tppredictgrads(ninput,1,1),tpinputs(ninput,1,1),tpoutputs(noutput,1,1),tpgrouploss(size(labelcvgroupweight)/3)
  real*8,dimension(nlabelcv) :: tppredict,tplabelvec
  real*8 :: initime, endtime, tplabelweight, tpgradtotloss

  print "(/,a)","DNN Testing Data"

  call deeppub_time_from_1970(initime)
  
  tpgrouploss = 0d0; if ( ngradcv > 0 .and. icudagroup > 0 ) gradtotloss_d = 0.0_SD

  open(newunit=iofile,file="predict.txt",action="write")
  do idata = 1, deepntotdata
     tpinputs(1:ninput,1,1) = deeptrajcoor(1:ninput,idata)
     tplabelvec(:) = labelcvtraj(:,idata); tppredict = 0d0

     if ( ngradcv > 0 ) then
        tppredictgrads = 0d0
        tptruegrads(:,1,1) = graddeeptrajcoor(1:ninput,idata)
     end if

     if ( ngradcv > 0 ) tptruegrads(:,1,1) = graddeeptrajcoor(1:ninput,idata)

     if ( icudagroup == 0 ) then

        call mlp_network_forward(1,tpinputs,tpoutputs); tppredict = tpoutputs(:,1,1)
        if ( ngradcv > 0 ) then
            tpoutputs(:,:,1)=1d0
            call dnn_flooding_backward(tpoutputs, tppredictgrads)
            call deeppub_loss_function_grad(tptruegrads(:,:,1),tppredictgrads(:,:,1),tpgradtotloss)
        end if

     else

        if ( icudagroup > 1 ) stop "icudagroup must be 1 for prediction job!"
        deeptrajcoor_d(1:ninput,1) = tpinputs(1:ninput,1,1); shuffleidx_d = 1
        !if ( normalmode /= 0 ) call gnn_input_normalize_cuda<<<(ninput-1)/32+1,32>>>()
        call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,1,1,ninput)
        call mlp_network_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(1,1)
        call mlp_network_forward_cuda(tpoutputs=tpoutputs); tppredict = tpoutputs(:,1,1)

        call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,1,1,noutput)
        call mlp_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(1,1,.true.)
        if ( ngradcv > 0 ) then
           call dnn_flooding_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>()
           do ilayer = nlayer-1, 1, -1
              call dnn_flooding_backward_cuda<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(ilayer)
           end do
           i = hiddenstate_index(1)+1; j = hiddenstate_index(2)
           tppredictgrads(:,1,1) = delta_layer_d(i:j)
           call dnn_flooding_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(1,1)
           tpgradtotloss = gradtotloss_d
        end if

     end if

     if ( ngradcv == 0 ) then
        if ( ifavglabel .eqv. .true. ) then
           write(iofile,'(i10,*(f20.8))') idata,tplabelvec(:)+labelcvtrajavg(:),tppredict(:)+labelcvtrajavg(:)
        else
           write(iofile,'(i10,*(f15.8))') idata,tplabelvec(:),tppredict(:)
        end if
     else
        if ( ifavglabel .eqv. .true. ) then
           write(iofile,'(i10,*(f20.8))') idata,tplabelvec(:)+labelcvtrajavg(:),tppredict(:)+labelcvtrajavg(:),tptruegrads(:,1,1),tppredictgrads(:,1,1)
        else
           write(iofile,'(i10,*(f15.8))') idata,tplabelvec(:),tppredict(:),tptruegrads(:,1,1),tppredictgrads(:,1,1)
        end if
     end if

     do i = 1, size(labelcvgroupweight)/3
        j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1)); tplabelweight = labelcvgroupweight(3*i)
        select case (lossfunctype)
          case (RMSE); tpgrouploss(i) = tpgrouploss(i) + sum(((tppredict(j:k)-tplabelvec(j:k))/tplabelweight)**2)
          case (MAE);  tpgrouploss(i) = tpgrouploss(i) + sum((abs(tppredict(j:k)-tplabelvec(j:k))/tplabelweight)) 
        end select
     end do

  end do
  close(iofile)

  do i = 1, size(labelcvgroupweight)/3
     j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1))
     call deeppub_loss_function_end(deepntotdata*(k-j+1), tpgrouploss(i))
  end do
  print "(a,*(i10,f20.8))","Network Output Group Error  ",(i,tpgrouploss(i),i=1,size(labelcvgroupweight)/3)
  if ( ngradcv > 0 ) then
     print "(a,10x,f20.8)","Network Gradient Error      ",tpgradtotloss
  end if

  call deeppub_time_from_1970(endtime)
  print *,"Cost time ",endtime-initime
end subroutine

subroutine dnn_check_grad()
  integer :: ilayer,i,j,ipos
  real*8 :: upv,downv,h,originv,refgrad,maxerr
  real*8 :: tpinputs(ninput,1,1),tpoutputs(noutput,1,1),tplabels(noutput,1,1),tptruegrads(ninput,1,1)
  real*8 :: tpgrads(ninput,1,1)
  real*8 :: rand

  ! set the inputs and calculate the output values of neurons in all the layers
  call random_seed(); call random_number(tpinputs(:,1,1)); call random_number(tplabels(:,1,1))

  if ( normalmode /= 0 ) call dnn_input_normalize(tpinputs(:,1,1))
  call mlp_network_forward(1,tpinputs,tpoutputs)

  ! calculate the gradients in all the layers, gradients, grad_weights_l2l, grad_weights_t2t, grad_bias
  call mlp_network_backward_bptt(1,tplabels,.true.)

  if ( ngradcv > 0 ) then
     tpoutputs(:,1,1)=1d0; call dnn_flooding_backward(tpoutputs, tpgrads)
     call random_number(tptruegrads(:,1,1)); call dnn_flooding_forward(tptruegrads)
  end if
  h = 0.001d0; maxerr = 0d0
  do ilayer = nlayer,2,-1
     do i = 1, mlplayers(ilayer)%neurons
        do j = 1, mlplayers(ilayer-1)%neurons
           call random_number(rand)
           originv = mlplayers(ilayer)%weights_l2l(i,j)
           mlplayers(ilayer)%weights_l2l(i,j) = originv + h
           call get_loss(upv)
           mlplayers(ilayer)%weights_l2l(i,j) = originv - h
           call get_loss(downv)
           refgrad = (upv-downv)/(2d0*h)
           maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_weights_l2l(i,j)-refgrad))
           mlplayers(ilayer)%weights_l2l(i,j) = originv
        end do
     end do
     do i = 1,mlplayers(ilayer)%neurons
        call random_number(rand)
        originv = mlplayers(ilayer)%bias(i)
        mlplayers(ilayer)%bias(i) = originv + h
        call get_loss(upv)
        mlplayers(ilayer)%bias(i) = originv - h
        call get_loss(downv)
        refgrad = (upv-downv)/(2d0*h)
        maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_bias(i)-refgrad))
        mlplayers(ilayer)%bias(i) = originv
     end do

     if ( ifuselayernorm .eqv. .true. ) then
        call random_number(rand)
        originv = mlplayers(ilayer)%layerweight
        mlplayers(ilayer)%layerweight = originv + h
        call get_loss(upv)
        mlplayers(ilayer)%layerweight = originv - h
        call get_loss(downv)
        refgrad = (upv-downv)/(2d0*h)
        maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_layerweight-refgrad))
        mlplayers(ilayer)%layerweight = originv

        call random_number(rand)
        originv = mlplayers(ilayer)%layerbias
        mlplayers(ilayer)%layerbias = originv + h
        call get_loss(upv)
        mlplayers(ilayer)%layerbias = originv - h
        call get_loss(downv)
        refgrad = (upv-downv)/(2d0*h)
        maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_layerbias-refgrad))
        mlplayers(ilayer)%layerbias = originv
     end if
  end do

  print "(a,f20.15)","DNN Network Gradient Error:" ,maxerr
contains

subroutine get_loss(tploss)
  real*8,intent(out) :: tploss

  call mlp_network_forward(1,tpinputs,tpoutputs)
  tploss = sum(labelcvweight(:)*(tplabels(1:nlabelcv,1,1) - tpoutputs(1:noutput,1,1))**2)

  if ( ngradcv > 0 ) then
     tpoutputs(:,:,1)=1d0; call dnn_flooding_backward(tpoutputs, tpgrads)
     tploss = tploss + sum((tptruegrads(1:ngradcv,1,1) - tpgrads(1:ngradcv,1,1))**2)
  end if
end subroutine
end subroutine

subroutine dnn_flooding_initialize(tpnetworkfile,tpicuda)
  character(len=*),intent(in) :: tpnetworkfile
  integer,intent(in) :: tpicuda

  networkfile = tpnetworkfile; jobtype = PREDICT; icudagroup = tpicuda
  call deep_initialize("",tpicuda=tpicuda)
  call mlp_initialize(ninput,noutput,nlayer,layers,totparms,tpoutputweight=labelcvweight)
  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms
end subroutine

subroutine dnn_check_flood()
  integer :: i,j,ilayer
  real*8 :: bin(ninput),originv(ninput)
  real*8 :: tpout1(noutput),tpout2(noutput),tpoutputs(noutput,1,1),tpinputs(ninput,1,1),h,maxerr
  real*8 :: tpbin1(ninput),tpbin2(ninput)

  if ( deepntotdata /= 1 ) stop "deepntotdata should be 1 in CHECK task!"
  call random_seed(); call random_number(originv)

  tpinputs(:,1,1) = originv
  if ( normalmode /= 0 ) call dnn_input_normalize(tpinputs(:,1,1))
  call mlp_network_forward(1,tpinputs,tpoutputs)

  tpoutputs(:,1,1)=1d0; call dnn_flooding_backward(tpoutputs, tpinputs); bin(:)= tpinputs(:,1,1)

  call dnn_flooding_backward_end(bin)

  if ( icudagroup > 0 ) then
     deeptrajcoor_d(1:ninput,1) = originv(1:ninput); shuffleidx_d = 1 

     if ( normalmode /= 0 ) call dnn_input_normalize_cuda<<<(ninput-1)/32+1,32>>>()

     call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,1,1,ninput)
     call mlp_network_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(1,1)
     call mlp_network_forward_cuda()

     call dnn_flooding_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>()
     do ilayer = nlayer-1, 1, -1
        call dnn_flooding_backward_cuda<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(ilayer)
     end do

     call dnn_flooding_backward_end_cuda<<<(ninput-1)/32+1,32>>>()

     i = delta_layer_index_d(1)+1; j = delta_layer_index_d(2)
     tpinputs(1:ninput,1,1) = delta_layer_d(i:j)

     if ( ngradcv == 0 ) then
        do i = 1, ninput
           print "(a,i4,2e16.4e2)","CPU and GPU flooding error on input ",i,bin(i),tpinputs(i,1,1)
        end do
     else
        do i = 1, ngradcv
           print "(a,i4,2e16.4e2)","CPU and GPU flooding error on input ",i,bin(i),tpinputs(i,1,1)
        end do
     end if
  end if

  if ( ngradcv > 0 ) return

  h = 0.01d0; maxerr = -1d0
  do i = 1, ninput
     tpinputs(:,1,1) = originv; tpinputs(i,1,1) = originv(i) + h
     if ( normalmode /= 0 ) call dnn_input_normalize(tpinputs(:,1,1))
     call mlp_network_forward(1,tpinputs,tpoutputs); tpout1 = tpoutputs(:,1,1)

     tpinputs(:,1,1) = originv; tpinputs(i,1,1) = originv(i) - h
     if ( normalmode /= 0 ) call dnn_input_normalize(tpinputs(:,1,1))
     call mlp_network_forward(1,tpinputs,tpoutputs); tpout2 = tpoutputs(:,1,1)

     maxerr = max(abs(sum((tpout1-tpout2)/(2d0*h))-bin(i)),maxerr)
  end do
  write(6,'(a,f20.15)'),'Network Flooding Error:',maxerr
end subroutine

subroutine dnn_input_normalize(tpvec)
  real*8,intent(inout) :: tpvec(:)
  integer :: i
  real*8 :: tpmin,tpmax

  if ( normalmode == 0 ) return
  do i = 1, ninput
     tpmin = trajmin(i); tpmax = trajmax(i); if ( tpmin == tpmax ) cycle
     if ( normalmode == 1 ) then
        tpvec(i) = normalfactor*( tpvec(i) - trajmin(i) )/( trajmax(i) - trajmin(i) )
     else if ( normalmode == 2 ) then
        tpvec(i) = normalfactor*( 2d0*tpvec(i) - (trajmin(i)+trajmax(i)) )/( trajmax(i) - trajmin(i) )
     end if
  end do
end subroutine

subroutine dnn_flooding_backward_end(tpvec)
  real*8,dimension(:) :: tpvec

  if ( normalmode == 1 ) then
     tpvec(:) = normalfactor*tpvec(:)/(trajmax - trajmin)
  else if ( normalmode == 2 ) then
     tpvec(:) = normalfactor*2d0*tpvec(:)/(trajmax - trajmin)
  end if
end subroutine

attributes(global) subroutine dnn_flooding_backward_end_cuda()
  integer :: istate
  real(kind=SD) :: tpvalue

  istate = (blockidx%x-1)*32+threadidx%x; if ( istate > ninput_d ) return
  tpvalue = delta_layer_d(delta_layer_index_d(1) + istate)
  if ( normalmode_d == 1 ) then
     tpvalue = normalfactor_d*tpvalue/(trajmax_d(istate) - trajmin_d(istate))
  else if ( normalmode_d == 2 ) then
     tpvalue = normalfactor_d*2.0_SD*tpvalue/(trajmax_d(istate) - trajmin_d(istate))
  end if
  delta_layer_d(delta_layer_index_d(1) + istate) = tpvalue
end subroutine

subroutine dnn_flooding_backward(bout, bin, errormark)
  real*8,dimension(:,:,:) :: bout,bin
  integer,dimension(:),optional :: errormark
  integer :: ilayer,idata

  do idata = 1, size(bout,2)
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     mlplayers(nlayer)%hiddenstate(:,idata,1,1) = bout(:,idata,1)
     do ilayer = nlayer-1,1,-1
        mlplayers(ilayer)%hiddenstate(:,idata,1,1) = matmul(transpose(mlplayers(ilayer+1)%weights_l2l(:,:)),mlplayers(ilayer+1)%hiddenstate(:,idata,1,1))
        if ( ilayer >= 2 ) then
            mlplayers(ilayer)%hiddenstate(:,idata,1,1) = mlplayers(ilayer)%hiddenstate(:,idata,1,1)*mlplayers(ilayer)%grad_active(:,idata,1,1)

           if ( ifuselayernorm .eqv. .true. ) then
              mlplayers(ilayer)%hiddenstate(:,idata,1,1) = mlplayers(ilayer)%hiddenstate(:,idata,1,1)*mlplayers(ilayer)%layerweight
                 call mlp_layer_normalization_backward( &
                      mlplayers(ilayer)%layernormin(:,idata,1,1),   &
                      mlplayers(ilayer)%hiddenstate(:,idata,1,1),                   &
                      mlplayers(ilayer)%layermean(idata,1,1),               &
                      mlplayers(ilayer)%layersigma(idata,1,1) )
           end if
        end if
     end do
     bin(:,idata,1) = mlplayers(1)%hiddenstate(:,idata,1,1)
  end do
end subroutine

subroutine dnn_flooding_forward(bin,errormark)
  real*8,dimension(:,:,:) :: bin
  integer,dimension(:),optional :: errormark
  integer :: ilayer,idata,istate,tpnum
  real*8 :: tpsum,tpsigma,tpmean,tpnormin

  do idata = 1, size(bin,2)
     if ( present(errormark) ) then
        if ( errormark(idata) == 1 ) cycle
     end if

     mlplayers(1)%delta_layer(:) = 0.0d0
     mlplayers(1)%delta_layer(1:ngradcv) = 2.0d0*gradcvweight*(mlplayers(1)%hiddenstate(1:ngradcv,idata,1,1)-bin(1:ngradcv,idata,1))
     do ilayer = 2, nlayer
        call deeppub_matmul_outer_product(mlplayers(ilayer)%grad_weights_l2l(:,:),  &
             mlplayers(ilayer)%hiddenstate(:,idata,1,1),mlplayers(ilayer-1)%delta_layer(:))
        mlplayers(ilayer)%delta_layer(:) = &
             matmul(mlplayers(ilayer)%weights_l2l(:,:),mlplayers(ilayer-1)%delta_layer(:))
        if ( ilayer == nlayer ) exit

        if ( ifuselayernorm .eqv. .true. ) then
           stop "should come here"
        end if
        mlplayers(ilayer)%delta_layer(:) = mlplayers(ilayer)%delta_layer(:)*mlplayers(ilayer)%grad_active(:,idata,1,1)
     end do
  end do
end subroutine

attributes(global) subroutine dnn_input_normalize_cuda()
  integer :: istate
  real(kind=SD) :: tpvalue

  istate = (blockidx%x-1)*32+threadidx%x; if ( istate > size(trajmin_d,1) ) return
  if ( normalmode_d == 1 ) then
     if ( trajmax_d(istate) == trajmin_d(istate) ) return
     deeptrajcoor_d(istate,1) = normalfactor_d*( deeptrajcoor_d(istate,1) - trajmin_d(istate) )/( trajmax_d(istate) - trajmin_d(istate) )
  else if ( normalmode_d == 2 ) then
     if ( trajmax_d(istate) == trajmin_d(istate) ) return
     deeptrajcoor_d(istate,1) = normalfactor_d*( 2.0_SD*deeptrajcoor_d(istate,1) - (trajmin_d(istate) + trajmax_d(istate)) )/( trajmax_d(istate) - trajmin_d(istate) )
  end if
end subroutine

attributes(global) subroutine dnn_flooding_backward_cuda_outputlayer()
  integer :: istate,irec

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/noutput_d+1; if ( irec > icudagroup_d ) return
  if ( errormark_d(irec) == 1 ) return
  delta_layer_d(delta_layer_index_d(nlayer_d) + istate) = 1.0_SD
end subroutine

attributes(global) subroutine dnn_flooding_backward_cuda(ilayer)
  integer,intent(in),value :: ilayer
  integer :: ileftstate,irightstate,nleftneuron,nrightneuron
  integer :: istate,ibias,idelta,nlayer,irec
  real(kind=SD) :: tpstate,tpvalue

  nlayer = nlayer_d; tpstate = 0.0_SD
  nleftneuron = mlplayers_d(ilayer); nrightneuron = mlplayers_d(ilayer+1)

  ileftstate = blockidx%x; irec = (ileftstate-1)/nleftneuron+1; if ( errormark_d(irec) == 1 ) return
  ileftstate = ileftstate - (irec-1)*nleftneuron

  if ( ileftstate <= nleftneuron ) then
     idelta = delta_layer_index_d(ilayer+1) + (irec-1)*nrightneuron
     ibias = weights_l2l_index_d(ilayer+1) + (ileftstate-1)*nrightneuron
     do irightstate = threadidx%x, nrightneuron, 32
        tpstate = tpstate + weights_l2l_d(ibias + irightstate)*delta_layer_d(idelta+irightstate)
     end do
  end if

  ibias = 1
  do while (ibias<=16)
     tpvalue = __shfl_xor(tpstate,ibias); tpstate = tpstate + tpvalue
     ibias = ibias*2
  end do

  if ( threadidx%x == 1 ) then
     idelta = (irec-1)*nleftneuron + ileftstate
     if ( ilayer > 1 ) then
        istate = grad_active_index_d(ilayer) + idelta
        tpstate = tpstate*grad_active_d(istate)
     end if
     delta_layer_d(delta_layer_index_d(ilayer) + idelta) = tpstate
  end if
end subroutine

attributes(global) subroutine dnn_flooding_forward_cuda_inputlayer(ibatch,igroup)
  integer,intent(in),value :: ibatch,igroup
  integer :: istate,index,irec
  real(kind=SD) :: netinput,tpvalue

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/ninput_d+1; if ( irec > icudagroup_d ) return
  if ( errormark_d(irec) == 1 ) return

  index = istate; istate = istate - (irec-1)*ninput_d; if ( istate > ninput_d ) return
  netinput = delta_layer_d(delta_layer_index_d(1) + index)

  tpvalue = 0.0_SD
  if ( istate <= ngradcv_d ) then
     tpvalue = netinput - batchgraddata_d((irec-1)*ninput_d + istate)
  end if

  if ( deepntotdata_d > 0 ) then
     delta_layer_d(delta_layer_index_d(1) + index) = 2_SD*tpvalue*gradcvweight_d
  end if

  if ( istate > ngradcv_d ) return

  if ( lossfunctype_d == RMSE ) then
     irec = atomicadd(gradtotloss_d,tpvalue*tpvalue)
  else if ( lossfunctype_d == MAE ) then
     irec = atomicadd(gradtotloss_d,abs(tpvalue))
  end if
end subroutine

attributes(global) subroutine dnn_flooding_forward_cuda(ilayer)
  integer,intent(in),value :: ilayer
  integer :: istate,ileftstate,irightstate,nleftneuron,nrightneuron,idelta,il2l,irec
  real(kind=SD) :: tpstate,tpvalue,tpgrad

  nleftneuron = mlplayers_d(ilayer-1); nrightneuron = mlplayers_d(ilayer); tpstate = 0.0_SD

  irightstate = blockidx%x; irec = (irightstate-1)/nrightneuron+1; if ( errormark_d(irec) == 1 ) return
  irightstate = irightstate - (irec-1)*nrightneuron
  idelta = delta_layer_index_d(ilayer-1) + (irec-1)*nleftneuron
  il2l = weights_l2l_index_d(ilayer) - nrightneuron + irightstate
  tpgrad = delta_layer_d(delta_layer_index_d(ilayer) + (irec-1)*nrightneuron + irightstate)
  do ileftstate = threadidx%x, nleftneuron, 32
     tpvalue = delta_layer_d(idelta+ileftstate)
     istate = il2l + ileftstate*nrightneuron
     tpstate = tpstate + tpvalue*weights_l2l_d(istate)
     tpvalue = atomicadd( grad_weights_l2l_d(istate), tpvalue*tpgrad )
  end do

  istate = 1
  do while (istate<=16)
     tpvalue = __shfl_xor(tpstate,istate); tpstate = tpstate + tpvalue
     istate = istate*2
  end do

  if ( threadidx%x == 1 ) then
     istate = (irec-1)*nrightneuron + irightstate
     if ( ilayer < nlayer_d ) then
        tpstate = tpstate*grad_active_d(grad_active_index_d(ilayer) + istate)
     end if
     delta_layer_d(delta_layer_index_d(ilayer) + istate) = tpstate
  end if

end subroutine

attributes(global) subroutine dnn_cudaactivate_hiddenstate(ilayer)
  integer,value :: ilayer
  integer :: istate,iactive
  real(kind=SD) :: tpvalue

  iactive = (blockidx%x-1)*blockdim%x + threadidx%x
  istate = iactive + hiddenstate_index_d(ilayer)
  if ( istate > hiddenstate_index_d(ilayer+1) ) return

  tpvalue = hiddenstate_d(istate)
  iactive = grad_active_index_d(ilayer) + iactive
  call mlp_activation_function_cuda(tpvalue,hiddenstate_d(istate),grad_active_d(iactive))
end subroutine

attributes(global) subroutine dnn_cudaactivate_delta(ilayer)
  integer,value :: ilayer
  integer :: istate,iactive

  iactive = (blockidx%x-1)*blockdim%x + threadidx%x
  istate = iactive + delta_layer_index_d(ilayer)
  if ( istate > delta_layer_index_d(ilayer+1) ) return

  iactive = grad_active_index_d(ilayer) + iactive
  delta_layer_d(istate) = delta_layer_d(istate)*grad_active_d(iactive)
end subroutine

attributes(global) subroutine dnn_cudadeactivate_delta(ilayer)
  integer,value :: ilayer
  integer :: istate,iactive
  real(kind=SD) :: tpvalue

  iactive = (blockidx%x-1)*blockdim%x + threadidx%x
  istate = iactive + delta_layer_index_d(ilayer)
  if ( istate > delta_layer_index_d(ilayer+1) ) return

  tpvalue = delta_layer_d(istate)
  iactive = grad_active_index_d(ilayer) + iactive

  delta_layer_d(istate) = tpvalue*grad_active_d(iactive)
end subroutine

attributes(global) subroutine dnn_cudaupdatebias(ilayer)
  integer,value :: ilayer
  integer :: idelta,iactive,istate,irow,icol,icudagroup

  istate = (blockidx%x-1)*blockdim%x + threadidx%x
  idelta = delta_layer_index_d(ilayer); iactive = delta_layer_index_d(ilayer+1)
  if ( idelta+istate > iactive ) return

  icudagroup = icudagroup_d
  icol = (istate-1)/icudagroup + 1; irow = istate - (icol-1)*icudagroup

  icol = (irow-1)*(iactive - idelta)/icudagroup + icol
  idelta = idelta + istate; istate = icol

  iactive = grad_active_index_d(ilayer) + istate
  delta_layer_d(idelta) = delta_layer_d(idelta)*grad_active_d(iactive)

  iactive = (istate-1)/icudagroup + 1; istate = istate - (iactive-1)*icudagroup
  istate = bias_index_d(ilayer) + istate
  iactive = atomicadd(grad_bias_d(istate),  delta_layer_d(idelta))
end subroutine

attributes(global) subroutine dnn_cudaaddbias(ilayer)
  integer,value :: ilayer
  integer :: ineuron,istate,istart,istop

  istate = (blockidx%x-1)*blockdim%x + threadidx%x
  istart = hiddenstate_index_d(ilayer)
  istop = hiddenstate_index_d(ilayer+1)
  if ( istart + istate > istop  ) return

  istop = (istop - istart)/icudagroup_d
  ineuron = (istate - 1)/istop + 1; ineuron = istate - (ineuron-1)*istop
  hiddenstate_d(istart+istate) = hiddenstate_d(istart+istate) + bias_d(bias_index_d(ilayer)+ineuron)
end subroutine

end module
