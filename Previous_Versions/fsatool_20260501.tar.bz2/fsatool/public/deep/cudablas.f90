module cudablas
  implicit none

  interface cublasInit
    integer function cublasInit() bind(C,name='cublasInit')
    end function cublasInit
  end interface cublasInit

  interface cublasXgemm
    subroutine cublasDgemm(transa, transb, m, n, k, alpha, a, lda, b, ldb, beta, c, ldc) bind(C,name='cublasDgemm')
      use iso_c_binding
      character(1,c_char),value :: transa, transb
      integer(c_int),value :: m, n, k, lda, ldb, ldc
      real(c_double), device, dimension(lda, *) :: a
      real(c_double), device, dimension(ldb, *) :: b
      real(c_double), device, dimension(ldc, *) :: c
      real(c_double),value  :: alpha, beta ! device or host variable 
    end subroutine

    subroutine cublasSgemm(transa, transb, m, n, k, alpha, a, lda, b, ldb, beta, c, ldc) bind(C,name='cublasSgemm')
      use iso_c_binding
      character(1,c_char),value :: transa, transb
      integer(c_int),value :: m, n, k, lda, ldb, ldc
      real(c_float), device, dimension(lda, *) :: a
      real(c_float), device, dimension(ldb, *) :: b
      real(c_float), device, dimension(ldc, *) :: c
      real(c_float),value  :: alpha, beta ! device or host variable 
    end subroutine
  end interface cublasXgemm
  
end module
