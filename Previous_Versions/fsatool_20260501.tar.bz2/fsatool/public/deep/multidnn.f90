module multidnn
  use deep; use deeppub; use mlp0
  implicit none
  integer,private :: nmultinet

  type multidnntype
    character*50 :: name
    integer :: id,ninput,noutput,natom,nlayer,normalmode,cvstart(1),cvend(1)
    integer :: labelcvstart(1),labelcvend(1)
    real*8 :: normalfactor
    integer,allocatable,dimension(:) :: layers
    real*8,allocatable,dimension(:) :: labelcvgroupweight,trajmin,trajmax,labelcvtrajmin,labelcvtrajmax,labelcvtrajavg
    logical :: ifbias,ifavglabel
  end type

  type(multidnntype),allocatable,private :: multidnns(:) 
  type(mlptype),dimension(:),allocatable,private :: multinetworklist

contains

subroutine multidnn_initialize(parmfile,ifok)
  character(len=*),intent(in) :: parmfile
  logical,intent(out) :: ifok
  integer :: tpninput,tpnoutput,i,j,k,iofile,ierr,ifile,tplayers(20),tpnlayer,totparms
  integer,parameter :: maxnfile=420
  real*8 :: tpvec(99)
  character*150 :: tpfiles(maxnfile),tpfilename,tpline,tpstring
  character*150,allocatable :: networknames(:)
  character*150 :: trajfile(maxntrajfile),checktrajfile(maxntrajfile),inputbiasfile(maxntrajfile),outputcutfile(maxntrajfile)

  namelist / multidnn / networknames, lossfunction

  ifok = .true.

  allocate(networknames(maxnfile)); networknames=""
  open(newunit=iofile, file=parmfile, action="read")
  read(iofile, nml=multidnn, iostat=ierr); close(iofile)
  if ( ierr /= 0 ) then
     ifok=.false.; return
  end if

  nmultinet = 0
  do ifile = 1, maxnfile
     if ( networknames(ifile)=="" ) exit
  end do
  nmultinet = ifile - 1
  allocate(multidnns(nmultinet)); multidnns(:)%ifbias = .false.
  allocate(multinetworklist(nmultinet))

  if ( deepprocnum > 1 ) stop "Only one process is required in Multi-DNN prediction!"

  totparms = 0
  do ifile = 1, nmultinet
     multidnns(ifile)%id = ifile; multidnns(ifile)%name = trim(networknames(ifile))
     tpfilename = trim(networknames(ifile))//".net"; tplayers = 0
     open(newunit=iofile,file=tpfilename,action="read")
     do 
        read(iofile,"(a)",iostat=ierr) tpline
        if ( ierr /= 0 ) exit
        if ( trim(tpline) == "network layers:" ) then
           read(iofile,"(20(i5))") tplayers; i = 0
           do; i = i + 1; if ( tplayers(i) == 0 ) exit; end do; tpnlayer = i - 1
           multidnns(ifile)%nlayer = tpnlayer
           allocate(multidnns(ifile)%layers(tpnlayer)); multidnns(ifile)%layers(1:tpnlayer) = tplayers(1:tpnlayer)
           multidnns(ifile)%ninput = multidnns(ifile)%layers(1)
           multidnns(ifile)%noutput = multidnns(ifile)%layers(tpnlayer)
           multidnns(ifile)%natom = (multidnns(ifile)%ninput+9)/4
        else if ( trim(tpline) == "activation function:" ) then
           read(iofile,"(a)") activation
        else if ( tpline(1:5) == "bias:" ) then
           multidnns(ifile)%ifbias = .true.
        else if ( trim(tpline) == "cv range:" ) then
           read(iofile,"(*(i8))") multidnns(ifile)%cvstart(1),multidnns(ifile)%cvend(1) 
           if ( (multidnns(ifile)%cvend(1) - multidnns(ifile)%cvstart(1) + 1) /= multidnns(ifile)%ninput ) then
              print *,"cv range is confirmed with ninput ",multidnns(ifile)%cvstart(1),multidnns(ifile)%cvend(1),multidnns(ifile)%ninput; stop
           end if
        else if ( trim(tpline) == "normalization mode:" ) then
           read(iofile,*) multidnns(ifile)%normalmode
        else if ( trim(tpline) == "normalization factor:" ) then
           read(iofile,*) multidnns(ifile)%normalfactor
        else if ( trim(tpline) == "cv low boundary:" ) then
           allocate(multidnns(ifile)%trajmin(multidnns(ifile)%ninput))
           allocate(multidnns(ifile)%trajmax(multidnns(ifile)%ninput))
           read(iofile,"(*(f15.8))") multidnns(ifile)%trajmin
        else if ( trim(tpline) == "cv up boundary:" ) then
           read(iofile,"(*(f15.8))") multidnns(ifile)%trajmax
        else if ( trim(tpline) == "label cv range:" ) then
           read(iofile,"(*(i8))") multidnns(ifile)%labelcvstart(1),multidnns(ifile)%labelcvend(1)
           if ( (multidnns(ifile)%labelcvend(1)-multidnns(ifile)%labelcvstart(1)+1) /= multidnns(ifile)%noutput ) then
              print *,"label cv range is not confirmed with noutput! ",multidnns(ifile)%labelcvstart(1),multidnns(ifile)%labelcvend(1),multidnns(ifile)%noutput; stop
           end if
        else if ( trim(tpline) == "label cv low boundary:" ) then
           allocate(multidnns(ifile)%labelcvtrajmin(multidnns(ifile)%noutput))
           read(iofile,"(*(f15.8))") multidnns(ifile)%labelcvtrajmin   
        else if ( trim(tpline) == "label cv up boundary:" ) then
           allocate(multidnns(ifile)%labelcvtrajmax(multidnns(ifile)%noutput))
           read(iofile,"(*(f15.8))") multidnns(ifile)%labelcvtrajmax
        else if ( trim(tpline(1:17)) == "label cv average:" ) then
           read(tpline,"(a18,l4)") tpstring,multidnns(ifile)%ifavglabel
           allocate(multidnns(ifile)%labelcvtrajavg(multidnns(ifile)%noutput))
           read(iofile,"(*(f20.8))") multidnns(ifile)%labelcvtrajavg
        else if ( trim(tpline) == "labelcv group weight:" ) then
           read(iofile,"(*(f10.3))") tpvec

           do i = 1, size(tpvec); if ( tpvec(i) == 0d0 ) exit ; end do
           k = (i - 1)/3
           if ( k > 0 ) then
              allocate(multidnns(ifile)%labelcvgroupweight(3*k))
              multidnns(ifile)%labelcvgroupweight(1:3*k)=tpvec(1:3*k)
           else
              allocate(multidnns(ifile)%labelcvgroupweight(3))
              multidnns(ifile)%labelcvgroupweight(1:3)=[1,noutput,1.0d0]
           end if

        end if
     end do
     close(iofile)

     if ( multidnns(ifile)%natom /= multidnns(ifile)%noutput/3 ) then
        print *,"network's input and output are not confirmed with each other! ",multidnns(ifile)%ninput,multidnns(ifile)%noutput,multidnns(ifile)%natom; stop
     end if

     call mlp0_initialize(multinetworklist(ifile),multidnns(ifile)%layers,totparms,tpifbias=multidnns(ifile)%ifbias)
print *,"multidnns(ifile)%ifbias ",multidnns(ifile)%ifbias
  end do

  if ( icudagroup > 0 )  call mlp0_initialize_cuda(multinetworklist)

  print "(/,a,/)",   "Doing Multi-DNN Prediction"

  do ifile = 1, nmultinet
     print "(a,i5,5x,a,a,5x,a,i5)","    Network ID ",ifile,"Name ",trim(networknames(ifile)),"Atom Number ",multidnns(ifile)%natom
     print "(a,*(i5))",  "Network Layers ",multidnns(ifile)%layers(:)

  end do

  print "(/,a,a)",   "    Activation Function : ",trim(activation)
  print "(a,i10)",   "       Total parameters : ",totparms

  print *

  call deeppub_set_activefunction_and_lossfunction()

  trajfile=""; checktrajfile=""; inputbiasfile=""; outputcutfile=""
  allocate(cvstart(1),cvend(1),labelcvstart(1),labelcvend(1))
  do ifile = 1, nmultinet
     print "(/,a,i5,5x,a)","Doing prediction for network ",ifile,trim(networknames(ifile))

     normalmode = multidnns(ifile)%normalmode
     normalfactor = multidnns(ifile)%normalfactor
     ninput = multidnns(ifile)%ninput
     noutput = multidnns(ifile)%noutput
     cvstart = multidnns(ifile)%cvstart; cvend = multidnns(ifile)%cvend
     labelcvstart = multidnns(ifile)%labelcvstart; labelcvend = multidnns(ifile)%labelcvend
     nlabelcv = labelcvend(1) - labelcvstart(1) + 1
     if ( allocated(trajmin) ) deallocate(trajmin)
     allocate(trajmin(ninput)); trajmin = multidnns(ifile)%trajmin
     if ( allocated(trajmax) ) deallocate(trajmax)
     allocate(trajmax(noutput)); trajmax = multidnns(ifile)%trajmax
     if ( allocated(labelcvtrajmin) ) deallocate(labelcvtrajmin,labelcvtrajmax)
     allocate(labelcvtrajmin(noutput),labelcvtrajmax(noutput))
     labelcvtrajmin = multidnns(ifile)%labelcvtrajmin
     labelcvtrajmax = multidnns(ifile)%labelcvtrajmax
     if ( allocated(labelcvtrajavg) ) deallocate(labelcvtrajavg) 
     allocate(labelcvtrajavg(noutput)); labelcvtrajavg=multidnns(ifile)%labelcvtrajavg
     ifavglabel = multidnns(ifile)%ifavglabel

     trajfile(1) = trim(networknames(ifile))//".deeptraj"
     call deep_traj_loadin(trajfile,0,0, checktrajfile,inputbiasfile,outputcutfile,.false.)
     call deep_traj_normalization()

     call mlp0_network_reload(multinetworklist(ifile),tpfile=trim(networknames(ifile))//".net")

     if ( allocated(labelcvgroupweight) ) deallocate(labelcvgroupweight)
     allocate(labelcvgroupweight(size(multidnns(ifile)%labelcvgroupweight)))
     labelcvgroupweight(:) = multidnns(ifile)%labelcvgroupweight(:)

     if ( allocated(labelcvweight) ) deallocate(labelcvweight)
     allocate(labelcvweight(noutput))
     do i = 1, size(labelcvgroupweight)/3
        j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1))
        if ( j < 1 .or. j > noutput .or. k < 1 .or. k > noutput ) stop "incorrect labelcvgroupweight setup"
        labelcvweight(j:k) = labelcvgroupweight(3*i)
     end do

     call multinn_predict(multinetworklist(ifile))

  end do

end subroutine

subroutine multinn_predict(tpnet)
  type(mlptype) :: tpnet
  integer :: iofile,istart,iend,idata,istep,index,i,j,k,ilayer
  real*8 :: tptruegrads(ninput,1,1),tppredictgrads(ninput,1,1),tpinputs(ninput,1,1),tpoutputs(noutput,1,1),tpgrouploss(size(labelcvgroupweight)/3)
  real*8,dimension(nlabelcv) :: tppredict,tplabelvec
  real*8 :: initime, endtime, tpgradtotloss

  tpgrouploss = 0d0; if ( ngradcv > 0 .and. icudagroup > 0 ) gradtotloss_d = 0.0_SD
  open(newunit=iofile,file="predict.txt",action="write")
  do idata = 1, deepntotdata
     tpinputs(1:ninput,1,1) = deeptrajcoor(1:ninput,idata)
     tplabelvec(:) = labelcvtraj(:,idata); tppredict = 0d0

     if ( ngradcv > 0 ) then
        tppredictgrads = 0d0
        tptruegrads(:,1,1) = graddeeptrajcoor(1:ninput,idata)
     end if

     if ( icudagroup == 0 ) then

        call mlp0_network_forward(tpnet,1,tpinputs,tpoutputs); tppredict = tpoutputs(:,1,1)

        if ( ngradcv > 0 ) then
            tpoutputs(:,:,1)=1d0
            call mlp0_flooding_backward(tpnet, tpoutputs, tppredictgrads(:,:,1))
            call deeppub_loss_function_grad(tptruegrads(:,:,1),tppredictgrads(:,:,1),tpgradtotloss)
        end if

     else

        if ( icudagroup > 1 ) stop "icudagroup must be 1 for prediction job!"
        deeptrajcoor_d(1:ninput,1) = tpinputs(1:ninput,1,1); shuffleidx_d = 1
        !if ( normalmode /= 0 ) call gnn_input_normalize_cuda<<<(ninput-1)/32+1,32>>>()
        call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,1,1,ninput)
        call mlp0_network_forward_cuda(tpnet,tpoutputs=tpoutputs); tppredict = tpoutputs(:,1,1)

        call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,1,1,noutput)
        call mlp0_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(tpnet%id,.true.)

        if ( ngradcv > 0 ) then
           call mlp0_flooding_backward_cuda(tpnet,tpgrads=tppredictgrads)
           call mlp0_flooding_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(tpnet%id)
           tpgradtotloss = gradtotloss_d
        end if

     end if

     if ( ngradcv == 0 ) then
        if ( ifavglabel .eqv. .true. ) then
           write(iofile,'(i10,*(f20.8))') idata,tplabelvec(:)+labelcvtrajavg(:),tppredict(:)+labelcvtrajavg(:)
        else
           write(iofile,'(i10,*(f15.8))') idata,tplabelvec(:),tppredict(:)
        end if
     else
        if ( ifavglabel .eqv. .true. ) then
           write(iofile,'(i10,*(f20.8))') idata,tplabelvec(:)+labelcvtrajavg(:),tppredict(:)+labelcvtrajavg(:),tptruegrads(:,1,1),tppredictgrads(:,1,1)
        else
           write(iofile,'(i10,*(f15.8))') idata,tplabelvec(:),tppredict(:),tptruegrads(:,1,1),tppredictgrads(:,1,1)
        end if
     end if

     do i = 1, size(labelcvgroupweight)/3
        j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1))
        select case (lossfunctype)
          case (RMSE); tpgrouploss(i) = tpgrouploss(i) + sum(((tppredict(j:k)-tplabelvec(j:k)))**2)
          case (MAE);  tpgrouploss(i) = tpgrouploss(i) + sum((abs(tppredict(j:k)-tplabelvec(j:k))))
        end select
     end do

  end do
  close(iofile)

  do i = 1, size(labelcvgroupweight)/3
     j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1))
     call deeppub_loss_function_end(deepntotdata*(k-j+1), tpgrouploss(i))
  end do
  print "(a,*(i10,f20.8))","Network Output Group Error  ",(i,tpgrouploss(i),i=1,size(labelcvgroupweight)/3)

end subroutine

end module
