module deeppub
  use nccl; use cudafor; use mpi; use curand_device
  implicit none

  integer,parameter :: maxnlayer = 10
  integer,parameter :: SP = 4, DP = 8, SD = DP
  integer :: maxnsteps = 1, netnum = 0

  integer :: nepoch, totparms, deepsharenum, deepshareid, deep_shared_comm_world
  integer :: deepprocid,deepprocnum,icudagroup,jobtype,deepiseed,learnratewarmsteps,learnratepatientsteps
  integer :: deepntotdata,checkdeepntotdata,batchnum,checkbatchnum
  integer,device :: deepprocid_d,deepprocnum_d
  type(ncclResult) :: deepncclstat
  type(ncclUniqueId) :: deepnccluid
  type(ncclComm) :: deepncclcomm
  integer(kind=cuda_stream_kind) :: deepncclstream

  integer,parameter :: TRAIN=1, PREDICT=2, CHECK=3, EIGEN=4, STREAM=5
  integer,parameter :: maxntrajfile=50
  integer,parameter :: DNN=1, RNN=2, SRV=3, TAE=4, POISSON=5, GNN=6
  integer,parameter :: SIGM=1, TANH=2, RELU=3, LEAKYRELU=4, SELU=5, ARCTAN=6, SYMSIGM=7, LOGLOG=8, GAUSSIAN=9, SILU=10
  integer,parameter :: RMSE=1, MAE=2
  integer :: batchsize,ioptmethod,bptt_trun, activefunctype, lossfunctype
  character*150 :: networkfile = ""
  character*20 :: activation,lossfunction
  real*8 :: dropout,l1normfactor,l2normfactor,learnrate
  real*8 :: gradcvweight,maxlearnrate,minlearnrate,learnratedecay
  real*8,dimension(:),allocatable :: labelcvgroupweight(:),labelcvweight(:)

  integer :: ifclasses
  logical :: ifsaveminlossnetwork,ifproceed,ifuselayernorm

  type :: mlplayer
     ! number of neurons in the layer
     integer :: neurons

     real*8 :: layerweight, layerbias
     real*8 :: grad_layerweight, gradg_layerweight,gradgsq_layerweight
     real*8 :: grad_layerbias, gradg_layerbias,gradgsq_layerbias

     ! bias: bias on the neuron
     ! weights_l2l: layer-to-layer weights at the same time step
     ! weights_t2t: time-to-time weights in the same layer
     real*8,pointer :: weights_l2l(:,:),weights_t2t(:,:),bias(:)

     ! gradients on different neural netowrk variables (bias and weights)
     real*8,pointer :: grad_weights_l2l(:,:),grad_weights_t2t(:,:),grad_bias(:)
     real*8,pointer :: gradg_weights_l2l(:,:),gradg_weights_t2t(:,:),gradg_bias(:)
     real*8,pointer :: gradgsq_weights_l2l(:,:),gradgsq_weights_t2t(:,:),gradgsq_bias(:)

     ! delta_layer: derivative of the Loss function with respect to a layer (delta)
     real*8,pointer :: delta_layer(:)

     ! arrays for mini-batch gradient descent
     ! hiddenstate(nenuron,batchsize,0:ntimestep,2)
     ! output data of neurons in all layers
     ! 0 : neuron states before the first time step
     ! 2 : duplicated states in Siamese neural network
     real*8,pointer :: grad_active(:,:,:,:),hiddenstate(:,:,:,:),softmaxstate(:,:,:,:)
     real*8,pointer :: layernormin(:,:,:,:),layernormout(:,:,:,:),layermean(:,:,:),layersigma(:,:,:)

     ! plugin for flooding network
     real*8,pointer :: biaspot(:,:),addbiaspot(:,:),graddelta(:,:,:,:)
  end type

!============== variables on GPU

  integer,dimension(:),allocatable,device :: shuffleidx_d
  integer,device :: deepntotdata_d,lossfunctype_d,activefunctype_d,icudagroup_d,maxnsteps_d
  integer,device :: normalmode_d,ioptmethod_d,ntau_d,batchsize_d,nlabelcv_d,ngradcv_d,netnum_d
  integer,dimension(:),allocatable,device :: errormark_d

  real(kind=SD),device :: totenergyloss_d,totforceloss_d
  real(kind=SD),device :: dropout_d,normalfactor_d
  real(kind=SD),device :: learnrate_d,totloss_d,l1normfactor_d,l2normfactor_d,gradtotloss_d,gradcvweight_d
  real(kind=SD),dimension(:),allocatable,device :: labelcvweight_d(:)

  real(kind=SD),dimension(:),allocatable,device :: batchdata_d,batchlabel_d,batchgraddata_d

contains

subroutine deeppub_InitalizeSharedMemory()
  use, intrinsic :: iso_c_binding, only : c_ptr, c_f_pointer
  integer :: ierr
  call mpi_comm_split_type(mpi_comm_world, mpi_comm_type_shared, 0, mpi_info_null, deep_shared_comm_world, ierr)
  call mpi_comm_rank(deep_shared_comm_world, deepshareid, ierr)
  call mpi_comm_size(deep_shared_comm_world, deepsharenum, ierr)
end subroutine

subroutine deeppub_MPISharedMemoryAllocate(shared_win,   &
        dimreal1d,dimreal2d,dimreal3d,sharereal1d,sharereal2d,sharereal3d,   &
        dimint1d,dimint2d,dimint3d,shareint1d,shareint2d,shareint3d,         &
        dimstr1d,dimstr2d,dimstr3d,sharestrlen,sharestr1d,sharestr2d,sharestr3d)
  use, intrinsic :: iso_c_binding, only : c_ptr, c_f_pointer
  integer, intent(out) :: shared_win
  integer, intent(in), optional :: dimreal1d(1),dimreal2d(2),dimreal3d(3)
  real*8, pointer, intent(out), optional :: sharereal1d(:),sharereal2d(:,:),sharereal3d(:,:,:)
  integer, intent(in), optional :: dimint1d(1),dimint2d(2),dimint3d(3)
  integer, pointer, intent(out), optional :: shareint1d(:),shareint2d(:,:),shareint3d(:,:,:)
  integer, intent(in), optional :: dimstr1d(1),dimstr2d(2),dimstr3d(3)
  integer,intent(in),optional :: sharestrlen
  character(len=sharestrlen), pointer, intent(out), optional :: sharestr1d(:),sharestr2d(:,:),sharestr3d(:,:,:)

  type(C_PTR) :: baseptr
  integer :: ierr, disp_unit
  integer(kind=mpi_address_kind) :: windowsize

  if ( deepshareid == 0) then
     if ( present(dimreal1d) ) then
        windowsize = int(dimreal1d(1), MPI_ADDRESS_KIND)*8_MPI_ADDRESS_KIND
     else if ( present(dimreal2d) ) then
        windowsize = int(dimreal2d(1)*dimreal2d(2), MPI_ADDRESS_KIND)*8_MPI_ADDRESS_KIND
     else if ( present(dimreal3d) ) then
        windowsize = int(dimreal3d(1)*dimreal3d(2)*dimreal3d(3), MPI_ADDRESS_KIND)*8_MPI_ADDRESS_KIND
     else if ( present(dimint1d) ) then
        windowsize = int(dimint1d(1), MPI_ADDRESS_KIND)*4_MPI_ADDRESS_KIND
     else if ( present(dimint2d) ) then
        windowsize = int(dimint2d(1)*dimint2d(2), MPI_ADDRESS_KIND)*4_MPI_ADDRESS_KIND
     else if ( present(dimint3d) ) then
        windowsize = int(dimint3d(1)*dimint3d(2)*dimint3d(3), MPI_ADDRESS_KIND)*4_MPI_ADDRESS_KIND
     else if ( present(dimstr1d) ) then
        windowsize = int(dimstr1d(1)*sharestrlen, MPI_ADDRESS_KIND)*1_MPI_ADDRESS_KIND
     else if ( present(dimstr2d) ) then
        windowsize = int(dimstr2d(1)*dimstr2d(2)*sharestrlen, MPI_ADDRESS_KIND)*1_MPI_ADDRESS_KIND
     else if ( present(dimstr3d) ) then
        windowsize = int(dimstr3d(1)*dimstr3d(2)*dimstr3d(3)*sharestrlen, MPI_ADDRESS_KIND)*1_MPI_ADDRESS_KIND
     end if
  else
     windowsize = 0_MPI_ADDRESS_KIND
  end if
  disp_unit = 1

  call mpi_win_allocate_shared(windowsize, disp_unit, mpi_info_null, deep_shared_comm_world, &
             baseptr, shared_win, ierr)
  if ( deepshareid /= 0) then
     call mpi_win_shared_query(shared_win, 0, windowsize, disp_unit, baseptr, ierr)
  end if

  if ( present(dimreal1d) ) then
     call c_f_pointer(baseptr, sharereal1d, dimreal1d); sharereal1d = 0d0
  else if ( present(dimreal2d) ) then
     call c_f_pointer(baseptr, sharereal2d, dimreal2d); sharereal2d = 0d0
  else if ( present(dimreal3d) ) then
     call c_f_pointer(baseptr, sharereal3d, dimreal3d); sharereal3d = 0d0
  else if ( present(dimint1d) ) then
     call c_f_pointer(baseptr, shareint1d, dimint1d); shareint1d = 0
  else if ( present(dimint2d) ) then
     call c_f_pointer(baseptr, shareint2d, dimint2d); shareint2d = 0
  else if ( present(dimint3d) ) then
     call c_f_pointer(baseptr, shareint3d, dimint3d); shareint3d = 0
!  else if ( present(dimstr1d) ) then
!     call c_f_pointer(baseptr, sharestr1d, dimstr1d); sharestr1d = ""
!  else if ( present(dimstr2d) ) then
!     call c_f_pointer(baseptr, sharestr2d, dimstr2d); sharestr2d = ""
!  else if ( present(dimstr3d) ) then
!     call c_f_pointer(baseptr, sharestr3d, dimstr3d); sharestr3d = ""
  end if
end subroutine

! https://gcc.gnu.org/onlinedocs/gcc-4.2.1/gfortran/RANDOM_005fSEED.html
subroutine deeppub_random_init(iseed)
  implicit none
  integer,intent(in) :: iseed
  integer :: i,randsize,clock
  integer,dimension(:),allocatable :: randseed
  real*8 :: tprand

  call random_seed(size=randsize); allocate(randseed(randsize))
  if ( iseed < 0 ) then
     call system_clock(count=clock)
     randseed = clock + abs(iseed)  + 37 * (/ (i - 1, i = 1, randsize) /)
     call random_seed(put=randseed)
  else
     do i=1,randsize; randseed(i) = (iseed+1)*i; end do
     call random_seed(put=randseed)
  end if
  do i=1,200
     call random_number(tprand)
  end do
end subroutine

! code from http://goodluck1982.blog.sohu.com/113355265.html
subroutine deeppub_time_from_1970(msec)
  implicit none
  real*8 :: msec
  integer ::timevec(8)
  integer,parameter :: inityear=1970
  integer :: monthdays(12)
  integer :: i,j,nleapyear
  data monthdays /31,28,31,30,31,30,31,31,30,31,30,31/
  call date_and_time(values=timevec)
  !timevec(1):year(xxxx)    !timevec(2):month(1~12)   !timevec(3):date(1~31)              !timevec(5):hour(0~23)
  !timevec(6):miniute(0~59) !timevec(7):second(0~59)  !timevec(4):timezone(unit:miniute)  !timevec(8):millisecond(0~999)
  nleapyear=0
  do i=inityear,timevec(1)-1
     if( isleapyear(i)) nleapyear=nleapyear+1
  enddo
  if(isleapyear(timevec(1))) then
    monthdays(2)=29
  else
    monthdays(2)=28
  endif
  msec = ((timevec(1)-inityear)*365 + nleapyear + sum(monthdays(1:timevec(2)-1)) + timevec(3) - 1 )*24*3.6d3 - timevec(4)*60
  msec = msec + timevec(5)*3.6d3 + timevec(6)*60 + timevec(7)
  msec = msec*1000d0 + timevec(8)
contains
function isleapyear(year)
  logical::isleapyear
  integer::year
  if( mod(year,4)/=0) then
     isleapyear=.false.
  else if(mod(year,100)/=0) then
     isleapyear=.true.
  else if(mod(year,400)==0) then
     isleapyear=.true.
  else
     isleapyear=.false.
  endif
end function
end subroutine

subroutine deeppub_expandinput_by_rotation(tpinput,tpoutput,tpingrad,tpoutgrad)
   real*8,intent(in) :: tpinput(:)
   real*8,intent(out) :: tpoutput(:,:)
   real*8,intent(in),optional :: tpingrad(:)
   real*8,intent(out),optional :: tpoutgrad(:,:)
   integer :: i,j,k,tpnatom,imat
   real*8 :: incoor(3, size(tpinput)/3), rot_angle, tpvec(3)
   real*8 :: mat_rx(3,3), ccenter(3), mat_24(3,3,24), tpmat(3,3)

   if ( mod(size(tpinput),3) /= 0 .or. size(tpoutput,2) /= 24 ) then
      print *,"input size error!"; stop
   end if

   tpnatom = size(tpinput)/3; incoor(:,:) = reshape(tpinput,[3,tpnatom])
   ccenter = (minval(incoor,dim=2)+maxval(incoor,dim=2))/2d0

   imat = 0
   do i = 1, 6
      select case (i)
         case (1)
            tpmat = axis_rotation('y', 0.0d0)
         case (2)
            tpmat = axis_rotation('y', 90.0d0)
         case (3)
            tpmat = axis_rotation('y', 180.0d0)
         case (4)
            tpmat = axis_rotation('y', 270.0d0)
         case (5)
            tpmat = axis_rotation('z', 90.0d0)
         case (6)
            tpmat = axis_rotation('z', -90.0d0)
      end select
      do j = 1, 4
         rot_angle = 90d0*dble(j-1)
         mat_rx = axis_rotation('x', rot_angle)
         tpmat = matmul(mat_rx, tpmat)
         imat = imat + 1

         do k = 1, tpnatom
            tpoutput(3*k-2:3*k,imat) = matmul(tpmat, incoor(:,k) - ccenter)
         end do

         if ( present(tpingrad) ) then
            do k = 1, tpnatom
               tpoutgrad(3*k-2:3*k,imat) = matmul(tpmat, tpingrad)
            end do
         end if

      end do
   end do

   if ( imat /= 24 ) stop "imat error!"

contains

   ! https://zhuanlan.zhihu.com/p/183973440
   function axis_rotation(axis, angle) result(mat_r)
      character(len=*), intent(in) :: axis
      real*8, intent(in) :: angle
      real*8 :: mat_r(3, 3), cos_beta, sin_beta

      cos_beta = cosd(angle); sin_beta = sind(angle)
      select case(trim(axis))
         case('x')
            mat_r = reshape([1d0,0d0,0d0, 0d0,cos_beta,sin_beta, 0d0,-sin_beta,cos_beta],[3,3])
         case('y')
            mat_r = reshape([cos_beta,0d0,-sin_beta, 0d0,1d0,0d0, sin_beta,0d0,cos_beta],[3,3])
         case('z')
            mat_r = reshape([cos_beta,sin_beta,0d0, -sin_beta,cos_beta,0d0, 0d0,0d0,1d0],[3,3])
         case default
            stop 'error case'
      end select

   end function axis_rotation

end subroutine 

subroutine deeppub_uniformdata_2d(uniform, minval, maxval)
   real*8 :: uniform(:,:), minval, maxval
   real*8 :: u1
   integer :: i, j

   do i = 1, size(uniform, 1)
      do j = 1, size(uniform, 2)
         call random_number(u1)
         uniform(i, j) = u1*(maxval - minval) + minval
      end do
   end do
end subroutine

! Box-Muller algorithm
subroutine deeppub_normaldata_2d(normal, mean, sigma)
   real*8 :: normal(:,:), mean, sigma
   real*8 :: u1, u2, pi
   integer :: i, j

   pi = acos(-1d0)
   do i = 1, size(normal, 1)
      do j = 1, size(normal, 2)
         call random_number(u1); call random_number(u2)
         normal(i, j) = sqrt(-2.0d0*log(u1))*cos(2.0d0*pi*u2)
         ! normal(i, j) = sqrt(-2.0d0*log(u1))*sin(2.0d0*pi*u2)
         normal(i, j) = normal(i, j)*sigma
         normal(i, j) = normal(i, j) + mean
      end do
   end do
end subroutine

! Box-Muller algorithm
subroutine deeppub_normaldata_4d(normal, mean, sigma)
   real*8 :: normal(:,:,:,:), mean, sigma
   real*8 :: u1, u2, pi, tpvalue
   integer :: i, j, k, l

   pi = acos(-1d0)
   do i = 1, size(normal, 1)
      do j = 1, size(normal, 2)
         do k = 1, size(normal, 3)
            do l = 1, size(normal,4)
               call random_number(u1); call random_number(u2)
               tpvalue = sqrt(-2.0d0*log(u1))*cos(2.0d0*pi*u2)
               tpvalue = tpvalue*sigma
               normal(i, j, k, l) = tpvalue + mean
            end do
         end do
      end do
   end do
end subroutine

subroutine deeppub_normaldata_1d(normal, mean, sigma)
   real*8 :: normal(:), mean, sigma
   real*8 :: u1, u2, pi
   integer :: i
   pi = acos(-1d0)
   do i = 1, size(normal, 1)
      call random_number(u1); call random_number(u2)
      normal(i) = sqrt(-2.0d0*log(u1))*cos(2.0d0*pi*u2)
      normal(i) = normal(i)*sigma
      normal(i) = normal(i) + mean
   end do
end subroutine

subroutine deeppub_ncclAllReduce_vector(tparray_d, tpnum)
  real(kind=SD),intent(inout),device :: tparray_d(:)
  integer,intent(in) :: tpnum
  integer :: ierr
  if ( SD == SP ) then
     deepncclstat = ncclAllReduce(tparray_d,tparray_d,tpnum,ncclFloat,ncclSum,deepncclcomm,deepncclstream)    
  else if ( SD == DP ) then
     deepncclstat = ncclAllReduce(tparray_d,tparray_d,tpnum,ncclDouble,ncclSum,deepncclcomm,deepncclstream)  
  end if
  ierr = cudaStreamSynchronize(deepncclstream)
end subroutine

subroutine deeppub_ncclAllReduce_scalar(tpvalue_d)
  real(kind=SD),intent(inout),device :: tpvalue_d
  integer :: ierr
  if ( SD == SP ) then
     deepncclstat = ncclAllReduce(tpvalue_d,tpvalue_d,1,ncclFloat,ncclSum,deepncclcomm,deepncclstream)
  else if ( SD == DP ) then
     deepncclstat = ncclAllReduce(tpvalue_d,tpvalue_d,1,ncclDouble,ncclSum,deepncclcomm,deepncclstream)
  end if
  ierr = cudaStreamSynchronize(deepncclstream)
end subroutine

attributes(global) subroutine deeppub_transpose_matrix(tpnrow,tpncol,tpinput,tpoutput)
  integer,intent(in),value :: tpnrow,tpncol
  real(kind=SD) :: tpinput(:),tpoutput(:)
  integer :: istate,icol

  istate = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( istate > (tpnrow*tpncol) ) return

  icol = (istate-1)/tpnrow + 1
  tpoutput( (istate - (icol-1)*tpnrow-1)*tpncol + icol ) = tpinput(istate)
end subroutine

attributes(global) subroutine deeppub_transpose_add_matrix(tpnrow,tpncol,tpinput,tpoutput)
  integer,intent(in),value :: tpnrow,tpncol
  real(kind=SD) :: tpinput(:),tpoutput(:)
  integer :: istate,icol

  istate = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( istate > (tpnrow*tpncol) ) return

  icol = (istate-1)/tpnrow + 1
  icol = (istate - (icol-1)*tpnrow-1)*tpncol + icol
  tpoutput(icol) = tpoutput(icol) + tpinput(istate)
end subroutine

attributes(global) subroutine deeppub_copy_matrix(tpinput,tpoutput)
  real(kind=SD) :: tpinput(:),tpoutput(:)
  integer :: istate

  istate = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( istate > size(tpinput) ) return
  tpoutput(istate) = tpinput(istate)
end subroutine

attributes(global) subroutine deeppub_add_matrix(tpinput,tpoutput)
  real(kind=SD) :: tpinput(:),tpoutput(:)
  integer :: istate

  istate = (blockidx%x-1)*blockdim%x + threadidx%x
  if ( istate > size(tpinput) ) return
  tpoutput(istate) = tpoutput(istate) + tpinput(istate) 
end subroutine

!========================= Other Subroutines ====================================

subroutine deeppub_matmul_outer_product(outmat,vec1,vec2)
  real*8,dimension(:,:) :: outmat
  real*8,dimension(:) :: vec1,vec2
  integer i,j
  do i=1,size(outmat,1)
    do j=1,size(outmat,2)
       outmat(i,j) = outmat(i,j) + vec1(i)*vec2(j)
    end do
  end do
end subroutine

subroutine deeppub_activation_softmax(x,y)
  real*8,dimension(:),intent(in) :: x
  real*8,dimension(:),intent(out) :: y
  real*8 :: tpsum
  y = exp(x); tpsum = sum(y); y = y/tpsum
end subroutine

subroutine deeppub_activation_function(x,y,dy)
  real*8,dimension(:),intent(in) :: x
  real*8,dimension(:),intent(out) :: y
  real*8,dimension(:),intent(out),optional :: dy
  integer :: i
  select case(activefunctype)
    case (SIGM)
       y = 1d0/(1d0+exp(-x)); if ( present(dy) ) dy = y*(1d0-y)
    case (TANH)
       y = 1d0 - 2d0/(1d0+exp(2d0*x)); if ( present(dy) ) dy = 1d0 - y*y
    case (RELU)
       !y = 0.5d0*(x+abs(x)); if ( present(dy) ) dy = abs(x>0)
       y = 0.5d0*(x+abs(x))
       if ( present(dy) ) then
          dy = 0d0
          do i = 1, size(x)
             if ( x(i) > 0d0 ) dy(i) = 1d0
          end do
       end if
    case (LEAKYRELU) ! Leaky ReLU
       y = 0.01d0*x;
       do i = 1, size(x)
          if (x(i) > 0d0) y(i) = x(i)
       end do
       if ( present(dy) ) then
          dy = 0.01d0
          do i = 1, size(x)
             if (x(i) > 0d0) dy(i) = 1d0
          end do
       end if
    case (SELU) ! Scaled Exponential Linear Unit, see https://iq.opengenus.org/scaled-exponential-linear-unit/
       y = 1.050700987d0*1.673263242d0*(exp(x) - 1d0)
       do i = 1, size(x)
          if ( x(i) > 0d0 ) y(i) = 1.050700987d0*x(i) 
       end do
       if ( present(dy) ) then
          dy = y + 1.050700987d0*1.673263242d0
          do i = 1, size(x)
             if (x(i) > 0d0) dy(i) = 1.050700987d0
          end do
       end if
    case (ARCTAN) ! Tan-1(x)
       y = atan(x)
       if ( present(dy) ) dy = 1d0/(x*x + 1d0)
    case (SYMSIGM) ! Symmetrical Sigmoid
       y = 1d0 - 2d0/(1d0+exp(x))
       if ( present(dy) ) dy = 0.5d0*(1d0-y*y)
    case (LOGLOG)
       y = 1d0 - exp(-exp(x))
       if ( present(dy) ) dy = exp(x - exp(x))
    case (GAUSSIAN)
       y = exp(-x*x)
       if ( present(dy) ) dy = -2d0*x*y
    case (SILU)
       y = 1d0/(1d0+exp(-x))
       if ( present(dy) ) dy = y + x*y*(1d0-y)
       y = x*y
    case default
       stop "Invalid activation function!"
  end select
end subroutine

subroutine deeppub_activation_function3d(x,dx)
  real*8,dimension(:,:,:),intent(inout) :: x
  real*8,dimension(:,:,:),intent(out),optional :: dx
  integer :: i,j,k

  select case(activefunctype)
    case (SIGM)
       x = 1d0/(1d0+exp(-x)); if ( present(dx) ) dx = x*(1d0-x)
    case (TANH)
       x = 1d0 - 2d0/(1d0+exp(2d0*x)); if ( present(dx) ) dx = 1d0 - x*x
    case (RELU)
       !x = 0.5d0*(x+abs(x)); if ( present(dx) ) dx = abs(x>0)
       x = 0.5d0*(x+abs(x))
       if ( present(dx) ) then
          dx = 0d0
          do k = 1, size(x,3)
             do i = 1, size(x,1)
                do j = 1, size(x,2)
                   if ( x(i,j,k) > 0d0 ) dx(i,j,k) = 1d0
                end do
             end do
          end do
       end if
    case (LEAKYRELU) ! Leaky ReLU
       do k = 1, size(x,3)
          do i = 1, size(x,1)
             do j = 1, size(x,2)
                if (x(i,j,k) <= 0d0) x(i,j,k) = 0.01d0*x(i,j,k)
             end do
          end do
       end do
       if (present(dx)) then
          dx = 0.01d0
          do k = 1, size(x,3)
             do i = 1, size(x,1)
                do j = 1, size(x,2)
                   if (x(i,j,k) > 0d0) dx(i,j,k) = 1d0
                end do
             end do
          end do
       end if
    case default
       stop "Invalid activation function!"
  end select
end subroutine

attributes(device) subroutine deeppub_activation_function_cuda(x,y,dy)
  real(kind=SD),intent(in) :: x
  real(kind=SD),intent(out) :: y
  real(kind=SD),intent(out),optional :: dy
  select case(activefunctype_d)
    case (SIGM)
       y = 1_SD/(1_SD+exp(-x)); if ( present(dy) ) dy = y*(1_SD-y)
    case (TANH)
       y = 1_SD - 2_SD/(1_SD+exp(2_SD*x)); if ( present(dy) ) dy = 1_SD - y*y
    case (RELU)
       y = 0.5_SD*(x+abs(x)); if ( present(dy) ) dy = abs(x>0.0_SD)
    case (LEAKYRELU) ! Leaky ReLU
       y = 0.01_SD*x
       if (x > 0_SD) y = x
       if ( present(dy) ) then
          dy = 0.01_SD
          if (x > 0_SD) dy = 1_SD
       end if
    case (SELU)
       y = 1.75809933988_SD*(exp(x) - 1_SD)
       if ( x > 0_SD ) y = 1.050700987_SD*x
       if ( present(dy) ) then
          dy = y + 1.75809933988_SD
          if (x > 0_SD ) dy = 1.050700987_SD
       end if
    case (ARCTAN) ! Tan-1(x)
       y = atan(x)
       if ( present(dy) ) dy = 1_SD/(x*x + 1_SD)
    case (SYMSIGM) ! Symmetrical Sigmoid
       y = 1_SD - 2_SD/(1_SD+exp(x))
       if ( present(dy) ) dy = 0.5_SD*(1_SD-y*y)
    case (LOGLOG)
       y = 1_SD - exp(-exp(x))
       if ( present(dy) ) dy = exp(x - exp(x))
    case (GAUSSIAN)
       y = exp(-x*x)
       if ( present(dy) ) dy = -2_SD*x*y
    case (SILU)
       y = 1_SD/(1_SD+exp(-x))
       if ( present(dy) ) dy = y + x*y*(1_SD-y)
       y = x*y
  end select
end subroutine

subroutine deeppub_set_activefunction_and_lossfunction()
  select case(trim(activation))
    case ('sigm'); activefunctype = SIGM
    case ('tanh'); activefunctype = TANH
    case ('relu'); activefunctype = RELU
    case ('leakyrelu'); activefunctype = LEAKYRELU
    case ('selu'); activefunctype = SELU
    case ('arctan'); activefunctype = ARCTAN
    case ('symsigm'); activefunctype =  SYMSIGM
    case ('loglog'); activefunctype = LOGLOG
    case ('gaussian'); activefunctype = GAUSSIAN
    case ('silu'); activefunctype = SILU
    case default
       stop "Invalid activation function!"
  end select

  select case(trim(lossfunction))
    case ('rmse'); lossfunctype = RMSE
    case ('mae'); lossfunctype = MAE
    case default; stop "Invalid loss function!"
  end select
end subroutine

subroutine deeppub_print_time(iofile,cputime,tpepoch,timepercent)
  implicit none
  integer,intent(in) :: iofile
  real*8,intent(in) :: cputime      ! milliseconds
  integer,intent(in) :: tpepoch     ! iepoch
  real*8,intent(in) :: timepercent
  integer :: nday,nhour,nminute,nsecond,nmillisec
  real*8  :: realdays,remainingtime

  realdays = (0.001d0*cputime)/dble(3600*24)
  write(iofile,"(a22,i8,a17,f12.3,a)")    "      Trained Epochs : ",tpepoch," epochs, Speed : ",dble(tpepoch)/realdays," epochs/day"

  nsecond=int(cputime*0.001d0); nmillisec=cputime-nsecond
  nhour=nsecond/3600; nday=nhour/24; nhour=mod(nhour,24)
  nsecond=mod(nsecond,3600); nminute=nsecond/60; nsecond=mod(nsecond,60)

  write(iofile,"(a22,i8,a,i4,a,i4,a,i4,a)") "        Elapsed Time : ",nday," day",nhour," hour", &
             nminute," min",nsecond," sec" ! ,nmillisec," msec"

  remainingtime = cputime*(1d0 - timepercent)/timepercent
  nsecond=int(remainingtime*0.001d0); nmillisec=remainingtime-nsecond
  nhour=nsecond/3600; nday=nhour/24; nhour=mod(nhour,24)
  nsecond=mod(nsecond,3600); nminute=nsecond/60; nsecond=mod(nsecond,60)

  write(iofile,"(a22,i8,a,i4,a,i4,a,i4,a)") "      Remaining Time : ",nday," day",nhour," hour", &
             nminute," min",nsecond," sec" ! ,nmillisec," msec"
end subroutine

subroutine deeppub_loss_function(tptrueoutputs,tpoutputs,tptotloss,tperrormark)
  real*8,intent(in) :: tptrueoutputs(:,:),tpoutputs(:,:)
  real*8,intent(inout) :: tptotloss
  integer,intent(in),optional :: tperrormark(:)
  integer :: idata,tpbatchsize
  real*8 :: tploss

  tpbatchsize = size(tptrueoutputs,2)
  do idata = 1, tpbatchsize
     if ( present(tperrormark) ) then
        if ( tperrormark(idata) == 1 ) cycle
     end if
     select case (lossfunctype)
       case (RMSE); tploss = sum((tptrueoutputs(:,idata) - tpoutputs(:,idata))**2)
       case (MAE);  tploss = sum(abs(tptrueoutputs(:,idata) - tpoutputs(:,idata)))
     end select
     tptotloss = tptotloss + tploss
  end do
end subroutine

subroutine deeppub_loss_function_end(tpndata,tploss)
  real*8,intent(inout) :: tploss
  integer,intent(in) :: tpndata
  select case(lossfunctype)
    case (RMSE)
       tploss = sqrt(tploss/dble(tpndata))
    case (MAE)
       tploss = tploss/dble(tpndata)
  end select
end subroutine

subroutine deeppub_loss_function_grad(tptruegrads,tpinputs,tptotloss,tperrormark)
  real*8,intent(in) :: tptruegrads(:,:)
  real*8,intent(in) :: tpinputs(:,:)
  real*8,intent(inout) :: tptotloss
  integer,intent(in),optional :: tperrormark(:)
  integer :: idata,tpbatchsize,tpngradcv
  real*8 :: tploss

  tpbatchsize = size(tpinputs,2); tpngradcv = size(tpinputs,1)
  do idata = 1, tpbatchsize
     if ( present(tperrormark) ) then
        if ( tperrormark(idata) == 1 ) cycle
     end if

     select case (lossfunctype)
       case (RMSE); tploss = sum((tptruegrads(1:tpngradcv,idata) - tpinputs(1:tpngradcv,idata))**2)
       case (MAE);  tploss = sum(abs(tptruegrads(1:tpngradcv,idata) - tpinputs(1:tpngradcv,idata)))
     end select
     tptotloss = tptotloss + tploss
  end do
end subroutine

end module
