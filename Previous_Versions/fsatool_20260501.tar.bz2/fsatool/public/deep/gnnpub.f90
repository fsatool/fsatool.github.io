module gnnpub
   use deeppub; use mlp0

implicit none

   type(mlptype) :: gnetmain(4),gnetatomemb, gnetedgeemb, gnetforce
   type(mlptype) :: gnetupdate(2,2), gnetvecoutput(2)

   integer :: nattention 
   type(mlptype),dimension(:),allocatable :: gnetnodequery, gnetnodekey,  gnetnodevalue, gnetedgekey, &
                  gnetedgevalue, gnetsproj, gnetvecproj, gnetfproj, gnetwsrcproj, gnetwtrgproj, gnetoproj
   type(mlptype),dimension(:),allocatable :: networklist

   integer :: nsnap,ignncudagroup,maxbatchsnapnedge=0
! ============================ change 20260403 =============================
   logical :: ifdoubleedge,iftrainforce,ifavgene,ifbuildedgeatruntime,use_torch
! ============================ change 20260403 =============================

   integer,parameter :: maxatomtype=100, maxnmol=10, maxnatompermol=1000
   real,parameter :: pi=3.141592653589793d0
   integer :: allbatchnatom, nmol,net_for_checking, gnnmode, atomembeddinglength, edgeembeddinglength,nedge,headnum,headsize
   real*8 :: edgediscut,forceweight,totenergyloss,totforceloss
   character*20,private,dimension(:),allocatable :: molnames
   integer,dimension(:),pointer :: snapedgeindex,snapedgenums,molatomtypes,snapatomdegrees,molatomindex,molatomnums,molsnapnums,snap2mol,snapatomindex
   integer,dimension(:,:),pointer :: snapedges
   character*3,private,dimension(:),allocatable :: molatomnames

   real*8,dimension(:),pointer :: snapenergies,molavgene
   real*8,dimension(:,:),pointer :: snapatomcoors,snapatomforces 
   real*8,dimension(:,:),allocatable :: batchrefsnapatomforces

   ! batch data
   integer :: batchsnapnatom,batchsnapnedge,batchsnapnmol
   integer,dimension(:),allocatable :: batchsnap2mol,batchsnapatomindex,batchsnapedgeindex,batchatomdegree
   integer,dimension(:,:),allocatable :: batchsnapedges
   real*8,dimension(:),allocatable :: batchrefsnapenergies,batchsnapenergies,batchedgedisdecays,batchatomenergies
   real*8,allocatable :: batchedgedistance(:)
   integer,allocatable:: batchatomtype(:)

   contains

   subroutine gnnpub_initialize(parmfile,ifok)
      character(len=*),intent(in) :: parmfile
      logical,intent(out) :: ifok
      integer :: iwin,iofile,ierr,imol,totparms,iatt,i
      character*15 :: tpmolnames(maxnatompermol)
! ============================ change 20260403 =============================
      namelist / gnn / batchsize, dropout, learnrate, minlearnrate, learnratedecay, learnratewarmsteps, learnratepatientsteps, &
           ifuselayernorm, lossfunction, ioptmethod, l1normfactor, nepoch, batchsize, activation, deepiseed, &
           networkfile, nattention, molnames, gnnmode, net_for_checking, edgediscut, atomembeddinglength,    &
           edgeembeddinglength, headnum, forceweight, ifdoubleedge, iftrainforce, ifavgene, ifsaveminlossnetwork, &
           ifproceed, ifbuildedgeatruntime, use_torch
      use_torch = .false.
! ============================ change 20260403 =============================
      nsnap = 0; nedge = 0; headnum = 0; iftrainforce = .false.; forceweight = 0d0; totenergyloss = 0d0; totforceloss = 0d0
      ifdoubleedge = .false.; ifavgene = .false.; nattention = 4
      learnrate = 0.001d0; maxlearnrate = learnrate; minlearnrate = 1d-7; learnratedecay = 0.8d0; learnratewarmsteps = 0; learnratepatientsteps = 0; ifuselayernorm = .false.
      lossfunction = "rmse"; ioptmethod = 2; l1normfactor = 2d0; activation = "silu"; deepiseed = 0; networkfile = "network.txt"
      dropout = 0d0; batchsize = 1; netnum = 1; bptt_trun = 1; ifproceed = .false.
      ifsaveminlossnetwork = .false.; maxnsteps = 1; ifbuildedgeatruntime = .true.; ifok = .true.

      allocate(molnames(maxnmol)); molnames = ""
      open(newunit=iofile, file=parmfile, action="read")
      read(iofile, nml=gnn, iostat=ierr); close(iofile)
      if ( ierr /= 0 ) then
          ifok=.false.; return
      end if
      nmol = 0
      do imol = 1, maxnmol
         if ( molnames(imol) == "" ) exit
         nmol = nmol + 1; tpmolnames(nmol) = molnames(nmol)
      end do
      deallocate(molnames); allocate(molnames(nmol)); molnames(1:nmol) = tpmolnames(1:nmol)
      call deeppub_MPISharedMemoryAllocate(iwin, dimreal1d=[nmol], sharereal1d=molavgene)

      if ( jobtype == PREDICT .or. jobtype == CHECK .or. (ifproceed .eqv. .true.) .or. jobtype == MD ) then
         call gnnpub_network_loadparm()
      end if

      call deeppub_set_activefunction_and_lossfunction()

      if ( l1normfactor > 0.0d0 .and. l2normfactor > 0.0d0 ) stop "l1normfactor and l2normfactor can not be positive simultaneously!"

      ignncudagroup = icudagroup; maxlearnrate = learnrate
      if ( icudagroup > 0 ) then

         if ( mod(batchsize, ignncudagroup*deepprocnum) /= 0 ) then
            print *,"mod(batchsize, ignncudagroup*deepprocnum) must be 0!"; stop
         end if
         learnrate_d = learnrate; dropout_d = dropout
         ioptmethod_d = ioptmethod; l1normfactor_d = l1normfactor; l2normfactor_d = l2normfactor
         lossfunctype_d = lossfunctype; activefunctype_d = activefunctype
         icudagroup_d = icudagroup; netnum_d = netnum; maxnsteps_d = maxnsteps
         batchsize_d = batchsize; maxnsteps_d = maxnsteps
      end if
      if ( deepiseed /= 0 ) call deeppub_random_init(deepiseed)
      if ( forceweight < 0d0 .or. forceweight > 1d0 ) stop "forceweight shall be in the range of 0 to 1"
      if ( forceweight > 0d0 ) iftrainforce = .true.
      if ( mod(atomembeddinglength,headnum) /= 0 ) stop "atomembeddinglength must be an integral multiple of headnum!"
      headsize = atomembeddinglength/headnum
      call gnnpub_read_atom_coors()
      call gnnpub_build_atom_edges()
      totparms = 0

      allocate(gnetnodequery(nattention), gnetnodekey(nattention), gnetnodevalue(nattention), &
               gnetedgekey(nattention), gnetedgevalue(nattention), gnetsproj(nattention),  &
               gnetvecproj(nattention),gnetoproj(nattention))
      if (nattention > 1) then
         allocate(gnetfproj(nattention-1), gnetwsrcproj(nattention-1), gnetwtrgproj(nattention-1))
      end if

      call mlp0_initialize(gnetmain(1),[edgeembeddinglength, atomembeddinglength],totparms,tpifbias=.true.)
      call mlp0_initialize(gnetmain(2), [2*atomembeddinglength, atomembeddinglength], totparms, tpifbias=.true.)
      call mlp0_initialize(gnetmain(3), [atomembeddinglength,atomembeddinglength/2,1], totparms, tpifbias=.true.)
      call mlp0_initialize(gnetmain(4),[edgeembeddinglength, atomembeddinglength],totparms,tpifbias=.true.)
      call mlp0_initialize(gnetatomemb,[maxatomtype, atomembeddinglength*2],totparms,tpifbias=.false.,tpifembedding=.true.)

      call mlp0_initialize(gnetedgeemb,[1, edgeembeddinglength*2],totparms,tpifbias=.false.)

      ! set mean and beta
      do i=1,edgeembeddinglength
         call mlp0_setweight(gnetedgeemb,2,i,1,exp(-edgediscut)+dble(i-1)*(1d0-exp(-edgediscut))/dble(edgeembeddinglength-1))
         call mlp0_setweight(gnetedgeemb,2,edgeembeddinglength+i,1,(1d0-exp(-edgediscut))**2/(4d0*dble(edgeembeddinglength-1)**3))
      end do
   
      call mlp0_initialize(gnetupdate(1,1), [atomembeddinglength*2,atomembeddinglength,atomembeddinglength/2], totparms, tpifbias=.true.,tpiflastactivation=.true.)
      call mlp0_initialize(gnetupdate(1,2), [atomembeddinglength*2,atomembeddinglength,atomembeddinglength/2], totparms, tpifbias=.true.)
      call mlp0_initialize(gnetupdate(2,1), [atomembeddinglength,atomembeddinglength/2,1], totparms, tpifbias=.true.)
      call mlp0_initialize(gnetupdate(2,2), [atomembeddinglength,atomembeddinglength/2,1], totparms, tpifbias=.true.)
      call mlp0_initialize(gnetvecoutput(1), [atomembeddinglength,atomembeddinglength+atomembeddinglength/2], totparms, tpifbias=.false.)
      call mlp0_initialize(gnetvecoutput(2), [atomembeddinglength/2,atomembeddinglength/2+1], totparms, tpifbias=.false.)
 
      do iatt = 1, nattention
         call mlp0_initialize(gnetnodequery(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpiflayernorm=ifuselayernorm)
         call mlp0_initialize(gnetnodekey(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpiflayernorm=ifuselayernorm)
         call mlp0_initialize(gnetnodevalue(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpiflayernorm=ifuselayernorm)

         call mlp0_initialize(gnetedgekey(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpiflastactivation=.true.)
         call mlp0_initialize(gnetedgevalue(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpiflastactivation=.true.)
    
         call mlp0_initialize(gnetsproj(iatt), [atomembeddinglength,atomembeddinglength*2],totparms,tpiflastactivation=.true.)
         call mlp0_initialize(gnetvecproj(iatt), [atomembeddinglength,atomembeddinglength*3],totparms,tpifbias=.false.)
         if (iatt /= nattention) then
            call mlp0_initialize(gnetfproj(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpiflastactivation=.true.)
            call mlp0_initialize(gnetwsrcproj(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpifbias=.false.)
            call mlp0_initialize(gnetwtrgproj(iatt), [atomembeddinglength,atomembeddinglength],totparms,tpifbias=.false.)
         end if
         call mlp0_initialize(gnetoproj(iatt), [atomembeddinglength,atomembeddinglength*3],totparms)
      end do
      allocate(networklist(12+11*nattention-3))
      networklist(1:12) = [gnetmain(1), gnetmain(2), gnetmain(3), gnetmain(4), gnetatomemb, gnetedgeemb, gnetupdate(1,1), gnetupdate(1,2), gnetupdate(2,1), gnetupdate(2,2), gnetvecoutput(1), gnetvecoutput(2)]

      do iatt = 1, nattention
         if (iatt /= nattention) then
!            networklist(6+iatt*11-10:6+iatt*11) = &
            networklist(12+iatt*11-10:12+iatt*11) = &
               [gnetnodequery(iatt), gnetnodekey(iatt), gnetnodevalue(iatt), gnetedgekey(iatt), gnetedgevalue(iatt), &
               gnetsproj(iatt), gnetvecproj(iatt), gnetfproj(iatt), gnetwsrcproj(iatt), gnetwtrgproj(iatt), gnetoproj(iatt)]
         else
!            networklist(6+iatt*11-10:6+iatt*11-3) = &
            networklist(12+iatt*11-10:12+iatt*11-3) = &
               [gnetnodequery(iatt), gnetnodekey(iatt), gnetnodevalue(iatt), gnetedgekey(iatt), gnetedgevalue(iatt), &
               gnetsproj(iatt), gnetvecproj(iatt), gnetoproj(iatt)]
         end if
      end do
      call mlp0_network_prepare(networklist)
      deepntotdata = nsnap; batchnum = (nsnap - 1)/batchsize + 1

      if ( deepprocid > 0 ) return

      print "(/, a,)",    "============ GNN Information ==========="
      print *
      print "(a,i16)",    "      Total snapshots : ",nsnap
      print "(a,i16)",    "           Batch Size : ",batchsize
      print "(a,i16)",    "    Number of Batches : ",batchnum

      print "(a,i16)",    "     Number of Epochs : ",nepoch
      print "(a,a16)",    "  Activation Function : ",trim(activation)
      print "(a,a16)",    "   Loss Function Type : ",trim(lossfunction)
      print "(a,f16.5)",  "        Learning Rate : ",learnrate
      print "(a,a16)",    "         Network File : ",trim(networkfile)
      if ( ioptmethod == 1 ) then
         print "(a,a16)",    "    Network Optimizer : ","       SDP"
      else if ( ioptmethod == 2 ) then
         print "(a,a16)",    "    Network Optimizer : ","      ADAM"
      else
         stop "Invalid netowrk optimizer!"
      end if
      print "(a,2f16.5)",   "L1 and L2 Norm factor : ",l1normfactor,l2normfactor
      print "(a,f16.5)",    "  Dropout Probability : ",dropout

      print "(a,i16)",   "             GNN mode : ",gnnmode
      print "(a,i16)",   "Atom Embedding Length : ",atomembeddinglength
      print "(a,i16)",   "Edge Embedding Length : ",edgeembeddinglength

      print "(a,f16.3)", " Edge Distance Cutoff : ",edgediscut
      print "(a,i16)",   "     Total Parameters : ",totparms

      print "(a,i16)",   "Multi-Attention Heads : ",headnum
      print "(a,f16.3)", "    Atom Force Weight : ",forceweight
   end subroutine

   subroutine gnnpub_read_atom_coors()
      integer :: iwin,tpindex,i,j,iofile,ierr,imol,iatom,isnap,tpatomtypes(maxnatompermol)
      real*8 :: tpavg,tpatomcoor(3,maxnatompermol),tpatomforce(3,maxnatompermol),tppot
      character*15 :: tpatomnames(maxnatompermol)
      character*150 :: tpline

!real*8 :: rotmat(3,3),tpvec(3),theta
!theta = 0.5d0
!rotmat(1,1:3) = [cos(theta), sin(theta), 0d0]
!rotmat(2,1:3) = [-sin(theta), cos(theta), 0d0]
!rotmat(3,1:3) = [0d0, 0d0, 1d0]

      if ( atomembeddinglength == 0 ) stop "atombeddeinglength must be positive!"

      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=(/nmol/), shareint1d=molsnapnums)
      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=(/nmol/), shareint1d=molatomnums)
      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=(/nmol+1/), shareint1d=molatomindex)

      if ( deepprocid == 0 ) then
         nsnap = 0
         do imol = 1, nmol
            open(newunit=iofile, file=trim(molnames(imol))//".pdb", action="read")
            iatom = 0
            do
               read(iofile,"(a150)",iostat=ierr) tpline
               if ( ierr /= 0 ) exit
               if ( trim(tpline) == "END" ) exit
               iatom = iatom + 1; if ( iatom > maxnatompermol ) stop "maxnatompermol is too small!"
            end do
            close(iofile)
            molatomnums(imol) = iatom; molatomindex(imol+1) = molatomindex(imol)+iatom

            if ( jobtype == MD ) cycle

            open(newunit=iofile, file=trim(molnames(imol))//".deeptraj", action="read")
            isnap = 0
            do
               read(iofile,*,iostat=ierr); if ( ierr /= 0 ) exit
               isnap = isnap + 1
            end do
            close(iofile)
            molsnapnums(imol) = isnap
            nsnap = nsnap + isnap
         end do
      end if

      if ( jobtype == MD ) nsnap = 1

      call mpi_bcast(nsnap,1,mpi_integer,0, mpi_comm_world,ierr)
      allocate(molatomnames(molatomindex(nmol+1))); molatomnames = ""

      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=[molatomindex(nmol+1)], shareint1d=molatomtypes)

      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=[nsnap], shareint1d=snap2mol)

      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=[nsnap+1], shareint1d=snapatomindex)

      if ( jobtype == MD ) then
         snap2mol = 1; molsnapnums = 1; snapatomindex(nsnap+1) = molatomnums(1)
      end if

      tpindex = dot_product(molatomnums(1:nmol),molsnapnums(1:nmol))
      call deeppub_MPISharedMemoryAllocate(iwin, dimreal2d=[3,tpindex], sharereal2d=snapatomcoors)
      call deeppub_MPISharedMemoryAllocate(iwin, dimreal2d=[3,tpindex], sharereal2d=snapatomforces)
      call deeppub_MPISharedMemoryAllocate(iwin, dimreal1d=[nsnap], sharereal1d=snapenergies)

      if ( deepprocid == 0 ) then
         isnap = 0; tpindex = 0
         do imol = 1, nmol
            open(newunit=iofile, file=trim(molnames(imol))//".pdb", action="read")
            iatom = 0; tpatomtypes = 0; tpatomnames = ""
            do 
               read(iofile,"(a150)",iostat=ierr) tpline
               if ( ierr /= 0 ) exit
               if ( trim(tpline) == "END" ) exit
               iatom = iatom + 1
               read(tpline,"(13x,a3,14x,3f8.3,4x,i1)") tpatomnames(iatom),tpatomcoor(1:3,iatom),tpatomtypes(iatom)
            end do
            close(iofile)
            i = molatomindex(imol)+1; j = molatomindex(imol+1)   
            molatomnames(i:j) = tpatomnames(1:iatom)
            molatomtypes(i:j) = tpatomtypes(1:iatom)

            if ( jobtype == MD ) cycle

            tpavg = 0d0
            open(newunit=iofile, file=trim(molnames(imol))//".deeptraj", action="read")
            do
               read(iofile,*,iostat=ierr) i,i,i,i,tpatomcoor(1:3,1:molatomnums(imol)),tpatomforce(1:3,1:molatomnums(imol)),tppot
               if ( ierr /= 0 ) exit
               isnap = isnap + 1; snap2mol(isnap) = imol

!if ( isnap == 2 ) then
!do i = 1, molatomnums(imol)
!   tpvec(1) = dot_product(rotmat(1,:),tpatomcoor(:,i))
!   tpvec(2) = dot_product(rotmat(2,:),tpatomcoor(:,i))
!   tpvec(3) = dot_product(rotmat(3,:),tpatomcoor(:,i))
!   tpatomcoor(:,i) = tpvec(:)
!   tpvec(1) = dot_product(rotmat(1,:),tpatomforce(:,i))
!   tpvec(2) = dot_product(rotmat(2,:),tpatomforce(:,i))
!   tpvec(3) = dot_product(rotmat(3,:),tpatomforce(:,i))
!   tpatomforce(:,i) = tpvec(:)
!end do
!end if

               ! snapatomcoors(:,:): all coordinates of all snapshots

               snapatomcoors(1:3,tpindex+1:tpindex+molatomnums(imol)) = tpatomcoor(1:3,1:molatomnums(imol))
               if ( iftrainforce ) then
                  snapatomforces(1:3,tpindex+1:tpindex+molatomnums(imol)) = tpatomforce(1:3,1:molatomnums(imol))
               end if
               ! snapenergies(isnap): energy of isnap
               snapenergies(isnap) = tppot; tpavg = tpavg + tppot
               ! molatomnum(imol): atom number in molecule imol
               tpindex = tpindex + molatomnums(imol); snapatomindex(isnap+1) = tpindex
            end do
            close(iofile)
            if ( (ifavgene) .and. ( (jobtype == TRAIN) .and. (ifproceed .eqv. .false.)) ) molavgene(imol) = tpavg/dble(molsnapnums(imol))
         end do
      end if

      call mpi_bcast(molatomnames, molatomindex(nmol+1)*3, mpi_char, 0, mpi_comm_world, ierr)

      if ( (ifavgene) .and. ( (jobtype == TRAIN) .and. (ifproceed .eqv. .false.)) ) then
         call mpi_bcast(molavgene, nmol, mpi_double_precision, 0, mpi_comm_world, ierr)
      end if

      if ( deepprocid > 0 ) return

      do imol = 1, nmol
         ! molatomindex(imol) : atom range in imol, from i to j
         i = molatomindex(imol)+1; j = molatomindex(imol+1)
         print "(a,i4,4x,a20,a,i5,4x,a,i8)","molecule ",imol,molnames(imol)," atom number ",molatomnums(imol)," frames ",molsnapnums(imol)
         print "(a,*(a5))","atom names: ",adjustr(molatomnames(i:j))
         print "(a,*(i5))","atom types: ",molatomtypes(i:j)
      end do

      print *

      !  print "(a)","mol and atom coor"
      !  do isnap = 1, nsnap
      !     imol = snap2mol(isnap)
      !     print "(a,i5,4x,a,i5,4x,a,i5,4x,a,f18.3)","snap ",isnap,"mol ",imol, "atom number ",molatomnums(imol)," energy ",snapenergies(isnap)
      !     tpindex = snapatomindex(isnap)
      !     do iatom = 1, molatomnums(imol)
      !        print "(2i5,a,*(f8.3))",iatom,molatomtypes(iatom),molatomnames(iatom),snapatomcoors(1:3,tpindex+iatom),snapatomforces(1:3,tpindex+iatom)
      !     end do
      !  end do
   end subroutine

   subroutine gnnpub_build_atom_edges()
      integer :: iwin,tpgroupsize,isnap,ierr,imol,iatom,jatom,iedge,tpindex,istart,istop,iatompos
      real*8 :: tpvec(3),tpdissq,tpdiscutsq,tpatomcoor(3,maxnatompermol)

      if ( ignncudagroup == 0 ) then
         tpgroupsize = batchsize
      else
         tpgroupsize = ignncudagroup
      end if
      allocate(batchrefsnapenergies(tpgroupsize)); batchrefsnapenergies = 0d0
      allocate(batchsnapatomindex(tpgroupsize+1)); batchsnapatomindex = 0
      allocate(batchsnapedgeindex(tpgroupsize+1)); batchsnapedgeindex = 0
      allocate(batchsnapenergies(tpgroupsize)); batchsnapenergies = 0d0
      allocate(batchsnap2mol(tpgroupsize)); batchsnap2mol = 0

      if ( edgediscut == 0d0 ) stop "edgediscut must be positive!"
      if ( jobtype == MD ) return

      tpdiscutsq = edgediscut**2
      tpindex = dot_product(molatomnums(1:nmol),molsnapnums(1:nmol))
      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=[tpindex], shareint1d=snapatomdegrees)
      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=[nsnap], shareint1d=snapedgenums)

      if ( deepprocid == 0 ) then
         nedge = 0; snapatomdegrees = 0
         ! cycle over all snapshots
         do isnap = 1, nsnap

            if ( mod(isnap,10000) == 0 ) print "(a,i8)","building edges for snapshot ",isnap
            imol = snap2mol(isnap); iatompos = snapatomindex(isnap)
            tpatomcoor(1:3,1:molatomnums(imol)) = snapatomcoors(1:3,snapatomindex(isnap)+1:snapatomindex(isnap)+molatomnums(imol))

            tpindex = 0
            ! cycle over all atoms isnap
            do iatom = 1, molatomnums(imol)
               ! cycle over all atoms isnap
               do jatom = iatom+1, molatomnums(imol)
                  tpvec(1:3) = tpatomcoor(1:3,iatom) - tpatomcoor(1:3,jatom)
                  tpdissq = dot_product(tpvec,tpvec)
                  if ( tpdissq < tpdiscutsq ) then
                     if ( ifdoubleedge .eqv. .false. ) then
                        tpindex = tpindex + 1
                     else
                        tpindex = tpindex + 2
                     end if
                     snapatomdegrees(iatompos+iatom) = snapatomdegrees(iatompos+iatom) + 1
                     snapatomdegrees(iatompos+jatom) = snapatomdegrees(iatompos+jatom) + 1
                  end if
               end do
            end do

            snapedgenums(isnap) = tpindex
            nedge = nedge + tpindex
         end do
      end if

      call mpi_bcast(nedge,1,mpi_integer,0, mpi_comm_world,ierr)

      if ( ifbuildedgeatruntime .eqv. .true. ) return

      call deeppub_MPISharedMemoryAllocate(iwin, dimint1d=[nsnap+1], shareint1d=snapedgeindex)
      call deeppub_MPISharedMemoryAllocate(iwin, dimint2d=[2,nedge], shareint2d=snapedges)

      if ( deepprocid == 0 ) then
         tpindex = 0
         ! cycle over all snapshots
         do isnap = 1, nsnap
            imol = snap2mol(isnap)
            ! extract atom coordinates and save to tpatomcoor
            tpatomcoor(1:3,1:molatomnums(imol)) = snapatomcoors(1:3,snapatomindex(isnap)+1:snapatomindex(isnap)+molatomnums(imol))
            ! cycle over all atoms in imol
            do iatom = 1, molatomnums(imol)
               do jatom = iatom+1, molatomnums(imol)
                  tpvec(1:3) = tpatomcoor(1:3,iatom) - tpatomcoor(1:3,jatom)
                  tpdissq = dot_product(tpvec,tpvec)
                  if ( tpdissq < tpdiscutsq ) then
                     if ( ifdoubleedge .eqv. .false. ) then
                        tpindex = tpindex + 1
                        snapedges(1:2,tpindex) = [iatom,jatom]
                     else
                        tpindex = tpindex + 2
                        snapedges(1:2,tpindex-1) = [iatom,jatom]
                        snapedges(1:2,tpindex) = [jatom,iatom]
                     end if
                  end if
               end do
            end do
            ! snapedgeindex: edge range in different snapshots
            snapedgeindex(isnap+1) = tpindex
         end do
      end if

      if ( deepprocid > 0 ) return

      print "(\,a,i10,a,f10.3)","Total edges ",tpindex," are built for all snapshots with criterion ",edgediscut

   end subroutine

   ! tpibatch: batch index
   subroutine gnnpub_prepare_batchsize(tpshuffleidx,tpibatch,tpigroup)
      integer,intent(in) :: tpibatch,tpshuffleidx(:),tpigroup
      integer :: i,j,iatt,iatom,jatom,iedge,idata,istart,isnap,imol,tpnatom,tpnedge,tpgroupsize,iatomstart
      real*8 :: tpvec(3),tpdissq,tpdiscutsq

      batchsnapatomindex = 0; batchsnapedgeindex = 0; tpnatom = 0; tpnedge = 0

      istart = (tpibatch-1)*batchsize; tpgroupsize = batchsize; batchsnapnmol = 0
      if ( ignncudagroup > 0 ) then
         tpgroupsize = ignncudagroup
         istart = istart + (tpigroup-1)*ignncudagroup*deepprocnum+deepprocid*ignncudagroup
      end if

      ! cycle over all snapshots in current batch
      ! nsnap: total number of snapshots in the dataset
      do idata = 1, tpgroupsize
         if ( (istart + idata) > nsnap ) cycle
         ! tpshuffleidx: shuffled indices of snapshots
         isnap = tpshuffleidx(istart + idata)
         ! molecule index of current isnap
         imol = snap2mol(isnap)
         batchsnap2mol(idata) = imol
         ! accumulate the total atom number
         tpnatom = tpnatom + molatomnums(imol)
         ! pick the current molecule energy
         if ( jobtype /= MD ) then
            batchrefsnapenergies(idata) = snapenergies(isnap) - molavgene(imol)
         end if
         ! set the atom range for the molecules
         batchsnapatomindex(idata+1) = tpnatom
         batchsnapnmol = batchsnapnmol + 1

         if ( ifbuildedgeatruntime .eqv. .false. ) then
             ! accumulate the total edge number
             tpnedge = tpnedge + snapedgenums(isnap)
             ! set the edge range for the molecules
             batchsnapedgeindex(idata+1) = tpnedge
         end if

     end do

     batchsnapnatom = tpnatom
     allbatchnatom = allbatchnatom + batchsnapnatom

     if (allocated(batchatomtype)) deallocate(batchatomtype,batchatomdegree)
     allocate(batchatomtype(batchsnapnatom),batchatomdegree(batchsnapnatom)); batchatomtype = 0; batchatomdegree = 0

     if ( jobtype /= MD ) then
        if (allocated(batchrefsnapatomforces)) deallocate(batchrefsnapatomforces)
        allocate(batchrefsnapatomforces(3,batchsnapnatom))
     end if
     tpnatom = 0
     do idata = 1, batchsnapnmol
        isnap = tpshuffleidx(istart + idata); imol = snap2mol(isnap)
        if ( jobtype /= MD ) then
           do iatom = 1, molatomnums(imol)
              batchrefsnapatomforces(1:3,tpnatom+iatom) = snapatomforces(1:3,snapatomindex(isnap)+iatom)
           end do
        end if
        do iatom = 1, molatomnums(imol)
           batchatomtype(tpnatom+iatom) = molatomtypes(molatomindex(imol)+iatom)
        end do
        tpnatom = tpnatom + molatomnums(imol)
     end do

     if ( ifbuildedgeatruntime .eqv. .false. ) then

        batchsnapnedge = tpnedge; maxbatchsnapnedge = batchsnapnedge

        tpnatom = 0; istart = (tpibatch-1)*batchsize
        do idata = 1, batchsnapnmol
           isnap = tpshuffleidx(istart + idata); imol = snap2mol(isnap)
           batchatomdegree(tpnatom+1:tpnatom+molatomnums(imol)) = snapatomdegrees(snapatomindex(isnap)+1:snapatomindex(isnap)+molatomnums(imol))
           tpnatom = tpnatom + molatomnums(imol)
        end do

     else

        if ( maxbatchsnapnedge == 0 ) then
           tpdiscutsq = edgediscut**2
           do idata = 1, batchsnapnmol
              isnap = tpshuffleidx(istart + idata); imol = snap2mol(isnap)
              iatomstart = snapatomindex(isnap)
              do iatom = 1, molatomnums(imol)
                 do jatom = iatom+1, molatomnums(imol)
                    tpvec(1:3) = snapatomcoors(1:3,iatomstart+iatom) - snapatomcoors(1:3,iatomstart+jatom)
                    tpdissq = dot_product(tpvec,tpvec)
                    if ( tpdissq < tpdiscutsq ) maxbatchsnapnedge = maxbatchsnapnedge + 1
                 end do
              end do
           end do
           maxbatchsnapnedge = maxbatchsnapnedge*2.0*1.45
        end if

     end if

  end subroutine

  subroutine gnnpub_network_update()
     call mlp0_network_update(networklist)
  end subroutine

  subroutine gnnpub_initialize_for_dynamic_batchsize()
      integer :: iatt

      call mlp0_initialize_for_dynamic_batchsize(gnetmain(1), batchsnapnedge)
      call mlp0_initialize_for_dynamic_batchsize(gnetmain(2), batchsnapnatom)
      call mlp0_initialize_for_dynamic_batchsize(gnetmain(3), batchsnapnatom)
      call mlp0_initialize_for_dynamic_batchsize(gnetmain(4), batchsnapnedge)
      call mlp0_initialize_for_dynamic_batchsize(gnetatomemb, maxatomtype)
      call mlp0_initialize_for_dynamic_batchsize(gnetedgeemb, 1)

      call mlp0_initialize_for_dynamic_batchsize(gnetupdate(1,1), batchsnapnatom)
      call mlp0_initialize_for_dynamic_batchsize(gnetupdate(1,2), batchsnapnatom)
      call mlp0_initialize_for_dynamic_batchsize(gnetupdate(2,1), batchsnapnatom)
      call mlp0_initialize_for_dynamic_batchsize(gnetupdate(2,2), batchsnapnatom)
      call mlp0_initialize_for_dynamic_batchsize(gnetvecoutput(1), batchsnapnatom*8)
      call mlp0_initialize_for_dynamic_batchsize(gnetvecoutput(2), batchsnapnatom*8)

      do iatt = 1, nattention
         call mlp0_initialize_for_dynamic_batchsize(gnetnodequery(iatt), batchsnapnatom)
         call mlp0_initialize_for_dynamic_batchsize(gnetnodekey(iatt), batchsnapnatom)
         call mlp0_initialize_for_dynamic_batchsize(gnetnodevalue(iatt), batchsnapnatom)
         call mlp0_initialize_for_dynamic_batchsize(gnetedgekey(iatt), batchsnapnedge)
         call mlp0_initialize_for_dynamic_batchsize(gnetedgevalue(iatt), batchsnapnedge)
         if ( ifdoubleedge .eqv. .false. ) then
            call mlp0_initialize_for_dynamic_batchsize(gnetsproj(iatt), batchsnapnedge*2)
         else
            call mlp0_initialize_for_dynamic_batchsize(gnetsproj(iatt), batchsnapnedge)
         end if
         call mlp0_initialize_for_dynamic_batchsize(gnetvecproj(iatt), batchsnapnatom*8)
         if (iatt /= nattention) then
            call mlp0_initialize_for_dynamic_batchsize(gnetfproj(iatt), batchsnapnedge)
            call mlp0_initialize_for_dynamic_batchsize(gnetwsrcproj(iatt), batchsnapnatom*8)
            call mlp0_initialize_for_dynamic_batchsize(gnetwtrgproj(iatt), batchsnapnatom*8)
         end if
         call mlp0_initialize_for_dynamic_batchsize(gnetoproj(iatt), batchsnapnatom)
      end do
      if ( icudagroup > 0 ) call mlp0_initialize_for_dynamic_batchsize_cuda()

   end subroutine

subroutine gnnpub_network_saveparm(tpnetworkfile)
  character(len=*),intent(in),optional :: tpnetworkfile
  integer :: iofile

  if ( present(tpnetworkfile) ) then
     open(newunit=iofile,file=tpnetworkfile,action="write")
  else
     open(newunit=iofile,file=networkfile,action="write")
  end if

  write(iofile,"(a)") "ectivation function"
  write(iofile,"(a10)") activation
  write(iofile,"(a)") "use layer normalization"
  write(iofile,"(l10)") ifuselayernorm
  write(iofile,"(a)") "gnnmode"
  write(iofile,"(i10)") gnnmode
  write(iofile,"(a)") "edge discut"
  write(iofile,"(f10.3)") edgediscut
  write(iofile,"(a)") "atom embedding length"
  write(iofile,"(i10)") atomembeddinglength
  write(iofile,"(a)") "edge embedding length"
  write(iofile,"(i10)") edgeembeddinglength
  write(iofile,"(a)") "head num"
  write(iofile,"(i10)") headnum
  write(iofile,"(a)") "force weight"
  write(iofile,"(f10.3)") forceweight
  write(iofile,"(a)") "use double edge"
  write(iofile,"(l10)") ifdoubleedge
  write(iofile,"(a)") "average potential energy"
  write(iofile,"(l10)") ifavgene
  write(iofile,"(a)") "potential energy averages"
  write(iofile,"(*(f20.8))") molavgene(1:nmol)
  write(iofile,"(a)") "attention layer number"
  write(iofile,"(i10)") nattention
  close(iofile)
end subroutine

subroutine gnnpub_network_loadparm()
  integer :: iofile

  open(newunit=iofile,file=networkfile,action="read")
  read(iofile,*); read(iofile,"(a10)") activation
  read(iofile,*); read(iofile,"(l10)") ifuselayernorm
  read(iofile,*); read(iofile,"(i10)") gnnmode
  read(iofile,*); read(iofile,"(f10.3)") edgediscut
  read(iofile,*); read(iofile,"(i10)") atomembeddinglength
  read(iofile,*); read(iofile,"(i10)") edgeembeddinglength
  read(iofile,*); read(iofile,"(i10)") headnum
  read(iofile,*); read(iofile,"(f10.3)") forceweight
  read(iofile,*); read(iofile,"(l10)") ifdoubleedge
  read(iofile,*); read(iofile,"(l10)") ifavgene
  read(iofile,*); read(iofile,"(*(f20.8))") molavgene(1:nmol)
  read(iofile,*); read(iofile,"(i10)") nattention
  close(iofile)
end subroutine

end module
