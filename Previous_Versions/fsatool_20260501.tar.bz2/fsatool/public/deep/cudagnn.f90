module cudagnn
   use deeppub; use mlp0; use gnnpub
   implicit none

  integer,device :: batchsnapnatom_d
  real(kind=SD),device,dimension(:),allocatable :: batchsnapenergies_d
  real(kind=SD),device,dimension(:,:),pointer :: snapatomcoors_d,batchsnapatomforces_d

  real(kind=SD),device,allocatable :: batchrefsnapenergies_d(:),batchrefsnapatomforces_d(:,:)
  integer,device,private :: ignncudagroup_d,headsize_d,headnum_d,gnnmode_d,maxatomtype_d,nattention_d
  integer,device,private :: maxbatchsnapnedge_d,batchsnapnmol_d,atomembeddinglength_d, edgeembeddinglength_d,batchsnapnedge_d

  integer,device,private,allocatable :: molatomseq2map_d(:,:),molatomseq2mapindex_d(:)
  integer,device,private,dimension(:),allocatable :: snap2mol_d,molatomnums_d,molatomindex_d,molsnapnums_d,molatomtypes_d
  integer,device,private,dimension(:),allocatable :: snapatomdegrees_d,snapedgeindex_d,snapatomindex_d,snapedgenums_d,batchatomtype_d,batchsnapatomindex_d,batchsnapedgeindex_d,batchatomdegree_d
  integer,device,private,dimension(:,:),allocatable :: snapedges_d,batchsnapedges_d

  real(kind=SD),device,private :: edgediscut_d, forceweight_d

  real(kind=SD),device,private,dimension(:),allocatable :: grad_L2atomenergy_d,grad_L2decay_d
  real(kind=SD),device,private,dimension(:),allocatable :: batchedgedistance_d,edgeembmeans_d,edgeembbetas_d

  real(kind=SD),device,private,dimension(:),allocatable :: batchedgedisdecays_d,batchatomenergies_d

  real(kind=SD),device,private,dimension(:,:),allocatable :: message_d,snapatomforces_d

  real(kind=SD),device,private,dimension(:,:),allocatable :: batchmessageres_d,batchatomembeddings_d,batchedgeembeddings_d,batchedgedirections_d,largeedgeembeddings_d,largeedgeembeddings_for_edge_d,nodefeatures_of_first_layer_d

  real(kind=SD),device,private,dimension(:,:),allocatable :: nodefeatures_d,edgefeatures_d

  real(kind=SD),device,private,dimension(:,:,:),allocatable :: vecmessage_d,batchmessagevm_d,batchmessageangle_d,batchmijvec_d,batchmijdir_d,batchedgedih_d,headattentions_d,grad_attenactiv_d

  real(kind=SD),device,private,dimension(:,:,:,:),allocatable :: batchnodequery_d,batchnodekey_d,batchnodevalue_d,batchedgekey_d,batchedgevalue_d

  real(kind=SD),device,private,dimension(:,:,:,:),allocatable :: vecfeatures_d,batchvect_d,batchvecs_d,batchvecv_d,batchvecdiht_d,batchvecdihs_d

  ! for back propagation
  real(kind=SD),device,private,dimension(:,:),allocatable :: grad_L2atomemb_d,grad_L2edgeemb_d
  real(kind=SD),device,private,dimension(:,:),allocatable :: grad_L2fproj_d,grad_L2ef_d,grad_L2attn_d
  real(kind=SD),device,private,dimension(:,:),allocatable :: grad_L2mij_d,grad_L2message_d,grad_L2nf_d,grad_L2oproj_d,grad_L2sproj_d
  real(kind=SD),device,private,dimension(:,:,:),allocatable :: grad_L2V_d,grad_L2Q_d,grad_L2K_d,grad_L2wtrgproj_d,grad_L2wsrcproj_d
  real(kind=SD),device,private,dimension(:,:,:),allocatable :: grad_L2vecproj_d,grad_L2vf_d,upper_grad_L2vf_d
  real(kind=SD),device,private,dimension(:,:,:),allocatable :: grad_L2DenseV_d,grad_L2DenseK_d

  real(kind=SD),device,private :: vecfeatures_normmean_d
  real(kind=SD),device,allocatable,private :: grad_L2vf_dot_vecfeature13_d(:), grad_L2vf_dot_vecfeature48_d(:)
  real(kind=SD),device,allocatable,private :: vecfeatures_normed_d(:,:,:,:),delta_grad_L2vf_notnormed_d(:,:,:)

  real(kind=SD),device,allocatable :: grad_decay2dis_d(:),grad_dirij2coordi_d(:,:,:),delta_coors_d(:,:,:)

  real(kind=SD),device,allocatable,private :: batchupdate12_d(:,:), batchvecoutput1_d(:,:,:), batchvecoutput2_d(:,:,:),batchvecoutput2sumsq_d(:,:)
  real(kind=SD),device,allocatable,private :: vecfeatures_normsigma1_d(:,:),vecfeatures_normlength_sq1_d(:,:,:)
  real(kind=SD),device,allocatable,private :: vecfeatures_normsigma2_d(:,:),vecfeatures_normlength_sq2_d(:,:,:)
  real(kind=SD),device,allocatable,private :: batchoutputx_d(:,:),batchoutputv_d(:,:,:)

  real(kind=SD),device,private,allocatable :: grad_L2outx2_d(:,:),grad_L2outx1_d(:,:),grad_L2outx_d(:,:)
  real(kind=SD),device,private,allocatable :: grad_L2outv2_d(:,:,:),grad_L2outv1_d(:,:,:),grad_L2outv_d(:,:,:)
  real(kind=SD),device,private,allocatable :: grad_L2outvecnorm2head_d(:,:),grad_L2outvecnorm1head_d(:,:)
  real(kind=SD),device,private,allocatable :: grad_L2vecout2_d(:,:,:),grad_L2vecout1_d(:,:,:)

contains

subroutine cudagnn_initialize()
  integer :: i,j,itot,ipair,imol,iatom,jatom
  integer,allocatable :: tpmolatomseq2map(:,:)

  ignncudagroup_d = ignncudagroup; forceweight_d = forceweight
  headsize_d = headsize; headnum_d = headnum; gnnmode_d = gnnmode; edgediscut_d = edgediscut
  maxatomtype_d = maxatomtype; nattention_d = nattention
  atomembeddinglength_d = atomembeddinglength
  edgeembeddinglength_d = edgeembeddinglength
  deepntotdata_d = deepntotdata

  deallocate(errormark_d)

  allocate(batchrefsnapenergies_d(batchsize)) 
  allocate(batchsnapatomindex_d(batchsize+1)) 
  allocate(batchsnapenergies_d(batchsize))
  allocate(batchsnapedgeindex_d(batchsize+1))

  allocate(snapatomindex_d(nsnap+1)); snapatomindex_d = snapatomindex
  allocate(snapatomcoors_d(3,size(snapatomcoors,2)))
  snapatomcoors_d = snapatomcoors

  if ( jobtype /= MD ) then
     allocate(snapedgenums_d(nsnap)); snapedgenums_d = snapedgenums
     allocate(snapatomforces_d(3,size(snapatomforces,2)))
     snapatomforces_d = snapatomforces
     if ( ifbuildedgeatruntime .eqv. .false. ) then
        allocate(snapedges_d(2,nedge)); snapedges_d = snapedges
        allocate(snapedgeindex_d(nsnap+1)); snapedgeindex_d = snapedgeindex
     end if
     allocate(snapatomdegrees_d(size(snapatomcoors,2))); snapatomdegrees_d = snapatomdegrees
  end if

  allocate(molatomnums_d(nmol),molatomindex_d(nmol+1)); molatomnums_d = molatomnums; molatomindex_d = molatomindex
  allocate(molsnapnums_d(nmol)); molsnapnums_d = molsnapnums
  allocate(molatomtypes_d(molatomindex(nmol+1))); molatomtypes_d = molatomtypes

  allocate(edgeembmeans_d(edgeembeddinglength),edgeembbetas_d(edgeembeddinglength))

  allocate(snap2mol_d(nsnap)); snap2mol_d = snap2mol
  itot = 0
  do imol = 1, nmol
     itot = itot + (1+molatomnums(imol)-1)*(molatomnums(imol)-1)/2
  end do
  ipair = 0
  allocate(tpmolatomseq2map(2,itot),molatomseq2map_d(2,itot),molatomseq2mapindex_d(nmol+1))
  tpmolatomseq2map = 0; molatomseq2mapindex_d = 0
  do imol = 1, nmol
     do iatom = 1, molatomnums(imol)-1
        do jatom = iatom+1, molatomnums(imol)
           ipair = ipair + 1
           tpmolatomseq2map(1:2,ipair) = [iatom,jatom]
        end do
     end do
     molatomseq2mapindex_d(imol+1) = ipair
  end do
  if ( itot /= ipair ) stop "atom pair index error!"
  molatomseq2map_d = tpmolatomseq2map

  allocate(batchdata_d(1))
end subroutine

subroutine cudagnn_prepare_batchdata()
  integer,save :: tpmaxnatom = 0, tpmaxnedge = 0, tpmaxbatchdata = 0, tpmaxbatchlabel = 0
  integer :: i
 
  if ( batchsnapnatom > tpmaxnatom ) then
     tpmaxnatom = batchsnapnatom

     if ( (atomembeddinglength*batchsnapnatom*8) > tpmaxbatchdata ) then
        tpmaxbatchdata = atomembeddinglength*batchsnapnatom*8
        deallocate(batchdata_d); allocate(batchdata_d(tpmaxbatchdata))
     end if

     if ( (atomembeddinglength*3*batchsnapnatom*8) > tpmaxbatchlabel ) then
        tpmaxbatchlabel = atomembeddinglength*3*batchsnapnatom*8
        deallocate(batchlabel_d); allocate(batchlabel_d(tpmaxbatchlabel))
     end if

     deallocate(grad_L2atomenergy_d); allocate(grad_L2atomenergy_d(batchsnapnatom))
     deallocate(nodefeatures_of_first_layer_d,batchatomembeddings_d,batchatomenergies_d)
     deallocate(batchnodequery_d,batchnodekey_d,batchnodevalue_d)

     allocate(batchatomembeddings_d(atomembeddinglength*2,batchsnapnatom)); batchatomembeddings_d = 0d0

     deallocate(vecfeatures_normsigma1_d,vecfeatures_normlength_sq1_d)
     deallocate(vecfeatures_normsigma2_d,vecfeatures_normlength_sq2_d)
     allocate(vecfeatures_normsigma1_d(batchsnapnatom,nattention),vecfeatures_normlength_sq1_d(atomembeddinglength,batchsnapnatom,nattention))
     allocate(vecfeatures_normsigma2_d(batchsnapnatom,nattention),vecfeatures_normlength_sq2_d(atomembeddinglength,batchsnapnatom,nattention))

     deallocate(batchupdate12_d, batchvecoutput1_d, batchvecoutput2_d, batchvecoutput2sumsq_d)
     allocate(batchupdate12_d(atomembeddinglength/2,batchsnapnatom))
     allocate(batchvecoutput1_d(atomembeddinglength+atomembeddinglength/2,8,batchsnapnatom),batchvecoutput2_d(atomembeddinglength/2+1,8,batchsnapnatom))
     allocate(batchvecoutput2sumsq_d(atomembeddinglength/2,batchsnapnatom))

     deallocate(batchoutputx_d,batchoutputv_d)
     allocate(batchoutputx_d(atomembeddinglength/2,batchsnapnatom),batchoutputv_d(atomembeddinglength/2,8,batchsnapnatom))

     deallocate(vecfeatures_normed_d)
     allocate(vecfeatures_normed_d(atomembeddinglength, 8, batchsnapnatom,0:nattention)); vecfeatures_normed_d = 0d0

     allocate(batchatomenergies_d(batchsnapnatom))
     allocate(nodefeatures_of_first_layer_d(atomembeddinglength,batchsnapnatom))

     allocate(batchnodequery_d(headsize,headnum,batchsnapnatom,nattention),batchnodekey_d(headsize,headnum,batchsnapnatom,nattention),batchnodevalue_d(headsize,headnum,batchsnapnatom,nattention))

     deallocate(batchvect_d,batchvecs_d,batchvecv_d,batchvecdiht_d,batchvecdihs_d)
     if (nattention > 1) then
        allocate(batchvect_d(atomembeddinglength,8,batchsnapnatom,nattention),batchvecs_d(atomembeddinglength,8,batchsnapnatom,nattention), &
               batchvecv_d(atomembeddinglength,8,batchsnapnatom,nattention),batchvecdiht_d(atomembeddinglength,8,batchsnapnatom,nattention-1),batchvecdihs_d(atomembeddinglength,8,batchsnapnatom,nattention-1))
     else
        allocate(batchvect_d(atomembeddinglength,8,batchsnapnatom,nattention),batchvecs_d(atomembeddinglength,8,batchsnapnatom,nattention), &
               batchvecv_d(atomembeddinglength,8,batchsnapnatom,nattention))
     end if
     deallocate(vecfeatures_d,batchmessagevm_d,batchmessageangle_d,batchmessageres_d)
     allocate(vecfeatures_d(atomembeddinglength, 8, batchsnapnatom,0:nattention))
     allocate(batchmessagevm_d(atomembeddinglength,batchsnapnatom,nattention),batchmessageangle_d(atomembeddinglength,batchsnapnatom,nattention),batchmessageres_d(atomembeddinglength,batchsnapnatom))

     deallocate(grad_L2wtrgproj_d,grad_L2wsrcproj_d,grad_L2message_d)
     allocate(grad_L2wtrgproj_d(atomembeddinglength,8,batchsnapnatom))
     allocate(grad_L2wsrcproj_d(atomembeddinglength,8,batchsnapnatom))
     allocate(grad_L2message_d(atomembeddinglength,batchsnapnatom))

     deallocate(grad_L2nf_d,grad_L2vecproj_d,grad_L2vf_d,upper_grad_L2vf_d,grad_L2oproj_d,delta_grad_L2vf_notnormed_d)
     allocate(grad_L2nf_d(atomembeddinglength,batchsnapnatom),grad_L2vf_d(atomembeddinglength,8,batchsnapnatom),upper_grad_L2vf_d(atomembeddinglength,8,batchsnapnatom),delta_grad_L2vf_notnormed_d(atomembeddinglength,8,batchsnapnatom))
     allocate(grad_L2vecproj_d(atomembeddinglength*3,8,batchsnapnatom))
     allocate(grad_L2oproj_d(atomembeddinglength*3,batchsnapnatom))

     deallocate(grad_L2vf_dot_vecfeature13_d,grad_L2vf_dot_vecfeature48_d)
     allocate(grad_L2vf_dot_vecfeature13_d(batchsnapnatom),grad_L2vf_dot_vecfeature48_d(batchsnapnatom))

     deallocate(grad_L2atomemb_d,grad_L2K_d,grad_L2V_d,grad_L2Q_d)
     allocate(grad_L2K_d(headsize,headnum,batchsnapnatom),grad_L2V_d(headsize,headnum,batchsnapnatom),grad_L2Q_d(headsize,headnum,batchsnapnatom))
     allocate(grad_L2atomemb_d(atomembeddinglength*2,batchsnapnatom))

     deallocate(message_d,vecmessage_d,nodefeatures_d)
     allocate(message_d(atomembeddinglength,batchsnapnatom),nodefeatures_d(atomembeddinglength, batchsnapnatom))
     allocate(vecmessage_d(atomembeddinglength,8,batchsnapnatom))

     deallocate(batchsnapatomforces_d)
     allocate(batchsnapatomforces_d(3,batchsnapnatom))

     deallocate(grad_L2outx2_d,grad_L2outv2_d,grad_L2outx1_d,grad_L2outvecnorm2head_d)
     deallocate(grad_L2vecout2_d,grad_L2outv1_d,grad_L2outx_d,grad_L2outvecnorm1head_d)
     deallocate(grad_L2vecout1_d,grad_L2outv_d)

     allocate(grad_L2outx2_d(1,batchsnapnatom),grad_L2outv2_d(1,8,batchsnapnatom))
     allocate(grad_L2outx1_d(atomembeddinglength/2,batchsnapnatom),grad_L2outvecnorm2head_d(atomembeddinglength/2,batchsnapnatom))
     allocate(grad_L2vecout2_d(atomembeddinglength/2+1,8,batchsnapnatom),grad_L2outv1_d(atomembeddinglength/2,8,batchsnapnatom))
     allocate(grad_L2outx_d(atomembeddinglength,batchsnapnatom),grad_L2outvecnorm1head_d(atomembeddinglength,batchsnapnatom))
     allocate(grad_L2vecout1_d(atomembeddinglength+atomembeddinglength/2,8,batchsnapnatom),grad_L2outv_d(atomembeddinglength,8,batchsnapnatom))

     if ( jobtype /= MD ) then
        deallocate(batchrefsnapatomforces_d)
        allocate(batchrefsnapatomforces_d(3,batchsnapnatom))
     end if
  end if

  if ( jobtype /= MD ) then
     batchrefsnapatomforces_d(1:3,1:batchsnapnatom) = batchrefsnapatomforces(1:3,1:batchsnapnatom)
     batchrefsnapenergies_d = batchrefsnapenergies
  end if

  if ( batchsnapnedge > tpmaxnedge ) then
     tpmaxnedge = batchsnapnedge

     i = max( edgeembeddinglength*batchsnapnedge, atomembeddinglength*batchsnapnedge*2 )
     if ( i >  tpmaxbatchdata ) then
        tpmaxbatchdata = i
        deallocate(batchdata_d); allocate(batchdata_d(tpmaxbatchdata))
     end if

     if ( (atomembeddinglength*2*batchsnapnedge) > tpmaxbatchlabel ) then
        tpmaxbatchlabel = atomembeddinglength*2*batchsnapnedge
        deallocate(batchlabel_d); allocate(batchlabel_d(tpmaxbatchlabel))
     end if

     deallocate(grad_L2decay_d); allocate(grad_L2decay_d(batchsnapnedge))
     deallocate(largeedgeembeddings_d,largeedgeembeddings_for_edge_d,batchedgeembeddings_d)
     deallocate(batchedgekey_d,batchedgevalue_d)

     allocate(batchedgeembeddings_d(edgeembeddinglength,batchsnapnedge))
     allocate(largeedgeembeddings_d(atomembeddinglength,batchsnapnedge))
     allocate(largeedgeembeddings_for_edge_d(atomembeddinglength,batchsnapnedge))
     allocate(batchedgekey_d(headsize,headnum,batchsnapnedge,nattention),batchedgevalue_d(headsize,headnum,batchsnapnedge,nattention))

     deallocate(batchmijdir_d)
     allocate(batchmijdir_d(atomembeddinglength,batchsnapnedge,nattention))
     deallocate(batchmijvec_d,batchedgedih_d)
     allocate(batchmijvec_d(atomembeddinglength,batchsnapnedge,nattention))
     allocate(batchedgedih_d(atomembeddinglength,batchsnapnedge,nattention))

     deallocate(headattentions_d,grad_attenactiv_d)
     allocate(headattentions_d(headnum,batchsnapnedge,nattention),grad_attenactiv_d(headnum,batchsnapnedge,nattention))

     deallocate(grad_L2fproj_d,grad_L2ef_d,grad_L2sproj_d)
     allocate(grad_L2fproj_d(atomembeddinglength,batchsnapnedge))
     allocate(grad_L2ef_d(atomembeddinglength,batchsnapnedge))
     allocate(grad_L2sproj_d(atomembeddinglength*2,batchsnapnedge))

     deallocate(grad_L2mij_d,edgefeatures_d)
     allocate(grad_L2mij_d(atomembeddinglength,batchsnapnedge),edgefeatures_d(atomembeddinglength, batchsnapnedge))

     deallocate(grad_L2edgeemb_d,grad_L2DenseK_d,grad_L2DenseV_d,grad_L2attn_d)
     allocate(grad_L2edgeemb_d(edgeembeddinglength,batchsnapnedge),grad_L2DenseK_d(headsize,headnum,batchsnapnedge),grad_L2DenseV_d(headsize,headnum,batchsnapnedge),grad_L2attn_d(headnum,batchsnapnedge))

  end if

end subroutine

   subroutine cudagnn_calculate_batch_edge_info(istart)
      integer,intent(in) :: istart

      if ( ifbuildedgeatruntime .eqv. .false. ) then
         if (allocated(batchsnapedges)) deallocate(batchsnapedges_d,batchedgedistance_d,batchedgedisdecays_d,grad_decay2dis_d,batchedgedirections_d,grad_dirij2coordi_d)
         allocate(batchsnapedges_d(2,batchsnapnedge)); batchsnapedges_d = 0
         allocate(batchedgedistance_d(batchsnapnedge)); batchedgedistance_d = 0d0
         allocate(batchedgedisdecays_d(batchsnapnedge)); batchedgedisdecays_d = 0d0
         allocate(grad_decay2dis_d(batchsnapnedge)); grad_decay2dis_d = 0d0
         allocate(batchedgedirections_d(8,batchsnapnedge)); batchedgedirections_d = 0d0
         allocate(grad_dirij2coordi_d(8,3,batchsnapnedge)); grad_dirij2coordi_d = 0d0
      else
         if ( .not. allocated(batchsnapedges_d) ) then
            maxbatchsnapnedge_d = maxbatchsnapnedge
            allocate(batchsnapedges_d(2,maxbatchsnapnedge)); batchsnapedges_d = 0
            allocate(batchedgedistance_d(maxbatchsnapnedge)); batchedgedistance_d = 0d0
            allocate(batchedgedisdecays_d(maxbatchsnapnedge)); batchedgedisdecays_d = 0d0
            allocate(grad_decay2dis_d(maxbatchsnapnedge)); grad_decay2dis_d = 0d0
            allocate(batchedgedirections_d(8,maxbatchsnapnedge)); batchedgedirections_d = 0d0
            allocate(grad_dirij2coordi_d(8,3,maxbatchsnapnedge)); grad_dirij2coordi_d = 0d0
         end if
      end if

      if ( (jobtype /= MD) .or. (jobtype == MD .and. (.not. allocated(batchatomdegree_d)) ) ) then
         batchsnapnmol_d = batchsnapnmol
         batchsnapnatom_d = batchsnapnatom
         batchsnapatomindex_d = batchsnapatomindex

         if (allocated(batchatomdegree_d)) deallocate(batchatomdegree_d,batchatomtype_d)
         allocate(batchatomdegree_d(batchsnapnatom),batchatomtype_d(batchsnapnatom))
         batchatomtype_d = batchatomtype
      end if

      if ( ifbuildedgeatruntime .eqv. .false. ) then

         batchsnapedgeindex_d = batchsnapedgeindex
         batchatomdegree_d = batchatomdegree
         batchsnapnedge_d = batchsnapnedge
         call cudagnn_set_batchdata<<<batchsnapnmol,32>>>(istart)

      else

         batchsnapnedge_d = 0; batchatomdegree_d = 0
         call cudagnn_buildedges_at_runtime<<<batchsnapnmol,32>>>(istart)
         batchsnapnedge = batchsnapnedge_d

      end if

  end subroutine

  attributes(global) subroutine cudagnn_buildedges_at_runtime(istart)
      integer,value :: istart
      integer :: maxbatchsnapnedge,iedge,imol,idata,ipair,isnap,iatom,jatom,tpnatom
      real(kind=SD) :: tpdiscutsq,sq3,tpvec(3),tpdissq,tpdis,edgediscut,pi_cut,xsq,ysq,zsq,xyz,xy,xz,yz

      idata = blockidx%x
      isnap = shuffleidx_d(istart + idata); imol = snap2mol_d(isnap)
      isnap = snapatomindex_d(isnap); maxbatchsnapnedge = maxbatchsnapnedge_d
      edgediscut = edgediscut_d; tpdiscutsq = edgediscut**2; sq3 = sqrt(3.0_SD)
      tpnatom = batchsnapatomindex_d(idata); pi_cut = pi/edgediscut

      do ipair = molatomseq2mapindex_d(imol)+threadidx%x, molatomseq2mapindex_d(imol+1), 32
         iatom = molatomseq2map_d(1,ipair); jatom = molatomseq2map_d(2,ipair)
         tpvec(1:3) = snapatomcoors_d(1:3,isnap+iatom) - snapatomcoors_d(1:3,isnap+jatom)
         tpdissq = dot_product(tpvec,tpvec)

         if ( tpdissq < tpdiscutsq ) then
            iedge = atomicadd(batchatomdegree_d(tpnatom+iatom),1)
            iedge = atomicadd(batchatomdegree_d(tpnatom+jatom),1)

            tpdis = sqrt(tpdissq); tpvec = tpvec/tpdis
            xsq = tpvec(1)*tpvec(1); ysq = tpvec(2)*tpvec(2); zsq = tpvec(3)*tpvec(3); xyz = tpvec(1)*tpvec(2)*tpvec(3)
            xy = tpvec(1)*tpvec(2); xz = tpvec(1)*tpvec(3); yz = tpvec(2)*tpvec(3)

            iedge = atomicadd(batchsnapnedge_d,1)
            if ( (iedge+2) > maxbatchsnapnedge ) then
               print *,"maxbatchsnapnedge is too small! ",maxbatchsnapnedge,iedge+2; stop
            end if
            batchsnapedges_d(1,iedge+1) = tpnatom+iatom
            batchsnapedges_d(2,iedge+1) = tpnatom+jatom
            batchedgedistance_d(iedge+1) = tpdis

            batchedgedisdecays_d(iedge+1) = max(0.5_SD*(cos(tpdis*pi_cut) + 1.0_SD), 0.000000001_SD)
            grad_decay2dis_d(iedge+1) = - 0.5_SD*(pi_cut)*sin(tpdis*pi_cut)

            batchedgedirections_d(1:8,iedge+1) = [tpvec(1), tpvec(2), tpvec(3), &
                     sq3*xz, sq3*xy,    &
                     0.5_SD*(3.0_SD*ysq - 1.0_SD), &
                     sq3*yz, sq3*0.5_SD*(zsq-xsq)]

            grad_dirij2coordi_d(:,1,iedge+1) = &
                    [1.0_SD-xsq, -xy, -xz, &
                     sq3*tpvec(3)*(1_SD-2_SD*xsq), sq3*tpvec(2)*(1_SD-2_SD*xsq), -3_SD*tpvec(1)*ysq, &
                     -2_SD*sq3*xyz, -sq3*tpvec(1)*(ysq+2_SD*zsq) ] / tpdis

            grad_dirij2coordi_d(:,2,iedge+1) = &
                    [-xy, 1.0_SD-ysq, -yz, &
                     -2_SD*sq3*xyz, sq3*tpvec(1)*(1_SD-2_SD*ysq), 3_SD*tpvec(2)*(1_SD-ysq), &
                     sq3*tpvec(3)*(1_SD-2_SD*ysq), sq3*tpvec(2)*(xsq-zsq) ] / tpdis

            grad_dirij2coordi_d(:,3,iedge+1) = &
                    [-xz, -yz, 1.0_SD-zsq, &
                     sq3*tpvec(1)*(1_SD-2_SD*zsq), -2_SD*sq3*xyz, -3_SD*tpvec(3)*ysq, &
                     sq3*tpvec(2)*(1_SD-2_SD*zsq), sq3*tpvec(3)*(ysq+2_SD*xsq) ] / tpdis

            tpvec = -tpvec; xyz = -xyz

            iedge = atomicadd(batchsnapnedge_d,1)
            batchsnapedges_d(1,iedge+1) = tpnatom+jatom
            batchsnapedges_d(2,iedge+1) = tpnatom+iatom
            batchedgedistance_d(iedge+1) = tpdis
            batchedgedisdecays_d(iedge+1) = max(0.5_SD*(cos(tpdis*pi_cut) + 1.0_SD), 0.000000001_SD)
            grad_decay2dis_d(iedge+1) = - 0.5_SD*(pi_cut)*sin(tpdis*pi_cut)

            batchedgedirections_d(1:8,iedge+1) = [tpvec(1), tpvec(2), tpvec(3), &
                     sq3*xz, sq3*xy,    &
                     0.5_SD*(3.0_SD*ysq - 1.0_SD), &
                     sq3*yz, sq3*0.5_SD*(zsq-xsq)]

            grad_dirij2coordi_d(:,1,iedge+1) = &
                    [1.0_SD-xsq, -xy, -xz, &
                     sq3*tpvec(3)*(1_SD-2_SD*xsq), sq3*tpvec(2)*(1_SD-2_SD*xsq), -3_SD*tpvec(1)*ysq, &
                     -2_SD*sq3*xyz, -sq3*tpvec(1)*(ysq+2_SD*zsq) ] / tpdis

            grad_dirij2coordi_d(:,2,iedge+1) = &
                    [-xy, 1.0_SD-ysq, -yz, &
                     -2_SD*sq3*xyz, sq3*tpvec(1)*(1_SD-2_SD*ysq), 3_SD*tpvec(2)*(1_SD-ysq), &
                     sq3*tpvec(3)*(1_SD-2_SD*ysq), sq3*tpvec(2)*(xsq-zsq) ] / tpdis

            grad_dirij2coordi_d(:,3,iedge+1) = &
                    [-xz, -yz, 1.0_SD-zsq, &
                     sq3*tpvec(1)*(1_SD-2_SD*zsq), -2_SD*sq3*xyz, -3_SD*tpvec(3)*ysq, &
                     sq3*tpvec(2)*(1_SD-2_SD*zsq), sq3*tpvec(3)*(ysq+2_SD*xsq) ] / tpdis

         end if
      end do

   end subroutine

   subroutine cudagnn_network_forward(calloss,printinfo) 
      logical,intent(in),optional :: calloss,printinfo
      integer :: imol,i,iatt
      real*8 :: tpvalue,tpvec(3)
      real*8, allocatable :: tpene(:)

      call cudagnn_batchdadta_for_gnetatomemb<<<maxatomtype,32>>>()
      icudagroup = maxatomtype; icudagroup_d = icudagroup
      call mlp0_network_forward_cuda(gnetatomemb)

      call cudagnn_traindata_batchatomembeddings<<<batchsnapnatom,32>>>(gnetatomemb%id)

      batchdata_d(1) = 1.0_SD
      icudagroup = 1; icudagroup_d = icudagroup
      call mlp0_network_forward_cuda(gnetedgeemb)

      call cudagnn_traindata_edgeembmeans_edgeembbetas_batchedgeembeddings<<<batchsnapnedge,32>>>(gnetedgeemb%id)

      i = edgeembeddinglength*batchsnapnedge
      batchdata_d(1:i) = reshape(batchedgeembeddings_d,[i])
      icudagroup = batchsnapnedge; icudagroup_d = icudagroup
      call mlp0_network_forward_cuda(gnetmain(4))
      call cudagnn_traindata_largeedgeembeddings_for_edge<<<batchsnapnedge,32>>>(gnetmain(4)%id)
      
      call mlp0_network_forward_cuda(gnetmain(1))

      call cudagnn_batchdata_set_zero<<<1,32>>>(2*atomembeddinglength*batchsnapnatom)

      call cudagnn_edge_message_aggregation<<<batchsnapnedge,32>>>(gnetmain(1)%id)
      call cudagnn_edge_message_aggregation2<<<batchsnapnatom,32>>>()
      icudagroup_d = batchsnapnatom; icudagroup = batchsnapnatom

      call mlp0_network_forward_cuda(gnetmain(2))
      call cudagnn_traindata_nodefeatures<<<batchsnapnatom,32>>>(gnetmain(2)%id)

      call cudagnn_traindata_edgefeatures<<<batchsnapnedge,32>>>()

      vecfeatures_d(:,:,:,0) = 0.0_SD

      do iatt = 1, nattention

         i = atomembeddinglength*batchsnapnatom
         batchdata_d(1:i) = reshape(nodefeatures_d,[i])
         icudagroup = batchsnapnatom; icudagroup_d = icudagroup

         call mlp0_network_forward_cuda(gnetnodequery(iatt))
         call cudagnn_batchdata_node_qkv<<<batchsnapnatom,32>>>(gnetnodequery(iatt)%id,iatt,1)

         call mlp0_network_forward_cuda(gnetnodekey(iatt))
         call cudagnn_batchdata_node_qkv<<<batchsnapnatom,32>>>(gnetnodekey(iatt)%id,iatt,2)

         call mlp0_network_forward_cuda(gnetnodevalue(iatt))
         call cudagnn_batchdata_node_qkv<<<batchsnapnatom,32>>>(gnetnodevalue(iatt)%id,iatt,3)

         if ( iatt /= 1 ) then

            i = atomembeddinglength*batchsnapnatom*8
            batchdata_d(1:i) = reshape(vecfeatures_normed_d(:,:,:,iatt-1),[i])
            icudagroup = batchsnapnatom*8; icudagroup_d = icudagroup

            if ( iatt /= nattention ) then
               call mlp0_network_forward_cuda(gnetwtrgproj(iatt))
               call cudagnn_traindata_batchvecdiht_batchvecdihs<<<batchsnapnatom,32>>>(gnetwtrgproj(iatt)%id,iatt,1)

               call mlp0_network_forward_cuda(gnetwsrcproj(iatt))
               call cudagnn_traindata_batchvecdiht_batchvecdihs<<<batchsnapnatom,32>>>(gnetwsrcproj(iatt)%id,iatt,2)
            end if

            call mlp0_network_forward_cuda(gnetvecproj(iatt))
            call cudagnn_traindata_batchvect_batchvecs_batchvecv<<<batchsnapnatom,32>>>(gnetvecproj(iatt)%id,iatt)

         else

            call cudagnn_traindata_batchvecdiht_batchvecdihs_batchvect_batchvecs_batchvecv_zero<<<batchsnapnatom,32>>>(iatt)

         end if

         i = atomembeddinglength*batchsnapnedge
         batchdata_d(1:i) = reshape(edgefeatures_d,[i])
         icudagroup = batchsnapnedge; icudagroup_d = icudagroup
         call mlp0_network_forward_cuda(gnetedgekey(iatt))
         call cudagnn_traindata_batchedgekey_batchedgevalue<<<batchsnapnedge,32>>>(gnetedgekey(iatt)%id,iatt,2)

         call mlp0_network_forward_cuda(gnetedgevalue(iatt))
         call cudagnn_traindata_batchedgekey_batchedgevalue<<<batchsnapnedge,32>>>(gnetedgevalue(iatt)%id,iatt,3)

         if (iatt /= nattention) then
            call mlp0_network_forward_cuda(gnetfproj(iatt))
            call cudagnn_traindata_batchedgedih<<<batchsnapnedge,32>>>(gnetfproj(iatt)%id,iatt)
         end if

         call cudagnn_traindata_headattentions<<<batchsnapnedge,32>>>(iatt)

         call cudagnn_message_and_vecmessage_set_zero<<<batchsnapnatom,32>>>()
         call cudagnn_message_batchdata_gnetsproj<<<batchsnapnedge,32>>>(iatt,gnnmode)

         icudagroup = batchsnapnedge; icudagroup_d = icudagroup

         call mlp0_network_forward_cuda(gnetsproj(iatt))
         call cudagnn_traindata_batchmijvec_batchmjivec<<<batchsnapnedge,32>>>(gnetsproj(iatt)%id,iatt)

         call cudagnn_traindata_vecmessage<<<batchsnapnedge,32>>>(iatt)

         i = atomembeddinglength*batchsnapnatom
         batchdata_d(1:i) = reshape(message_d, [i])
         icudagroup = batchsnapnatom; icudagroup_d = icudagroup
         call mlp0_network_forward_cuda(gnetoproj(iatt))
         call cudagnn_traindata_batchmessagevm_batchmessageangle_batchmessageres<<<batchsnapnatom,32>>>(gnetoproj(iatt)%id,iatt)

         call cudagnn_traindata_vecfeatures_nodefeatures<<<batchsnapnatom,32>>>(iatt)

         if ( ifuselayernorm ) then
            call cudagnn_vecfeature_normsigma<<<batchsnapnatom,32>>>(iatt)
            call cudagnn_vecfeature_layernorm<<<batchsnapnatom,32>>>(iatt)
         end if

         if ( (iatt /= nattention) .and. (iatt /= 1) ) then
            call cudagnn_traindata_edgefeatures_in_attention<<<batchsnapnedge,32>>>(iatt)
         end if

      end do

      i = atomembeddinglength*batchsnapnatom*8
      batchdata_d(1:i) = reshape(vecfeatures_normed_d(:,:,:,nattention),[i])
      icudagroup = batchsnapnatom*8; icudagroup_d = icudagroup
      call mlp0_network_forward_cuda(gnetvecoutput(1))
      call cudagnn_batchvecoutput1_batchdata_for_gnetupdate<<<batchsnapnatom,32>>>(gnetvecoutput(1)%id)
      icudagroup = batchsnapnatom; icudagroup_d = icudagroup
      call mlp0_network_forward_cuda(gnetupdate(1,1))
      call cudagnn_traindata_batchoutputx<<<batchsnapnatom,32>>>(gnetupdate(1,1)%id)
      call mlp0_network_forward_cuda(gnetupdate(1,2))
      call cudagnn_traindata_batchupdate12_batchoutputv<<<batchsnapnatom,32>>>(gnetupdate(1,2)%id)

      i = atomembeddinglength/2*batchsnapnatom*8
      batchdata_d(1:i) = reshape(batchoutputv_d(:,:,:),[i])        
      icudagroup = batchsnapnatom*8; icudagroup_d = icudagroup
      call mlp0_network_forward_cuda(gnetvecoutput(2))
      call cudagnn_batchdata_for_gnetupdate2<<<batchsnapnatom,32>>>(gnetvecoutput(2)%id)

      icudagroup = batchsnapnatom; icudagroup_d = icudagroup
      call mlp0_network_forward_cuda(gnetupdate(2,1))
      call cudagnn_traindata_batchoutputx2<<<batchsnapnatom,32>>>(gnetupdate(2,1)%id)
      call mlp0_network_forward_cuda(gnetupdate(2,2))
      call cudagnn_traindata_batchoutputv_batchoutputx<<<(batchsnapnatom-1)/32+1,32>>>(gnetupdate(2,2)%id)

      if ( present(calloss) ) then
         call cudagnn_calculate_loss_function<<<batchsnapnmol,32>>>(.true.)
      else
         call cudagnn_calculate_loss_function<<<batchsnapnmol,32>>>(.false.)
      end if

      if ( present(printinfo) ) then
         if ( printinfo .eqv. .true. ) then
            allocate(tpene(size(batchrefsnapenergies)))
            tpene = batchsnapenergies_d
            open(unit=1000, file="energy_prediction_result.txt", status='old', position='append')
            if ( present(calloss) ) then
               do i = 1, size(batchrefsnapenergies)
                  imol = batchsnap2mol(i)
                  write(1000,'(f15.3,a,f15.3)') tpene(i) + molavgene(imol),"\t", batchrefsnapenergies(i) + molavgene(imol)
               end do
            else
               do i = 1, size(batchrefsnapenergies)
                  imol = batchsnap2mol(i)
                  write(1000,'(f15.3)') tpene(i) + molavgene(imol)
               end do
            end if
            close(1000)
            deallocate(tpene)
         end if
      end if
   end subroutine
   
   subroutine cudagnn_network_backward(calloss,printinfo)
      logical,intent(in),optional :: calloss,printinfo
      integer :: i,iatt,j
      real*8,allocatable :: tpmat2d(:,:)

      if ( present(calloss) ) then
         call cudagnn_batchlabel_for_grad_L2atomenergy_and_gnetmain3<<<batchsnapnmol,32>>>(.true.)
      else
         call cudagnn_batchlabel_for_grad_L2atomenergy_and_gnetmain3<<<batchsnapnmol,32>>>(.false.)
      end if

      i = batchsnapnatom; batchlabel_d(1:i) = reshape(grad_L2outx2_d,[i])
      icudagroup = batchsnapnatom; icudagroup_d = icudagroup
      call mlp0_network_backward_cuda(gnetupdate(2,1),.false.)
      call cudagnn_traindata_grad_L2outx1_grad_L2outvecnorm2head<<<batchsnapnatom,32>>>(gnetupdate(2,1)%id)

      batchlabel_d(1:i) = 0.0_SD
      call mlp0_network_backward_cuda(gnetupdate(2,2),.false.)
      call cudagnn_traindata_grad_L2outx1_grad_L2outvecnorm2head_grad_L2vecout2<<<batchsnapnatom,32>>>(gnetupdate(2,2)%id)

      i = (atomembeddinglength/2+1)*batchsnapnatom*8; batchlabel_d(1:i) = reshape(grad_L2vecout2_d,[i])
      icudagroup = 8*batchsnapnatom; icudagroup_d = icudagroup
      call mlp0_network_backward_cuda(gnetvecoutput(2),.false.)
      call cudagnn_traindata_grad_L2outv1<<<batchsnapnatom,32>>>(gnetvecoutput(2)%id)

      i = (atomembeddinglength/2)*batchsnapnatom; batchlabel_d(1:i) = reshape(grad_L2outx1_d,[i])
      icudagroup = batchsnapnatom; icudagroup_d = icudagroup
      call mlp0_network_backward_cuda(gnetupdate(1,1),.false.)
      call cudagnn_traindata_grad_L2outx_grad_L2outvecnorm1head_batchlabel_for_gnetupdate12<<<batchsnapnatom,32>>>(gnetupdate(1,1)%id)

      call mlp0_network_backward_cuda(gnetupdate(1,2),.false.)
      call cudagnn_traindata_grad_L2nf_batchlabel_for_gnetvecoutput1<<<batchsnapnatom,32>>>(gnetupdate(1,2)%id)
      icudagroup = batchsnapnatom*8; icudagroup_d = icudagroup
      call mlp0_network_backward_cuda(gnetvecoutput(1),.false.)
      call cudagnn_traindata_grad_L2nf_delta_grad_L2vf_notnormed<<<batchsnapnatom,32>>>(gnetvecoutput(1)%id)

      if ( ifuselayernorm ) then
         call cudagnn_traindata_grad_L2vf_normalization1<<<batchsnapnatom,32>>>(nattention)
         call cudagnn_traindata_grad_L2vf_normalization2<<<batchsnapnatom,32>>>(nattention)
      end if
      grad_L2vf_d = delta_grad_L2vf_notnormed_d 

      call cudagnn_traindata_grad_L2decay_batchsnapatomforces_zero<<<(batchsnapnedge-1)/32+1,32>>>()
      call cudagnn_traindata_grad_L2ef_zero<<<batchsnapnedge,32>>>()

      call cudagnn_traindata_batchsnapatomforces_add_grad_L2vf<<<batchsnapnedge,32>>>(nattention)

      do iatt=nattention,1,-1

         call cudagnn_grad_L2K_grad_L2V_grad_L2Q_zero<<<batchsnapnatom,32>>>()

         !delta_node part
         call cudagnn_traindata_grad_L2vecproj_grad_L2oproj<<<batchsnapnatom,32>>>(iatt)

         !delta_edge part
         if ( (iatt /= nattention) .and. (iatt /= 1) ) then
            call cudagnn_traindata_grad_L2wsrcproj_grad_L2wtrgproj_zero<<<batchsnapnatom,32>>>()
            call cudagnn_traindata_grad_L2wsrcproj_grad_L2wtrgproj_grad_L2fproj<<<batchsnapnedge,32>>>(iatt)
         end if

         !delta_vec part
         upper_grad_L2vf_d = grad_L2vf_d; delta_grad_L2vf_notnormed_d = 0.0d0

         call cudagnn_traindata_upper_grad_L2vf_and_delta_grad_L2vf_notnormed<<<batchsnapnatom,32>>>()
         call cudagnn_traindata_grad_L2sproj_grad_L2vf<<<batchsnapnedge,32>>>(iatt)

         if ( ifuselayernorm .and. (iatt /= 1) ) then
            call cudagnn_traindata_grad_L2vf_normalization1<<<batchsnapnatom,32>>>(iatt-1)
            call cudagnn_traindata_grad_L2vf_normalization2<<<batchsnapnatom,32>>>(iatt-1)
         end if
         call cudagnn_batchdata_grad_L2vf_add_delta<<<batchsnapnatom,32>>>()

         !message part
         i = atomembeddinglength*2*batchsnapnedge
         batchlabel_d(1:i) = reshape(grad_L2sproj_d,[atomembeddinglength*2*batchsnapnedge])
         icudagroup = batchsnapnedge; icudagroup_d = icudagroup
         call mlp0_network_backward_cuda(gnetsproj(iatt),.false.)
         call cudagnn_batchdata_grad_L2mij_grad_L2mji<<<batchsnapnedge,32>>>(gnetsproj(iatt)%id)

         i = atomembeddinglength*3*batchsnapnatom
         batchlabel_d(1:i) = reshape(grad_L2oproj_d,[atomembeddinglength*3*batchsnapnatom])
         icudagroup = batchsnapnatom; icudagroup_d = icudagroup
         call mlp0_network_backward_cuda(gnetoproj(iatt),.false.)
         call cudagnn_batchdata_grad_L2mij_grad_L2mji_add_grad_L2message<<<batchsnapnedge,32>>>(gnetoproj(iatt)%id)

         call cudagnn_traindata_grad_L2DenseV_grad_L2V<<<batchsnapnedge,32>>>(iatt)

         call cudagnn_traindata_grad_L2attn_grad_L2DenseK_grad_L2K_grad_L2K_grad_L2Q<<<batchsnapnedge,32>>>(iatt)

         call cudagnn_traindata_grad_L2decay<<<(batchsnapnedge-1)/32+1,32>>>(iatt)

         i = atomembeddinglength*batchsnapnatom
         batchlabel_d(1:i) = reshape(grad_L2V_d,[atomembeddinglength*batchsnapnatom])
         icudagroup = batchsnapnatom; icudagroup_d = icudagroup
         call mlp0_network_backward_cuda(gnetnodevalue(iatt),.false.)
         call cudagnn_traindata_grad_L2nf_add_delta<<<batchsnapnatom,32>>>(gnetnodevalue(iatt)%id)

         batchlabel_d(1:i) = reshape(grad_L2Q_d,[atomembeddinglength*batchsnapnatom])
         call mlp0_network_backward_cuda(gnetnodequery(iatt),.false.)
         call cudagnn_traindata_grad_L2nf_add_delta<<<batchsnapnatom,32>>>(gnetnodequery(iatt)%id)

         batchlabel_d(1:i) = reshape(grad_L2K_d,[atomembeddinglength*batchsnapnatom])
         call mlp0_network_backward_cuda(gnetnodekey(iatt),.false.)
         call cudagnn_traindata_grad_L2nf_add_delta<<<batchsnapnatom,32>>>(gnetnodekey(iatt)%id)

         i = atomembeddinglength*batchsnapnedge
         batchlabel_d(1:i) = reshape(grad_L2DenseV_d,[atomembeddinglength*batchsnapnedge])
         icudagroup = batchsnapnedge; icudagroup_d = icudagroup
         call mlp0_network_backward_cuda(gnetedgevalue(iatt),.false.)
         call cudagnn_batchdata_grad_L2ef_add_delta<<<batchsnapnedge,32>>>(gnetedgevalue(iatt)%id)

         batchlabel_d(1:i) = reshape(grad_L2DenseK_d,[atomembeddinglength*batchsnapnedge])
         call mlp0_network_backward_cuda(gnetedgekey(iatt),.false.)
         call cudagnn_batchdata_grad_L2ef_add_delta<<<batchsnapnedge,32>>>(gnetedgekey(iatt)%id)

         if ( (iatt /= nattention) .and. (iatt /= 1) ) then
            batchlabel_d(1:i) = reshape(grad_L2fproj_d,[atomembeddinglength*batchsnapnedge])
            call mlp0_network_backward_cuda(gnetfproj(iatt),.false.)
            call cudagnn_batchdata_grad_L2ef_add_delta<<<batchsnapnedge,32>>>(gnetfproj(iatt)%id)
         end if

         call cudagnn_traindata_delta_grad_L2vf_notnormed_zero<<<batchsnapnatom,32>>>()

         if ( iatt == 1 ) exit

         if ( iatt /= nattention ) then

            i = atomembeddinglength*batchsnapnatom*8
            batchlabel_d(1:i) = reshape(grad_L2wsrcproj_d,[atomembeddinglength*batchsnapnatom*8])
            icudagroup = batchsnapnatom*8; icudagroup_d = icudagroup

            call mlp0_network_backward_cuda(gnetwsrcproj(iatt),.false.)
            call cudagnn_batchdata_grad_L2vf_notnormed_prepare<<<batchsnapnatom,32>>>(gnetwsrcproj(iatt)%id)

            batchlabel_d(1:i) = reshape(grad_L2wtrgproj_d,[atomembeddinglength*batchsnapnatom*8])
            call mlp0_network_backward_cuda(gnetwtrgproj(iatt),.false.)
            call cudagnn_batchdata_grad_L2vf_notnormed_prepare<<<batchsnapnatom,32>>>(gnetwtrgproj(iatt)%id)

         end if

         i = atomembeddinglength*3*batchsnapnatom*8
         batchlabel_d(1:i) = reshape(grad_L2vecproj_d,[atomembeddinglength*3*batchsnapnatom*8])
         icudagroup = batchsnapnatom*8; icudagroup_d = icudagroup

         call mlp0_network_backward_cuda(gnetvecproj(iatt),.false.)
         call cudagnn_batchdata_grad_L2vf_notnormed_prepare<<<batchsnapnatom,32>>>(gnetvecproj(iatt)%id)

         if ( ifuselayernorm ) then
            call cudagnn_traindata_grad_L2vf_normalization1<<<batchsnapnatom,32>>>(iatt-1)
            call cudagnn_traindata_grad_L2vf_normalization2<<<batchsnapnatom,32>>>(iatt-1)
         end if
         call cudagnn_batchdata_grad_L2vf_add_delta<<<batchsnapnatom,32>>>()

         call cudagnn_traindata_batchsnapatomforces_add_grad_L2vf<<<batchsnapnedge,32>>>(iatt-1)

!         call cudagnn_traindata_rejmatrix_batchsnapatomforces<<<batchsnapnedge,32>>>(iatt)

      end do

      i = atomembeddinglength*batchsnapnatom
      batchlabel_d(1:i) = reshape(grad_L2nf_d,[atomembeddinglength*batchsnapnatom]) 
      call cudagnn_batchlabel_for_gnetmain2<<<batchsnapnedge,32>>>()
      icudagroup = batchsnapnatom; icudagroup_d = icudagroup

      call mlp0_network_backward_cuda(gnetmain(2),.false.)
      call cudagnn_traindata_grad_L2decay_add_gnetmain2<<<batchsnapnedge,32>>>(gnetmain(2)%id)
      call cudagnn_traindata_ini_grad_L2atomemb<<<batchsnapnatom,32>>>(gnetmain(2)%id)

      call cudagnn_traindata_grad_L2atomemb_batchabel_for_gnetmain1<<<batchsnapnedge,32>>>(gnetmain(2)%id)
      icudagroup = batchsnapnedge; icudagroup_d = icudagroup
      call mlp0_network_backward_cuda(gnetmain(1),.false.)

      call cudagnn_traindata_grad_L2edgeemb_batchabel_for_gnetmain4<<<batchsnapnedge,32>>>(gnetmain(1)%id)

      call mlp0_network_backward_cuda(gnetmain(4),.false.)
      call cudagnn_traindata_grad_L2edgeemb_plus_gnetmain4_and_grad_L2decay<<<batchsnapnedge,32>>>(gnetmain(4)%id)
      call cudagnn_traindata_batchsnapatomforces_add_grads<<<batchsnapnedge,32>>>()

      if ( present(calloss) ) then
         call cudagnn_traindata_batchsnapatomforces_reverse<<<(batchsnapnatom-1)/32+1,32>>>(.true.)
      else
         call cudagnn_traindata_batchsnapatomforces_reverse<<<(batchsnapnatom-1)/32+1,32>>>(.false.)
      end if

      if ( present(printinfo) ) then
         if ( printinfo .eqv. .true. ) then
            allocate(tpmat2d(3,batchsnapnatom)); tpmat2d = batchsnapatomforces_d
            open(unit=100, file="force_prediction_result.txt", status='old', position='append')
            if ( present(calloss) ) then
               do i = 1, batchsnapnatom
                  write(100,'(3f10.3,a,3f10.3)') tpmat2d(1:3,i),"\t", batchrefsnapatomforces(1:3,i)
               end do
            else
               do i = 1, batchsnapnatom
                  write(100,'(3f10.3)') tpmat2d(1:3,i)
               end do
            end if
            close(100)
            deallocate(tpmat2d)
         end if
      end if

   end subroutine

!=========================== subroutines for initialization

attributes(global) subroutine cudagnn_set_batchdata(istart)
  integer,value :: istart
  integer :: iedge,isnap,iatompos,iedgepos,isnapedgepos,isnapatompos,iatom,jatom
  real(kind=SD) :: tpvec(3),tpdis,sq3,edgediscut

  isnap = blockidx%x; edgediscut = edgediscut_d
  iatompos = batchsnapatomindex_d(isnap)
  iedgepos = batchsnapedgeindex_d(isnap)

  isnap = shuffleidx_d(istart + isnap)
  isnapatompos = snapatomindex_d(isnap)
  isnapedgepos = snapedgeindex_d(isnap)

  sq3 = 1.732050807569_SD
  do iedge = threadidx%x, snapedgenums_d(isnap), 32
     iatom = snapedges_d(1,isnapedgepos+iedge); jatom = snapedges_d(2,isnapedgepos+iedge)
     batchsnapedges_d(1:2,iedgepos+iedge) = [iatompos+iatom,iatompos+jatom]

     iatom = isnapatompos+iatom; jatom = isnapatompos+jatom
     tpvec(1:3) = snapatomcoors_d(:,iatom) - snapatomcoors_d(:,jatom)
     tpdis = sqrt(dot_product(tpvec,tpvec))
     batchedgedistance_d(iedgepos+iedge) = tpdis
     batchedgedisdecays_d(iedgepos+iedge) = max(0.5_SD*(cos(tpdis*pi/edgediscut) + 1.0_SD), 0.000000001_SD)
     grad_decay2dis_d(iedgepos+iedge) = - 0.5_SD*(pi/edgediscut)*sin(tpdis*pi/edgediscut)

     tpvec = tpvec/tpdis
     batchedgedirections_d(1:8,iedgepos+iedge) = [tpvec(1), tpvec(2), tpvec(3), &
              sq3*tpvec(1)*tpvec(3), sq3*tpvec(1)*tpvec(2),    &
              0.5_SD*(3.0_SD*tpvec(2)*tpvec(2) - 1.0_SD), &
              sq3*tpvec(2)*tpvec(3), sq3*0.5_SD*(tpvec(3)*tpvec(3)- tpvec(1)*tpvec(1))]

     grad_dirij2coordi_d(:,:,iedgepos+iedge) = transpose(reshape([1.0_SD-tpvec(1)**2, -tpvec(1)*tpvec(2), -tpvec(1)*tpvec(3), &
           -tpvec(1)*tpvec(2), 1.0_SD-tpvec(2)**2, -tpvec(2)*tpvec(3), &
           -tpvec(1)*tpvec(3), -tpvec(2)*tpvec(3), 1.0_SD-tpvec(3)**2, &
           sq3*tpvec(3)*(1_SD-2_SD*tpvec(1)**2), -2_SD*sq3*tpvec(1)*tpvec(2)*tpvec(3), sq3*tpvec(1)*(1_SD-2_SD*tpvec(3)**2), &
           sq3*tpvec(2)*(1_SD-2_SD*tpvec(1)**2), sq3*tpvec(1)*(1_SD-2_SD*tpvec(2)**2), -2_SD*sq3*tpvec(1)*tpvec(2)*tpvec(3), &
           -3_SD*tpvec(1)*tpvec(2)**2, 3_SD*tpvec(2)*(1_SD-tpvec(2)**2), -3_SD*tpvec(3)*tpvec(2)**2, &
           -2_SD*sq3*tpvec(1)*tpvec(2)*tpvec(3), sq3*tpvec(3)*(1_SD-2_SD*tpvec(2)**2), sq3*tpvec(2)*(1_SD-2_SD*tpvec(3)**2), &
           -sq3*tpvec(1)*(tpvec(2)**2+2_SD*tpvec(3)**2), sq3*tpvec(2)*(tpvec(1)**2-tpvec(3)**2), sq3*tpvec(3)*(tpvec(2)**2+2_SD*tpvec(1)**2)],[3,8]))
     grad_dirij2coordi_d(:,:,iedgepos+iedge) = grad_dirij2coordi_d(:,:,iedgepos+iedge) / tpdis

  end do
end subroutine

!=========================== subroutines for forward propagations

attributes(global) subroutine cudagnn_batchdata_set_zero(tpsize)
  integer,value :: tpsize
  integer :: idx
  do idx = threadidx%x, tpsize, 32
     batchdata_d(idx) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdadta_for_gnetatomemb()
  integer :: iatomtype,jatomtype,ipos

  iatomtype = blockidx%x
  do jatomtype = threadidx%x, maxatomtype_d, 32
     ipos = (iatomtype-1)*maxatomtype_d + jatomtype
     if ( jatomtype == iatomtype ) then
        batchdata_d(ipos) = 1.0_SD
     else
        batchdata_d(ipos) = 0.0_SD
     end if
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchatomembeddings(id)
  integer,value :: id
  integer :: iemb,iatomtype,istate,iatom

  iatom = blockidx%x; iatomtype = batchatomtype_d(iatom)+1
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatomtype-1)*atomembeddinglength_d*2
  do iemb = threadidx%x, atomembeddinglength_d*2, 32
     batchatomembeddings_d(iemb,iatom) = hiddenstate_d(istate+iemb)
  end do
end subroutine

attributes(global) subroutine  cudagnn_traindata_edgeembmeans_edgeembbetas_batchedgeembeddings(id)
  integer,value :: id
  integer :: iemb,iedge,istate
  real(kind=SD) :: expdis

  iedge = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d)

  if ( iedge == 1 ) then
     do iemb = threadidx%x, edgeembeddinglength_d, 32
        edgeembmeans_d(iemb) = hiddenstate_d(istate+iemb); edgeembbetas_d(iemb) = hiddenstate_d(istate+iemb+edgeembeddinglength_d)
     end do
  end if
  expdis = exp(-batchedgedistance_d(iedge))
  do iemb = threadidx%x, edgeembeddinglength_d, 32
     batchedgeembeddings_d(iemb,iedge) = batchedgedisdecays_d(iedge)*   &
            exp(-(expdis - hiddenstate_d(istate+iemb))**2 * hiddenstate_d(istate+iemb+edgeembeddinglength_d))
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_largeedgeembeddings_for_edge(id)
  integer,value :: id
  integer :: iemb,iedge,istate

  iedge = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iedge-1)*atomembeddinglength_d
  do iemb = threadidx%x, atomembeddinglength_d, 32
     largeedgeembeddings_for_edge_d(iemb,iedge) = hiddenstate_d(istate+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_for_gnetmain1()
  integer :: iedge,iemb

  iedge = (blockidx%x-1)*edgeembeddinglength_d
  do iemb = threadidx%x, edgeembeddinglength_d, 32
     batchdata_d(iedge + iemb) = batchedgeembeddings_d(iemb, blockidx%x)
  end do
end subroutine

attributes(global) subroutine cudagnn_edge_message_aggregation(id)
  integer,value :: id
  integer :: iemb,iedge,iatom,jatom,ipos,jpos,istate
  real(kind=SD) :: tpvalue1,tpvalue2,tpdecay,tpemb

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iedge-1)*atomembeddinglength_d
  tpdecay = batchedgedisdecays_d(iedge)
  jpos = (jatom-1)*2*atomembeddinglength_d
  do iemb = threadidx%x, atomembeddinglength_d, 32
     tpemb = hiddenstate_d(istate+iemb)
     largeedgeembeddings_d(iemb,iedge) = tpemb
     tpvalue1 = tpemb*tpdecay*batchatomembeddings_d(iemb,iatom)
     tpvalue2 = atomicadd(batchdata_d(jpos+iemb),tpvalue1)
  end do
end subroutine

attributes(global) subroutine cudagnn_edge_message_aggregation2()
  integer :: iatom,iemb,ipos1,ipos2,nemb

  iatom = blockidx%x; nemb = atomembeddinglength_d
  ipos1 = (iatom-1)*2*nemb
  ipos2 = ipos1 + nemb
  do iemb = threadidx%x, nemb, 32
     batchdata_d(ipos2+iemb) = batchatomembeddings_d(nemb+iemb,iatom)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_nodefeatures(id)
  integer,value :: id
  integer :: iemb,iatom,istate

  iatom = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*atomembeddinglength_d

  do iemb = threadidx%x, atomembeddinglength_d, 32
     nodefeatures_of_first_layer_d(iemb,iatom) = hiddenstate_d(istate+iemb)
     nodefeatures_d(iemb,iatom) = hiddenstate_d(istate+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_edgefeatures()
  integer :: iemb,iedge,iatom,jatom

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  do iemb = threadidx%x, atomembeddinglength_d, 32
     edgefeatures_d(iemb,iedge) = largeedgeembeddings_for_edge_d(iemb,iedge)*   &
                                  (nodefeatures_d(iemb,iatom) + nodefeatures_d(iemb,jatom))
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_node_qkv(id,iatt,itype)
  integer,value :: id,iatt,itype
  integer :: iemb,iatom,ipos,ihead,istate

  iatom = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*atomembeddinglength_d

  do iemb = threadidx%x, atomembeddinglength_d, 32
     ihead = (iemb-1)/headsize_d + 1
     ipos = iemb - (ihead-1)*headsize_d
     select case(itype)
        case (1); batchnodequery_d(ipos,ihead,iatom,iatt) = hiddenstate_d(istate+iemb)
        case (2); batchnodekey_d(ipos,ihead,iatom,iatt) = hiddenstate_d(istate+iemb)
        case (3); batchnodevalue_d(ipos,ihead,iatom,iatt) = hiddenstate_d(istate+iemb)
     end select
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchvecdiht_batchvecdihs(id,iatt,itype)
  integer,value :: id,iatt,itype
  integer :: iemb,iatom,idim,istate,nemb

  iatom = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1; nemb = atomembeddinglength_d
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*nemb*8

  do iemb = threadidx%x, nemb, 32
     do idim = 1, 8
        if ( itype == 1 ) then
           batchvecdiht_d(iemb,idim,iatom,iatt) = hiddenstate_d(istate+(idim-1)*nemb+iemb)
        else if ( itype == 2 ) then
           batchvecdihs_d(iemb,idim,iatom,iatt) = hiddenstate_d(istate+(idim-1)*nemb+iemb)
        end if
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchvect_batchvecs_batchvecv(id,iatt)
  integer,value :: id,iatt
  integer :: iemb,iatom,ipos,istate,stride,nemb,ivec

  iatom = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  nemb = atomembeddinglength_d; stride = nemb*3
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*stride*8

  do iemb = threadidx%x, nemb, 32
     ipos = istate + iemb
     do ivec = 1, 8
        batchvect_d(iemb,ivec,iatom,iatt) = hiddenstate_d(ipos+(ivec-1)*stride)
        batchvecs_d(iemb,ivec,iatom,iatt) = hiddenstate_d(ipos+(ivec-1)*stride+nemb)
        batchvecv_d(iemb,ivec,iatom,iatt) = hiddenstate_d(ipos+(ivec-1)*stride+nemb*2)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchvecdiht_batchvecdihs_batchvect_batchvecs_batchvecv_zero(iatt)
  integer,value :: iatt
  integer :: iemb,iatom

  iatom = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     batchvect_d(iemb,:,iatom,iatt) = 0.0_SD 
     batchvecs_d(iemb,:,iatom,iatt) = 0.0_SD
     batchvecv_d(iemb,:,iatom,iatt) = 0.0_SD
  end do

  if ( iatt /= nattention_d ) then
     do iemb = threadidx%x, atomembeddinglength_d, 32
        batchvecdiht_d(iemb,:,iatom,iatt) = 0.0_SD
        batchvecdihs_d(iemb,:,iatom,iatt) = 0.0_SD
     end do
  end if 
end subroutine

attributes(global) subroutine cudagnn_traindata_batchedgekey_batchedgevalue(id,iatt,itype)
  integer,value :: id,iatt,itype
  integer :: iemb,iedge,ipos,ihead,istate
  real(kind=SD) :: tpvalue,tpgrad
  iedge = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iedge-1)*atomembeddinglength_d

  select case(itype)
  case(2)
     do iemb = threadidx%x, atomembeddinglength_d, 32
        ihead = (iemb-1)/headsize_d + 1
        ipos = iemb - (ihead-1)*headsize_d
        batchedgekey_d(ipos,ihead,iedge,iatt) = hiddenstate_d(istate+iemb)
     end do
  case(3)
     do iemb = threadidx%x, atomembeddinglength_d, 32
        ihead = (iemb-1)/headsize_d + 1
        ipos = iemb - (ihead-1)*headsize_d
        batchedgevalue_d(ipos,ihead,iedge,iatt) = hiddenstate_d(istate+iemb)
     end do
  end select
end subroutine

attributes(global) subroutine cudagnn_traindata_batchedgedih(id,iatt)
  integer,value :: id,iatt
  integer :: iemb,iedge,istate

  iedge = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iedge-1)*atomembeddinglength_d
  do iemb = threadidx%x, atomembeddinglength_d, 32
     batchedgedih_d(iemb,iedge,iatt) = hiddenstate_d(istate+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_headattentions(iatt)
  integer,value :: iatt
  integer :: iedge,ihead,iatom,jatom,iemb
  real(kind=SD) :: tpvalue,tpsum

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  do ihead = 1, headnum_d
     tpsum = 0.0_SD
     do iemb = threadidx%x, headsize_d, 32
        tpsum = tpsum + batchedgekey_d(iemb,ihead,iedge,iatt)*    &
                (batchnodequery_d(iemb,ihead,jatom,iatt)*batchnodekey_d(iemb,ihead,iatom,iatt))
     end do

     iemb = 1
     do while (iemb<=16)
        tpvalue = __shfl_xor(tpsum,iemb); tpsum = tpsum + tpvalue
        iemb = iemb*2
     end do

     if ( threadidx%x == 1 ) then
        call deeppub_activation_function_cuda(tpsum,tpvalue,grad_attenactiv_d(ihead,iedge,iatt))
        headattentions_d(ihead,iedge,iatt) = tpvalue*batchedgedisdecays_d(iedge)
     end if
  end do
  
end subroutine

attributes(global) subroutine cudagnn_message_and_vecmessage_set_zero()
  integer :: iatom,iemb
  iatom = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     message_d(iemb,iatom) = 0.0_SD
     vecmessage_d(iemb,:,iatom) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_message_batchdata_gnetsproj(iatt,gnnmode)
  integer,value :: iatt,gnnmode
  integer :: istart,iemb,ihead,iedge,iatom,jatom,headsize,stride,ipos
  real(kind=SD) :: tpvalue,tpval

  iedge = blockidx%x; headsize = headsize_d
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  stride = atomembeddinglength_d*batchsnapnedge_d
  istart = (iedge-1)*atomembeddinglength_d
  if ( gnnmode == 2 ) then
     do ihead = 1, headnum_d
        ipos = (ihead-1)*headsize
        do iemb = threadidx%x, headsize, 32
           tpval = headattentions_d(ihead,iedge,iatt)*batchedgevalue_d(iemb,ihead,iedge,iatt)
           tpvalue = atomicadd(nodefeatures_d(ipos+iemb,jatom), tpval*batchnodevalue_d(iemb,ihead,iatom,iatt))
        end do
     end do
  else if (  gnnmode == 4 ) then
     do ihead = 1, headnum_d
        ipos = (ihead-1)*headsize
        do iemb = threadidx%x, headsize, 32
           tpval = headattentions_d(ihead,iedge,iatt)*batchedgevalue_d(iemb,ihead,iedge,iatt)
           tpvalue = tpval*batchnodevalue_d(iemb,ihead,iatom,iatt)
           batchdata_d(istart+ipos+iemb) = tpvalue
           tpvalue = atomicadd(message_d(ipos+iemb,jatom),tpvalue)
        end do
     end do
  else if ( gnnmode == 3 ) then
     do ihead = 1, headnum_d
        ipos = (ihead-1)*headsize
        do iemb = threadidx%x, headsize, 32
           tpvalue = batchedgevalue_d(iemb,ihead,iedge,iatt)*batchnodevalue_d(iemb,ihead,iatom,iatt)
           batchdata_d(istart+ipos+iemb) = tpvalue
           tpvalue = atomicadd(message_d(ipos+iemb,jatom),tpvalue)
        end do
     end do
  end if
end subroutine

attributes(global) subroutine cudagnn_traindata_batchmijvec_batchmjivec(id,iatt)
  integer,value :: id,iatt
  integer :: iedge,iemb,istate,nemb,stride
  real(kind=SD) :: tpvalue,tpgrad

  iedge = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  nemb = atomembeddinglength_d; stride = nemb*batchsnapnedge_d*2
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iedge-1)*nemb*2
 
  do iemb = threadidx%x, nemb, 32
     batchmijdir_d(iemb,iedge,iatt) = hiddenstate_d(istate+iemb)
     batchmijvec_d(iemb,iedge,iatt) = hiddenstate_d(istate+nemb+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_vecmessage(iatt)
  integer,value :: iatt
  integer :: iedge,iatom,jatom,iemb,idim
  real(kind=SD) :: tpvalue

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  do iemb = threadidx%x, atomembeddinglength_d, 32
     do idim = 1, 8
        tpvalue = atomicadd(vecmessage_d(iemb,idim,jatom),                 &
            batchmijdir_d(iemb,iedge,iatt)*batchedgedirections_d(idim,iedge) +  &
            batchmijvec_d(iemb,iedge,iatt)*vecfeatures_normed_d(iemb,idim,iatom,iatt-1))
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchmessagevm_batchmessageangle_batchmessageres(id,iatt)
  integer,value :: id,iatt
  integer :: iatom,istate,iemb,nemb

  iatom = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1; nemb = atomembeddinglength_d
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*nemb*3
  do iemb = threadidx%x, nemb, 32
     batchmessagevm_d(iemb,iatom,iatt) = hiddenstate_d(istate+iemb)
     batchmessageangle_d(iemb,iatom,iatt) = hiddenstate_d(istate+nemb+iemb)
     batchmessageres_d(iemb,iatom) = hiddenstate_d(istate+nemb+nemb+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_vecfeatures_nodefeatures(iatt)
  integer,value :: iatt
  integer :: iatom,iemb,idim

  iatom = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     vecfeatures_d(iemb,:,iatom,iatt) = vecfeatures_d(iemb,:,iatom,iatt-1) + &
           vecmessage_d(iemb,:,iatom) + batchmessagevm_d(iemb,iatom,iatt)*batchvecv_d(iemb,:,iatom,iatt)
     nodefeatures_d(iemb,iatom) = nodefeatures_d(iemb,iatom) + batchmessageangle_d(iemb,iatom,iatt)*sum(batchvect_d(iemb,:,iatom,iatt)*batchvecs_d(iemb,:,iatom,iatt))+batchmessageres_d(iemb,iatom)
  end do
end subroutine

attributes(global) subroutine cudagnn_vecfeature_normsigma(iatt)
  integer,value :: iatt
  integer :: iemb,iatom
  real(kind=SD) :: tpvalue,tpsum13,tpsum48

  iatom = blockidx%x; tpsum13 = 0.0_SD; tpsum48 = 0.0_SD
  do iemb = threadidx%x, atomembeddinglength_d, 32
     tpvalue = sum(vecfeatures_d(iemb,1:3,iatom,iatt)**2)
     tpsum13 = tpsum13 + tpvalue
     tpvalue = sum(vecfeatures_d(iemb,4:8,iatom,iatt)**2)
     tpsum48 = tpsum48 + tpvalue
  end do
  call syncthreads()

  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpsum13,iemb); tpsum13 = tpsum13 + tpvalue
     tpvalue = __shfl_xor(tpsum48,iemb); tpsum48 = tpsum48 + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     vecfeatures_normsigma1_d(iatom,iatt) = sqrt(tpsum13/real(atomembeddinglength_d,kind=SD) + 0.0000000000000001_SD)
     vecfeatures_normsigma2_d(iatom,iatt) = sqrt(tpsum48/real(atomembeddinglength_d,kind=SD) + 0.0000000000000001_SD)
  end if
end subroutine

attributes(global) subroutine cudagnn_vecfeature_layernorm(iatt)
  integer,value :: iatt
  integer :: iemb,iatom
  real(kind=SD) :: tpvalue1,tpvalue2

  iatom = blockidx%x
  tpvalue1 = vecfeatures_normsigma1_d(iatom,iatt)*2.0_SD
  tpvalue2 = vecfeatures_normsigma2_d(iatom,iatt)*2.0_SD
  do iemb = threadidx%x, atomembeddinglength_d, 32
     vecfeatures_normed_d(iemb,1:3,iatom,iatt) = vecfeatures_d(iemb,1:3,iatom,iatt) / tpvalue1
     vecfeatures_normed_d(iemb,4:8,iatom,iatt) = vecfeatures_d(iemb,4:8,iatom,iatt) / tpvalue2
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_edgefeatures_in_attention(iatt)
  integer,value :: iatt
  integer :: iedge,iatom,jatom,iemb

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  do iemb = threadidx%x, atomembeddinglength_d, 32
     edgefeatures_d(iemb,iedge) =  edgefeatures_d(iemb,iedge) + batchedgedih_d(iemb,iedge,iatt)*  &
               sum(batchvecdiht_d(iemb,:,jatom,iatt)*batchvecdihs_d(iemb,:,iatom,iatt))
  end do
end subroutine

attributes(global) subroutine cudagnn_batchvecoutput1_batchdata_for_gnetupdate(id)
  integer,value :: id
  integer :: istate,iemb,iatom,ipos,nemb,idim,nembstep

  iatom = blockidx%x; nemb = atomembeddinglength_d; nembstep = nemb+nemb/2
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*8*nembstep

  do iemb = threadidx%x, nembstep, 32
     do idim = 1, 8
        batchvecoutput1_d(iemb,idim,iatom) = hiddenstate_d(istate+(idim-1)*nembstep+iemb)
     end do
  end do

  ipos = (blockidx%x-1)*nemb*2
  do iemb = threadidx%x, nemb, 32
     batchdata_d(ipos+iemb) = nodefeatures_d(iemb,iatom)
     batchdata_d(ipos+nemb+iemb) = sqrt(sum(batchvecoutput1_d(iemb,:,iatom)**2))
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchoutputx(id)
  integer,value :: id
  integer :: iemb,iatom,istate

  iatom = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*atomembeddinglength_d/2
  do iemb = threadidx%x, atomembeddinglength_d/2, 32
     batchoutputx_d(iemb,iatom) = hiddenstate_d(istate+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchupdate12_batchoutputv(id)
  integer,value :: id
  integer :: iemb,iatom,nemb,dim,istate
  real(kind=SD) :: tpvalue

  iatom = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*nemb/2

  do iemb = threadidx%x, nemb/2, 32
     tpvalue = hiddenstate_d(istate+iemb)
     batchupdate12_d(iemb,iatom) = tpvalue
     do dim = 1, 8
        batchoutputv_d(iemb,dim,iatom) = tpvalue * batchvecoutput1_d(nemb+iemb,dim,iatom)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_for_gnetupdate2(id)
  integer,value :: id
  integer :: istate,iemb,iatom,ipos,nemb,idim,nembstep
  real(kind=SD) :: tpsum,tpvalue

  iatom = blockidx%x; nemb = atomembeddinglength_d; nembstep = nemb/2+1
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d) + (iatom-1)*8*nembstep

  do idim = threadidx%x, 8
     batchvecoutput2_d(nembstep,idim,iatom) = hiddenstate_d(istate+idim*nembstep)
  end do

  ipos = (blockidx%x-1)*atomembeddinglength_d
  do iemb = threadidx%x, nemb/2, 32
     batchdata_d(ipos+iemb) = batchoutputx_d(iemb,iatom)
     tpsum = 0.0_SD
     do idim = 1, 8
        tpvalue = hiddenstate_d(istate+(idim-1)*nembstep+iemb)
        batchvecoutput2_d(iemb,idim,iatom) = tpvalue
        tpsum = tpsum + tpvalue**2
     end do
     tpsum = sqrt(tpsum)
     batchvecoutput2sumsq_d(iemb,iatom) = tpsum
     batchdata_d(ipos+nemb/2+iemb) = tpsum
     ! batchdata_d(ipos+nemb/2+iemb) = sqrt(sum(batchvecoutput2_d(iemb,:,iatom)**2))
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchoutputx2(id)
  integer,value :: id
  integer :: iatom,istate

  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > batchsnapnatom_d ) return
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d)
  batchoutputx_d(1,iatom) = hiddenstate_d(istate+iatom)
end subroutine

attributes(global) subroutine cudagnn_traindata_batchoutputv_batchoutputx(id)
  integer,value :: id
  integer :: iatom,istate

  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > batchsnapnatom_d ) return
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+net(id)%nlayer_d)
  batchoutputx_d(1,iatom) = batchoutputx_d(1,iatom) + hiddenstate_d(istate+iatom) * sum(batchvecoutput2_d(atomembeddinglength_d/2+1,1:8,iatom)) * 0.0_SD
end subroutine

!=========================== subroutines for loss function

attributes(global) subroutine cudagnn_calculate_loss_function(calloss)
!  integer,value :: id
  logical,value :: calloss
  integer :: iatom,imol,istate,iemb
  real(kind=SD) :: tpene,tpvalue

  imol = blockidx%x; tpene = 0.0_SD 
  do iatom = batchsnapatomindex_d(imol)+threadidx%x, batchsnapatomindex_d(imol+1), 32
     tpene = tpene + batchoutputx_d(1,iatom)
  end do

  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpene,iemb); tpene = tpene + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     batchsnapenergies_d(imol) = tpene
     if ( calloss .eqv. .false. ) return
     select case (lossfunctype_d)
        case (RMSE)
           tpvalue = atomicadd(totenergyloss_d, (tpene - batchrefsnapenergies_d(imol))**2)
        case (MAE)
           tpvalue = atomicadd(totenergyloss_d, abs(tpene - batchrefsnapenergies_d(imol)))
     end select
  end if
end subroutine

!=========================== subroutines for backward propagations

attributes(global) subroutine cudagnn_batchlabel_for_grad_L2atomenergy_and_gnetmain3(calloss)
  logical,value :: calloss
  integer :: iatom,imol,ipos
  imol = blockidx%x
  if ( calloss .eqv. .true. ) then
     do iatom = batchsnapatomindex_d(imol)+threadidx%x, batchsnapatomindex_d(imol+1), 32
        batchlabel_d(iatom) = (1.0_SD-forceweight_d)*2.0_SD*(batchsnapenergies_d(imol) - batchrefsnapenergies_d(imol))
        grad_L2atomenergy_d(iatom) = batchlabel_d(iatom)
     end do
  else
     do iatom = batchsnapatomindex_d(imol)+threadidx%x, batchsnapatomindex_d(imol+1), 32
        batchlabel_d(iatom) = 1.0_SD
        grad_L2atomenergy_d(iatom) = 1.0_SD
     end do
  end if

  do iatom = batchsnapatomindex_d(imol)+threadidx%x, batchsnapatomindex_d(imol+1), 32
     grad_L2outx2_d(1,iatom) = grad_L2atomenergy_d(iatom)
     grad_L2outv2_d(1,:,iatom) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2outx1_grad_L2outvecnorm2head(id)
  integer,value :: id
  integer :: iemb,istate,iatom,nemb

  iatom = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*nemb
  do iemb = threadidx%x, nemb/2, 32
     grad_L2outx1_d(iemb,iatom) = hiddenstate_d(istate+iemb)
     grad_L2outvecnorm2head_d(iemb,iatom) = hiddenstate_d(istate+nemb/2+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2outx1_grad_L2outvecnorm2head_grad_L2vecout2(id)
  integer,value :: id
  integer :: idim,iemb,istate,iatom,nemb
  real(kind=SD) :: tpvalue

  iatom = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*nemb
  do iemb = threadidx%x, nemb/2, 32
     grad_L2outx1_d(iemb,iatom) = grad_L2outx1_d(iemb,iatom) + hiddenstate_d(istate+iemb)
     tpvalue = grad_L2outvecnorm2head_d(iemb,iatom) + hiddenstate_d(istate+nemb/2+iemb)
     grad_L2outvecnorm2head_d(iemb,iatom) = tpvalue
     tpvalue = tpvalue/batchvecoutput2sumsq_d(iemb,iatom)
     do idim = 1, 8
        grad_L2vecout2_d(iemb,idim,iatom) = tpvalue * batchvecoutput2_d(iemb,idim,iatom)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2outv1(id)
  integer,value :: id
  integer :: idim,iemb,istate,iatom,halfnemb

  iatom = blockidx%x; halfnemb = atomembeddinglength_d/2
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*halfnemb*8
  do iemb = threadidx%x, halfnemb, 32
     do idim = 1, 8
        grad_L2outv1_d(iemb,idim,iatom) = hiddenstate_d(istate+(idim-1)*halfnemb+iemb)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2outx_grad_L2outvecnorm1head_batchlabel_for_gnetupdate12(id)
  integer,value :: id
  integer :: iemb,istate,iatom,nemb

  iatom = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*nemb*2
  do iemb = threadidx%x, nemb, 32
     grad_L2outx_d(iemb,iatom) = hiddenstate_d(istate+iemb)
     grad_L2outvecnorm1head_d(iemb,iatom) =  hiddenstate_d(istate+nemb+iemb)
  end do
  do iemb = threadidx%x, nemb/2, 32
     batchlabel_d((iatom-1)*nemb/2+iemb) = sum(grad_L2outv1_d(iemb,:,iatom) * batchvecoutput1_d(nemb+iemb,:,iatom))
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2nf_batchlabel_for_gnetvecoutput1(id)
  integer,value :: id
  integer :: idim,iemb,istate,iatom,nemb,nembstep,ipos
  real(kind=SD) :: tpvalue

  iatom = blockidx%x; nemb = atomembeddinglength_d; nembstep = nemb+nemb/2
  ipos = (iatom-1)*8*nembstep
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*nemb*2
  do iemb = threadidx%x, nemb, 32
     grad_L2nf_d(iemb,iatom) = grad_L2outx_d(iemb,iatom) + hiddenstate_d(istate+iemb)
     tpvalue = grad_L2outvecnorm1head_d(iemb,iatom) + hiddenstate_d(istate+nemb+iemb)
     tpvalue = tpvalue / sqrt(sum(batchvecoutput1_d(iemb,:,iatom)**2))
     do idim = 1, 8
        !grad_L2vecout1_d(iemb,idim,iatom) = tpvalue * batchvecoutput1_d(iemb,idim,iatom)
        batchlabel_d(ipos+(idim-1)*nembstep+iemb) = tpvalue * batchvecoutput1_d(iemb,idim,iatom)
     end do
  end do
  do iemb = threadidx%x, nemb/2, 32
     do idim = 1, 8
        !grad_L2vecout1_d(nemb+iemb,idim,iatom) = grad_L2outv1_d(iemb,idim,iatom)*batchupdate12_d(iemb,iatom)
        batchlabel_d(ipos+(idim-1)*nembstep+nemb+iemb) = grad_L2outv1_d(iemb,idim,iatom)*batchupdate12_d(iemb,iatom)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2nf_delta_grad_L2vf_notnormed(id)
  integer,value :: id
  integer :: idim,iemb,istate,iatom,nemb

  iatom = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*nemb*8
  do iemb = threadidx%x, nemb, 32
     do idim = 1, 8
        delta_grad_L2vf_notnormed_d(iemb,idim,iatom) = hiddenstate_d(istate+(idim-1)*nemb+iemb)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2vf_normalization1(iatt)
  integer,value :: iatt
  integer :: iatom,iemb,idim
  real(kind=SD) :: tpsum1,tpsum2,tpsigma1,tpsigma2,tpvalue

  iatom = blockidx%x; tpsum1 = 0.0_SD; tpsum2 = 0.0_SD
  tpsigma1 = vecfeatures_normsigma1_d(iatom,iatt) * 2.0_SD
  tpsigma2 = vecfeatures_normsigma2_d(iatom,iatt) * 2.0_SD
  do iemb = threadidx%x, atomembeddinglength_d,32
     do idim = 1, 3
        tpvalue = delta_grad_L2vf_notnormed_d(iemb,idim,iatom)/tpsigma1
        delta_grad_L2vf_notnormed_d(iemb,idim,iatom) = tpvalue
        tpsum1 = tpsum1 + tpvalue * vecfeatures_normed_d(iemb,idim,iatom,iatt)
     end do
     do idim = 4, 8
        tpvalue = delta_grad_L2vf_notnormed_d(iemb,idim,iatom)/tpsigma2
        delta_grad_L2vf_notnormed_d(iemb,idim,iatom) = tpvalue
        tpsum2 = tpsum2 + tpvalue * vecfeatures_normed_d(iemb,idim,iatom,iatt)
     end do
  end do
  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpsum1,iemb); tpsum1 = tpsum1 + tpvalue
     tpvalue = __shfl_xor(tpsum2,iemb); tpsum2 = tpsum2 + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     grad_L2vf_dot_vecfeature13_d(iatom) = tpsum1
     grad_L2vf_dot_vecfeature48_d(iatom) = tpsum2
  end if
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2vf_normalization2(iatt)
  integer,value :: iatt
  integer :: iatom,iemb,idim
  real(kind=SD) :: tpembinv,tpsum1,tpsum2

  iatom = blockidx%x
  tpsum1 = grad_L2vf_dot_vecfeature13_d(iatom)
  tpsum2 = grad_L2vf_dot_vecfeature48_d(iatom)
  tpembinv = 4.0_SD/real(atomembeddinglength_d,kind=SD)
  do iemb = threadidx%x, atomembeddinglength_d,32
     do idim = 1, 3
        delta_grad_L2vf_notnormed_d(iemb,idim,iatom) = delta_grad_L2vf_notnormed_d(iemb,idim,iatom) - tpsum1*vecfeatures_normed_d(iemb,idim,iatom,iatt)*tpembinv
     end do
     do idim = 4, 8
        delta_grad_L2vf_notnormed_d(iemb,idim,iatom) = delta_grad_L2vf_notnormed_d(iemb,idim,iatom) - tpsum2*vecfeatures_normed_d(iemb,idim,iatom,iatt)*tpembinv
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2decay_batchsnapatomforces_zero()
  integer :: iedge
  iedge = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iedge > batchsnapnedge_d ) return
  grad_L2decay_d(iedge) = 0.0_SD
  if ( iedge <= batchsnapnatom_d ) then
     batchsnapatomforces_d(1:3,iedge) = 0.0_SD
  end if
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2ef_zero()
  integer :: iedge,iemb
  iedge = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     grad_L2ef_d(iemb,iedge) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_batchsnapatomforces_add_grad_L2vf(iatt)
  integer,value :: iatt
  integer :: iedge,iatom,jatom,iemb,iaxis
  real(kind=SD) :: tpvec(3),tpvalue,tpeneinv

  iedge = blockidx%x; tpvec(:) = 0.0_SD
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  tpeneinv = 1.0_SD / grad_L2atomenergy_d(iatom)
  do iemb = threadidx%x, atomembeddinglength_d,32
     tpvalue = batchmijdir_d(iemb,iedge,iatt) * tpeneinv
     do iaxis = 1, 3
        tpvec(iaxis) = tpvec(iaxis) + tpvalue * dot_product(grad_L2vf_d(iemb,:,jatom),grad_dirij2coordi_d(:,iaxis,iedge))
     end do
  end do
 
  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpvec(1),iemb); tpvec(1) = tpvec(1) + tpvalue
     tpvalue = __shfl_xor(tpvec(2),iemb); tpvec(2) = tpvec(2) + tpvalue
     tpvalue = __shfl_xor(tpvec(3),iemb); tpvec(3) = tpvec(3) + tpvalue
     iemb = iemb*2
  end do
 
  if ( threadidx%x == 1 ) then
     do iaxis = 1, 3
        tpvalue = atomicadd(batchsnapatomforces_d(iaxis,iatom), tpvec(iaxis))
        tpvalue = atomicadd(batchsnapatomforces_d(iaxis,jatom), -tpvec(iaxis))
     end do
  end if
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2mij_grad_L2mji()
  integer :: iemb,iedge,iatom,jatom

  iedge = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d,32
     iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
     grad_L2mij_d(iemb,iedge)=grad_L2nf_d(iemb,jatom)
  end do
end subroutine

attributes(global) subroutine cudagnn_grad_L2K_grad_L2V_grad_L2Q_zero()
 integer :: iatom,iemb
 iatom = blockidx%x
 do iemb = threadidx%x, headsize_d, 32
    grad_L2K_d(iemb,:,iatom) = 0.0_SD 
    grad_L2Q_d(iemb,:,iatom) = 0.0_SD
    grad_L2V_d(iemb,:,iatom) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2vecproj_grad_L2oproj(iatt)
  integer,value :: iatt
  integer :: iemb,dim,nemb,iatom
  real(kind=SD) :: tpvalue

  iatom = blockidx%x; nemb = atomembeddinglength_d

  do iemb = threadidx%x, nemb, 32
     tpvalue = grad_L2nf_d(iemb,iatom)*batchmessageangle_d(iemb,iatom,iatt)
     do dim = 1, 8
        grad_L2vecproj_d(iemb,dim,iatom) = tpvalue*batchvecs_d(iemb,dim,iatom,iatt)
        grad_L2vecproj_d(nemb+iemb,dim,iatom) = tpvalue*batchvect_d(iemb,dim,iatom,iatt)
        grad_L2vecproj_d(nemb*2+iemb,dim,iatom) = grad_L2vf_d(iemb,dim,iatom)*batchmessagevm_d(iemb,iatom,iatt)
     end do
     grad_L2oproj_d(iemb,iatom)=sum(grad_L2vf_d(iemb,:,iatom)*batchvecv_d(iemb,:,iatom,iatt))
     tpvalue = grad_L2nf_d(iemb,iatom)
     grad_L2oproj_d(nemb+iemb,iatom) = tpvalue*sum(batchvect_d(iemb,:,iatom,iatt)*batchvecs_d(iemb,:,iatom,iatt))
     grad_L2oproj_d(nemb*2+iemb,iatom) = tpvalue
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2wsrcproj_grad_L2wtrgproj_zero()
  integer :: iedge,iatom,jatom,idim,iemb

  iatom = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     grad_L2wtrgproj_d(iemb,:,iatom) = 0.0_SD; grad_L2wsrcproj_d(iemb,:,iatom) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2wsrcproj_grad_L2wtrgproj_grad_L2fproj(iatt)
  integer,value :: iatt
  integer :: iedge,iatom,jatom,idim,iemb
  real(kind=SD) :: tp,tpfactor

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  do iemb = threadidx%x, atomembeddinglength_d, 32
     tpfactor = grad_L2ef_d(iemb,iedge)*batchedgedih_d(iemb,iedge,iatt)
     do idim = 1, 8
        tp = atomicadd( grad_L2wtrgproj_d(iemb,idim,jatom), tpfactor*batchvecdihs_d(iemb,idim,iatom,iatt) )
        tp = atomicadd( grad_L2wsrcproj_d(iemb,idim,iatom), tpfactor*batchvecdiht_d(iemb,idim,jatom,iatt) )
     end do
     grad_L2fproj_d(iemb,iedge) = grad_L2ef_d(iemb,iedge)*   &
            sum(batchvecdiht_d(iemb,:,jatom,iatt)*batchvecdihs_d(iemb,:,iatom,iatt))
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_upper_grad_L2vf_and_delta_grad_L2vf_notnormed()
  integer :: iatom,iemb

  iatom = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     upper_grad_L2vf_d(iemb,:,iatom) = grad_L2vf_d(iemb,:,iatom)
     delta_grad_L2vf_notnormed_d(iemb,:,iatom) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2sproj_grad_L2vf(iatt) 
  integer,value :: iatt
  integer :: iemb,iedge,nemb,iatom,jatom,idim
  real(kind=SD) :: tpvalue

  iedge = blockidx%x; nemb = atomembeddinglength_d
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  do iemb = threadidx%x, nemb, 32
     grad_L2sproj_d(iemb,iedge) = dot_product(upper_grad_L2vf_d(iemb,:,jatom),batchedgedirections_d(:,iedge))
     grad_L2sproj_d(nemb+iemb,iedge) = sum(upper_grad_L2vf_d(iemb,:,jatom)*vecfeatures_normed_d(iemb,:,iatom,iatt-1))
     do idim = 1, 8
        tpvalue = upper_grad_L2vf_d(iemb,idim,jatom)*batchmijvec_d(iemb,iedge,iatt)
        tpvalue = atomicadd(delta_grad_L2vf_notnormed_d(iemb,idim,iatom),tpvalue)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_grad_L2mij_grad_L2mji(id)
  integer,value :: id
  integer :: iemb,iedge,istate,nemb

  iedge = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iedge-1)*nemb

  do iemb = threadidx%x, nemb, 32
     grad_L2mij_d(iemb,iedge) = hiddenstate_d(istate+iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_grad_L2mij_grad_L2mji_add_grad_L2message(id)
  integer,value :: id
  integer :: iemb,iatom,jatom,iedge,istate,nemb
  real(kind=SD) :: tpvalue

  iedge = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1)
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  do iemb = threadidx%x, nemb, 32
     grad_L2mij_d(iemb,iedge) = grad_L2mij_d(iemb,iedge) + hiddenstate_d(istate + (jatom-1)*nemb + iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2DenseV_grad_L2V(iatt)
  integer,value :: iatt
  integer :: iedge,iemb,iatom,jatom,k,istart
  real(kind=SD) :: tpvalue,tp

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  do k = 1, headnum_d
     tpvalue = headattentions_d(k,iedge,iatt)
     istart = (k-1)*headsize_d

     do iemb = threadidx%x, headsize_d, 32
        grad_L2DenseV_d(iemb,k,iedge)= &
           grad_L2mij_d(istart+iemb,iedge)*tpvalue*                    &
           batchnodevalue_d(iemb,k,iatom,iatt)
        tp = atomicadd(grad_L2V_d(iemb,k,iatom), &
           grad_L2mij_d(istart+iemb,iedge)*tpvalue*            &
           batchedgevalue_d(iemb,k,iedge,iatt) )
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2nf_add_delta(id)
  integer,value :: id
  integer :: iemb,istate,iatom

  iatom = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*atomembeddinglength_d

  do iemb = threadidx%x, atomembeddinglength_d, 32
     grad_L2nf_d(iemb,iatom) = grad_L2nf_d(iemb,iatom) + hiddenstate_d(istate + iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2decay(iatt)
  integer,value :: iatt
  integer :: iedge
  iedge = (blockidx%x-1)*blockdim%x + threadidx%x; if (iedge > batchsnapnedge_d ) return
  grad_L2decay_d(iedge) =  grad_L2decay_d(iedge) + sum(grad_L2attn_d(:,iedge)*headattentions_d(:,iedge,iatt)/batchedgedisdecays_d(iedge))
end subroutine

attributes(global) subroutine cudagnn_traindata_delta_grad_L2vf_notnormed_zero()
  integer :: iatom,iemb
  iatom = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     delta_grad_L2vf_notnormed_d(iemb,:,iatom) = 0.0_SD
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_grad_L2vf_notnormed_prepare(id)
  integer,value :: id
  integer :: idim,iemb,istate,iatom,nemb

  iatom = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*nemb*8

  do iemb = threadidx%x, atomembeddinglength_d, 32
     do idim = 1, 8
        delta_grad_L2vf_notnormed_d(iemb,idim,iatom) = delta_grad_L2vf_notnormed_d(iemb,idim,iatom) + hiddenstate_d(istate + (idim-1)*nemb + iemb)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_grad_L2vf_add_delta()
  integer :: idim,iemb,iatom

  iatom = blockidx%x
  do iemb = threadidx%x, atomembeddinglength_d, 32
     do idim = 1, 8
        grad_L2vf_d(iemb,idim,iatom) = grad_L2vf_d(iemb,idim,iatom) + delta_grad_L2vf_notnormed_d(iemb,idim,iatom)
     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_batchdata_grad_L2ef_add_delta(id)
  integer,value :: id
  integer :: iemb,istate,iedge

  iedge = blockidx%x
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iedge-1)*atomembeddinglength_d

  do iemb = threadidx%x, atomembeddinglength_d, 32
     grad_L2ef_d(iemb,iedge) = grad_L2ef_d(iemb,iedge) + hiddenstate_d(istate + iemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2attn_grad_L2DenseK_grad_L2K_grad_L2K_grad_L2Q(iatt)
  integer,value :: iatt
  integer :: iedge,iemb,iatom,jatom,k,istart
  real(kind=SD) :: tpvalue

  iedge = blockidx%x; 
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  do k = 1, headnum_d
     istart = (k-1)*headsize_d

     tpvalue =  &
        dot_product(grad_L2mij_d(istart+1:istart+headsize_d,iedge),batchedgevalue_d(:,k,iedge,iatt)* &
        batchnodevalue_d(:,k,iatom,iatt))

     grad_L2attn_d(k,iedge) = tpvalue
     tpvalue = tpvalue*batchedgedisdecays_d(iedge)*grad_attenactiv_d(k,iedge,iatt)

     do iemb = threadidx%x, headsize_d, 32

        grad_L2DenseK_d(iemb,k,iedge) = tpvalue*     &
             ( batchnodequery_d(iemb,k,jatom,iatt)*batchnodekey_d(iemb,k,iatom,iatt)  )

        istart = atomicadd( grad_L2K_d(iemb,k,iatom), tpvalue* &
           batchnodequery_d(iemb,k,jatom,iatt)*batchedgekey_d(iemb,k,iedge,iatt) )

        istart = atomicadd( grad_L2Q_d(iemb,k,jatom), tpvalue* &
           batchnodekey_d(iemb,k,iatom,iatt)*batchedgekey_d(iemb,k,iedge,iatt) )

     end do
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_rejmatrix_batchsnapatomforces(iatt)
  integer,value :: iatt
  integer :: iatom,jatom,iedge,iemb,idim,jdim
  real(kind=SD) :: tpedgevec(8),tpsum(3),tpvalue,tpvalue2,tpmat(8,8),tpvec(8)

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  tpsum = 0.0_SD

  if ( iatt /= nattention_d ) then

     do iemb = threadidx%x, atomembeddinglength_d, 32
        do idim = 1, 8
           tpvalue = batchvecdiht_d(iemb,idim,iatom,iatt-1)
           tpvalue2 = batchvecdihs_d(iemb,idim,jatom,iatt-1)
           do jdim = idim, 8
              tpmat(idim,jdim) = tpvalue*batchvecdihs_d(iemb,jdim,jatom,iatt-1) + &
                                 tpvalue2 + batchvecdiht_d(iemb,jdim,iatom,iatt-1)
              tpmat(jdim,idim) = tpmat(idim,jdim)
           end do
        end do

        tpedgevec(1:8) = batchedgedirections_d(1:8,iedge)
        tpvec = 0.0_SD
        do idim = 1, 8
           do jdim = 1, 8
              tpvalue = -tpedgevec(jdim)*dot_product(tpmat(idim,:),tpedgevec(:)) + &
                        -tpedgevec(idim)*dot_product(tpedgevec(:),tpmat(:,jdim)) + &
                         2.0_SD*tpmat(idim,jdim)
              tpvec(idim) = tpvec(idim) + tpvalue*tpedgevec(jdim)
           end do
        end do

        tpvalue =  grad_L2ef_d(iemb,iedge)*batchedgedih_d(iemb,iedge,iatt-1)

        do idim = 1, 3
           tpsum(idim) = tpsum(idim) - tpvalue*dot_product(tpvec(:),grad_dirij2coordi_d(:,idim,iedge))
        end do
     end do
  end if

  do iemb = threadidx%x, atomembeddinglength_d, 32
     tpvalue = batchmijdir_d(iemb,iedge,iatt-1)
     tpvec(1:8) = grad_L2vf_d(iemb,1:8,jatom)
     do idim = 1, 3
        tpsum(idim) = tpsum(idim) + tpvalue*dot_product(tpvec(1:8),grad_dirij2coordi_d(1:8,idim,iedge))
     end do
  end do

  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpsum(1),iemb); tpsum(1) = tpsum(1) + tpvalue
     tpvalue = __shfl_xor(tpsum(2),iemb); tpsum(2) = tpsum(2) + tpvalue
     tpvalue = __shfl_xor(tpsum(3),iemb); tpsum(3) = tpsum(3) + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     tpsum = tpsum/grad_L2atomenergy_d(iatom)
     iemb = atomicadd(batchsnapatomforces_d(1,iatom), tpsum(1))
     iemb = atomicadd(batchsnapatomforces_d(2,iatom), tpsum(2))
     iemb = atomicadd(batchsnapatomforces_d(3,iatom), tpsum(3))
     iemb = atomicadd(batchsnapatomforces_d(1,jatom), -tpsum(1))
     iemb = atomicadd(batchsnapatomforces_d(2,jatom), -tpsum(2))
     iemb = atomicadd(batchsnapatomforces_d(3,jatom), -tpsum(3))
  end if
end subroutine

attributes(global) subroutine cudagnn_batchlabel_for_gnetmain2()
  integer :: iedge,iemb,iatom,jatom,ipos,jpos
  real(kind=SD) :: tpvalue,addvalue

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  ipos = (iatom-1)*atomembeddinglength_d
  jpos = (jatom-1)*atomembeddinglength_d 
  do iemb = threadidx%x, atomembeddinglength_d, 32
     addvalue = grad_L2ef_d(iemb,iedge)*largeedgeembeddings_for_edge_d(iemb,iedge)
     tpvalue = atomicadd(batchlabel_d(ipos+iemb),addvalue)
     tpvalue = atomicadd(batchlabel_d(jpos+iemb),addvalue)
  end do 
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2decay_add_gnetmain2(id)
  integer,value :: id
  integer :: iedge,iemb,iatom,jatom,istate
  real(kind=SD) :: tpsum,tpvalue

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (jatom-1)*atomembeddinglength_d*2

  tpsum = 0.0_SD
  do iemb = threadidx%x, atomembeddinglength_d, 32
     tpsum = tpsum + largeedgeembeddings_d(iemb,iedge)*batchatomembeddings_d(iemb,iatom)*hiddenstate_d(istate + iemb)
  end do        

  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpsum,iemb); tpsum = tpsum + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     grad_L2decay_d(iedge) = grad_L2decay_d(iedge) + tpsum
  end if
end subroutine

attributes(global) subroutine cudagnn_traindata_ini_grad_L2atomemb(id)
  integer,value :: id
  integer :: iatom,iemb,istate,nemb

  iatom = blockidx%x; nemb = atomembeddinglength_d
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iatom-1)*2*nemb

  do iemb = threadidx%x, nemb, 32
     grad_L2atomemb_d(iemb,iatom) = 0.0_SD
     grad_L2atomemb_d(nemb+iemb,iatom) = hiddenstate_d(istate+iemb+nemb)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2atomemb_batchabel_for_gnetmain1(id)
  integer,value :: id
  integer :: iedge,istate,iemb,iatom,jatom,ipos,jpos
  real(kind=SD) :: tpdecay,tpvalue,tpa,tpb

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)
  tpdecay = batchedgedisdecays_d(iedge)

  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1)
  ipos = istate + (iatom-1)*atomembeddinglength_d*2
  jpos = istate + (jatom-1)*atomembeddinglength_d*2 

  istate = (iedge-1)*atomembeddinglength_d

  do iemb = threadidx%x, atomembeddinglength_d, 32
     tpa = hiddenstate_d(jpos+iemb)*tpdecay
     tpvalue = atomicadd(grad_L2atomemb_d(iemb,iatom), tpa*largeedgeembeddings_d(iemb,iedge))
     batchlabel_d(istate+iemb) = tpa*batchatomembeddings_d(iemb,iatom)
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2edgeemb_batchabel_for_gnetmain4(id)
  integer,value :: id
  integer :: iatom,jatom,istate,iedge,iemb

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iedge-1)*edgeembeddinglength_d

  do iemb = threadidx%x, edgeembeddinglength_d, 32
     grad_L2edgeemb_d(iemb,iedge) = hiddenstate_d(istate+iemb) 
  end do

  istate = (iedge-1)*atomembeddinglength_d
  do iemb = threadidx%x, atomembeddinglength_d, 32
     batchlabel_d(istate+iemb) = grad_L2ef_d(iemb,iedge)*    &
         (nodefeatures_of_first_layer_d(iemb,iatom) + nodefeatures_of_first_layer_d(iemb,jatom))
  end do
end subroutine

attributes(global) subroutine cudagnn_traindata_grad_L2edgeemb_plus_gnetmain4_and_grad_L2decay(id)
  integer,value :: id
  integer :: iedge,istate,iemb
  real(kind=SD) :: tpsum,tpvalue

  iedge = blockidx%x; tpsum = 0.0_SD
  istate = net(id)%mlplayers_index_d + id - 1
  istate = net(id)%hiddenstate_index_d + hiddenstate_index_d(istate+1) + (iedge-1)*edgeembeddinglength_d

  do iemb = threadidx%x, edgeembeddinglength_d, 32
     grad_L2edgeemb_d(iemb,iedge) = grad_L2edgeemb_d(iemb,iedge) + hiddenstate_d(istate+iemb)
     tpsum = tpsum + grad_L2edgeemb_d(iemb,iedge)*batchedgeembeddings_d(iemb,iedge)
  end do

  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpsum,iemb); tpsum = tpsum + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     grad_L2decay_d(iedge) = grad_L2decay_d(iedge) + tpsum/batchedgedisdecays_d(iedge)
  end if
end subroutine

attributes(global) subroutine cudagnn_traindata_batchsnapatomforces_add_grads()
  integer :: iedge,iatom,jatom,iemb
  real(kind=SD) :: tpvalue,tpsum,expdis

  iedge = blockidx%x
  iatom = batchsnapedges_d(1,iedge); jatom = batchsnapedges_d(2,iedge)

  tpsum = 0.0_SD; expdis = exp(-batchedgedistance_d(iedge))
  do iemb = threadidx%x, edgeembeddinglength_d, 32
     tpsum = tpsum + 2.0_SD*edgeembbetas_d(iemb)*(expdis-edgeembmeans_d(iemb))* &
              batchedgeembeddings_d(iemb,iedge)*grad_L2edgeemb_d(iemb,iedge)*expdis
  end do

  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpsum,iemb); tpsum = tpsum + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     tpvalue = (tpsum + grad_L2decay_d(iedge)*grad_decay2dis_d(iedge))*batchedgedirections_d(1,iedge)/grad_L2atomenergy_d(iatom)
     iemb = atomicadd(batchsnapatomforces_d(1,iatom), tpvalue)
     iemb = atomicadd(batchsnapatomforces_d(1,jatom), -tpvalue)

     tpvalue = (tpsum + grad_L2decay_d(iedge)*grad_decay2dis_d(iedge))*batchedgedirections_d(2,iedge)/grad_L2atomenergy_d(iatom)
     iemb = atomicadd(batchsnapatomforces_d(2,iatom), tpvalue)
     iemb = atomicadd(batchsnapatomforces_d(2,jatom), -tpvalue)

     tpvalue = (tpsum + grad_L2decay_d(iedge)*grad_decay2dis_d(iedge))*batchedgedirections_d(3,iedge)/grad_L2atomenergy_d(iatom)
     iemb = atomicadd(batchsnapatomforces_d(3,iatom), tpvalue)
     iemb = atomicadd(batchsnapatomforces_d(3,jatom), -tpvalue)
  end if
end subroutine

attributes(global) subroutine cudagnn_traindata_batchsnapatomforces_reverse(calloss)
  logical,value :: calloss
  integer :: iatom,iemb
  real(kind=SD) :: tpsum,tpvalue

  iatom = (blockidx%x-1)*blockdim%x + threadidx%x; if ( iatom > batchsnapnatom_d ) return
  batchsnapatomforces_d(:,iatom) = - batchsnapatomforces_d(:,iatom)

  if ( calloss .eqv. .false. ) return

  tpsum = 0.0_SD
  select case (lossfunctype_d)
     case (RMSE)
        tpsum = ( (batchsnapatomforces_d(1,iatom) - batchrefsnapatomforces_d(1,iatom))**2 + &
                  (batchsnapatomforces_d(2,iatom) - batchrefsnapatomforces_d(2,iatom))**2 + &
                  (batchsnapatomforces_d(3,iatom) - batchrefsnapatomforces_d(3,iatom))**2 )/3.0_SD
     case (MAE)
        tpsum = ( abs(batchsnapatomforces_d(1,iatom) - batchrefsnapatomforces_d(1,iatom)) + &
                  abs(batchsnapatomforces_d(2,iatom) - batchrefsnapatomforces_d(2,iatom)) + &
                  abs(batchsnapatomforces_d(3,iatom) - batchrefsnapatomforces_d(3,iatom)) )/3.0_SD
  end select

  iemb = 1
  do while (iemb<=16)
     tpvalue = __shfl_xor(tpsum,iemb); tpsum = tpsum + tpvalue
     iemb = iemb*2
  end do

  if ( threadidx%x == 1 ) then
     tpvalue = atomicadd(totforceloss_d, tpsum)
  end if
end subroutine

end module
