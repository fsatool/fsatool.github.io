module deep
  use deeppub
  implicit none

  integer :: layers(maxnlayer)
  integer :: ntau, normalmode, skipdata
  integer :: ninput,noutput,nlayer
  real*8 :: timestepsize
  logical :: ifbias,ifnormeigenvec,ifavglabel

  integer :: iuncertainty,srvavgmode

  integer :: ntrajfile,nlabelcv,ngradcv
  integer,dimension(:),allocatable :: cvstart,cvend,labelcvstart,labelcvend,gradcvstart,gradcvend

  integer,dimension(:),pointer :: deeptrajindex,checkdeeptrajindex
  real*8,dimension(:,:),pointer :: deeptrajcoor,checkdeeptrajcoor,graddeeptrajcoor, checkgraddeeptrajcoor
  integer :: ntraj,maxdataperfile
  real*8 :: normalfactor
  real*8,dimension(:),allocatable :: trajmin, trajmax, gradtrajmin, gradtrajmax

  real*8,dimension(:,:),pointer :: labelcvtraj
  real*8,dimension(:,:),pointer :: checklabelcvtraj
  real*8,dimension(:),allocatable :: labelcvtrajmin,labelcvtrajmax,labelcvtrajavg

  !================== variables for CNN

  integer :: nconvlayer, nconvheight, nconvwidth, nconvchannel, ipoolmethod
  integer,parameter :: MAXPOOL=1, MEANPOOL=2
  type,private :: convlayer
     integer :: nfilter,nchannel

     integer :: filterstateheight,filterstatewidth,filterheight,filterwidth,filterstride
     real*8,pointer :: filterweight(:,:,:,:),filterbias(:),filterstate(:,:,:)
     real*8,pointer :: grad_filterweight(:,:,:,:),grad_filterbias(:)
     real*8,pointer :: gradg_filterweight(:,:,:,:),gradg_filterbias(:)
     real*8,pointer :: gradgsq_filterweight(:,:,:,:),gradgsq_filterbias(:)

     integer :: poolheight,poolwidth,poolstride,poolstateheight,poolstatewidth
     integer,pointer :: poolmaxloc(:,:)
     real*8,pointer :: poolstate(:,:,:)

     real*8,pointer :: delta_layer(:),grad_active(:,:,:)
  end type

  type(convlayer),dimension(:),allocatable :: convlayers

  !==================  variables on GPU

  integer,device :: checkdeepntotdata_d
  integer,dimension(:),allocatable,device :: deeptrajindex_d
  real(kind=SD),dimension(:,:),allocatable,device :: deeptrajcoor_d,labelcvtraj_d,checkdeeptrajcoor_d,checklabelcvtraj_d,graddeeptrajcoor_d,checkgraddeeptrajcoor_d
  real(kind=SD),dimension(:),allocatable,device :: trajmin_d,trajmax_d,gradtrajmin_d,gradtrajmax_d
  real(kind=SD),dimension(:),allocatable,device :: labelcvtrajavg_d
  logical,device :: ifuselayernorm_d
contains

!========================= Network Initialization ====================================

subroutine deep_initialize(parmfile,tptraj,tplayers,tpicuda)
  use deeppub
  character(len=*),intent(in) :: parmfile
  real*8,intent(in),optional :: tptraj(:,:)
  integer,intent(in),optional :: tplayers(:),tpicuda
  integer :: ierr,i,j,k,iofile,ilayer,recstart,recend
  integer :: tpintarray(maxntrajfile)
  real*8,allocatable :: tpvec(:)
  character*20 :: task
  character*150 :: trajfile(maxntrajfile),checktrajfile(maxntrajfile),inputbiasfile(maxntrajfile),outputcutfile(maxntrajfile)
  character*50 :: tpstring
  logical :: ifrotateinput

  integer :: cheight,cwidth,cchannel
  real*8 :: rand
  integer,dimension(maxnlayer) :: clayers,cfilterheight,cfilterwidth,cfilterstride,cpoolheight,cpoolwidth,cpoolstride

  namelist / deep / icudagroup, task, layers, batchsize, batchnum, activation, trajfile, cvstart, &
        cvend, recstart, recend, nepoch, ntau, normalfactor, networkfile, bptt_trun, learnrate,             &
        maxdataperfile, srvavgmode, labelcvstart, labelcvend, normalmode, ioptmethod,                       &
        deepiseed, checktrajfile, l1normfactor, l2normfactor, skipdata, ifproceed, inputbiasfile, outputcutfile, ifrotateinput, lossfunction, &
        cheight,cwidth,cchannel,clayers,cfilterheight,cfilterwidth,cfilterstride,cpoolheight,cpoolwidth,cpoolstride,ipoolmethod, &
        gradcvstart, gradcvend, gradcvweight, ifclasses, iuncertainty,ifnormeigenvec, &
        labelcvgroupweight, minlearnrate, learnratedecay, learnratewarmsteps, learnratepatientsteps, &
        ifsaveminlossnetwork, dropout, ifuselayernorm, ifbias, ifavglabel

  allocate(cvstart(maxntrajfile),cvend(maxntrajfile),labelcvstart(maxntrajfile),labelcvend(maxntrajfile),gradcvstart(maxntrajfile),gradcvend(maxntrajfile))
  totparms = 0; cvstart = 0; cvend = 0; labelcvstart = 0; labelcvend = 0; gradcvstart = 0; gradcvend = 0; gradcvweight = 0d0

  batchsize = 1; batchnum = 0; ntau = 0; nepoch = 0; activation = 'sigm'

  bptt_trun = 1; learnrate = 0.01d0; trajfile=""; checktrajfile=""; maxdataperfile = 0

  layers = 0; trajfile = ""; task=""; recstart=0; recend=0
  normalmode = 0; normalfactor = 0d0; srvavgmode = 1

  ioptmethod=1; deepiseed = 0; l1normfactor = 0.0d0; l2normfactor = 0.0d0; dropout = 0.0d0; skipdata = 0; ifproceed = .false.
  inputbiasfile = ""; outputcutfile = ""; ifrotateinput = .false.; lossfunction = "rmse"
  clayers = 0; cheight = 0; cwidth = 0; cchannel = 0; cfilterheight=1; cfilterwidth=1; cfilterstride=1; cpoolheight=1; cpoolwidth=1; cpoolstride=1; ipoolmethod=1

  ifclasses = 0; iuncertainty = 0; ifnormeigenvec = .false.
  minlearnrate = 1d-7; learnratedecay = 0.8d0; learnratewarmsteps = 0; learnratepatientsteps = 0
  ifsaveminlossnetwork = .false.; ifuselayernorm = .false.; ifbias = .true.
  ifavglabel = .false.

  icudagroup = 0; if ( present(tpicuda) ) icudagroup = tpicuda

  if ( netnum == 0 ) netnum = 1

  allocate(labelcvgroupweight(30)); labelcvgroupweight = 0d0

  if ( networkfile == "" .and. parmfile /= "" ) then

     open(newunit=iofile, file=parmfile, action="read")
     read(iofile, nml=deep, iostat=ierr); if ( ierr /= 0 ) stop "Read error for namelist deep!"
     close(iofile)

     maxlearnrate = learnrate

     if ( deepiseed /= 0 ) call deeppub_random_init(deepiseed)

     if ( icudagroup > 0 ) then
        if ( (jobtype == TRAIN) .and. (icudagroup*deepprocnum > batchsize) ) then
           print *, "icudagroup*procnum can not be larger than batchsize ",icudagroup, deepprocnum, batchsize
           stop
        end if
     end if

     if ( present(tplayers) ) layers(1:size(tplayers)) = tplayers(:)

     do nlayer=size(layers),1,-1; if ( layers(nlayer) /= 0 ) exit; end do

     if ( nlayer > 0 ) then
        ninput = layers(1); noutput = layers(nlayer)

        if ( inputbiasfile(1) /= "" ) then
           open(newunit=iofile,file=inputbiasfile(1),action="read"); i = 0
           do
              read(iofile,*,iostat=ierr); if ( ierr /= 0 ) exit
              i = i + 1
           end do
           close(iofile)
           if ( ninput /= i ) stop "ninput does not equal the records in the inputbiasfile!"
 
           if ( outputcutfile(1) /= "" ) then 
              open(newunit=iofile,file=outputcutfile(1),action="read"); i = 0
              do
                 read(iofile,*,iostat=ierr); if ( ierr /= 0 ) exit
                 i = i + 1
              end do
              close(iofile)
              if ( noutput /= i ) stop "noutput does not equal the records in the outputcutfile!"
           end if

        end if

        allocate(trajmin(ninput),trajmax(ninput)); trajmin=0d0; trajmax=0d0
        allocate(labelcvtrajmin(noutput),labelcvtrajmax(noutput)); labelcvtrajmin=0d0; labelcvtrajmax=0d0
        allocate(labelcvtrajavg(noutput)); labelcvtrajavg=0d0
        allocate(gradtrajmin(ninput),gradtrajmax(ninput)); gradtrajmin=0d0; gradtrajmax=0d0
     end if

  end if

  if ( jobtype == PREDICT .or. jobtype == CHECK ) then
     if ( nlayer > 0 ) then
        layers = 0; deallocate(trajmin,trajmax,labelcvtrajmin,labelcvtrajmax,gradtrajmin,gradtrajmax); ninput=0; noutput=0
        deallocate(labelcvtrajavg)
     end if

     open(newunit=iofile,file=networkfile,action="read")
     read(iofile,*)
     read(iofile,"(20i5)") layers
     do nlayer=size(layers),1,-1; if ( layers(nlayer) /= 0 ) exit; end do
     ninput = layers(1); noutput = layers(nlayer)
     allocate(trajmin(ninput),trajmax(ninput)); trajmin=0d0; trajmax=0d0
     allocate(labelcvtrajmin(noutput),labelcvtrajmax(noutput)); labelcvtrajmin=0d0; labelcvtrajmax=0d0
     allocate(labelcvtrajavg(noutput)); labelcvtrajavg=0d0
     allocate(gradtrajmin(ninput),gradtrajmax(ninput)); gradtrajmin = 0d0; gradtrajmax = 0d0

     read(iofile,*)
     read(iofile,"(a)") activation
     read(iofile,*)
     read(iofile,*) batchsize
     read(iofile,*)
     read(iofile,*) ntau
     read(iofile,*)
     if ( inputbiasfile(1) /= "" ) then
        read(iofile,"(*(i8))") (cvstart(i),cvend(i),i=1,maxntrajfile)
     else
        read(iofile,"(*(i8))") cvstart(1),cvend(1)
     end if
     read(iofile,*)
     read(iofile,*) normalmode
     read(iofile,*)
     read(iofile,*) normalfactor
     read(iofile,*)
     read(iofile,"(*(f15.8))") trajmin
     read(iofile,*)
     read(iofile,"(*(f15.8))") trajmax
     read(iofile,*)
     read(iofile,"(*(i8))") (labelcvstart(i),labelcvend(i), i=1,maxntrajfile)
     read(iofile,*)
     read(iofile,"(*(f15.8))") labelcvtrajmin
     read(iofile,*)
     read(iofile,"(*(f15.8))") labelcvtrajmax
     read(iofile,"(a18,l4)") tpstring,ifavglabel
     read(iofile,"(*(f20.8))") labelcvtrajavg
     read(iofile,*)
     read(iofile,"(*(i8))") (gradcvstart(i),gradcvend(i), i=1,maxntrajfile)
     read(iofile,*)
     read(iofile,*) gradcvweight
     read(iofile,*)
     read(iofile,"(*(f15.8))") gradtrajmin
     read(iofile,*)
     read(iofile,"(*(f15.8))") gradtrajmax
     read(iofile,*)
     read(iofile,"(*(f10.3))") labelcvgroupweight
!     read(iofile,"(a50)") tpstring
!     if ( tpstring(32:32) == "T" ) ifuselayernorm = .true.
     close(iofile)

     if ( jobtype == PREDICT ) then
        batchsize = 1
        if ( trajfile(1) == "" ) then
           deepntotdata = 1; allocate(deeptrajcoor(ninput,deepntotdata),labelcvtraj(noutput,deepntotdata))
        end if
     else if ( jobtype == CHECK ) then
        batchnum = 1
        if ( ntau > 0 ) then
           recstart = 1; recend = batchsize + ntau
           if ( trajfile(1) == "" ) stop "trajfile should be provided in the namelist in the CHECK task!"
        else
           batchsize = 1
           deepntotdata = 1; allocate(deeptrajcoor(ninput,deepntotdata),labelcvtraj(noutput,deepntotdata))
           deeptrajcoor = 0d0; labelcvtraj = 0d0
           if ( gradcvstart(1) > 0 .and. gradcvend(1) > 0 ) then
              allocate(graddeeptrajcoor(ninput,deepntotdata)); graddeeptrajcoor = 0d0
           end if
        end if
     end if  
  end if
  if ( maxnsteps /= 1 ) maxnsteps = ntau

  do i = 1, size(labelcvgroupweight); if ( labelcvgroupweight(i) == 0d0 ) exit ; end do
  k = (i - 1)/3
  if ( k > 0 ) then
     allocate(tpvec(size(labelcvgroupweight))); tpvec = labelcvgroupweight
     deallocate(labelcvgroupweight); allocate(labelcvgroupweight(3*k)); labelcvgroupweight(1:3*k)=tpvec(1:3*k)
     deallocate(tpvec)
  else
     deallocate(labelcvgroupweight)
     allocate(labelcvgroupweight(3)); labelcvgroupweight=[1,noutput,1.0d0]
  end if

  allocate(labelcvweight(noutput))
  do i = 1, size(labelcvgroupweight)/3
     j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1))
     if ( j < 1 .or. j > noutput .or. k < 1 .or. k > noutput ) stop "incorrect labelcvgroupweight setup"
     labelcvweight(j:k) = labelcvgroupweight(3*i)
  end do

  do i = 1, maxntrajfile; if ( cvstart(i) == 0 ) exit; end do; ntrajfile = i - 1
  if ( ntrajfile > 0 ) then 
     tpintarray = cvstart; deallocate(cvstart); allocate(cvstart(ntrajfile)); cvstart(1:ntrajfile) = tpintarray(1:ntrajfile)
     tpintarray = cvend; deallocate(cvend); allocate(cvend(ntrajfile)); cvend(1:ntrajfile) = tpintarray(1:ntrajfile)

     if ( labelcvstart(1) > 0 .and. labelcvend(1) > 0 ) then
        nlabelcv = noutput
        do i = 1, maxntrajfile; if ( labelcvstart(i) == 0 ) exit; end do; ntrajfile = i - 1
        tpintarray = labelcvstart; deallocate(labelcvstart); allocate(labelcvstart(ntrajfile)); labelcvstart(1:ntrajfile) = tpintarray(1:ntrajfile)
        tpintarray = labelcvend; deallocate(labelcvend); allocate(labelcvend(ntrajfile)); labelcvend(1:ntrajfile) = tpintarray(1:ntrajfile)
     else
        deallocate(labelcvstart,labelcvend,labelcvtrajmin,labelcvtrajmax,labelcvtrajavg)
        allocate(labelcvstart(1),labelcvend(1)); labelcvstart = 0; labelcvend = 0
        allocate(labelcvtrajmin(1),labelcvtrajmax(1)); labelcvtrajmin = 0d0; labelcvtrajmax = 0d0
        allocate(labelcvtrajavg(1)); labelcvtrajavg=0d0
     end if
     if ( gradcvstart(1) > 0 .and. gradcvend(1) > 0 ) then
        if ( gradcvweight == 0.0d0 ) stop "gradcvweight is not presented for ngradcv > 0!"
        do i = 1, maxntrajfile; if ( cvstart(i) == 0 ) exit; end do; ntrajfile = i - 1
        ngradcv = gradcvend(1) - gradcvstart(1) + 1
        if ( noutput > 1 ) stop "noutput can not be larger than 1 when gradcvweight > 0.0 "
        tpintarray = gradcvstart; deallocate(gradcvstart); allocate(gradcvstart(ntrajfile)); gradcvstart(1:ntrajfile) = tpintarray(1:ntrajfile)
        tpintarray = gradcvend; deallocate(gradcvend); allocate(gradcvend(ntrajfile)); gradcvend(1:ntrajfile) = tpintarray(1:ntrajfile)
     else
        deallocate(gradcvstart,gradcvend,gradtrajmin,gradtrajmax)
        ngradcv = 0
        allocate(gradcvstart(1),gradcvend(1)); gradcvstart = 0; gradcvend = 0
        allocate(gradtrajmin(1),gradtrajmax(1)); gradtrajmin = 0d0; gradtrajmax = 0d0
     end if
  else
     deallocate(cvstart,cvend); allocate(cvstart(1),cvend(1)); cvstart=0; cvend=0
     nlabelcv=0; deallocate(labelcvstart,labelcvend,labelcvtrajmin,labelcvtrajmax); allocate(labelcvstart(1),labelcvend(1)); labelcvstart=0; labelcvend=0; labelcvtrajmin = 0d0; labelcvtrajmax = 0d0
     deallocate(labelcvtrajavg); allocate(labelcvtrajavg(1)); labelcvtrajavg=0d0
     ngradcv=0; deallocate(gradcvstart,gradcvend,gradtrajmin,gradtrajmax); allocate(gradcvstart(1),gradcvend(1),gradtrajmin(1),gradtrajmax(1)); gradcvstart=0; gradcvend = 0; gradtrajmin = 0d0; gradtrajmax = 0d0
  end if

  call deeppub_set_activefunction_and_lossfunction()

  if ( l1normfactor > 0.0d0 .and. l2normfactor > 0.0d0 ) stop "l1normfactor and l2normfactor can not be positive at the same time!"

!  totparms = 0
!  call mlp_initialize(ninput,noutput,nlayer,layers,totparms,tpoutputweight=labelcvweight)
!
!  if ( jobtype == PREDICT .or. jobtype == CHECK .or. ifproceed .eqv. .true. ) then
!     call deep_network_reload()
!  else
!     if ( icudagroup > 0 ) call mlp_network_upload()
!  end if

  if ( deepprocid == 0 ) then
     print "(/,a,10i8)", "      Network Layers : ",layers(1:nlayer)
     print "(a,i16)",    "    Number of Epochs : ",nepoch
     print "(a,a16)",    " Activation Function : ",trim(activation)
     print "(a,a16)",    "  Loss Function Type : ",trim(lossfunction)
     print "(a,f16.5)",  "       Learning Rate : ",learnrate
     print "(a,i16)",    "          Time Steps : ",ntau
     print "(a,a16)",    "        Network File : ",trim(networkfile)
     if ( ioptmethod == 1 ) then
        print "(a,a16)",    "   Network Optimizer : ","       SDP"
     else if ( ioptmethod == 2 ) then
        print "(a,a16)",    "   Network Optimizer : ","      ADAM"
     else
        stop "Invalid netowrk optimizer!"
     end if
     print "(a,2f16.5)",   "L1 and L2 Norm factor: ",l1normfactor,l2normfactor
     print "(a,f16.5)",    " Dropout Probability : ",dropout
     print "(a,100i8)",    "      CV Index Range : ",(cvstart(j),cvend(j),j=1,size(cvstart))
     if ( nlabelcv > 0 ) then
        print "(a,100i8)",    "Label CV Index Range : ",(labelcvstart(j),labelcvend(j),j=1,size(labelcvstart))
     end if
     if ( size(labelcvgroupweight)/3 > 1 ) then
        print "(a,*(2i8,f10.3))",  "Label CV Group Weight: ",( nint(labelcvgroupweight(3*i-2)),nint(labelcvgroupweight(3*i-1)),labelcvgroupweight(3*i),i=1,size(labelcvgroupweight)/3 )
     end if
     if ( learnratewarmsteps > 0 ) then
        print "(a,i16)",    " Leanrate Warm Steps : ",learnratewarmsteps
        print "(a,f16.5)", "Learnate Decay Factor: ",learnratedecay
        print "(a,f16.10)","Minimum Learning Rate: ",minlearnrate
        print "(a,i16)",    "Learnrate PatientStep: ",learnratepatientsteps
     end if

  end if

  if ( trajfile(1) /= "" ) then
     call deep_traj_loadin(trajfile,recstart,recend,checktrajfile,inputbiasfile,outputcutfile,ifrotateinput)
     if ( deepprocid == 0 ) call deep_traj_normalization()
  else if ( present(tptraj) ) then
     if ( ninput /= size(tptraj,1) ) stop "ninput does not equal the first dimension of deeptrajcoor!"
     deepntotdata = size(tptraj,2)
     i = (deepntotdata - 1)/batchsize + 1
     if ( batchnum == 0 ) then
        batchnum = i
     else if ( batchnum > i ) then
        print "(a,2i8)","batchnum exceeds the maximum(tptraj) ", batchnum, i; stop
     end if
     allocate(deeptrajcoor(ninput,deepntotdata)); deeptrajcoor = tptraj
     call deep_traj_normalization()
  end if

  call mpi_bcast(trajmin,ninput,mpi_double_precision,0, mpi_comm_world,ierr)
  call mpi_bcast(trajmax,ninput,mpi_double_precision,0, mpi_comm_world,ierr)
  if ( ngradcv > 0 ) then
     call mpi_bcast(gradtrajmin,ngradcv,mpi_double_precision,0, mpi_comm_world,ierr)
     call mpi_bcast(gradtrajmax,ngradcv,mpi_double_precision,0, mpi_comm_world,ierr)
  end if
  call mpi_barrier(mpi_comm_world,ierr)

  !================= initialization for CNN

  do nconvlayer=size(clayers),1,-1; if ( clayers(nconvlayer) /= 0 ) exit; end do

  if ( nconvlayer > 0 ) then
     allocate(convlayers(0:nconvlayer))

     nconvheight = cheight; nconvwidth = cwidth; nconvchannel = cchannel

     do ilayer = 1, nconvlayer
        if ( ilayer > 1 ) then
           cheight = convlayers(ilayer-1)%poolstateheight
           cwidth = convlayers(ilayer-1)%poolstatewidth
           cchannel = convlayers(ilayer-1)%nfilter
        end if
        convlayers(ilayer)%nchannel = cchannel
        convlayers(ilayer)%nfilter = clayers(ilayer)
        convlayers(ilayer)%filterheight = cfilterheight(ilayer) 
        convlayers(ilayer)%filterwidth = cfilterwidth(ilayer)
        convlayers(ilayer)%filterstride = cfilterstride(ilayer)

        cheight = ( cheight + cfilterheight(ilayer) - 2 )/cfilterstride(ilayer) + 1
        cwidth = ( cwidth + cfilterwidth(ilayer) - 2 )/cfilterstride(ilayer) + 1
        convlayers(ilayer)%filterstateheight = cheight; convlayers(ilayer)%filterstatewidth = cwidth
        allocate( convlayers(ilayer)%filterstate(cheight,cwidth,clayers(ilayer))); convlayers(ilayer)%filterstate = 0d0

        allocate( convlayers(ilayer)%filterweight(cfilterheight(ilayer),cfilterwidth(ilayer),cchannel,clayers(ilayer)) )
        allocate( convlayers(ilayer)%filterbias(clayers(ilayer)) )
        convlayers(ilayer)%filterweight = 0d0; convlayers(ilayer)%filterbias = 0d0

        if ( jobtype == TRAIN ) then
           call deeppub_normaldata_4d(convlayers(ilayer)%filterweight, 0d0, 1d0)
           convlayers(ilayer)%filterweight = convlayers(ilayer)%filterweight*0.1d0
           call deeppub_normaldata_1d(convlayers(ilayer)%filterbias, 0d0, 1d0)  
           convlayers(ilayer)%filterbias = convlayers(ilayer)%filterbias*0.1d0
        end if

        allocate( convlayers(ilayer)%grad_filterweight(cfilterheight(ilayer),cfilterwidth(ilayer),cchannel,clayers(ilayer)) )
        allocate( convlayers(ilayer)%grad_filterbias(clayers(ilayer)) )
        convlayers(ilayer)%grad_filterweight = 0d0; convlayers(ilayer)%grad_filterbias = 0d0

        if ( ioptmethod == 2 ) then
           allocate( convlayers(ilayer)%gradg_filterweight(cfilterheight(ilayer),cfilterwidth(ilayer),cchannel,clayers(ilayer)) )
           allocate( convlayers(ilayer)%gradg_filterbias(clayers(ilayer)) )
           convlayers(ilayer)%gradg_filterweight = 0d0; convlayers(ilayer)%gradg_filterbias = 0d0

           allocate( convlayers(ilayer)%gradgsq_filterweight(cfilterheight(ilayer),cfilterwidth(ilayer),cchannel,clayers(ilayer)) )
           allocate( convlayers(ilayer)%gradgsq_filterbias(clayers(ilayer)) )
           convlayers(ilayer)%gradgsq_filterweight = 0d0; convlayers(ilayer)%gradgsq_filterbias = 0d0
        end if

        convlayers(ilayer)%poolheight = cpoolheight(ilayer)
        convlayers(ilayer)%poolwidth = cpoolwidth(ilayer)
        convlayers(ilayer)%poolstride = cpoolstride(ilayer)

        cheight = (convlayers(ilayer)%filterstateheight-1)/convlayers(ilayer)%poolstride + 1
        cwidth = (convlayers(ilayer)%filterstatewidth-1)/convlayers(ilayer)%poolstride + 1
        convlayers(ilayer)%poolstateheight = cheight
        convlayers(ilayer)%poolstatewidth = cwidth
        allocate(convlayers(ilayer)%poolstate(cheight,cwidth,clayers(ilayer)))
        allocate( convlayers(ilayer)%grad_active(cheight,cwidth,clayers(ilayer)))
        convlayers(ilayer)%poolstate = 0d0; convlayers(ilayer)%grad_active = 0d0

        if ( ipoolmethod == MAXPOOL ) then
           allocate(convlayers(ilayer)%poolmaxloc(2,clayers(ilayer))); convlayers(ilayer)%poolmaxloc=0
        end if

        allocate( convlayers(ilayer)%delta_layer(clayers(ilayer)) ); convlayers(ilayer)%delta_layer = 0d0

     end do

  end if

  !================= initialization for cuda

  if ( icudagroup == 0 ) return

  icudagroup_d = icudagroup; dropout_d = dropout; ifuselayernorm_d = ifuselayernorm
  normalmode_d = normalmode; normalfactor_d = normalfactor; gradcvweight_d = gradcvweight
  learnrate_d = learnrate; deepntotdata_d = deepntotdata; activefunctype_d = activefunctype 
  netnum_d = netnum; maxnsteps_d = maxnsteps

  batchsize_d = batchsize; ntau_d = ntau; nlabelcv_d = nlabelcv; ngradcv_d=ngradcv; ioptmethod_d = ioptmethod; l1normfactor_d = l1normfactor; l2normfactor_d = l2normfactor
  lossfunctype_d = lossfunctype

  allocate(trajmin_d(ninput),trajmax_d(ninput)); trajmin_d = trajmin; trajmax_d = trajmax
  allocate(errormark_d(icudagroup)); errormark_d = 0
  allocate(shuffleidx_d(deepntotdata)); shuffleidx_d = [(i,i=1,deepntotdata)]
  allocate(labelcvweight_d(noutput)); labelcvweight_d = labelcvweight
  allocate(batchdata_d(ninput*icudagroup),batchlabel_d(noutput*icudagroup)); batchdata_d = 0.0_SD; batchlabel_d = 0.0_SD
  allocate(batchgraddata_d(ninput*icudagroup)); batchgraddata_d = 0.0_SD

  if ( deepntotdata > 0 ) then

     allocate(deeptrajcoor_d(ninput,deepntotdata)); deeptrajcoor_d = deeptrajcoor

     if ( ntau > 0 ) then
        allocate(deeptrajindex_d(deepntotdata)); deeptrajindex_d = deeptrajindex
     end if
     if ( nlabelcv > 0 ) then
        allocate(labelcvtraj_d(nlabelcv,deepntotdata)); labelcvtraj_d = labelcvtraj
        allocate(labelcvtrajavg_d(nlabelcv)); labelcvtrajavg_d = labelcvtrajavg
     end if
     if ( checkdeepntotdata > 0 ) then
        checkdeepntotdata_d = checkdeepntotdata
        allocate(checkdeeptrajcoor_d(ninput,checkdeepntotdata),checklabelcvtraj_d(nlabelcv,checkdeepntotdata))
        checkdeeptrajcoor_d = checkdeeptrajcoor; checklabelcvtraj_d = checklabelcvtraj
     end if
     if ( ngradcv > 0 ) then
        allocate(graddeeptrajcoor_d(ngradcv,deepntotdata)); graddeeptrajcoor_d = graddeeptrajcoor
        if ( checkdeepntotdata > 0 ) then
           allocate(checkgraddeeptrajcoor_d(ngradcv,checkdeepntotdata)); checkgraddeeptrajcoor_d = checkgraddeeptrajcoor
        end if
        allocate(gradtrajmin_d(ngradcv),gradtrajmax_d(ngradcv)); gradtrajmin_d=gradtrajmin; gradtrajmax_d=gradtrajmax
     end if
  end if

end subroutine

subroutine deep_check_data_preprocess()
  real*8 :: distri(100),vmin,vmax,vdis
  integer :: i,idx,dpos

  vmax = normalfactor; vmin = 0
  if (normalmode==2) vmin = - normalfactor
  vdis = vmax - vmin
  do i = 1,ninput
     distri = 0d0
     do idx = 1,deepntotdata
        dpos = int((deeptrajcoor(i,idx) - vmin)*99d0/vdis) + 1
        if (dpos<=0 ) dpos = 1
        if (dpos>100 ) dpos = 100
        distri(dpos) = distri(dpos) + 1d0
     end do
     distri = distri/dble(deepntotdata)
     write(6,'(i8,*(f15.6))'),i,distri
  end do
end subroutine

subroutine deep_traj_loadin(trajfile,recstart,recend,checktrajfile,inputbiasfile,outputcutfile,ifrotateinput)
  character*150,intent(in) :: trajfile(:),checktrajfile(:),inputbiasfile(:),outputcutfile(:)
  integer,intent(in) :: recstart,recend
  logical,intent(in) :: ifrotateinput
  integer,parameter :: maxninput=1000000
  integer :: itot,i,j,k,irec,ierr,maxncv,iofile(maxntrajfile),ifile,tpndata,tpcvstart,tpcvend,tplabelcvstart,tplabelcvend,tpgradcvstart,tpgradcvend
  integer :: tpinput2cvindex(ninput),tpoutput2cvindex(noutput)
  real*8 :: tpvec(maxninput),tpvalue,tpmax,tpmin,tpinputbias(ninput)
  character*1000000 :: tpstring  
  logical :: ifupdaterange,ifinputbiased,ifoutputcut,ifexist
  real*8,allocatable,dimension(:,:) :: tpexpandinput,tpexpandgrad

  if ( deepprocid == 0 ) then

     print *
     do ifile = 1, maxntrajfile
        if ( trajfile(ifile) == "" ) then
           exit
        else
           inquire (file=trajfile(ifile), exist=ifexist)
           if ( ifexist .eqv. .false. ) then
              print *,"Trajfile ",trim(trajfile(ifile))," does not exist!"; stop
           end if
        end if
        open(newunit=iofile(ifile),file=trajfile(ifile),action="read")
     end do
     ntrajfile = ifile - 1

     ifinputbiased=.false.; if ( trim(inputbiasfile(1)) /= "" ) ifinputbiased=.true.
     ifoutputcut=.false.; if ( trim(outputcutfile(1)) /= "" ) ifoutputcut=.true.

     if ( (ifinputbiased .eqv. .false.) .and. (cvend(1) - cvstart(1) + 1 /= ninput) ) stop "input cv number is not equivalent to ninput!"
     if ( (ifoutputcut .eqv. .false.) .and. (nlabelcv > 0) .and. (labelcvend(1) - labelcvstart(1) + 1 /= noutput) ) stop "output cv number is not equivalent to noutput!"
     
     read(iofile(1),*) timestepsize; rewind(iofile(1))
   
     deepntotdata = 0
     do ifile=1, ntrajfile
        print "(a,a)",     "Read Trajectory File : ",trim(trajfile(ifile))
        irec = 0
        do
           read(iofile(ifile),*,iostat=ierr); if ( ierr < 0 ) exit
           irec = irec + 1; if ( skipdata > 0 .and. mod(irec,skipdata+1) /= 0 ) cycle
           if ( maxdataperfile > 0 .and. irec > maxdataperfile ) exit
           if ( recstart > 0 .and. recend > 0 ) then
              if ( irec < recstart ) cycle; if ( irec > recend ) exit
           end if
           deepntotdata = deepntotdata + 1
        end do
        rewind(iofile(ifile))
        print "(a,i16)",    "Read Records In File : ",irec
     end do
     if ( ifrotateinput .eqv. .true. ) deepntotdata = deepntotdata*24
     print "(a,i16,/)",      "          Total Data : ",deepntotdata
     if ( recstart > 0 .and. recend > 0 ) then
        print "(a,2i8)",     "        Record Range : ",recstart,recend
     end if

     i = (deepntotdata - ntau - 1)/batchsize + 1
     if ( batchnum == 0 ) then
        batchnum = i
     else if ( batchnum > i ) then
        print "(a,10i8)","batchnum exceeds the maximum (loadin) ", batchnum,deepntotdata,ntau,batchsize, i; stop
     end if

     print "(a,i16)",     "          Batch Size : ",batchsize
     print "(a,i16)",     "   Number of Batches : ",batchnum
     print "(a,f16.3)",   "      Time Step Size : ",timestepsize
     print "(a,i16)",     "  Normalization Mode : ",normalmode
     print "(a,f16.3)",   "Normalization Factor : ",normalfactor

  end if

  call mpi_bcast(batchnum,1,mpi_integer,0, mpi_comm_world,ierr)
  call mpi_bcast(deepntotdata,1,mpi_integer,0, mpi_comm_world,ierr)

  call deeppub_MPISharedMemoryAllocate(i, dimreal2d=(/ninput,deepntotdata/), sharereal2d=deeptrajcoor)

  if ( ntau > 0 ) call deeppub_MPISharedMemoryAllocate(i, dimint1d=(/deepntotdata/), shareint1d=deeptrajindex)
  if ( nlabelcv > 0 ) call deeppub_MPISharedMemoryAllocate(i, dimreal2d=(/nlabelcv,deepntotdata/), sharereal2d=labelcvtraj)
 
  if ( ngradcv > 0 ) then
     call deeppub_MPISharedMemoryAllocate(i, dimreal2d=(/ngradcv,deepntotdata/), sharereal2d=graddeeptrajcoor)
  end if

  if ( deepprocid == 0 ) then

     deeptrajcoor = 0d0
     if ( ntau > 0 ) deeptrajindex = 0
     if ( nlabelcv > 0 ) labelcvtraj = 0d0
     if ( ifrotateinput .eqv. .true. ) deepntotdata = deepntotdata/24

     if ( ifinputbiased .eqv. .true. ) print *

     itot = 0
     do ifile = 1, ntrajfile

        maxncv = 0; read(iofile(ifile),"(a)") tpstring
        do i = 5, maxninput
           read (tpstring, *, iostat=ierr) tpvec(1:i); if (ierr /= 0) exit
        end do
        maxncv = max(maxncv,i - 5); rewind(iofile(ifile))
 
        if ( ifinputbiased .eqv. .true. ) then

           if ( cvstart(ifile) > maxncv .or. cvend(ifile) > maxncv ) then
              print *,"cvstart or cvend is larger than max cv in trajectory file! ",ifile,cvstart(ifile),cvend(ifile),maxncv; stop
           end if

           tpinputbias = 0d0; tpinput2cvindex = 0
           if ( ifile > 1 .and.  trim(inputbiasfile(ifile)) == "" ) then
              print "(a,i6,a)","inputbiasfile ",ifile," is not presented!"; stop
           end if
           open(newunit=j,file=inputbiasfile(ifile),action="read")
           print "(a,a)",      "Read Input Bias File : ",trim(inputbiasfile(ifile))
           do irec = 1, ninput
              read(j,*,iostat=ierr) i,k,tpinputbias(irec)
              if ( ierr /= 0 ) stop "reading inputbiasfile error!"
              if ( k > 0 ) tpinput2cvindex(irec) = k
           end do
           close(j)
           tpcvstart = cvstart(ifile); tpcvend = cvend(ifile)
           tpgradcvstart = gradcvstart(ifile); tpgradcvend = gradcvend(ifile)

           print "(a,100i8)", "      CV Index Range : ",tpcvstart,tpcvend
           if ( tpcvstart == 0 .or. tpcvend == 0 ) stop "cvstart or cvend cannot be 0 when ifinputbias=true!"

           if ( nlabelcv > 0 ) then
              if ( ifoutputcut .eqv. .true. ) then
                 tpoutput2cvindex = 0
                 open(newunit=j,file=outputcutfile(ifile),action="read")
                 print "(a,a)",      "Read Output Cut File : ",trim(outputcutfile(ifile))
                 do irec = 1, noutput
                    read(j,*,iostat=ierr) i,k
                    if ( ierr /= 0 ) stop "reading outputcutfile error!"
                    if ( k > 0 ) tpoutput2cvindex(irec) = k
                 end do
                 close(j)
                 tplabelcvstart = labelcvstart(ifile); tplabelcvend = labelcvend(ifile)
                 print "(a,100i8)", "Label CV Index Range : ",tplabelcvstart,tplabelcvend
                 if ( tplabelcvstart == 0 .or. tplabelcvend == 0 ) stop "labelcvstart or labelcvend cannot be 0 when ifoutputcut=true!"
              else
                 tplabelcvstart = labelcvstart(1); tplabelcvend = labelcvend(1)
              end if
           end if

        else
           tpcvstart = cvstart(1); tpcvend = cvend(1)
           if ( nlabelcv > 0 ) then
              tplabelcvstart = labelcvstart(1); tplabelcvend = labelcvend(1)
           end if
           if ( ngradcv > 0 ) then
              tpgradcvstart = gradcvstart(1); tpgradcvend = gradcvend(1)
           end if
        end if

        if ( ifrotateinput .eqv. .true. ) then
           allocate(tpexpandinput(tpcvend-tpcvstart+1,24))
           if ( ngradcv > 0 ) allocate(tpexpandgrad(tpcvend-tpcvstart+1,24))
        end if

        irec = 0 
        do
           read(iofile(ifile),*,iostat=ierr) tpvec(1:4+maxncv); if ( ierr < 0 ) exit
           irec = irec + 1; if ( skipdata > 0 .and. mod(irec,skipdata+1) /= 0 ) cycle
           if ( maxdataperfile > 0 .and. irec > maxdataperfile ) exit
           if ( recstart > 0 .and. recend > 0 ) then
              if ( irec < recstart ) cycle; if ( irec > recend ) exit
           end if
           itot = itot + 1

           if ( ntau > 0 ) deeptrajindex(itot) = int(tpvec(3))

           if ( ifrotateinput .eqv. .true. ) then

              if ( ngradcv == 0 ) then
                 call deeppub_expandinput_by_rotation(tpvec(4+tpcvstart:4+tpcvend),tpexpandinput)
              else
                 call deeppub_expandinput_by_rotation(tpvec(4+tpcvstart:4+tpcvend),tpexpandinput,tpingrad=tpvec(4+tpgradcvstart:4+tpgradcvend),tpoutgrad=tpexpandgrad)
              end if

              if ( ifinputbiased .eqv. .false. ) then
                 do k = 1, 24
                    deeptrajcoor(:,(k-1)*deepntotdata+itot) = tpexpandinput(:,k)
                    if ( ngradcv > 0 ) graddeeptrajcoor(:,(k-1)*deepntotdata+itot) = tpexpandgrad(:,k)
                 end do
              else
                 do k = 1, 24
                    do i = 1, ninput
                       j = tpinput2cvindex(i); if ( j == 0 ) cycle
                       deeptrajcoor(i,(k-1)*deepntotdata+itot) = tpexpandinput(j,k) + tpinputbias(i)
                       if ( ngradcv > 0 .and. i <= ngradcv ) graddeeptrajcoor(i,(k-1)*deepntotdata+itot) = tpexpandgrad(j,k)
                    end do
                 end do
              end if
              if ( nlabelcv > 0 ) then
                 if ( ifoutputcut .eqv. .false. ) then
                    do k = 1, 24
                       labelcvtraj(1:nlabelcv,(k-1)*deepntotdata+itot) = tpvec(4+tplabelcvstart:4+tplabelcvend)
                    end do
                 else
                    do k = 1, 24
                       do i = 1, noutput
                          j = tpoutput2cvindex(i); if ( j == 0 ) cycle
                          labelcvtraj(i,(k-1)*deepntotdata+itot) = tpvec(4+tplabelcvstart+j-1)
                       end do
                    end do
                 end if
              end if

           else

              if ( ifinputbiased .eqv. .false. ) then
                 deeptrajcoor(1:tpcvend-tpcvstart+1,itot) = tpvec(4+tpcvstart:4+tpcvend)
                 if ( ngradcv > 0 ) graddeeptrajcoor(1:tpgradcvend-tpgradcvstart+1,itot) = tpvec(4+tpgradcvstart:4+tpgradcvend)
              else
                 do i = 1, ninput
                    j = tpinput2cvindex(i); if ( j == 0 ) cycle
                    deeptrajcoor(i,itot) = tpvec(4+tpcvstart+j-1) + tpinputbias(i)
                    if ( ngradcv > 0 ) graddeeptrajcoor(i,itot) = tpvec(4+tpgradcvstart+j-1)
                 end do 
              end if
              if ( nlabelcv > 0 ) then
                 if ( ifoutputcut .eqv. .false. ) then
                    labelcvtraj(1:nlabelcv,itot) = tpvec(4+tplabelcvstart:4+tplabelcvend)
                 else
                    do i = 1, noutput
                       j = tpoutput2cvindex(i); if ( j == 0 ) cycle
                       labelcvtraj(i,itot) = tpvec(4+tplabelcvstart+j-1)
                    end do
                 end if
              end if
           end if

        end do
        close(iofile(ifile))

        if ( ifrotateinput .eqv. .true. ) then
           deallocate(tpexpandinput)
           if ( ngradcv > 0 ) deallocate(tpexpandgrad)
        end if

     end do

     if ( itot /= deepntotdata ) stop "Requested Data in the trajectory file are not consistent!"
     if ( ifrotateinput .eqv. .true. ) deepntotdata = deepntotdata*24

  end if

  if ( deepprocid == 0 ) then

     print *; checkdeepntotdata = 0
     do ifile=1, maxntrajfile
        if ( checktrajfile(ifile) == "" ) then
           exit
        else
           inquire (file=checktrajfile(ifile), exist=ifexist)
           if ( ifexist .eqv. .false. ) then
              print *,"Trajfile ",trim(checktrajfile(ifile))," does not exist!"; stop
           end if
        end if 
        print "(a,a)","Read Validation File : ",trim(checktrajfile(ifile))
        open(newunit=iofile(ifile),file=checktrajfile(ifile),action="read")
        irec = 0
        do
           read(iofile(ifile),*,iostat=ierr); if ( ierr < 0 ) exit
           irec = irec + 1; if ( skipdata > 0 .and. mod(irec,skipdata+1) /= 0 ) cycle
           if ( maxdataperfile > 0 .and. irec > maxdataperfile ) exit
           if ( recstart > 0 .and. recend > 0 ) then
              if ( irec < recstart ) cycle; if ( irec > recend ) exit
           end if
           checkdeepntotdata = checkdeepntotdata + 1
        end do
        rewind(iofile(ifile))
        print "(a,i16)",    "Read Records In File : ",irec
     end do
     if ( checkdeepntotdata > 0 ) then
        print "(a,i16)",      "          Total Data : ",checkdeepntotdata
        if ( nlabelcv == 0 ) stop "nlabelcv must be positive for checktrajfile!"
        if ( ntau > 0 ) stop "ntau cannot be positive for checktrajfile!"
     end if

  end if
 
  call mpi_bcast(checkdeepntotdata,1,mpi_integer,0, mpi_comm_world,ierr)
   
  if ( checkdeepntotdata > 0 ) then

     call deeppub_MPISharedMemoryAllocate(i, dimreal2d=(/ninput,checkdeepntotdata/), sharereal2d=checkdeeptrajcoor)
     if ( nlabelcv > 0 ) call deeppub_MPISharedMemoryAllocate(i, dimreal2d=(/nlabelcv,checkdeepntotdata/), sharereal2d=checklabelcvtraj)
     if ( ntau > 0 ) call deeppub_MPISharedMemoryAllocate(i, dimint1d=(/checkdeepntotdata/), shareint1d=checkdeeptrajindex)
     if ( ngradcv > 0 ) call deeppub_MPISharedMemoryAllocate(i, dimreal2d=(/ngradcv,checkdeepntotdata/), sharereal2d=checkgraddeeptrajcoor)

     if ( deepprocid == 0 ) then

        checkdeeptrajcoor = 0d0
        if ( nlabelcv > 0 ) checklabelcvtraj = 0d0
        if ( ntau > 0 ) checkdeeptrajindex = 0        
     
        itot = 0
        do ifile = 1, maxntrajfile
           if ( checktrajfile(ifile) == "" ) exit

           maxncv = 0; read(iofile(ifile),"(a)") tpstring
           do i = 5, maxninput
              read (tpstring, *, iostat=ierr) tpvec(1:i); if (ierr /= 0) exit
           end do
           maxncv = max(maxncv,i - 5); rewind(iofile(ifile))

           tpinputbias = 0d0
           if ( ifinputbiased .eqv. .true. ) then
              if ( ifile > 1 .and.  trim(inputbiasfile(ifile+ntrajfile)) == "" ) then
                 print "(a,i6,a)","inputbiasfile ",ifile+ntrajfile," is not presented!"; stop
              end if
              open(newunit=j,file=inputbiasfile(ifile+ntrajfile),action="read")
              print "(a,a)",     "Read Input Bias File : ",trim(inputbiasfile(ifile+ntrajfile))
              do irec = 1, ninput
                 read(j,*,iostat=ierr) i,k,tpinputbias(irec)
                 if ( ierr /= 0 ) stop "reading inputbiasfile error!"
                 if ( k > 0 ) tpinput2cvindex(irec) = k
              end do
              close(j)
              tpcvstart = cvstart(ifile+ntrajfile); tpcvend = cvend(ifile+ntrajfile)
              tpgradcvstart = gradcvstart(ifile+ntrajfile); tpgradcvend = gradcvend(ifile+ntrajfile)

              print "(a,100i8)", "      CV Index Range : ",tpcvstart,tpcvend
              if ( tpcvstart == 0 .or. tpcvend == 0 ) stop "cvstart or cvend cannot be 0 when ifinputbias=true!"

              if ( nlabelcv > 0 ) then
                 if ( ifoutputcut .eqv. .true. ) then
                    if ( ifile > 1 .and.  trim(outputcutfile(ifile+ntrajfile)) == "" ) then
                       print "(a,i6,a)","outputcutfile ",ifile+ntrajfile," is not presented!"; stop
                    end if
                    open(newunit=j,file=outputcutfile(ifile+ntrajfile),action="read")
                    print "(a,a)",     "Read Output Cut File : ",trim(outputcutfile(ifile+ntrajfile))
                    do irec = 1, noutput
                       read(j,*,iostat=ierr) i,k
                       if ( ierr /= 0 ) stop "reading outputfile error!"
                       if ( k > 0 ) tpoutput2cvindex(irec) = k
                    end do
                    close(j)
                    tplabelcvstart = labelcvstart(ifile+ntrajfile); tplabelcvend = labelcvend(ifile+ntrajfile)
                    print "(a,100i8)", "Label CV Index Range : ",tplabelcvstart,tplabelcvend
                    if ( tplabelcvstart == 0 .or. tplabelcvend == 0 ) stop "labelcvstart or labelcvend cannot be 0 when ifoutputcut=true!"
                 else
                    tplabelcvstart = labelcvstart(1); tplabelcvend = labelcvend(1)
                 end if
              end if
           else
              tpcvstart = cvstart(1); tpcvend = cvend(1)
              if ( nlabelcv > 0 ) then
                 tplabelcvstart = labelcvstart(1); tplabelcvend = labelcvend(1)
              end if
              if ( ngradcv > 0 ) then
                 tpgradcvstart = gradcvstart(1); tpgradcvend = gradcvend(1)
              end if
           end if

           irec = 0
           do
              read(iofile(ifile),*,iostat=ierr) tpvec(1:4+maxncv); if ( ierr /= 0 ) exit
              irec = irec + 1; if ( skipdata > 0 .and. mod(irec,skipdata+1) /= 0 ) cycle
              if ( maxdataperfile > 0 .and. irec > maxdataperfile ) exit
              if ( recstart > 0 .and. recend > 0 ) then
                 if ( irec < recstart ) cycle; if ( irec > recend ) exit
              end if
              itot = itot + 1
              if ( ntau > 0 ) checkdeeptrajindex(itot) = int(tpvec(3))
              if ( ifinputbiased .eqv. .false. ) then
                 checkdeeptrajcoor(1:tpcvend-tpcvstart+1,itot) = tpvec(4+tpcvstart:4+tpcvend)
                 if ( ngradcv > 0 ) checkgraddeeptrajcoor(1:tpgradcvend-tpgradcvstart+1,itot) = tpvec(4+tpgradcvstart:4+tpgradcvend)
              else
                 do i = 1, ninput
                    j = tpinput2cvindex(i); if ( j == 0 ) cycle
                    checkdeeptrajcoor(i,itot) = tpvec(4+tpcvstart+j-1) + tpinputbias(i)
                    if ( ngradcv > 0 .and. i <= ngradcv ) checkgraddeeptrajcoor(i,itot) = tpvec(4+tpgradcvstart+j-1)
                 end do
              end if
              if ( nlabelcv > 0 ) then
                 if ( ifoutputcut .eqv. .false. ) then
                    checklabelcvtraj(1:nlabelcv,itot) = tpvec(4+tplabelcvstart:4+tplabelcvend)
                 else
                    do i = 1, noutput
                       j = tpoutput2cvindex(i); if ( j == 0 ) cycle
                       checklabelcvtraj(i,itot) = tpvec(4+tplabelcvstart+j-1)
                    end do
                 end if
              end if
           end do
           close(iofile(ifile))
        end do
        if ( itot /= checkdeepntotdata ) stop "Requested data in the checkfile are not consistent!"
     end if

  end if

  call mpi_barrier(mpi_comm_world, ierr)
end subroutine

subroutine deep_traj_normalization(ifresettrajmin)
  logical,intent(in),optional :: ifresettrajmin
  integer :: i
  real*8 :: tpmin, tpmax

  if ( trajmin(1) == 0d0 .and. trajmax(1) == 0d0 ) then
     do i = 1, ninput
        trajmin(i) = minval(deeptrajcoor(i,:)); trajmax(i) = maxval(deeptrajcoor(i,:))
     end do
  else if ( present(ifresettrajmin) ) then
     if ( ifresettrajmin .eqv. .true. ) then
        do i = 1, ninput
           trajmin(i) = minval(deeptrajcoor(i,:)); trajmax(i) = maxval(deeptrajcoor(i,:))
        end do
     end if
  end if
 
  if ( normalmode /= 0 ) then
     do i = 1, ninput
        tpmin = trajmin(i); tpmax = trajmax(i); if ( tpmin == tpmax ) cycle
        if ( normalmode == 1 ) then
           deeptrajcoor(i,1:deepntotdata) = normalfactor*(deeptrajcoor(i,1:deepntotdata) - tpmin)/(tpmax-tpmin)
           if ( checkdeepntotdata > 0 ) checkdeeptrajcoor(i,1:checkdeepntotdata) = normalfactor*(checkdeeptrajcoor(i,1:checkdeepntotdata) - tpmin)/(tpmax-tpmin)
        else if ( normalmode == 2 ) then
           deeptrajcoor(i,1:deepntotdata) = normalfactor*(2d0*deeptrajcoor(i,1:deepntotdata) - (tpmin+tpmax))/(tpmax-tpmin)
           if ( checkdeepntotdata > 0 ) checkdeeptrajcoor(i,1:checkdeepntotdata) = normalfactor*(2d0*checkdeeptrajcoor(i,1:checkdeepntotdata) - (tpmin+tpmax))/(tpmax-tpmin)
        else if ( normalmode == 3 ) then
            tpmin = sum(deeptrajcoor(i,1:deepntotdata))/dble(deepntotdata)
            tpmax = sum(deeptrajcoor(i,1:deepntotdata)**2)/dble(deepntotdata)
            tpmax = sqrt(tpmax - tpmin**2)
            deeptrajcoor(i,1:deepntotdata) = (deeptrajcoor(i,1:deepntotdata) - tpmin)/tpmax
            if ( checkdeepntotdata > 0 ) checkdeeptrajcoor(i,1:deepntotdata) = (checkdeeptrajcoor(i,1:deepntotdata) - tpmin)/tpmax
        else
           stop "Invalid normalization mode!"
        end if
     end do
  end if

  if ( nlabelcv > 0 ) then
     if ( jobtype == TRAIN ) then
        do i = 1, nlabelcv
           labelcvtrajmin(i) = minval(labelcvtraj(i,:)); labelcvtrajmax(i) = maxval(labelcvtraj(i,:))
           if ( labelcvtrajmin(i) < -9999.0d0 ) labelcvtrajmin(i) = -9999d0
           if ( labelcvtrajmin(i) > 9999.0d0 ) labelcvtrajmin(i) = 9999d0
           if ( labelcvtrajmax(i) < -9999.0d0 )  labelcvtrajmax(i) = -9999d0
           if ( labelcvtrajmax(i) > 9999.0d0 )  labelcvtrajmax(i) = 9999d0
           labelcvtrajavg(i) = sum(labelcvtraj(i,:))/dble(deepntotdata)
        end do
     end if
     if ( ifavglabel .eqv. .true. ) then
        do i = 1, nlabelcv
           labelcvtraj(i,:) = labelcvtraj(i,:) - labelcvtrajavg(i)
        end do
        if ( checkdeepntotdata > 0 ) then
           do i = 1, nlabelcv
              checklabelcvtraj(i,:) = checklabelcvtraj(i,:) - labelcvtrajavg(i)
           end do
        end if
     end if
  end if

  if ( ngradcv > 0 ) then
     if ( jobtype == TRAIN ) then
        do i = 1, ngradcv
           gradtrajmin(i) = minval(graddeeptrajcoor(i,:)); gradtrajmax(i) = maxval(graddeeptrajcoor(i,:))
        end do
     end if
  end if

end subroutine

!========================= Network Export and Import ====================================

subroutine deep_network_save(tpnetworkfile)
  character(len=*),intent(in),optional :: tpnetworkfile
  integer :: i,j,ilayer,iofile

  if ( present(tpnetworkfile) ) then
     open(newunit=iofile,file=tpnetworkfile,action="write")
  else
     open(newunit=iofile,file=networkfile,action="write")
  end if
  write(iofile,"(a)") "network layers:"
  write(iofile,"(20i5)") layers(1:nlayer)
  write(iofile,"(a)") "activation function:"
  write(iofile,"(a20)") activation
  write(iofile,"(a)") "batch size:"
  write(iofile,"(i8)") batchsize
  write(iofile,"(a)") "time steps:"
  write(iofile,"(i8)") ntau
  write(iofile,"(a)") "cv range:"
  write(iofile,"(*(i8))") (cvstart(i), cvend(i), i=1,size(cvstart))
  write(iofile,"(a)") "normalization mode:"
  write(iofile,"(i8)") normalmode
  write(iofile,"(a)") "normalization factor:"
  write(iofile,"(f8.3)") normalfactor
  write(iofile,"(a)") "cv low boundary:"
  write(iofile,'(*(f15.8))') trajmin
  write(iofile,"(a)") "cv up boundary:"
  write(iofile,'(*(f15.8))') trajmax
  write(iofile,"(a)") "label cv range:"
  write(iofile,"(*(i8))") (labelcvstart(i), labelcvend(i), i=1,size(labelcvstart))
  write(iofile,"(a)") "label cv low boundary:"
  write(iofile,'(*(f15.8))') (labelcvtrajmin(i),i=1,nlabelcv)
  write(iofile,"(a)") "label cv up boundary:"
  write(iofile,'(*(f15.8))') (labelcvtrajmax(i),i=1,nlabelcv)
  write(iofile,"(a,l4)") "label cv average: ",ifavglabel
  write(iofile,'(*(f20.8))') (labelcvtrajavg(i),i=1,nlabelcv)
  write(iofile,"(a)") "grad cv range:"
  write(iofile,"(*(i8))") (gradcvstart(i), gradcvend(i), i=1,size(gradcvstart))
  write(iofile,"(a)") "grad cv weight:"
  write(iofile,"(2f12.3)") gradcvweight
  write(iofile,"(a)") "grad cv low boundary:"
  write(iofile,'(*(f15.8))') (gradtrajmin(i),i=1,ngradcv)
  write(iofile,"(a)") "grad cv up boundary:"
  write(iofile,'(*(f15.8))') (gradtrajmax(i),i=1,ngradcv)
  write(iofile,"(a)") "labelcv group weight:"
  write(iofile,'(*(f10.3))') (labelcvgroupweight(i),i=1,size(labelcvgroupweight))
!  write(iofile,"(a,l4)") "layer normalization weight: ",ifuselayernorm
!  write(iofile,'(*(f15.6))') (mlplayers(ilayer)%layerweight,ilayer=2,nlayer-1)
!  write(iofile,"(a)") "layer normalization bias:"
!  write(iofile,'(*(f15.6))') (mlplayers(ilayer)%layerbias,ilayer=2,nlayer-1)
  close(iofile)

end subroutine

!========================= Network Forward and Backward propagation ====================================

subroutine deep_get_batchdata(tpshuffleidx,tpibatch,tpinputs,tptrueoutputs,tptruegrads,tperrormark)
  integer,intent(in) :: tpibatch,tpshuffleidx(:)
  real*8,intent(out) :: tpinputs(:,:),tptrueoutputs(:,:)
  real*8,intent(out),optional :: tptruegrads(:,:)
  integer,intent(out) :: tperrormark(:)
  integer :: idata,istart,ipos,realidata,tpninput,tpnoutput,tpngradcv

  tperrormark = 0; istart = (tpibatch-1)*batchsize
  tpninput = size(tpinputs,1); tpnoutput = size(tptrueoutputs,1)
  tpngradcv = 0; if ( present(tptruegrads) ) tpngradcv = size(tptruegrads,1)
  do idata = 1, batchsize
     ipos = istart + idata
     if ( ipos > deepntotdata ) then
         tperrormark(idata) = 1; cycle
     end if
     realidata = tpshuffleidx(ipos)
     tpinputs(1:tpninput,idata) = deeptrajcoor(1:tpninput,realidata)
     tptrueoutputs(1:tpnoutput,idata) = labelcvtraj(1:tpnoutput,realidata)
     if ( tpngradcv > 0 ) tptruegrads(1:tpngradcv,idata) = graddeeptrajcoor(1:tpngradcv,realidata)
  end do
end subroutine

subroutine deep_get_batchdata_check(tpibatch,tpinputs,tptrueoutputs,tptruegrads,tperrormark)
  integer,intent(in) :: tpibatch
  real*8,intent(out) :: tpinputs(:,:),tptrueoutputs(:,:)
  real*8,intent(out),optional :: tptruegrads(:,:)
  integer,intent(out) :: tperrormark(:)
  integer :: idata,istart,ipos,tpninput,tpnoutput,tpngradcv

  tperrormark = 0; istart = (tpibatch-1)*batchsize
  tpninput = size(tpinputs,1); tpnoutput = size(tptrueoutputs,1)
  tpngradcv = 0; if ( present(tptruegrads) ) tpngradcv = size(tptruegrads,1)
  do idata = 1, batchsize
     ipos = istart + idata
     if ( ipos > checkdeepntotdata ) then
         tperrormark(idata) = 1; cycle
     end if
     tpinputs(1:tpninput,idata) = checkdeeptrajcoor(1:tpninput,ipos)
     tptrueoutputs(1:tpnoutput,idata) = checklabelcvtraj(1:tpnoutput,ipos)
     if ( tpngradcv > 0 ) tptruegrads(1:tpngradcv,idata) = checkgraddeeptrajcoor(1:tpngradcv,ipos)
  end do
end subroutine

attributes(global) subroutine deep_get_batchdata_cuda(inet,ibatch,igroup,ninput)
  integer,intent(in),value :: inet,ibatch,igroup,ninput
  integer :: istate,irec,ipos

  istate = (blockidx%x-1)*32+threadidx%x; irec = (istate-1)/ninput+1; if ( irec > icudagroup_d ) return
  istate = istate - (irec-1)*ninput; if ( istate == 1 ) errormark_d(irec) = 1
  ipos = (igroup-1)*icudagroup_d*deepprocnum_d + deepprocid_d*icudagroup_d + irec; if ( ipos > batchsize_d ) return
  ipos = (ibatch-1)*batchsize_d + ipos

  if ( deepntotdata_d > 0 ) then

     if ( ipos > deepntotdata_d - ntau_d ) return

     ipos = shuffleidx_d(ipos)
     if ( ntau_d > 0 ) then
        if ( deeptrajindex_d(ipos) /= deeptrajindex_d(ipos+ntau_d) ) return
     end if
     if ( istate <= ninput ) then
        if ( istate == 1 ) errormark_d(irec) = 0

        if ( inet == 2 ) then
           batchdata_d((irec-1)*ninput + istate) = deeptrajcoor_d(istate,ipos+ntau_d)
        else
           batchdata_d((irec-1)*ninput + istate) = deeptrajcoor_d(istate,ipos)

           if ( ngradcv_d > 0 ) then
              batchgraddata_d((irec-1)*ninput + istate) = graddeeptrajcoor_d(istate,ipos)
           end if

        end if
     end if

  else

     if ( ipos > checkdeepntotdata_d ) return

     if ( istate <= ninput ) then
        if ( istate == 1 ) errormark_d(irec) = 0
        batchdata_d((irec-1)*ninput + istate) = checkdeeptrajcoor_d(istate,ipos)

        if ( ngradcv_d > 0 ) then
           batchgraddata_d((irec-1)*ninput + istate) = checkgraddeeptrajcoor_d(istate,ipos)
        end if

     end if

  end if
end subroutine

attributes(global) subroutine deep_get_batchlabel_cuda(inet,ibatch,igroup,noutput)
  integer,intent(in),value :: ibatch,inet,igroup,noutput
  integer :: istate,irec,index

  if ( nlabelcv_d == 0 ) return

  istate = (blockidx%x-1)*32+threadidx%x
  irec = (istate-1)/noutput+1; if ( irec > icudagroup_d ) return
  if ( errormark_d(irec) == 1 ) return

  istate = istate - (irec-1)*noutput; if ( istate > noutput ) return

  index = (ibatch-1)*batchsize_d + (igroup-1)*icudagroup_d*deepprocnum_d + deepprocid_d*icudagroup_d + irec
  if ( deepntotdata_d > 0 ) then
     index = shuffleidx_d(index)
     batchlabel_d((irec-1)*noutput + istate) = labelcvtraj_d(istate,index)
  else
     batchlabel_d((irec-1)*noutput + istate) = checklabelcvtraj_d(istate,index)
  end if
end subroutine

!subroutine deep_shuffledata()
!  use thrustlib
!  integer :: i
!
!  !  thrust::sequence(data, data + N);
!  !  thrust::default_random_engine rng;
!  !  rng.seed(12345678);
!  !  thrust::shuffle(data, data + N, rng);
!
!  shuffleidx_d = [(i,i=1,deepntotdata)]
!  call thrustlib_thrustsort(shuffleidx_d,shuffleidx_d,deepntotdata)
!end subroutine

end module
