program main
  use mpi; use deeppub
  implicit none
  integer :: ierr,procid,procnum
  character*100 :: parmfile,command

  call mpi_init(ierr)
  call mpi_comm_rank(mpi_comm_world, procid, ierr)
  call mpi_comm_size(mpi_comm_world, procnum, ierr)

  parmfile="deep.in"
  call get_command_argument(1,command)
  if ( trim(command) == "-i" ) then
     call get_command_argument(2,parmfile)
  end if

  call deephub_go(parmfile,procnum,procid)
  call mpi_finalize(ierr)
end program
