! TAE reference
!
! Christoph Wehmeyer and Frank Noe
! Time-lagged autoencoders: Deep learning of slow collective variables for molecular kinetics.
! J. Chem. Phys. 2018, 148, 241703.

module tae
  use deeppub
  use deep
  use mlp
  implicit none

contains

subroutine tae_go(parmfile)
  character(len=*),intent(in) :: parmfile
  integer :: ilen,iofile,ierr
  character*100 :: task
  namelist / deep / task

  open(newunit=iofile,file=parmfile,action="read")
  read(iofile, nml=deep, iostat=ierr); if ( ierr < 0 ) stop "Cannot find the deep namelist!"
  close(iofile)

  ilen = len(trim(task))
  if ( task(ilen-4:ilen) == "train" ) then
     jobtype = TRAIN
  else if ( task(ilen-6:ilen) == "predict" ) then
     jobtype = PREDICT
  else if ( task(ilen-4:ilen) == "check" ) then
     jobtype = CHECK
  end if

  call deep_initialize(parmfile)
  call mlp_initialize(ninput,noutput,nlayer,layers,totparms)
  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms

  if ( noutput /= ninput ) stop "TAE error, noutput /= niniput!"
  if ( mod(nlayer,2) /= 1 ) stop "TAE error, nlayer must be an odd number!"

  select case(jobtype)
  case (TRAIN)
     call tae_train()
  case (PREDICT)
     call tae_predict()
  case (CHECK)
     call tae_check_grad()
     call tae_check_flood()
  end select
end subroutine

!========================= TAE Network Training and Prediction ====================================

! Train the TAE network by the mini-batch gradient descent method
subroutine tae_train()
  integer,dimension(:),allocatable :: shuffleidx
  integer :: index,ibatch,iepoch,idata,realidata,errormark(batchsize),tpgroupindex,tpbatchindex
  real*8 :: loss,totloss,tpinputs(ninput,batchsize,maxnsteps),tptrueoutputs(noutput,batchsize,maxnsteps),tpoutputs(noutput,batchsize,maxnsteps),time1,time2
  real*8 :: initime,endtime
  real :: rand

  print "(/,a)","TAE Training Data"

  allocate(shuffleidx(deepntotdata-ntau))
  do idata = 1,deepntotdata-ntau
     shuffleidx(idata) = idata
  end do

  call deeppub_time_from_1970(initime)
  do iepoch = 1,nepoch

     ! shuffling the data
     do idata = deepntotdata-ntau, 2, -1
        call random_number(rand); index = int(rand * idata) + 1
        realidata = shuffleidx(index); shuffleidx(index) = shuffleidx(idata); shuffleidx(idata) = realidata
     end do

     totloss =  0d0; ibatch = 0; tpbatchindex = 0; tpgroupindex = 0; errormark = 0
     do idata = 1, deepntotdata

        tpbatchindex = tpbatchindex + 1
        tpgroupindex = tpgroupindex + 1
        realidata = shuffleidx(idata)

        if ( deeptrajindex(realidata) /= deeptrajindex(realidata+ntau) ) then
           errormark(tpgroupindex)=1
        end if
        if ( errormark(tpgroupindex) == 0 ) then
           tpinputs(:,tpgroupindex,1) = deeptrajcoor(:,realidata)
           tptrueoutputs(:,tpgroupindex,1) = deeptrajcoor(:,realidata+ntau)
        end if

        if ( tpgroupindex == batchsize .or. idata == deepntotdata ) then
           if ( tpgroupindex < batchsize ) errormark(tpgroupindex+1:batchsize) = 1
           call mlp_network_forward(1,tpinputs,tpoutputs,errormark=errormark)
           call mlp_network_backward_bptt(1,tptrueoutputs,.true.,errormark=errormark)
           loss = 0d0
           do index = 1, batchsize
              if ( errormark(index) == 1 ) cycle
              loss = loss + sum((tptrueoutputs(:,index,1) - tpoutputs(:,index,1))**2)
           end do
           totloss = totloss + loss
           errormark = 0; tpgroupindex = 0
        end if

        if ( tpbatchindex == batchsize .or. idata == deepntotdata ) then
           call mlp_network_update(); tpbatchindex = 0
           ibatch = ibatch + 1; if ( ibatch == batchnum ) exit
        end if

     end do

     index = min(batchsize*batchnum, deepntotdata-ntau)
     ! print "(a,i8,1000f15.8)","Epoch ",iepoch,sqrt(totloss/dble(index))
     call deeppub_time_from_1970(endtime)
     if (mod(iepoch,20)==0) call deeppub_print_time(6,(endtime-initime),iepoch,dble(iepoch)/dble(nepoch))

  end do

  print "(/,a,f20.15)","Final Loss Function ",sqrt(totloss/dble(index))
  call deep_network_save()
  call mlp_network_save()
end subroutine

subroutine tae_predict()
  integer :: iofile,idata,iencodelayer
  real*8 :: tpinputs(ninput,1,1),tpoutputs(noutput,1,1)

  print "(/,a)","TAE Testing Data"

  iencodelayer = (nlayer+1)/2
  open(newunit=iofile,file="predict.txt",action="write")
  do idata = 1, deepntotdata
     tpinputs(:,1,1) = deeptrajcoor(:,idata)
     call mlp_network_forward(1,tpinputs,tpoutputs)
     write(iofile,'(f10.3,3i2,10f10.4)') dble(idata)*timestepsize,0,0,0,mlplayers(iencodelayer)%hiddenstate(:,1,1,1)
  end do
  close(iofile)
end subroutine

subroutine tae_check_grad()
  integer :: ilayer,idata,i,j,ipos
  real*8 :: upv,downv,h,originv,refgrad,maxerr
  real*8 :: tpinputs(ninput,batchsize,maxnsteps),tpoutputs(ninput,batchsize,maxnsteps),tptrueoutputs(ninput,batchsize,maxnsteps)

  ! set the inputs and calculate the output values of neurons in all the layers
  do idata = 1, batchsize
     tpinputs(:,idata,1) = deeptrajcoor(:,idata)
  end do
  call mlp_network_forward(1,tpinputs,tpoutputs)
  ! calculate the gradients in all the layers, gradients, grad_weights_l2l, grad_weights_t2t, grad_bias
  do idata = 1, batchsize
     tpoutputs(:,idata,1) = deeptrajcoor(:,idata+ntau)
  end do
  call mlp_network_backward_bptt(1,tpoutputs,.true.)

  ! set the inputs again
  do idata = 1, batchsize
     tpinputs(:,idata,1) = deeptrajcoor(:,idata)
     tptrueoutputs(:,idata,1) = deeptrajcoor(:,idata+ntau)
  end do

  h = 0.001d0; maxerr = 0d0
  do ilayer = nlayer,2,-1

     do i = 1, mlplayers(ilayer)%neurons
        do j = 1, mlplayers(ilayer-1)%neurons
           originv = mlplayers(ilayer)%weights_l2l(i,j)
           mlplayers(ilayer)%weights_l2l(i,j) = originv + h
           call get_loss(upv)
           mlplayers(ilayer)%weights_l2l(i,j) = originv - h
           call get_loss(downv)
           refgrad = (upv-downv)/(2d0*h)
           maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_weights_l2l(i,j)-refgrad))
           mlplayers(ilayer)%weights_l2l(i,j) = originv
        end do
     end do

     do i = 1,mlplayers(ilayer)%neurons
        originv = mlplayers(ilayer)%bias(i)
        mlplayers(ilayer)%bias(i) = originv + h
        call get_loss(upv)
        mlplayers(ilayer)%bias(i) = originv - h
        call get_loss(downv)
        refgrad = (upv-downv)/(2d0*h)
        maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_bias(i)-refgrad))
        mlplayers(ilayer)%bias(i) = originv
     end do

  end do

  print "(a,f20.15)","TAE Network Gradient Error:" ,maxerr

contains

subroutine get_loss(tploss)
  real*8,intent(out) :: tploss

  call mlp_network_forward(1,tpinputs,tpoutputs)
  tploss = 0d0
  do idata = 1, batchsize
     tploss = tploss + sum((tptrueoutputs(:,idata,1) - tpoutputs(:,idata,1))**2)
  end do
end subroutine
end subroutine

!========================= Enhanced Sampling (TAE) ====================================

subroutine tae_flooding_initialize(tpnetworkfile,tpninput,tpnoutput)
  character(len=*),intent(in) :: tpnetworkfile
  integer,intent(out) :: tpninput,tpnoutput

  networkfile = tpnetworkfile; jobtype = PREDICT
  call deep_initialize("")
  call mlp_initialize(ninput,noutput,nlayer,layers,totparms)
  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms
  tpninput = ninput; tpnoutput = noutput
end subroutine

subroutine tae_flooding_forward(prein,preout)
  real*8,dimension(:),intent(in) :: prein
  real*8,dimension(:),intent(out) :: preout
  real*8 :: tpinputs(ninput,1,1),tpoutputs(noutput,1,1)

  if ( normalmode == 1 ) then
     tpinputs(:,1,1) = normalfactor*( prein - trajmin )/( trajmax - trajmin )
  else if ( normalmode == 2 ) then
     tpinputs(:,1,1) = normalfactor*( 2d0*prein - (trajmin+trajmax) )/( trajmax - trajmin )
  else
     tpinputs(:,1,1) = prein
  end if
  call mlp_network_forward(1,tpinputs,tpoutputs)
  preout = mlplayers((nlayer+1)/2)%hiddenstate(:,1,1,1)
end subroutine

subroutine tae_flooding_backward(bout, bin)
  real*8,dimension(:) :: bout,bin
  integer :: ilayer,iedlayer
  real*8 :: tpvec(ninput)
  real*8,dimension(maxval(mlplayers(:)%neurons)) :: tpdeltalayer

  iedlayer = (nlayer+1)/2    ! encode layer
  tpdeltalayer(1:mlplayers(iedlayer)%neurons) = bout*mlplayers(iedlayer)%grad_active(:,1,1,1)

  do ilayer = iedlayer-1,1,-1
     tpdeltalayer(1:mlplayers(ilayer)%neurons) = &
             matmul(transpose(mlplayers(ilayer+1)%weights_l2l(:,:)),tpdeltalayer(1:mlplayers(ilayer+1)%neurons))
     if ( ilayer >= 2 ) then
        tpdeltalayer(1:mlplayers(ilayer)%neurons) = &
             mlplayers(ilayer)%grad_active(:,1,1,1)*tpdeltalayer(1:mlplayers(ilayer)%neurons)
     end if
  end do

  if ( normalmode == 1 ) then
     bin = normalfactor*tpdeltalayer(1:mlplayers(1)%neurons)/(trajmax - trajmin)
  else if ( normalmode == 2 ) then
     bin = normalfactor*2d0*tpdeltalayer(1:mlplayers(1)%neurons)/(trajmax - trajmin)
  else
     bin = tpdeltalayer(1:mlplayers(1)%neurons)
  end if
end subroutine

subroutine tae_check_flood()
  real*8 :: predata(ninput),preout(noutput),bout(noutput),bin(ninput)
  real*8 :: tpout1(noutput),tpout2(noutput),tpinputs(ninput,1,1),tpoutputs(noutput,1,1)
  real*8 :: upv,downv,h,originv(ninput),maxerr
  integer :: ilayer,i,j,k

  call random_number(predata)
  batchsize = 1; maxnsteps = 1; originv = predata
  call tae_flooding_forward(predata,preout)
  bout = 1d0
  call tae_flooding_backward(bout, bin)

  h = 0.01d0; maxerr = 0d0
  do i = 1,mlplayers(1)%neurons
     predata = originv
     predata(i) = originv(i) + h
     call tae_flooding_forward(predata,tpout1)
     predata(i) = originv(i) - h
     call tae_flooding_forward(predata,tpout2)
     maxerr = max(abs(sum((tpout1-tpout2)/(2d0*h))-bin(i)),maxerr)
  end do
  write(6,'(a,f20.15)'),'TAE Network Flooding Error:',maxerr
end subroutine

end module
