module gnn
  !use torch
  use mpi; use deeppub; use deep
  use mlp0; use gnnpub; use cpugnn; use cudagnn
  use multidnn; use torch
  implicit none

  type(mlptype) :: net0

contains

subroutine gnn_go(parmfile)
  character(len=*),intent(in) :: parmfile
  integer :: ilen,iofile,ierr
  logical :: ifok
  character*100 :: task
  namelist / deep / task

  open(newunit=iofile,file=parmfile,action="read")
  read(iofile, nml=deep, iostat=ierr); if ( ierr < 0 ) stop "Cannot find the deep namelist!"
  close(iofile)

  ilen = len(trim(task))
  if ( task(ilen-4:ilen) == "train" ) then
     jobtype = TRAIN
  else if ( task(ilen-6:ilen) == "predict" ) then
     jobtype = PREDICT
  else if ( task(ilen-4:ilen) == "check" ) then
     jobtype = CHECK
  else if ( task(ilen-1:ilen) == "md" ) then
     jobtype = MD
  else
     stop "unrecognized job"
  end if

  call gnnpub_initialize(parmfile, ifok)

  if ( ifok ) then
     if ( icudagroup > 0 ) call cudagnn_initialize()
     !call mlp0_network_reloadall(networklist)
     !call gnn_predict(); return
     !call cpugnn_check_grads(); return
     select case(jobtype)
     case (TRAIN)
        call gnn_train()
     case (PREDICT)
        call gnn_predict()
     case ( MD )
        call gnn_md()
     end select
     return
  end if

  call multidnn_initialize(parmfile, ifok)

  if ( ifok ) then

     return
  end if

  networkfile=""; call deep_initialize(parmfile)
  call mlp0_initialize(net0,layers,totparms,tpoutputweight=labelcvweight,tpifbias=ifbias)

  call mlp0_network_prepare([net0])

  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms

  select case(jobtype)
  case (TRAIN)
     call gnn_train2()
  case (PREDICT)
     call gnn_predict2()
  case (CHECK)
     call gnn_check_grads()
  end select

end subroutine

!========================= DNN Network Training and Prediction ====================================

subroutine gnn_train()
  integer,dimension(:),pointer :: shuffleidx
  integer :: i,j,k,ibatch,index,iepoch,idata,realidata,istart,ipos,ilayer,igroup
  integer :: system,ierr,istream,errormark(batchsize)
  real*8 :: loss,totloss,checktotloss,gradtotloss,checkgradtotloss
  real*8 :: mintotloss,pretotloss,totlossflood,learnratecoolminloss
  real*8 :: initime,endtime
  real :: rand
  integer :: learnratecoolminstep,minlossepoch,learnratewarmpeakepoch
  logical :: iflearnratewarm
  character*150 :: tpstring,tpfilename,lastnetworkfilename

  if ( deepprocnum > 0 ) then
     call deeppub_MPISharedMemoryAllocate(i, dimint1d=[deepntotdata], shareint1d=shuffleidx)
  else
     allocate(shuffleidx(nsnap))
  end if

  if ( icudagroup > 0 ) allocate(shuffleidx_d(deepntotdata))

  if ( deepprocid == 0 ) then
      call deeppub_time_from_1970(initime)
      print "(/,a)","GNN Training Data"
      shuffleidx = [(idata,idata=1,deepntotdata)]
  end if

  lastnetworkfilename=""; mintotloss = huge(1.0); pretotloss = huge(1.0); minlossepoch = 0
  if ( learnratewarmsteps > 0 ) then
     iflearnratewarm = .true.; learnrate = minlearnrate; learnratecoolminstep = 0
     if ( icudagroup > 0 ) learnrate_d = learnrate
  end if

  do iepoch = 1,nepoch

     if ( deepprocid == 0 ) then
        do idata = deepntotdata, 2, -1
           call random_number(rand); index = int(rand * idata) + 1
           realidata = shuffleidx(index); shuffleidx(index) = shuffleidx(idata); shuffleidx(idata) = realidata
        end do
     end if
     call mpi_barrier(mpi_comm_world,ierr)

     allbatchnatom = 0
     if ( icudagroup == 0 ) then
        totloss = 0d0; totenergyloss = 0d0; totforceloss = 0d0
     else if ( icudagroup > 0 ) then
        totloss_d = 0.0_SD; shuffleidx_d = shuffleidx
        totenergyloss_d = 0.0_SD; totforceloss_d = 0.0_SD
     end if

     do ibatch = 1, batchnum

        if ( icudagroup == 0 ) then

           call gnnpub_prepare_batchsize(shuffleidx,ibatch,1)
           call gnnpub_initialize_for_dynamic_batchsize()

           call cpugnn_prepare_batchdata()
           call cpugnn_calculate_batch_edge_info(shuffleidx,ibatch)
           call cpugnn_network_forward()
           call cpugnn_network_backward()

        else

           do igroup = 1, (batchsize-1)/(ignncudagroup*deepprocnum)+1
              call gnnpub_prepare_batchsize(shuffleidx,ibatch,igroup)
              if ( batchsnapnmol == 0 ) exit
              call gnnpub_initialize_for_dynamic_batchsize()
              call cudagnn_prepare_batchdata()
              !call cudagnn_calculate_batch_edge_info(shuffleidx,ibatch,igroup)
              call cudagnn_network_forward()
              call cudagnn_network_backward()
           end do

        end if

        call gnnpub_network_update()

     end do

     if ( icudagroup > 0 ) then
        call deeppub_ncclAllReduce_scalar(totenergyloss_d); totenergyloss = totenergyloss_d
        if ( iftrainforce ) then
           call mpi_reduce(allbatchnatom, index, 1, mpi_integer, mpi_sum, 0, mpi_comm_world, ierr) 
           allbatchnatom = index
           call deeppub_ncclAllReduce_scalar(totforceloss_d); totforceloss = totforceloss_d
        end if
     end if

     index = min(batchsize*batchnum, deepntotdata)
     call deeppub_loss_function_end(index, totenergyloss); totloss = totenergyloss
     if ( iftrainforce ) then
        call deeppub_loss_function_end(allbatchnatom, totforceloss); totloss = totforceloss
     end if

     if ( deepprocid == 0 ) then

        if ( checkdeepntotdata == 0 ) then
           if ( iftrainforce .eqv. .false. ) then
              print "(a,i6,5x,a,f18.6,5x,a,f12.8)","Epoch ",iepoch,"Loss ",totenergyloss,"Learnrate ",learnrate
           else
              print "(a,i6,5(5x,a,f18.6))","Epoch ",iepoch,"Loss ",totenergyloss,"Learnrate ",learnrate,"ForceLoss ",totforceloss
           end if
        end if

        call deeppub_time_from_1970(endtime)
        if (mod(iepoch,5)==0 .and. deepprocid==0) call deeppub_print_time(6,(endtime-initime),iepoch,dble(iepoch)/dble(nepoch))

        if ( learnratewarmsteps > 0 ) then
           if ( iflearnratewarm .eqv. .true. ) then
              learnrate = learnrate + (maxlearnrate-minlearnrate)/dble(learnratewarmsteps)
              if ( (iepoch-learnratecoolminstep) >= learnratewarmsteps ) then
                 iflearnratewarm = .false.; learnratecoolminstep = iepoch; learnratecoolminloss = huge(1.0)
                 learnratewarmpeakepoch = 0
              end if
           else
              if ( totloss > pretotloss .and. learnrate > minlearnrate ) then
                 if ( learnratewarmpeakepoch == 0 ) learnratewarmpeakepoch = iepoch
                 if ( learnratedecay > 0.0d0 ) then
                    learnrate = learnrate*learnratedecay
                 else
                    ! Sigmoid Decay with Warmup (sig+) (Eq.3)
                    ! https://doi.org/10.3390/electronics10162029
                    learnrate = minlearnrate + (maxlearnrate-minlearnrate)/(1d0+exp(abs(learnratedecay)*(2d0*dble(iepoch-learnratewarmpeakepoch)-1d0)))
                 end if
              end if
              if ( totloss < learnratecoolminloss ) then
                 learnratecoolminloss = totloss; learnratecoolminstep = iepoch
              else if ( (iepoch - learnratecoolminstep) > learnratepatientsteps ) then
                 iflearnratewarm = .true.; learnrate = minlearnrate
                 learnratecoolminstep = iepoch
              end if
           end if
        end if

        if ( totloss < mintotloss ) then
           if ( (ifsaveminlossnetwork .eqv. .true.) .and. (mod(iepoch,10)==0) ) then
              if ( lastnetworkfilename /= "" ) ierr = system("rm -f "//lastnetworkfilename)
              write(tpstring,*) iepoch; write(tpfilename,"(f10.5)") totloss
              write(tpfilename,"(a)") "network_epoch"//trim(adjustl(tpstring))//"_loss"//trim(adjustl(tpfilename))//".txt"
              call gnnpub_network_saveparm(tpfilename)
              call mlp0_network_saveall(networklist,tpfilename)
              lastnetworkfilename = tpfilename
              mintotloss = totloss; minlossepoch = iepoch
           end if
        end if
        pretotloss = totloss

     end if

     call mpi_bcast(learnrate,1,mpi_double_precision,0, mpi_comm_world,ierr)
     if ( icudagroup > 0 ) learnrate_d = learnrate

  end do

  if ( deepprocid == 0 ) then
 
     !call gnn_predict()
     call gnnpub_network_saveparm()
     call mlp0_network_saveall(networklist)
     !call mlp0_network_reloadall(networklist)
     !call gnn_predict()

  end if
 
end subroutine

subroutine gnn_predict()
  integer,dimension(:),pointer :: shuffleidx
  integer :: ierr,idata,igroup,ibatch,index,ipos
  real*8 :: totloss,endtime,initime

  if ( deepprocnum > 1 ) stop "Only one process is allowed in gnn prediction!"

  allocate(shuffleidx(deepntotdata))
  if ( icudagroup > 0 ) allocate(shuffleidx_d(deepntotdata))

  print "(/,a)","GNN prediction"

  allbatchnatom = 0; shuffleidx = [(idata,idata=1,deepntotdata)]
  if ( icudagroup == 0 ) then
     totloss = 0d0; totenergyloss = 0d0; totforceloss = 0d0
  else if ( icudagroup > 0 ) then
     totloss_d = 0.0_SD; shuffleidx_d = shuffleidx
     totenergyloss_d = 0.0_SD; totforceloss_d = 0.0_SD
  end if

  open(unit=100, file="force_prediction_result.txt", status='replace');close(100)
  open(unit=1000, file="energy_prediction_result.txt", status='replace');close(1000)

  call deeppub_time_from_1970(initime)

  do ibatch = 1, batchnum
     if ( deepprocid == 0 ) print "(a,i8)","processing batch ",ibatch
     if ( icudagroup == 0 ) then

        call gnnpub_prepare_batchsize(shuffleidx,ibatch,1)
        call cpugnn_calculate_batch_edge_info(shuffleidx,ibatch)
        call gnnpub_initialize_for_dynamic_batchsize()
        call cpugnn_prepare_batchdata()
        call cpugnn_network_forward(calloss=.true.,printinfo=.true.)
        call cpugnn_network_backward(calloss=.true.,printinfo=.true.)

     else

        do igroup = 1, (batchsize-1)/(ignncudagroup*deepprocnum)+1
           call gnnpub_prepare_batchsize(shuffleidx,ibatch,igroup)
           ipos = (ibatch-1)*batchsize+(igroup-1)*ignncudagroup*deepprocnum+deepprocid*ignncudagroup
           call cudagnn_calculate_batch_edge_info(ipos)
           if ( batchsnapnmol == 0 ) exit
           call gnnpub_initialize_for_dynamic_batchsize()
           call cudagnn_prepare_batchdata()
           call cudagnn_network_forward(calloss=.true.,printinfo=.true.)
           call cudagnn_network_backward(calloss=.true.,printinfo=.true.)
        end do

     end if

  end do

  if ( icudagroup > 0 ) then
     call deeppub_ncclAllReduce_scalar(totenergyloss_d); totenergyloss = totenergyloss_d
     if ( iftrainforce ) then
        call mpi_reduce(allbatchnatom, index, 1, mpi_integer, mpi_sum, 0, mpi_comm_world, ierr)
        allbatchnatom = index
        call deeppub_ncclAllReduce_scalar(totforceloss_d); totforceloss = totforceloss_d
     end if
  end if

  index = min(batchsize*batchnum, deepntotdata)
  call deeppub_loss_function_end(index, totenergyloss)
  if ( iftrainforce ) then
     call deeppub_loss_function_end(allbatchnatom, totforceloss)
  end if

  call deeppub_time_from_1970(endtime)
  print *
  print "(a,f18.6)","Energy Prediction Loss ",totenergyloss
  print "(a,f18.6)","Force Prediction Loss  ",totforceloss
  print "(a,f18.3)","Cost Time              ",(endtime-initime)/1000d0
end subroutine

subroutine gnn_md_initialize(parmfile,tpicuda)
  character(len=*),intent(in) :: parmfile
  integer,intent(in) :: tpicuda
  logical :: ifok
  jobtype = MD; icudagroup = tpicuda; ignncudagroup = icudagroup; deepprocid = 0; deepprocnum = 1
  batchsize = 1
  call gnnpub_initialize(parmfile, ifok)
  if ( ifok ) then
     if ( icudagroup > 0 ) call cudagnn_initialize()
  end if
end subroutine

subroutine gnn_md()
  integer :: ierr,i,tpnsnap,tpnatom,isnap,iatom,iofile
  real*8,allocatable :: cachedcoors(:,:,:),tpcoor(:,:),tpforce(:,:)
  real(kind=SD),device,allocatable :: tpcoor_d(:,:),tpforce_d(:,:)
  real(kind=SD),device :: tppot_d
  real*8 :: time1,time2,caltime,tppot
  integer :: shuffleidx(1)=1
  logical :: use_deepgnn = .true.

  open(unit=100, file="force_prediction_result.txt", status='replace');close(100)
  open(unit=1000, file="energy_prediction_result.txt", status='replace');close(1000)

  tpnatom = molatomnums(1); tpnsnap = 0
  open(newunit=iofile,file="testdata4mol.deeptraj",action="read")
  do 
     read(iofile,*,iostat=ierr)
     if ( ierr /= 0 ) exit
     tpnsnap = tpnsnap + 1
  end do
  allocate(cachedcoors(3,tpnatom,tpnsnap))
  rewind(iofile)
  do isnap = 1, tpnsnap
     read(iofile,*) i,i,i,i,cachedcoors(:,:,isnap)
  end do
  close(iofile)
  if ( icudagroup == 0 ) then
     allocate(tpcoor(3,tpnatom),tpforce(3,tpnatom))
  else
     allocate(tpcoor_d(3,tpnatom),tpforce_d(3,tpnatom))
  end if
  caltime = 0
  do isnap = 1, tpnsnap
     call deeppub_time_from_1970(time1)
     if ( icudagroup == 0 ) then
        tpcoor(1:3,1:tpnatom) = cachedcoors(1:3,1:tpnatom,isnap)
        if ( use_deepgnn ) then
           call gnn_potforce(tpcoor=tpcoor,tppot=tppot,tpforce=tpforce,printinfo=.true.)
        else
           !call gnnpub_prepare_batchsize(shuffleidx,1,1)
           !call torch_potforce(z=batchatomtype,pos=tpcoor,energy=tppot,force=tpforce)
        end if
     else
        tpcoor_d(1:3,1:tpnatom) = cachedcoors(1:3,1:tpnatom,isnap)
        call gnn_potforce(tpcoor_d=tpcoor_d,tppot_d=tppot_d,tpforce_d=tpforce_d,printinfo=.true.)
     end if

     call deeppub_time_from_1970(time2)
     caltime = caltime + time2 - time1

  end do

  print *
  print "(a,i6)",   "Total Snapshots   ",tpnsnap
  print "(a,f10.3)","Calculation time  ",caltime/tpnsnap
end subroutine

subroutine gnn_potforce(tpcoor,tpcoor_d,tppot,tppot_d,tpforce,tpforce_d,printinfo)
  real*8,optional :: tpcoor(:,:),tpforce(:,:),tppot
  real(kind=SD),device,optional,target :: tpcoor_d(:,:),tpforce_d(:,:)
  real(kind=SD),device,optional :: tppot_d
  logical,optional :: printinfo
  integer :: shuffleidx(1)=1,i
  real(kind=SD) :: tpvalue
! ============================ change 20260403 =============================
  real(kind=SD), allocatable,save :: tpforcevalue(:,:)
  real(kind=SD), allocatable, save :: tptpcoor(:,:)
! ============================ change 20260403 =============================
  if ( icudagroup == 0 ) then
     if ( .not. present(tpcoor) ) stop "atom coor data on CPU is missing!"
     if ( allocated(batchrefsnapatomforces) ) deallocate(batchrefsnapatomforces)
     if ( allocated(batchrefsnapenergies) ) deallocate(batchrefsnapenergies)
     snapatomcoors(1:3,1:molatomnums(1)) = tpcoor
  else
     if ( .not. present(tpcoor_d) ) stop "atom coor data on GPU is missing!"
     if (.not. allocated(shuffleidx_d)) then
        allocate(shuffleidx_d(1)); shuffleidx_d = 1
     end if
     if ( allocated(batchrefsnapatomforces_d) ) then
        deallocate(batchrefsnapatomforces,batchrefsnapenergies)
        deallocate(batchrefsnapatomforces_d,batchrefsnapenergies_d)
     end if
     snapatomcoors_d => tpcoor_d
     batchsnapatomforces_d => tpforce_d
     !call gnn_copy_device_coor<<<1,32>>>(tpcoor_d)

  end if

  if ( icudagroup == 0 ) then

     if ( maxbatchsnapnedge == 0 ) then
        call gnnpub_prepare_batchsize(shuffleidx,1,1)
     end if
     call cpugnn_calculate_batch_edge_info(shuffleidx,1)
     call gnnpub_initialize_for_dynamic_batchsize()
     call cpugnn_prepare_batchdata()
     call cpugnn_network_forward(printinfo=printinfo)
     call cpugnn_network_backward(printinfo=printinfo)
     tppot = batchsnapenergies(1)
     tpforce = batchsnapatomforces

  else
! ============================ change 20260403 =============================
     if ( use_torch ) then
        call gnnpub_prepare_batchsize(shuffleidx,1,1)
        if ( .not. allocated(tptpcoor) ) then
           allocate(tptpcoor(size(tpcoor_d,1),size(tpcoor_d,2)))
           allocate(tpforcevalue(size(tpcoor_d,1),size(tpcoor_d,2)))
        end if
        tptpcoor = tpcoor_d
        call torch_potforce(z=batchatomtype,pos=tptpcoor,energy=tpvalue,force=tpforcevalue)
        tppot_d = tpvalue
        tpforce_d = tpforcevalue
     else
        if ( maxbatchsnapnedge == 0 ) then
           call gnnpub_prepare_batchsize(shuffleidx,1,1)
        end if
        call cudagnn_calculate_batch_edge_info(0)
        call gnnpub_initialize_for_dynamic_batchsize()
        call cudagnn_prepare_batchdata()
        call cudagnn_network_forward(printinfo=printinfo)
        call cudagnn_network_backward(printinfo=printinfo)
        tpvalue = batchsnapenergies_d(1)
        tppot_d = tpvalue
     end if
! ============================ change 20260403 =============================

     !call gnn_copy_device_force<<<1,32>>>(tpforce_d)
  end if
end subroutine

attributes(global) subroutine gnn_copy_device_coor(tpcoor_d)
  real*8 :: tpcoor_d(:,:)
  integer :: iatom
  do iatom = threadidx%x, batchsnapnatom_d, 32
     snapatomcoors_d(:,iatom) = tpcoor_d(:,iatom)
  end do
end subroutine

attributes(global) subroutine gnn_copy_device_force(tpforce_d)
  real*8 :: tpforce_d(:,:)
  integer :: iatom
  do iatom = threadidx%x, batchsnapnatom_d, 32
     tpforce_d(:,iatom) = batchsnapatomforces_d(:,iatom)
  end do
end subroutine

!===================================================================

subroutine gnn_train2()
  integer,dimension(:),pointer :: shuffleidx
  integer :: i,j,k,ibatch,index,iepoch,idata,realidata,istart,ipos,ilayer,igroup
  integer :: system,ierr,istream,errormark(batchsize)
  real*8 :: loss,totloss,checktotloss,gradtotloss,checkgradtotloss
  real*8,dimension(:,:,:),allocatable :: tpinputs,tpoutputs,tptrueoutputs,tptruegrads
  real*8 :: initime,endtime,time1,time2
  real :: rand
  real*8 :: mintotloss,pretotloss,totlossflood,batchloss,learnratecoolminloss
  integer :: learnratecoolminstep,minlossepoch,learnratewarmpeakepoch
  logical :: iflearnratewarm
  character*150 :: tpstring,tpfilename,lastnetworkfilename

  if ( deepprocnum > 0 ) then
     call deeppub_MPISharedMemoryAllocate(i, dimint1d=(/deepntotdata/), shareint1d=shuffleidx)
  else
     allocate(shuffleidx(deepntotdata))
  end if

  if ( deepprocid == 0 ) then
      call deeppub_time_from_1970(initime)
      print "(/,a)","DNN Training Data"
      shuffleidx = [(idata,idata=1,deepntotdata)]
  end if

  if ( icudagroup == 0 ) then
     allocate(tpinputs(ninput,batchsize,1),tpoutputs(noutput,batchsize,1),tptrueoutputs(noutput,batchsize,1))
     allocate(tptruegrads(ngradcv,batchsize,1))
  end if

  lastnetworkfilename=""; mintotloss = huge(1.0); pretotloss = huge(1.0); minlossepoch = 0
  if ( learnratewarmsteps > 0 ) then
     iflearnratewarm = .true.; learnrate = minlearnrate; learnratecoolminstep = 0
     if ( icudagroup > 0 ) learnrate_d = learnrate
  end if

  do iepoch = 1,nepoch

     if ( deepprocid == 0 ) then
        do idata = deepntotdata, 2, -1
           call random_number(rand); index = int(rand * idata) + 1
           realidata = shuffleidx(index); shuffleidx(index) = shuffleidx(idata); shuffleidx(idata) = realidata
        end do
     end if
     call mpi_barrier(mpi_comm_world,ierr)
   
     if ( icudagroup == 0 ) then
        totloss = 0d0; gradtotloss = 0d0
     else
        totloss_d = 0.0_SD; shuffleidx_d = shuffleidx
        if ( ngradcv > 0 ) gradtotloss_d = 0.0_SD
     end if

     do ibatch = 1, batchnum

        if ( icudagroup == 0 ) then

           call deep_get_batchdata(shuffleidx,ibatch,tpinputs(:,:,1),tptrueoutputs(:,:,1),tptruegrads=tptruegrads(:,:,1),tperrormark=errormark)

           call mlp0_network_forward(net0,1,tpinputs,tpoutputs,errormark=errormark)

           call deeppub_loss_function(tptrueoutputs(1:noutput,:,1),tpoutputs(1:noutput,:,1),totloss,tperrormark=errormark)

           call mlp0_network_backward_bptt(net0,1,tptrueoutputs,.true.,errormark=errormark)

           if ( ngradcv > 0 ) then
               tpoutputs(:,:,1)=1d0
               !call mlp0_flooding_backward(net0, tpoutputs, tpinputs(:,:,1), errormark=errormark)
               call mlp0_network_backward_bptt(net0,1,tpoutputs,.false.,tpfirstdeltalayer=tpinputs(:,:,1),ifdoflood=.true.)

               call deeppub_loss_function_grad(tptruegrads(:,:,1), tpinputs(:,:,1), gradtotloss, tperrormark=errormark)

               call mlp0_flooding_forward(net0, tptruegrads, errormark=errormark)
           end if

        else

           do igroup = 1, (batchsize-1)/(icudagroup*deepprocnum)+1

              call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,ibatch,igroup,ninput)
              call mlp0_network_forward_cuda(net0)
              call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,ibatch,igroup,noutput)
              call mlp0_network_backward_cuda(net0,.true.)

              if ( ngradcv > 0 ) then
                 call mlp0_flooding_backward_cuda(net0)
                 call mlp0_flooding_forward_cuda(net0)
              end if

           end do

        end if

        call mlp0_network_update([net0])

     end do

     if ( icudagroup > 0 ) then
        call deeppub_ncclAllReduce_scalar(totloss_d); totloss = totloss_d
        if ( ngradcv > 0 ) then
           call deeppub_ncclAllReduce_scalar(gradtotloss_d); gradtotloss = gradtotloss_d
        end if
     end if

     index = min(batchsize*batchnum, deepntotdata)
     call deeppub_loss_function_end(index*nlabelcv, totloss)
     if ( ngradcv > 0 ) call deeppub_loss_function_end(index*ngradcv, gradtotloss)

     if ( checkdeepntotdata > 0 ) then

        if ( icudagroup == 0 ) then
           checktotloss = 0.0d0; checkgradtotloss = 0.0d0
        else 
           deepntotdata_d = 0; totloss_d = 0.0_SD
           if ( ngradcv > 0 ) gradtotloss_d = 0.0_SD
        end if

        do ibatch = 1, (checkdeepntotdata-1)/batchsize+1
   
           if ( icudagroup == 0 ) then

              call deep_get_batchdata_check(ibatch,tpinputs(:,:,1),tptrueoutputs(:,:,1),tptruegrads=tptruegrads(:,:,1),tperrormark=errormark)
              call mlp0_network_forward(net0,1,tpinputs,tpoutputs,errormark=errormark)
              call deeppub_loss_function(tptrueoutputs(:,:,1),tpoutputs(:,:,1),checktotloss,tperrormark=errormark)

              if ( ngradcv > 0 ) then
                  tpoutputs(:,:,1)=1d0
                  call mlp0_flooding_backward(net0, tpoutputs, tpinputs(:,:,1), errormark=errormark)
                  call deeppub_loss_function_grad(tptruegrads(:,:,1),tpinputs(:,:,1),checkgradtotloss,tperrormark=errormark)
              end if

           else

              do igroup = 1, (batchsize-1)/(icudagroup*deepprocnum)+1

                 call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,ibatch,igroup,ninput)
                 call mlp0_network_forward_cuda(net0)
                 call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,ibatch,igroup,noutput)
                 call mlp0_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(net0%id,.true.)

                 if ( ngradcv > 0 ) then
                    call mlp0_flooding_backward_cuda(net0)
                    call mlp0_flooding_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(net0%id)
                 end if

              end do

           end if
   
        end do

        if ( icudagroup > 0 ) then
           call deeppub_ncclAllReduce_scalar(totloss_d); checktotloss = totloss_d
           if ( ngradcv > 0 ) then
              call deeppub_ncclAllReduce_scalar(gradtotloss_d); checkgradtotloss = gradtotloss_d
           end if
           deepntotdata_d = deepntotdata
        end if

        call deeppub_loss_function_end(checkdeepntotdata*nlabelcv, checktotloss)
        if ( ngradcv > 0 ) call deeppub_loss_function_end(checkdeepntotdata*ngradcv, checkgradtotloss)

     end if


     if ( deepprocid == 0 ) then
 
        if ( checkdeepntotdata == 0 ) then
           if ( ngradcv == 0 ) then
              print "(a,i6,5x,a,f12.6,5x,a,f12.8)","Epoch ",iepoch,"Loss ",totloss,"Learnrate ",learnrate
           else
              print "(a,i6,5(5x,a,f12.6))","Epoch ",iepoch,"Loss ",totloss,"GradLoss ",gradtotloss
           end if
        else
           if ( ngradcv == 0 ) then
              print "(a,i6,5(5x,a,f12.6,5x,a,f12.8))","Epoch ",iepoch,"Loss ",totloss,"ValidLoss ",checktotloss,"Learnrate ",learnrate
           else
              print "(a,i6,5(5x,a,f12.6))","Epoch ",iepoch,"Loss ",totloss,"GradLoss ",gradtotloss,"ValidLoss ",checktotloss, "ValidGradLoss ",checkgradtotloss
           end if
        end if

        call deeppub_time_from_1970(endtime)
        if (mod(iepoch,20)==0 .and. deepprocid==0) call deeppub_print_time(6,(endtime-initime),iepoch,dble(iepoch)/dble(nepoch))

        if ( learnratewarmsteps > 0 ) then
           if ( iflearnratewarm .eqv. .true. ) then
              learnrate = learnrate + (maxlearnrate-minlearnrate)/dble(learnratewarmsteps)
              if ( (iepoch-learnratecoolminstep) >= learnratewarmsteps ) then
                 iflearnratewarm = .false.; learnratecoolminstep = iepoch; learnratecoolminloss = huge(1.0)
                 learnratewarmpeakepoch = 0
              end if
           else
              if ( totloss > pretotloss .and. learnrate > minlearnrate ) then
                 if ( learnratewarmpeakepoch == 0 ) learnratewarmpeakepoch = iepoch
                 if ( learnratedecay > 0.0d0 ) then
                    learnrate = learnrate*learnratedecay
                 else
                    ! Sigmoid Decay with Warmup (sig+) (Eq.3)
                    ! https://doi.org/10.3390/electronics10162029
                    learnrate = minlearnrate + (maxlearnrate-minlearnrate)/(1d0+exp(abs(learnratedecay)*(2d0*dble(iepoch-learnratewarmpeakepoch)-1d0))) 
                 end if
              end if
              if ( totloss < learnratecoolminloss ) then
                 learnratecoolminloss = totloss; learnratecoolminstep = iepoch
              else if ( (iepoch - learnratecoolminstep) > learnratepatientsteps ) then
                 iflearnratewarm = .true.; learnrate = minlearnrate
                 learnratecoolminstep = iepoch
              end if
           end if
        end if

        if ( totloss < mintotloss ) then
           if ( (ifsaveminlossnetwork .eqv. .true.) .and. (mod(iepoch,10) == 0) ) then
              if ( lastnetworkfilename /= "" ) ierr = system("rm -f "//lastnetworkfilename)
              write(tpstring,*) iepoch; write(tpfilename,"(f10.5)") totloss
              write(tpfilename,"(a)") "network_epoch"//trim(adjustl(tpstring))//"_loss"//trim(adjustl(tpfilename))//".txt"
              call deep_network_save(tpfilename)
              call mlp0_network_save(net0,tpfilename)
              lastnetworkfilename = tpfilename
              mintotloss = totloss; minlossepoch = iepoch
           end if
        end if
        pretotloss = totloss

     end if

     call mpi_bcast(learnrate,1,mpi_double_precision,0, mpi_comm_world,ierr)
     if ( icudagroup > 0 ) learnrate_d = learnrate

  end do

  call mpi_barrier(mpi_comm_world, ierr)

  if ( icudagroup == 0 ) then

     totloss = 0.0d0; shuffleidx = [(i,i=1,deepntotdata)]
     do ibatch = 1, batchnum

        call deep_get_batchdata(shuffleidx,ibatch,tpinputs(:,:,1),tptrueoutputs(:,:,1),tptruegrads=tptruegrads(:,:,1),tperrormark=errormark)
        call mlp0_network_forward(net0,1,tpinputs,tpoutputs,errormark=errormark)
        call deeppub_loss_function(tptrueoutputs(1:noutput,:,1),tpoutputs(1:noutput,:,1),totloss,tperrormark=errormark)

    end do

  else

     totloss_d = 0.0_SD; shuffleidx_d = [(idata,idata=1,deepntotdata)]
     do ibatch = 1, batchnum
        do igroup = 1, (batchsize-1)/(icudagroup*deepprocnum)+1
           call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,ibatch,igroup,ninput)
           call mlp0_network_forward_cuda(net0)
           call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,ibatch,igroup,noutput)
           call mlp0_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(net0%id,.true.)
        end do
     end do
     call deeppub_ncclAllReduce_scalar(totloss_d); totloss = totloss_d

  end if

  call mpi_barrier(mpi_comm_world, ierr)

  if ( deepprocid == 0 ) then
     index = min(batchsize*batchnum, deepntotdata)
     call deeppub_loss_function_end(index*nlabelcv, totloss)
     print "(/,a,f15.8)",   " Final Loss Function ",totloss
     print "(a,f15.8,a,i8)","Minmum Loss Function ",mintotloss," at epoch ",minlossepoch
     call deeppub_time_from_1970(endtime)
     print "(a,f15.1)",     " Cost time (seconds) ",(endtime - initime)/1000d0
   
     call deep_network_save()
     call mlp0_network_save(net0)
  end if
end subroutine

subroutine gnn_predict2()
  integer :: iofile,istart,iend,idata,istep,index,i,j,k,ilayer
  real*8 :: tptruegrads(ninput,1,1),tppredictgrads(ninput,1,1),tpinputs(ninput,1,1),tpoutputs(noutput,1,1),tpgrouploss(size(labelcvgroupweight)/3)
  real*8,dimension(nlabelcv) :: tppredict,tplabelvec
  real*8 :: initime, endtime, tpgradtotloss

  print "(/,a)","DNN Testing Data"

  call deeppub_time_from_1970(initime)
  
  tpgrouploss = 0d0; if ( ngradcv > 0 .and. icudagroup > 0 ) gradtotloss_d = 0.0_SD
  open(newunit=iofile,file="predict.txt",action="write")
  do idata = 1, deepntotdata
     tpinputs(1:ninput,1,1) = deeptrajcoor(1:ninput,idata)
     tplabelvec(:) = labelcvtraj(:,idata); tppredict = 0d0

     if ( ngradcv > 0 ) then
        tppredictgrads = 0d0
        tptruegrads(:,1,1) = graddeeptrajcoor(1:ninput,idata)
     end if

     if ( icudagroup == 0 ) then

        call mlp0_network_forward(net0,1,tpinputs,tpoutputs); tppredict = tpoutputs(:,1,1)

        if ( ngradcv > 0 ) then
            tpoutputs(:,:,1)=1d0
            call mlp0_flooding_backward(net0, tpoutputs, tppredictgrads(:,:,1))
            call deeppub_loss_function_grad(tptruegrads(:,:,1),tppredictgrads(:,:,1),tpgradtotloss)
        end if

     else

        if ( icudagroup > 1 ) stop "icudagroup must be 1 for prediction job!"
        deeptrajcoor_d(1:ninput,1) = tpinputs(1:ninput,1,1); shuffleidx_d = 1
        !if ( normalmode /= 0 ) call gnn_input_normalize_cuda<<<(ninput-1)/32+1,32>>>()
        call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,1,1,ninput)
        call mlp0_network_forward_cuda(net0,tpoutputs=tpoutputs); tppredict = tpoutputs(:,1,1)

        call deep_get_batchlabel_cuda<<<(icudagroup*noutput-1)/32+1,32>>>(1,1,1,noutput)
        call mlp0_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(net0%id,.true.)

        if ( ngradcv > 0 ) then
           call mlp0_flooding_backward_cuda(net0,tpgrads=tppredictgrads)
           call mlp0_flooding_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(net0%id)
           tpgradtotloss = gradtotloss_d
        end if

     end if

     if ( ngradcv == 0 ) then
        if ( ifavglabel .eqv. .true. ) then
           write(iofile,'(i10,*(f20.8))') idata,tplabelvec(:)+labelcvtrajavg(:),tppredict(:)+labelcvtrajavg(:)
        else
           write(iofile,'(i10,*(f15.8))') idata,tplabelvec(:),tppredict(:)
        end if
     else
        if ( ifavglabel .eqv. .true. ) then
           write(iofile,'(i10,*(f20.8))') idata,tplabelvec(:)+labelcvtrajavg(:),tppredict(:)+labelcvtrajavg(:),tptruegrads(:,1,1),tppredictgrads(:,1,1)
        else
           write(iofile,'(i10,*(f15.8))') idata,tplabelvec(:),tppredict(:),tptruegrads(:,1,1),tppredictgrads(:,1,1)
        end if
     end if

     do i = 1, size(labelcvgroupweight)/3
        j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1))
        select case (lossfunctype)
          case (RMSE); tpgrouploss(i) = tpgrouploss(i) + sum(((tppredict(j:k)-tplabelvec(j:k)))**2)
          case (MAE);  tpgrouploss(i) = tpgrouploss(i) + sum((abs(tppredict(j:k)-tplabelvec(j:k)))) 
        end select
     end do

  end do
  close(iofile)

  do i = 1, size(labelcvgroupweight)/3
     j = nint(labelcvgroupweight(3*i-2)); k = nint(labelcvgroupweight(3*i-1))
     call deeppub_loss_function_end(deepntotdata*(k-j+1), tpgrouploss(i))
  end do
  print "(a,*(i10,f20.8))","Network Output Group Error  ",(i,tpgrouploss(i),i=1,size(labelcvgroupweight)/3)
  if ( ngradcv > 0 ) then
     print "(a,10x,f20.8)","Network Gradient Error      ",tpgradtotloss
  end if
  call deeppub_time_from_1970(endtime)
  print *,"Cost time ",endtime-initime
end subroutine
!===================================================

subroutine gnn_check_grads()
  integer :: ilayer,i,j,ipos,nlayer,ninput,noutput
  integer,allocatable :: layers(:)
  real*8 :: upv,downv,h,originv,refgrad,maxerr,rand,tpvalue,calgrad
  real*8,allocatable :: tpinputs(:,:,:), tpoutputs(:,:,:), tplabels(:,:,:), tptruegrads(:,:,:), tpgrads(:,:,:)

  call mlp0_getlayerinfo(net0, nlayer, layers)
  ninput = layers(1); noutput = layers(nlayer)
  allocate(tpinputs(ninput,1,1),tpoutputs(noutput,1,1),tplabels(noutput,1,1),tptruegrads(ninput,1,1),tpgrads(ninput,1,1))

  ! set the inputs and calculate the output values of neurons in all the layers
  call random_seed(); call random_number(tpinputs(:,1,1))
  call random_number(tplabels(:,1,1))
  tplabels = -406747.38329599d0

  if ( nsnap == 0 .and. normalmode /= 0 ) call gnn_input_normalize(tpinputs(:,1,1))

  call mlp0_network_forward(net0, 1, tpinputs, tpoutputs)

  ! calculate the gradients in all the layers, gradients, grad_weights_l2l, grad_weights_t2t, grad_bias
  call mlp0_network_backward_bptt(net0, 1, tplabels, .true.)

!  if ( ngradcv > 0 ) then
!     tpoutputs(:,1,1)=1d0; call gnn_flooding_backward(tpoutputs, tpgrads)
!     call random_number(tptruegrads(:,1,1)); call gnn_flooding_forward(tptruegrads)
!  end if
  print *
  h = 0.001d0; maxerr = 0d0
  do ilayer = nlayer, 2, -1
     do i = 1, layers(ilayer)
        do j = 1, layers(ilayer-1)
           call mlp0_getweight(net0,ilayer,i,j,originv,gradw=calgrad)
           call mlp0_setweight(net0,ilayer,i,j,originv+h); call get_loss(upv)
           call mlp0_setweight(net0,ilayer,i,j,originv-h); call get_loss(downv)
           refgrad = (upv-downv)/(2d0*h)
           maxerr = max(maxerr,abs(calgrad-refgrad))
           call mlp0_setweight(net0,ilayer,i,j,originv)
        end do
     end do
  end do
  print *,"max weight error ",maxerr

  maxerr = 0d0
  do ilayer = nlayer, 2, -1
     do i = 1, layers(ilayer)
        call mlp0_getbias(net0,ilayer,i,originv,gradbias=calgrad)
        call mlp0_setbias(net0,ilayer,i,originv+h); call get_loss(upv)
        call mlp0_setbias(net0,ilayer,i,originv-h); call get_loss(downv)
        refgrad = (upv-downv)/(2d0*h)
        maxerr = max(maxerr,abs(calgrad-refgrad))
        call mlp0_setbias(net0,ilayer,i,originv)
     end do
  end do
  print *,"max bias error ",maxerr

!  if ( ifuselayernorm .eqv. .true. ) then
!     maxerr = 0d0
!     do ilayer = 1, nlayer-1
!        call mlp0_get_layernorm_weightbias(net0,ilayer,originv,tpvalue,gradlayerweight=calgrad)
!        call mlp0_set_layernorm_weightbias(net0,ilayer,originv+h,tpvalue); call get_loss(upv)
!        call mlp0_set_layernorm_weightbias(net0,ilayer,originv-h,tpvalue); call get_loss(downv)
!        refgrad = (upv-downv)/(2d0*h)
!        maxerr = max(maxerr,abs(calgrad-refgrad))
!        call mlp0_set_layernorm_weightbias(net0,ilayer,originv,tpvalue)
!     end do
!     print *,"max layernorm weight error ",maxerr
!     maxerr = 0d0
!     do ilayer = 1, nlayer-1
!        call mlp0_get_layernorm_weightbias(net0,ilayer,tpvalue,originv,gradlayerbias=calgrad)
!        call mlp0_set_layernorm_weightbias(net0,ilayer,tpvalue,originv+h); call get_loss(upv)
!        call mlp0_set_layernorm_weightbias(net0,ilayer,tpvalue,originv-h); call get_loss(downv)
!        refgrad = (upv-downv)/(2d0*h)
!        maxerr = max(maxerr,abs(calgrad-refgrad))
!        call mlp0_set_layernorm_weightbias(net0,ilayer,tpvalue,originv)
!     end do
!     print *,"max layernorm bias error ",maxerr
!  end if

contains
subroutine get_loss(tploss)
  real*8,intent(out) :: tploss

  call mlp0_network_forward(net0, 1, tpinputs, tpoutputs)
  tploss = sum(labelcvweight(:)*(tplabels(1:nlabelcv,1,1) - tpoutputs(1:noutput,1,1))**2)

!  if ( ngradcv > 0 ) then
!     tpoutputs(:,:,1)=1d0; call dnn_flooding_backward(tpoutputs, tpgrads)
!     tploss = tploss + sum((tptruegrads(1:ngradcv,1,1) - tpgrads(1:ngradcv,1,1))**2)
!  end if
end subroutine
end subroutine

subroutine gnn_input_normalize(tpvec)
  real*8,intent(inout) :: tpvec(:)
  integer :: i
  real*8 :: tpmin,tpmax

  if ( normalmode == 0 ) return
  do i = 1, ninput
     tpmin = trajmin(i); tpmax = trajmax(i); if ( tpmin == tpmax ) cycle
     if ( normalmode == 1 ) then
        tpvec(i) = normalfactor*( tpvec(i) - trajmin(i) )/( trajmax(i) - trajmin(i) )
     else if ( normalmode == 2 ) then
        tpvec(i) = normalfactor*( 2d0*tpvec(i) - (trajmin(i)+trajmax(i)) )/( trajmax(i) - trajmin(i) )
     end if
  end do
end subroutine

attributes(global) subroutine gnn_input_normalize_cuda()
  integer :: istate
  real(kind=SD) :: tpvalue

  istate = (blockidx%x-1)*32+threadidx%x; if ( istate > size(trajmin_d,1) ) return
  if ( normalmode_d == 1 ) then
     if ( trajmax_d(istate) == trajmin_d(istate) ) return
     deeptrajcoor_d(istate,1) = normalfactor_d*( deeptrajcoor_d(istate,1) - trajmin_d(istate) )/( trajmax_d(istate) - trajmin_d(istate) )
  else if ( normalmode_d == 2 ) then
     if ( trajmax_d(istate) == trajmin_d(istate) ) return
     deeptrajcoor_d(istate,1) = normalfactor_d*( 2.0_SD*deeptrajcoor_d(istate,1) - (trajmin_d(istate) + trajmax_d(istate)) )/( trajmax_d(istate) - trajmin_d(istate) )
  end if
end subroutine

end module
