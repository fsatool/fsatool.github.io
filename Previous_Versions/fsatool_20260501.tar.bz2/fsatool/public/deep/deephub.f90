subroutine deephub_go(parmfile,procnum,procid)
  use gnn; use dnn; use rnn; use tae; use srv; use cnn
  character*100 :: parmfile
  integer :: procid,procnum
  character*100 :: task
  namelist / deep / task, icudagroup

  deepprocnum = procnum; deepprocid = procid

  call deeppub_InitalizeSharedMemory()

  open(newunit=iofile,file=parmfile,action="read")
  read(iofile, nml=deep, iostat=ierr); if ( ierr < 0 ) stop "Cannot find the deep namelist!"
  close(iofile)

  if ( icudagroup == 0 ) then
     if ( deepprocnum > 1 ) stop "Only one processor is allowed when icudagroup == 0"
  else
     ierr = cudaSetDevice(deepprocid)
     if (deepprocid == 0) deepncclstat = ncclGetUniqueId(deepnccluid)
     call mpi_bcast(deepnccluid, int(sizeof(ncclUniqueId)), MPI_BYTE, 0, MPI_COMM_WORLD, ierr)
     call mpi_barrier(mpi_comm_world, ierr)
     deepncclstat = ncclCommInitRank(deepncclcomm, deepprocnum, deepnccluid, deepprocid)
     ierr = cudaStreamCreate(deepncclstream)
     deepprocid_d = deepprocid; deepprocnum_d = deepprocnum
  end if

  if ( task(1:3) == "dnn" ) then
     call dnn_go(parmfile)
  else if ( task(1:3) == "rnn" ) then
     call rnn_go(parmfile)
  else if ( task(1:3) == "tae" ) then
     call tae_go(parmfile)
  else if ( task(1:3) == "srv" ) then
     call srv_go(parmfile)
  else if ( task(1:3) == "cnn" ) then
     call cnn_go(parmfile)
  else if ( task(1:3) == "gnn" ) then
     call gnn_go(parmfile)
  else
     stop "Invalid task name"
  end if
end subroutine
