! SRV Reference
!
! Wei Chen, Hythem Sidky and Andrew L. Ferguson
! Nonlinear discovery of slow molecular modes using state-free reversible VAMPnets.
! J. Chem. Phys. 2019, 150, 214114.

module srv
  use deep; use deeppub; use cudafor; use cusolverDn; use cudablas
  use mlp
  implicit none

  real*8,dimension(:),allocatable :: lambda,gmean
  real*8,dimension(:,:),allocatable :: gbasis,cmat,lmat,linvmat,smat

  integer :: isrvuncertainty,nhiddenstate
  real*8 :: tmat,tback,tinv

  real(kind=SD),dimension(:),allocatable,device :: batch_hiddenstate_d
  real(kind=SD),dimension(:),allocatable,device :: batch_grad_active_d

  !==================  variables on CPU but used for GPU
  integer,dimension(:),allocatable :: grad_active_index

  !==================  variables on GPU
  integer,device :: nvaliddata_d,srvavgmode_d
  real(kind=SD),dimension(:),allocatable,device :: mean0_d,mean1_d,gmean_d,eigenvalues_d,lambda_d
  real(kind=SD),dimension(:,:),allocatable,device :: smat_d,ctlmat_d,cmat_d,qmat_d,lmat_d,linvmat_d,identity_d
  real(kind=SD),dimension(:,:),allocatable,device :: sinvmat_d,bctlmat_d,bcmat_d,blmat_d,blinvmat_d,bqmat_d,bout0_d,bout1_d
  real(kind=SD),dimension(:,:),allocatable,device :: tpmat_d
  integer,dimension(:),allocatable,device :: batcherrormark_d 

  !=================  variables for cusolver and cublas
  type(cusolverDnHandle) :: cusolverH; type(cusolverDnParams) :: params
  type(cudaDataType) :: dataType
  integer(4), parameter :: trans = CUBLAS_OP_N
  integer(4), parameter :: jobz = CUSOLVER_EIG_MODE_VECTOR, range = CUSOLVER_EIG_RANGE_ALL, uplo = CUBLAS_FILL_MODE_LOWER
  integer(8) :: syevdxworkspaceInBytesOnDevice, syevdxworkspaceInBytesOnHost, potrfworkspaceInBytesOnDevice, potrfworkspaceInBytesOnHost
  integer(8) :: getrfworkspaceInBytesOnDevice, getrfworkspaceInBytesOnHost
  integer(8) :: h_meig
  integer(1), allocatable, dimension(:), device :: syevdxbufferOnDevice,potrfbufferOnDevice,getrfbufferOnDevice
  integer(1), allocatable, dimension(:) :: syevdxbufferOnHost,potrfbufferOnHost,getrfbufferOnHost
  integer(4), device :: devinfo
  integer(8), allocatable, dimension(:), device :: devipiv

  !=================  variables for multi-temperature
  real*8,parameter :: gasconst=8.31441d0/4.184d3
  integer :: nkelvin,srvikelvin0,srvkelvinndata
  real*8,pointer :: srvtrajwgt(:)
  real*8,dimension(:),allocatable :: srvscaledfree,srvkelvins
  real*8,dimension(:),allocatable :: tpkelvinvec,kelvinnvalid,batchtrajwgt

contains

subroutine srv_go(parmfile,ikelvin0,scaledfree,trajwgt,kelvinndata,kelvins) 
  character(len=*),intent(in) :: parmfile
  integer,intent(in),optional :: ikelvin0,kelvinndata
  real*8,intent(in),optional :: scaledfree(:),kelvins(:)
  real*8,intent(in),optional,target :: trajwgt(:)

  integer :: iofile, idata, ierr, ilen, i, istate, iactive
  character*100 :: task
  real*8 :: tpdeeptrajcoor(36,1197*3),rand
  integer :: tpdeeptrajindex(1197*3)

  namelist / deep / task

  open(newunit=iofile,file=parmfile,action="read")
  read(iofile, nml=deep, iostat=ierr); if ( ierr < 0 ) stop "Cannot find the deep namelist!"
  close(iofile)

  nkelvin = 0; isrvuncertainty = 0
  if ( present(scaledfree) ) then
     nkelvin=size(scaledfree)
     srvikelvin0 = ikelvin0; srvkelvinndata = kelvinndata
     allocate(srvscaledfree(nkelvin),srvkelvins(nkelvin));
     srvscaledfree = scaledfree; srvkelvins = kelvins
     srvtrajwgt => trajwgt

     allocate(tpkelvinvec(nkelvin)); tpkelvinvec=0d0
     allocate(kelvinnvalid(nkelvin)); kelvinnvalid = 0d0
  end if

  ilen = len(trim(task))
  if ( task(ilen-4:ilen) == "train" ) then
     jobtype = TRAIN; netnum = 2
  else if ( task(ilen-6:ilen) == "predict" ) then
     jobtype = PREDICT; netnum = 1
  else if ( task(ilen-4:ilen) == "check" ) then
     jobtype = CHECK; netnum = 2
  else if ( task(ilen-4:ilen) == "eigen" ) then
     jobtype = EIGEN; netnum = 2
  else if ( task(ilen-5:ilen) == "stream" ) then
     jobtype = STREAM; netnum = 2
  end if

  call deep_initialize(parmfile)
  call mlp_initialize(ninput,noutput,nlayer,layers,totparms)
  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms

  if ( icudagroup > 0 ) then
     istate = size(hiddenstate_d,1)
     iactive = size(grad_active_d,1)
     nhiddenstate = istate
     allocate(batch_grad_active_d(iactive*((batchsize-1)/icudagroup+1))); batch_grad_active_d = 0.0_SD
     allocate(batch_hiddenstate_d(istate*((batchsize-1)/icudagroup+1))); batch_hiddenstate_d = 0.0_SD
  end if

  print "(a,i10)",      "    SRV Average Mode : ",srvavgmode

  call srv_allocate_arrays()

  select case(jobtype)
  case (TRAIN)
     call srv_train()
  case (PREDICT)
     call srv_network_reload_parmint("srv average mode:",srvavgmode)
     call srv_network_reload_parm1d("gmean:",gmean)
     call srv_network_reload_parm2d("gbasis:",gbasis)
     call srv_predict()
  case (CHECK)
     call srv_network_reload_parmint("srv average mode:",srvavgmode)
     call srv_network_reload_parm1d("gmean:",gmean)
     call srv_network_reload_parm2d("gbasis:",gbasis)
     call mlp_layer_normalization_check()
!     call srv_check_grad()
     call srv_check_flood()
  case (EIGEN)
     call srv_eigen_basis()
     call deep_network_save()
     call mlp_network_save()
     call srv_network_save_append_srvinfo()
     open(newunit=iofile,file="predict.txt",action="write")
     do idata = 1, deepntotdata
        lambda = matmul(deeptrajcoor(:,idata)-gmean,gbasis)
        write(iofile,'(f10.3,3i2,10f10.4)') dble(idata)*timestepsize,0,0,0,lambda(1:min(noutput,3))
     end do
     close(iofile)
  case (STREAM)

     i = 0
     open(newunit=iofile,file="traj/levelinfo_0.txt",action="read")
     do
        i = i + 1
        read(iofile,"(13x,i6,36x,36f8.3)",iostat=ierr) tpdeeptrajindex(i),tpdeeptrajcoor(:,i) 
        if ( ierr < 0 ) then; i = i - 1; exit; end if
     end do
     close(iofile)
     open(newunit=iofile,file="traj/levelinfo_1.txt",action="read")
     do 
        i = i + 1
        read(iofile,"(13x,i6,36x,36f8.3)",iostat=ierr) tpdeeptrajindex(i),tpdeeptrajcoor(:,i)
        if ( ierr < 0 ) then; i = i - 1; exit; end if
     end do
     close(iofile)
     open(newunit=iofile,file="traj/levelinfo_2.txt",action="read")
     do
        i = i + 1
        read(iofile,"(13x,i6,36x,36f8.3)",iostat=ierr) tpdeeptrajindex(i),tpdeeptrajcoor(:,i)
        if ( ierr < 0 ) then; i = i - 1; exit; end if
     end do
     close(iofile)

     call srv_settraj(tpdeeptrajcoor,tpdeeptrajindex,0.01d0)
     call deep_traj_normalization()

     i = (deepntotdata - 1)/batchsize + 1 
     if ( batchnum == 0 ) then
        batchnum = i
     else if ( batchnum > i ) then
        print "(a,2i8)","batchnum exceeds the maximum ", batchnum, i; stop
     end if

     call srv_train()
     deepntotdata = deepntotdata/3
     call srv_predict()
 
  end select

end subroutine

subroutine srv_allocate_arrays()
  integer :: i,tpmat(noutput,noutput)

  allocate(cmat(noutput,noutput),lmat(noutput,noutput),linvmat(noutput,noutput))
  allocate(smat(noutput,noutput),lambda(noutput),gbasis(noutput,noutput),gmean(noutput))

  if (icudagroup /= 0) then
     srvavgmode_d = srvavgmode
     allocate(mean0_d(noutput),mean1_d(noutput),gmean_d(noutput),eigenvalues_d(noutput),lambda_d(noutput))
     allocate(smat_d(noutput,noutput))
     allocate(ctlmat_d(noutput,noutput),cmat_d(noutput,noutput),qmat_d(noutput,noutput),lmat_d(noutput,noutput),linvmat_d(noutput,noutput),identity_d(noutput,noutput))
     allocate(sinvmat_d(noutput,noutput),bctlmat_d(noutput,noutput),bcmat_d(noutput,noutput),blmat_d(noutput,noutput),blinvmat_d(noutput,noutput),bqmat_d(noutput,noutput))
     allocate(tpmat_d(noutput,noutput))
     allocate(bout0_d(noutput,batchsize),bout1_d(noutput,batchsize))
     tpmat = 0d0
     do i = 1,noutput
        tpmat(i,i) = 1d0
     end do
     identity_d = tpmat
  end if
end subroutine

subroutine srv_settraj(tpdeeptrajcoor,tpdeeptrajindex,tptimestep)
  real*8,intent(in) :: tpdeeptrajcoor(:,:),tptimestep
  integer,intent(in) :: tpdeeptrajindex(:)

  if ( size(tpdeeptrajcoor,1) /= ninput ) then
     print *,"ninput is not compatible to deeptrajcoor! ",size(tpdeeptrajcoor,1),ninput; stop
  end if
  if ( deepntotdata /= 0 .and. deepntotdata /= size(tpdeeptrajcoor,2) ) then
     print *,"deepntotdata is not compatible to deeptrajcoor! ",deepntotdata,size(tpdeeptrajcoor,2); stop
  else
     deepntotdata = size(tpdeeptrajcoor,2)
  end if
  if ( .not. allocated(deeptrajcoor) ) then
     allocate(deeptrajcoor(ninput,deepntotdata),deeptrajindex(deepntotdata)); deeptrajcoor = 0d0; deeptrajindex = 0
  end if
  deeptrajcoor = tpdeeptrajcoor; deeptrajindex = tpdeeptrajindex
  timestepsize = tptimestep
end subroutine

! Train the neuron network by the mini-batch gradient descent method
subroutine srv_train(ifsavenetwork) 
  logical,intent(in),optional :: ifsavenetwork

  integer,dimension(:),allocatable :: shuffleidx,checkshuffleidx
  real*8,dimension(:,:,:),allocatable :: tpinputs
  integer :: nerr,iepoch,idata,ibatch,ipos,istart,index,realidata,errormark(batchsize)
  real*8 :: tpoutputs0(noutput,batchsize),tpoutputs1(noutput,batchsize),tpoutputs(noutput,batchsize,maxnsteps)
  real*8 :: totloss,checktotloss,time1,time2
  real*8 :: initime,endtime,loss
  real :: rand
  integer :: ilayer,igroup ! Used for GPU
  integer :: it2
real*8 :: t1,t2,ta,tb,tc,tx,ty,ttot,batchloss,addpotcoef
integer :: iofile

  print "(/,a)","SRV Training Data"
  allocate(tpinputs(ninput,batchsize,maxnsteps))

  if ( icudagroup > 0 ) then
     if ( mod(batchsize,icudagroup) /= 0 ) then
        print *,"In SRV, batchsize must be an integer multiple of icudagroup!"; stop
     else if ( mod(deepntotdata-ntau,batchsize) /= 0 ) then
        print *,"In SRV, deepntotdata-ntau must be an integer multiple of batchsize!"; stop
     end if
     allocate(batcherrormark_d(batchsize)); batcherrormark_d = 0
     call srv_culib_ini()
     allocate(grad_active_index(nlayer+1)); grad_active_index = grad_active_index_d
  end if

  if ( nkelvin > 0 ) then
     if ( size(srvtrajwgt) /= deepntotdata ) then
        print *,"In SRV with multi-temperature, deepntotdata must be equal to the size of srvtrajwgt!"; stop
     end if
     allocate(batchtrajwgt(batchsize))
  end if

  allocate(shuffleidx(deepntotdata-ntau),checkshuffleidx(checkdeepntotdata-ntau))
  do idata = 1,deepntotdata-ntau
     shuffleidx(idata) = idata
  end do
  if ( checkdeepntotdata > 0 ) then
     do idata = 1,checkdeepntotdata-ntau
        checkshuffleidx(idata) = idata
     end do
  end if

  call deeppub_time_from_1970(initime)

ta = 0d0; tb = 0d0; tc = 0d0; tmat = 0d0; tback = 0d0; tinv = 0d0
call cpu_time(tx)
!open(newunit=iofile,file="bias.txt",action="write")
  do iepoch = 1,nepoch

     ! shuffling the data
     do idata = deepntotdata-ntau, 2, -1
        call random_number(rand); istart = int(rand * idata) + 1
        index = shuffleidx(istart); shuffleidx(istart) = shuffleidx(idata); shuffleidx(idata) = index
     end do

     if ( icudagroup == 0 ) then
        totloss = 0d0
     else
        totloss = 0d0; totloss_d = 0.0_SD; shuffleidx_d = shuffleidx
     end if

     do ibatch = 1, batchnum

        istart = (ibatch-1)*batchsize; errormark = 0; nerr = 0; tpinputs = 0d0; tpoutputs = 0d0
        if ( nkelvin > 0 ) then
           kelvinnvalid = 0d0; tpkelvinvec=0d0
        end if
        do idata = 1, batchsize
           ipos = istart + idata
           if ( ipos+ntau > deepntotdata ) then
              errormark(idata) = 1; nerr = nerr + 1; cycle
           end if
           realidata = shuffleidx(ipos)
           if ( deeptrajindex(realidata) /= deeptrajindex(realidata+ntau) ) then
              errormark(idata) = 1; nerr = nerr + 1; cycle
           end if
           tpinputs(:,idata,1) = deeptrajcoor(:,realidata)

           if ( nkelvin > 0 ) then
              batchtrajwgt(idata) = srvtrajwgt(realidata)
              it2 = (realidata-1)/srvkelvinndata + 1
              kelvinnvalid(it2) = kelvinnvalid(it2) + 1d0
           end if
        end do

        if ( batchsize <= nerr + 1 ) cycle

        if ( icudagroup == 0 ) then
call cpu_time(t1)
           call mlp_network_forward(1,tpinputs,tpoutputs,errormark=errormark)
           tpoutputs0(:,1:batchsize) = tpoutputs(:,1:batchsize,1)

           tpinputs = 0d0
           do idata = 1, batchsize
              if ( errormark(idata) == 1 ) cycle
              ipos = istart + idata; realidata = shuffleidx(ipos)
              tpinputs(:,idata,1) = deeptrajcoor(:,realidata+ntau)
           end do
           call mlp_network_forward(2,tpinputs,tpoutputs,errormark=errormark)
           tpoutputs1(:,1:batchsize) = tpoutputs(:,1:batchsize,1)
call cpu_time(t2)
ta = ta + t2 - t1

call cpu_time(t1)
           call srv_eigen_loss(batchsize, tpoutputs0, tpoutputs1, loss, errormark=errormark, tptrajwgt=batchtrajwgt)
           totloss = totloss + loss
call cpu_time(t2)
tc = tc + t2 - t1

call cpu_time(t1)
           call srv_eigen_backward(tpoutputs0,tpoutputs1,errormark=errormark)
call cpu_time(t2)
tb = tb + t2 - t1

        else

noutput = noutput_d; noutput_d = noutput
call cpu_time(t1)
           nvaliddata_d = 0
           do igroup = 1, (batchsize-1)/icudagroup+1
              call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(1,ibatch,igroup,ninput)
              call mlp_network_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(1,igroup)

              do ilayer = 2, nlayer
                 call mlp_network_forward_cuda_layer<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(1,ilayer)
              end do
              call deep_get_batchdata_cuda<<<(icudagroup*ninput-1)/32+1,32>>>(2,ibatch,igroup,ninput)
              call mlp_network_forward_cuda_inputlayer<<<(icudagroup*ninput-1)/32+1,32>>>(2,igroup)

              do ilayer = 2, nlayer
                 call mlp_network_forward_cuda_layer<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(2,ilayer)
              end do
              call srv_batch_upload_hiddenstate<<<(hiddenstate_index(nlayer+1)-1)/32+1,32>>>(igroup)
              call srv_batch_upload_active<<<(grad_active_index(nlayer+1)-1)/32+1,32>>>(igroup)
              call srv_batch_upload_errormark<<<(icudagroup-1)/32+1,32>>>(igroup)
           end do
noutput = noutput_d; noutput_d = noutput
call cpu_time(t2)
ta = ta + t2 - t1

noutput = noutput_d; noutput_d = noutput
call cpu_time(t1)
           call srv_eigen_loss_cudapack()
noutput = noutput_d; noutput_d = noutput
call cpu_time(t2)
tc = tc + t2 - t1
cmat = cmat_d

noutput = noutput_d; noutput_d = noutput
call cpu_time(t1)
           call srv_eigen_backward_cudapack(ibatch=ibatch)
noutput = noutput_d; noutput_d = noutput
call cpu_time(t2)
tb = tb + t2 - t1

        end if

        call mlp_network_update()

     end do

     if (icudagroup/=0) then
        totloss = totloss_d; lambda = lambda_d
     end if
     print "(a,i8,3000f15.8)","Epoch ",iepoch,totloss/dble(batchnum),lambda
     if ( checkdeepntotdata > 0 ) then
        ! shuffling the data
        do idata = checkdeepntotdata-ntau, 2, -1
           call random_number(rand); istart = int(rand * idata) + 1
           index = checkshuffleidx(istart); checkshuffleidx(istart) = checkshuffleidx(idata); checkshuffleidx(idata) = index
        end do
        checktotloss = 0d0; checkbatchnum = (checkdeepntotdata - 1)/batchsize + 1
        do ibatch = 1, checkbatchnum
           istart = (ibatch-1)*batchsize; errormark = 0; nerr = 0
           do idata = 1, batchsize
              ipos = istart + idata
              if ( ipos+ntau > checkdeepntotdata ) then
                 errormark(idata) = 1; nerr = nerr + 1; cycle
              end if
              realidata = checkshuffleidx(ipos)
              if ( checkdeeptrajindex(realidata) /= checkdeeptrajindex(realidata+ntau) ) then
                 errormark(idata) = 1; nerr = nerr + 1; cycle
              end if
              tpinputs(:,idata,1) = checkdeeptrajcoor(:,realidata)
           end do

           if ( batchsize <= nerr + 1 ) cycle

           call mlp_network_forward(1,tpinputs,tpoutputs,errormark=errormark)
           tpoutputs0(:,1:batchsize) = tpoutputs(:,1:batchsize,1)

           do idata = 1, batchsize
              if ( errormark(idata) == 1 ) cycle
              ipos = istart + idata; realidata = checkshuffleidx(ipos)
              tpinputs(:,idata,1) = checkdeeptrajcoor(:,realidata+ntau)
           end do
           call mlp_network_forward(2,tpinputs,tpoutputs,errormark=errormark)
           tpoutputs1(:,1:batchsize) = tpoutputs(:,1:batchsize,1)

           call srv_eigen_loss(batchsize, tpoutputs0, tpoutputs1, loss, errormark=errormark)
           checktotloss = checktotloss + loss
        end do

        print "(a,i8,3000f15.8)","Epoch ",iepoch,checktotloss/dble(checkbatchnum),lambda
     end if

     call deeppub_time_from_1970(endtime)
     if (mod(iepoch,20)==0) call deeppub_print_time(6,(endtime-initime),iepoch,dble(iepoch)/dble(nepoch))

  end do

  print "(/,a,f20.15)","Final Loss Function ",totloss/dble(batchnum)
call cpu_time(ty)
!ttot = ty - tx
!write(6,'(10a15)'),"Forward","MatBack","OutlayerBack","NetBack","MeanLoss","InvLoss","Tot"
!write(6,'(10f15.6)'),ta,tmat,tb-tmat-tback,tback,tc-tinv,tinv,ttot
!write(6,'(10f15.6)'),ta/ttot,tmat/ttot,(tb-tmat-tback)/ttot,tback/ttot,(tc-tinv)/ttot,tinv/ttot,ttot/ttot
  if ( icudagroup > 0 ) call mlp_network_download()

  ! at last step, calculate the eigen-function (qbasis) based on all the deep trajectory data)
  call srv_eigen_basis()

  if ( present(ifsavenetwork) ) then
     if ( ifsavenetwork .eqv. .true. ) then
        call deep_network_save()
        call mlp_network_save()
        call srv_network_save_append_srvinfo()
     end if
  else
     call deep_network_save()
     call mlp_network_save()
     call srv_network_save_append_srvinfo()
  end if
!close(iofile)
end subroutine

subroutine srv_predict()
  integer :: i,iofile,tpnout
  real*8 :: tpinputs(ninput,1,1),tpoutputs(noutput,1,1)

  print "(/,a)","SRV Testing Data"

  tpnout = min(noutput,6)
  open(newunit=iofile,file="predict.txt",action="write")
  do i = 1, deepntotdata
     if ( nkelvin > 0 ) then
        if ( i <= (srvikelvin0-1)*srvkelvinndata .or. i > srvikelvin0*srvkelvinndata) cycle
     end if
     tpinputs(:,1,1) = deeptrajcoor(:,i)
     if ( ninput == noutput .and. nlayer == 2 ) then
        tpoutputs(:,1,1) = tpinputs(:,1,1)
     else
        call mlp_network_forward(1,tpinputs,tpoutputs)
     end if
     tpoutputs(:,1,1) = matmul(tpoutputs(:,1,1)-gmean,gbasis)
     write(iofile,'(f10.3,3i2,10f10.4)') dble(i)*timestepsize, 0, 0, 0, tpoutputs(1:tpnout,1,1)
  end do
  close(iofile)
end subroutine

subroutine srv_eigen_loss(tpndata,tpoutputs0,tpoutputs1,tploss,errormark,tptrajwgt)
  integer,intent(in) :: tpndata
  real*8,intent(inout) :: tpoutputs0(noutput,tpndata),tpoutputs1(noutput,tpndata),tploss
  integer,intent(in),dimension(:),optional :: errormark
  real*8,intent(in),optional :: tptrajwgt(:)

  integer :: i,j,k,info,tempint,sortIndex(noutput),ipiv(noutput),nvaliddata
  real*8,dimension(noutput,noutput) :: ctlmat,tpmat,qmat,gmeanmat
  real*8 :: eigenvalues(noutput),eigenvalues_img(noutput)
  real*8 :: mean0(noutput),mean1(noutput),temp,work(4*noutput)
  real*8 :: ta,tb

  integer :: ioFile
  real*8 :: uncertainty,Xvalue,Yvalue,xmean,ymean,xval,yval,sumx2,sumy2,sumxy,downvalue

  mean0 = 0d0; mean1 = 0d0; nvaliddata = 0
  do i = 1, tpndata
     if ( present(errormark) ) then
        if ( errormark(i) == 1 ) cycle
     end if
     nvaliddata = nvaliddata + 1
     mean0(:) = mean0(:) + tpoutputs0(:,i)
     mean1(:) = mean1(:) + tpoutputs1(:,i)
  end do
  mean0 = mean0/dble(nvaliddata); mean1 = mean1/dble(nvaliddata)
  gmean = (mean0 + mean1)/2d0

  downvalue = 0d0
  if ( srvavgmode == 1 ) then
     do i = 1, tpndata
        if ( present(errormark) ) then
           if ( errormark(i) == 1 ) cycle
        end if
        tpoutputs0(:,i) = tpoutputs0(:,i) - mean0
        tpoutputs1(:,i) = tpoutputs1(:,i) - mean1
        if ( nkelvin /= 0 ) downvalue = downvalue + tptrajwgt(i)
     end do
  end if

  ! calculate the C matrix and Q matrix
  cmat = 0d0; qmat = 0d0
  do i = 1, tpndata

     if ( present(errormark) ) then
        if ( errormark(i) == 1 ) cycle
     end if

     if ( nkelvin == 0 ) then
        do j = 1,noutput
           do k = 1,noutput
              cmat(j,k) = cmat(j,k) + tpoutputs0(j,i)*tpoutputs1(k,i) + tpoutputs1(j,i)*tpoutputs0(k,i)
              qmat(j,k) = qmat(j,k) + tpoutputs0(j,i)*tpoutputs0(k,i) + tpoutputs1(j,i)*tpoutputs1(k,i)
           end do
        end do
     else
        do j = 1,noutput
           do k = 1,noutput
              cmat(j,k) = cmat(j,k) + (tpoutputs0(j,i)*tpoutputs1(k,i) + tpoutputs1(j,i)*tpoutputs0(k,i))*tptrajwgt(i)
              qmat(j,k) = qmat(j,k) + (tpoutputs0(j,i)*tpoutputs0(k,i) + tpoutputs1(j,i)*tpoutputs1(k,i))*tptrajwgt(i)
           end do
        end do
     end if

  end do
  if ( nkelvin == 0 ) then
     cmat = cmat/dble(2*nvaliddata); qmat = qmat/dble(2*nvaliddata)
  else
     cmat = cmat/dble(2); qmat = qmat/dble(2)
     !temp = sum(dabs(cmat)+dabs(qmat))/dble(2d0*noutput*noutput)
     !cmat = cmat*dexp(-dlog(temp)); qmat = qmat*dexp(-dlog(temp))
  end if

  if (isrvuncertainty == 1) then
     open (newunit=ioFile, file='uncertainty.txt', action="write")
     do j = 1, noutput
        do k = 1,noutput
           uncertainty = 0d0
           if ( nkelvin == 0 ) then
              Xvalue = qmat(j,k); Yvalue = 1d0
           else
              Xvalue = qmat(j,k)/dble(nvaliddata); Yvalue = downvalue/dble(nvaliddata)
           end if
           xmean = Xvalue; ymean = Yvalue
           sumx2 = 0d0; sumy2 = 0d0; sumxy = 0d0
           do i = 1, tpndata
              if ( present(errormark) ) then
                 if ( errormark(i) == 1 ) cycle
              end if
              if ( nkelvin == 0 ) then
                 xval = (tpoutputs0(j,i)*tpoutputs0(k,i) + tpoutputs1(j,i)*tpoutputs1(k,i))/2d0
                 sumx2 = sumx2 + (xval-xmean)**2d0
              else
                 xval = (tpoutputs0(j,i)*tpoutputs0(k,i) + tpoutputs1(j,i)*tpoutputs1(k,i))*tptrajwgt(i)/2d0
                 yval = tptrajwgt(i)
                 sumx2 = sumx2 + (xval-xmean)**2d0; sumy2 = sumy2 + (yval-ymean)**2d0; sumxy = sumxy + (xval-xmean)*(yval-ymean)
              end if
           end do
           if ( nkelvin == 0 ) then
              uncertainty = sumx2/dble(nvaliddata)/dble(nvaliddata-1)
           else
              uncertainty = sumx2/(Xvalue**2d0) + sumy2/(Yvalue**2d0) - 2d0*sumxy/(Xvalue*Yvalue)
              uncertainty = uncertainty*(Xvalue**2d0)/(Yvalue**2d0)/dble(nvaliddata)/dble(nvaliddata-1)
           end if
           write(ioFile,'(2i8,2f15.6))'),j,k,Xvalue/Yvalue,uncertainty
        end do
     end do
     close(ioFile)
  end if

  if ( srvavgmode == 2 ) then
     do i = 1,noutput
        do j = 1,noutput
           gmeanmat(i,j) = gmean(i)*gmean(j)
        end do
     end do
     cmat = cmat - gmeanmat; qmat = qmat - gmeanmat
  end if

  ! decomposition for Q matrix, Q = L * L^t
  lmat = 0d0
  do k = 1,noutput
     ! lmat(k,k) = sqrt(qmat(k,k)-dot_product(lmat(k,1:k-1),lmat(k,1:k-1)))
     temp = qmat(k,k)-dot_product(lmat(k,1:k-1),lmat(k,1:k-1))
     if ( abs(temp) < 1d-10 ) then
        temp = 1d-10
     else if ( temp < -1d-10 ) then
        print *,"matrix error (Q = L * L^t)!",temp; stop
     end if
     lmat(k,k) = dsqrt(temp)
     do j = k+1,noutput
        lmat(j,k) = (qmat(j,k)-dot_product(lmat(j,1:k-1),lmat(k,1:k-1)))/lmat(k,k)
     end do
  end do

  call cpu_time(ta)
  linvmat = lmat
  call DGETRF(noutput,noutput,linvmat,noutput,ipiv,info)
  call DGETRI(noutput,linvmat,noutput,ipiv,work,noutput,info)

  ! matrix Cm = L^t * C * (L^-1)^t
  ctlmat = matmul(linvmat,matmul(cmat,transpose(linvmat)))

  ! solve the standard eigenvalue equation, Cm * V = V * L
  smat = 0d0; tpmat = 0d0
  call dgeev("N", "V", noutput, ctlmat, noutput, eigenvalues, eigenvalues_img, &
             tpmat, noutput, smat, noutput, work, 4*noutput, info)

  do i = 1, noutput; sortIndex(i) = i; end do
  do i = 1, noutput
     do j = i + 1, noutput
        if ( eigenvalues(j) > eigenvalues(i) ) then
           temp = eigenvalues(i); eigenvalues(i) = eigenvalues(j); eigenvalues(j) = temp
           tempint = sortIndex(i); sortIndex(i) = sortIndex(j); sortIndex(j) = tempint
        end if
     end do
  end do

  tpmat = smat
  do i = 1, noutput
     smat(:,i) = tpmat(:,sortIndex(i))
  end do

  tploss = 0d0
  do j = 1,noutput
     lambda(j) = eigenvalues(j)
     tploss = tploss - lambda(j)
  end do
  call cpu_time(tb)
  tinv = tinv + tb - ta

end subroutine

! Calculate the eigen-function based on all the deep trajectory data
subroutine srv_eigen_basis()
  integer :: idata,ilayer,tpbatchsize,errormark(deepntotdata-ntau)
  real*8 :: tpinput(ninput,1,1),tpoutput(noutput,1,1),tploss,temp
  integer :: i,it2
  real*8,dimension(:,:),pointer :: tpoutputs0,tpoutputs1

  allocate(tpoutputs0(noutput,deepntotdata),tpoutputs1(noutput,deepntotdata))
  tpbatchsize = batchsize; batchsize = 1

  if ( ifuselayernorm .eqv. .true. ) then
     do ilayer = 1, nlayer
        deallocate(mlplayers(ilayer)%layermean)
        allocate(mlplayers(ilayer)%layermean(batchsize,1,1))
        deallocate(mlplayers(ilayer)%layersigma)
        allocate(mlplayers(ilayer)%layersigma(batchsize,1,1))
        mlplayers(ilayer)%layerweight = 0d0; mlplayers(ilayer)%layerbias = 0d0
     end do
  end if

  if ( ninput == noutput .and. nlayer == 2 ) then
     do idata = 1, deepntotdata
        tpoutputs0(1:noutput,idata) = deeptrajcoor(1:ninput,idata)
!write(6,'(a,i15,100f15.6)'),'output0:',idata,tpoutputs0(:,idata)
     end do
  else
     do idata = 1, deepntotdata
        tpinput(:,1,1) = deeptrajcoor(1:ninput,idata)
        call mlp_network_forward(1,tpinput,tpoutput)
        tpoutputs0(1:noutput,idata) = tpoutput(:,1,1)
     end do
  end if

  batchsize = tpbatchsize; errormark = 0

  ! get the time-lagged outputs at t+tau steps
  if ( nkelvin > 0 ) then
     kelvinnvalid = 0d0; tpkelvinvec=0d0
  end if
  do idata = 1, deepntotdata - ntau
     if ( deeptrajindex(idata) /= deeptrajindex(idata+ntau) ) then
!write(6,'(a,i15,100i15)'),'trajindex:',idata,deeptrajindex(idata),deeptrajindex(idata+ntau)
        errormark(idata) = 1; cycle
     end if
     tpoutputs1(:,idata) = tpoutputs0(:,idata+ntau)

     if (nkelvin > 0) then
        it2 = (idata-1)/srvkelvinndata + 1
        kelvinnvalid(it2) = kelvinnvalid(it2) + 1d0
     end if
  end do

  if (iuncertainty == 1) isrvuncertainty = 1
  if ( nkelvin == 0 ) then
     call srv_eigen_loss(deepntotdata-ntau, tpoutputs0, tpoutputs1, tploss, errormark=errormark)
  else
     call srv_eigen_loss(deepntotdata-ntau, tpoutputs0, tpoutputs1, tploss, errormark=errormark, tptrajwgt = srvtrajwgt)
  end if
  isrvuncertainty = 0

  deallocate(tpoutputs0,tpoutputs1)

  ! eigenvvector of the generalized eigenvalue equation, C * S = Lamda * Q * S   ( Q = L * L^t)
  ! S = (L^-1)^t * V
  gbasis = matmul(transpose(linvmat),smat)
  do i = 1,noutput
     if ( gbasis(1,i) < 0d0 ) gbasis(:,i) = -gbasis(:,i)
  end do

  if ( ifnormeigenvec .eqv. .true. ) then
     do i = 1,noutput
        temp = sqrt(dot_product(gbasis(:,i),gbasis(:,i)))
        gbasis(:,i) = gbasis(:,i)/temp
     end do
  end if

end subroutine

subroutine srv_eigen_backward(tpoutputs0,tpoutputs1,errormark)
  real*8,intent(in) :: tpoutputs0(noutput,batchsize),tpoutputs1(noutput,batchsize)
  integer,intent(in),dimension(:),optional :: errormark
  integer :: info,i,j,k,l,i1,j1,ilayer,ipiv(noutput),nvaliddata
  real*8,dimension(noutput,noutput) :: tpmat,sinvmat,bctlmat,bcmat,blinvmat,blmat,bqmat
  real*8 :: work(4*noutput),bout0(noutput,batchsize),bout1(noutput,batchsize)
  real*8 :: tpoutputs(noutput,batchsize,maxnsteps)
  real*8 :: bmean0(noutput),bmean1(noutput),tpbcvalue,tpbqvalue,temp
real*8 :: t1,t2

call cpu_time(t1)
  ! inverse matrix of S matrix in Eq.42
  sinvmat = smat
  call DGETRF(noutput,noutput,sinvmat,noutput,ipiv,info)
  call DGETRI(noutput,sinvmat,noutput,ipiv,work,noutput,info)

  ! dLoss/dLamda
  tpmat = 0d0
  do j = 1,noutput
     !tpmat(j,j) = -1d0
     tpmat(j,j) = -1d0
  end do

  ! Cm = dLoss/dCm = (S^-1)^t * dLoss/dLamda * S
  bctlmat = matmul(transpose(sinvmat),matmul(tpmat,transpose(smat)))

  ! bcmat = Bc = dLoss/dC = (L^-1)^t * Cm * L^-1
  bcmat = matmul(transpose(linvmat),matmul(bctlmat,linvmat))

  ! B = dLoss/dL^-1 = Cm * ( L^-1 * C^t ) + Cm^t *( L^-1 * C)
  blinvmat = matmul(bctlmat,matmul(linvmat,transpose(cmat))) + matmul(transpose(bctlmat),matmul(linvmat,cmat))

  ! Bm = dLoss/dL = - (L^-1)^t * B * L^t
  blmat = - matmul(transpose(linvmat),matmul(blinvmat,transpose(linvmat)))

  ! bqmat = dLoss/dQ = dLoss/dL * dL/dQ = Bm * dL/dQ
  bqmat = 0d0; tpmat = blmat
  do i = noutput,1,-1
     do j = i,1,-1
        if (j==i) then
           bqmat(i,j) = 0.5d0*tpmat(i,j)/lmat(j,j)
        else
           bqmat(i,j) = tpmat(i,j)/lmat(j,j)
           tpmat(j,j) = tpmat(j,j) - tpmat(i,j)*lmat(i,j)/lmat(j,j)
        end if
        do k = j-1,1,-1
           tpmat(i,k) = tpmat(i,k) - bqmat(i,j)*lmat(j,k)
           tpmat(j,k) = tpmat(j,k) - bqmat(i,j)*lmat(i,k)
        end do
     end do
  end do
call cpu_time(t2)
tmat = tmat + t2 - t1

  nvaliddata = 0
  do i = 1, batchsize
     if ( present(errormark) ) then
        if ( errormark(i) == 1 ) cycle
     end if
     nvaliddata = nvaliddata + 1
  end do

  ! dL/dOutput = dLoss/dC * dC/dOutput + dLoss/dQ * dQ/dOutput
  !            = bcmat * dC/dOutput + bqmat * dQ/dOutput
  bout0 = 0d0; bout1 = 0d0
  do i = 1, batchsize
     if ( present(errormark) ) then
        if ( errormark(i) == 1 ) cycle
     end if
     do j = 1,noutput
        do k = 1,noutput
           tpbcvalue = bcmat(j,k); tpbqvalue = bqmat(j,k)
           if (nkelvin > 0) then
              tpbcvalue = tpbcvalue*batchtrajwgt(i); tpbqvalue = tpbqvalue*batchtrajwgt(i)
           end if

           ! dC/dOutput0
           bout0(j,i) = bout0(j,i) + tpoutputs1(k,i)*tpbcvalue
           bout0(k,i) = bout0(k,i) + tpoutputs1(j,i)*tpbcvalue
           ! dC/dOutput1
           bout1(k,i) = bout1(k,i) + tpoutputs0(j,i)*tpbcvalue
           bout1(j,i) = bout1(j,i) + tpoutputs0(k,i)*tpbcvalue
           ! dQ/dOutput0
           bout0(j,i) = bout0(j,i) + tpoutputs0(k,i)*tpbqvalue
           bout0(k,i) = bout0(k,i) + tpoutputs0(j,i)*tpbqvalue
           ! dQ/dOutput1
           bout1(j,i) = bout1(j,i) + tpoutputs1(k,i)*tpbqvalue
           bout1(k,i) = bout1(k,i) + tpoutputs1(j,i)*tpbqvalue

           if ( srvavgmode == 2 ) then
              bout0(j,i) = bout0(j,i) - gmean(k)*tpbcvalue
              bout0(k,i) = bout0(k,i) - gmean(j)*tpbcvalue
              bout1(j,i) = bout1(j,i) - gmean(k)*tpbcvalue
              bout1(k,i) = bout1(k,i) - gmean(j)*tpbcvalue
              bout0(j,i) = bout0(j,i) - gmean(k)*tpbqvalue
              bout0(k,i) = bout0(k,i) - gmean(j)*tpbqvalue
              bout1(j,i) = bout1(j,i) - gmean(k)*tpbqvalue
              bout1(k,i) = bout1(k,i) - gmean(j)*tpbqvalue
           end if
        end do
     end do
  end do
  if ( nkelvin == 0 ) then
     bout0 = bout0/dble(2*nvaliddata); bout1 = bout1/dble(2*nvaliddata)
  else
     bout0 = bout0/dble(2); bout1 = bout1/dble(2)
  end if

  if ( srvavgmode == 1 ) then
     bmean0 = 0d0; bmean1 = 0d0
     do i = 1, batchsize
        if ( present(errormark) ) then
           if ( errormark(i) == 1 ) cycle
        end if
        bmean0(:) = bmean0(:) + bout0(:,i)
        bmean1(:) = bmean1(:) + bout1(:,i)
     end do
     bmean0 = bmean0/dble(nvaliddata); bmean1 = bmean1/dble(nvaliddata)
     do i = 1, batchsize
        if ( present(errormark) ) then
           if ( errormark(i) == 1 ) cycle
        end if
        bout0(:,i) = bout0(:,i) - bmean0
        bout1(:,i) = bout1(:,i) - bmean1
     end do
  end if

call cpu_time(t1)
  do j = 1, batchsize
     tpoutputs(:,j,1) = bout0(:,j)
  end do
  call mlp_network_backward_bptt(1,tpoutputs,.false.,errormark=errormark)

  do j = 1, batchsize
     tpoutputs(:,j,1) = bout1(:,j)
  end do
  call mlp_network_backward_bptt(2,tpoutputs,.false.,errormark=errormark)
call cpu_time(t2)
tback = tback + t2 - t1
end subroutine

!================================= SRV on GPU =========================================

attributes(global) subroutine srv_batch_upload_errormark(igroup)
  integer,intent(in),value :: igroup
  integer :: ipos,tarpos,ishfl,tpvalue,tpsum

  ipos = (blockidx%x-1)*32+threadidx%x; if (ipos > icudagroup_d) return
  tarpos = (igroup-1)*icudagroup_d + ipos
  batcherrormark_d(tarpos) = errormark_d(ipos)
  tpsum = 1 - errormark_d(ipos)

  ishfl = 1
  do while (ishfl<=16)
     tpvalue = __shfl_xor(tpsum,ishfl); tpsum = tpsum + tpvalue
     ishfl = ishfl*2
  end do

  if ( threadidx%x == 1 ) then
     tpvalue = atomicadd(nvaliddata_d,tpsum)
  end if
end subroutine

attributes(global) subroutine srv_batch_download_errormark(igroup)
  integer,intent(in),value :: igroup
  integer :: ipos,tarpos,ishfl,tpvalue,tpsum

  ipos = (blockidx%x-1)*32+threadidx%x; if (ipos > icudagroup_d) return
  tarpos = (igroup-1)*icudagroup_d + ipos
  errormark_d(ipos) = batcherrormark_d(tarpos)
end subroutine

subroutine srv_eigen_loss_cudapack()
  real*8 :: ta,tb

  mean0_d = 0.0_SD; mean1_d = 0.0_SD; gmean_d = 0.0_SD; cmat_d = 0.0_SD; qmat_d = 0.0_SD; lmat_d = 0.0_SD
  call srv_eigen_mean_cuda<<<noutput*((batchsize-1)/32+1),32>>>()
  if ( srvavgmode == 1 ) call srv_eigen_minusmean_cuda<<<noutput*((batchsize-1)/32+1),32>>>()
  call srv_eigen_cqmat_cuda<<<noutput*((batchsize-1)/32+1),32>>>()

  ! decomposition for Q matrix on GPU, Q = L * L^t (Have some issues)
  !lmat_d = qmat_d
  !call CUSOLVER_CHECK(cusolverDnXpotrf(cusolverH, params, uplo, noutput, dataType, lmat_d, noutput, dataType,&
  !                    potrfbufferOnDevice, potrfworkspaceInBytesOnDevice, potrfbufferOnHost, potrfworkspaceInBytesOnHost, devinfo ))
  !call srv_remove_upper_cuda<<<(noutput*noutput-1)/32+1,32>>>()
  call srv_cholesky_lmat()

  linvmat_d = lmat_d
  call CUSOLVER_CHECK(cusolverDnXgetrf(cusolverH, params, noutput, noutput, dataType, linvmat_d, noutput, devipiv,&
                      dataType, getrfbufferOnDevice, getrfworkspaceInBytesOnDevice, getrfbufferOnHost,getrfworkspaceInBytesOnHost, devinfo ))
  tpmat_d = identity_d
  call CUSOLVER_CHECK(cusolverDnXgetrs(cusolverH, params, trans, noutput, noutput, dataType, linvmat_d, noutput, devipiv, dataType, tpmat_d, noutput, devinfo ))
  linvmat_d = tpmat_d

  call cublasXgemm('N','T',noutput,noutput,noutput,1.0_SD,cmat_d,noutput,linvmat_d,noutput,0.0_SD,tpmat_d,noutput)
  call cublasXgemm('N','N',noutput,noutput,noutput,1.0_SD,linvmat_d,noutput,tpmat_d,noutput,0.0_SD,ctlmat_d,noutput)

  smat_d = ctlmat_d
noutput = noutput_d; noutput_d = noutput
call cpu_time(ta)
  call CUSOLVER_CHECK(cusolverDnXsyevdx(cusolverH, params, jobz, range, uplo, noutput, dataType, &
                                 smat_d, noutput, 0.0_DP, 0.0_DP, 1, noutput, h_meig, dataType, eigenvalues_d, &
                                 dataType, syevdxbufferOnDevice, syevdxworkspaceInBytesOnDevice, syevdxbufferOnHost, &
                                 syevdxworkspaceInBytesOnHost, devinfo))
noutput = noutput_d; noutput_d = noutput
call cpu_time(tb)
tinv = tinv + tb - ta
  call srv_cusolver_changeorder<<<(noutput+1)/2,32>>>()
  lambda_d = eigenvalues_d
end subroutine

subroutine srv_cholesky_lmat()
  integer j,k
  real*8 temp,qmat(noutput,noutput)
  ! decomposition for Q matrix, Q = L * L^t
  lmat = 0d0; qmat = qmat_d
  do k = 1,noutput
     ! lmat(k,k) = sqrt(qmat(k,k)-dot_product(lmat(k,1:k-1),lmat(k,1:k-1)))
     temp = qmat(k,k)-dot_product(lmat(k,1:k-1),lmat(k,1:k-1))
     if ( abs(temp) < 1d-10 ) then
        temp = 1d-10
     else if ( temp < -1d-10 ) then
        print *,"matrix error (Q = L * L^t)!",temp; stop
     end if
     lmat(k,k) = dsqrt(temp)
     do j = k+1,noutput
        lmat(j,k) = (qmat(j,k)-dot_product(lmat(j,1:k-1),lmat(k,1:k-1)))/lmat(k,k)
     end do
  end do
  lmat_d = lmat
end subroutine

attributes(global) subroutine srv_remove_upper_cuda()
  integer :: ipos,irow,icol
  ipos = (blockidx%x-1)*32+threadidx%x; irow = (ipos-1)/noutput_d+1; icol = ipos - (irow-1)*noutput_d
  if (irow<icol) lmat_d(irow,icol) = 0.0_SD
end subroutine

attributes(global) subroutine srv_eigen_mean_cuda()
  integer :: blockperout,iout,ipos,igroup,idx,idx0,idx1,ishfl
  real(kind=SD) :: tpvalue0,tpvalue1,tpsum0,tpsum1

  blockperout = (batchsize_d-1)/32+1; iout = (blockidx%x-1)/(blockperout)+1
  ipos = (blockidx%x-1)*32+threadidx%x-(iout-1)*blockperout*32; if (ipos>batchsize_d) return

  igroup = (ipos-1)/icudagroup_d+1; idx = ipos - (igroup-1)*icudagroup_d
  idx0 = (igroup-1)*hiddenstate_index_d(nlayer_d+1)+hiddenstate_index_d(nlayer_d)+(idx-1)*noutput_d+iout
  idx1 = idx0 + noutput_d*icudagroup_d

  if ( batcherrormark_d(ipos) == 1 ) then
     tpsum0 = 0.0_SD; tpsum1 = 0.0_SD
  else
     tpsum0 = batch_hiddenstate_d(idx0)/nvaliddata_d; tpsum1 = batch_hiddenstate_d(idx1)/nvaliddata_d
  end if

  ishfl = 1
  do while (ishfl<=16)
     tpvalue0 = __shfl_xor(tpsum0,ishfl); tpsum0 = tpsum0 + tpvalue0
     tpvalue1 = __shfl_xor(tpsum1,ishfl); tpsum1 = tpsum1 + tpvalue1
     ishfl = ishfl*2
  end do

  if ( threadidx%x == 1 ) then
     tpvalue0 = atomicadd(mean0_d(iout),tpsum0)
     tpvalue1 = atomicadd(mean1_d(iout),tpsum1)
     tpvalue0 = atomicadd(gmean_d(iout),(tpsum0+tpsum1)/2.0_SD)
  end if
end subroutine

attributes(global) subroutine srv_eigen_minusmean_cuda()
  integer :: blockperout,iout,ipos,igroup,idx,idx0,idx1,ishfl
  real(kind=SD) :: tpvalue0,tpvalue1,tpsum0,tpsum1

  blockperout = (batchsize_d-1)/32+1; iout = (blockidx%x-1)/(blockperout)+1
  ipos = (blockidx%x-1)*32+threadidx%x-(iout-1)*blockperout*32; if (ipos>batchsize_d) return

  igroup = (ipos-1)/icudagroup_d+1; idx = ipos - (igroup-1)*icudagroup_d
  idx0 = (igroup-1)*hiddenstate_index_d(nlayer_d+1)+hiddenstate_index_d(nlayer_d)+(idx-1)*noutput_d+iout
  idx1 = idx0 + noutput_d*icudagroup_d

  batch_hiddenstate_d(idx0) = batch_hiddenstate_d(idx0) - mean0_d(iout)
  batch_hiddenstate_d(idx1) = batch_hiddenstate_d(idx1) - mean1_d(iout)
end subroutine

attributes(global) subroutine srv_eigen_cqmat_cuda()
  integer :: blockperout,iout,kout,ipos,igroup,idx,ibase0,ibase1,ishfl
  real(kind=SD) :: tpcvalue,tpqvalue,tpvalue

  blockperout = (batchsize_d-1)/32+1; iout = (blockidx%x-1)/(blockperout)+1
  ipos = (blockidx%x-1)*32+threadidx%x-(iout-1)*blockperout*32; if (ipos>batchsize_d) return

  igroup = (ipos-1)/icudagroup_d+1; idx = ipos - (igroup-1)*icudagroup_d
  ibase0 = (igroup-1)*hiddenstate_index_d(nlayer_d+1)+hiddenstate_index_d(nlayer_d)+(idx-1)*noutput_d
  ibase1 = ibase0 + noutput_d*icudagroup_d

  do kout = 1,noutput_d
     if ( batcherrormark_d(ipos) == 1 ) then
        tpcvalue = 0.0_SD; tpqvalue = 0.0_SD
     else
        tpcvalue = batch_hiddenstate_d(iout+ibase0)*batch_hiddenstate_d(kout+ibase1) + batch_hiddenstate_d(iout+ibase1)*batch_hiddenstate_d(kout+ibase0)
        tpqvalue = batch_hiddenstate_d(iout+ibase0)*batch_hiddenstate_d(kout+ibase0) + batch_hiddenstate_d(iout+ibase1)*batch_hiddenstate_d(kout+ibase1)
        tpcvalue = tpcvalue/(2.0_SD*nvaliddata_d); tpqvalue = tpqvalue/(2.0_SD*nvaliddata_d)
     end if

     ishfl = 1
     do while (ishfl<=16)
        tpvalue = __shfl_xor(tpcvalue,ishfl); tpcvalue = tpcvalue + tpvalue
        tpvalue = __shfl_xor(tpqvalue,ishfl); tpqvalue = tpqvalue + tpvalue
        ishfl = ishfl*2
     end do

     if ( threadidx%x == 1 ) then
        tpvalue = atomicadd(cmat_d(iout,kout),tpcvalue)
        tpvalue = atomicadd(qmat_d(iout,kout),tpqvalue)
     end if
  end do
end subroutine

subroutine errormsg(msg,real1,real2,real3,int1,int2,int3,str1,str2,str3,log1,log2,log3,ifwarning)
  include 'mpif.h'
  character(len=*),intent(in) :: msg
  real*8,intent(in),optional :: real1,real2,real3
  integer,intent(in),optional :: int1,int2,int3
  logical,intent(in),optional :: log1,log2,log3,ifwarning
  character(len=*),intent(in),optional :: str1,str2,str3
  integer :: ierr,iosiminfo

  iosiminfo=6; ierr=1
  if ( present(ifwarning) ) then
     if ( ifwarning .eqv. .true. ) ierr=0
  end if
  if ( ierr == 0 ) then
     write (iosiminfo, "(a,a)") "Warning: ",msg
  else if (ierr == 1) then
     write (iosiminfo, "(a,a)") "Error: ",msg
  endif

  write (iosiminfo, "(a,a)") "Error: ",msg
  if ( present(real1) ) write(iosiminfo,"(a,f10.3)") "real1= ",real1
  if ( present(real2) ) write(iosiminfo,"(a,f10.3)") "real2= ",real2
  if ( present(real3) ) write(iosiminfo,"(a,f10.3)") "real3= ",real3
  if ( present(int1) ) write(iosiminfo,"(a,i10)") "int1= ",int1
  if ( present(int2) ) write(iosiminfo,"(a,i10)") "int2= ",int2
  if ( present(int3) ) write(iosiminfo,"(a,i10)") "int3= ",int3
  if ( present(str1) ) write(iosiminfo,"(a,a)") "str1= ",trim(str1)
  if ( present(str2) ) write(iosiminfo,"(a,a)") "str2= ",trim(str2)
  if ( present(str3) ) write(iosiminfo,"(a,a)") "str3= ",trim(str3)
  if ( present(log1) ) write(iosiminfo,"(a,l6)") "log1= ",log1
  if ( present(log2) ) write(iosiminfo,"(a,l6)") "log2= ",log2
  if ( present(log3) ) write(iosiminfo,"(a,l6)") "log3= ",log3
  flush(iosiminfo)
  if ( ierr == 1 ) then
     if ( mpi_comm_world > 0 ) call mpi_finalize(ierr)
     stop
  end if
end subroutine

subroutine CUSOLVER_CHECK(status)
  integer, intent(in) :: status
  ! status from website:
  ! https://docs.nvidia.com/hpc-sdk/compilers/fortran-cuda-interfaces/index.html#cfsolver-init
  select case (status)
  case (0); return
  case (1); call errormsg('cusolver', str1="CUSOLVER_STATUS_NOT_INITIALIZED")
  case (2); call errormsg('cusolver', str1="CUSOLVER_STATUS_ALLOC_FAILED")
  case (3); call errormsg('cusolver', str1="CUSOLVER_STATUS_INVALID_VALUE")
  case (4); call errormsg('cusolver', str1="CUSOLVER_STATUS_ARCH_MISMATCH")
  case (5); call errormsg('cusolver', str1="CUSOLVER_STATUS_MAPPING_ERROR")
  case (6); call errormsg('cusolver', str1="CUSOLVER_STATUS_EXECUTION_FAILED")
  case (7); call errormsg('cusolver', str1="CUSOLVER_STATUS_INTERNAL_ERROR")
  case (8); call errormsg('cusolver', str1="CUSOLVER_STATUS_MATRIX_TYPE_NOT_SUPPORTED")
  case (9); call errormsg('cusolver', str1="CUSOLVER_STATUS_NOT_SUPPORTED")
  case (10); call errormsg('cusolver', str1="CUSOLVER_STATUS_ZERO_PIVOT")
  case (11); call errormsg('cusolver', str1="CUSOLVER_STATUS_INVALID_LICENSE")
  case (12); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_NOT_INITIALIZED")
  case (13); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID")
  case (14); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID_PREC")
  case (15); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID_REFINE")
  case (16); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID_MAXITER")
  case (20); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_INTERNAL_ERROR")
  case (21); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_NOT_SUPPORTED")
  case (22); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_OUT_OF_RANGE")
  case (23); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_NRHS_NOT_SUPPORTED_FOR_REFINE_GMRES")
  case (25); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_INFOS_NOT_INITIALIZED")
  case (26); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_INFOS_NOT_DESTROYED")
  case (30); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_MATRIX_SINGULAR")
  case (31); call errormsg('cusolver', str1="CUSOLVER_STATUS_INVALID_WORKSDACE")
  end select
end subroutine CUSOLVER_CHECK

subroutine srv_culib_ini()
  implicit none
  integer istat

  dataType = cudaDataType(CUDA_R_64F)
  call CUSOLVER_CHECK(cusolverDnCreate(cusolverH))
  call CUSOLVER_CHECK(cusolverDnCreateParams(params))

  potrfworkspaceInBytesOnHost = 0; potrfworkspaceInBytesOnDevice = 0
  call CUSOLVER_CHECK(cusolverDnXpotrf_bufferSize(cusolverH, params, uplo, noutput, dataType,&
                      lmat_d, noutput, dataType, potrfworkspaceInBytesOnDevice, potrfworkspaceInBytesOnHost))
  allocate (potrfbufferOnDevice(potrfworkspaceInBytesOnDevice), potrfbufferOnHost(potrfworkspaceInBytesOnHost))

  allocate (devipiv(noutput))
  getrfworkspaceInBytesOnHost = 0; getrfworkspaceInBytesOnDevice = 0
  call CUSOLVER_CHECK(cusolverDnXgetrf_bufferSize(cusolverH, params, noutput, noutput, dataType, linvmat_d, &
                      noutput, dataType, getrfworkspaceInBytesOnDevice, getrfworkspaceInBytesOnHost))
  allocate (getrfbufferOnDevice(getrfworkspaceInBytesOnDevice), getrfbufferOnHost(getrfworkspaceInBytesOnHost))

  syevdxworkspaceInBytesOnHost = 0; syevdxworkspaceInBytesOnDevice = 0
  call CUSOLVER_CHECK(cusolverDnXsyevdx_buffersize(cusolverH, params, jobz, range, uplo, noutput, dataType, &
                              smat_d, noutput, 0.0_DP, 0.0_DP, 1, noutput, h_meig, dataType, eigenvalues_d, &
                              dataType, syevdxworkspaceInBytesOnDevice, syevdxworkspaceInBytesOnHost))
  allocate (syevdxbufferOnDevice(syevdxworkspaceInBytesOnDevice), syevdxbufferOnHost(syevdxworkspaceInBytesOnHost))

  istat = cublasInit()
end subroutine

attributes(global) subroutine srv_cusolver_changeorder()
  integer :: iblock,ithread,icol,jcol,irow
  real(kind=SD) :: tpval

  iblock = blockidx%x; ithread = threadidx%x
  icol = iblock; jcol = noutput_d - icol + 1
  do irow = ithread,noutput_d,32
     tpval = smat_d(irow,icol); smat_d(irow,icol) = smat_d(irow,jcol); smat_d(irow,jcol) = tpval
  end do
  if (ithread==1) then
     tpval = eigenvalues_d(icol); eigenvalues_d(icol) = eigenvalues_d(jcol); eigenvalues_d(jcol) = tpval
     tpval = atomicadd(totloss_d,-eigenvalues_d(icol))
     if ( icol /= jcol ) then
        tpval = atomicadd(totloss_d,-eigenvalues_d(jcol))
     end if
  end if
end subroutine

subroutine srv_eigen_backward_cudapack(ibatch)
  implicit none
  integer,intent(in),optional :: ibatch
  integer :: i,j,k,nvaliddata,ilayer,igroup
  real*8 :: tpmat(noutput,noutput),bqmat(noutput,noutput)
  real(kind=SD),device :: tpmat2_d(noutput,noutput)
real*8 :: t1,t2

noutput = noutput_d; noutput_d = noutput
call cpu_time(t1)
  sinvmat_d = smat_d
  call CUSOLVER_CHECK(cusolverDnXgetrf(cusolverH, params, noutput, noutput, dataType, sinvmat_d, noutput, devipiv,&
                      dataType, getrfbufferOnDevice, getrfworkspaceInBytesOnDevice, getrfbufferOnHost,getrfworkspaceInBytesOnHost, devinfo ))
  tpmat_d = identity_d
  call CUSOLVER_CHECK(cusolverDnXgetrs(cusolverH, params, trans, noutput, noutput, dataType, sinvmat_d, noutput, devipiv, dataType, tpmat_d, noutput, devinfo ))
  sinvmat_d = tpmat_d

  tpmat_d = 0.0_SD
  do i = 1, noutput
     tpmat_d(i,i) = 1.0_SD
  end do
 
  call cublasXgemm('N','T',noutput,noutput,noutput,-1.0_SD,tpmat_d,noutput,smat_d,noutput,0.0_SD,tpmat2_d,noutput)
  call cublasXgemm('T','N',noutput,noutput,noutput,1.0_SD,sinvmat_d,noutput,tpmat2_d,noutput,0.0_SD,bctlmat_d,noutput)

  call cublasXgemm('N','N',noutput,noutput,noutput,1.0_SD,bctlmat_d,noutput,linvmat_d,noutput,0.0_SD,tpmat_d,noutput)
  call cublasXgemm('T','N',noutput,noutput,noutput,1.0_SD,linvmat_d,noutput,tpmat_d,noutput,0.0_SD,bcmat_d,noutput)

  call cublasXgemm('N','T',noutput,noutput,noutput,1.0_SD,linvmat_d,noutput,cmat_d,noutput,0.0_SD,tpmat_d,noutput)
  call cublasXgemm('N','N',noutput,noutput,noutput,1.0_SD,bctlmat_d,noutput,tpmat_d,noutput,0.0_SD,blinvmat_d,noutput)
  call cublasXgemm('N','N',noutput,noutput,noutput,1.0_SD,linvmat_d,noutput,cmat_d,noutput,0.0_SD,tpmat_d,noutput)
  call cublasXgemm('T','N',noutput,noutput,noutput,1.0_SD,bctlmat_d,noutput,tpmat_d,noutput,0.0_SD,tpmat2_d,noutput)
  call cublasXgemm('N','N',noutput,noutput,noutput,1.0_SD,tpmat2_d,noutput,identity_d,noutput,1.0_SD,blinvmat_d,noutput)

  call cublasXgemm('N','T',noutput,noutput,noutput,1.0_SD,blinvmat_d,noutput,linvmat_d,noutput,0.0_SD,tpmat_d,noutput)
  call cublasXgemm('T','N',noutput,noutput,noutput,-1.0_SD,linvmat_d,noutput,tpmat_d,noutput,0.0_SD,blmat_d,noutput)

  ! bqmat = dLoss/dQ = dLoss/dL * dL/dQ = Bm * dL/dQ
  bqmat = 0d0; tpmat = blmat_d; lmat = lmat_d
  do i = noutput,1,-1
     do j = i,1,-1
        if (j==i) then
           bqmat(i,j) = 0.5d0*tpmat(i,j)/lmat(j,j)
        else
           bqmat(i,j) = tpmat(i,j)/lmat(j,j)
           tpmat(j,j) = tpmat(j,j) - tpmat(i,j)*lmat(i,j)/lmat(j,j)
        end if
        do k = j-1,1,-1
           tpmat(i,k) = tpmat(i,k) - bqmat(i,j)*lmat(j,k)
           tpmat(j,k) = tpmat(j,k) - bqmat(i,j)*lmat(i,k)
        end do
     end do
  end do

  bqmat_d = bqmat; bout0_d = 0.0_SD; bout1_d = 0.0_SD
noutput = noutput_d; noutput_d = noutput
call cpu_time(t2)
tmat = tmat + t2 - t1
  call srv_mat2out_cuda<<<batchsize*((noutput-1)/32+1),32>>>()

noutput = noutput_d; noutput_d = noutput
call cpu_time(t1)
  if ( .not. present(ibatch) ) then
     print *,'One more parameter named ibatch should been provided for cuda backward.'
     stop
  end if
  do igroup = 1, (batchsize-1)/icudagroup+1
     call srv_batch_download_errormark<<<(icudagroup-1)/32+1,32>>>(igroup)
     call srv_eigen_backward_hiddenstate<<<(noutput*icudagroup-1)/32+1,32>>>(igroup)

     call mlp_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(1,igroup,.false.)

     call srv_batch_download_hiddenstate<<<(hiddenstate_index(nlayer+1)-1)/32+1,32>>>(igroup)
     call srv_batch_download_active<<<(grad_active_index(nlayer+1)-1)/32+1,32>>>(igroup)
     do ilayer = nlayer-1,2,-1
        call mlp_network_backward_cuda_layer<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(1,ilayer)
     end do
     call mlp_network_backward_cuda_outputlayer<<<(icudagroup*noutput-1)/32+1,32>>>(2,igroup,.false.)
     do ilayer = nlayer-1,2,-1
        call mlp_network_backward_cuda_layer<<<icudagroup*mlplayers(ilayer)%neurons,32>>>(2,ilayer)
     end do
  end do
noutput = noutput_d; noutput_d = noutput
call cpu_time(t2)
tback = tback + t2 - t1
end subroutine

attributes(global) subroutine srv_mat2out_cuda()
  integer :: blockperbatch,ibatch,jout,kout,igroup,idx,ibase0,ibase1,ishfl
  real(kind=SD) :: tpbcvalue,tpbqvalue,tpvalue,jival0,kival0,jival1,kival1

  blockperbatch = (noutput_d-1)/32+1; ibatch = (blockidx%x-1)/(blockperbatch)+1
  jout = (blockidx%x-1)*32+threadidx%x-(ibatch-1)*blockperbatch*32; if (jout>noutput_d) return

  igroup = (ibatch-1)/icudagroup_d+1; idx = ibatch - (igroup-1)*icudagroup_d
  ibase0 = (igroup-1)*hiddenstate_index_d(nlayer_d+1)+hiddenstate_index_d(nlayer_d)+(idx-1)*noutput_d
  ibase1 = ibase0 + noutput_d*icudagroup_d

  jival0 = 0.0_SD; jival1 = 0.0_SD
  do kout = 1,noutput_d
     if ( batcherrormark_d(ibatch) == 1 ) then
        tpbcvalue = 0.0_SD; tpbqvalue = 0.0_SD
     else
        tpbcvalue = bcmat_d(jout,kout)/(2.0_SD*nvaliddata_d); tpbqvalue = bqmat_d(jout,kout)/(2.0_SD*nvaliddata_d)
     end if
     ! dC/dOutput0 + dQ/dOutput0
     jival0 = jival0 + (batch_hiddenstate_d(ibase1+kout))*tpbcvalue + (batch_hiddenstate_d(ibase0+kout))*tpbqvalue
     kival0 = (batch_hiddenstate_d(ibase1+jout))*tpbcvalue + (batch_hiddenstate_d(ibase0+jout))*tpbqvalue
     ! dC/dOutput1 + dQ/dOutput1
     jival1 = jival1 + (batch_hiddenstate_d(ibase0+kout))*tpbcvalue + (batch_hiddenstate_d(ibase1+kout))*tpbqvalue
     kival1 = (batch_hiddenstate_d(ibase0+jout))*tpbcvalue + (batch_hiddenstate_d(ibase1+jout))*tpbqvalue

     ishfl = 1
     do while (ishfl<=16)
        tpvalue = __shfl_xor(kival0,ishfl); kival0 = kival0 + tpvalue
        tpvalue = __shfl_xor(kival1,ishfl); kival1 = kival1 + tpvalue
        ishfl = ishfl*2
     end do

     if ( threadidx%x == 1 ) then
        tpvalue = atomicadd(bout0_d(kout,ibatch),kival0)
        tpvalue = atomicadd(bout1_d(kout,ibatch),kival1)
     end if
  end do
  tpvalue = atomicadd(bout0_d(jout,ibatch),jival0)
  tpvalue = atomicadd(bout1_d(jout,ibatch),jival1)
end subroutine

attributes(global) subroutine srv_eigen_backward_hiddenstate(igroup)
  integer,intent(in),value :: igroup
  integer :: ipos,ihid,j,idx,jout

  ! ihid <= hidden(nlayer_d) will been written in download.
  ipos = (blockidx%x-1)*32+threadidx%x; if (ipos > noutput_d*icudagroup_d) return
  idx = (ipos-1)/noutput_d + 1; jout = ipos - (idx-1)*noutput_d
  j = (igroup-1)*icudagroup_d + idx; if (j>batchsize_d) return
  ihid = ipos+hiddenstate_index_d(nlayer_d)

  hiddenstate_d(ihid) = bout0_d(jout,j)
  hiddenstate_d(ihid+noutput_d*icudagroup_d) = bout1_d(jout,j)
end subroutine

!========================= Enhanced Sampling (SRV) ====================================

subroutine srv_flooding_initialize(tpnetworkfile,tpnbiores,tpresname)
  character(len=*),intent(in) :: tpnetworkfile
  integer,intent(in),optional :: tpnbiores
  character*4,dimension(:),intent(in),optional :: tpresname

  networkfile = tpnetworkfile; jobtype = PREDICT
  call deep_initialize("")
  call mlp_initialize(ninput,noutput,nlayer,layers,totparms)
  if (deepprocid==0) print "(a,i16)",    "    Total Parameters : ",totparms
  allocate(gbasis(noutput,noutput),gmean(noutput))
  call srv_network_reload_parmint("srv average mode:",srvavgmode)
  call srv_network_reload_parm1d("gmean:",gmean)
  call srv_network_reload_parm2d("gbasis:",gbasis)
end subroutine

subroutine srv_flooding_forward(prein,preout)
  real*8,dimension(:),intent(in) :: prein
  real*8,dimension(:),intent(out) :: preout
  real*8 :: tpinputs(ninput,1,1),tpoutputs(noutput,1,1)
  integer :: ipro,ires,jres,idx,ipos,i
  !real*8 :: tpval(maxnpair),tpmin,tpmax
  real*8 :: tpval(ninput),tpmin,tpmax

  if ( normalmode == 1 ) then
     tpinputs(:,1,1) = normalfactor*( prein - trajmin )/( trajmax - trajmin )
  else if ( normalmode == 2 ) then
     tpinputs(:,1,1) = normalfactor*( 2d0*prein - (trajmin+trajmax) )/( trajmax - trajmin )
  else
     tpinputs(:,1,1) = prein
  end if

  if ( ninput == noutput .and. nlayer == 2 ) then
     tpoutputs(:,1,1) = tpinputs(:,1,1)
  else
     call mlp_network_forward(1,tpinputs,tpoutputs)
  end if
  preout = matmul(tpoutputs(:,1,1)-gmean,gbasis)
end subroutine

subroutine srv_flooding_backward(netidx, bout, bin)
  integer,intent(in) :: netidx
  real*8,dimension(:) :: bout,bin
  integer :: bptt_step,idata,istep,ilayer
  real*8 :: tpvec(ninput)
  real*8,dimension(maxval(mlplayers(:)%neurons)) :: tpdeltalayer
  integer :: ipro,ires,jres,idx,ipos,i
  !real*8 :: tpval(maxnpair),tpmax,tpmin
  real*8 :: tpval(ninput),tpmax,tpmin

  if ( ninput == noutput .and. nlayer == 2 ) then
     tpvec(1:ninput) = matmul(bout,transpose(gbasis)) 
     if ( normalmode == 1 ) then
        bin = normalfactor*tpvec/(trajmax - trajmin)
     else if ( normalmode == 2 ) then
        bin = normalfactor*2d0*tpvec/( trajmax - trajmin )
     else
        bin = tpvec
     end if
  end if

  do idata = 1, 1

     do istep = maxnsteps, 1, -1

        ! delta^L = d(Loss)/d(S^L) = S^t - y^t
        mlplayers(nlayer)%delta_layer(:) = matmul(bout,transpose(gbasis)) 

        do bptt_step = istep,max(1,istep-bptt_trun+1),-1

           ! Eq.3-24
           ! delta^i = d(Loss)/d(S^i) = U^i+1 * d(f(t))^i+1 * delta^i+1(t) + W^i * d(f(t))^i * delta^i(t+1)
           do ilayer = nlayer-1,1,-1
              if ( bptt_step == istep .or. ilayer==1 ) then 

                 mlplayers(ilayer)%delta_layer(:) = &
                          matmul(transpose(mlplayers(ilayer+1)%weights_l2l(:,:)),mlplayers(ilayer+1)%delta_layer(:))

              else if (ilayer==nlayer-1) then

                 tpdeltalayer(1:mlplayers(ilayer)%neurons) = &
                       matmul(transpose(mlplayers(ilayer)%weights_t2t(:,:)),mlplayers(ilayer)%delta_layer(:))
                 mlplayers(ilayer)%delta_layer(:) = tpdeltalayer(1:mlplayers(ilayer)%neurons)

              else

                 tpdeltalayer(1:mlplayers(ilayer)%neurons) = &
                       matmul(transpose(mlplayers(ilayer+1)%weights_l2l(:,:)),mlplayers(ilayer+1)%delta_layer(:)) + &
                       matmul(transpose(mlplayers(ilayer)%weights_t2t(:,:)),mlplayers(ilayer)%delta_layer(:))
                 mlplayers(ilayer)%delta_layer(:) = tpdeltalayer(1:mlplayers(ilayer)%neurons)


              end if

              if ( ilayer >= 2 ) then
                 mlplayers(ilayer)%delta_layer(:) = &
                     mlplayers(ilayer)%grad_active(:,idata,bptt_step,netidx)*   &
                     mlplayers(ilayer)%delta_layer(:)

                 if ( ifuselayernorm .eqv. .true. ) then
                    mlplayers(ilayer)%delta_layer(:) = mlplayers(ilayer)%layerweight*mlplayers(ilayer)%delta_layer(:) 
                    call mlp_layer_normalization_backward( &
                         mlplayers(ilayer)%layernormin(:,idata,bptt_step,netidx),   &
                         mlplayers(ilayer)%delta_layer(:),                   &
                         mlplayers(ilayer)%layermean(idata,bptt_step,netidx),               &
                         mlplayers(ilayer)%layersigma(idata,bptt_step,netidx) )
                 end if
              end if

           end do

           if ( normalmode == 1 ) then
              bin = normalfactor*mlplayers(1)%delta_layer(:)/(trajmax - trajmin)
           else if ( normalmode == 2 ) then
              bin = normalfactor*2d0*mlplayers(1)%delta_layer(:)/(trajmax - trajmin)
           else
              bin = mlplayers(1)%delta_layer(:)
           end if

        end do
     end do
  end do

end subroutine

!============================= Correctness Check (SRV) ================================

subroutine srv_check_flood()
  real*8,allocatable,dimension(:) :: predata,bin,originv
  real*8,allocatable,dimension(:,:,:) :: tpinputs
  real*8 :: preout(noutput),bout(noutput)
  real*8 :: tpout1(noutput),tpout2(noutput),tpoutputs(noutput,1,1)
  real*8 :: upv,downv,h,maxerr
  integer :: ilayer,i,j,k,nnodes,ires,jres,idx

  allocate(predata(ninput),bin(ninput),originv(ninput),tpinputs(ninput,1,1))
  nnodes = ninput
  call random_seed(); call random_number(predata)

  batchsize = 1; batchsize = 1; maxnsteps = 1; originv = predata
  call srv_flooding_forward(predata,preout)
  bout = 1d0
  call srv_flooding_backward(1, bout, bin)

  h = 0.01d0; maxerr = -1d0
  !do i = 1,mlplayers(1)%neurons
  do i = 1,nnodes
     predata = originv
     predata(i) = originv(i) + h
     call srv_flooding_forward(predata,tpout1)
     predata(i) = originv(i) - h
     call srv_flooding_forward(predata,tpout2)
     maxerr = max(abs(sum((tpout1-tpout2)/(2d0*h))-bin(i)),maxerr)
     print *,i,abs(sum((tpout1-tpout2)/(2d0*h))-bin(i))
  end do
  ! If maxerr in output is -1d0, there must be some issues.
  write(6,'(a,f20.15)'),'SRV Network Flooding Error:',maxerr
  deallocate(predata,bin,originv,tpinputs)
end subroutine

subroutine srv_check_grad()
  integer :: ilayer,idata,i,j,k,ibatch,istart,ipos,index
  real*8 :: rand
  real*8 :: upv,downv,h,originv,tpgrad,maxerr,tpoutputs0(noutput,batchsize),tpoutputs1(noutput,batchsize)
  real*8 :: tpinputs(ninput,batchsize,1),tpoutputs(noutput,batchsize,1),tploss
  integer :: it2

  if ( nkelvin > 0 ) then
     kelvinnvalid = 0d0; tpkelvinvec=0d0
  end if
  do idata = 1, batchsize
     tpinputs(:,idata,1) = deeptrajcoor(:,idata)
     if (nkelvin > 0) then
        batchtrajwgt(idata) = srvtrajwgt(idata)
        it2 = (idata-1)/srvkelvinndata + 1
        kelvinnvalid(it2) = kelvinnvalid(it2) + 1d0
     end if
  end do
  call mlp_network_forward(1,tpinputs,tpoutputs)
  tpoutputs0(:,1:batchsize) = tpoutputs(:,1:batchsize,1)

  do idata = 1, batchsize
     tpinputs(:,idata,1) = deeptrajcoor(:,idata+ntau)
  end do
  call mlp_network_forward(2,tpinputs,tpoutputs)
  tpoutputs1(:,1:batchsize) = tpoutputs(:,1:batchsize,1)

  if ( nkelvin == 0 ) then
     call srv_eigen_loss(batchsize, tpoutputs0, tpoutputs1, tploss)
  else
     call srv_eigen_loss(batchsize, tpoutputs0, tpoutputs1, tploss, tptrajwgt = batchtrajwgt)
  end if
  call srv_eigen_backward(tpoutputs0,tpoutputs1)

  h = 0.0001d0; maxerr = -1d0; maxnsteps = 1
  do ilayer = nlayer,2,-1
     do i = 1, mlplayers(ilayer)%neurons
        do j = 1, mlplayers(ilayer-1)%neurons
           call random_number(rand)
           !if ( rand < 1d0 - 1d0/dble(mlplayers(ilayer)%neurons) ) cycle 
           if ( rand < 1d0 - 1d0/dble(mlplayers(ilayer)%neurons)/10d0 ) cycle 
           originv = mlplayers(ilayer)%weights_l2l(i,j)
           mlplayers(ilayer)%weights_l2l(i,j) = originv + h; call get_loss(upv)
           mlplayers(ilayer)%weights_l2l(i,j) = originv - h; call get_loss(downv)
           tpgrad = (upv-downv)/(2d0*h)
           maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_weights_l2l(i,j)-tpgrad))
           print *,ilayer,i,j,abs(mlplayers(ilayer)%grad_weights_l2l(i,j)-tpgrad)
           mlplayers(ilayer)%weights_l2l(i,j) = originv
        end do
     end do

     do i = 1,mlplayers(ilayer)%neurons
        call random_number(rand)
        !if ( rand < 1d0 - 1d0/dble(mlplayers(ilayer)%neurons) ) cycle 
        if ( rand < 1d0 - 1d0/dble(mlplayers(ilayer)%neurons)/10d0 ) cycle 
        originv = mlplayers(ilayer)%bias(i)
        mlplayers(ilayer)%bias(i) = originv + h; call get_loss(upv)
        mlplayers(ilayer)%bias(i) = originv - h; call get_loss(downv)
        tpgrad = (upv-downv)/(2d0*h)
        maxerr = max(maxerr,abs(mlplayers(ilayer)%grad_bias(i)-tpgrad))
        print *,ilayer,i,abs(mlplayers(ilayer)%grad_bias(i)-tpgrad)
        mlplayers(ilayer)%bias(i) = originv
     end do
  end do
  ! If maxerr in output is -1d0, there must be some issues.
  write(6,'(a,f20.15)'),'SRV Network Gradient Error:',maxerr

contains

subroutine get_loss(tploss)
  real*8,intent(out) :: tploss
  integer :: it2

  do k = 1, batchsize
     tpinputs(:,k,1) = deeptrajcoor(:,k+ntau)
  end do
  call mlp_network_forward(2,tpinputs,tpoutputs)
  tpoutputs1(:,1:batchsize) = tpoutputs(:,1:batchsize,1)

  if ( nkelvin > 0 ) then
     kelvinnvalid = 0d0; tpkelvinvec=0d0
  end if
  do k = 1, batchsize
     tpinputs(:,k,1) = deeptrajcoor(:,k)
     if (nkelvin > 0) then
        batchtrajwgt(idata) = srvtrajwgt(idata)
        it2 = (idata-1)/srvkelvinndata + 1
        kelvinnvalid(it2) = kelvinnvalid(it2) + 1d0
     end if
  end do
  call mlp_network_forward(1,tpinputs,tpoutputs)
  tpoutputs0(:,1:batchsize) = tpoutputs(:,1:batchsize,1)

  if ( nkelvin == 0 ) then
     call srv_eigen_loss(batchsize, tpoutputs0, tpoutputs1, tploss)
  else
     call srv_eigen_loss(batchsize, tpoutputs0, tpoutputs1, tploss, tptrajwgt = batchtrajwgt)
  end if
end subroutine 
end subroutine

!============================= Other Subroutines (SRV) ================================

subroutine srv_normalfactor_forward(tpval,tpmin,tpmax,fixval)
  real*8,intent(inout) :: tpval
  real*8,intent(in) :: tpmin,tpmax
  real*8,intent(in),optional :: fixval

  if (present(fixval)) tpval = fixval
  if ( normalfactor /= 0d0 ) then
     if ( normalmode == 1 ) then
        tpval = normalfactor*( tpval - tpmin )/( tpmax - tpmin )
     else if ( normalmode == 2 ) then
        tpval = normalfactor*( 2d0*tpval - (tpmin+tpmax) )/( tpmax - tpmin )
     else
        tpval = tpval
     end if
  else
     tpval = tpval
  end if
end subroutine

subroutine srv_normalfactor_backward(tpval,tpmin,tpmax,fixval)
  real*8,intent(inout) :: tpval
  real*8,intent(in) :: tpmin,tpmax
  real*8,intent(in),optional :: fixval

  if (present(fixval)) tpval = fixval
  if ( normalmode == 1 ) then
     tpval = normalfactor*tpval/(tpmax - tpmin)
  else if ( normalmode == 2 ) then
     tpval = normalfactor*2d0*tpval/(tpmax - tpmin)
  else
     tpval = tpval
  end if
end subroutine

subroutine srv_network_save_append_srvinfo()
  integer :: iofile,i
  open(newunit=iofile,file=networkfile,action="write",access="append")
  write(iofile,"(a)") "srv average mode:"
  write(iofile,"(i8)") srvavgmode
  write(iofile,'(a)'),'gmean:'
  write(iofile,'(3000f15.8)') gmean
  write(iofile,'(a)'),'gbasis:'
  do i = 1,noutput
     write(iofile,'(3000f15.8)'),gbasis(i,:)
  end do
  write(iofile,'(a)'),'Lambda:'
  write(iofile,'(3000f15.8)'),lambda
  write(iofile,'(a)'),'Lag Time(ns):'
  write(iofile,'(3000f15.8)'),dble(ntau)*timestepsize
  write(iofile,'(a)'),'Implied Time Scale(ns):'
  write(iofile,'(3000f15.8)'),-dble(ntau)*timestepsize/log(lambda)
  close(iofile)
end subroutine

attributes(global) subroutine srv_batch_upload_hiddenstate(igroup)
  integer,intent(in),value :: igroup
  integer :: ipos,tarpos

  ipos = (blockidx%x-1)*32+threadidx%x; if (ipos > hiddenstate_index_d(nlayer_d+1)) return
  tarpos = (igroup-1)*hiddenstate_index_d(nlayer_d+1) + ipos
  batch_hiddenstate_d(tarpos) = hiddenstate_d(ipos)
end subroutine

attributes(global) subroutine srv_batch_upload_active(igroup)
  integer,intent(in),value :: igroup
  integer :: ipos,tarpos

  ipos = (blockidx%x-1)*32+threadidx%x; if (ipos > grad_active_index_d(nlayer_d+1)) return
  tarpos = (igroup-1)*grad_active_index_d(nlayer_d+1) + ipos
  batch_grad_active_d(tarpos) = grad_active_d(ipos)
end subroutine

attributes(global) subroutine srv_batch_download_hiddenstate(igroup)
  integer,intent(in),value :: igroup
  integer :: ipos,tarpos

  ! ipos > hidden(nlayer_d) have been written in delta.
  ipos = (blockidx%x-1)*32+threadidx%x; if (ipos > hiddenstate_index_d(nlayer_d)) return
  tarpos = (igroup-1)*hiddenstate_index_d(nlayer_d+1) + ipos
  hiddenstate_d(ipos) = batch_hiddenstate_d(tarpos)
end subroutine

attributes(global) subroutine srv_batch_download_active(igroup)
  integer,intent(in),value :: igroup
  integer :: ipos,tarpos

  ipos = (blockidx%x-1)*32+threadidx%x; if (ipos > grad_active_index_d(nlayer_d+1)) return
  tarpos = (igroup-1)*grad_active_index_d(nlayer_d+1) + ipos
  grad_active_d(ipos) = batch_grad_active_d(tarpos)
end subroutine

!=============================== load parm from network file ======================

subroutine srv_network_reload_parmint(tpparm,tpint)
  character(len=*),intent(in) :: tpparm
  integer,intent(out) :: tpint
  integer :: iofile,ierr
  character*100 :: tpstr
  logical :: ifhit

  ifhit = .false.
  open(newunit=iofile,file=networkfile,action="read")
  do
     read(iofile,"(a)",iostat=ierr) tpstr; if ( ierr < 0 ) exit
     if ( trim(tpstr) == trim(tpparm) ) then
        ifhit = .true.
        read(iofile,*) tpint; exit
     end if
  end do
  close(iofile)
  if ( ifhit .eqv. .false. ) then
     print "(a,a)","Can not find the parameter ",tpparm
  end if
end subroutine

subroutine srv_network_reload_parmreal(tpparm,tpreal)
  character(len=*),intent(in) :: tpparm
  real*8,intent(out) :: tpreal
  integer :: iofile,ierr
  character*100 :: tpstr
  logical :: ifhit

  ifhit = .false.
  open(newunit=iofile,file=networkfile,action="read")
  do
     read(iofile,"(a)",iostat=ierr) tpstr; if ( ierr < 0 ) exit
     if ( trim(tpstr) == trim(tpparm) ) then
        ifhit = .true.
        read(iofile,*) tpreal; exit
     end if
  end do
  close(iofile)
  if ( ifhit .eqv. .false. ) then
     print "(a,a)","Can not find the parameter ",tpparm
  end if
end subroutine

subroutine srv_network_reload_parmlogical(tpparm,tplogical)
  character(len=*),intent(in) :: tpparm
  logical,intent(out) :: tplogical
  integer :: iofile,ierr
  character*100 :: tpstr
  logical :: ifhit

  ifhit = .false.
  open(newunit=iofile,file=networkfile,action="read")
  do
     read(iofile,"(a)",iostat=ierr) tpstr; if ( ierr < 0 ) exit
     if ( trim(tpstr) == trim(tpparm) ) then
        ifhit = .true.
        read(iofile,*) tplogical; exit
     end if
  end do
  close(iofile)
  if ( ifhit .eqv. .false. ) then
     print "(a,a)","Can not find the parameter ",tpparm
  end if
end subroutine

subroutine srv_network_reload_parm1d(tpparm,tparray)
  character(len=*),intent(in) :: tpparm
  real*8,intent(out) :: tparray(:)
  integer :: iofile,ierr
  character*100 :: tpstr
  logical :: ifhit

  ifhit = .false.
  open(newunit=iofile,file=networkfile,action="read")
  do
     read(iofile,"(a)",iostat=ierr) tpstr; if ( ierr < 0 ) exit
     if ( trim(tpstr) == trim(tpparm) ) then
        ifhit = .true.
        read(iofile,'(*(f15.8))') tparray; exit
     end if
  end do
  close(iofile)
  if ( ifhit .eqv. .false. ) then
     print "(a,a)","Can not find the parameter ",tpparm
  end if
end subroutine

subroutine srv_network_reload_parm2d(tpparm,tparray)
  character(len=*),intent(in) :: tpparm
  real*8,intent(out) :: tparray(:,:)
  integer :: iofile,ierr,tpnline,i
  character*100 :: tpstr
  logical :: ifhit

  tpnline = size(tparray,1); ifhit = .false.
  open(newunit=iofile,file=networkfile,action="read")
  do
     read(iofile,"(a)",iostat=ierr) tpstr; if ( ierr < 0 ) exit
     if ( trim(tpstr) == trim(tpparm) ) then
        ifhit = .true.
        do i = 1, tpnline
           read(iofile,'(*(f15.8))') tparray(i,:)
        end do
        exit
     end if
  end do
  close(iofile)
  if ( ifhit .eqv. .false. ) then
     print "(a,a)","Can not find the parameter ",tpparm
  end if
end subroutine


end module
