module nma
   use ambertop; use normaldata; use pubmod, only : procid, procnum, ioptmethod
   use cudanma, only: frequencies; use mpi
   implicit none
   ! private; public :: nma_go
   
   real*8, parameter :: unitmatrix(3, 3) = &
                        reshape((/1d0, 0d0, 0d0, 0d0, 1d0, 0d0, 0d0, 0d0, 1d0/), (/3, 3/))
   real*8, dimension(:), allocatable :: hessianline

   interface nma_storehessian
      module procedure nma_storehessianij, nma_storehessiani
   end interface nma_storehessian

contains

   subroutine nma_initialize(parmfile, ninframe, ientropy)
      use ambertop, only: nowcoor, nowforce, igb, discut, saltcon, mass, ambertop_readtopfile, resindex, molindex
      use cudanma, only: massinv, frequencies, cudanma_initialize, cudanma_gpuinfo
      use gb, only: gb_initialize
      use pubmod, only: errormsg, pubmod_get_resindex_resmass_rescharge, procid
      use struct
      implicit none
      character(len=*), intent(in), optional :: parmfile
      integer, intent(in), optional :: ninframe, ientropy

      real*8, dimension(:, :), allocatable :: tpcoor
      integer :: system, iofile, ierr, ifile, npro, nfra, sharedwin
      
      namelist /nma/ topfile, trajfiles, crdfile, molarray, discut, igb, igbsa, saltcon, neigens, skipinitdata, &
          skipdata, icuda, temperature, imin, freqcut, ioptmethod
      
      namelist /qha/ topfile, trajfiles, neigens, molarray, temperature, imin, freqcut

      if (present(parmfile)) then
         ! Default parameters
         topfile = "";  trajfiles = ""; crdfile = ""; igb = 0; igbsa = 0; saltcon = 0.0d0
         ishake = 0; igbsa = 0; respastep = 1; ifblocksum = .true.; imin = 1; molarray = 0
         discut = 12.0d0; neigens = 0; skipinitdata = 0; skipdata = 0; icuda = 0
         temperature = 298.15d0; ioptmethod = 1; freqcut = 1d-4

         open (NewUnit=iofile, file=parmfile)
            if (casemode == 1) then
               read (iofile, nml=nma, iostat=ierr)
               if (ierr /= 0) call errormsg("Cannot find the nma namelist")
            else if (casemode == 2) then
               read (iofile, nml=qha, iostat=ierr)
               if (ierr /= 0) call errormsg("Cannot find the qha namelist")
            end if
         close (iofile)
         
         call checkfile(topfile)
         call ambertop_readtopfile(trim(topfile))
         if ( ipb > 0 ) call errormsg("Topology file should not contain waters and periodic box information!")
         call pubmod_get_resindex_resmass_rescharge()
         allocate (nowcoor(3, natom), nowforce(3, natom)); nowcoor = 0.0d0; nowforce = 0.0d0
         
         if ( procid == 0 ) then
            print "(/,20x,a,/)","Performing normal mode analysis"
            if (icuda > 0) call cudanma_gpuinfo()
            print "(a,T28,a2,a)", "Control file",": ", trim(parmfile)
            print "(a,T28,a2,a)", "Topology file",": ", trim(topfile)
            if (crdfile /= '') print "(a,T28,a2,a)", "Coordinate file",": ", trim(crdfile)
            do ifile = 1, size(trajfiles)
               if (trajfiles(ifile) == "" .or. crdfile /= '') exit
               print "(a,T28,a2,a)",   'Trajectory file',": ", trim(trajfiles(ifile))
            end do
            print '(a, T28, a2, f0.2)', 'Temperatrue (K)',': ', temperature
            print '(a, T28, a2, f0.2)', 'Distance cutoff (Ang)',': ', discut
            print '(a, T28, a2, f0.5)', 'Frequency cutoff (cm^-1)',': ', freqcut
         end if
         call nma_calmolarray()
         !!! for mpi 
         if ( procid == 0 ) then
            if (crdfile == '' .and. casemode == 1)  then 
               call nma_get_ncalframe()
            else 
               ncalframe = 1
            end if
            if (ncalframe < 1) stop 'error ncalframe'
         end if
         call mpi_bcast(ncalframe,1,mpi_integer,0, mpi_comm_world,ierr)

      end if

      if (present(ninframe)) ncalframe = ninframe
      if (present(ientropy)) casemode = ientropy
      ! npro=1 => complex, npro=2 => receptor, npro=3 => ligand, npro=4 => delta = complex - receptor - ligand
      ! ncalframe + 1 = averge of all calculated frames
      ! ncalframe + 2 = standard deviation of all calculated frames
      npro = 4; nfra = ncalframe + 2
      call MPISharedMemoryAllocate(sharedwin, dimreal2d=[npro,nfra], sharereal2d=S_tra)
      call MPISharedMemoryAllocate(sharedwin, dimreal2d=[npro,nfra], sharereal2d=S_rot)
      call MPISharedMemoryAllocate(sharedwin, dimreal2d=[npro,nfra], sharereal2d=S_vib)
      call MPISharedMemoryAllocate(sharedwin, dimreal2d=[npro,nfra], sharereal2d=S_tot)
      call MPISharedMemoryAllocate(sharedwin, dimint2d=[2,nfra], shareint2d=frame_location)
      S_tra = 0.0d0; S_rot = 0.0d0; S_vib = 0.0d0; S_tot = 0.0d0; frame_location = 0

      ndegree = 3*natom; nhessian = ndegree*(ndegree + 1)/2
      ndegreemol = 3*natom
      if ( ndegree < 3) stop 'error ndegree'

      if (igb == 0) saltcon = 0.0d0
      if (neigens > 0) then
         allocate (eigenvalues(neigens), eigenvectors(ndegree, neigens))
         if ( procid == 0 ) then
            ierr = system("rm -rf eigens"); ierr = system("mkdir eigens")
         end if
      end if

      allocate (frequencies(ndegree))
      allocate (massinv(natom), hessianline(nhessian))
      allocate (entropy_svibn(ndegree))
      massinv(:) = 1d0/sqrt(mass(:)); hessianline = 0d0

      call struct_initialize()

      if ( procid == 0 ) print *
      if (icuda /= 0 .and. casemode == 1) call cudanma_Initialize()

   end subroutine nma_initialize

   subroutine nma_calmolarray()
      use pubmod, only : procid,errormsg
      integer :: imol, irec, ilig, icom, iflag

      if (any(molarray > nmol) .or. any(molarray < 0)) stop "Incorrect molecule index!"

      if ( nmol > 20 ) call errormsg("Molecule number should not be larger than 20! ",int1=nmol)
      if ( sum(molarray) == 0 ) then
         molarray(1:nmol) = [(imol, imol=1,nmol)]
      end if

      icom = 0; irec = 0; ilig = 0; iflag = 1
      do imol = 1, size(molarray)
         if (molarray(imol) /= 0) icom = icom + 1
         if (molarray(imol) /= 0 .and. iflag == 1) irec = irec + 1
         if (molarray(imol) /= 0 .and. iflag == 2) ilig = ilig + 1
         
         if (molarray(imol) /= 0 .and. molarray(imol + 1) == 0) iflag = 2
      end do
      if (irec + ilig /= icom) stop 'irec + ilig /= icom'
      allocate(commolarray(icom), recmolarray(irec), ligmolarray(ilig), molrange(2, nmol))
      commolarray = 0; recmolarray = 0; ligmolarray = 0; molrange = 0
      icom = 0; irec = 0; ilig = 0; iflag = 1
      do imol = 1, size(molarray)

         if (molarray(imol) /= 0 .and. iflag == 1) then
            icom = icom + 1; commolarray(icom) = molarray(imol)
            irec = irec + 1; recmolarray(irec) = molarray(imol)
         else if (molarray(imol) /= 0 .and. iflag == 2) then
            icom = icom + 1; commolarray(icom) = molarray(imol)
            ilig = ilig + 1; ligmolarray(ilig) = molarray(imol)
         end if
         
         if (molarray(imol) /= 0 .and. molarray(imol + 1) == 0) iflag = 2
      end do

      do imol = 1, nmol
         molrange(1, imol) = resindex(molindex(imol) + 1) + 1
         molrange(2, imol) = resindex(molindex(imol + 1) + 1)
      end do

      if (sum(ligmolarray) == 0) recmolarray = 0

      if ( procid > 0 ) return

      print '(/,a,/)', 'Selected molecules and atom ranges'
      do imol = 1, nmol
         print '(5x, a, I4, a, 2I8)', 'molecule ',imol,'   atom range ', molrange(:, imol)
      end do

      if (sum(commolarray) /= 0) print '(/,a, *(I4))', 'Complex molecules    : ', commolarray
      if (sum(recmolarray) /= 0) print '(a, *(I4))', 'Receptor molecules   : ', recmolarray
      if (sum(ligmolarray) /= 0) print '(a, *(I4))', 'Ligand molecules     : ', ligmolarray

   end subroutine nma_calmolarray

   subroutine nma_get_ncalframe()
      use pubmod, only : pubmod_read_traj
      integer :: itraj, ierr, isnap
      ncalframe = 0
      do itraj = 1, size(trajfiles)
         if (trajfiles(itraj) == "") exit
         ierr = 1; isnap = 0
         do while (.true.)
            
            call pubmod_read_traj(trajfiles(itraj), natom, nowcoor, ierr)
            if (ierr < 0) exit

            isnap = isnap + 1
            if ( isnap <= skipinitdata ) cycle
            if ( skipdata > 0 .and. mod(isnap-skipinitdata,skipdata+1) /= 1 ) cycle
            ncalframe = ncalframe + 1

         end do
      end do

   end subroutine nma_get_ncalframe

   subroutine nma_finish(parmfile)
      use ambertop, only: nowcoor
      use cudanma, only: massinv, frequencies, cudanma_finish
      implicit none
      character(len=*), intent(in), optional :: parmfile

      if (present(parmfile)) then
         deallocate (nowcoor, nowforce)
      end if

      if ( neigens > 0 ) deallocate (eigenvalues, eigenvectors)
      deallocate (frequencies, entropy_svibn, massinv, hessianline)
      deallocate (commolarray, recmolarray, ligmolarray, molrange)
      if (icuda /= 0) call cudanma_finish()
   end subroutine nma_finish

   subroutine nma_go(parmfile)
      use mpi
      use pubmod, only : pubmod_read_traj, pubmod_read_crdfile, errormsg
      implicit none
      character(len=*), intent(in) :: parmfile
      integer :: itraj, ierr, iframe, isnap
      real*8, dimension(:, :), allocatable :: tpcoor

      call time_from_1970(time_start); call date_and_time(DATE=dateinfo1, TIME=timeinfo1)
      call nma_initialize(parmfile)
      
      allocate (tpcoor(3, natom)); tpcoor = 0d0
      isnap = 0; iframe = 0

      if ( crdfile /= '' ) then

         call pubmod_read_crdfile(crdfile, tpcoor)
         call nma_entropy_calculation(tpcoor, 1, 1, 1)

      else if ( crdfile == '' ) then

         ! cycle over the trajectory files
         do itraj = 1, size(trajfiles)
            if (trim(trajfiles(itraj)) == "") exit
            isnap = 0
            do while (.true.)
               call pubmod_read_traj(trajfiles(itraj), natom, tpcoor, ierr)
               if (ierr < 0) exit
               isnap = isnap + 1
               if ( isnap <= skipinitdata ) cycle
               if ( skipdata > 0 .and. mod(isnap-skipinitdata,skipdata+1) /= 1 ) cycle

               iframe = iframe + 1
               if (mod(iframe - 1, procnum) == procid) then
                  frame_location(:, iframe) = [itraj, isnap]
                  call nma_entropy_calculation(tpcoor, iframe, itraj, isnap)
               end if

            end do
         end do

      else

         call errormsg("no available coordinate file")

      end if

      call mpi_barrier(mpi_comm_world, ierr); if ( procid > 0 ) return
      call date_and_time(DATE=dateinfo2, TIME=timeinfo2); call time_from_1970(time_stop)

      call vector_averstddev(S_tra)
      call vector_averstddev(S_rot)
      call vector_averstddev(S_vib)
      call vector_averstddev(S_tot)

      call nma_print_entropy(nmaoutfile)
      call nma_print_totalentropy(nmaoutfile); call nma_print_totalentropy(6)
      call nma_print_time_info(nmaoutfile); call nma_print_time_info(6)

      ! call nma_print_eigens()

      call nma_finish(parmfile); deallocate(tpcoor)
   
   contains 

      subroutine vector_averstddev(vector2d)
         real*8, intent(inout) :: vector2d(:,:)
         integer :: i, j
         real*8 :: tpsum

         vector2d(:, ncalframe + 1) = sum(vector2d(:, 1:ncalframe), dim = 2)/ncalframe
         do j = 1, size(vector2d, dim = 1)
            tpsum = 0.0d0
            do i = 1, ncalframe
               tpsum = tpsum + (vector2d(j,i) - vector2d(j, ncalframe + 1))**2.0
            end do
            vector2d(j, ncalframe + 2) = sqrt(tpsum/ncalframe)
         end do

      end subroutine vector_averstddev

   end subroutine nma_go

   subroutine nma_entropy_calculation(tpcoor, iframe, itraj, isnap)
      real*8, intent(in) :: tpcoor(3,natom)
      integer, intent(in) :: iframe, itraj, isnap

      if (procid == 0) print "(/a,I4)", 'Doing calculation on frame : ', iframe

      if (sum(commolarray) /= 0) then
         nowcoor = tpcoor
         call normaldata_setmolarray(commolarray, .true.)
         call nma_calculation(tpmolarray=commolarray)
         call normaldata_setmolarray(commolarray, .false.)
         S_tra(1, iframe) = entropy_stra; S_rot(1, iframe) = entropy_srot; S_vib(1, iframe) = entropy_svib
         S_tot(1, iframe) = S_tra(1, iframe) + S_rot(1, iframe) + S_vib(1, iframe)
         if (neigens > 0) call normaldata_write_eigendata(isnap, itraj, freq=frequencies, istart=freqstart)
      end if
      
      if (sum(recmolarray) /= 0) then
         nowcoor = tpcoor
         call normaldata_setmolarray(recmolarray, .true.)
         call nma_calculation(tpmolarray=recmolarray)
         call normaldata_setmolarray(recmolarray, .false.)
         S_tra(2, iframe) = entropy_stra; S_rot(2, iframe) = entropy_srot; S_vib(2, iframe) = entropy_svib
         S_tot(2, iframe) = S_tra(2, iframe) + S_rot(2, iframe) + S_vib(2, iframe)
      end if

      if (sum(ligmolarray) /= 0) then
         nowcoor = tpcoor
         call normaldata_setmolarray(ligmolarray, .true.)
         call nma_calculation(tpmolarray=ligmolarray)
         call normaldata_setmolarray(ligmolarray, .false.)
         S_tra(3, iframe) = entropy_stra; S_rot(3, iframe) = entropy_srot; S_vib(3, iframe) = entropy_svib
         S_tot(3, iframe) = S_tra(3, iframe) + S_rot(3, iframe) + S_vib(3, iframe)
      end if

      ! calculate the delta entropy
      S_tra(4, iframe) = S_tra(1, iframe) - S_tra(2, iframe) - S_tra(3, iframe)
      S_rot(4, iframe) = S_rot(1, iframe) - S_rot(2, iframe) - S_rot(3, iframe)
      S_vib(4, iframe) = S_vib(1, iframe) - S_vib(2, iframe) - S_vib(3, iframe)
      S_tot(4, iframe) = S_tot(1, iframe) - S_tot(2, iframe) - S_tot(3, iframe)

   end subroutine nma_entropy_calculation

   subroutine nma_calculation(tpmolarray)
      use struct, only : struct_minimize, struct_potforce_cpu, struct_potforce_gpu
      use cudanma, only : cudanma_calvibmode, hessianline_d, bondatom_d, angleatom_d, &
                         diheatom_d, nonbond14_d, nowcoor_d, charge_d, radius_d, vdweps_d
      use cudafor
      integer, intent(in) :: tpmolarray(:)
      integer :: istart, iend, imol, ibond, iangle, idihe, iatom
      integer :: tpbondatom(3*nbond), tpangleatom(4*nangle), tpdiheatom(5*ndihedral), tpnonbond14(3,nnb14)
      real*8 :: tprad(natom), tpcharge(natom), tpvdweps(natom)
      integer :: tpbond(nbond*3), istat

      ndegree = 0
      do imol = 1, size(tpmolarray)
         if (tpmolarray(imol) /= 0) ndegree = ndegree + &
                              molrange(2, tpmolarray(imol)) - molrange(1, tpmolarray(imol)) + 1
      end do
      ndegree = ndegree*3; nhessian = ndegree*(ndegree + 1)/2

      if ( procid == 0) print "(a)", 'Optimizing structure'
      call struct_minimize(1000, 500, 0.0001d0, 200)

      ! call nma_check_hessian(tpmolarray)

      istat = cudaDeviceSynchronize()
      if ( procid == 0) print "(a)", 'Building Hessian matrix'
      if (icuda == 0) then
         call nma_calvibmode(tpmolarray)
      else
         call cudanma_calvibmode(tpmolarray)
      end if
      ! if ( procid == 0 ) print "(a, I6)", 'Vibrational modes start from :', freqstart
      if ( procid == 0 ) print "(a, 2I6)", 'Vibrational modes range :', freqstart, ndegree
      ! calculate vibrational entropy of molecule
      call nma_entropy(tpmolarray)

      ! --- Translational entropy calculation
      call nma_traentropy(tpmolarray)
      ! --- Rotational entropy calculation
      call nma_rotentropy(tpmolarray)
      call nma_unit_conversion()

   end subroutine nma_calculation

   subroutine nma_check_hessian(tpmolarray)
      use cudatop, only : nowcoor_d
      use cudanma, only : hessianline_d, cudanma_calvibmode
      use gb, only : gb_potforce
      integer, intent(in) :: tpmolarray(:)
      real*8 :: error, tphessianline(size(hessianline)),stepsize,maxerror
      real*8 :: tppot0,tpgrad1,tpgrad2,tpdev, tpicoor, tpjcoor
      real*8 :: tphessian(ndegree, ndegree)
      integer :: i, j, iline, ii, jj, icoor, jcoor, maxi, maxj, iofile, lo1, lo2
      real*8 :: tppot1, tppot2, tppot3, tppot4, perror, maxperror, hsq4

      print "(a)","Begin to check the calculation error of the Hessian matrix"
      hessianline = 0.0d0
      call nma_matrix_elecvdw(nowcoor)
      call nma_matrix_bond(nowcoor)
      call nma_matrix_angle(nowcoor)
      call nma_matrix_dihedral(nowcoor)
      call nma_matrix_elecvdw14(nowcoor)
      if (igb /= 0) call nma_matrix_GB(nowcoor)

      !!! check 1
      print*, 'check1'
      call normaldata_hessian_1d_2d(hessianline, tphessian)
      maxerror = 0d0
      do i = 1, ndegree
         error = sum(tphessian(i, :))
         if (abs(error) > abs(maxerror)) then
            maxerror = error; maxi = i
         end if
         print*, i, error
      end do
      print *, "Max hessian matrix row error is ", maxerror
      print *, "Max hessian matrix row error location ", maxi
      print *

      !!! check 2
      print*, 'check2'
      maxerror = 0d0; maxperror = 0d0; stepsize = 0.0001d0; hsq4 = 4d0*stepsize*stepsize
      do i = 1, 3*natom
         ii = (i-1)/3+1; if (radius(ii) == 0.0d0) cycle

         do j = 1, i
            jj = (j-1)/3+1;; if (radius(jj) == 0.0d0) cycle

            icoor = mod(i, 3); jcoor = mod(j, 3)
            if (icoor == 0) icoor = 3; if (jcoor == 0) jcoor = 3

            tpicoor = nowcoor(icoor, ii)
            tpjcoor = nowcoor(jcoor, jj)
            if ( i == j) then
               call gb_potforce(nowcoor, tppot0)      ! E(0,0)
               nowcoor(icoor, ii) = tpicoor + 2d0*stepsize
               call gb_potforce(nowcoor, tppot1)      ! E(+,0)
               nowcoor(icoor, ii) = tpicoor - 2d0*stepsize
               call gb_potforce(nowcoor, tppot2)      ! E(-,0)
               tpdev = (tppot1+tppot2-2d0*tppot0)/hsq4
            else

               nowcoor(icoor, ii) = tpicoor - stepsize
               nowcoor(jcoor, jj) = tpjcoor - stepsize
               call gb_potforce(nowcoor, tppot1)      ! E(-,-)

               nowcoor(jcoor, jj) = tpjcoor + stepsize
               call gb_potforce(nowcoor, tppot2)      ! E(-,+)

               nowcoor(icoor, ii) = tpicoor + stepsize
               call gb_potforce(nowcoor, tppot3)      ! E(+,+)

               nowcoor(jcoor, jj) = tpjcoor - stepsize
               call gb_potforce(nowcoor, tppot4)      ! E(+,-)
               tpdev = (tppot1+tppot3-tppot2-tppot4)/hsq4
            end if

            nowcoor(icoor, ii) = tpicoor
            nowcoor(jcoor, jj) = tpjcoor

            error = tpdev - hessianline(i*(i-1)/2+j); perror = abs(error/hessianline(i*(i-1)/2+j))

            if (abs(error) > 1d-3 .or. abs(perror) > 5d-2 .or. tpdev == 0d0) then
               print "(2I6, 4e20.10)", i, j, tpdev, hessianline(i*(i-1)/2+j), error, perror
            end if 
            if (abs(error) > abs(maxerror)) then
               maxerror = error; maxi = i; maxj = j
            end if

            if (abs(perror) > abs(maxperror) .and. tpdev > 0.1) then
               maxperror = perror; lo1 = i; lo2 = j
            end if
         end do

      end do

      print "(a,2e20.10)", "Max analytical-Numerical error is ", maxerror, maxperror
      print "(a,4I6)", "Max analytical-Numerical error location ", maxi, maxj, lo1, lo2
      print *

      !!! check 3
      if (icuda == 0) stop 'skip CPU-GPU check'
      print*, 'check3'
      nowcoor = nowcoor_d
      call nma_calvibmode(tpmolarray)
      call cudanma_calvibmode(tpmolarray); tphessianline = hessianline_d
      tphessianline = tphessianline - hessianline

      print *,"CPU-GPU error is ", maxval(tphessianline), maxloc(tphessianline)

      stop
   end subroutine nma_check_hessian

   ! build hessian matrix and calculate the vibrational modes
   subroutine nma_calvibmode(tpmolarray)
      use ambertop, only: nowcoor, igb
      implicit none
      integer, intent(in) :: tpmolarray(:)
      integer :: i, j1, j2, iofile

      hessianline = 0.0d0
      call nma_matrix_elecvdw(nowcoor)
      call nma_matrix_bond(nowcoor)
      call nma_matrix_angle(nowcoor)
      call nma_matrix_dihedral(nowcoor)
      call nma_matrix_elecvdw14(nowcoor)
      ! hessian matrix for Generalized Born energy
      if (igb /= 0) call nma_matrix_GB(nowcoor)
      ! mass weighted for hessian matrix
      call nma_massweighted()

      ! print triangular Hessian matrix
      ! open(NewUnit=iofile, file='hessian.dat')
      !   do i = 1, ndegree
      !      j1 = i*(i - 1)/2 + 1; j2 = i*(i + 1)/2
      !      write(iofile, '(*(f15.7))') hessianline(j1:j2)
      !   end do 
      ! close(iofile)

      call nma_geteigenvalues(tpmolarray)
   end subroutine nma_calvibmode

   subroutine nma_geteigenvalues(tpmolarray)
      use pubmod, only : errormsg, procid
      integer, intent(in) :: tpmolarray(:)

      integer :: i, j, k, iline, ihessian, lindex, uindex, imol, ieigen, tpstart, tpend
      real*8 :: tphessianline(nhessian), tphessian(ndegree, ndegree)
      logical :: iin, jin
      ! varibles for dspevd function
      integer :: N, liwork, lwork, LDZ, info
      integer, allocatable :: iwork(:)
      real*8, allocatable :: Z(:, :), work(:)
      character(len=1) :: JOBZ, UPLO

      N = ndegree; LDZ = ndegree; JOBZ = 'V'; UPLO = 'U'
      lwork = 2*N*N + 6*N + 1; liwork = 3 + 5*N
      allocate (Z(N, N), work(lwork), iwork(liwork))
      if ( procid == 0) print "(a)", 'Calculating eigenvalues of Hessian matrix on CPU'

      ! remove redundant elements for non-sysmetric eigen solver
      if ( .false. ) then
         tphessianline = 0.0d0
         iline = 0
         do i = 1, 3*natom; do j = 1, i
            iin = .false.; jin = .false.
            do k = 1, size(tpmolarray)
               imol = tpmolarray(k)
               if (imol == 0) cycle
               lindex = 3*molrange(1, imol) - 2; uindex = 3*molrange(2, imol)
               if (i >= lindex .and. i <= uindex) iin = .true.
   
               if (j >= lindex .and. j <= uindex) jin = .true.
   
               if (iin .and. jin) then
                  ihessian = (i - 1)*i/2 + j; iline = iline + 1
                  tphessianline(iline) = hessianline(ihessian)
                  exit
               end if
            end do
         end do; end do
         if (iline /= nhessian) stop 'error index of hessian matrix'
         call dspevd(JOBZ, UPLO, N, tphessianline, frequencies, Z, LDZ, work, lwork, iwork, liwork, info)
         if (info /= 0) call errormsg('dspevd info', int1=info)
         call normaldata_unit_conversion(tpmolarray, Z)
      end if 

      ! prepare for sysmetric eigen solver
      call normaldata_hessian_1d_2d(hessianline, tphessian)
      call dsyevd(JOBZ, UPLO, ndegree, tphessian, ndegree, frequencies, work, lwork, iwork, liwork, info)
      if (info /= 0) call errormsg('dsyevd info', int1=info)
      call normaldata_unit_conversion(tpmolarray, tphessian)

      deallocate (Z, work, iwork)

   end subroutine nma_geteigenvalues

   subroutine nma_matrix_elecvdw(tpcoor)
      use ambertop, only: nexcludedatoms, excludedatomlist, surften
      use ambertop, only: typeindex, nonbondedparmindex, discut
      use ambertop, only: nvdwtype, vdwacoef, vdwbcoef, charge
      use parmdata, only: gb1sigma, gb1epsilon, gb1cutoff, gb1c1, gb1c2
      implicit none
      real*8, intent(in) :: tpcoor(3, natom)
      integer :: i, j, k, itype, vdwindex, lastiexc, tpnexc
      real*8 :: dedr, d2edr2, dij2, dij2inv, dij6inv, vdwa, vdwb, vdwscale
      real*8 :: qi, qj, elec, coori(3), rij(3), tpmatrix(3, 3)
      logical :: ifskipatoms(0:natom)
      real*8 :: cutoff, sigma, epsilon, dis, coef1, coef2, coef3, tpa, tpb

      lastiexc = 0
      do i = 1, natom - 1
         ifskipatoms(i + 1:natom) = .false.; tpnexc = nexcludedatoms(i)
         ifskipatoms(excludedatomlist(lastiexc + 1:lastiexc + tpnexc)) = .true.; lastiexc = lastiexc + tpnexc

         qi = charge(i); if ( qi == 0.0d0 ) cycle
         itype = typeindex(i); coori(1:3) = tpcoor(1:3, i)

         do j = i + 1, natom
            if (ifskipatoms(j) .eqv. .true.) cycle

            qj = charge(j); if ( qj == 0.0d0 ) cycle

            rij(1:3) = coori(1:3) - tpcoor(1:3, j); dij2 = dot_product(rij, rij)

            if (dij2 > discut**2) cycle; dij2inv = 1d0/dij2

            elec = qi*charge(j)*sqrt(dij2inv)
            vdwindex = nonbondedparmindex(nvdwtype*(itype - 1) + typeindex(j))
            dij6inv = dij2inv**3; vdwscale = 6d0*dij6inv
            vdwa = vdwacoef(vdwindex)*vdwscale*dij6inv
            vdwb = vdwbcoef(vdwindex)*vdwscale
            ! dedr = de/dr * dijinv
            dedr = -(elec + 2d0*vdwa - vdwb)*dij2inv
            d2edr2 = (2d0*elec + 26d0*vdwa - 7d0*vdwb)*dij2inv

            if ( igb == 1 .and. igbsa == 1 ) then 
               if ( (gb1sigma(i) /= 0d0) .and. (gb1sigma(j) /= 0d0) ) then
                  cutoff = gb1cutoff(i)+gb1cutoff(j); dis = sqrt(dij2)
                  if (dis < cutoff) then
                     sigma = gb1sigma(i)+gb1sigma(j)
                     epsilon = sqrt(gb1epsilon(i)*gb1epsilon(j))
                     coef3 = 1d0+(cutoff-dis)/sigma
                     coef1=coef3**2; coef2=coef1**2; coef1=(coef2**2)*coef1
                     tpa = gb1c1/coef1; tpb = gb1c2/coef2
                     dedr = dedr - 1.2d0*surften*epsilon*(10d0*tpa-4d0*tpb)/(sigma*coef3*dis)
                     d2edr2 = d2edr2 -1.2d0*surften*epsilon*(10d0*11d0*tpa-4d0*5d0*tpb)/(sigma*sigma*coef3*coef3)
                  end if 
               end if
            end if 
            d2edr2 = (d2edr2 - dedr)*dij2inv

            do k = 1, 3
               tpmatrix(:, k) = d2edr2*rij(:)*rij(k)
               tpmatrix(k, k) = tpmatrix(k, k) + dedr
            end do

            call nma_storehessian(i, tpmatrix)
            call nma_storehessian(j, tpmatrix)
            call nma_storehessian(i, j, -tpmatrix)
         end do

      end do
   end subroutine nma_matrix_elecvdw

   subroutine nma_matrix_bond(tpcoor)
      use ambertop, only: nbond, bondatom, bondeqval, bondforceconst
      implicit none
      real*8, intent(in) :: tpcoor(3, natom)

      integer :: i, j, k, itype, ibond
      real*8 :: dedr, d2edr2, dij2inv, rij(3), tpmatrix(3, 3)
      integer :: iloop

      ! print*, hessianline(21)
      do ibond = 1, nbond

         itype = bondatom(3*ibond); if ( itype == 0 ) cycle
         i = bondatom(3*ibond - 2); j = bondatom(3*ibond - 1)
         rij(1:3) = tpcoor(1:3, i) - tpcoor(1:3, j); dij2inv = 1d0/dot_product(rij, rij)
         d2edr2 = 2d0*bondforceconst(itype)
         ! dedr = de/dr * dijinv (dijinv : 1/r) and de/dr = d2edr2*(dij - tpeqval)
         dedr = d2edr2*(1d0 - bondeqval(itype)*sqrt(dij2inv))

         d2edr2 = (d2edr2 - dedr)*dij2inv

         ! nabla_ii = [(d2e/dr2-de/dr*dijinv)*(rij)*(rij^T)*dij2inv + de/dr*dijinv*unitmatrix]
         ! dgemm : matrix multiplication, C = alpha*A*B + beta*C
         ! (alpha: d2edr2, A: rij, B: rij, beta: 1d0, C: tpmatrix)
         ! call dgemm('N', 'N', 3, 3, 1, d2edr2, rij, 3, rij, 1, 1d0, tpmatrix, 3)

         do k = 1, 3
            tpmatrix(:, k) = d2edr2*rij(:)*rij(k)
            tpmatrix(k, k) = tpmatrix(k, k) + dedr
         end do
         ! save local hessian matrix to global hessian matrix
         call nma_storehessian(i, tpmatrix)     ! i-i diagonal element
         call nma_storehessian(j, tpmatrix)     ! j-j diagonal element
         call nma_storehessian(i, j, -tpmatrix) ! i-j off-diagonal element

      end do

   end subroutine nma_matrix_bond

   subroutine nma_matrix_angle(tpcoor)
      use ambertop, only: nangle, angleatom, angleeqval, angleforceconst
      implicit none
      real*8, intent(in) :: tpcoor(3, natom)

      integer :: i, j, k, itype, iangle, tpindex
      real*8 :: tptheta, tpdelta, tpfactor, tpk, tpeqval, dedcos, d2edcos2
      real*8 :: dij2inv, dkj2inv, dijinv, dkjinv, dijdkjinv, sintheta, costheta
      real*8, dimension(3) :: rij, rkj, nablaicos, nablakcos
      real*8, dimension(3, 3) :: rijrij, rkjrkj, rkjrij, tpmatrix
      real*8, dimension(3, 3) :: nablaii, nablakk, nablaik

      do iangle = 1, nangle

         itype = angleatom(4*iangle); if ( itype == 0 ) cycle
         i = angleatom(4*iangle - 3); j = angleatom(4*iangle - 2); k = angleatom(4*iangle - 1)
         tpk = angleforceconst(itype); tpeqval = angleeqval(itype)

         rij(1:3) = tpcoor(1:3, i) - tpcoor(1:3, j); dij2inv = 1d0/dot_product(rij, rij)
         rkj(1:3) = tpcoor(1:3, k) - tpcoor(1:3, j); dkj2inv = 1d0/dot_product(rkj, rkj)
         dijinv = sqrt(dij2inv); dkjinv = sqrt(dkj2inv)
         dijdkjinv = dijinv*dkjinv; costheta = dot_product(rij, rkj)*dijdkjinv
         costheta = min(1d0, max(-1d0, costheta)); sintheta = sqrt(1d0 - costheta**2)
         tptheta = acos(costheta); tpdelta = tptheta - tpeqval; tpfactor = 2d0*tpk/sintheta
         dedcos = -tpfactor*tpdelta; d2edcos2 = tpfactor*(sintheta - tpdelta*costheta)/sintheta**2

         do tpindex = 1, 3
            rijrij(:, tpindex) = dij2inv*rij(tpindex)*rij(:)
            rkjrkj(:, tpindex) = dkj2inv*rkj(tpindex)*rkj(:)
            rkjrij(:, tpindex) = dijdkjinv*rij(tpindex)*rkj(:)
         end do

         tpmatrix = rkjrij + transpose(rkjrij)
         nablaicos = (rkj*dkjinv - costheta*rij*dijinv)*dijinv
         nablakcos = (rij*dijinv - costheta*rkj*dkjinv)*dkjinv

         ! nablaii : grad_i(grad_i(cos(theta)))
         nablaii = -(tpmatrix + costheta*unitmatrix - 3*costheta*rijrij)*dij2inv
         ! nablakk : grad_k(grad_k(cos(theta)))
         nablakk = -(tpmatrix + costheta*unitmatrix - 3*costheta*rkjrkj)*dkj2inv
         ! nablaik = grad_k(grad_i(cos(theta)))
         nablaik = -(rkjrkj + rijrij - costheta*rkjrij - unitmatrix)*dijdkjinv

         ! hessian matrix related to atom i, k, Hii,Hik,Hkk (because of symmetry, Hki is not necessary)
         do tpindex = 1, 3
            nablaii(:, tpindex) = d2edcos2*nablaicos(tpindex)*nablaicos(:) + dedcos*nablaii(:,tpindex)
            nablakk(:, tpindex) = d2edcos2*nablakcos(tpindex)*nablakcos(:) + dedcos*nablakk(:,tpindex)
            nablaik(:, tpindex) = d2edcos2*nablaicos(tpindex)*nablakcos(:) + dedcos*nablaik(:,tpindex)
         end do

         ! grad_j(grad_j(E))  (note that nablaii is overlapped by elements in hessian matrix)
         ! grad_j = - (grad_i + grad_k)
         tpmatrix = nablaii + nablakk + nablaik + transpose(nablaik)

         ! save local hessian matrix Hii, Hkk, Hik to global
         call nma_storehessian(i, nablaii); call nma_storehessian(k, nablakk)
         call nma_storehessian(i, k, nablaik)
         ! save local hessian matrix Hjj, Hij, Hjk to global
         call nma_storehessian(j, tpmatrix)
         tpmatrix = -(nablaii + nablaik); call nma_storehessian(i, j, tpmatrix)
         tpmatrix = -(nablakk + nablaik); call nma_storehessian(j, k, tpmatrix)
      end do
   end subroutine nma_matrix_angle

   subroutine nma_matrix_dihedral(tpcoor)
      use ambertop, only: ndihedral, diheatom, dihephase, diheperiod, diheforceconst, ndihegroup
      implicit none
      real*8, intent(in) :: tpcoor(3, natom)

      integer :: i, j, k, l, idihe, itype, tpindex, idihegroup
      real*8 :: tpn, tpphase, tpcoeff, dedphi, d2edphi2, phi
      real*8 :: dkj, dkj2, dkj2inv, tlen2inv, ulen2inv, rijrkj, rlkrkj
      real*8, dimension(3, 3) :: nablaij, nablaik, nablalj, nablalk, nablakj
      real*8, dimension(3, 3) :: nablaii, nablajj, nablakk, nablall, tpmatrix
      real*8, dimension(3) :: rij, rkj, rlk, tline, uline, nablai, nablaj, nablak, nablal, tpnabla

      do idihegroup = 1, ndihegroup
         idihe=dihegroupindex(idihegroup)+1

         itype = diheatom(5*idihe); if ( itype == 0 ) cycle

         i = diheatom(5*idihe - 4); j = diheatom(5*idihe - 3)
         k = diheatom(5*idihe - 2); l = diheatom(5*idihe - 1)

         rij(1:3) = tpcoor(1:3, i) - tpcoor(1:3, j); rlk(1:3) = tpcoor(1:3, l) - tpcoor(1:3, k)
         rkj(1:3) = tpcoor(1:3, k) - tpcoor(1:3, j); dkj2 = dot_product(rkj, rkj)
         dkj2inv = 1d0/(dkj2); dkj = sqrt(dkj2)
         rijrkj = dot_product(rij, rkj); rlkrkj = dot_product(rlk, rkj)
         ! Akj(here use nablakj) = unitmatrix crossdot rkj
         nablakj = reshape((/0d0, rkj(3), -rkj(2), -rkj(3), 0d0, rkj(1), rkj(2), -rkj(1), 0d0/), (/3, 3/))

         call cross_product(rij, rkj, tline); call cross_product(rlk, rkj, uline)
         tlen2inv = 1d0/dot_product(tline, tline); ulen2inv = 1d0/dot_product(uline, uline)

         phi = dot_product(tline, uline)*sqrt(tlen2inv*ulen2inv); phi = min(1d0, max(-1d0, phi))
         phi = sign(1.0d0, dot_product(rij, uline)) * acos(phi)

         dedphi = 0d0; d2edphi2 = 0d0
         do idihe = dihegroupindex(idihegroup) + 1, dihegroupindex(idihegroup + 1)
            itype=diheatom(5 * idihe); tpn = diheperiod(itype)
            tpphase = tpn * phi - dihephase(itype)
            tpcoeff = - tpn * diheforceconst(itype)
            dedphi = dedphi + tpcoeff * sin(tpphase)
            d2edphi2 = d2edphi2 + tpn * tpcoeff * cos(tpphase)
         enddo

         ! Calculate nabla_i, nabla_j, nabla_k and nabla_l
         nablai = dkj*tlen2inv*tline; nablal = -dkj*ulen2inv*uline
         tpnabla = (rijrkj*nablai + rlkrkj*nablal)*dkj2inv
         nablaj = tpnabla - nablai; nablak = -(tpnabla + nablal)

         ! Calculate nabla_ii and nabla_ll
         ! nablaii : grad_i(grad_i(cos(phi))), nablall : grad_l(grad_l(cos(phi)))
         ! call dgemm('N', 'N', 3, 3, 1, 2d0*tlen2inv, tline, 3, tline, 1, 0d0, tpmatrix, 3)
         ! call dgemm('N', 'N', 3, 3, 3, dkj*tlen2inv, nablakj, 3, unitmatrix - tpmatrix, 3, 0d0, nablaii, 3)
         do tpindex = 1, 3
            tpmatrix(:,tpindex) = 2d0*tlen2inv*tline(tpindex)*tline(:)
         end do
         nablaii = dkj*tlen2inv*matmul(nablakj,unitmatrix - tpmatrix)

         ! call dgemm('N', 'N', 3, 3, 1, 2d0*ulen2inv, uline, 3, uline, 1, 0d0, tpmatrix, 3)
         ! call dgemm('N', 'N', 3, 3, 3, -dkj*ulen2inv, nablakj, 3, unitmatrix - tpmatrix, 3, 0d0, nablall, 3)
         do tpindex = 1, 3
            tpmatrix(:,tpindex) = 2d0*ulen2inv*uline(tpindex)*uline(:)
         end do
         nablall = -dkj*ulen2inv*matmul(nablakj,unitmatrix - tpmatrix)

         ! Calculate nabla_ij, nabla_ik, nablalj and nabla_lk
         ! Here we calculate Transpose(nabla_ki) and Transpose(nabla_jl) instead nabla_ik and nabla_lj

         do tpindex = 1, 3
            tpmatrix(:, tpindex) = rkj(tpindex)*nablai(:)
         end do
         nablaik = -(tpmatrix + rijrkj*nablaii)*dkj2inv
         do tpindex = 1, 3
            tpmatrix(:, tpindex) = rkj(tpindex)*nablal(:)
         end do
         nablalj = (tpmatrix + rlkrkj*nablall)*dkj2inv
         nablaij = -(nablaii + nablaik); nablalk = -(nablall + nablalj)

         ! Calculate nabla_jj and nabla_kk by nabla_ii, nabla_ll, nabla_ij, nabla_lj, nabla_ik and nabla_lk
         nablajj = (rijrkj - dkj2)*nablaij + rlkrkj*nablalj
         do tpindex = 1, 3
            nablajj(:, tpindex) = -nablai(tpindex)*(rij-rkj) + nablajj(:,tpindex)
            nablajj(:, tpindex) = -nablal(tpindex)*rlk + nablajj(:,tpindex)
            nablajj(:, tpindex) = 2d0*dkj2inv*nablaj(tpindex)*rkj + dkj2inv*nablajj(:,tpindex)
         end do

         nablakk = (rijrkj)*nablaik + (rlkrkj + dkj2)*nablalk
         do tpindex = 1, 3
            nablakk(:, tpindex) = nablai(tpindex)*rij + nablakk(:,tpindex)
            nablakk(:, tpindex) = nablal(tpindex)*(rlk+rkj) + nablakk(:,tpindex)
            nablakk(:, tpindex) = -2d0*dkj2inv*nablak(tpindex)*rkj - dkj2inv*nablakk(:,tpindex)
         end do

         ! Calculate nabla_kj by nabla_ij, nabla_jj and nabla_lj; And nabla_il = 0
         nablakj = -(nablajj + nablaij + nablalj); tpmatrix = 0d0

         do tpindex = 1, 3
            nablaii(:, tpindex) = d2edphi2*nablai(tpindex)*nablai(:) + dedphi*nablaii(:,tpindex)
            nablajj(:, tpindex) = d2edphi2*nablaj(tpindex)*nablaj(:) + dedphi*nablajj(:,tpindex)
            nablakk(:, tpindex) = d2edphi2*nablak(tpindex)*nablak(:) + dedphi*nablakk(:,tpindex)

            nablall(:, tpindex) = d2edphi2*nablal(tpindex)*nablal(:) + dedphi*nablall(:,tpindex)
            nablaij(:, tpindex) = d2edphi2*nablai(tpindex)*nablaj(:) + dedphi*nablaij(:,tpindex)
            nablaik(:, tpindex) = d2edphi2*nablai(tpindex)*nablak(:) + dedphi*nablaik(:,tpindex)

            nablalj(:, tpindex) = d2edphi2*nablal(tpindex)*nablaj(:) + dedphi*nablalj(:,tpindex)
            nablalk(:, tpindex) = d2edphi2*nablal(tpindex)*nablak(:) + dedphi*nablalk(:,tpindex)

            nablakj(:, tpindex) = d2edphi2*nablak(tpindex)*nablaj(:) + dedphi*nablakj(:,tpindex)
            tpmatrix(:, tpindex) = d2edphi2*nablai(tpindex)*nablal(:) + dedphi*tpmatrix(:,tpindex)
         end do

         call nma_storehessian(i, nablaii)
         call nma_storehessian(j, nablajj)
         call nma_storehessian(k, nablakk)
         call nma_storehessian(l, nablall)
         call nma_storehessian(i, j, nablaij)
         call nma_storehessian(i, k, nablaik)
         call nma_storehessian(i, l, tpmatrix)

         call nma_storehessian(k, j, nablakj)
         call nma_storehessian(l, j, nablalj)
         call nma_storehessian(l, k, nablalk)

      end do
   end subroutine nma_matrix_dihedral

   subroutine nma_matrix_dihedral_select_case(tpcoor)
      use ambertop, only: ndihedral, diheatom, dihephase, diheperiod, diheforceconst
      implicit none
      real*8, intent(in) :: tpcoor(3, natom)

      integer :: i, j, k, l, idihe, itype, tpindex
      real*8 :: tpk, tpn, tpphase, tpcoeff, dedphi, d2edphi2
      real*8 :: dkj, dkj2, dkj2inv, tlen2inv, ulen2inv, rijrkj, rlkrkj
      real*8 :: cosphi, cosphi2, cosnphi, sinphi, dcosndcos
      real*8, dimension(3, 3) :: nablaij, nablaik, nablalj, nablalk, nablakj
      real*8, dimension(3, 3) :: nablaii, nablajj, nablakk, nablall, tpmatrix
      real*8, dimension(3) :: rij, rkj, rlk, tline, uline, nablai, nablaj, nablak, nablal, tpnabla

      do idihe = 1, ndihedral

         itype = diheatom(5*idihe); if ( itype == 0 ) cycle

         i = diheatom(5*idihe - 4); j = diheatom(5*idihe - 3)
         k = diheatom(5*idihe - 2); l = diheatom(5*idihe - 1)
         tpk = diheforceconst(itype)
         tpn = diheperiod(itype); tpphase = dihephase(itype)
         rij(1:3) = tpcoor(1:3, i) - tpcoor(1:3, j); rlk(1:3) = tpcoor(1:3, l) - tpcoor(1:3, k)
         rkj(1:3) = tpcoor(1:3, k) - tpcoor(1:3, j); dkj2 = dot_product(rkj, rkj)
         dkj2inv = 1d0/(dkj2); dkj = sqrt(dkj2)
         rijrkj = dot_product(rij, rkj); rlkrkj = dot_product(rlk, rkj)
         ! Akj(here use nablakj) = unitmatrix crossdot rkj
         nablakj = reshape((/0d0, rkj(3), -rkj(2), -rkj(3), 0d0, rkj(1), rkj(2), -rkj(1), 0d0/), (/3, 3/))

         call cross_product(rij, rkj, tline); call cross_product(rlk, rkj, uline)
         tlen2inv = 1d0/dot_product(tline, tline); ulen2inv = 1d0/dot_product(uline, uline)

         cosphi = dot_product(tline, uline)*sqrt(tlen2inv*ulen2inv); cosphi = min(1d0, max(-1d0, cosphi))
         cosphi2 = cosphi**2; sinphi = sign(sqrt(1 - cosphi2), dot_product(rij, uline))

         select case (int(tpn))
         case (0); cosnphi = 1d0
            dcosndcos = 0d0
         case (1); cosnphi = cosphi
            dcosndcos = 1d0
         case (2); cosnphi = 2d0*cosphi2 - 1d0
            dcosndcos = 4d0*cosphi
         case (3); cosnphi = (4d0*cosphi2 - 3d0)*cosphi
            dcosndcos = 12d0*cosphi2 - 3d0
         case (4); cosnphi = 8d0*(cosphi2 - 1d0)*cosphi2 + 1d0
            dcosndcos = 16d0*(2d0*cosphi2 - 1d0)*cosphi
         case (5); cosnphi = ((16d0*cosphi2 - 20d0)*cosphi2 + 5d0)*cosphi
            dcosndcos = 20d0*(4d0*cosphi2 - 3d0)*cosphi2 + 5d0
         case (6); cosnphi = (16d0*(cosphi2 - 1d0)*cosphi2 + 1d0)*(2d0*cosphi2 - 1d0)
            dcosndcos = (192d0*(cosphi2 - 1d0)*cosphi2 + 36d0)*cosphi
         case default
            call multiple_angle_formulas(int(tpn), cosphi, cosphi2, cosnphi, dcosndcos)
         end select

         tpcoeff = -tpk*sign(1.0d0, cos(tpphase))
         dedphi = tpcoeff*dcosndcos*sinphi; d2edphi2 = tpn**2*tpcoeff*cosnphi

         ! Calculate nabla_i, nabla_j, nabla_k and nabla_l
         nablai = dkj*tlen2inv*tline; nablal = -dkj*ulen2inv*uline
         tpnabla = (rijrkj*nablai + rlkrkj*nablal)*dkj2inv
         nablaj = tpnabla - nablai; nablak = -(tpnabla + nablal)

         ! Calculate nabla_ii and nabla_ll
         ! nablaii : grad_i(grad_i(cos(phi))), nablall : grad_l(grad_l(cos(phi)))
         ! call dgemm('N', 'N', 3, 3, 1, 2d0*tlen2inv, tline, 3, tline, 1, 0d0, tpmatrix, 3)
         ! call dgemm('N', 'N', 3, 3, 3, dkj*tlen2inv, nablakj, 3, unitmatrix - tpmatrix, 3, 0d0, nablaii, 3)
         do tpindex = 1, 3
            tpmatrix(:,tpindex) = 2d0*tlen2inv*tline(tpindex)*tline(:)
         end do
         nablaii = dkj*tlen2inv*matmul(nablakj,unitmatrix - tpmatrix)

         ! call dgemm('N', 'N', 3, 3, 1, 2d0*ulen2inv, uline, 3, uline, 1, 0d0, tpmatrix, 3)
         ! call dgemm('N', 'N', 3, 3, 3, -dkj*ulen2inv, nablakj, 3, unitmatrix - tpmatrix, 3, 0d0, nablall, 3)
         do tpindex = 1, 3
            tpmatrix(:,tpindex) = 2d0*ulen2inv*uline(tpindex)*uline(:)
         end do
         nablall = -dkj*ulen2inv*matmul(nablakj,unitmatrix - tpmatrix)

         ! Calculate nabla_ij, nabla_ik, nablalj and nabla_lk
         ! Here we calculate Transpose(nabla_ki) and Transpose(nabla_jl) instead nabla_ik and nabla_lj

         do tpindex = 1, 3
            tpmatrix(:, tpindex) = rkj(tpindex)*nablai(:)
         end do
         nablaik = -(tpmatrix + rijrkj*nablaii)*dkj2inv
         do tpindex = 1, 3
            tpmatrix(:, tpindex) = rkj(tpindex)*nablal(:)
         end do
         nablalj = (tpmatrix + rlkrkj*nablall)*dkj2inv
         nablaij = -(nablaii + nablaik); nablalk = -(nablall + nablalj)

         ! Calculate nabla_jj and nabla_kk by nabla_ii, nabla_ll, nabla_ij, nabla_lj, nabla_ik and nabla_lk
         nablajj = (rijrkj - dkj2)*nablaij + rlkrkj*nablalj
         do tpindex = 1, 3
            nablajj(:, tpindex) = -nablai(tpindex)*(rij-rkj) + nablajj(:,tpindex)
            nablajj(:, tpindex) = -nablal(tpindex)*rlk + nablajj(:,tpindex)
            nablajj(:, tpindex) = 2d0*dkj2inv*nablaj(tpindex)*rkj + dkj2inv*nablajj(:,tpindex)
         end do

         nablakk = (rijrkj)*nablaik + (rlkrkj + dkj2)*nablalk
         do tpindex = 1, 3
            nablakk(:, tpindex) = nablai(tpindex)*rij + nablakk(:,tpindex)
            nablakk(:, tpindex) = nablal(tpindex)*(rlk+rkj) + nablakk(:,tpindex)
            nablakk(:, tpindex) = -2d0*dkj2inv*nablak(tpindex)*rkj - dkj2inv*nablakk(:,tpindex)
         end do

         ! Calculate nabla_kj by nabla_ij, nabla_jj and nabla_lj; And nabla_il = 0
         nablakj = -(nablajj + nablaij + nablalj); tpmatrix = 0d0

         do tpindex = 1, 3
            nablaii(:, tpindex) = d2edphi2*nablai(tpindex)*nablai(:) + dedphi*nablaii(:,tpindex)
            nablajj(:, tpindex) = d2edphi2*nablaj(tpindex)*nablaj(:) + dedphi*nablajj(:,tpindex)
            nablakk(:, tpindex) = d2edphi2*nablak(tpindex)*nablak(:) + dedphi*nablakk(:,tpindex)

            nablall(:, tpindex) = d2edphi2*nablal(tpindex)*nablal(:) + dedphi*nablall(:,tpindex)
            nablaij(:, tpindex) = d2edphi2*nablai(tpindex)*nablaj(:) + dedphi*nablaij(:,tpindex)
            nablaik(:, tpindex) = d2edphi2*nablai(tpindex)*nablak(:) + dedphi*nablaik(:,tpindex)

            nablalj(:, tpindex) = d2edphi2*nablal(tpindex)*nablaj(:) + dedphi*nablalj(:,tpindex)
            nablalk(:, tpindex) = d2edphi2*nablal(tpindex)*nablak(:) + dedphi*nablalk(:,tpindex)

            nablakj(:, tpindex) = d2edphi2*nablak(tpindex)*nablaj(:) + dedphi*nablakj(:,tpindex)
            tpmatrix(:, tpindex) = d2edphi2*nablai(tpindex)*nablal(:) + dedphi*tpmatrix(:,tpindex)
         end do

         call nma_storehessian(i, nablaii)
         call nma_storehessian(j, nablajj)
         call nma_storehessian(k, nablakk)
         call nma_storehessian(l, nablall)
         call nma_storehessian(i, j, nablaij)
         call nma_storehessian(i, k, nablaik)
         call nma_storehessian(i, l, tpmatrix)

         call nma_storehessian(k, j, nablakj)
         call nma_storehessian(l, j, nablalj)
         call nma_storehessian(l, k, nablalk)

      end do
   end subroutine nma_matrix_dihedral_select_case

   subroutine nma_matrix_elecvdw14(tpcoor)
      use ambertop, only: nonbond14, scale14vdw, scale14elec
      use ambertop, only: nnb14, vdwacoef, vdwbcoef, charge
      use ambertop, only: nonbondedparmindex, typeindex, nvdwtype
      implicit none
      real*8, intent(in) :: tpcoor(3, natom)

      integer :: idihe, i, j, itype, vdw14index, tpindex
      real*8 :: elec14, vdwscale, rij(3), tpmatrix(3, 3)
      real*8 :: dedr, d2edr2, dij2inv, dij6inv, vdwa, vdwb, tpelec, tpvdw, sumelec, sumvdw

      sumelec = 0d0; sumvdw = 0d0
      do idihe = 1, nnb14

         itype = nonbond14(3, idihe); if ( itype == 0 ) cycle
         i = nonbond14(1, idihe); j = nonbond14(2, idihe)
         rij(1:3) = tpcoor(1:3, i) - tpcoor(1:3, j); dij2inv = 1d0/dot_product(rij, rij)

         ! uncommit this line in comparison with nmode in AMBER
         ! scale14elec(itype) = 0.5d0

         elec14 = scale14elec(itype)*charge(i)*charge(j)*sqrt(dij2inv)
         vdw14index = nonbondedparmindex(nvdwtype*(typeindex(i) - 1) + typeindex(j))
         dij6inv = dij2inv**3; vdwscale = 6d0*scale14vdw(itype)*dij6inv
         vdwa = vdwacoef(vdw14index)*vdwscale*dij6inv
         vdwb = vdwbcoef(vdw14index)*vdwscale
         ! dedr = de/dr * dijinv
         dedr = -(elec14 + 2d0*vdwa - vdwb)*dij2inv
         d2edr2 = (2d0*elec14 + 26d0*vdwa - 7d0*vdwb)*dij2inv

         d2edr2 = (d2edr2 - dedr)*dij2inv
         do tpindex = 1, 3
            tpmatrix(:, tpindex) = d2edr2*rij(:)*rij(tpindex)
            tpmatrix(tpindex, tpindex) = tpmatrix(tpindex, tpindex) + dedr
         end do

         ! tpmatrix = dedr*unitmatrix; d2edr2 = (d2edr2 - dedr)*dij2inv
         ! do tpindex = 1, 3
         !    tpmatrix(:, tpindex) = d2edr2*rij(tpindex)*rij(:) + tpmatrix(:,tpindex)
         ! end do

         call nma_storehessian(i, tpmatrix)
         call nma_storehessian(j, tpmatrix)
         call nma_storehessian(i, j, -tpmatrix)
      end do
      !print "(a, 2f15.7)", 'total ene', sumelec, sumvdw
      !print*, sumelec/2, sumvdw/2


   end subroutine nma_matrix_elecvdw14

   subroutine nma_matrix_GB(tpcoor)
      use ambertop, only: charge, discut
      use gb, only: gb_radeffborn, epsin, epsout, gbdiscut, fsrho, radeff, radoff, kappa
      use cudanma, only: cudanma_GB_PartialE
      implicit none
      real*8, intent(in) :: tpcoor(3, natom)

      integer :: i, j, k, l, tpindex
      real*8 :: qi, qj, radeffi, radeff2, dij2, dE_a, d2E_a, kij, lij
      real*8 :: nablakl(3, 3), nablak_a(3, natom), nablal_a(3, natom)
      real*8 :: coori(3), rij(3), Partial_E(6), nablakl_a(3, 3, natom), dradeffdI(2, natom)
      real*8 :: nablak_d(3,natom),nablakl_d(3,3,natom),nablal_ai(3),nablak_ai(3),nablakl_ai(3,3)
      real*8 :: dE_d(natom),d2E_d(natom),discutsq,tpkdotl(3,3)

      discutsq = discut**2
      call gb_radeffborn(tpcoor, dradeffdI)
      call nma_GB_nablaEffBorn_prepare()

      do k = 1, natom

         if ( charge(k) == 0d0 ) cycle

         ! nablak_a(i) -> grad_k((alpha_i^-1)), alpha_i : effective Born radius of atom i
         call nma_GB_nablaEffBorn_k(); nablal_a = nablak_a
         do l = k, natom

            if ( charge(l) == 0d0 ) cycle

            ! nablakl_a -> grad_k(grad_l(alpha_i^-1))
            if (l /= k) then
               call nma_GB_nablaEffBorn_l()
            end if

            nablakl = 0d0

            do i = 1, natom
               qi = charge(i); if ( qi == 0d0 ) cycle
               coori(1:3) = tpcoor(1:3, i); radeffi = radeff(i)
               nablakl_ai(:,:) = nablakl_a(:,:,i)
               nablal_ai(:) = nablal_a(:,i); nablak_ai(:) = nablak_a(:,i)
               do tpindex = 1, 3
                  tpkdotl(:,tpindex) = nablak_ai(tpindex)*nablal_ai(:)
               end do

               dE_a = dE_d(i); d2E_a = d2E_d(i)
               ! nablakl -> nabla_k(nabla_l(E_ii))
               ! nablakl = dE_dai*nablakl_a(i) + d2E_dai*(nablal_a(i)^T * nablak_a(i))
               do tpindex = 1, 3
                  nablakl(:, tpindex) = nablakl(:, tpindex) + d2E_a*tpkdotl(:,tpindex) + dE_a*nablakl_ai(:,tpindex)
               end do

               do j = i + 1, natom
                  qj = charge(j); if ( qj == 0d0 ) cycle

                  rij(1:3) = coori(1:3) - tpcoor(1:3, j); dij2 = dot_product(rij, rij)
                  if ( dij2 > discutsq ) cycle
                  radeff2 = radeffi*radeff(j)

                  ! calculate six terms in the formula of grad_k'(grad_k(Eij))
                  ! epsin = 4*pi * epsilon0; epsout = 4*pi * epsilon0*epsilon
                  ! Ecoef_ij = Ecoef_ji = qi*qj / (8*pi*epsilon*epsilon0); Ecoef = Ecoef_ij + Ecoef_ji
                  ! Partial_E(6) = (/dE_a, d2E_a2, d2E_aa, dE_d, d2E_d2, d2E_ad/)
                  call nma_GB_PartialE(qi*qj/epsout, epsout/epsin)

                  nablakl = nablakl + Partial_E(1)*(nablakl_ai + nablakl_a(:, :, j))
                  do tpindex = 1, 3
                     nablakl(:, tpindex) = nablakl(:, tpindex) + Partial_E(2)*(    &
                            tpkdotl(:,tpindex) + nablak_a(tpindex,j)*nablal_a(:,j)  ) 
                  end do

                  do tpindex = 1, 3
                     nablakl(:, tpindex) = nablakl(:, tpindex) + Partial_E(3)*(    &
                            nablak_a(tpindex,j)*nablal_ai(:) + nablak_ai(tpindex)*nablal_a(:,j) )
                  end do

                  kij = 0d0; lij = 0d0
                  if (k == i) then; kij = 1d0; else if (k == j) then; kij = -1d0; end if
                  if (l == i) then; lij = 1d0; else if (l == j) then; lij = -1d0; end if

                  if (kij /= 0d0) then
                     do tpindex = 1, 3
                        nablakl(:, tpindex) = nablakl(:, tpindex) + Partial_E(6)*kij*rij(tpindex)*(nablal_ai(:) + nablal_a(:, j))
                     end do
                  else
                     dij2 = 0d0
                  end if

                  if (lij /= 0d0) then
                     do tpindex = 1, 3
                        nablakl(:, tpindex) = nablakl(:, tpindex) + Partial_E(6)*lij*(nablak_ai(tpindex) + nablak_a(tpindex, j))*rij(:)
                     end do
                  else
                     dij2 = 0d0
                  end if

                  if ( dij2 == 0d0 ) cycle

                  dij2 = kij*lij
                  do tpindex = 1, 3
                     nablakl(:, tpindex) = nablakl(:, tpindex) + dij2*Partial_E(5)*rij(tpindex)*rij(:)
                     nablakl(tpindex, tpindex) = nablakl(tpindex, tpindex) + dij2*Partial_E(4)
                  end do

               end do
            end do

            call nma_storehessian(k, l, nablakl)

         end do
      end do

   contains

      subroutine nma_GB_nablaEffBorn_prepare()
         implicit none
         real*8 :: tpvalue, coork(3), tpvec(3), tpdcoor(3), tpradeff, tpmatrix(3,3), tpnablak_a(3), tpnablakl_a(3,3)

         nablak_d = 0d0
         do k = 1, natom
            qi = charge(k); if ( qi == 0d0 ) cycle

            coork = tpcoor(:, k); tpnablakl_a = 0d0; tpnablak_a =0d0
            do i = 1, natom
               if ( charge(i) == 0d0 ) cycle
               if (i /= k) then
                  call nma_GB_nablaintegral(k, i, coork - tpcoor(:,i), tpvec, tpmatrix)
                  tpnablak_a = tpnablak_a - tpvec
                  tpnablakl_a = tpnablakl_a + tpmatrix
               end if
            end do

            nablak_d(:, k) = tpnablak_a; nablakl_d(:, :, k) =  tpnablakl_a

            ! radeffi -> alpha_i; qi -> qi^2/(8*pi*epsilon0*epsilon*alpha_i)
            ! radeffi -> -kappa*alpha_i; d2E_a -> exp(-kappa*alpha_i)
            tpradeff = radeff(k)
            qi = qi**2/(2d0*epsout*tpradeff); tpradeff = -kappa*tpradeff
            tpvalue = exp(tpradeff)

            ! dE_a -> d(E_ii)/d(alpha_i^-1); d2E_a -> d2(E_ii)/d(alpha_i^-1)2
            dE_d(k) = -(epsout/epsin - tpvalue - tpradeff*tpvalue)*qi
            d2E_d(k) = qi*tpvalue*tpradeff**2
         end do
      end subroutine

      subroutine nma_GB_nablaEffBorn_k()
         implicit none
         real*8 :: dradeff, d2radeff, coork(3), tpvec(3), tpmatrix(3, 3)

         nablakl_a = 0d0; nablak_a = 0d0; coork = tpcoor(:, k)
         do i = 1, natom
            if ( charge(i) == 0d0 .or. i == k ) cycle
            dradeff = dradeffdI(1, i); d2radeff = dradeffdI(2, i)
            ! grad_k(I_i)
            call nma_GB_nablaintegral(i, k, tpcoor(:,i) - coork, tpvec, tpmatrix)
            ! temporary array for grad_k(grad_k(I_i))
            do tpindex = 1, 3
               tpmatrix(:, tpindex) = d2radeff*tpvec(tpindex)*tpvec(:) + dradeff*tpmatrix(:,tpindex)
            end do
            nablak_a(:, i) = dradeff*tpvec; nablakl_a(:, :, i) = tpmatrix
         end do
         nablak_a(:,k) = nablak_d(:,k)

         dradeff = dradeffdI(1, k); d2radeff = dradeffdI(2, k)
         tpvec = nablak_a(:, k); tpmatrix = nablakl_d(:, :, k)
         do tpindex = 1, 3
            tpmatrix(:, tpindex) = d2radeff*tpvec(tpindex)*tpvec(:) + dradeff*tpmatrix(:,tpindex)
         end do
         nablak_a(:, k) = dradeff*tpvec; nablakl_a(:, :, k) = tpmatrix

      end subroutine nma_GB_nablaEffBorn_k

      subroutine nma_GB_nablaEffBorn_l()
         implicit none
         real*8 :: dradeff, d2radeff, coorkl(3), coorl(3), tpvec(3), tpmatrix(3, 3)

         coorl = tpcoor(:, l); coorkl = tpcoor(:, k) - coorl(:)
         do i = 1, natom
            if ( charge(i) == 0d0 .or. i == l ) cycle
            dradeff = dradeffdI(1, i); d2radeff = dradeffdI(2, i)/dradeff
            call nma_GB_nablaintegral(i, l, tpcoor(:,i) - coorl, tpvec)
            do tpindex = 1, 3
               tpmatrix(:, tpindex) = d2radeff*nablak_a(tpindex, i)*tpvec(:)
            end do
            nablakl_a(:, :, i) = tpmatrix; nablal_a(:, i) = dradeff*tpvec
         end do

         ! i == k
         call nma_GB_nablaintegral(k, l, coorkl(:), tpvec, tpmatrix)
         nablakl_a(:, :, k) = nablakl_a(:, :, k) - dradeffdI(1, k)*tpmatrix

         ! i == l
         call nma_GB_nablaintegral(l, k, -coorkl(:), tpvec, tpmatrix)
         dradeff = dradeffdI(1, l); d2radeff = dradeffdI(2, l)
         do tpindex = 1, 3
            tpmatrix(:, tpindex) = d2radeff*tpvec(tpindex)*nablak_d(:, l) - dradeff*tpmatrix(:,tpindex)
         end do
         nablakl_a(:, :, l) = tpmatrix; nablal_a(:, l) = dradeff*nablak_d(:, l)

      end subroutine nma_GB_nablaEffBorn_l

      subroutine nma_GB_nablaintegral(i, j, rij, tpvec, tpmatrix)
         use ambertop, only: radius
         use parmdata, only: gb1watrad, gb1sneck, gb1mmat, gb1dmat
         implicit none
         integer, intent(in) :: i, j
         real*8, intent(in) :: rij(3)
         real*8, intent(out) :: tpvec(3)
         real*8, intent(out), optional :: tpmatrix(3, 3)
         real*8, parameter :: d1a = 1d0/3d0, d1b = 0.6d0, d1c = 6d0/7d0, d1d = 10d0/9d0, d1f = 15d0/11d0
         real*8, parameter :: d2a = 2d0, d2b = 4.8d0, d2c = 60d0/7d0, d2d = 40d0/3d0, d2f = 210d0/11d0
         real*8 :: dij, dij2, fsrhoj, fsrhoj2, dI_d, d2I_d
         real*8 :: roffi, neckmpar, coef1, coef2, coef3
         logical :: cald2
         integer :: m, n

         dij2 = dot_product(rij, rij); dij = sqrt(dij2)
         roffi = radoff(i); fsrhoj = fsrho(j); fsrhoj2 = fsrhoj**2
         ! d : distance between atom i and atom j
         ! dI_d  -> 1/d     * d(I)    / d(d)
         ! d2I_d -> 1/(d)^2 * [d^2(I) / d(d)^2  -  dI_d]
         cald2 = present(tpmatrix); dI_d = 0d0
         if (cald2) d2I_d = 0d0

         if (dij <= (gbdiscut + fsrhoj)) then
            ! sphere j partially within cutoff
            if (dij > (gbdiscut - fsrhoj)) then
               coef1 = 1d0/(dij - fsrhoj); coef2 = log(gbdiscut*coef1); coef3 = 1/gbdiscut**2
               dI_d = 0.5d0*(dij2 + fsrhoj2)*(coef1**2 - coef3) - coef2
               if (cald2) d2I_d = 1.5d0*fsrhoj*(dij + fsrhoj)*coef1**2 - 3d0*coef2 &
                                  + 0.5d0*(dij2 + 3d0*fsrhoj2)*(dij*coef1**3 - coef3)
            ! artifical regime for smoothing
            else if (dij > 4d0*fsrhoj) then
               coef3 = fsrhoj/dij; coef1 = coef3**2
               coef2 = d1a + coef1*(d1b + coef1*(d1c + coef1*(d1d + coef1*d1f)))
               coef3 = 16d0*coef3*coef1; dI_d = coef3*coef2
               if (cald2) then
                  coef2 = d2a + coef1*(d2b + coef1*(d2c + coef1*(d2d + coef1*d2f)))
                  d2I_d = coef3*coef2
               end if
            ! spheres not overlapping
            else if (dij > (roffi + fsrhoj)) then
               coef1 = 1d0/(dij2 - fsrhoj2); coef2 = 2d0*dij*fsrhoj
               coef3 = log((dij - fsrhoj)/(dij + fsrhoj))
               dI_d = coef3 + coef2*(dij2 + fsrhoj2)*coef1**2
               if (cald2) d2I_d = 3d0*coef3 + coef2*(3d0*dij2 - fsrhoj2)*(dij2 + 3d0*fsrhoj2)*coef1**3
            ! spheres overlapping
            else if (dij > abs(roffi - fsrhoj)) then
               coef1 = 1d0/(dij + fsrhoj); coef2 = log(coef1*roffi); coef3 = 1.0d0/roffi**2
               dI_d = coef2 + 0.5d0*(dij2 + fsrhoj2)*(coef3 - coef1**2)
               if (cald2) d2I_d = 3*coef2 + 0.5d0*(dij2 + 3*fsrhoj2)*coef3 &
                                  + fsrhoj*(3*dij2 - fsrhoj2)*coef1**3 - 0.5d0
            ! sphere i inside sphere j
            else if (roffi < fsrhoj) then
               coef1 = 1d0/(dij2 - fsrhoj2); coef2 = 2d0*dij*fsrhoj
               coef3 = log((fsrhoj - dij)/(fsrhoj + dij))
               dI_d = coef3 + coef2*(dij2 + fsrhoj2)*coef1**2
               if (cald2) d2I_d = 3d0*coef3 + coef2*(3d0*dij2 - fsrhoj2)*(dij2 + 3d0*fsrhoj2)*coef1**3
            ! sphere j inside sphere j
            else
               dI_d = 0d0
               if (cald2) d2I_d = 0d0
            end if
         end if
         coef1 = 1d0/dij2; coef3 = dij*coef1; coef2 = 0.25d0*coef1*coef3; dI_d = dI_d*coef2
         if (cald2) d2I_d = -d2I_d*coef1*coef2

         ! if ( igb == 1 ) then
         if (dij < (radius(i) + radius(j) + gb1watrad)) then
            m = nint((radius(i) - 0.95d0)/0.05d0); n = nint((radius(j) - 0.95d0)/0.05d0)
            neckmpar = gb1sneck*gb1mmat(m, n)*coef3; coef1 = dij - gb1dmat(m, n)
            coef2 = coef1**2; coef3 = 1d0/(1d0 + coef2 + 0.3d0*coef2**3)
            neckmpar = neckmpar*coef3**2; coef1 = coef1*(2d0 + 1.8d0*coef2**2)
            dI_d = dI_d + neckmpar*coef1
            if (cald2) d2I_d = d2I_d + neckmpar*((dij*(2d0 + 9d0*coef2**2) - coef1)/dij2 &
                                                 - 2d0*coef1**2*coef3/dij)
         end if
         ! end if

         tpvec(:) = -dI_d*rij(:)
         if (cald2) then
            do tpindex = 1, 3
               tpmatrix(:, tpindex) = d2I_d*rij(tpindex)*rij(:)
               tpmatrix(tpindex, tpindex) = tpmatrix(tpindex, tpindex) + dI_d
            end do
         end if
      end subroutine nma_GB_nablaintegral

      subroutine nma_GB_PartialE(Ecoef, epsilon)
         ! Partial_E(6) = (/dE_a, d2E_a2, d2E_aa, dE_d, d2E_d2, d2E_ad/)
         implicit none
         real*8, intent(in) :: Ecoef, epsilon
         real*8 :: expmdij, fgb, fgb3inv, coef1, coef2
         real*8 :: dE_f, d2E_f, df_d, df_a, d2f_a2, d2f_d2, d2f_aa, d2f_ad

         ! expmdij = exp(-D_ij); notice that here D_ij = dij2/4*radeff2
         expmdij = exp(-dij2/(4d0*radeff2)); fgb = sqrt(dij2 + radeff2*expmdij)
         coef1 = kappa*fgb; coef2 = exp(-coef1); fgb3inv = 1.0/fgb**3

         ! E = E_ij + E_ji; f = fgb = f_ij = f_ji
         ! dE_f -> Ecoef/f * d(E)/d(f); d2E_f -> Ecoef/f^2 * d^2(E)/d(f)^2
         dE_f = Ecoef*(epsilon - coef2 - coef1*coef2)*fgb3inv
         d2E_f = (Ecoef*kappa**2*coef2 - 3d0*fgb*dE_f)*fgb3inv

         ! df_d -> f/d * d(f)/d(d); df_a -> f/alpha * d(f)/d(alpha^-1)
         ! d -> dij; alpha -> effective born radii
         df_d = 1 - 0.25d0*expmdij; df_a = -0.5d0*expmdij*(radeff2 + 0.25d0*dij2)

         ! d2f_d2 -> (f/d^2) * d^2(f)/d(d)^2 - (1/d^2) * df_d
         ! d2f_a2 -> (f/alpha^2)      * d^2(f)/d(alpha^-1)^2
         ! d2f_aa -> f/(alpha*alpha') * d^2(f) / [d(alpha^-1) * d(alpha'^-1)]
         ! d2f_ad -> f/(alpha*d)      * d^2(f) / [d(alpha^-1) * d(d)]
         d2f_d2 = 0.125d0*expmdij/radeff2; d2f_ad = 0.5d0*dij2*d2f_d2
         d2f_aa = 0.5d0*dij2*d2f_ad - df_a; d2f_a2 = d2f_aa - df_a

         Partial_E(:) = 0d0; coef1 = d2E_f*df_a**2
         ! Partial_E(6) = (/dE_a, d2E_a2, d2E_aa, dE_d, d2E_d2, d2E_ad/)
         ! dE_a -> 1/alpha            * d(E)    / d(alpha^-1)
         ! d2E_a2 -> 1/(alpha)^2      * d^2(E)  / d(alpha^-1)^2
         ! d2E_aa -> 1/(alpha*alpha') * d^2(E)  / [d(alpha^-1) * d(alpha'^-1)]
         ! dE_d -> 1/d                * d(E)    / d(d)
         ! d2E_d2 -> 1/(d)^2          * [d^2(E) / d(d)^2  -  dE_d]
         ! d2E_ad -> 1/(alpha*d)      * d^2(E)  / [d(alpha^-1) * d(d)]
         Partial_E(1) = dE_f*df_a; Partial_E(4) = dE_f*df_d
         Partial_E(2) = dE_f*d2f_a2 + coef1; Partial_E(5) = dE_f*d2f_d2 + d2E_f*df_d**2
         Partial_E(3) = dE_f*d2f_aa + coef1; Partial_E(6) = dE_f*d2f_ad + d2E_f*df_a*df_d
      end subroutine nma_GB_PartialE

   end subroutine nma_matrix_GB

   subroutine nma_massweighted()
      use cudanma, only: massinv
      implicit none
      integer :: i, j, ihessian, iatom, jatom

      do i = 1, 3*natom
         do j = 1, i
            ihessian = (i - 1)*i/2 + j
            iatom = (i-1)/3+1; jatom = (j-1)/3+1
            hessianline(ihessian) = massinv(iatom)*hessianline(ihessian)*massinv(jatom)
         end do
      end do
   end subroutine nma_massweighted

   ! Interface for nma_storehessian
   subroutine nma_storehessiani(atomindex, matrixij)
      implicit none
      integer, intent(in) :: atomindex
      real*8, intent(in) :: matrixij(0:2, 0:2)

      integer :: i, j, matrixindex(0:2)

      i = 3*atomindex

      matrixindex(2) = i*(i + 1)/2
      matrixindex(1) = matrixindex(2) - i
      matrixindex(0) = matrixindex(1) - i + 1

      do i = 0, 2
         j = matrixindex(i)
         hessianline(j - i:j) = hessianline(j - i:j) + matrixij(0:i, i)
      end do
   end subroutine nma_storehessiani

   subroutine nma_storehessianij(atomi, atomj, matrixij)
      implicit none
      integer, intent(in) :: atomi, atomj
      real*8, intent(in) :: matrixij(3, 3)
      integer :: i, j, matrixindex(3)
      real*8 :: tpmatrix(3, 3)

      if (atomi > atomj) then
         ! tpmatrix = transpose(transpose(matrixij))
         ! The second transpose used for tpmatrix(1:3,i) to accelerate because of the column major
         i = 3*atomj; j = 3*atomi; tpmatrix = matrixij
      else if (atomi < atomj) then
         i = 3*atomi; j = 3*atomj; tpmatrix = transpose(matrixij)
      else
         ! print*, 'warning : atomi == atomj'
         call nma_storehessiani(atomi, matrixij); return
      end if

      matrixindex(3) = j*(j - 1)/2 + i
      matrixindex(2) = matrixindex(3) - j + 1
      matrixindex(1) = matrixindex(2) - j + 2

      do i = 1, 3
         j = matrixindex(i)
         hessianline(j - 2:j) = hessianline(j - 2:j) + tpmatrix(1:3, i)
      end do
   end subroutine nma_storehessianij

   subroutine nma_entropy(tpmolarray)
      use ambertop, only: nowcoor, mass
      use pubmod, only: errormsg
      use cudanma, only: frequencies

      integer, intent(in) :: tpmolarray(:)
      integer :: ieigen, ifreq
      real*8 :: betahnu

      ! --- Vibrational entropy calculation
      ! freq = nu/c
      entropy_svibn = 0.0d0
      do ifreq = freqstart, ndegree
         betahnu = planck*lightspeed*frequencies(ifreq)/(boltzmann*temperature)
         ! unit : joules/(mol*kelvin)
         entropy_svibn(ifreq) = avogadro*boltzmann*(betahnu/(exp(betahnu) - 1.0d0) - log(1.0d0 - exp(-betahnu)))
      end do
      entropy_svib = sum(entropy_svibn)

      ! ! --- Translational entropy calculation
      ! call nma_traentropy(tpmolarray)

      ! ! --- Rotational entropy calculation
      ! call nma_rotentropy(tpmolarray)

      ! ! unit conversion from joule/(mol*kelvin) to kcal/mol
      ! entropy_svib = sum(entropy_svibn)
      ! entropy_svib = temperature*entropy_svib*joule2kcal
      ! entropy_stra = temperature*entropy_stra*joule2kcal
      ! entropy_srot = temperature*entropy_srot*joule2kcal

      ! ! for each vibrational mode unit conversion from joule/(mol*kelvin) to kcal/mol
      ! entropy_svibn = temperature*entropy_svibn*joule2kcal

   end subroutine nma_entropy
      
   subroutine nma_unit_conversion()
      implicit none 
      ! unit conversion from joule/(mol*kelvin) to kcal/mol
      entropy_svib = temperature*entropy_svib*joule2kcal
      entropy_stra = temperature*entropy_stra*joule2kcal
      entropy_srot = temperature*entropy_srot*joule2kcal

      ! for each vibrational mode unit conversion from joule/(mol*kelvin) to kcal/mol
      entropy_svibn = temperature*entropy_svibn*joule2kcal
   end subroutine nma_unit_conversion

   subroutine nma_traentropy(tpmolarray)
      use ambertop, only: mass
      integer, intent(in) :: tpmolarray(:)
      integer, save :: itra = 1
      integer :: imol, i, latom, uatom
      real*8 :: totmass, lambda_th, volum

      itra = itra + 1; totmass = 0.0d0
      do i = 1, size(tpmolarray)
         imol = tpmolarray(i); if (imol == 0) cycle
         latom = molrange(1, imol); uatom = molrange(2, imol)
         totmass = totmass + sum(mass(latom:uatom))*au_kg
      end do
      ! lambda_th : the thermal wavelength
      lambda_th = planck/sqrt(2.0d0*pi*totmass*boltzmann*temperature)
      volum = avogadro*boltzmann*temperature/atm2pascal
      entropy_stra = avogadro*boltzmann*(2.5d0 - log(avogadro*lambda_th**3.0d0/volum))
   end subroutine nma_traentropy

   subroutine nma_rotentropy(tpmolarray, tpeigenvector)
      use ambertop, only: nowcoor, mass
      use pubmod, only: errormsg,pubmod_get_getinerialaxis

      integer, intent(in) :: tpmolarray(:)
      real*8, optional :: tpeigenvector(3, 3)
      integer :: imol, i, iatom, icoor, latom, uatom
      real*8, parameter :: a_meter = 1.0d-10
      real*8 :: sigma, theta_r(3), tp, imom(3), centroid(3), cencoor(3, natom), imomatrix(6)
      real*8 :: x2, y2, z2, xy, xz, yz, totmass, tpmass, tpmat(3,3)

      integer :: N, liwork, lwork, LDZ, info
      integer, allocatable :: iwork(:)
      real*8, allocatable :: Z(:, :), work(:)
      character(len=1) :: JOBZ, UPLO

      totmass = 0.0d0; centroid = 0.0d0
      do i = 1, size(tpmolarray)
         imol = tpmolarray(i); if (imol == 0) cycle
         latom = molrange(1, imol); uatom = molrange(2, imol)
         totmass = totmass + sum(mass(latom:uatom))

         do iatom = latom, uatom
            tpmass = mass(iatom)
            centroid(:) = centroid(:) + tpmass*nowcoor(:, iatom)
         end do
      end do

      ! the coordinates of center of mass
      centroid = centroid/totmass
      ! write(*, '(a, 3f15.7)')'centroid', centroid

      do i = 1, size(tpmolarray)
         imol = tpmolarray(i); if (imol == 0) cycle
         latom = molrange(1, imol); uatom = molrange(2, imol)
         do iatom = latom, uatom
            cencoor(:, iatom) = nowcoor(:, iatom) - centroid(:)
         end do
      end do
      imomatrix = 0.0d0
      do i = 1, size(tpmolarray)
         imol = tpmolarray(i); if (imol == 0) cycle
         latom = molrange(1, imol); uatom = molrange(2, imol)
         do iatom = latom, uatom
            tpmass = mass(iatom)
            x2 = cencoor(1, iatom)*cencoor(1, iatom)
            y2 = cencoor(2, iatom)*cencoor(2, iatom)
            z2 = cencoor(3, iatom)*cencoor(3, iatom)
            xy = cencoor(1, iatom)*cencoor(2, iatom)
            xz = cencoor(1, iatom)*cencoor(3, iatom)
            yz = cencoor(2, iatom)*cencoor(3, iatom)

            imomatrix(1) = imomatrix(1) + tpmass*(y2 + z2) ! Ixx
            imomatrix(3) = imomatrix(3) + tpmass*(x2 + z2) ! Iyy
            imomatrix(6) = imomatrix(6) + tpmass*(x2 + y2) ! Izz

            imomatrix(2) = imomatrix(2) - tpmass*xy        ! Ixy
            imomatrix(4) = imomatrix(4) - tpmass*xz        ! Ixz
            imomatrix(5) = imomatrix(5) - tpmass*yz        ! Iyz
         end do
      end do

      N = 3; LDZ = 3; JOBZ = 'V'; UPLO = 'U'
      lwork = 2*N*N + 6*N + 1; liwork = 3 + 5*N
      allocate (Z(N, N), work(lwork), iwork(liwork))
      call dspevd(JOBZ, UPLO, N, imomatrix, imom, Z, LDZ, work, lwork, iwork, liwork, info)
      if (info /= 0) call errormsg('dspevd info', int1=info)

      if (present(tpeigenvector)) then 
         tpeigenvector = Z
         return 
      end if 
      deallocate (Z, work, iwork)

      ! sigma : symmetry number of the molecule
      ! theta_r : rotational temperature
      ! imon : principal moments of inertia
      sigma = 1.0d0; tp = 1.0d0
      do icoor = 1, 3
         theta_r(icoor) = planck*planck/(8.0d0*pi*pi*imom(icoor)*boltzmann)
         ! unit conversion of imom from au*angstrom^2 to kg*m^2
         theta_r(icoor) = theta_r(icoor)/(au_kg*a_meter*a_meter)
         tp = tp*temperature/theta_r(icoor)
      end do
      tp = sqrt(pi)/sigma*sqrt(tp)
      entropy_srot = avogadro*boltzmann*(1.5d0 + log(tp))

   end subroutine nma_rotentropy

   subroutine nma_print_entropy(ionumber)
      integer, intent(in) :: ionumber
      integer :: iframe

      10 FORMAT(a, T18, f12.3, 3(8x, f12.3))

      do iframe = 1, ncalframe
         
         write(ionumber, '(/,90(1H=))')
         write(ionumber, '(2x,a,I4,5x,a,I4,5x,a,I4)')'Cal. Frame Index : ', iframe, 'Traj Index : ', &
                        frame_location(1,iframe), 'Snapshot Index : ', frame_location(2,iframe)
         write(ionumber, '(90(1H-))')
         write(ionumber, '(a,T23,a,11x,a,2(14x,a))')'Energy Term', 'Complex ', 'Receptor', 'Ligand', ' Delta'

         write(ionumber, 10)'TS_tra', S_tra(:, iframe)
         write(ionumber, 10)'TS_rot', S_rot(:, iframe)
         write(ionumber, 10)'TS_vib', S_vib(:, iframe)
         write(ionumber, 10)'TS_tot(t+r+v)', S_tot(:, iframe)
      end do
      
   end subroutine nma_print_entropy

   subroutine nma_print_totalentropy(ionumber)
      integer, intent(in) :: ionumber
      integer :: iframe

      ! 11 FORMAT(a, T17, f10.4, 13x, f10.4, 10x, f10.4, 10x, f10.4)
      11 FORMAT(a, T18, f12.3, 3(8x, f12.3))

      if (ionumber == 6) then 
         write(ionumber, '(/,90(1H=))')
         write(ionumber, '(20x,a,1x,I0,1x,a)')'Summary data for all', ncalframe, 'frames'
         write(ionumber, '(90(1H-))')
         write(ionumber, '(a)')'Average'
         write(ionumber, '(a,T23,a,11x,a,2(14x,a))')'Energy Term', 'Complex ', 'Receptor', 'Ligand', ' Delta'
         write(ionumber, 11)'TS_tra', S_tra(:, ncalframe + 1)
         write(ionumber, 11)'TS_rot', S_rot(:, ncalframe + 1)
         write(ionumber, 11)'TS_vib', S_vib(:, ncalframe + 1)
         write(ionumber, 11)'TS_tot(t+r+v)', S_tot(:, ncalframe + 1)
      end if 

      if (ncalframe > 1 .and. ionumber /= 6) then 
         write(ionumber, '(/,90(1H=))')
         write(ionumber, '(20x,a,1x,I0,1x,a)')'Summary data for all', ncalframe, 'frames'
         write(ionumber, '(90(1H-))')
         write(ionumber, '(a)')'Average'
         write(ionumber, '(a,T23,a,11x,a,2(14x,a))')'Energy Term', 'Complex ', 'Receptor', 'Ligand', ' Delta'
         write(ionumber, 11)'TS_tra', S_tra(:, ncalframe + 1)
         write(ionumber, 11)'TS_rot', S_rot(:, ncalframe + 1)
         write(ionumber, 11)'TS_vib', S_vib(:, ncalframe + 1)
         write(ionumber, 11)'TS_tot(t+r+v)', S_tot(:, ncalframe + 1)

         write(ionumber, '(/,a)')'Std Dev'
         write(ionumber, '(a,T23,a,11x,a,2(14x,a))')'Energy Term', 'Complex ', 'Receptor', 'Ligand', ' Delta'
         write(ionumber, 11)'TS_tra', S_tra(:, ncalframe + 2)
         write(ionumber, 11)'TS_rot', S_rot(:, ncalframe + 2)
         write(ionumber, 11)'TS_vib', S_vib(:, ncalframe + 2)
         write(ionumber, 11)'TS_tot(t+r+v)', S_tot(:, ncalframe + 2)
      end if 

   end subroutine nma_print_totalentropy

   subroutine nma_print_time_info(ionumber)
      integer, intent(in) :: ionumber
      integer :: iframe, nday, nhour, nminute, nsecond, nmillisec
      real*8 :: tptime

      write(ionumber, '(/a30,T32,11(a))') '  Start time  : ', dateinfo1(1:4), '/', dateinfo1(5:6), '/', &
                           dateinfo1(7:8), ' at ', timeinfo1(1:2), ':', timeinfo1(3:4), ':', timeinfo1(5:6)
      write(ionumber, '(a30,T32,11(a))')  '    End time  : ', dateinfo2(1:4), '/', dateinfo2(5:6), '/', &
                           dateinfo2(7:8), ' at ', timeinfo2(1:2), ':', timeinfo2(3:4), ':', timeinfo2(5:6)

      tptime = (time_stop - time_start)/1000d0
      nsecond=int(tptime); nmillisec=(tptime-nsecond)*1000
      nhour=nsecond/3600; nday=mod(nhour,24)
      nsecond=mod(nsecond,3600); nminute=nsecond/60; nsecond=mod(nsecond,60)
      write(ionumber,"(a30,T30,i3,a,i3,a,i3,a,i4,a)") "Total calculation time  : ", nhour, " hour", &
            nminute, " min", nsecond," sec", nmillisec," msec"

   end subroutine nma_print_time_info

end module nma
