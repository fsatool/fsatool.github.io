module qha
   use pubmod, only : icuda
   use ambertop; use normaldata
   use nma, only : hessianline
   implicit none
   real*8, dimension(:, :), allocatable :: allcoor
   integer :: nqhaframe

contains 

   subroutine qha_go(parmfile)
      use pubmod, only : pubmod_read_traj
      use struct; use cudatop
      use nma, only : nma_initialize, nma_finish, nma_print_entropy, nma_print_time_info, nma_print_totalentropy
      implicit none
      character(len=*), intent(in) :: parmfile
      integer :: ifile, ierr, iframe

      call time_from_1970(time_start); call date_and_time(DATE=dateinfo1, TIME=timeinfo1)
      call nma_initialize(parmfile)

      nqhaframe = 0
      do ifile = 1, maxntraj
         if (trim(trajfiles(ifile)) == "") exit
         do while (.true.)
            call pubmod_read_traj(trajfiles(ifile), natom, nowcoor, ierr)
            if (ierr < 0) exit
            nqhaframe = nqhaframe + 1
            if ( nqhaframe <= skipinitdata ) cycle
            if ( skipdata > 0 .and. mod(nqhaframe-skipinitdata,skipdata+1) /= 1 ) cycle
         end do
      end do
      allocate (allcoor(ndegree, nqhaframe)); allcoor = 0.0d0

      iframe = 0
      do ifile = 1, maxntraj
         if (trim(trajfiles(ifile)) == "") exit
         do while (.true.)
            call pubmod_read_traj(trajfiles(ifile), natom, nowcoor, ierr)
            if (ierr < 0) exit
            iframe = iframe + 1
            if ( iframe <= skipinitdata ) cycle
            if ( skipdata > 0 .and. mod(iframe-skipinitdata,skipdata+1) /= 1 ) cycle
            ! print "(6(f12.6))", nowcoor(:, 1:natom)
            if ( imin /= 0 ) then
               if ( procid == 0) print "(a)", 'Optimizing structure'
               call struct_minimize(1000, 500, 0.0001d0, 200)
            end if
            allcoor(:, iframe) = reshape( nowcoor, (/ ndegree /) )
            if (procid == 0) print "(a,I4)", 'Doing calculation on frame : ', iframe
            call qha_entropy_calculation(iframe)

         end do
      end do

      call qha_calculation()
      call date_and_time(DATE=dateinfo2, TIME=timeinfo2); call time_from_1970(time_stop)
      ncalframe = 1; frame_location = 0
      call nma_print_entropy(nmaoutfile); call nma_print_entropy(6)
      ! call nma_print_totalentropy(nmaoutfile); call nma_print_totalentropy(6)
      call nma_print_time_info(nmaoutfile); call nma_print_time_info(6)

      call nma_finish(); deallocate(allcoor)

   end subroutine qha_go

   subroutine qha_entropy_calculation(iframe)
      use nma, only : nma_rotentropy
      integer, intent(in) :: iframe

      if (sum(commolarray) /= 0) then
         call nma_rotentropy(commolarray)
         S_rot(1, iframe) = entropy_srot*temperature*joule2kcal
      end if 

      if (sum(recmolarray) /= 0) then
         call nma_rotentropy(recmolarray)
         S_rot(2, iframe) = entropy_srot*temperature*joule2kcal
      end if 

      if (sum(ligmolarray) /= 0) then
         call nma_rotentropy(ligmolarray)
         S_rot(3, iframe) = entropy_srot*temperature*joule2kcal
      end if 

   end subroutine qha_entropy_calculation

   subroutine qha_getndegree(tpmolarray)
      integer, intent(in) :: tpmolarray(:)
      integer :: imol
      ndegree = 0
      do imol = 1, size(tpmolarray)
         if (tpmolarray(imol) /= 0) ndegree = ndegree + &
                              molrange(2, tpmolarray(imol)) - molrange(1, tpmolarray(imol)) + 1
      end do
      ndegree = ndegree*3; nhessian = ndegree*(ndegree + 1)/2
   end subroutine qha_getndegree

   subroutine qha_calculation(ninframe)
      use nma, only : nma_geteigenvalues, nma_entropy
      integer, intent(in), optional :: ninframe
      integer :: i, j, ihessian, ieigen, iframe
      real*8 :: average(ndegree) 

      if (present(ninframe)) nqhaframe = ninframe
      print*, 'nqhaframe', nqhaframe
      if (nqhaframe < 2) stop 'QHA frame number is smaller than 2'
      do i = 1, ndegree
         average(i) = sum(allcoor(i, 1:nqhaframe))/real(nqhaframe)
      end do

      do i = 1, ndegree
         do j = 1, i
            ihessian = (i - 1)*i/2 + j
            hessianline(ihessian) = qha_getcovariance(i, j, average)
         end do
      end do

      iframe = 1
      100   FORMAT(a, T20, f15.4)
      if (sum(commolarray) /= 0) then
         call qha_getndegree(commolarray)
         call qha_geteigenvalues(commolarray)
         S_tra(1, iframe) = entropy_stra; S_vib(1, iframe) = entropy_svib
         S_rot(1, iframe) = sum(S_rot(1, 1:nqhaframe))/nqhaframe 
         S_tot(1, iframe) = S_tra(1, iframe) + S_rot(1, iframe) + S_vib(1, iframe)
         if (neigens > 0) call normaldata_write_eigendata(1, 1, freq=frequencies, istart=freqstart)

      end if

      if (sum(recmolarray) /= 0) then
         call qha_getndegree(recmolarray)
         call qha_geteigenvalues(recmolarray)
         S_tra(2, iframe) = entropy_stra; S_vib(2, iframe) = entropy_svib
         S_rot(2, iframe) = sum(S_rot(2, 1:nqhaframe))/nqhaframe 
         S_tot(2, iframe) = S_tra(2, iframe) + S_rot(2, iframe) + S_vib(2, iframe)
      end if

      if (sum(ligmolarray) /= 0) then
         call qha_getndegree(ligmolarray)
         call qha_geteigenvalues(ligmolarray)
         S_tra(3, iframe) = entropy_stra; S_vib(3, iframe) = entropy_svib
         S_rot(3, iframe) = sum(S_rot(3, 1:nqhaframe))/nqhaframe 
         S_tot(3, iframe) = S_tra(3, iframe) + S_rot(3, iframe) + S_vib(3, iframe)
      end if
      ! calculate the delta entropy
      S_tra(4, iframe) = S_tra(1, iframe) - S_tra(2, iframe) - S_tra(3, iframe)
      S_rot(4, iframe) = S_rot(1, iframe) - S_rot(2, iframe) - S_rot(3, iframe)
      S_vib(4, iframe) = S_vib(1, iframe) - S_vib(2, iframe) - S_vib(3, iframe)
      S_tot(4, iframe) = S_tot(1, iframe) - S_tot(2, iframe) - S_tot(3, iframe)

   end subroutine qha_calculation

   function qha_getcovariance(i, j, average)
      integer, intent(in) :: i, j
      real*8, intent(in) :: average(:)
      real*8 :: tpsum, qha_getcovariance
      integer :: k, iatom, jatom
      tpsum = 0.0d0
      do k = 1, nqhaframe
         tpsum = tpsum + allcoor(i, k)*allcoor(j, k)
      end do

      iatom = ceiling(real(i)/3.0d0); jatom = ceiling(real(j)/3.0d0)
      qha_getcovariance = tpsum/real(nqhaframe) - average(i)*average(j)
      qha_getcovariance = sqrt(mass(iatom))*qha_getcovariance*sqrt(mass(jatom))

   end function qha_getcovariance

   subroutine qha_geteigenvalues(tpmolarray)
      use pubmod, only: errormsg
      use cudanma, only: frequencies
      use nma, only: nma_entropy, nma_traentropy, nma_rotentropy, nma_unit_conversion

      integer, intent(in) :: tpmolarray(:)
      integer :: i, j, k, iline, ihessian
      real*8 :: tphessianline(nhessian)
      ! varibles for dspevd function
      integer :: N, liwork, lwork, LDZ, info, ieigen, tpstart, tpend
      integer :: lindex, uindex, imol
      logical :: iin, jin
      integer, allocatable :: iwork(:)
      real*8, allocatable :: Z(:, :), work(:)
      character(len=1) :: JOBZ, UPLO

      N = ndegree; LDZ = ndegree; JOBZ = 'V'; UPLO = 'U'
      lwork = 2*N*N + 6*N + 1; liwork = 3 + 5*N
      allocate (Z(N, N), work(lwork), iwork(liwork))
      iline = 0; tphessianline = 0.0d0
      do i = 1, 3*natom; do j = 1, i
         iin = .false.; jin = .false.
         do k = 1, size(tpmolarray)
            imol = tpmolarray(k)
            if (imol == 0) cycle
            lindex = 3*molrange(1, imol) - 2; uindex = 3*molrange(2, imol)
            if (i >= lindex .and. i <= uindex) iin = .true.
            if (j >= lindex .and. j <= uindex) jin = .true.
            if (iin .and. jin) then
               ihessian = (i - 1)*i/2 + j; iline = iline + 1
               tphessianline(iline) = hessianline(ihessian)
               exit
            end if
         end do
      end do; end do
      call dspevd(JOBZ, UPLO, N, tphessianline, frequencies, Z, LDZ, work, lwork, iwork, liwork, info)
      if (info /= 0) call errormsg('dspevd info', int1=info)

      call normaldata_unit_conversion(tpmolarray, Z)
      if ( procid == 0 ) print "(a, 2I6)", 'Vibrational modes range :', freqstart, ndegree
      call nma_entropy(tpmolarray)

      ! --- Translational entropy calculation
      call nma_traentropy(tpmolarray)
      call nma_unit_conversion()

   end subroutine qha_geteigenvalues

end module qha
