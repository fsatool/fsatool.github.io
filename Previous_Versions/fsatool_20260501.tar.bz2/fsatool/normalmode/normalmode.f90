program normalmode
   use mpi; use public
   use pubmod, only : procid, procnum
   use normaldata, only: nmaoutfile, casemode
   use anm, only: anm_go
   use nma, only: nma_go
   use qha, only: qha_go
   implicit none
   integer :: ierr
   character*150 :: command, command2, command3, outfile

   call mpi_init(ierr)
   call mpi_comm_rank(mpi_comm_world, procid, ierr)
   call mpi_comm_size(mpi_comm_world, procnum, ierr)
   call InitalizeSharedMemory()

   ! call copyright()
   parmfile = 'nma.in'; outfile = 'nma.out'
   call get_command_argument(1, command)
   call get_command_argument(2, command2)
   if (trim(command2) == "-i") then
      call get_command_argument(3, parmfile); call checkfile(parmfile)
   end if

   call get_command_argument(4, command3)
   if (trim(command3) == "-o") then
      call get_command_argument(5, outfile)
   end if

   open (NewUnit=nmaoutfile, file=trim(outfile), status='replace')

   select case (trim(command))
   case ("anm")
      casemode = 0
      if (parmfile == "") parmfile = "anm.in"
      call anm_go(parmfile)
   case ("nma")
      casemode = 1
      if (parmfile == "") parmfile = "nma.in"
      call nma_go(parmfile)
   case ('qha')
      casemode = 2
      if (parmfile == "") parmfile = "qha.in"
      call qha_go(parmfile)
   case default
      print *, "wrong command ", trim(command); stop
   end select

   close (nmaoutfile)

   call mpi_finalize(ierr)
end program
