module normaldata
   use public
   use pubmod, only: icuda, pi, avogadro, boltzmann, planck, joule2kcal, atm2pascal, cal2joule
   implicit none
   ! atm2pascal : Standard atmospheric pressure with unit pascal
   
   integer, parameter :: maxntraj = 10
   real*8, parameter :: kcal_j = 1000d0*cal2joule
   integer :: molarray(20) = 0
   integer, allocatable, dimension(:) :: commolarray, recmolarray, ligmolarray
   integer, allocatable, dimension(:, :) :: molrange
   integer :: imin = 1
   
   integer :: skipinitdata, skipdata, ncalframe
   character*150 :: trajfiles(maxntraj),crdfile
   character*150 :: topfile

   ! (2*pi*nu)^2 = omega^2 = lambda
   ! lambda is the eigenvalues of the hessian matrix with the unit [kcal/(mol*A^2*au)]
   ! freq = nu/c = sqrt(lambda)/(2*pi*c); j/(kg*m^2) = s^-2
   ! --- unit conversion
   ! sqrt(lambda)/2*pi*c = (sqrt(kcal/(mol*A^2*au)) / (2*pi*c)
   !                     = sqrt(kcal/(g*A^2)) / (2*pi*c)
   !                     = sqrt(4184/1.0e-23)*sqrt(j/(kg*m^2)) / (6*pi*1.0e+10*(cm/s))
   !                     = sqrt(4.184)*1.0e+3 / (6*pi)
   !                     = 108.516 (cm^-1)
   real*8, parameter :: tocm_1 = sqrt(cal2joule)/(6*pi)*1.0d+3    ! unit conversion to cm^-1
   real*8, parameter ::  au_kg = 1.660539d-27         ! atom mass
   real*8, parameter :: lightspeed = 3.0d+10          ! with unit cm/s

   real*8 :: temperature, freqcut
   integer :: ndegree, neigens, nmaoutfile, nhessian
   ! integer :: imol1(2), imol2(2), nmol1, nmol2, nmol12, 
   integer :: ndegreemol, casemode
   real*8, dimension(:), allocatable :: eigenvalues, entropy_svibn
   real*8, dimension(:, :), allocatable :: eigenvectors

   real*8 :: entropy_svib = 0.0d0, entropy_stra = 0.0d0, entropy_srot = 0.0d0, time_start, time_stop
   character(len= 8) :: dateinfo1, dateinfo2
   character(len=10) :: timeinfo1, timeinfo2
   integer :: freqstart

   real*8, pointer, dimension(:, :) :: S_tra, S_rot, S_vib, S_tot
   integer, pointer, dimension(:, :) :: frame_location
   
   ! used in nma module
   real*8, allocatable, dimension(:) :: massinv, frequencies(:)

contains

   function normaldata_ifarrayequal(array1, array2)
      integer, intent(in) :: array1(:), array2(:)
      logical :: normaldata_ifarrayequal
      integer :: i

      normaldata_ifarrayequal = .false.
      if (size(array1) /= size(array2)) return
      do i = 1, size(array1) 
         if (array1(i) /= array2(i)) return
      end do
      normaldata_ifarrayequal = .true.

   end function normaldata_ifarrayequal

   subroutine normaldata_write_eigendata(isnap, itraj, resfluc, freq, istart)
      use ambertop, only : natom
      integer, intent(in), optional :: isnap, itraj
      real*8, intent(in), dimension(:), optional :: resfluc, freq
      integer, intent(in), optional :: istart
      integer :: iofile, idim, system, tpstart, tpend
      character*150 :: tpfilename, tpstr, tpstr2
      logical, save :: ifmkdir

      call getfreeunit(iofile)

      tpfilename = ""; tpstr = ""

      if (present(isnap)) then
         write (tpstr, "(i4)") isnap; tpstr = "_snap"//adjustl(tpstr)
         if (present(itraj)) then
            write (tpstr2, "(i4)") itraj; tpstr = "_traj"//trim(adjustl(tpstr2))//adjustl(tpstr)
         end if
      end if

      tpfilename = "eigens/eigens"//trim(tpstr)//".txt"
      open (file=tpfilename, unit=iofile, action="write")

      tpstart = 1; tpend = neigens
      if ( present(freq) ) then
         tpstart = istart; tpend = istart+neigens-1
      end if

      write (iofile, "(a)") "Mode Indices"
      if (casemode == 1 .or. casemode == 0) then 
         write (iofile, "(50i12)") (idim, idim=tpstart,tpend)
      else if(casemode == 2) then
         write (iofile, "(50i12)") (idim, idim=ndegree, ndegree-neigens+1, -1)
      end if 
      write (iofile, "(a)") "Eigenvalues"
      write (iofile, "(50e12.3)") eigenvalues(1:neigens)
      if (present(freq)) then
         write (iofile, "(a,f10.8,a)") "Frequencies (cm^-1) > ",freqcut," (cm^-1)"
         if (casemode == 1) then 
            write (iofile, "(50e12.3)") freq(tpstart:tpend)
         else if (casemode == 2) then 
            write (iofile, "(50e12.3)") freq(ndegree:ndegree-neigens+1:-1)
         end if 
         write (iofile, "(a,f8.3)") "Vibrational Entropy (kcal/mol), Temperature = ",temperature
         if (casemode == 1) then 
            write (iofile, "(50f12.3)") entropy_svibn(tpstart:tpend)
         else if (casemode == 2) then 
            write (iofile, "(50f12.3)") entropy_svibn(ndegree:ndegree-neigens+1:-1)
         end if 
      end if
      write (iofile, "(a)") "Eigenvectors"
      do idim = 1, ndegree
         write (iofile, "(50f12.3)") eigenvectors(idim, 1:neigens)
      end do
      close (iofile)

      if (present(resfluc)) then
         tpfilename = "res_fluc"//trim(tpstr)//".txt"
         open (file=tpfilename, unit=iofile, action="write")
         do idim = 1, size(resfluc)
            write (iofile, "(i4,f10.5)") idim, resfluc(idim)
         end do
         close (iofile)
      end if

   end subroutine

   subroutine normaldata_setmolarray(tpmolarray,ifset)
      use ambertop
      use cudagb, only : gb1maxsum_d
      use cudatop, only: bondatom_d, angleatom_d, diheatom_d, nonbond14_d, nowcoor_d, charge_d, radius_d, vdweps_d
      use parmdata, only : gb1maxsum, gb1maxsasa
      integer, intent(in) :: tpmolarray(:)
      logical, intent(in) :: ifset
      integer :: istart, iend, imol, ibond, iangle, idihe, iatom
      real*8,save :: tpgb1maxsum
      integer,allocatable,dimension(:),save :: tpatommol, tpbondatom, tpangleatom, tpdiheatom
      integer,allocatable,dimension(:,:),save :: tpnonbond14
      real*8,allocatable,dimension(:),save :: tpradius, tpcharge, tpvdweps

      if ( ifset .eqv. .true. ) then
         allocate(tpatommol(natom), tpbondatom(3*nbond), tpangleatom(4*nangle), tpdiheatom(5*ndihedral), tpnonbond14(3,nnb14))
         tpbondatom = bondatom; tpangleatom = angleatom; tpdiheatom = diheatom; tpnonbond14 = nonbond14
         allocate(tpradius(natom), tpcharge(natom), tpvdweps(natom))
         tpradius = radius; tpcharge = charge; tpvdweps = vdweps
         if ( igbsa == 1 ) then
            tpgb1maxsum=gb1maxsum; gb1maxsum = 0d0
         end if

         tpatommol=0
         do iatom=1,natom
            if ( any(atommol(iatom) == tpmolarray) ) then
               tpatommol(iatom) = 1
               if ( igbsa == 1 ) gb1maxsum = gb1maxsum + gb1maxsasa(iatom)
            end if
         end do

         if ( icuda > 0 ) then
            nowcoor_d = nowcoor; gb1maxsum_d=gb1maxsum
         end if

         do imol = 1, nmol
            if (any(tpmolarray == imol)) cycle
            istart = resindex(molindex(imol) + 1) + 1; iend = resindex(molindex(imol + 1) + 1)
            tpatommol(istart:iend) = 0
            charge(istart:iend) = 0.0d0; radius(istart:iend) = 0.0d0; vdweps(istart:iend) = 0.0d0
            if ( icuda > 0 ) then
               charge_d(istart:iend) = 0.0
               radius_d(istart:iend) = 0.0
               vdweps_d(istart:iend) = 0.0
            end if
         end do

         do ibond = 1, nbond
            if ( tpatommol(bondatom(3*ibond - 2)) == 0 ) then
               bondatom(3*ibond) = 0
               if ( icuda > 0 ) bondatom_d(3*ibond) = 0
            end if
         end do
         do iangle = 1, nangle
            if ( tpatommol(angleatom(4*iangle - 3)) == 0 ) then
               angleatom(4*iangle) = 0
               if ( icuda > 0 ) angleatom_d(4*iangle) = 0
            end if
         end do
         do idihe = 1, ndihedral
            if ( tpatommol(diheatom(5*idihe - 4)) == 0 ) then
               diheatom(5*idihe) = 0
               if ( icuda > 0 ) diheatom_d(5*idihe) = 0
            end if
         end do
         do idihe = 1, nnb14
            if ( tpatommol(nonbond14(1,idihe)) == 0 ) then
               nonbond14(3,idihe) = 0
               if ( icuda > 0 ) nonbond14_d(3,idihe) = 0
            end if
         end do

      else

         do imol = 1, nmol
            if (any(tpmolarray == imol)) cycle
            istart = resindex(molindex(imol) + 1) + 1; iend = resindex(molindex(imol + 1) + 1)
            charge(istart:iend) = tpcharge(istart:iend)
            radius(istart:iend) = tpradius(istart:iend)
            vdweps(istart:iend) = tpvdweps(istart:iend)
            if ( icuda > 0 ) then
               charge_d(istart:iend) = tpcharge(istart:iend)
               radius_d(istart:iend) = tpradius(istart:iend)
               vdweps_d(istart:iend) = tpvdweps(istart:iend)
            end if
         end do

         do ibond = 1, nbond
            if ( tpatommol(bondatom(3*ibond - 2)) == 0 ) then
               bondatom(3*ibond) = tpbondatom(3*ibond)
               if ( icuda > 0 ) bondatom_d(3*ibond) = tpbondatom(3*ibond)
            end if
         end do
         do iangle = 1, nangle
            if ( tpatommol(angleatom(4*iangle - 3)) == 0 ) then
               angleatom(4*iangle) = tpangleatom(4*iangle)
               if ( icuda > 0 ) angleatom_d(4*iangle) = tpangleatom(4*iangle)
            end if
         end do
         do idihe = 1, ndihedral
            if ( tpatommol(tpdiheatom(5*idihe - 4)) == 0 ) then
               diheatom(5*idihe) = tpdiheatom(5*idihe)
               if ( icuda > 0 ) diheatom_d(5*idihe) = tpdiheatom(5*idihe)
            end if
         end do
         do idihe = 1, nnb14
            if ( tpatommol(nonbond14(1,idihe)) == 0 ) then
               nonbond14(3,idihe) = tpnonbond14(3,idihe)
               if ( icuda > 0 ) nonbond14_d(3,idihe) = tpnonbond14(3,idihe)
            end if
         end do

         if ( igbsa == 1 ) then
            gb1maxsum = tpgb1maxsum
            if ( icuda > 0 ) gb1maxsum_d = tpgb1maxsum
         end if

         deallocate(tpatommol, tpbondatom, tpangleatom, tpdiheatom, tpnonbond14)
         deallocate(tpradius, tpcharge, tpvdweps)

      end if

   end subroutine

   subroutine normaldata_hessian_1d_2d(hessianline, tphessian)
      use ambertop, only: natom, radius
      real*8, intent(in) :: hessianline(:)
      real*8, intent(inout) :: tphessian(:, :)

      integer :: i, j, iatom, jatom, ilineloc, ihessian, lindex, uindex, imol, ii, jj
      real*8 :: irad, jrad

      ilineloc = 0
      do i = 1, 3*natom
         iatom = (i-1)/3 + 1; irad = radius(iatom); if ( irad == 0d0 ) cycle
         do j = 1, i
            jatom = (j-1)/3 + 1; jrad = radius(jatom); if ( jrad == 0d0 ) cycle

            ihessian = (i - 1)*i/2 + j        ! location in Hessian matrix
            ilineloc = ilineloc + 1           ! location in Hessian line array

            ! find the root of equation: ii*(ii+1)/2 = ilineloc
            ii = floor((-1.0d0 + sqrt(1.0d0 + 8.0d0*ilineloc))/2.0d0)
            jj = ilineloc - (ii + 1)*ii/2
            if (jj == 0) then
               jj = ii
            else
               ii = ii + 1
            end if

            tphessian(ii, jj) = hessianline(ihessian)
            if (ii /= jj) tphessian(jj, ii) = tphessian(ii, jj)

        end do
      end do
      if (ilineloc /= nhessian) stop 'error index of hessian matrix'

   end subroutine normaldata_hessian_1d_2d

   ! convert the frequencies to unit of cm^-1
   subroutine normaldata_unit_conversion(tpmolarray, tpeigenvector)
      use ambertop, only : natom, mass
      integer, intent(in) :: tpmolarray(:)
      real*8, intent(in) :: tpeigenvector(:,:)
      real*8 :: tpeigenvalues(3*natom)
      integer :: ieigen, tpstart, tpend

      tpeigenvalues = frequencies; freqstart = 0
      do ieigen = 1, ndegree
         ! (2*pi*nu)^2 = omega^2 = lambda
         ! lambda is the eigenvalues of the hessian matrix with the unit [kcal/(mol*A^2*au)]
         ! freq = nu/c = sqrt(lambda)/(2*pi*c); j/(kg*m^2) = s^-2
         ! --- unit conversion
         ! sqrt(lambda)/2*pi*c = (sqrt(kcal/(mol*A^2*au)) / (2*pi*c)
         !                     = sqrt(kcal/(g*A^2)) / (2*pi*c)
         !                     = sqrt(4184/1.0e-23)*sqrt(j/(kg*m^2)) / (6*pi*1.0e+10*(cm/s))
         !                     = sqrt(4.184)*1.0e+3 / (6*pi)
         !                     = 108.516 (cm^-1)
         if ( frequencies(ieigen) > 0 ) then

            if (casemode == 1) then 
               frequencies(ieigen) = tocm_1*sqrt(frequencies(ieigen))
               if ( freqstart == 0 .and. frequencies(ieigen) > freqcut .and. ieigen > 6 ) freqstart = ieigen
            else if (casemode == 2) then
               frequencies(ieigen) = tocm_1*sqrt((boltzmann*temperature*avogadro)/(kcal_j*frequencies(ieigen)))
               if ( freqstart == 0 .and. frequencies(ieigen) > freqcut .and. ieigen > 6 ) freqstart = ieigen
            end if 
            
         end if
      end do

      if (normaldata_ifarrayequal(tpmolarray, commolarray) .and. neigens > 0) then
         tpstart = freqstart; tpend = tpstart + neigens - 1
         if (tpend > ndegree) then
            print "(a,I4)", 'Warning : valid vibmode is smaller than neigens, neigens auto set to :', ndegree - freqstart + 1
            neigens = ndegree - freqstart + 1; tpend = ndegree
         end if 
         if (casemode == 1) then
            eigenvalues(1:neigens) = tpeigenvalues(tpstart:tpend)
            eigenvectors(:, 1:neigens) = tpeigenvector(:, tpstart:tpend)
         else 
            eigenvalues(1:neigens) = tpeigenvalues(ndegree:ndegree-neigens+1:-1)
            eigenvectors(:, 1:neigens) = tpeigenvector(:, ndegree:ndegree-neigens+1:-1)
         end if 

         if (casemode == 2) then 
            do ieigen = 1, ndegree, 3
               eigenvectors(ieigen:ieigen + 2, :) = eigenvectors(ieigen:ieigen + 2, :)/sqrt(mass(ceiling(ieigen/3.0d0)))
            end do 
         end if 
      end if

   end subroutine normaldata_unit_conversion

end module
