! Reference

! A. R. Atilgan, S. R. Durell, R. L. Jernigan, M. C. Demirel, O. Keskin, and I. Bahar
! Anisotropy of Fluctuation Dynamics of Proteins with an Elastic Network Model.
! Biophys. J. 2001, 80: 505-515

module anm
   use normaldata
   use pubmod
   implicit none

contains

   subroutine anm_go(parmfile)
      implicit none
      character(len=*), intent(in) :: parmfile
      real*8, allocatable, dimension(:) :: work, eigenval, resfluctuation
      integer, allocatable, dimension(:) :: isuppz, iwork
      real*8, allocatable, dimension(:, :) :: matrix, alphacoor, eigenvec
      integer :: i, j, k, m, iofile, ierr, info, tempi, tempj, system
      real*8 :: dissq, tpvec(3), tpmat(3, 3), stiffness, discut, dx, dy, dz
      character*150 :: pdbfile, topfile

      namelist /anm/ pdbfile, neigens, discut, stiffness

      neigens = 0; discut = 100000.0d0; stiffness = 1.0d0; kelvin0 = 298.0d0

      call getfreeunit(iofile); open (unit=iofile, file=parmfile, action="read")
      read (iofile, nml=anm, iostat=ierr)
      if (ierr /= 0) call errormsg("Cannot find the anm namelist")
      close (iofile)

      if (pdbfile /= "") then
         call pubmod_read_pdb_file(pdbfile, "calpha", selectcoor=alphacoor, resnum=nres)
      else if (topfile /= "") then
         ! call pubmod_read_top_file(topfile,"calpha",resnum=nres,totatomnum=natom,atomnum=atomnum,atomindex=atomindex,resindex=resatomindex)
         call pubmod_read_top_file(topfile, "calpha", resnum=nres)
      else
         stop "wrong input pdb or topology file"
      end if

      if ((neigens == 0) .or. (neigens > (3*nres - 6))) neigens = 3*nres - 6

      print "(a)", "Anisotropic network model analysis"
      print "(/,a,a)", "input file                 : ", trim(pdbfile)
      print "(a,i10)", "residue number             : ", nres
      print "(a,f10.1)", "distance cutoff            : ", discut
      print "(a,f10.1)", "stiffness                  : ", stiffness
      print "(a,i10,/)", "applying first eigen modes : ", neigens

      ierr = system("rm -rf eigens"); ierr = system("mkdir eigens")

      natom = nres
      allocate (resfluctuation(nres)); resfluctuation = 0.0d0
      allocate (eigenvectors(3*nres, neigens), eigenvalues(neigens))
      allocate (eigenvec(3*nres, 3*nres), eigenval(3*nres), matrix(3*nres, 3*nres))
      ndegree = 3*nres; eigenvectors = 0d0; eigenvalues = 0d0; matrix = 0d0
      allocate (isuppz(2*3*nres), iwork(10*3*nres), work(26*3*nres))

      ! build Hessian matrix (Eq.26)
      do i = 1, nres
         do j = i + 1, nres
            dx = alphacoor(1, i) - alphacoor(1, j)
            dy = alphacoor(2, i) - alphacoor(2, j)
            dz = alphacoor(3, i) - alphacoor(3, j)
            dissq = dx**2 + dy**2 + dz**2

            if (dissq > discut**2) cycle

            ! if ( (j-i) == 1  ) then
            !    stiffness=50.0d0
            ! else if ( (j-i) == 2 ) then
            !    stiffness=5.0d0
            ! else if ( (j-i) == 3 ) then
            !    stiffness=4.0d0
            ! else if ( (j-i) == 4 ) then
            !    stiffness=3.0d0
            ! else
            !    stiffness=1.0d0
            ! end if

            tempi = 3*i - 2; tempj = 3*j - 2
            matrix(tempi, tempj) = (-stiffness*dx*dx)/dissq
            matrix(tempi, tempj + 1) = (-stiffness*dx*dy)/dissq
            matrix(tempi, tempj + 2) = (-stiffness*dx*dz)/dissq
            matrix(tempi + 1, tempj + 1) = (-stiffness*dy*dy)/dissq
            matrix(tempi + 1, tempj + 2) = (-stiffness*dy*dz)/dissq
            matrix(tempi + 2, tempj + 2) = (-stiffness*dz*dz)/dissq

            matrix(tempi + 1, tempj) = matrix(tempi, tempj + 1)
            matrix(tempi + 2, tempj) = matrix(tempi, tempj + 2)
            matrix(tempi + 2, tempj + 1) = matrix(tempi + 1, tempj + 2)

            do k = tempi, tempi + 2
               do m = tempj, tempj + 2
                  matrix(m, k) = matrix(k, m)
               end do
            end do

         end do
      end do

      do i = 1, 3*nres, 3
         tpmat = 0d0
         do j = 1, 3*nres, 3
            if (i == j) cycle
            do k = 1, 3
               do m = k, 3
                  tpmat(k, m) = tpmat(k, m) + matrix(i + k - 1, j + m - 1)
               end do
            end do
         end do
         do k = 1, 3
            do m = k, 3
               matrix(i + k - 1, i + m - 1) = -tpmat(k, m)
               if (k /= m) matrix(i + m - 1, i + k - 1) = -tpmat(k, m)
            end do
         end do
      end do

      call DSYEVR("V", "A", "U", 3*nres, matrix, 3*nres, 1d0, 1d0, 1, 1, 0d0, 3*nres, eigenval, eigenvec, &
                  3*nres, isuppz, work, 26*nres*3, iwork, 10*nres*3, info)
      if (info > 0) stop "eigen solver error!"

      do i = 1, neigens
         j = 3*nres - i + 1
         eigenvalues(i) = eigenval(j)
         eigenvectors(:, i) = eigenvec(:, j)
      end do

      ! calculate the root-mean-square fluctuations of residues (Eq.9)
      ! theoretical predicted fluctuations is 3*Bfactor/(8*pi*pi) (page 509)
      resfluctuation = 0.0d0
      do i = 1, nres
         dissq = 0d0
         do j = 1, 3
            do k = 1, neigens
               if (abs(eigenvalues(k)) < 1d-6) cycle
               dissq = dissq + (eigenvectors(3*(i - 1) + j, k)**2)/eigenvalues(k)
            end do
         end do
         resfluctuation(i) = (3.0d0*gasconst*kelvin0/stiffness)*dissq
      end do

      call normaldata_write_eigendata(isnap=1, itraj=1, resfluc=resfluctuation)
   end subroutine

end module
