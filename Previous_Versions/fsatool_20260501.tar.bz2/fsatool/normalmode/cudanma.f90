module cudanma
   use cudafor; use cusolverDn; use normaldata
   use cudatop, only: charge_d, radius_d, nowcoor_d, vdweps_d, bondatom_d, angleatom_d, diheatom_d
   use cudatop, only: bondeqval_d, bondforceconst_d, angleeqval_d, angleforceconst_d
   use cudatop, only: nonbond14_d, excludedatomlist_d, dihegroupindex_d
   use cudatop, only: dihephase_d, diheperiod_d, diheforceconst_d, scale14vdw_d, scale14elec_d
   use cudagb, only: fsrho_d, radoff_d, radeff_d, gb1alpha_d, gb1beta_d, gb1gamma_d, &
                     igb_d, igbsa_d, surften_d, gb1cutoff_d, gb1sigma_d, gb1epsilon_d

   implicit none

   integer, parameter :: SP = SELECTED_REAL_KIND(4), DP = SELECTED_REAL_KIND(8)
   integer, parameter :: SD = SP
   integer, parameter :: warpsize = 32

   integer, device, allocatable, dimension(:) :: nonbondedparmindex_d
   real(kind=SD), device, allocatable, dimension(:) :: vdwacoef_d, vdwbcoef_d

   ! constant variables
   real(kind=SD), constant :: unitmatrix_c(3, 3) = &
                  reshape((/1.0_SD, 0.0_SD, 0.0_SD, 0.0_SD, 1.0_SD, 0.0_SD, 0.0_SD, 0.0_SD, 1.0_SD/), (/3, 3/))
   integer, constant :: natom_c, nbond_c, nangle_c, ndihegroup_c, nnb14_c, nnb_c, nvdwtype_c, ndegree_c
   integer :: nblockbond, nblockangle, nblockdihe, nblock14, nblocknb, nblockatom

   ! atom information: radius, mass, Coordinates, Frequences and hessian matrix/Line
   real(kind=SD), device, allocatable :: massinv_d(:)
   real(kind=DP), device, allocatable, target :: hessianline_d(:) 
   real(kind=DP), texture, pointer :: hessianline_t(:), nowcoor_t(:, :)

   real(kind=DP), device, allocatable, target :: Freq_d(:)
   real(kind=DP), texture, pointer :: Freq_t(:)

   integer, device, allocatable, dimension(:) :: typeindex_d
   integer, device, allocatable, dimension(:, :) :: blockpos_d, blockskip_d
 
   ! Generalized Born

   real(kind=SD), constant :: gb1watrad_c, gbneckmat_c(21, 21), gb1dmat_c(21, 21)
   real(kind=SD), constant :: discut2_c, epsoutinv_c, epsilon_c, kappa_c, gbdiscut_c, gbdiscut2_c
   real(kind=DP), device, allocatable, dimension(:, :), private :: dradeffdI_d, nabla_d
   real(kind=DP), device, allocatable, dimension(:, :, :), private :: nablaij_d

   interface cudanma_storehessian
      module procedure cudanma_storehessian_ij, cudanma_storehessian_i
   end interface cudanma_storehessian
   interface cudanma_dgemm
      module procedure cudanma_dgemm1, cudanma_dgemm3
   end interface cudanma_dgemm
   interface cudanma_GB_nablaEffBorn
      module procedure cudanma_GB_nablaEffBorn_k, cudanma_GB_nablaEffBorn_l
   end interface cudanma_GB_nablaEffBorn

contains

   subroutine cudanma_initialize()
      use ambertop, only: typeindex, excludedatomlist, nexcludedatoms, nonbond14, nangletype, ndihetype
      use ambertop, only: radius, charge, discut, vdwacoef, vdwbcoef, scale14vdw, scale14elec, nbondtype
      use ambertop, only: natom, nbond, nangle, ndihedral, ndihegroup, nnb14, nnb, nvdwtype, mass, igb, igbsa
      use ambertop, only: bondatom, bondeqval, bondforceconst, angleatom, angleeqval, angleforceconst
      use ambertop, only: diheatom, dihephase, diheperiod, diheforceconst, dihegroupindex, nonbondedparmindex, surften
      use gb, only: epsin, epsout, gbdiscut, kappa, fsrho, radoff, fsrhomax
      use parmdata, only: gb1watrad, gb1sneck, gb1mmat, gb1dmat, gb1alpha, gb1beta, gb1gamma, gb1cutoff, gb1sigma, gb1epsilon
      implicit none
      integer(8) :: h_meig
      integer :: excludedatomindex(natom + 1)
      integer, device :: excludedatomindex_d(natom + 1)
      integer, allocatable, dimension(:, :) :: blockpos

      allocate (hessianline_d(ndegree*(ndegree + 1)/2)); hessianline_d = 0.0_DP
      allocate (Freq_d(ndegree)); Freq_d = 0.0_DP; Freq_t => Freq_d

      allocate (nowcoor_d(3, natom), radius_d(natom), massinv_d(natom))
      natom_c = natom; radius_d = radius; massinv_d = massinv
      nowcoor_t => nowcoor_d; hessianline_t => hessianline_d

      ! Initial constant variables
      nbond_c = nbond; nangle_c = nangle; ndihegroup_c = ndihegroup; ndegree_c = ndegreemol
      nnb14_c = nnb14; nnb_c = nnb; nvdwtype_c = nvdwtype; discut2_c = discut**2

      ! Initial FF parameters
      allocate (bondatom_d(3*nbond), bondeqval_d(nbondtype), bondforceconst_d(nbondtype))
      bondatom_d = bondatom; bondeqval_d = bondeqval; bondforceconst_d = bondforceconst

      allocate (angleatom_d(4*nangle), angleeqval_d(nangletype), angleforceconst_d(nangletype))
      angleatom_d = angleatom; angleeqval_d = angleeqval; angleforceconst_d = angleforceconst

      allocate (diheatom_d(5*ndihedral), dihephase_d(ndihetype))
      allocate (diheperiod_d(ndihetype), diheforceconst_d(ndihetype))
      diheperiod_d = diheperiod; diheforceconst_d = diheforceconst
      diheatom_d = diheatom; dihephase_d = dihephase
      dihegroupindex_d = dihegroupindex

      allocate (charge_d(natom), nonbond14_d(3, nnb14), typeindex_d(natom))
      allocate (vdwacoef_d(nvdwtype*(nvdwtype + 1)/2 + 1), scale14vdw_d(ndihetype))
      allocate (vdwbcoef_d(nvdwtype*(nvdwtype + 1)/2 + 1), scale14elec_d(ndihetype))
      allocate (excludedatomlist_d(nnb), nonbondedparmindex_d(nvdwtype*nvdwtype))
      excludedatomlist_d = excludedatomlist; nonbondedparmindex_d = nonbondedparmindex
      charge_d = charge; nonbond14_d = nonbond14; typeindex_d = typeindex
      vdwbcoef_d = vdwbcoef; scale14elec_d = scale14elec
      vdwacoef_d = vdwacoef; scale14vdw_d = scale14vdw

      if ( igb == 0 ) igbsa = 0
      igb_d = igb; igbsa_d = igbsa; surften_d = surften

      ! Initial parameters used in Generalized Born model
      if ( igb == 1 ) then
         epsoutinv_c = 1.0_SD/epsout; epsilon_c = epsout/epsin; kappa_c = kappa
         gbdiscut_c = gbdiscut; gb1watrad_c = gb1watrad
         allocate (fsrho_d(natom), radeff_d(natom), radoff_d(natom), dradeffdI_d(2, natom))
         allocate (gb1alpha_d(natom), gb1beta_d(natom), gb1gamma_d(natom))
         radeff_d = 0.0_DP; dradeffdI_d = 0.0_DP
         fsrho_d = fsrho; radoff_d = radoff; gbneckmat_c = gb1sneck*gb1mmat; gb1dmat_c = gb1dmat
         gb1alpha_d = gb1alpha; gb1beta_d = gb1beta; gb1gamma_d = gb1gamma; gbdiscut2_c = (gbdiscut + fsrhomax)**2
         allocate(nabla_d(3,natom),nablaij_d(3,3,natom)); nabla_d = 0.0_DP; nablaij_d = 0.0_DP

         if ( igbsa == 1 ) then
            allocate(gb1cutoff_d(natom),gb1sigma_d(natom),gb1epsilon_d(natom))
            gb1cutoff_d = gb1cutoff; gb1sigma_d = gb1sigma; gb1epsilon_d = gb1epsilon
         end if
      end if

      ! Calculate block numbers
      nblockbond = (nbond - 1)/warpsize + 1; nblockangle = (nangle - 1)/warpsize + 1
      ! nblockdihe = (ndihedral - 1)/warpsize + 1; nblock14 = (nnb14 - 1)/warpsize + 1
      nblockdihe = (ndihegroup - 1)/warpsize + 1; nblock14 = (nnb14 - 1)/warpsize + 1
      nblockatom = (natom - 1)/warpsize + 1; nblocknb = nblockatom*(nblockatom + 1)/2

      ! Initial atoms begin in each block
      allocate (blockpos_d(2, nblocknb), blockpos(2, nblocknb)); blockpos = 0
      do h_meig = 2, nblocknb
         blockpos(1, h_meig) = blockpos(1, h_meig - 1); blockpos(2, h_meig) = blockpos(2, h_meig - 1) + warpsize
         if (blockpos(2, h_meig) > natom) then
            blockpos(1, h_meig) = blockpos(1, h_meig - 1) + warpsize; blockpos(2, h_meig) = blockpos(1, h_meig)
            if (blockpos(1, h_meig) > natom) exit
         end if
      end do
      blockpos_d = blockpos; deallocate (blockpos)

      ! Initial atoms skiped in each thread
      excludedatomindex = 0; excludedatomindex_d = 0; blockskip_d = 0
      do h_meig = 1, natom
         excludedatomindex(h_meig + 1) = excludedatomindex(h_meig) + nexcludedatoms(h_meig)
      end do
      excludedatomindex_d = excludedatomindex; allocate (blockskip_d(3, nblocknb*warpsize))
      call cudanma_init_skip <<< nblocknb, warpsize >>> (excludedatomindex_d)

   end subroutine cudanma_initialize

   subroutine cudanma_finish()
      use ambertop, only: igb
      implicit none

      deallocate (hessianline_d, nowcoor_d, radius_d, massinv_d)
      deallocate (bondatom_d, bondeqval_d, angleatom_d, angleeqval_d, diheatom_d, dihephase_d)
      deallocate (bondforceconst_d, angleforceconst_d, diheperiod_d, diheforceconst_d)
      deallocate (charge_d, nonbond14_d, typeindex_d, nonbondedparmindex_d)
      deallocate (vdwacoef_d, vdwbcoef_d, scale14vdw_d, scale14elec_d)
      deallocate (excludedatomlist_d, blockskip_d, blockpos_d)
      deallocate (Freq_d)
      if (igb /= 0) then
         deallocate (fsrho_d, radeff_d, radoff_d, dradeffdI_d)
         deallocate (gb1alpha_d, gb1beta_d, gb1gamma_d)
      end if
   end subroutine cudanma_finish

   subroutine cudanma_calvibmode(tpmolarray)
      use ambertop, only: nowcoor, igb
      implicit none
      integer, intent(in) :: tpmolarray(:)
      real(kind=SD) :: tpv
      type(dim3) :: nblock3d, nthread3d

      ! ndegree = 3*natom_c
      nthread3d = dim3(16, 16, 1)
      nblock3d = dim3(ceiling(real(ndegreemol)/nthread3d%x), ceiling(real(ndegreemol)/nthread3d%y), 1)

      hessianline_t = 0d0
      call cudanma_matrix_elecvdw <<< nblocknb, warpsize >>> ()
      call cudanma_matrix_bond <<< nblockbond, warpsize >>> ()
      call cudanma_matrix_angle <<< nblockangle, warpsize >>> ()
      call cudanma_matrix_dihedral <<< nblockdihe, warpsize >>> ()
      call cudanma_matrix_elecvdw14 <<< nblock14, warpsize >>> ()
      if (igb /= 0) call cudanma_matrix_GB()

      call cudanma_massweighted <<< nblock3d, nthread3d >>> ()
      call cudanma_geteigenvalues(tpmolarray)
   end subroutine cudanma_calvibmode

   subroutine cudanma_geteigenvalues(tpmolarray)
      use pubmod, only: errormsg, procid
      use cusolverDn
      implicit none
      integer, intent(in) :: tpmolarray(:)
      integer(4), device :: devinfo
      integer(8) :: h_meig
      integer(4) :: info
      logical :: iin, jin
      real(kind=DP) :: tphessian(ndegree, ndegree), hessianline(ndegreemol*(ndegreemol+1)/2)
      real(kind=DP), device :: tphessian_d(ndegree, ndegree)

      ! variables related to cuSolver
      type(cudaDataType) :: dataType; ! integer(cuda_stream_kind) :: stream
      type(cusolverDnParams) :: params; type(cusolverDnHandle) :: cusolverH
      integer(4), parameter :: jobz = CUSOLVER_EIG_MODE_VECTOR, &
                               range = CUSOLVER_EIG_RANGE_ALL, uplo = CUBLAS_FILL_MODE_UPPER
      integer(8) :: workspaceInBytesOnDevice, workspaceInBytesOnHost
      integer(1), allocatable, dimension(:), device :: bufferOnDevice
      integer(1), allocatable, dimension(:) :: bufferOnHost
      integer :: tpstart, tpend, ieigen, i

      ! copy data on CPU
      hessianline = hessianline_d
      call normaldata_hessian_1d_2d(hessianline, tphessian)
      tphessian_d = tphessian

      ! Initial CUSOLVER for cusolverDnXsyevdx
      call CUSOLVER_CHECK(cusolverDnCreate(cusolverH))
      call CUSOLVER_CHECK(cusolverDnCreateParams(params))
      ! call CUSOLVER_CHECK(cusolverDnSetAdvOptions(params, CUSOLVERDN_GETRF, CUSOLVER_ALG_1))
      ! h_meig = cudaStreamCreateWithFlags(stream, cudaStreamNonBlocking)
      ! call CUSOLVER_CHECK(cusolverDnSetStream(cusolverH, stream))

      !if (SD == SP) then
      !   dataType = cudaDataType(CUDA_R_32F)
      !else if (SD == DP) then
      dataType = cudaDataType(CUDA_R_64F)
      !end if
      workspaceInBytesOnHost = 0; workspaceInBytesOnDevice = 0
      call CUSOLVER_CHECK(cusolverDnXsyevdx_buffersize(cusolverH, params, jobz, range, uplo, ndegree, dataType, &
                                 tphessian_d, ndegree, 0.0_DP, 0.0_DP, 1, ndegree, h_meig, dataType, Freq_t, &
                                 dataType, workspaceInBytesOnDevice, workspaceInBytesOnHost))
      ! print*, 'size cusolver', workspaceInBytesOnDevice, workspaceInBytesOnHost
      allocate (bufferOnDevice(workspaceInBytesOnDevice), bufferOnHost(workspaceInBytesOnHost))
      if ( procid == 0) print "(a)", 'Calculating eigenvalues of Hessian matrix on GPU'
      call CUSOLVER_CHECK(cusolverDnXsyevdx(cusolverH, params, jobz, range, uplo, ndegree, dataType, &
                                 tphessian_d, ndegree, 0.0_DP, 0.0_DP, 1, ndegree, h_meig, dataType, Freq_t, &
                                 dataType, bufferOnDevice, workspaceInBytesOnDevice, bufferOnHost, &
                                 workspaceInBytesOnHost, devinfo))

      info = devinfo
      if (info < 0) then
         call errormsg('cusolverDnXsyevdx info', int1=-info, &
                       str1="the i-th parameter is wrong (not counting handle).")
      else if (info > 0) then
         call errormsg('cusolverDnXsyevdx info', int1=info, &
            str1="i off-diagonal elements of an intermediate tridiagonal form did not converge to zero.")
      end if

      frequencies = Freq_d; tphessian = tphessian_d

      call normaldata_unit_conversion(tpmolarray, tphessian)

      deallocate (bufferOnDevice, bufferOnHost)
      call CUSOLVER_CHECK(cusolverDnDestroy(cusolverH))
      call CUSOLVER_CHECK(cusolverDnDestroyParams(params))

   end subroutine cudanma_geteigenvalues

   attributes(global) subroutine cudanma_matrix_elecvdw()
      use cudatop, only : vdweps_d, vdwsigma_d
      implicit none
      integer :: iskip, iskipstart, iskipend, skipatom, i, j, k, index, next, igbsa
      real(kind=SD) :: qi, qj, elec, coori(3), coorj(3), rij(3), tpmatrix(3, 3)
      real(kind=SD) :: ivdweps, ivdwsigma, jvdweps, jvdwsigma, igb1sigma, igb1cutoff, igb1epsilon
      real(kind=SD) :: dedr, d2edr2, dij2, dij2inv, vdwa, vdwb, jgb1sigma, jgb1cutoff, jgb1epsilon
      real(kind=SD) :: gb1epsilon, gb1sigma, dis, surften

      i = blockpos_d(1, blockidx%x) + threadidx%x; if (i > natom_c) return
      j = blockpos_d(2, blockidx%x) + threadidx%x
      next = threadidx%x + 1; skipatom = 0

      coori(1:3) = nowcoor_t(1:3, i); qi = charge_d(i)
      ivdweps = vdweps_d(i); ivdwsigma = vdwsigma_d(i)

      igbsa = igbsa_d
      if ( igbsa == 1 ) then
         surften = - 1.2_SD*surften_d
         igb1sigma = gb1sigma_d(i); igb1epsilon = gb1epsilon_d(i); igb1cutoff = gb1cutoff_d(i)
      end if

      if (j <= natom_c) then
         coorj = nowcoor_t(1:3, j); qj = charge_d(j)
         jvdweps = vdweps_d(j); jvdwsigma = vdwsigma_d(j)
         if ( igbsa == 1 ) then
            jgb1sigma = gb1sigma_d(j); jgb1epsilon = gb1epsilon_d(j); jgb1cutoff = gb1cutoff_d(j)
         end if
      end if

      index = (blockidx%x - 1)*blockdim%x + threadidx%x
      iskip = blockskip_d(1, index); iskipstart = blockskip_d(2, index); iskipend = blockskip_d(3, index)
      if (iskip > 0) skipatom = excludedatomlist_d(iskip)

      do index = 1, blockdim%x
         j = __shfl(j, next); qj = __shfl(qj, next)
         coorj(1) = __shfl(coorj(1), next); coorj(2) = __shfl(coorj(2), next)
         coorj(3) = __shfl(coorj(3), next)
         jvdweps = __shfl(jvdweps, next); jvdwsigma = __shfl(jvdwsigma, next)

         if ( igbsa == 1 ) then
            jgb1sigma = __shfl(jgb1sigma, next); jgb1epsilon = __shfl(jgb1epsilon, next); jgb1cutoff = __shfl(jgb1cutoff, next)
         end if

         if (i >= j .or. j > natom_c) cycle
         if (qi == 0.0_SD .or. qj == 0.0_SD) cycle

         if (j == skipatom) then
            iskip = iskip + 1; if (iskip > iskipend) iskip = iskipstart
            skipatom = excludedatomlist_d(iskip); cycle
         end if

         rij(1:3) = coori(1:3) - coorj(1:3); dij2 = dot_product(rij, rij)
         if (dij2 > discut2_c) cycle; dij2inv = 1.0_SD/dij2

         elec = qi*qj*sqrt(dij2inv)

         vdwa = ivdwsigma + jvdwsigma
         vdwa = vdwa**2*dij2inv; vdwa = vdwa*vdwa*vdwa
         vdwb = vdwa*ivdweps*jvdweps

         ! here dedr = de/dr * dijinv
         dedr = - ( elec + vdwb*(12.0_SD*vdwa - 6.0_SD) )*dij2inv
         d2edr2 = ( 2.0_SD*elec + vdwb*(156.0_SD*vdwa - 42.0_SD) )*dij2inv

         if ( igbsa == 1 ) then
            if ( (igb1sigma /= 0.0_SD) .and. (jgb1sigma /= 0.0_SD) ) then
               vdwb = igb1cutoff+jgb1cutoff; dis = sqrt(dij2)
               if ( dis < vdwb ) then
                  gb1sigma = igb1sigma + jgb1sigma
                  gb1epsilon = surften*sqrt( igb1epsilon*jgb1epsilon)
                  vdwa = 1.0_SD + (vdwb - dis)/gb1sigma; gb1sigma = gb1sigma*vdwa
                  vdwa=vdwa**2; vdwb=vdwa**2; vdwa=(vdwb**2)*vdwa
                  vdwa = 6.666666667_SD/vdwa; vdwb = 6.666666667_SD/vdwb
                  dedr = dedr + gb1epsilon*(vdwa-vdwb)/(gb1sigma*dis)
                  d2edr2 = d2edr2 + gb1epsilon*(11.0_SD*vdwa-5.0_SD*vdwb)/(gb1sigma*gb1sigma)
               end if
            end if
         end if

         d2edr2 = (d2edr2 - dedr)*dij2inv
         do k = 1, 3
            tpmatrix(:,k) = d2edr2*rij(k)*rij(:)
            tpmatrix(k,k) = tpmatrix(k,k) + dedr
         end do
         call cudanma_storehessian(i, tpmatrix)
         call cudanma_storehessian(j, tpmatrix)
         tpmatrix = -tpmatrix
         call cudanma_storehessian(i, j, tpmatrix)
      end do
   end subroutine cudanma_matrix_elecvdw

   attributes(global) subroutine cudanma_matrix_bond()
      implicit none
      integer :: i, j, itype, ibond, tpindex
      real(kind=SD) :: dedr, d2edr2, dij2inv, rij(3), tpmatrix(3, 3)

      ibond = (blockidx%x - 1)*blockdim%x + threadidx%x
      if (ibond > nbond_c) return
      j = 3*ibond-2; itype = bondatom_d(j+2); if (itype == 0) return
      i = bondatom_d(j); j = bondatom_d(j+1)

      d2edr2 = 2.0*bondforceconst_d(itype)
      rij(1:3) = nowcoor_t(1:3, i) - nowcoor_t(1:3, j); dij2inv = 1.0_SD/dot_product(rij, rij)

      ! dedr = de/dr * dijinv and de/dr = d2edr2*(dij - tpeqval)
      dedr = d2edr2*(1.0_SD - bondeqval_d(itype)*sqrt(dij2inv))
      d2edr2 = (d2edr2 - dedr)*dij2inv

      ! nabla_ii = [(d2e/dr2-de/dr*dijinv)*rij*(rij^T)*dij2inv + de/dr*dijinv*unitmatrix]
      ! call cudanma_dgemm(d2edr2, rij, rij, 1.0_SD, tpmatrix)
      do tpindex = 1, 3
         tpmatrix(:,tpindex) = d2edr2*rij(tpindex)*rij(:)
         tpmatrix(tpindex,tpindex) = tpmatrix(tpindex,tpindex) + dedr
      end do

      call cudanma_storehessian(i, tpmatrix)
      call cudanma_storehessian(j, tpmatrix)
      tpmatrix = -tpmatrix
      call cudanma_storehessian(i, j, tpmatrix)
   end subroutine cudanma_matrix_bond

   attributes(global) subroutine cudanma_matrix_angle()
      implicit none
      integer :: i, j, k, itype, iangle, tpindex
      real(kind=SD) :: tpdelta, tpfactor, dedcos, d2edcos2
      real(kind=SD) :: dij2inv, dkj2inv, dijinv, dkjinv, dijdkjinv, sintheta, costheta
      real(kind=SD), dimension(3, 3) :: rijrij, rkjrkj, rkjrij, nablaii, nablakk, nablaik, tpmatrix
      real(kind=SD), dimension(3) :: rij, rkj, nablaicos, nablakcos

      iangle = (blockidx%x - 1)*blockdim%x + threadidx%x
      if (iangle > nangle_c) return
      k = 4*iangle-3; itype = angleatom_d(k+3); if (itype == 0) return
      i = angleatom_d(k); j = angleatom_d(k+1); k = angleatom_d(k+2)

      rij(1:3) = nowcoor_t(1:3, i) - nowcoor_t(1:3, j); dij2inv = 1.0_SD/dot_product(rij, rij)
      rkj(1:3) = nowcoor_t(1:3, k) - nowcoor_t(1:3, j); dkj2inv = 1.0_SD/dot_product(rkj, rkj)
      dijinv = sqrt(dij2inv); dkjinv = sqrt(dkj2inv)
      dijdkjinv = dijinv*dkjinv; costheta = dot_product(rij, rkj)*dijdkjinv
      costheta = min(0.99999_SD, max(-0.99999_SD, costheta)); sintheta = sqrt(1.0_SD - costheta**2)
      tpdelta = acos(costheta) - angleeqval_d(itype); tpfactor = 2.0_SD*angleforceconst_d(itype)/sintheta
      dedcos = -tpfactor*tpdelta; d2edcos2 = tpfactor*(sintheta - tpdelta*costheta)/sintheta**2


      ! call cudanma_dgemm(dij2inv, rij, rij, 0.0_SD, rijrij)
      ! call cudanma_dgemm(dkj2inv, rkj, rkj, 0.0_SD, rkjrkj)
      ! call cudanma_dgemm(dijdkjinv, rkj, rij, 0.0_SD, rkjrij)
      do tpindex = 1, 3
         rijrij(:,tpindex) = dij2inv*rij(tpindex)*rij(:)
         rkjrkj(:,tpindex) = dkj2inv*rkj(tpindex)*rkj(:)
         rkjrij(:,tpindex) = dijdkjinv*rij(tpindex)*rkj(:)
      end do

      tpmatrix = rkjrij + transpose(rkjrij)
      nablaicos = (rkj*dkjinv - costheta*rij*dijinv)*dijinv
      nablakcos = (rij*dijinv - costheta*rkj*dkjinv)*dkjinv

      nablaii = -(tpmatrix + costheta*unitmatrix_c - 3*costheta*rijrij)*dij2inv
      nablakk = -(tpmatrix + costheta*unitmatrix_c - 3*costheta*rkjrkj)*dkj2inv
      nablaik = -(rkjrkj + rijrij - costheta*rkjrij - unitmatrix_c)*dijdkjinv

      ! call cudanma_dgemm(d2edcos2, nablaicos, nablaicos, dedcos, nablaii)
      ! call cudanma_dgemm(d2edcos2, nablakcos, nablakcos, dedcos, nablakk)
      ! call cudanma_dgemm(d2edcos2, nablakcos, nablaicos, dedcos, nablaik)
      do tpindex = 1, 3
         nablaii(:,tpindex) = d2edcos2*nablaicos(tpindex)*nablaicos(:) + dedcos*nablaii(:,tpindex)
         nablakk(:,tpindex) = d2edcos2*nablakcos(tpindex)*nablakcos(:) + dedcos*nablakk(:,tpindex)
         nablaik(:,tpindex) = d2edcos2*nablaicos(tpindex)*nablakcos(:) + dedcos*nablaik(:,tpindex)
      end do

      tpmatrix = nablaii + nablakk + nablaik + transpose(nablaik)
      call cudanma_storehessian(i, nablaii); call cudanma_storehessian(k, nablakk)
      call cudanma_storehessian(i, k, nablaik); call cudanma_storehessian(j, tpmatrix)
      tpmatrix = -(nablaii + nablaik); call cudanma_storehessian(i, j, tpmatrix)
      tpmatrix = -(nablakk + nablaik); call cudanma_storehessian(j, k, tpmatrix)
   end subroutine cudanma_matrix_angle

   ! attributes(global) subroutine cudanma_matrix_dihedral()
   !    implicit none
   !    integer :: i, j, k, l, idihe, itype, tpindex
   !    real(kind=SD) :: tpn, dedphi, d2edphi2, phi, tpcoeff, tpphase
   !    real(kind=SD) :: dkj, dkj2, dkj2inv, tlen2inv, ulen2inv, rijrkj, rlkrkj
   !    ! real(kind=SD) :: cosphi, cosphi2, cosnphi, dcosndcos
   !    real(kind=SD), dimension(3, 3) :: nablaij, nablaik, nablalj, nablalk, nablakj
   !    real(kind=SD), dimension(3, 3) :: nablaii, nablajj, nablakk, nablall, tpmatrix
   !    real(kind=SD), dimension(3) :: rij, rkj, rlk, tline, uline, nablai, nablaj, nablak, nablal, tpvec

   !    idihe = (blockidx%x - 1)*blockdim%x + threadidx%x; if (idihe > nndihedral_c) return

   !    l = 5*idihe - 4;  itype = diheatom_d(l+4); if (itype == 0) return
   !    i = diheatom_d(l); j = diheatom_d(l+1); k = diheatom_d(l+2); l = diheatom_d(l+3)

   !    ! tpn = diheperiod_d(itype)
   !    rij(1:3) = nowcoor_t(1:3, i) - nowcoor_t(1:3, j); rlk(1:3) = nowcoor_t(1:3, l) - nowcoor_t(1:3, k)
   !    rkj(1:3) = nowcoor_t(1:3, k) - nowcoor_t(1:3, j); dkj2 = dot_product(rkj, rkj)
   !    dkj2inv = 1.0_SD/(dkj2); dkj = sqrt(dkj2)
   !    rijrkj = dot_product(rij, rkj); rlkrkj = dot_product(rlk, rkj)
   !    ! Akj(here use nablakj) = unitmatrix crossdot rkj
   !    nablakj = reshape((/0.0_SD, rkj(3), -rkj(2), -rkj(3), 0.0_SD, rkj(1), rkj(2), -rkj(1), 0.0_SD/), (/3, 3/))

   !    call cudanma_Cross_Product(rij, rkj, tline); call cudanma_Cross_Product(rlk, rkj, uline)
   !    tlen2inv = 1.0_SD/dot_product(tline, tline); ulen2inv = 1.0_SD/dot_product(uline, uline)

   !    ! ------------------------------------------------------------------------------------------------
   !    ! cosphi = dot_product(tline, uline)*sqrt(tlen2inv*ulen2inv); cosphi = min(1.0_SD, max(-1.0_SD, cosphi))
   !    ! cosphi2 = cosphi**2
      
   !    ! select case (int(tpn))
   !    ! case (0); cosnphi = 1.0_SD
   !    !    dcosndcos = 0.0_SD
   !    ! case (1); cosnphi = cosphi
   !    !    dcosndcos = 1.0_SD
   !    ! case (2); cosnphi = 2.0_SD*cosphi2 - 1.0_SD
   !    !    dcosndcos = 4.0_SD*cosphi
   !    ! case (3); cosnphi = (4.0_SD*cosphi2 - 3.0_SD)*cosphi
   !    !    dcosndcos = 12.0_SD*cosphi2 - 3.0_SD
   !    ! case (4); cosnphi = 8.0_SD*(cosphi2 - 1.0_SD)*cosphi2 + 1.0_SD
   !    !    dcosndcos = 16.0_SD*(2.0_SD*cosphi2 - 1.0_SD)*cosphi
   !    ! case (5); cosnphi = ((16.0_SD*cosphi2 - 20.0_SD)*cosphi2 + 5.0_SD)*cosphi
   !    !    dcosndcos = 20.0_SD*(4.0_SD*cosphi2 - 3.0_SD)*cosphi2 + 5.0_SD
   !    ! case (6); cosnphi = (16.0_SD*(cosphi2 - 1.0_SD)*cosphi2 + 1.0_SD)*(2.0_SD*cosphi2 - 1.0_SD)
   !    !    dcosndcos = (192.0_SD*(cosphi2 - 1.0_SD)*cosphi2 + 36.0_SD)*cosphi
   !    ! case default
   !    !    stop "e"
   !    !    ! call multiple_angle_formulas(int(tpn),cosphi,cosphi2,cosnphi,dcosndcos)
   !    ! end select
   !    ! ------------------------------------------------------------------------------------------------

   !    phi = dot_product(tline, uline)*sqrt(tlen2inv*ulen2inv); phi = min(1.0_SD, max(-1.0_SD, phi))
   !    phi = sign(1.0_SD, dot_product(rij, uline)) * acos(phi)

   !    tpn = diheperiod_d(itype); tpcoeff = - tpn * diheforceconst_d(itype)
   !    tpphase = tpn * phi - dihephase_d(itype)
   !    dedphi = tpcoeff * sin(tpphase)
   !    d2edphi2 = tpn * tpcoeff * cos(tpphase)

   !    ! tpn = diheperiod_d(itype)
   !    ! d2edphi2 = -diheforceconst_d(itype)*sign(1.0, cos(dihephase_d(itype)))
   !    ! dedphi = d2edphi2*dcosndcos*sign(sqrt(1 - cosphi2), dot_product(rij, uline))
   !    ! d2edphi2 = tpn**2*d2edphi2*cosnphi

   !    ! Calculate nabla_i, nabla_j, nabla_k and nabla_l
   !    nablai = dkj*tlen2inv*tline; nablal = -dkj*ulen2inv*uline
   !    tpvec = (rijrkj*nablai + rlkrkj*nablal)*dkj2inv
   !    nablaj = tpvec - nablai; nablak = -(tpvec + nablal)

   !    ! Calculate nabla_ii and nabla_ll

   !    tpmatrix(:,1) = [1.0_SD,0.0_SD,0.0_SD]
   !    tpmatrix(:,2) = [0.0_SD,1.0_SD,0.0_SD]
   !    tpmatrix(:,3) = [0.0_SD,0.0_SD,1.0_SD]

   !    ! call cudanma_dgemm(-2.0_SD*tlen2inv, tline, tline, 1.0_SD, tpmatrix)
   !    ! call cudanma_dgemm(dkj*tlen2inv, nablakj, tpmatrix, 0.0_SD, nablaii)
   !    do tpindex = 1, 3
   !       tpmatrix(:,tpindex) = -2.0_SD*tlen2inv*tline(tpindex)*tline(:) + tpmatrix(:,tpindex)
   !    end do
   !    nablaii = dkj*tlen2inv*matmul(nablakj,tpmatrix)
   !    ! call cudanma_dgemm(dkj*tlen2inv, nablakj, tpmatrix, 0.0_SD, nablaii)

   !    tpmatrix(:,1) = [1.0_SD,0.0_SD,0.0_SD]
   !    tpmatrix(:,2) = [0.0_SD,1.0_SD,0.0_SD]
   !    tpmatrix(:,3) = [0.0_SD,0.0_SD,1.0_SD]
   !    ! call cudanma_dgemm(-2.0_SD*ulen2inv, uline, uline, 1.0_SD, tpmatrix)
   !    ! call cudanma_dgemm(-dkj*ulen2inv, nablakj, tpmatrix, 0.0_SD, nablall)
   !    do tpindex = 1, 3
   !       tpmatrix(:,tpindex) = -2.0_SD*ulen2inv*uline(tpindex)*uline(:) + tpmatrix(:,tpindex)
   !    end do
   !    nablall = -dkj*ulen2inv*matmul(nablakj,tpmatrix)

   !    ! Calculate nabla_ij, nabla_ik, nablalj and nabla_lk
   !    ! Here we calculate Transpose(nabla_ki) and Transpose(nabla_jl) instead nabla_ik and nabla_lj
   !    ! call cudanma_dgemm(1.0_SD, nablai, rkj, 0.0_SD, tpmatrix)
   !    do tpindex = 1, 3
   !       tpmatrix(:,tpindex) = rkj(tpindex)*nablai(:)
   !    end do
   !    nablaik = -(tpmatrix + rijrkj*nablaii)*dkj2inv
   !    ! call cudanma_dgemm(1.0_SD, nablal, rkj, 0.0_SD, tpmatrix)
   !    do tpindex = 1, 3
   !       tpmatrix(:,tpindex) = rkj(tpindex)*nablal(:)
   !    end do
   !    nablalj = (tpmatrix + rlkrkj*nablall)*dkj2inv
   !    nablaij = -(nablaii + nablaik); nablalk = -(nablall + nablalj)

   !    ! Calculate nabla_jj and nabla_kk by nabla_ii, nabla_ll, nabla_ij, nabla_lj, nabla_ik and nabla_lk
   !    nablajj = (rijrkj - dkj2)*nablaij + rlkrkj*nablalj
   !    tpvec = rkj - rij
   !    ! call cudanma_dgemm(1.0_SD, tpvec, nablai, 1.0_SD, nablajj)
   !    ! call cudanma_dgemm(-1.0_SD, rlk, nablal, 1.0_SD, nablajj)
   !    ! call cudanma_dgemm(2.0_SD*dkj2inv, rkj, nablaj, dkj2inv, nablajj)
   !    do tpindex = 1, 3
   !       nablajj(:,tpindex) = nablai(tpindex)*tpvec(:) + nablajj(:,tpindex)
   !       nablajj(:,tpindex) = -nablal(tpindex)*rlk + nablajj(:,tpindex)
   !       nablajj(:,tpindex) = 2.0_SD*dkj2inv*nablaj(tpindex)*rkj + dkj2inv*nablajj(:,tpindex)
   !    end do

   !    nablakk = (rijrkj)*nablaik + (rlkrkj + dkj2)*nablalk
   !    ! call cudanma_dgemm(1.0_SD, rij, nablai, 1.0_SD, nablakk)
   !    ! tpvec = rlk + rkj
   !    ! call cudanma_dgemm(1.0_SD, tpvec, nablal, 1.0_SD, nablakk)
   !    ! call cudanma_dgemm(-2.0_SD*dkj2inv, rkj, nablak, -dkj2inv, nablakk)
   !    do tpindex = 1, 3
   !       nablakk(:,tpindex) = nablai(tpindex)*rij(:) + nablakk(:,tpindex)
   !       nablakk(:,tpindex) = nablal(tpindex)*(rlk + rkj) + nablakk(:,tpindex)
   !       nablakk(:,tpindex) = -2.0_SD*dkj2inv*nablak(tpindex)*rkj(:) - dkj2inv*nablakk(:,tpindex)
   !    end do

   !    ! Calculate nabla_kj by nabla_ij, nabla_jj and nabla_lj; And nabla_il = 0
   !    nablakj = -(nablajj + nablaij + nablalj); tpmatrix = 0.0_SD
   !    ! call cudanma_dgemm(d2edphi2, nablai, nablai, dedphi, nablaii)
   !    ! call cudanma_dgemm(d2edphi2, nablaj, nablaj, dedphi, nablajj)
   !    ! call cudanma_dgemm(d2edphi2, nablak, nablak, dedphi, nablakk)
   !    ! call cudanma_dgemm(d2edphi2, nablal, nablal, dedphi, nablall)
   !    ! call cudanma_dgemm(d2edphi2, nablaj, nablai, dedphi, nablaij)
   !    ! call cudanma_dgemm(d2edphi2, nablak, nablai, dedphi, nablaik)
   !    ! call cudanma_dgemm(d2edphi2, nablaj, nablal, dedphi, nablalj)
   !    ! call cudanma_dgemm(d2edphi2, nablak, nablal, dedphi, nablalk)
   !    ! call cudanma_dgemm(d2edphi2, nablaj, nablak, dedphi, nablakj)
   !    ! call cudanma_dgemm(d2edphi2, nablal, nablai, dedphi, tpmatrix)
   !    do tpindex = 1, 3
   !       nablaii(:,tpindex) = d2edphi2*nablai(tpindex)*nablai(:) + dedphi*nablaii(:,tpindex)
   !       nablajj(:,tpindex) = d2edphi2*nablaj(tpindex)*nablaj(:) + dedphi*nablajj(:,tpindex)
   !       nablakk(:,tpindex) = d2edphi2*nablak(tpindex)*nablak(:) + dedphi*nablakk(:,tpindex)
   !       nablall(:,tpindex) = d2edphi2*nablal(tpindex)*nablal(:) + dedphi*nablall(:,tpindex)

   !       nablaij(:,tpindex) = d2edphi2*nablai(tpindex)*nablaj(:) + dedphi*nablaij(:,tpindex)
   !       nablaik(:,tpindex) = d2edphi2*nablai(tpindex)*nablak(:) + dedphi*nablaik(:,tpindex)
   !       nablalj(:,tpindex) = d2edphi2*nablal(tpindex)*nablaj(:) + dedphi*nablalj(:,tpindex)
   !       nablalk(:,tpindex) = d2edphi2*nablal(tpindex)*nablak(:) + dedphi*nablalk(:,tpindex)

   !       nablakj(:,tpindex) = d2edphi2*nablak(tpindex)*nablaj(:) + dedphi*nablakj(:,tpindex)
   !       tpmatrix(:,tpindex)= d2edphi2*nablai(tpindex)*nablal(:) + dedphi*tpmatrix(:,tpindex)
   !    end do

   !    call cudanma_storehessian(i, nablaii)
   !    call cudanma_storehessian(j, nablajj)
   !    call cudanma_storehessian(k, nablakk)
   !    call cudanma_storehessian(l, nablall)
   !    call cudanma_storehessian(i, j, nablaij)
   !    call cudanma_storehessian(i, k, nablaik)
   !    call cudanma_storehessian(l, j, nablalj)
   !    call cudanma_storehessian(l, k, nablalk)
   !    call cudanma_storehessian(k, j, nablakj)
   !    call cudanma_storehessian(i, l, tpmatrix)
   ! end subroutine cudanma_matrix_dihedral

   attributes(global) subroutine cudanma_matrix_dihedral()
      implicit none
      integer :: i, j, k, l, idihe, itype, tpindex, igroup
      real(kind=SD) :: tpn, dedphi, d2edphi2, phi, tpcoeff, tpphase
      real(kind=SD) :: dkj, dkj2, dkj2inv, tlen2inv, ulen2inv, rijrkj, rlkrkj
      real(kind=SD), dimension(3, 3) :: nablaij, nablaik, nablalj, nablalk, nablakj
      real(kind=SD), dimension(3, 3) :: nablaii, nablajj, nablakk, nablall, tpmatrix
      real(kind=SD), dimension(3) :: rij, rkj, rlk, tline, uline, nablai, nablaj, nablak, nablal, tpvec

      ! idihe = (blockidx%x - 1)*blockdim%x + threadidx%x; if (idihe > ndihegroup_c) return
      igroup = (blockidx%x - 1)*blockdim%x + threadidx%x; if (igroup > ndihegroup_c) return

      idihe = 5 * dihegroupindex_d(igroup) + 1; if (diheatom_d(idihe + 4) == 0) return
      i = diheatom_d(idihe); j = diheatom_d(idihe + 1)
      k = diheatom_d(idihe + 2); l = diheatom_d(idihe + 3)

      rij(1:3) = nowcoor_t(1:3, i) - nowcoor_t(1:3, j); rlk(1:3) = nowcoor_t(1:3, l) - nowcoor_t(1:3, k)
      rkj(1:3) = nowcoor_t(1:3, k) - nowcoor_t(1:3, j); dkj2 = dot_product(rkj, rkj)
      dkj2inv = 1.0_SD/(dkj2); dkj = sqrt(dkj2)
      rijrkj = dot_product(rij, rkj); rlkrkj = dot_product(rlk, rkj)
      ! Akj(here use nablakj) = unitmatrix crossdot rkj
      nablakj = reshape((/0.0_SD, rkj(3), -rkj(2), -rkj(3), 0.0_SD, rkj(1), rkj(2), -rkj(1), 0.0_SD/), (/3, 3/))

      call cudanma_Cross_Product(rij, rkj, tline); call cudanma_Cross_Product(rlk, rkj, uline)
      tlen2inv = 1.0_SD/dot_product(tline, tline); ulen2inv = 1.0_SD/dot_product(uline, uline)

      phi = dot_product(tline, uline)*sqrt(tlen2inv*ulen2inv); phi = min(1.0_SD, max(-1.0_SD, phi))
      phi = sign(1.0_SD, dot_product(rij, uline)) * acos(phi)

      dedphi = 0d0; d2edphi2 = 0d0
      do idihe = dihegroupindex_d(igroup) + 1, dihegroupindex_d(igroup + 1)
         itype=diheatom_d(5 * idihe); tpn = diheperiod_d(itype)
         tpphase = tpn * phi - dihephase_d(itype)
         tpcoeff = - tpn * diheforceconst_d(itype)
         dedphi = dedphi + tpcoeff * sin(tpphase)
         d2edphi2 = d2edphi2 + tpn * tpcoeff * cos(tpphase)
      enddo

      ! Calculate nabla_i, nabla_j, nabla_k and nabla_l
      nablai = dkj*tlen2inv*tline; nablal = -dkj*ulen2inv*uline
      tpvec = (rijrkj*nablai + rlkrkj*nablal)*dkj2inv
      nablaj = tpvec - nablai; nablak = -(tpvec + nablal)

      ! Calculate nabla_ii and nabla_ll

      tpmatrix(:,1) = [1.0_SD,0.0_SD,0.0_SD]
      tpmatrix(:,2) = [0.0_SD,1.0_SD,0.0_SD]
      tpmatrix(:,3) = [0.0_SD,0.0_SD,1.0_SD]

      ! call cudanma_dgemm(-2.0_SD*tlen2inv, tline, tline, 1.0_SD, tpmatrix)
      ! call cudanma_dgemm(dkj*tlen2inv, nablakj, tpmatrix, 0.0_SD, nablaii)
      do tpindex = 1, 3
         tpmatrix(:,tpindex) = -2.0_SD*tlen2inv*tline(tpindex)*tline(:) + tpmatrix(:,tpindex)
      end do
      nablaii = dkj*tlen2inv*matmul(nablakj,tpmatrix)
      ! call cudanma_dgemm(dkj*tlen2inv, nablakj, tpmatrix, 0.0_SD, nablaii)

      tpmatrix(:,1) = [1.0_SD,0.0_SD,0.0_SD]
      tpmatrix(:,2) = [0.0_SD,1.0_SD,0.0_SD]
      tpmatrix(:,3) = [0.0_SD,0.0_SD,1.0_SD]
      ! call cudanma_dgemm(-2.0_SD*ulen2inv, uline, uline, 1.0_SD, tpmatrix)
      ! call cudanma_dgemm(-dkj*ulen2inv, nablakj, tpmatrix, 0.0_SD, nablall)
      do tpindex = 1, 3
         tpmatrix(:,tpindex) = -2.0_SD*ulen2inv*uline(tpindex)*uline(:) + tpmatrix(:,tpindex)
      end do
      nablall = -dkj*ulen2inv*matmul(nablakj,tpmatrix)

      ! Calculate nabla_ij, nabla_ik, nablalj and nabla_lk
      ! Here we calculate Transpose(nabla_ki) and Transpose(nabla_jl) instead nabla_ik and nabla_lj
      ! call cudanma_dgemm(1.0_SD, nablai, rkj, 0.0_SD, tpmatrix)
      do tpindex = 1, 3
         tpmatrix(:,tpindex) = rkj(tpindex)*nablai(:)
      end do
      nablaik = -(tpmatrix + rijrkj*nablaii)*dkj2inv
      ! call cudanma_dgemm(1.0_SD, nablal, rkj, 0.0_SD, tpmatrix)
      do tpindex = 1, 3
         tpmatrix(:,tpindex) = rkj(tpindex)*nablal(:)
      end do
      nablalj = (tpmatrix + rlkrkj*nablall)*dkj2inv
      nablaij = -(nablaii + nablaik); nablalk = -(nablall + nablalj)

      ! Calculate nabla_jj and nabla_kk by nabla_ii, nabla_ll, nabla_ij, nabla_lj, nabla_ik and nabla_lk
      nablajj = (rijrkj - dkj2)*nablaij + rlkrkj*nablalj
      tpvec = rkj - rij
      ! call cudanma_dgemm(1.0_SD, tpvec, nablai, 1.0_SD, nablajj)
      ! call cudanma_dgemm(-1.0_SD, rlk, nablal, 1.0_SD, nablajj)
      ! call cudanma_dgemm(2.0_SD*dkj2inv, rkj, nablaj, dkj2inv, nablajj)
      do tpindex = 1, 3
         nablajj(:,tpindex) = nablai(tpindex)*tpvec(:) + nablajj(:,tpindex)
         nablajj(:,tpindex) = -nablal(tpindex)*rlk + nablajj(:,tpindex)
         nablajj(:,tpindex) = 2.0_SD*dkj2inv*nablaj(tpindex)*rkj + dkj2inv*nablajj(:,tpindex)
      end do

      nablakk = (rijrkj)*nablaik + (rlkrkj + dkj2)*nablalk
      ! call cudanma_dgemm(1.0_SD, rij, nablai, 1.0_SD, nablakk)
      ! tpvec = rlk + rkj
      ! call cudanma_dgemm(1.0_SD, tpvec, nablal, 1.0_SD, nablakk)
      ! call cudanma_dgemm(-2.0_SD*dkj2inv, rkj, nablak, -dkj2inv, nablakk)
      do tpindex = 1, 3
         nablakk(:,tpindex) = nablai(tpindex)*rij(:) + nablakk(:,tpindex)
         nablakk(:,tpindex) = nablal(tpindex)*(rlk + rkj) + nablakk(:,tpindex)
         nablakk(:,tpindex) = -2.0_SD*dkj2inv*nablak(tpindex)*rkj(:) - dkj2inv*nablakk(:,tpindex)
      end do

      ! Calculate nabla_kj by nabla_ij, nabla_jj and nabla_lj; And nabla_il = 0
      nablakj = -(nablajj + nablaij + nablalj); tpmatrix = 0.0_SD
      ! call cudanma_dgemm(d2edphi2, nablai, nablai, dedphi, nablaii)
      ! call cudanma_dgemm(d2edphi2, nablaj, nablaj, dedphi, nablajj)
      ! call cudanma_dgemm(d2edphi2, nablak, nablak, dedphi, nablakk)
      ! call cudanma_dgemm(d2edphi2, nablal, nablal, dedphi, nablall)
      ! call cudanma_dgemm(d2edphi2, nablaj, nablai, dedphi, nablaij)
      ! call cudanma_dgemm(d2edphi2, nablak, nablai, dedphi, nablaik)
      ! call cudanma_dgemm(d2edphi2, nablaj, nablal, dedphi, nablalj)
      ! call cudanma_dgemm(d2edphi2, nablak, nablal, dedphi, nablalk)
      ! call cudanma_dgemm(d2edphi2, nablaj, nablak, dedphi, nablakj)
      ! call cudanma_dgemm(d2edphi2, nablal, nablai, dedphi, tpmatrix)
      do tpindex = 1, 3
         nablaii(:,tpindex) = d2edphi2*nablai(tpindex)*nablai(:) + dedphi*nablaii(:,tpindex)
         nablajj(:,tpindex) = d2edphi2*nablaj(tpindex)*nablaj(:) + dedphi*nablajj(:,tpindex)
         nablakk(:,tpindex) = d2edphi2*nablak(tpindex)*nablak(:) + dedphi*nablakk(:,tpindex)
         nablall(:,tpindex) = d2edphi2*nablal(tpindex)*nablal(:) + dedphi*nablall(:,tpindex)

         nablaij(:,tpindex) = d2edphi2*nablai(tpindex)*nablaj(:) + dedphi*nablaij(:,tpindex)
         nablaik(:,tpindex) = d2edphi2*nablai(tpindex)*nablak(:) + dedphi*nablaik(:,tpindex)
         nablalj(:,tpindex) = d2edphi2*nablal(tpindex)*nablaj(:) + dedphi*nablalj(:,tpindex)
         nablalk(:,tpindex) = d2edphi2*nablal(tpindex)*nablak(:) + dedphi*nablalk(:,tpindex)

         nablakj(:,tpindex) = d2edphi2*nablak(tpindex)*nablaj(:) + dedphi*nablakj(:,tpindex)
         tpmatrix(:,tpindex)= d2edphi2*nablai(tpindex)*nablal(:) + dedphi*tpmatrix(:,tpindex)
      end do

      call cudanma_storehessian(i, nablaii)
      call cudanma_storehessian(j, nablajj)
      call cudanma_storehessian(k, nablakk)
      call cudanma_storehessian(l, nablall)
      call cudanma_storehessian(i, j, nablaij)
      call cudanma_storehessian(i, k, nablaik)
      call cudanma_storehessian(l, j, nablalj)
      call cudanma_storehessian(l, k, nablalk)
      call cudanma_storehessian(k, j, nablakj)
      call cudanma_storehessian(i, l, tpmatrix)
   end subroutine cudanma_matrix_dihedral

   attributes(global) subroutine cudanma_matrix_elecvdw14()
      use cudatop, only : vdwsigma_d, vdweps_d
      implicit none
      integer :: idihe, i, j, itype, tpindex
      real(kind=SD) :: elec14, rij(3), tpmatrix(3, 3)
      real(kind=SD) :: dedr, d2edr2, dij2inv, vdwa, vdwb

      idihe = (blockidx%x - 1)*blockdim%x + threadidx%x; if (idihe > nnb14_c) return
      itype = nonbond14_d(3, idihe); if ( itype == 0 ) return

      i = nonbond14_d(1, idihe); j = nonbond14_d(2, idihe)

      rij(1:3) = nowcoor_t(1:3, i) - nowcoor_t(1:3, j); dij2inv = 1.0_SD/dot_product(rij, rij)

      elec14 = scale14elec_d(itype)*charge_d(i)*charge_d(j)*sqrt(dij2inv)

      vdwa = vdwsigma_d(i) + vdwsigma_d(j)
      vdwa = vdwa**2*dij2inv; vdwa = vdwa*vdwa*vdwa
      vdwb = scale14vdw_d(itype)*vdwa*vdweps_d(i)*vdweps_d(j)

      ! note that dedr = de/dr * dijinv
      dedr = - ( elec14 + vdwb*(12.0_SD*vdwa - 6.0_SD) )*dij2inv
      d2edr2 = ( 2.0_SD*elec14 + vdwb*(156.0_SD*vdwa - 42.0_SD) )*dij2inv
 
      d2edr2 = (d2edr2 - dedr)*dij2inv

      ! call cudanma_dgemm(d2edr2, rij, rij, 1.0_SD, tpmatrix)
      do tpindex = 1, 3
         tpmatrix(:,tpindex) = d2edr2*rij(tpindex)*rij(:)
         tpmatrix(tpindex,tpindex) = tpmatrix(tpindex,tpindex) + dedr
      end do
      call cudanma_storehessian(i, tpmatrix)
      call cudanma_storehessian(j, tpmatrix)
      tpmatrix = -tpmatrix
      call cudanma_storehessian(i, j, tpmatrix)
   end subroutine cudanma_matrix_elecvdw14

   subroutine cudanma_matrix_GB()
      implicit none

      call cudanma_GB_prepare_setzero <<< nblockatom, warpsize >>> ()
      call cudanma_GB_prepare_nabla <<< dim3(nblockatom, nblockatom, 1), warpsize >>> ()

      call cudanma_GB_Integral <<< dim3(nblockatom, nblockatom, 1), warpsize >>> ()
      call cudanma_GB_Effective_Born <<< nblockatom, warpsize >>> ()

      call cudanma_GB_hessian <<< dim3(nblocknb, nblocknb, warpsize), warpsize, 6*warpsize*SD >>> ()
   end subroutine cudanma_matrix_GB

   attributes(global) subroutine cudanma_massweighted()
      integer :: i, j, ihessian, iatom, jatom

      i = (blockIdx%x - 1)*blockDim%x + threadIdx%x
      j = (blockIdx%y - 1)*blockDim%y + threadIdx%y
      if (i > ndegree_c .or. j > i) return

      ihessian = (i - 1)*i/2 + j
      iatom = (i-1)/3+1; jatom = (j-1)/3+1
      hessianline_d(ihessian) = massinv_d(iatom)*hessianline_d(ihessian)*massinv_d(jatom)
   end subroutine cudanma_massweighted

   ! Interface
   attributes(device) subroutine cudanma_storehessian_i(atomindex, matrixij)
      implicit none
      integer, intent(in) :: atomindex
      real(kind=SD), intent(in) :: matrixij(0:2, 0:2)
      integer :: i, j, k, matrixindex(0:2)
      real(kind=SD) :: mem

      i = 3*atomindex
      matrixindex(2) = i*(i + 1)/2
      matrixindex(1) = matrixindex(2) - i
      matrixindex(0) = matrixindex(1) - i + 1

      do i = 0, 2
         j = matrixindex(i)
         ! hessianline_t(j-i:j) = hessianline_t(j-i:j) + matrixij(0:i,i)
         do k = 0, i
            mem = atomicadd(hessianline_t(j - i + k), real(matrixij(k, i), kind=8))
         end do
      end do
   end subroutine cudanma_storehessian_i

   attributes(device) subroutine cudanma_storehessian_ij(atomi, atomj, matrixij)
      implicit none
      integer, intent(in) :: atomi, atomj
      real(kind=SD), intent(in) :: matrixij(3, 3)
      integer :: i, j, k, matrixindex(3)
      real(kind=SD) :: tpmatrix(3, 3)
      real(kind=SD) :: mem

      if (atomi > atomj) then
         ! tpmatrix = transpose(transpose(matrixij))
         ! The second transpose used for tpmatrix(1:3,i) to accelerate because of the column major
         i = 3*atomj; j = 3*atomi; tpmatrix = matrixij
      else if (atomi < atomj) then
         i = 3*atomi; j = 3*atomj; tpmatrix = transpose(matrixij)
      else
         call cudanma_storehessian_i(atomi, matrixij); return
      end if

      matrixindex(3) = j*(j - 1)/2 + i
      matrixindex(2) = matrixindex(3) - j + 1
      matrixindex(1) = matrixindex(2) - j + 2

      do i = 1, 3
         j = matrixindex(i)
         ! hessianline_t(j-2:j) = hessianline_t(j-2:j) + tpmatrix(1:3,i)
         do k = 1, 3
            mem = atomicadd(hessianline_t(j - 3 + k), real(tpmatrix(k, i), kind=8))
         end do
      end do
   end subroutine cudanma_storehessian_ij

   attributes(device) subroutine cudanma_dgemm1(alpha, A, B, beta, C)
      implicit none
      real(kind=SD), intent(in) :: alpha, beta
      real(kind=SD), dimension(3), intent(in) :: A, B
      real(kind=SD), dimension(3, 3), intent(inout) :: C
      real(kind=SD) :: temp
      integer :: i

      if (beta == 0.0_SD) then
         C = 0.0_SD
      else if (beta /= 1.0_SD) then
         C = beta*C
      end if

      do i = 1, 3
         temp = alpha*A(i)
         C(i, 1:3) = temp*B(1:3) + C(i, 1:3)
      end do
   end subroutine cudanma_dgemm1

   attributes(device) subroutine cudanma_dgemm3(alpha, A, B, beta, C)
      implicit none
      real(kind=SD), intent(in) :: alpha, beta
      real(kind=SD), dimension(3, 3), intent(in) :: A, B
      real(kind=SD), dimension(3, 3), intent(inout) :: C
      real(kind=SD) :: temp
      integer :: i, j

      if (beta == 0.0_SD) then
         C = 0.0_SD
      else if (beta /= 1.0_SD) then
         C = beta*C
      end if

      do i = 1, 3
         do j = 1, 3
            temp = dot_product(A(i, 1:3), B(1:3, j))
            C(i, j) = temp*alpha + C(i, j)
         end do
      end do
   end subroutine cudanma_dgemm3

   attributes(global) subroutine cudanma_GB_prepare_setzero()
      integer :: iatom
      iatom = (blockidx%x - 1)*blockdim%x + threadidx%x; if ( iatom > natom_c ) return
      radeff_d(iatom) = 0.0_DP; nabla_d(:,iatom) = 0.0_DP; nablaij_d(:,:,iatom) = 0.0_DP
   end subroutine cudanma_GB_prepare_setzero

   attributes(global) subroutine cudanma_GB_prepare_nabla()
      integer :: i,j,k,inext
      real(kind=SD) :: rij(3),nabla_a(3),nablakl_a(3,3),tpvec(3),tpmatrix(3,3)
      real(kind=SD) :: icoor(3),jcoor(3),irad,jrad,iradoff,jfsrho

      inext = threadidx%x + 1
      i = (blockidx%x - 1)*blockdim%x + threadidx%x; irad = 0.0_SD
      if ( i <= natom_c ) then
         irad = radius_d(i)
         if ( irad /= 0.0_SD ) then
            icoor = nowcoor_t(:,i); iradoff = radoff_d(i)
         end if
      end if
      j = (blockidx%y - 1)*blockdim%x + threadidx%x; jrad = 0.0_SD
      if ( j <= natom_c ) then
         jrad = radius_d(j)
         if ( jrad /= 0.0_SD ) then
            jcoor = nowcoor_t(:,j); jfsrho = fsrho_d(j)
         end if
      end if

      nabla_a = 0.0_SD; nablakl_a = 0.0_SD
      do k = 1, blockdim%x
         if ( i /= j .and.  i <= natom_c .and. j <= natom_c ) then
         if ( irad /= 0.0_SD .and. jrad /= 0.0_SD ) then
            rij = icoor - jcoor
            call cudanma_GB_nablaIntegral(i, j, irad, jrad, iradoff, jfsrho, rij, tpvec, tpmatrix)
            nabla_a(:) = nabla_a(:) - tpvec
            nablakl_a(:, :) = nablakl_a(:, :) + tpmatrix
         end if; end if

         j = __shfl(j,inext); jrad = __shfl(jrad,inext); jfsrho = __shfl(jfsrho,inext)
         jcoor(1) = __shfl(jcoor(1),inext); jcoor(2) = __shfl(jcoor(2),inext); jcoor(3) = __shfl(jcoor(3),inext)
      end do

      do k = 1, 3
         rij(1) = atomicadd(nabla_d(k,i),real(nabla_a(k),kind=8))
         do j = 1, 3
            rij(2) = atomicadd(nablaij_d(j,k,i), real(nablakl_a(j,k),kind=8))
         end do
      end do
   end subroutine cudanma_GB_prepare_nabla

   attributes(device) subroutine cudanma_GB_nablaEffBorn_k(i, k, icoor, kcoor, irad, krad, iradoff, kfsrho, nabla_a, nablakl_a)
      implicit none
      integer, intent(in) :: i, k
      real(kind=SD),intent(in) :: irad, krad, iradoff, kfsrho, icoor(3), kcoor(3)
      real(kind=SD), intent(out) :: nabla_a(3), nablakl_a(3, 3)
      real(kind=SD) :: dradeff, d2radeff, rij(3), tpvec(3), tpmatrix(3, 3)
      integer :: m

      nablakl_a = 0.0_SD; nabla_a = 0.0_SD
      ! nabla_a -> nablak_ai; nablakl_a -> nablakl_ai
      if (i == k) then
         tpvec = nabla_d(:,i); tpmatrix = nablaij_d(:,:,i)
      else
         rij = icoor - kcoor
         call cudanma_GB_nablaIntegral(i, k, irad, krad, iradoff, kfsrho, rij, tpvec, tpmatrix)
      end if
      dradeff = dradeffdI_d(1, i); d2radeff = dradeffdI_d(2, i)
      ! call cudanma_dgemm(d2radeff, tpvec, tpvec, dradeff, tpmatrix)
      do m = 1, 3
         tpmatrix(:,m) = d2radeff*tpvec(m)*tpvec(:) + dradeff*tpmatrix(:,m)
      end do
      nabla_a(:) = dradeff*tpvec; nablakl_a(:, :) = tpmatrix
   end subroutine cudanma_GB_nablaEffBorn_k

   attributes(device) subroutine cudanma_GB_nablaEffBorn_l(i, k, l, icoor, kcoor, lcoor, irad, krad, lrad, iradoff, lradoff, kfsrho, lfsrho, nablal_a, nablakl_a, nablak_a)
      implicit none
      integer, intent(in) :: i, k, l
      real(kind=SD),intent(in) :: irad, krad, lrad, iradoff, lradoff, kfsrho, lfsrho, icoor(3), kcoor(3), lcoor(3)
      real(kind=SD), intent(in) :: nablak_a(3)
      real(kind=SD), intent(out) :: nablal_a(3), nablakl_a(3, 3)
      real(kind=SD) :: dradeff, d2radeff, rij(3), tpvec(3), tpmatrix(3, 3)
      integer :: m, tpi

      nablakl_a = 0.0_SD; nablal_a = 0.0_SD
      ! nablal_a -> nablal_ai; nablakl_a -> nablakl_ai
      if (i == l) then
         rij = lcoor - kcoor
         call cudanma_GB_nablaIntegral(l, k, lrad, krad, lradoff, kfsrho, rij, tpvec, tpmatrix)
         tpvec = nabla_d(:,i)
      else
         rij = icoor - lcoor
         call cudanma_GB_nablaIntegral(i, l, irad, lrad, iradoff, lfsrho, rij, tpvec, tpmatrix)
         if ( i /= k ) tpmatrix = 0.0_SD
      end if

      tpmatrix = -tpmatrix; dradeff = dradeffdI_d(1, i); d2radeff = dradeffdI_d(2, i)/dradeff
      ! call cudanma_dgemm(d2radeff, tpvec, nablak_a, dradeff, tpmatrix)
      do m =1, 3
         tpmatrix(:,m) = d2radeff*nablak_a(m)*tpvec(:) + dradeff*tpmatrix(:,m)
      end do
      nablal_a(:) = dradeff*tpvec; nablakl_a(:, :) = tpmatrix
   end subroutine cudanma_GB_nablaEffBorn_l

   ! subsubroutines
   attributes(global) subroutine cudanma_init_skip(excludedatomindex_in)
      implicit none
      integer, intent(in) :: excludedatomindex_in(natom_c + 1)
      integer :: i, j, jstart, index
      integer :: iskip, iskipstart, iskipend

      i = blockpos_d(1, blockidx%x) + threadidx%x; if (i > natom_c) return
      jstart = blockpos_d(2, blockidx%x)
      ! jend = min(jstart + blockdim%x, natom_c)
      iskip = 0; iskipstart = 0; iskipend = 0

      do index = excludedatomindex_in(i) + 1, excludedatomindex_in(i + 1)
         j = excludedatomlist_d(index)
         if ((jstart < j) .and. (j <= natom_c)) then
            if (iskipstart == 0) iskipstart = index
            iskipend = index
            if ((j >= jstart + threadidx%x + 1) .and. (iskip == 0)) iskip = index
         end if
      end do
      if ((iskip == 0) .and. (iskipstart > 0)) iskip = iskipstart
      blockskip_d(1:3, (blockidx%x - 1)*blockdim%x + threadidx%x) = (/iskip, iskipstart, iskipend/)
   end subroutine cudanma_init_skip

   attributes(device) subroutine cudanma_Cross_Product(vec1, vec2, vec3)
      implicit none
      real(kind=SD), dimension(1:3), intent(in) :: vec1, vec2
      real(kind=SD), dimension(1:3), intent(out) :: vec3

      vec3(1) = vec1(2)*vec2(3) - vec1(3)*vec2(2)
      vec3(2) = vec1(3)*vec2(1) - vec1(1)*vec2(3)
      vec3(3) = vec1(1)*vec2(2) - vec1(2)*vec2(1)
   end subroutine cudanma_Cross_Product

   attributes(global) subroutine cudanma_GB_hessian()
      implicit none
      real(kind=SD),shared,dimension(blockdim%x) :: lrads, lradoffs, lfsrhos
      real(kind=SD),shared :: lcoor(3,blockdim%x)
      integer :: i, j, k, l, index1, index2, index3, next, natom, ithread
      real(kind=SD) :: qi, qj, radeffi, radeffj, radeff2, dij2, dE_a, d2E_a, kij, lij
      real(kind=SD) :: nablak_ai(3), nablak_aj(3), nablal_ai(3), nablal_aj(3), tpvec(3)
      real(kind=SD) :: coori(3), coorj(3), rij(3), Partial_E(6), nablakl_ai(3, 3), nablakl_aj(3, 3), nablakl(3, 3)
      real(kind=SD) :: nablakk_ai(3, 3), irad, iradoff, jrad, jradoff, krad, kfsrho, kcoor(3)

      ithread = threadidx%x
      i = blockpos_d(1, blockidx%x) + ithread
      k = blockpos_d(1, blockidx%y) + blockidx%z; if (k > natom .or. charge_d(k) == 0.0_SD) return
      j = blockpos_d(2, blockidx%x) + ithread; next = ithread + 1
      l = blockpos_d(2, blockidx%y)

      krad = radius_d(k); kfsrho = fsrho_d(k); kcoor = nowcoor_t(:,k)
      index1 = l + ithread
      if ( index1 <= natom_c .and. radius_d(index1) /= 0.0_SD ) then
         lrads(ithread) = radius_d(index1); lradoffs(ithread) = radoff_d(index1); lfsrhos(ithread) = fsrho_d(index1)
         lcoor(:,ithread) = nowcoor_t(:,index1)
      end if

      call syncthreads()

      qi = 0.0_SD; irad = 0.0_SD; iradoff = 0.0_SD
      if ( i <= natom_c ) then
         qi = charge_d(i)
         if (qi /= 0.0_SD) then
            coori = nowcoor_t(1:3, i); radeffi = radeff_d(i)
            irad = radius_d(i); iradoff = radoff_d(i)
            call cudanma_GB_nablaEffBorn(i, k, coori, kcoor, irad, krad, iradoff, kfsrho, nablak_ai, nablakk_ai)
         end if
      end if
   
      qj = 0.0_SD; jrad = 0.0_SD; jradoff = 0.0_SD 
      if ( j <= natom_c ) then
         qj = charge_d(j)
         if (qj /= 0.0_SD) then
            coorj = nowcoor_t(1:3, j); radeffj = radeff_d(j)
            jrad = radius_d(j); jradoff = radoff_d(j)
            call cudanma_GB_nablaEffBorn(j, k, coorj, kcoor, jrad, krad, jradoff, kfsrho, nablak_aj, nablakl_aj)

            if ( i == j ) then
               ! radeffi -> alpha_i; qi -> qi^2/(8*pi*epsilon0*epsilon*alpha_i)
               ! radeffi -> -kappa*alpha_i; d2E_a -> exp(-kappa*alpha_i)
               ! dij2 and radeff2 here used as a Temporary variable
               dij2 = qi**2*epsoutinv_c/(2.0_SD*radeffi); radeff2 = -kappa_c*radeffi
               d2E_a = exp(radeff2)
   
               ! dE_a -> d(E_ii)/d(alpha_i^-1); d2E_a -> d2(E_ii)/d(alpha_i^-1)2
               dE_a = -(epsilon_c - d2E_a - radeff2*d2E_a)*dij2
               d2E_a = dij2*d2E_a*radeff2**2;
            end if

         end if
      end if

      do index1 = 1, griddim%z
         l = l + 1
         if ( l < k ) cycle; if ( l > natom_c ) cycle; if (charge_d(l) == 0.0_SD) cycle

         nablakl = 0.0_SD

         if ( l == k ) then
            nablal_ai = nablak_ai; nablal_aj = nablak_aj; nablakl_ai = nablakk_ai
         else
            if ( i <= natom_c ) then
               if ( qi /= 0.0_SD ) then
                  call cudanma_GB_nablaEffBorn(i, k, l, coori, kcoor, lcoor(:,index1), irad, krad, lrads(index1), iradoff, lradoffs(index1), kfsrho, lfsrhos(index1), nablal_ai, nablakl_ai, nablak_ai)
               end if
            end if
            if ( j <= natom_c ) then
               if ( qj /= 0.0_SD ) then
                  call cudanma_GB_nablaEffBorn(j, k, l, coorj, kcoor, lcoor(:,index1), jrad, krad, lrads(index1), jradoff, lradoffs(index1), kfsrho, lfsrhos(index1), nablal_aj, nablakl_aj, nablak_aj)
               end if
            end if
         end if

         if (j == i .and. i <= natom_c .and. qi /= 0.0_SD) then
            ! nablakl -> nabla_k(nabla_l(E_ii))
            ! nablakl = dE_dai*nablakl_a(i) + d2E_dai*(nablal_a(i)^T * nablak_a(i))
            ! call cudanma_dgemm(d2E_a, nablal_ai, nablak_ai, dE_a, tpmatrix)
            do index2 = 1, 3
               nablakl(:,index2) = nablakl(:,index2) +  &
                          d2E_a*nablak_ai(index2)*nablal_ai(:) + dE_a*nablakl_ai(:,index2)
            end do
         end if

         do index2 = 1, blockdim%x
            j = __shfl(j, next); qj = __shfl(qj, next); radeffj = __shfl(radeffj, next)
            jrad = __shfl(jrad, next); jradoff = __shfl(jradoff, next)
            do index3 = 1, 3
               coorj(index3) = __shfl(coorj(index3), next)
               nablak_aj(index3) = __shfl(nablak_aj(index3), next)
               nablal_aj(index3) = __shfl(nablal_aj(index3), next)
               nablakl_aj(1, index3) = __shfl(nablakl_aj(1, index3), next)
               nablakl_aj(2, index3) = __shfl(nablakl_aj(2, index3), next)
               nablakl_aj(3, index3) = __shfl(nablakl_aj(3, index3), next)
            end do
            if (j <= i ) cycle; if ( j > natom_c) cycle
            if (qi == 0.0_SD ) cycle; if (qj == 0.0_SD) cycle
            rij = coori - coorj; dij2 = dot_product(rij, rij)
            if ( dij2 > discut2_c ) cycle

            radeff2 = radeffi*radeffj
            ! calculate six terms in the formula of grad_k'(grad_k(Eij))
            ! epsin = 4*pi * epsilon0; epsout = 4*pi * epsilon0*epsilon
            ! Ecoef_ij = Ecoef_ji = qi*qj / (8*pi*epsilon*epsilon0); Ecoef = Ecoef_ij + Ecoef_ji
            ! Partial_E(6) = (/dE_a, d2E_a2, d2E_aa, dE_d, d2E_d2, d2E_ad/)
            call cudanma_GB_PartialE(qi*qj*epsoutinv_c, epsilon_c, dij2, radeff2, kappa_c, Partial_E)

            kij = 0.0_SD; lij = 0.0_SD
            if (k == i) then; kij = 1.0_SD; else if (k == j) then; kij = -1.0_SD; end if
            if (l == i) then; lij = 1.0_SD; else if (l == j) then; lij = -1.0_SD; end if

            nablakl = nablakl + Partial_E(1)*(nablakl_ai + nablakl_aj)

            ! call cudanma_dgemm(1.0_SD, nablal_ai, nablak_ai, 0.0_SD, tpmatrix)
            ! call cudanma_dgemm(1.0_SD, nablal_aj, nablak_aj, 1.0_SD, tpmatrix)
            do index3 = 1, 3
               nablakl(:,index3) = nablakl(:,index3) + Partial_E(2)*(    &
                      nablak_aj(index3)*nablal_aj(:) + nablak_ai(index3)*nablal_ai(:)  )
            end do

            ! call cudanma_dgemm(1.0_SD, nablal_ai, nablak_aj, 0.0_SD, tpmatrix)
            ! call cudanma_dgemm(1.0_SD, nablal_aj, nablak_ai, 1.0_SD, tpmatrix)
            do index3 = 1, 3
                nablakl(:,index3) = nablakl(:,index3) + Partial_E(3)*(    &
                        nablak_ai(index3)*nablal_aj(:) + nablak_aj(index3)*nablal_ai(:) )
            end do

            dij2 = kij*lij
            if ( kij /= 0.0_SD .or. lij /= 0.0_SD ) then
               do index3 = 1, 3
                  nablakl(:,index3) = nablakl(:,index3) + dij2*Partial_E(5)*rij(index3)*rij(:)
                  nablakl(index3,index3) = nablakl(index3,index3) + dij2*Partial_E(4)
               end do
            end if

            if (kij /= 0.0_SD) then
               tpvec = nablal_ai + nablal_aj
               ! call cudanma_dgemm(kij, tpvec, rij, 1.0_SD, tpmatrix)
               do index3 = 1, 3
                  nablakl(:,index3) = nablakl(:,index3) + Partial_E(6)*kij*rij(index3)*tpvec(:)
               end do
            end if
            if (lij /= 0.0_SD) then
               tpvec = nablak_ai + nablak_aj
               ! call cudanma_dgemm(lij, rij, tpvec, 1.0_SD, tpmatrix)
               do index3 = 1, 3
                  nablakl(:,index3) = nablakl(:,index3) + Partial_E(6)*lij*tpvec(index3)*rij(:)
               end do
            end if
         end do
         call cudanma_storehessian(k, l, nablakl)
      end do
   end subroutine cudanma_GB_hessian

   attributes(device) subroutine cudanma_GB_PartialE(Ecoef, epsilon, dij2, radeff2, kappa, Partial_E)
      ! Partial_E(6) = (/dE_a, d2E_a2, d2E_aa, dE_d, d2E_d2, d2E_ad/)
      implicit none
      real(kind=SD), intent(in) :: Ecoef, epsilon, dij2, radeff2, kappa
      real(kind=SD) :: dE_f, d2E_f, df_d, df_a, d2f_a2, d2f_d2, d2f_aa, d2f_ad
      real(kind=SD) :: expmdij, fgb, fgb3inv, coef1, coef2
      real(kind=SD), intent(out) :: Partial_E(6)

      ! expmdij = exp(-D_ij); notice that here D_ij = dij2/4*radeff2
      expmdij = exp(-dij2/(4.0_SD*radeff2)); fgb = sqrt(dij2 + radeff2*expmdij)
      coef1 = kappa*fgb; coef2 = exp(-coef1); fgb3inv = 1.0_SD/fgb**3

      ! E = E_ij + E_ji; f = fgb = f_ij = f_ji
      ! dE_f -> Ecoef/f * d(E)/d(f); d2E_f -> Ecoef/f^2 * d^2(E)/d(f)^2
      dE_f = Ecoef*(epsilon - coef2 - coef1*coef2)*fgb3inv
      d2E_f = (Ecoef*kappa**2*coef2 - 3.0_SD*fgb*dE_f)*fgb3inv

      ! df_d -> f/d * d(f)/d(d); df_a -> f/alpha * d(f)/d(alpha^-1)
      ! d -> dij; alpha -> effective born radii
      df_d = 1.0_SD - 0.25_SD*expmdij; df_a = -0.5_SD*expmdij*(radeff2 + 0.25_SD*dij2)

      ! d2f_d2 -> (f/d^2) * d^2(f)/d(d)^2 - (1/d^2) * df_d
      ! d2f_a2 -> (f/alpha^2)      * d^2(f)/d(alpha^-1)^2
      ! d2f_aa -> f/(alpha*alpha') * d^2(f) / [d(alpha^-1) * d(alpha'^-1)]
      ! d2f_ad -> f/(alpha*d)      * d^2(f) / [d(alpha^-1) * d(d)]
      d2f_d2 = 0.125_SD*expmdij/radeff2; d2f_ad = 0.5_SD*dij2*d2f_d2
      d2f_aa = 0.5_SD*dij2*d2f_ad - df_a; d2f_a2 = d2f_aa - df_a

      Partial_E(:) = 0.0_SD; coef1 = d2E_f*df_a**2
      ! Partial_E(6) = (/dE_a, d2E_a2, d2E_aa, dE_d, d2E_d2, d2E_ad/)
      ! dE_a -> 1/alpha            * d(E)    / d(alpha^-1)
      ! d2E_a2 -> 1/(alpha)^2      * d^2(E)  / d(alpha^-1)^2
      ! d2E_aa -> 1/(alpha*alpha') * d^2(E)  / [d(alpha^-1) * d(alpha'^-1)]
      ! dE_d -> 1/d                * d(E)    / d(d)
      ! d2E_d2 -> 1/(d)^2          * [d^2(E) / d(d)^2  -  dE_d]
      ! d2E_ad -> 1/(alpha*d)      * d^2(E)  / [d(alpha^-1) * d(d)]
      Partial_E(1) = dE_f*df_a; Partial_E(4) = dE_f*df_d
      Partial_E(2) = dE_f*d2f_a2 + coef1; Partial_E(5) = dE_f*d2f_d2 + d2E_f*df_d**2
      Partial_E(3) = dE_f*d2f_aa + coef1; Partial_E(6) = dE_f*d2f_ad + d2E_f*df_a*df_d
   end subroutine cudanma_GB_PartialE

   attributes(device) subroutine cudanma_GB_nablaIntegral(i, j, irad, jrad, roffi, fsrhoj, rij, tpvec, tpmatrix)
      implicit none
      integer, intent(in) :: i, j
      real(kind=SD), intent(in) :: rij(3),irad,jrad,roffi,fsrhoj
      real(kind=SD), intent(out) :: tpvec(3)
      real(kind=SD), intent(out), optional :: tpmatrix(3, 3)
      real(kind=SD), parameter :: d1a = 1.0_SD/3.0_SD, d1b = 0.6_SD, d1c = 6.0_SD/7.0_SD, &
                                  d1d = 10.0_SD/9.0_SD, d1f = 15.0_SD/11.0_SD
      real(kind=SD), parameter :: d2a = 2.0_SD, d2b = 4.8_SD, d2c = 60.0_SD/7.0_SD, &
                                  d2d = 40.0_SD/3.0_SD, d2f = 210.0_SD/11.0_SD
      real(kind=SD) :: dij, dij2, fsrhoj2, dI_d, d2I_d
      real(kind=SD) :: neckmpar, coef1, coef2, coef3
      logical :: cald2
      integer :: m, n

      dij2 = dot_product(rij, rij); dij = sqrt(dij2); fsrhoj2 = fsrhoj**2
      ! d : distance between atom i and atom j
      ! dI_d  -> 1/d     * d(I)    / d(d)
      ! d2I_d -> 1/(d)^2 * [d^2(I) / d(d)^2  -  dI_d]
      cald2 = present(tpmatrix); dI_d = 0.0_SD
      if (cald2) d2I_d = 0.0_SD

      if (dij <= (gbdiscut_c + fsrhoj)) then
         ! sphere j partially within cutoff
         if (dij > (gbdiscut_c - fsrhoj)) then
            coef1 = 1.0_SD/(dij - fsrhoj); coef2 = log(gbdiscut_c*coef1); coef3 = 1.0_SD/gbdiscut_c**2
            dI_d = 0.5_SD*(dij2 + fsrhoj2)*(coef1**2 - coef3) - coef2
            if (cald2) d2I_d = 1.5_SD*fsrhoj*(dij + fsrhoj)*coef1**2 - 3.0_SD*coef2 &
                               + 0.5_SD*(dij2 + 3.0_SD*fsrhoj2)*(dij*coef1**3 - coef3)
            ! artifical regime for smoothing
         else if (dij > 4.0_SD*fsrhoj) then
            coef3 = fsrhoj/dij; coef1 = coef3**2
            coef2 = d1a + coef1*(d1b + coef1*(d1c + coef1*(d1d + coef1*d1f)))
            coef3 = 16.0_SD*coef3*coef1; dI_d = coef3*coef2
            if (cald2) then
               coef2 = d2a + coef1*(d2b + coef1*(d2c + coef1*(d2d + coef1*d2f)))
               d2I_d = coef3*coef2
            end if
            ! spheres not overlapping
         else if (dij > (roffi + fsrhoj)) then
            coef1 = 1.0_SD/(dij2 - fsrhoj2); coef2 = 2.0_SD*dij*fsrhoj
            coef3 = log((dij - fsrhoj)/(dij + fsrhoj))
            dI_d = coef3 + coef2*(dij2 + fsrhoj2)*coef1**2
            if (cald2) d2I_d = 3.0_SD*coef3 + coef2*(3.0_SD*dij2 - fsrhoj2)*(dij2 + 3.0_SD*fsrhoj2)*coef1**3
            ! spheres overlapping
         else if (dij > abs(roffi - fsrhoj)) then
            coef1 = 1.0_SD/(dij + fsrhoj); coef2 = log(coef1*roffi); coef3 = 1.0_SD/(roffi**2)
            dI_d = coef2 + 0.5_SD*(dij2 + fsrhoj2)*(coef3 - coef1**2)
            if (cald2) d2I_d = 3.0_SD*coef2 + 0.5_SD*(dij2 + 3.0_SD*fsrhoj2)*coef3 &
                               + fsrhoj*(3.0_SD*dij2 - fsrhoj2)*coef1**3 - 0.5_SD
            ! sphere i inside sphere j
         else if (roffi < fsrhoj) then
            coef1 = 1.0_SD/(dij2 - fsrhoj2); coef2 = 2.0_SD*dij*fsrhoj
            coef3 = log((fsrhoj - dij)/(fsrhoj + dij))
            dI_d = coef3 + coef2*(dij2 + fsrhoj2)**2
            if (cald2) d2I_d = 3.0_SD*coef3 + coef2*(3.0_SD*dij2 - fsrhoj2)*(dij2 + 3.0_SD*fsrhoj2)*coef1**3
            ! sphere j inside sphere j
         else
            dI_d = 0.0_SD
            if (cald2) d2I_d = 0.0_SD
         end if
      end if
      coef1 = 1.0_SD/dij2; coef3 = dij*coef1; coef2 = 0.25_SD*coef1*coef3; dI_d = dI_d*coef2
      if (cald2) d2I_d = -d2I_d*coef1*coef2

      if (dij < (irad + jrad + gb1watrad_c)) then
         m = nint((irad - 0.95_SD)/0.05_SD); n = nint((jrad - 0.95_SD)/0.05_SD)
         neckmpar = gbneckmat_c(m, n)*coef3; coef1 = dij - gb1dmat_c(m, n)
         coef2 = coef1*coef1; fsrhoj2 = coef2*coef2
         coef3 = 1.0_SD/(1.0_SD + coef2 + 0.3_SD*coef2*fsrhoj2)
         coef1 = coef1*(2.0_SD + 1.8_SD*fsrhoj2)
         neckmpar = neckmpar*coef3*coef3
         dI_d = dI_d + neckmpar*coef1
         if (cald2) d2I_d = d2I_d + neckmpar*((dij*(2.0_SD + 9.0_SD*fsrhoj2) - coef1)/dij2 &
                                                         - 2.0_SD*coef1*coef1*coef3/dij)
      end if

      if (cald2) then
         do m = 1, 3
            tpmatrix(:,m) = d2I_d*rij(m)*rij(:)
            tpmatrix(m,m) = tpmatrix(m,m) + dI_d
         end do
      end if
      tpvec(:) = -dI_d*rij(:)

   end subroutine cudanma_GB_nablaIntegral

   attributes(global) subroutine cudanma_GB_Integral()
      integer :: i, j, k, next, m, n
      real(kind=SD) :: coori(3), coorj(3), rij(3), dij, dij2, dijinv, coef1, coef2
      real(kind=SD) :: gbdiscutinv2, radeffi, roffi, roffiinv, fsrhoj, gbwatradj
      real(kind=SD) :: irad, jrad
      real(kind=SD), parameter :: ca = 1.0_SD/3.0_SD, cb = 0.4_SD, cc = 3.0_SD/7.0_SD, cd = 4.0_SD/9.0_SD, ce = 5.0_SD/11.0_SD

      gbdiscutinv2 = 1.0_SD/gbdiscut_c**2

      i = (blockidx%x - 1)*blockdim%x + threadidx%x
      j = (blockidx%y - 1)*blockdim%x + threadidx%x
      radeffi = 0.0_SD; next = threadidx%x + 1
      coorj = 0.0_SD; fsrhoj = 0.0_SD; irad = 0.0_SD; jrad = 0.0_SD

      if ( i <= natom_c ) then
         irad = radius_d(i)
         if ( irad /= 0.0_SD ) then
            coori = nowcoor_t(:, i); m = nint((irad - 0.95_SD)/0.05_SD)
            roffi = radoff_d(i); roffiinv = 1.0_SD/roffi
         end if
      end if

      if ( j <= natom_c ) then
         jrad = radius_d(j)
         if ( jrad /= 0.0_SD ) then
            coorj = nowcoor_t(:, j); fsrhoj = fsrho_d(j)
            gbwatradj = jrad + gb1watrad_c; n = nint((radius_d(j) - 0.95_SD)/0.05_SD)
         end if
      end if

      do k = 1, blockdim%x
         j = __shfl(j, next); fsrhoj = __shfl(fsrhoj, next); n = __shfl(n, next)
         gbwatradj = __shfl(gbwatradj, next); coorj(1) = __shfl(coorj(1), next)
         coorj(2) = __shfl(coorj(2), next); coorj(3) = __shfl(coorj(3), next)
         jrad = __shfl(jrad, next)

         if (i > natom_c .or. j > natom_c .or. i == j) cycle
         if (irad == 0.0_SD .or. jrad == 0.0_SD) cycle

         rij = coori - coorj; dij2 = dot_product(rij, rij)
         if (dij2 > gbdiscut2_c) cycle

         dij = sqrt(dij2); dijinv = 1.0_SD/dij
         if (dij > (gbdiscut_c + fsrhoj)) cycle

         if (dij > (gbdiscut_c - fsrhoj)) then
            coef1 = 1.0_SD/(dij - fsrhoj)
            radeffi = radeffi - 0.125_SD*dijinv*(1.0_SD + 2.0_SD*dij*coef1 + &
                                        gbdiscutinv2*(dij2 - 4.0_SD*gbdiscut_c*dij - fsrhoj**2) - &
                                        2.0_SD*log(coef1*gbdiscut_c))
         else if (dij > 4.0_SD*fsrhoj) then
            coef1 = (dijinv*fsrhoj)**2
            coef2 = ca + coef1*(cb + coef1*(cc + coef1*(cd + coef1*ce)))
            radeffi = radeffi - coef2*coef1*fsrhoj*dijinv**2
         else if (dij > (roffi + fsrhoj)) then
            coef1 = log((dij - fsrhoj)/(dij + fsrhoj))
            radeffi = radeffi - 0.5_SD*(fsrhoj/(dij2 - fsrhoj**2) + 0.5_SD*dijinv*coef1)
         else if (dij > abs(roffi - fsrhoj)) then
            coef1 = 0.5_SD*roffiinv*dijinv*(dij2 + roffi*roffi - fsrhoj**2)
            coef2 = 1.0_SD/(dij + fsrhoj)
            radeffi = radeffi - 0.25_SD*(roffiinv*(2.0_SD - coef1) - coef2 + dijinv*log(roffi*coef2))
         else if (roffi < fsrhoj) then
            coef1 = log((fsrhoj - dij)/(dij + fsrhoj))
            radeffi = radeffi - 0.5_SD*(fsrhoj/(dij2 - fsrhoj**2) + 2.0_SD*roffiinv + 0.5_SD*dijinv*coef1)
         end if

         if (dij < ( irad + jrad + gb1watrad_c)) then
            coef1 = dij - gb1dmat_c(m, n); coef2 = coef1**2
            radeffi = radeffi - gbneckmat_c(m, n)/(1.0_SD + coef2 + 0.3_SD*coef2**3)
         end if
      end do
      if (i <= natom_c .and. irad /= 0.0_SD) coef1 = atomicadd(radeff_d(i), real(radeffi,kind=8))

   end subroutine cudanma_GB_Integral

   attributes(global) subroutine cudanma_GB_Effective_Born()
      integer :: i
      real(kind=SD) :: roffi, gbpsi, coef1, coef2, tpsq, radi

      i = (blockidx%x - 1)*blockdim%x + threadidx%x; if (i > natom_c) return
      radi = radius_d(i); if (radi == 0.0_SD) return
      roffi = radoff_d(i)
      gbpsi = -radeff_d(i)*roffi; tpsq = gbpsi**2
      coef1 = tanh(gb1alpha_d(i)*gbpsi - gb1beta_d(i)*tpsq + gb1gamma_d(i)*gbpsi*tpsq)
      radeff_d(i) = (roffi*radi)/(radi - roffi*coef1)
      coef2 = gb1alpha_d(i) - 2.0_SD*gb1beta_d(i)*gbpsi + 3.0_SD*gb1gamma_d(i)*tpsq
      tpsq = coef1**2
      dradeffdI_d(1, i) = radeff_d(i)*roffi/radi*(1.0_SD - tpsq)*coef2
      dradeffdI_d(2, i) = -radeff_d(i)*roffi**2/radi*(1.0_SD - tpsq)*2.0_SD* &
                          (3.0_SD*gb1gamma_d(i)*gbpsi - gb1beta_d(i) - coef1*coef2**2)
   end subroutine cudanma_GB_Effective_Born

   subroutine CUSOLVER_CHECK(status)
      use pubmod, only: errormsg
      integer, intent(in) :: status
      ! status from website:
      ! https://docs.nvidia.com/hpc-sdk/compilers/fortran-cuda-interfaces/index.html#cfsolver-init
      select case (status)
      case (0); return
      case (1); call errormsg('cusolver', str1="CUSOLVER_STATUS_NOT_INITIALIZED")
      case (2); call errormsg('cusolver', str1="CUSOLVER_STATUS_ALLOC_FAILED")
      case (3); call errormsg('cusolver', str1="CUSOLVER_STATUS_INVALID_VALUE")
      case (4); call errormsg('cusolver', str1="CUSOLVER_STATUS_ARCH_MISMATCH")
      case (5); call errormsg('cusolver', str1="CUSOLVER_STATUS_MAPPING_ERROR")
      case (6); call errormsg('cusolver', str1="CUSOLVER_STATUS_EXECUTION_FAILED")
      case (7); call errormsg('cusolver', str1="CUSOLVER_STATUS_INTERNAL_ERROR")
      case (8); call errormsg('cusolver', str1="CUSOLVER_STATUS_MATRIX_TYPE_NOT_SUPPORTED")
      case (9); call errormsg('cusolver', str1="CUSOLVER_STATUS_NOT_SUPPORTED")
      case (10); call errormsg('cusolver', str1="CUSOLVER_STATUS_ZERO_PIVOT")
      case (11); call errormsg('cusolver', str1="CUSOLVER_STATUS_INVALID_LICENSE")
      case (12); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_NOT_INITIALIZED")
      case (13); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID")
      case (14); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID_PREC")
      case (15); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID_REFINE")
      case (16); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_PARAMS_INVALID_MAXITER")
      case (20); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_INTERNAL_ERROR")
      case (21); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_NOT_SUPPORTED")
      case (22); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_OUT_OF_RANGE")
      case (23); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_NRHS_NOT_SUPPORTED_FOR_REFINE_GMRES")
      case (25); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_INFOS_NOT_INITIALIZED")
      case (26); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_INFOS_NOT_DESTROYED")
      case (30); call errormsg('cusolver', str1="CUSOLVER_STATUS_IRS_MATRIX_SINGULAR")
      case (31); call errormsg('cusolver', str1="CUSOLVER_STATUS_INVALID_WORKSDACE")
      end select
   end subroutine CUSOLVER_CHECK

   ! code from book << CUDA Fortran for Scientists and Engineers >>
   ! print out the information about the device
   subroutine cudanma_gpuinfo()
      use cudafor
      type(cudaDeviceProp) :: prop
      integer :: nDevices = 0, i, ierr
      ierr = cudaGetDeviceCount(nDevices)
      if (nDevices == 0) then
         stop "No CUDA devices found"
      else
         write (*, "('CUDA Device Info',/)")
      end if
      do i = 0, nDevices - 1
         write (*, "(' Device Number: ',i0)") i
         ierr = cudaGetDeviceProperties(prop, i)
         write (*, "(' Device Name: ',a)") trim(prop%name)
         write (*, "(' Compute Capability: ',i0,'.',i0)") prop%major, prop%minor
      end do
      write(*, *)
   end subroutine cudanma_gpuinfo

end module cudanma
