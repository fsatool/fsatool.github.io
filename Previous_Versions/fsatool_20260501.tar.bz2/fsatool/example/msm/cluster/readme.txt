format of the file: cluster.out
 
col 1: cluster index
col 2: snapshot at the center of each cluster
