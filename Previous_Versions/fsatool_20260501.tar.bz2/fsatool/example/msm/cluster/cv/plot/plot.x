python plot.py ../save/cluster.out
