import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import sys

filename = sys.argv[1]

mpl.rcParams["agg.path.chunksize"] = 20000
data = np.loadtxt("../cv_0.txt",usecols=[1,2])       # set column index for cv here
clusterindex, centersnap = np.loadtxt(filename, unpack=True, dtype=int)
plt.xlabel("cv1")
plt.ylabel("cv2")
plt.axis("equal")
#plt.axis("off")
plt.scatter(data[:, 0], data[:, 1], c=clusterindex)  
snap = set(centersnap)
print(snap)
for i in snap:
    plt.scatter(data[i-1, 0], data[i-1, 1], marker='x')
plt.savefig(filename.split(".")[0] + ".png")
plt.show()
