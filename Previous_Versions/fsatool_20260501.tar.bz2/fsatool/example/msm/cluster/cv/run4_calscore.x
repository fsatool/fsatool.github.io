#!/bin/bash

../../../run.x "mpirun -n 1 ../../../../fsatool msm cluster -i run4_calscore.x" \
"" $0 $1

exit $?

&cluster
  ncluster=1
  clusterMethod="calscore", dataFile="cv_0.txt"
  clusterSelectType="save/run3_kmeans/cluster.out"
  clusterscore="DBI"
/

