#!/bin/bash

# mpirun -n 6 ../../../../fsatool msm cluster -i run1_kmedoids.x && exit

../../../run.x "mpirun -n 6 ../../../../fsatool msm cluster -i run1_kmedoids.x" \
"cluster.out" $0 $1

exit $?

&cluster
  ncluster=20, clusterMethod="kmedoids", dataFile="cv_0.txt"
  randomSeed=25, clusterCycle=10
  clusterscore="DBI"
  cvstart=1, cvend=2
/

