#!/bin/bash

# mpirun -n 6 ../../../../fsatool msm cluster -i run2_kmedoids_small.x && exit

../../../run.x "mpirun -n 6 ../../../../fsatool msm cluster -i run2_kmedoids_small.x" \
"cluster.out" $0 $1

exit $?

&cluster
  ncluster=20, clusterMethod="kmedoids", dataFile="cv_0_100.txt"
  randomSeed=25
/

