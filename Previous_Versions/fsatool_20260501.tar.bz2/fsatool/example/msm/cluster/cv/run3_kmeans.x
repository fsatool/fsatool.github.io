#!/bin/bash

# mpirun -n 6 ../../../../fsatool msm cluster -i run3_kmeans.x && exit

../../../run.x "mpirun -n 6 ../../../../fsatool msm cluster -i run3_kmeans.x" \
"cluster.out residue_score_and_similarity_score.txt" $0 $1

exit $?

&cluster
  ncluster=20, clusterMethod="kmeans", dataFile="cv_0.txt"
  randomSeed=25
  clusterscore="RSI"
/

