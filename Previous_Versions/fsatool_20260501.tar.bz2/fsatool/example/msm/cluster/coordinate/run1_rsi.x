#!/bin/bash

# mpirun -n 4 ../../../../fsatool msm cluster -i run1_rsi.x && exit

../../../run.x "mpirun -n 4 ../../../../fsatool msm cluster -i run1_rsi.x" \
"cluster.out cluster_4.nc residue_score_and_similarity_score.txt" $0 $1

exit $?

&cluster
    ncluster=5
    clustermethod="coordinate"
    datafile="../../../procinfo/leveltraj_0.nc", skipinitdata=2
    trajtype=2
    topfile="../../../procinfo/1le1.top"
    clusterselecttype="calpha"   ! allatom, backbone, calpha, sidechain, heavyatom, sideheavy
    randomseed=1234
    ifwriteclustersnaps=.true.
    clusterscore="RSI"
/
