module load anaconda/3/5.2.0
python vmd_show.py -p ../../../../procinfo/1le1.prmtop -t ../save/cluster_1.nc
