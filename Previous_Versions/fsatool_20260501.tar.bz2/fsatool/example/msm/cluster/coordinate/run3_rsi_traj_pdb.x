#!/bin/bash

# mpirun -n 4 ../../../../fsatool msm cluster -i run1_rsi.x && exit

../../../run.x "mpirun -n 4 ../../../../fsatool msm cluster -i run3_rsi_traj_pdb.x" \
"cluster.out residue_score_and_similarity_score.txt" $0 $1

exit $?

&cluster
    ncluster=5
    clustermethod="coordinate"
    pdbfile ="./data/test.pdb"
    datafile="./data/test.pdb",skipinitdata=2
    trajtype=2
    randomseed=1234
    ifwriteclustersnaps=.true.
    clusterscore="RSI"
/
