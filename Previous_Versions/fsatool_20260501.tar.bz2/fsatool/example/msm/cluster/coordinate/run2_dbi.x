#!/bin/bash

# mpirun -n 4 ../../../../fsatool msm cluster -i run2_dbi.x && exit

../../../run.x "mpirun -n 4 ../../../../fsatool msm cluster -i run2_dbi.x" \
"" $0 $1

exit $?

&cluster
    ncluster=5
    clustermethod="coordinate"
    datafile="../../../procinfo/leveltraj_0.nc", skipinitdata=2
    trajtype=2
    topfile="../../../procinfo/1le1.top"
    clusterselecttype="calpha"   ! allatom, backbone, calpha, sidechain, heavyatom, sideheavy
    randomseed=1234
    ifwriteclustersnaps=.true.
    clusterscore="DBI"
/
