#!/bin/bash

../../run.x "mpirun -n 1 ../../../fsatool msm ccp -i run6_ccp_classification.x" \
"" $0 $1

exit $?

&ccp
  ncluster1=5
  ncluster2=8
  ifgpubench=.true.
  icuda = 0
  reduceType="CCP"
  ccpfile="./data_row_gene_col_cell.csv"
  labelfile="./GSE67835_full_labels.csv"
  ifnorminputdata=.false.
  lowfeatureratio = 0.2
  splitdataratio = 0.9
  knncut = 3
  ifccppca = .true.
/

