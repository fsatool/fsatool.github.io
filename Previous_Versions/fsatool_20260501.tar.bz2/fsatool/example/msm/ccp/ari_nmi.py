import warnings
warnings.filterwarnings("ignore")

import numpy as np
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
import pandas as pd

y = pd.read_csv("./GSE67835_full_labels.csv")
y = np.array(list(y['Label'])).astype(int)
label = np.zeros(np.size(y))

with open("./save/run1_pca/ccp.out", "r") as f:
    i = 0
    while True:
        line = f.readline()
        if not line:
            break
        label[i] = line
        i += 1
ari = adjusted_rand_score(y, label)
nmi = normalized_mutual_info_score(y, label)
print("PCA ARI = ", ari)
print("PCA NMI = ", nmi)

with open("./save/run2_ccp/ccp.out", "r") as f:
    i = 0
    while True:
        line = f.readline()
        if not line:
            break
        label[i] = line
        i += 1
ari = adjusted_rand_score(y, label)
nmi = normalized_mutual_info_score(y, label)
print("CCP ARI = ", ari)
print("CCP NMI = ", nmi)
