
../../../../run.x "mpirun -np 1 ../../../../../fsatool msm cluster -i run8_kmeans_gpu_dbi.x" \
"" $0 $1

exit $?


&cluster
  ncluster=20, dataFile="../../../cluster/cv/cv_0.txt", randomSeed=25  
  ifgpubench=.true., 
  clusterMethod="kmeans", icuda=1
  clusterscore="DBI"
/

