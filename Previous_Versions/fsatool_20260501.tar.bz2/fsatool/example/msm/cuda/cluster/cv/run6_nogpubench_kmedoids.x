
../../../../run.x "mpirun -np 1 ../../../../../fsatool msm cluster -i run6_nogpubench_kmedoids.x" \
"" $0 $1

exit $?


&cluster
  ncluster=20, dataFile="../../../cluster/cv/cv_0.txt", randomSeed=25
  ifgpubench=.false.
  clusterMethod="kmedoids", icuda=1
/

