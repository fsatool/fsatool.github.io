
../../../../run.x "mpirun -np 1 ../../../../../fsatool msm cluster -i run5_nogpubench_kmeans.x" \
"" $0 $1

exit $?


&cluster
  ncluster=20, dataFile="../../../cluster/cv/cv_0.txt", randomSeed=25
  ifgpubench=.false., 
  clusterMethod="kmeans", icuda=1
/

