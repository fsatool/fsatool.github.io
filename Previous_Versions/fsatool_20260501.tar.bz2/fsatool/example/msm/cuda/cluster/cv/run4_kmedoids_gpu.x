
../../../../run.x "mpirun -np 2 ../../../../../fsatool msm cluster -i run4_kmedoids_gpu.x" \
"cluster.out residue_score_and_similarity_score.txt" $0 $1

exit $?


&cluster
  npicksnap = 500
  ncluster=20, dataFile="../../../cluster/cv/cv_0.txt", randomSeed=25  
  ifgpubench=.true., 
  clusterMethod="kmedoids", icuda=1
  clusterscore="RSI"
/

