
../../../../run.x "mpirun -np 2 ../../../../../fsatool msm  cluster -i run4_kmedoids_cpu_dbi.x" \
"" $0 $1

exit $?

&cluster
  ifgpubench=.true., kmedoidsmatsize=32, npicksnap=32
  ncluster=5, clustermethod="coordinate"
  datafile="../../../../procinfo/leveltraj_0.nc"
  skipinitdata=2
  trajtype=2
  topfile="../../../../procinfo/1le1.top"
  clusterselecttype="calpha"   ! allatom, backbone, calpha, sidechain, heavyatom, sideheavy
  randomseed=1234
  icuda = 0
  ifwriteclustersnaps=.true.
  clusterscore="DBI"
/

