
../../../../run.x "mpirun -np 2 ../../../../../fsatool msm  cluster -i run2_kmedoids_gpu_rsi.x" \
"cluster.out residue_score_and_similarity_score.txt" $0 $1

exit $?

&cluster
  ifgpubench=.true., npicksnap=32
  ncluster=5, clustermethod="coordinate"
  datafile="../../../../procinfo/leveltraj_0.nc"
  skipinitdata=2
  trajtype=2
  topfile="../../../../procinfo/1le1.top"
  clusterselecttype="calpha"   ! allatom, backbone, calpha, sidechain, heavyatom, sideheavy
  randomseed=1234
  icuda = 1
  ifwriteclustersnaps=.true.
  clusterscore="RSI"
/

