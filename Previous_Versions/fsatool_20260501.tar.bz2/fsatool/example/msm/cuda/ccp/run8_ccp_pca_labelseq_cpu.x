#!/bin/bash

../../../run.x "mpirun -n 1 ../../../../fsatool msm ccp -i run8_ccp_pca_labelseq_cpu.x" \
"ccp.out cell_feature_space.txt" $0 $1

exit $?

&ccp
  ncluster1=5
  ncluster2=8
  ncluster3=2
  ifgpubench=.true.
  icuda = 0
  reduceType="CCP"
  ccpfile="../../ccp/mnist_row_sample_col_labelseq.txt"
  randomSeed=25
  dataformat="labelseq"
  lowfeatureratio=0.5
!  testfile="../../ccp/mnist_row_sample_col_labelseq.txt"
!  knncut=5
  ifnorminputdata=.true.

  pcadimsteps = 2
  ifopt2d=.true.
  clustercontractionratio = 1.0
  clusteroptstepsize = 10.0
  clusteroptstepnum =  100
  clusteroptdisratio = 100.0
/
