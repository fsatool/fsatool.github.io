#!/bin/bash

../../../run.x "mpirun -n 1 ../../../../fsatool msm ccp -i run1_pca.x" \
"ccp.out cell_feature_space.txt" $0 $1

exit $?

&ccp
  ncluster1=5
  ncluster2=8
  ifgpubench=.true.
  icuda = 1
  reduceType="PCA"
  ccpfile="../../ccp/data_row_gene_col_cell.csv"
  ifnorminputdata=.false.
/

