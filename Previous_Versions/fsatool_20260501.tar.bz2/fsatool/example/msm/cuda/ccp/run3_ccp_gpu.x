#!/bin/bash

../../../run.x "mpirun -n 1 ../../../../fsatool msm ccp -i run3_ccp_gpu.x" \
"ccp.out cell_feature_space.txt" $0 $1

exit $?

&ccp
  ncluster1=5
  ncluster2=8
  ifgpubench=.true.
  icuda = 1
  reduceType="CCP"
  ccpfile="../../ccp/data_row_gene_col_cell.csv"
  labelfile="../../ccp/GSE67835_full_labels.csv"
  ifnorminputdata=.false.
/

