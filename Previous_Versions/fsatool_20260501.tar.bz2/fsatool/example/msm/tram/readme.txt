data.txt file includes all the sampling data at all the levels

200 10 : frame number (100 per level), cluster number
col1 : snap index
col2 : cluster index
col3 : traj index
