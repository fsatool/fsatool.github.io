#!/bin/bash

# mpirun ../../../fsatool msm tram -i run.x && exit

../../run.x "mpirun ../../../fsatool msm tram -i run.x" \
"tram_tpm.txt" $0 $1

exit $?

&tram
    temperature=300,330
    nlevel=2
    lagstep=1
    datafile="data.txt"
/
