#!/bin/bash

# rm -rf picksnap; mkdir picksnap; \
# mpirun -np 1 ../../../fsatool msm picksnap -i run1_pick_from_cv.x; \
# mv cluster* state* log.txt picksnap && exit

../../run.x "mpirun -np 1 ../../../fsatool msm picksnap -i run1_pick_from_cv.x" \
"cluster_3.nc state_1_cluster.nc state_2.nc state_3.nc state_1_cluster.pdb" $0 $1

exit $?

&picksnap
    topfile="../../procinfo/1le1.top"
    coorfiles="../../procinfo/leveltraj_0.nc","../../procinfo/leveltraj_1.nc"
    clusterindex=3
    stateindex=2, 3
    stateclusterindex=1
    msmdir="../all_in_one/save/run1_msm_cv/info/"
/
