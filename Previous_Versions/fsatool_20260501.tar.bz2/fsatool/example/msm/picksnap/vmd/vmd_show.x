module unload python/3/3.7.0
module load anaconda/3/5.2.0

python vmd_show.py -p ../../../procinfo/1le1.prmtop -t ../save/run1_pick_from_cv/state_2.nc
