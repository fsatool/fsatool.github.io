#!/bin/bash

# rm -rf picksnap; mkdir picksnap; \
# mpirun -np 1 ../../../fsatool msm picksnap -i run2_pick_from_coor.x; \
# mv state* picksnap && exit

../../run.x "mpirun -np 1 ../../../fsatool msm picksnap -i run2_pick_from_coor.x" \
"state_1_cluster.nc state_1.nc state_2.nc state_1_cluster.pdb" $0 $1

exit $?

&picksnap
    topfile="../../procinfo/1le1.top"
    coorfiles="../../procinfo/leveltraj_0.nc","../../procinfo/leveltraj_1.nc"
    stateindex=0
    stateclusterindex=1
    msmdir="../all_in_one/save/run2_msm_coordinate/info/"
/
