../run.x "mpirun -np 1 ../../fsatool sim -i ./run054_fep_octbox.x -p ./data/complex/pep.top -c ./data/complex/pep.crd -r ./data/complex/pep.rst" \
"./procinfo/fepdata.txt" $0 $1

exit $?

&sim
  ipb=1, discut=5.0, icuda=0, lagfreq=5.0, maxstep=100, printcvstep=2, savetrajstep=10000, deltatime=0.002, kelvin0=300.0, iseed=0, ishake=1
  task="fep"
/

&fep
  fepwindow = 5
  fepeqstep = 2
  fepsimstep = 6
  fepsamplestep = 2
  fepmolid = 1,2
  iffepsoftcore = .true.
/

