../run.x "mpiexec -np 1 ../../fsatool sim -i ./run048_ljpme.x -p ../procinfo/rectbox/1le1.top -c ../procinfo/rectbox/1le1.crd -r ../procinfo/rectbox/1le1.rst" \
"./procinfo/levelinfo_0.txt" $0 $1

exit $?

&sim
  imin=0, ipb=1, iljpme=1, discut=10.0, icuda=0, kelvin0=300.0, saltcon=0.1, iseed=0, lagfreq=0.0, ishake=1, deltatime=0.002, maxstep=6, printcvstep=2, savetrajstep=10000000
/
