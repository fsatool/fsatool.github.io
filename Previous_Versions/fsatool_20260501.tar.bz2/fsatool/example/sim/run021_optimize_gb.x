# $0 : shell filename, $1 : the first argument parameter, "update"
../run.x "mpirun -np 1 ../../fsatool sim -i ./run021_optimize_gb.x -p ../procinfo/1le1.top -c ../procinfo/1le1.crd -r ../procinfo/1le1.rst" \
"./procinfo/restart_0.rst" $0 $1

exit $?

&sim
  imin=1, igb=1, icuda=0, optmaxstep=20, optsdpstep=10, printcvstep=5, drms=0.00001, iseed=123
/

