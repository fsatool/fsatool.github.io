# $0 : shell filename, $1 : the first argument parameter, "update"
../../run.x "mpirun -np 4 ../../../fsatool sim -i ./run041_remd_cpu.x -r ./save/run021_optimize/procinfo/restart_0.rst -m ./data/system_aden_m3.top" "./procinfo/levelinfo_0.txt ./procinfo/levelinfo_3.txt" $0 $1

exit $?

&sim
  ipb=1, icuda=0, discut=4.0, lagfreq=0.0, saltcon=0.1, maxstep=60, printcvstep=10, savetrajstep=20, deltatime=0.020, kelvin0=300.0, iseed=0, ishake=1
  task="flood"
/

! mixing REMD
&flood
  kelvindown=300.0, kelvinup=301.0, exchangestep=10, biasrep=1
  ss2cv=1,2, ssngrid=100,100, floodingtime=1.0
/

&fsacolvar
  cv_type = 'COM_DIS'
  cv_min = 0.0, cv_max = 20.0
  cv_i =   1,  0, 200
/

&fsacolvar
  cv_type = 'COM_DIS'
  cv_min = 0.0, cv_max = 20.0
  cv_i =   500,  0, 800
/
