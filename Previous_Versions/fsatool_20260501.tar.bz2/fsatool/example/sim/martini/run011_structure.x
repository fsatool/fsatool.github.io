# $0 : shell filename, $1 : the first argument parameter, "update"
mkdir procinfo
../../run.x "mpirun -np 1 ../../../fsatool sim -i ./run011_structure.x -m ./data/system_aden_m3.top -c ./data/system_aden_m3.crd" "" $0 $1

# save the execute infomation temporary
exitcode=$?
rm -r procinfo
exit $exitcode

&sim
  imin=-1, icuda=0
/
