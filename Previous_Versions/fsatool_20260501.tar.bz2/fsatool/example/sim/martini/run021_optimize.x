# $0 : shell filename, $1 : the first argument parameter, "update"
../../run.x "mpirun -np 1 ../../../fsatool sim -i ./run021_optimize.x -m ./data/system_aden_m3.top -c ./data/system_aden_m3.crd" "./procinfo/restart_0.rst" $0 $1

# save the execute infomation temporary
exitcode=$?
exit $exitcode

&sim
  imin=1, icuda=0, optmaxstep=100, optsdpstep=50, printcvstep=10, drms=0.00001, iseed=123
/
