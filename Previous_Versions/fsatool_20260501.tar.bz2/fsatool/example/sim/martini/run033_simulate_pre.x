# $0 : shell filename, $1 : the first argument parameter, "update"
../../run.x "mpirun -np 1 ../../../fsatool sim -i ./run033_simulate_pre.x -r ./save/run021_optimize/procinfo/restart_0.rst -m ./data/system_aden_m3.top" "./procinfo/levelinfo_0.txt" $0 $1

# save the execute infomation temporary
exitcode=$?
exit $exitcode

&sim
  ipb=0, taut=0.01, icuda=0, lagfreq=0.0, saltcon=0.1, maxstep=50, printcvstep=10, savetrajstep=50, deltatime=0.020, kelvin0=310.0, iseed=123, ishake=1
/
