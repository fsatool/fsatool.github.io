# $0 : shell filename, $1 : the first argument parameter, "update"

mkdir procinfo
../../run.x "mpirun -np 1 ../../../fsatool sim -i ./run011_structure_cpu.x -pdb ./data/test.pdb" "" $0 $1

rm -r procinfo
exit $?

&sim
  imin=-1, igb=0, icuda=0, deepmode=2
/

&gnn
  networkfile = "../../analysis/cuda/test5_gnn/network.txt"
  molnames = "./data/test"
/
