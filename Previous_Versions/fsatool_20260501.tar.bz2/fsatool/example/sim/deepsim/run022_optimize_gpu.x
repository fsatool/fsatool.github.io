# $0 : shell filename, $1 : the first argument parameter, "update"
../../run.x "mpirun -np 1 ../../../fsatool sim -i ./run022_optimize_gpu.x -pdb ./data/test.pdb" "" $0 $1

# save the execute infomation temporary
exitcode=$?
exit $exitcode

&sim
  deepmode=2, imin=1, icuda=1, optmaxstep=60, optsdpstep=30, printcvstep=10, drms=0.00001, iseed=123
/

&gnn
  networkfile = "../../analysis/cuda/test5_gnn/network.txt"
  molnames = "./data/test"
/
