# $0 : shell filename, $1 : the first argument parameter, "update"
../../run.x "mpirun -np 1 ../../../fsatool sim -i ./run032_simulate_gpu.x -pdb ./data/test.pdb -r ./save/run021_optimize_cpu/procinfo/restart_0.rst" \
"./procinfo/levelinfo_0.txt ./procinfo/leveltraj_0.nc" $0 $1

exit $?

&sim
  deepmode=2, icuda=1, lagfreq=0.0, maxstep=60, printcvstep=10, savetrajstep=20, deltatime=0.001, kelvin0=300.0, iseed=0, ishake=0
/

&gnn
  networkfile = "../../analysis/cuda/test5_gnn/network.txt"
  molnames = "./data/test"
/

&fsacolvar
  cv_type = 'COM_DIS'
  cv_i =   1,  0, 21
/
