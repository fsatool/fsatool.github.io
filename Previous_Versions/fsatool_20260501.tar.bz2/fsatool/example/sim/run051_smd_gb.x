../run.x "mpirun -np 4 ../../fsatool sim -i ./run051_smd_gb.x -p ../procinfo/1le1.top -c ../procinfo/1le1.crd -r ../procinfo/1le1.rst" \
"./procinfo/smd_pathfree.txt ./procinfo/smd_paths_0.txt ./procinfo/traj_1.nc ./procinfo/weight_1.txt" $0 $1

exit $?

&sim
  igb=1, icuda=0, lagfreq=5.0, maxstep=100, printcvstep=10, savetrajstep=20, deltatime=0.002, kelvin0=300.0, iseed=0, ishake=1
  task="smd"
/

! standard ABMD
!&flood
!  ss2cv=1,2, ssngrid=100,100, floodingtime=0.1, wellkelvin=10000.0
!/

! mixing REMD
&flood
  kelvindown=300.0, kelvinup=301.0, exchangestep=10, biasrep=1
  ss2cv=1,2, ssngrid=100,100, floodingtime=1.0
/

&temd
  nkelvin=4, kelvindown=200.0, kelvinup=500.0
  exchangestep=10, ! montensample=100
/

&smd
  smdleadcv=3, smdrelaxstep=10, reversefrag=10, smdspeed=40000.0,
  smdinicv=0.0,5.8,42.9, smdendcv=0.0,5.8,46.0, smdk=0.0,0.0,10.0
  smdpathfrag=10, smdnpath=5, smdweightstep=10
/

&fsacolvar
  cv_type = 'RMSD'
  cv_min = 0.0, cv_max = 20.0
  cv_i =     5,    16,    40,    54,    78,    93,   107,   114,   136,   160,   174,   198, 0, 
  cv_r = 
     4.018,      3.070,      0.130,      7.760,      3.987,     -0.210, 
    10.051,      7.121,     -0.016,     13.783,      8.078,     -0.453, 
    16.234,     11.064,     -0.078,     20.008,     11.867,     -0.555, 
    22.623,     14.620,      0.220,     26.423,     15.326,     -0.123, 
    28.852,     18.293,      0.361,     32.685,     18.848,      0.081, 
    35.299,     21.673,      0.511,     39.134,     22.254,      0.357, 
/
 
&fsacolvar
  cv_type = 'NCONTACT'
  cv_min = 0.0, cv_max = 9.0
  cv_i =   12,   52,   27,   76,   50,   91,   65,  105,   89,  112,  103,  134,  110,  158,  132,  172,  147,  196, 
  cv_r =  9.0
/

&fsacolvar
  cv_type = 'COM_DIS'
  cv_i =   1,  0, 218
/
