# $0 : shell filename, $1 : the first argument parameter, "update"
mkdir procinfo
../run.x "mpirun -np 1 ../../fsatool sim -i ./run013_structure_octbox.x -p ../procinfo/octbox/1le1.top -c ../procinfo/octbox/1le1.crd" "" $0 $1

exitcode=$?
rm -r procinfo
exit $exitcode

&sim
  imin=-1, ipb=1, icuda=0, discut=10.0 
/
