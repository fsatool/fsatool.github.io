# $0 : shell filename, $1 : the first argument parameter, "update"
../../run.x "mpirun -np 1 ../../../fsatool sim -i ./run034_cv_rectbox_npt.x -p ../../procinfo/rectbox/1le1.top -c ../../procinfo/rectbox/1le1.crd -r ../../procinfo/rectbox/1le1.rst" \
"./procinfo/levelinfo_0.txt" $0 $1

exit $?

&sim
! for molecular dynamics simulation
  ipb=2, icuda=1, discut=4.0, lagfreq=0.0, maxstep=60, printcvstep=10, savetrajstep=1000, deltatime=0.001, kelvin0=300.0, iseed=0, ishake=0
/

! distance between the centroids of two atom groups
&fsacolvar
  cv_type = 'COM_DIS'
  cv_i =   1,  0, 218         ! atom group1 {1}, group2 {218}
/

! average distance between two sets of atoms
&fsacolvar
  cv_type = 'DISAVG'
  cv_i =   5, 174, 16, 198    ! atom pairs 5-174, 16-198
/

! average centroid distance between two sets of residues in a protein
&fsacolvar
  cv_type = 'DISAVGRES'
  cv_i =   1, 11, 2, 12       ! residue pairs 1-11, 2-12
/

! least root-mean-square deviation to a reference structure
&fsacolvar
  cv_type = 'RMSD'
! atom indices in a reference structure
  cv_i =     5,    16,    40,    54,    78,    93,   107,   114,   136,   160,   174,   198,
! atom coordinates (x,y,z) in a reference structure
  cv_r =
     4.018,      3.070,      0.130,      7.760,      3.987,     -0.210,
    10.051,      7.121,     -0.016,     13.783,      8.078,     -0.453,
    16.234,     11.064,     -0.078,     20.008,     11.867,     -0.555,
    22.623,     14.620,      0.220,     26.423,     15.326,     -0.123,
    28.852,     18.293,      0.361,     32.685,     18.848,      0.081,
    35.299,     21.673,      0.511,     39.134,     22.254,      0.357,
/

! distance root-mean-square deviation to a reference structure
&fsacolvar
  cv_type = 'DRMSD'
! atom indices in a reference structure
  cv_i =    1, 107, 218
! atom distances in a reference structure
  cv_r =    20.0, 30.0, 40.0     ! atom distances between atom pairs 1-107, 1-218, 107-218 
/

! three-atom angle (radians)
&fsacolvar
  cv_type = 'ANGLE'
  cv_i = 1, 107, 218
/

! four-atom dihedral (radians)
&fsacolvar
  cv_type = 'DIHEDRAL'
  cv_i = 1, 54, 107, 218   
/

! contact number between some pairs of atoms
&fsacolvar
  cv_type = 'NCONTACT'
  cv_i =   12,   52,   27,   76,      ! atom pairs 12-52, 27-76
  cv_r =  9.0
/

! contact number between some pairs of residues in a protein
&fsacolvar
  cv_type = 'NCONTACTRES'
  cv_i =   4,  9,  2,  11,      ! residue pairs 4-9, 2-11
  cv_r =  9.0
/

! radius of gyration of atoms
&fsacolvar
  cv_type = 'GYRATION'
  cv_i =   1, 107, 218,      ! atom indices
/

! radius of gyration of residues in a protein
&fsacolvar
  cv_type = 'GYRATIONRES'
  cv_i =   2, 4, 9, 11      ! residue indices
/
