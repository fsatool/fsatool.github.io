# $0 : shell filename, $1 : the first argument parameter, "update"
../run.x "mpirun -np 1 ../../fsatool sim -i ./run022_optimize_rectbox.x -p ../procinfo/rectbox/1le1.top -c ../procinfo/rectbox/1le1.crd" \
"./procinfo/restart_0.rst" $0 $1

exit $?

&sim
  imin=1, ipb=1, icuda=0, discut=4.0, printcvstep=4
  optmaxstep=20, optsdpstep=10, drms=0.00001, iseed=123
/

