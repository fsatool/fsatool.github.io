../run.x "mpirun -np 5 ../../fsatool sim -i ./run064_flood_tica_stream.x -p ../procinfo/1le1.top -c ../procinfo/1le1.crd -r ../procinfo/1le1.rst" \
"tica_eigeninfo.txt tica_eigenerr.txt ./procinfo/levelinfo_0.txt ./procinfo/levelinfo_3.txt" $0 $1

exit $?

&sim
  igb=1, icuda=0, lagfreq=5.0, saltcon=0.1, igbsa=1, maxstep=64, printcvstep=2, savetrajstep=20, deltatime=0.001, kelvin0=300.0, iseed=1234, ishake=0
  task="flood"
/

&flood
  kelvindown=300.0, kelvinup=300.0, exchangestep=8, biasrep=2
  ss2cv=4,5, ssngrid=100,100, floodingtime=0.01
/

&fsacolvar
  cv_type = 'RMSD'
  cv_min = 0.0, cv_max = 20.0
  cv_i =     5,    16,    40,    54,    78,    93,   107,   114,   136,   160,   174,   198, 0, 
  cv_r = 
     4.018,      3.070,      0.130,      7.760,      3.987,     -0.210, 
    10.051,      7.121,     -0.016,     13.783,      8.078,     -0.453, 
    16.234,     11.064,     -0.078,     20.008,     11.867,     -0.555, 
    22.623,     14.620,      0.220,     26.423,     15.326,     -0.123, 
    28.852,     18.293,      0.361,     32.685,     18.848,      0.081, 
    35.299,     21.673,      0.511,     39.134,     22.254,      0.357, 
/
 
&fsacolvar
  cv_type = 'NCONTACT'
  cv_min = 0.0, cv_max = 9.0
  cv_i =   12,   52,   27,   76,   50,   91,   65,  105,   89,  112,  103,  134,  110,  158,  132,  172,  147,  196, 
  cv_r =  9.0
/

&fsacolvar
  cv_type = 'COM_DIS'
  cv_i =   1,  0, 218
/

&fsacolvar
  cv_type = 'TICA'
  cv_min=-1.0, cv_max=1.0
  cv_i =  1, 2                          ! tica components
  cv_i2 =  1, 3                         ! cv index range
  cv_i3 =  8, 2                         ! cached cv records and lag step
  cv_r  =    1.143,    0.368,    0.111, ! reference eigenvector
  cv_r2 =    9.159,    6.444,   15.883, ! reference data average
/

&fsacolvar
  cv_type = 'TICA'
  cv_min=-1.0, cv_max=1.0
  cv_i =  1, 2                          ! tica components
  cv_i2 =  1, 3                         ! cv index range
  cv_i3 =  8, 2                         ! cached cv records and lag step
  cv_r  =    1.031,    2.511,    0.384, ! reference eigenvector
  cv_r2 =    9.159,    6.444,   15.883, ! reference data average
/
