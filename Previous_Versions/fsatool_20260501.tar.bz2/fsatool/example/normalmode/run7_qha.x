#!/bin/bash

#set -x
infile="qha.in"
outfile="qha.out"
moldir="../surfpb/mol/"
execute="mpirun -n 1 ../../fsatool normalmode qha -i $infile -o $outfile"
run="../run.x"
checkfile="qha.out eigens/eigens_traj1_snap1.txt"

#write the namelistfile
cat > $infile << EOF

### normalmode namelist file ###
&qha
   topfile    = "${moldir}pep.top"
   trajfiles  = "${moldir}pep.nc"
   temperature = 298.15, molarray = 1,0,2
   neigens = 5, freqcut = 0.1
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
