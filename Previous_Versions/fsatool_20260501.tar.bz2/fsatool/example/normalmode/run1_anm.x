#!/bin/bash

#set -x
infile='anm.in'
execute="mpirun -n 1 ../../fsatool normalmode anm -i $infile"
checkfile="./eigens/eigens_traj1_snap1.txt res_fluc_traj1_snap1.txt"

#write the infile
cat > $infile << EOF

### normalmode namelist file ###
&anm
   pdbfile = "../procinfo/model.pdb"
   neigens=3, discut=13.0, stiffness=1.0
/

EOF

if [[ $1 != test ]]; then
   ../run.x "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
