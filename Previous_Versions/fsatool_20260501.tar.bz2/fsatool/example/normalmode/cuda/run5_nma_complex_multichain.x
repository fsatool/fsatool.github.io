#!/bin/bash

#set -x
infile="nma.in"
outfile="nma.out"
moldir="../../surfpb/mol/"
execute="mpirun -n 1 ../../../fsatool normalmode nma -i $infile -o $outfile"
run="../../run.x"
checkfile="nma.out"

#write the namelistfile
cat > $infile << EOF

### normalmode namelist file ###
&nma
   topfile    = "${moldir}pep.top"
   trajfiles  = "${moldir}pep.nc"
   icuda = 1, igb = 1, imin = 1, saltcon = 0.100
   temperature = 298.15, molarray = 1,3,0,2,4
   skipinitdata = 1, skipdata = 1
   freqcut = 1.0
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
