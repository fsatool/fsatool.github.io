#!/bin/bash

#set -x
infile="nma.in"
outfile="nma.out"
moldir="../../surfpb/mol/"
execute="mpirun -n 1 ../../../fsatool normalmode nma -i $infile -o $outfile"
run="../../run.x"
checkfile="nma.out ./eigens/eigens_traj1_snap2.txt"

#write the namelistfile
cat > $infile << EOF

### normalmode namelist file ###
&nma
   topfile    = "${moldir}pep.top"
   trajfiles  = "${moldir}pep.nc"
   icuda = 1, igb = 1, igbsa = 1, imin = 1, saltcon = 0.100
   temperature = 298.15, molarray = 1,0,2
   skipinitdata = 1, skipdata = 1
   neigens = 3
   discut = 10000.0, freqcut = 0.1
/

EOF


if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
