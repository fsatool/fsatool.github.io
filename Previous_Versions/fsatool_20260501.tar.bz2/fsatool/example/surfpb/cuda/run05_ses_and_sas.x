#!/bin/bash

#set -x
infile="surfpb.in"
outfile="surfpb.out"
moldir="../../surfpb/mol/"
execute="mpirun -n 1 ../../../fsatool surfpb -i $infile -o $outfile"
run="../../run.x"
checkfile="surfpb.out"

#write the namelistfile
cat > $infile << EOF

### surfpb namelist file ###
&surfpb
   pqrfile    = "${moldir}pep.pqr"
   isurface   = 2
   ! 1 : generate the triangles and vertices after the solvation energy calculation
   ! 2 : skip solvation energy calculation and
   !     generate the triangles and vertices without potentials
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
