#!/bin/bash

#set -x
infile="surfpb.in"
outfile="surfpb.out"
moldir="../../surfpb/mol/"
execute="mpirun -n 1 ../../../fsatool surfpb -i $infile -o $outfile"
run="../../run.x"
checkfile="surfpb.out"

#write the namelistfile
cat > $infile << EOF

### surfpb namelist file ###
&surfpb
   topfile    = "${moldir}pep.top"
   trajfiles  = "${moldir}pep.nc"
   saltcon = 0.100, epsin = 1.0, epsout = 80.0
   ipbtype = 2, inonpolar = 1, temperature = 298.15
   icuda = 1, ientropy = 0, igb = 1, imin = 0
   skipinitdata = 1, skipdata = 1
   molarray = 1,0,2
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
