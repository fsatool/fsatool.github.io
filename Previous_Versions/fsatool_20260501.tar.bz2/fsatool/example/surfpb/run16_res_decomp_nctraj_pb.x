#!/bin/bash

#set -x
infile="surfpb.in"
outfile="surfpb.out"
moldir="./mol/"
execute="mpirun -n 1 ../../fsatool surfpb -i $infile -o $outfile"
run="../run.x"
checkfile="surfpb.out decomp_atompair_001.txt decomp_respair_001.txt residx.txt"

#write the namelistfile
cat > $infile << EOF

### surfpb namelist file ###
&surfpb
   topfile    = "${moldir}pep.top"
   !crdfile    = "${moldir}pep.crd"
   trajfiles  = "${moldir}pep.nc"
   saltcon = 0.100, epsin = 1.0, epsout = 80.0
   ipbtype = 1, inonpolar = 1, temperature = 298.15
   icuda = 0, ientropy = 0, igb = 1, imin = 0
   skipinitdata = 0, skipdata = 5
   ipairdecomp = 2         ! 1: decompose on residue level
                           ! 2: decompose on atom level
   molarray = 3
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
