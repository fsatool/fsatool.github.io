#!/bin/bash

#set -x
infile="surfpb.in"
outfile="surfpb.out"
moldir="./mol/"
execute="mpirun -n 1 ../../fsatool surfpb -i $infile -o $outfile"
run="../run.x"
checkfile="surfpb.out ses_1.ply"

#write the namelistfile
cat > $infile << EOF

### surfpb namelist file ###
&surfpb
   topfile    = "${moldir}pep.top"
   trajfiles  = "${moldir}pep.nc"
   isurface   = 3
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
