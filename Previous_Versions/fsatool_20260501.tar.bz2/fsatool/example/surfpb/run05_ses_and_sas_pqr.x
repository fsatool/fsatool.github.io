#!/bin/bash

#set -x
infile="surfpb.in"
outfile="surfpb.out"
moldir="./mol/"
execute="mpirun -n 1 ../../fsatool surfpb -i $infile -o $outfile"
run="../run.x"
checkfile="surfpb.out ses_0.ply sas_0.ply"

#write the namelistfile
cat > $infile << EOF

### surfpb namelist file ###
&surfpb
   pqrfile    = "./specialcase/specialmol/test3.pqr"
   subdividelevel = 1
   isurface   = 1
   ! 0 : normal PBSA calculation, no surface file output
   ! 1 : normal PBSA calculation, generate triangles and vertices with electrostatic potentials
   ! 2 : skip PBSA calculation, only output the area data
   ! 3 : skip PBSA calculation, generate triangles and vertices data file
/

EOF

if [[ $1 != test ]]; then
   "$run" "$execute" "$checkfile" $0 $1
else
   $execute
fi

status=$?
/bin/rm -f $infile

exit $status
