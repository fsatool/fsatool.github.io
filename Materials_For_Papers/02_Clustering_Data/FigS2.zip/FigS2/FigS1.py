
from PIL import Image
import matplotlib.pyplot as plt
from PIL import ImageDraw, ImageFont

img1 = Image.open(r"C:\Users\junyong\Desktop\all\paper\plot\FigS1\FigS1_a\FigS1_a.png")
img2 = Image.open(r"C:\Users\junyong\Desktop\all\paper\plot\FigS1\FigS1_b\FigS1_b.png")
result = Image.new(img1.mode, (640*2, 480 ))
result.paste(img1, box=(0, 0))
result.paste(img2, box=(640, 0))
draw = ImageDraw.Draw(result)
fnt = ImageFont.truetype(r'C:\Windows\Fonts\simkai.ttf', 50)
draw.text(xy=(0,-18), text="a", fill='black',font=fnt)
draw.text(xy=(625,-5), text="b", fill='black',font=fnt)
result.save(r"C:\Users\junyong\Desktop\all\paper\plot\FigS1\FigS1.png")




