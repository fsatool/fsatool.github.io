from PIL import Image
import matplotlib.pyplot as plt
from PIL import ImageDraw, ImageFont

img1 = Image.open(r'E:\C\Desktop\all\paper\plot\Fig7\fig7_a\fig7_a.png')
img2 = Image.open(r'E:\C\Desktop\all\paper\plot\Fig7\fig7_b\fig7_b.png')
img3 = Image.open(r'E:\C\Desktop\all\paper\plot\Fig7\fig7_c\fig7_c.png')
result = Image.new(img1.mode, (650, 450*3 ))
result.paste(img1, box=(18, 0))
result.paste(img2, box=(0, 435))
result.paste(img3, box=(0, 435*2+5))
draw = ImageDraw.Draw(result)
fnt = ImageFont.truetype(r'C:\Windows\Fonts\simkai.ttf', 50)
draw.text(xy=(570,25), text="a", fill='black',font=fnt)
draw.text(xy=(570,470), text="b", fill='black',font=fnt)
draw.text(xy=(562,900), text="c", fill='black',font=fnt)
result.save(r"E:\C\Desktop\all\paper\plot\Fig7\fig7.png")




