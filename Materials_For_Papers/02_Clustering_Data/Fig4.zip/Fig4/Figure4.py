import matplotlib.pyplot as plt
import numpy as np
data = np.genfromtxt("data4.txt",dtype=[int, float, float, float, float, float, float, float, float, float, float])  # 将文件中数据加载到data数组里
x = np.zeros(len(data))
y = np.zeros(len(data))
std_err= np.zeros(len(data))
for i in range(len(data)):
    x[i]=data[i][0]
    tpy=np.zeros(10)
    for j in range(10):
        tpy[j]=data[i][j+1]
    y[i]=np.average(tpy)
    std_err[i]=np.std(tpy)
plt.tick_params(labelsize=15)
plt.ylabel("Calculation Time (sec)",fontsize=20)
plt.xlabel("Test Center",fontsize=20)
error_params=dict(elinewidth=4,ecolor='k',capsize=5)#设置误差标记参数
#绘制柱状图，设置误差标记以及柱状图标签
color=[]
for i in range(len(y)):
    color.append('orange')
plt.bar(x,y,color=color,yerr=std_err,error_kw=error_params,\
                    tick_label=['32 (first)','32', '64','96','128', '160', '192', '224', '256', '288', '320'])
#显示图形
plt.show()
