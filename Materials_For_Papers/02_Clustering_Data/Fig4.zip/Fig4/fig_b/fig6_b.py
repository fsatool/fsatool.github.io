from bokeh.plotting import figure, output_file, show
from bokeh.models import CategoricalColorMapper, ColumnDataSource
from bokeh.palettes import Category10, Category20
import numpy as np
import umap
from sklearn.datasets import load_digits
import matplotlib.pyplot as plt
plt.figure(figsize=(13/2,9/2))
natom = 33
num=[]
sum=0
# 6 26 33 64 68 234 237
f1=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig5\pdb_files\cluster_6.pdb')
line = " "
coordinate1=[]
while line:  # 直到读取完文件
    line = f1.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if((len(splitline) > 0) and splitline[0] == "ATOM"): # 读到原子，就把坐标加入
        coordinate1.append(splitline[5])
        coordinate1.append(splitline[6])
        coordinate1.append(splitline[7])
f1.close()  # 关闭文件
coordinate1=np.array(coordinate1)
coordinate1=coordinate1.reshape(int(len(coordinate1)/(3*natom)), 3*natom)
testdata1 = coordinate1
testlabel1=[]
for i in range(testdata1.shape[0]):
    testlabel1 = np.append(testlabel1, "1");
sum += len(testlabel1)
num.append(sum)

# 6 26 33 64 68 234 237
f2=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig5\pdb_files\cluster_26.pdb')
line = " "
coordinate2=[]
while line:  # 直到读取完文件
    line = f2.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if((len(splitline) > 0) and splitline[0] == "ATOM"): # 读到原子，就把坐标加入
        coordinate2.append(splitline[5])
        coordinate2.append(splitline[6])
        coordinate2.append(splitline[7])
f2.close()  # 关闭文件
coordinate2=np.array(coordinate2)
coordinate2=coordinate2.reshape(int(len(coordinate2)/(3*natom)), 3*natom)
testdata2 = coordinate2
testlabel2=[]
for i in range(testdata2.shape[0]):
    testlabel2 = np.append(testlabel2, "2");
sum += len(testlabel2)
num.append(sum)

# 6 26 33 64 68 234 237
f3=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig5\pdb_files\cluster_33.pdb')
line = " "
coordinate3=[]
while line:  # 直到读取完文件
    line = f3.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if((len(splitline) > 0) and splitline[0] == "ATOM"): # 读到原子，就把坐标加入
        coordinate3.append(splitline[5])
        coordinate3.append(splitline[6])
        coordinate3.append(splitline[7])
f3.close()  # 关闭文件
coordinate3=np.array(coordinate3)
coordinate3=coordinate3.reshape(int(len(coordinate3)/(3*natom)), 3*natom)
testdata3 = coordinate3
testlabel3=[]
for i in range(testdata3.shape[0]):
    testlabel3 = np.append(testlabel3, "3");
sum += len(testlabel3)
num.append(sum)

# 6 26 33 64 68 234 237
f4=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig5\pdb_files\cluster_64.pdb')
line = " "
coordinate4=[]
while line:  # 直到读取完文件
    line = f4.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if((len(splitline) > 0) and splitline[0] == "ATOM"): # 读到原子，就把坐标加入
        coordinate4.append(splitline[5])
        coordinate4.append(splitline[6])
        coordinate4.append(splitline[7])
f4.close()  # 关闭文件
coordinate4=np.array(coordinate4)
coordinate4=coordinate4.reshape(int(len(coordinate4)/(3*natom)), 3*natom)
testdata4 = coordinate4
testlabel4=[]
for i in range(testdata4.shape[0]):
    testlabel4 = np.append(testlabel4, "4");
sum += len(testlabel4)
num.append(sum)

# 6 26 33 64 68 234 237
f5=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig5\pdb_files\cluster_68.pdb')
line = " "
coordinate5=[]
while line:  # 直到读取完文件
    line = f5.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if((len(splitline) > 0) and splitline[0] == "ATOM"): # 读到原子，就把坐标加入
        coordinate5.append(splitline[5])
        coordinate5.append(splitline[6])
        coordinate5.append(splitline[7])
f5.close()  # 关闭文件
coordinate5=np.array(coordinate5)
coordinate5=coordinate5.reshape(int(len(coordinate5)/(3*natom)), 3*natom)
testdata5 = coordinate5
testlabel5=[]
for i in range(testdata5.shape[0]):
    testlabel5 = np.append(testlabel5, "5");
sum += len(testlabel5)
num.append(sum)

# 6 26 33 64 68 234 237
f6=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig5\pdb_files\cluster_234.pdb')
line = " "
coordinate6=[]
while line:  # 直到读取完文件
    line = f6.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if((len(splitline) > 0) and splitline[0] == "ATOM"): # 读到原子，就把坐标加入
        coordinate6.append(splitline[5])
        coordinate6.append(splitline[6])
        coordinate6.append(splitline[7])
f6.close()  # 关闭文件
coordinate6=np.array(coordinate6)
coordinate6=coordinate6.reshape(int(len(coordinate6)/(3*natom)), 3*natom)
testdata6 = coordinate6
testlabel6=[]
for i in range(testdata6.shape[0]):
    testlabel6 = np.append(testlabel6, "6");
sum += len(testlabel6)
num.append(sum)

# 6 26 33 64 68 234 237
f7=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig5\pdb_files\cluster_237.pdb')
line = " "
coordinate7=[]
while line:  # 直到读取完文件
    line = f7.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if((len(splitline) > 0) and splitline[0] == "ATOM"): # 读到原子，就把坐标加入
        coordinate7.append(splitline[5])
        coordinate7.append(splitline[6])
        coordinate7.append(splitline[7])
f7.close()  # 关闭文件
coordinate7=np.array(coordinate7)
coordinate7=coordinate7.reshape(int(len(coordinate7)/(3*natom)), 3*natom)
testdata7 = coordinate7
testlabel7=[]
for i in range(testdata7.shape[0]):
    testlabel7 = np.append(testlabel7, "7");
sum += len(testlabel7)
num.append(sum)

print(testdata1.shape[0],testdata1.shape[1])   
print(testdata2.shape[0],testdata2.shape[1])   
print(testdata3.shape[0],testdata3.shape[1])   
print(testdata4.shape[0],testdata4.shape[1])   
print(testdata5.shape[0],testdata5.shape[1])   
print(testdata6.shape[0],testdata6.shape[1])   
print(testdata7.shape[0],testdata7.shape[1]) 

coordinate = np.array([])
coordinate = np.append(coordinate, coordinate1)
coordinate = np.append(coordinate, coordinate2)
coordinate = np.append(coordinate, coordinate3)
coordinate = np.append(coordinate, coordinate4)
coordinate = np.append(coordinate, coordinate5)
coordinate = np.append(coordinate, coordinate6)
coordinate = np.append(coordinate, coordinate7)
coordinate=coordinate.reshape(int(len(coordinate)/(3*natom)), 3*natom)
testdata = coordinate
print(testdata.shape[0],testdata.shape[1]) 

testlabel = np.array([])
testlabel = np.append(testlabel, testlabel1)
testlabel = np.append(testlabel, testlabel2)
testlabel = np.append(testlabel, testlabel3)
testlabel = np.append(testlabel, testlabel4)
testlabel = np.append(testlabel, testlabel5)
testlabel = np.append(testlabel, testlabel6)
testlabel = np.append(testlabel, testlabel7)
print(testlabel.shape[0]) 
print(testlabel)
 
# n_neighbors=20,min_dist=0.1,metric='correlation',random_state=50
embedding = umap.UMAP(n_neighbors=20,
                      min_dist=0.1,
                      metric='correlation',random_state=50).fit_transform(testdata)
#print(embedding) #UMAP降维后的数据
print(embedding.shape[0],embedding.shape[1])  
#output_file("test.html")

x1=np.array(embedding[0:num[0]])
x2=np.array(embedding[num[0]:num[1]])
x3=np.array(embedding[num[1]:num[2]])
x4=np.array(embedding[num[2]:num[3]])
x5=np.array(embedding[num[3]:num[4]])
x6=np.array(embedding[num[4]:num[5]])
x7=np.array(embedding[num[5]:num[6]])


s1=plt.scatter(x1[:,0], x1[:,1], color='blue')  # 6
s2=plt.scatter(x2[:,0], x2[:,1], color='cyan') # 26
s3=plt.scatter(x3[:,0], x3[:,1], color='magenta') # 33
s4=plt.scatter(x4[:,0], x4[:,1], color='red') # 64
s5=plt.scatter(x5[:,0], x5[:,1], color='black') # 68
s6=plt.scatter(x6[:,0], x6[:,1], color='yellow') # 234
s7=plt.scatter(x7[:,0], x7[:,1], color='green') # 237


# 6 26 33 64 68 234 237
plt.xticks([-15,-10,-5,0,5,10,15,20],fontsize=20)
plt.yticks([-10,-5,0,5,10,15,20],fontsize=20)
font = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 20,
        }
plt.xlabel("UMAP_1",fontdict=font)
plt.ylabel("UMAP_2",fontdict=font)
#plt.legend((s1,s2,s3,s4,s5,s6,s7),('1','2','3','4','5','6','7') ,loc = 'upper left')
plt.tight_layout()
plt.savefig(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_b\fig6_b.png')
plt.show()
