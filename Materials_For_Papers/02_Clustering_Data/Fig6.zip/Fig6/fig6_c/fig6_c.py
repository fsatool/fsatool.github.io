# coding=utf-8
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
plt.figure(figsize=(13/2,9/2))
f=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_c\residue_score_and_similarity_score_0317.txt')
line = " "
r_score1=[]
s_score1=[]
r_score2=[]
s_score2=[]
r_score3=[]
s_score3=[]
r_score4=[]
s_score4=[]
r_score5=[]
s_score5=[]
r_score6=[]
s_score6=[]
r_score7=[]
s_score7=[]
# 6 26 33 64 68 234 237
while line:  # 直到读取完文件
    line = f.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 and int(splitline[1]) == 6):
        r_score1.append(float(splitline[2]))
        s_score1.append(float(splitline[3]))
    if(len(splitline) > 0 and int(splitline[1]) == 26):
        r_score2.append(float(splitline[2]))
        s_score2.append(float(splitline[3]))
    if(len(splitline) > 0 and int(splitline[1]) == 33):
        r_score3.append(float(splitline[2]))
        s_score3.append(float(splitline[3]))
    if(len(splitline) > 0 and int(splitline[1]) == 64):
        r_score4.append(float(splitline[2]))
        s_score4.append(float(splitline[3]))
    if(len(splitline) > 0 and int(splitline[1]) == 68):
        r_score5.append(float(splitline[2]))
        s_score5.append(float(splitline[3]))
    if(len(splitline) > 0 and int(splitline[1]) == 234):
        r_score6.append(float(splitline[2]))
        s_score6.append(float(splitline[3]))
    if(len(splitline) > 0 and int(splitline[1]) == 237):
        r_score7.append(float(splitline[2]))
        s_score7.append(float(splitline[3]))
f.close()  # 关闭文件


s1=plt.scatter(r_score1, s_score1, color='blue')  # 6
s2=plt.scatter(r_score2, s_score2, color='cyan') # 26
s3=plt.scatter(r_score3, s_score3, color='magenta') # 33
s4=plt.scatter(r_score4, s_score4, color='red') # 64
s5=plt.scatter(r_score5, s_score5, color='black') # 68
s6=plt.scatter(r_score6, s_score6, color='yellow') # 234
s7=plt.scatter(r_score7, s_score7, color='green') # 237

# 6 26 33 64 68 234 237
plt.xticks([0,0.2,0.4,0.6,0.8,1.0],fontsize=20)
plt.yticks([0.8,0.85,0.9,0.95,1.0],fontsize=20)
font = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 20,
        }
plt.xlabel("Residue Score",fontdict=font)
plt.ylabel("Similarity Score",fontdict=font)
plt.rcParams.update({'font.size': 16})
plt.legend((s1,s2,s3,s4,s5,s6,s7),('1','2','3','4','5','6','7') ,loc = 'lower left')
plt.tight_layout()
plt.savefig(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_c\fig6_c.png')
plt.show()
