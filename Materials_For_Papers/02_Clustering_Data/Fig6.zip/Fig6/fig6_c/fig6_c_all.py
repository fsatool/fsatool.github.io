# coding=utf-8
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
plt.figure(figsize=(13/2,9/2))
f=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_c\residue_score_and_similarity_score.txt')
line = " "
r_score1=[]
s_score1=[]

# 6 26 33 64 68 234 237
while line:  # 直到读取完文件
    line = f.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0):
        r_score1.append(float(splitline[2]))
        s_score1.append(float(splitline[3]))
f.close()  # 关闭文件


s1=plt.scatter(r_score1, s_score1, color='blue')  # 6


# 6 26 33 64 68 234 237
plt.xticks([0,0.2,0.4,0.6,0.8,1.0],fontsize=20)
plt.yticks([0.8,0.85,0.9,0.95,1.0],fontsize=20)
font = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 20,
        }
plt.xlabel("Residue Score",fontdict=font)
plt.ylabel("Similarity Score",fontdict=font)
plt.rcParams.update({'font.size': 16})
#plt.legend((s1,s2,s3,s4,s5,s6,s7),('1','2','3','4','5','6','7') ,loc = 'lower left')
plt.tight_layout()
plt.savefig(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_c\fig6_c_all.png')
plt.show()
