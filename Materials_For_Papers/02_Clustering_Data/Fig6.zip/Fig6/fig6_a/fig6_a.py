# coding=utf-8
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
plt.figure(figsize=(12.60/2,9/2))
f1=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\colvar_6.txt')
line = " "
rmsd1=[]
y1=[]
while line:  # 直到读取完文件
    line = f1.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 ):
        rmsd1.append(float(splitline[1]))
        y1.append(float(splitline[2]))
f1.close()  # 关闭文件

f2=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\colvar_26.txt')
line = " "
rmsd2=[]
y2=[]
while line:  # 直到读取完文件
    line = f2.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 ):
        rmsd2.append(float(splitline[1]))
        y2.append(float(splitline[2]))
f2.close()  # 关闭文件

f3=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\colvar_33.txt')
line = " "
rmsd3=[]
y3=[]
while line:  # 直到读取完文件
    line = f3.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 ):
        rmsd3.append(float(splitline[1]))
        y3.append(float(splitline[2]))
f3.close()  # 关闭文件

f4=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\colvar_64.txt')  
line = " "
rmsd4=[]
y4=[]
while line:  # 直到读取完文件
    line = f4.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 ):
        rmsd4.append(float(splitline[1]))
        y4.append(float(splitline[2]))
f4.close()  # 关闭文件

f5=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\colvar_68.txt')
line = " "
rmsd5=[]
y5=[]
while line:  # 直到读取完文件
    line = f5.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 ):
        rmsd5.append(float(splitline[1]))
        y5.append(float(splitline[2]))
f5.close()  # 关闭文件

f6=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\colvar_234.txt')
line = " "
rmsd6=[]
y6=[]
while line:  # 直到读取完文件
    line = f6.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 ):
        rmsd6.append(float(splitline[1]))
        y6.append(float(splitline[2]))
f6.close()  # 关闭文件

f7=open(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\colvar_237.txt')
line = " "
rmsd7=[]
y7=[]
while line:  # 直到读取完文件
    line = f7.readline().strip()  # 读取一行文件
    splitline = line.split() # 按空格切割
    if(len(splitline) > 0 ):
        rmsd7.append(float(splitline[1]))
        y7.append(float(splitline[2]))
f7.close()  # 关闭文件


s1=plt.scatter(rmsd1, y1, color='blue')  # 6
s2=plt.scatter(rmsd2, y2, color='cyan') # 26
s3=plt.scatter(rmsd3, y3, color='magenta') # 33
s4=plt.scatter(rmsd4, y4, color='red') # 64
s5=plt.scatter(rmsd5, y5, color='black') # 68
s6=plt.scatter(rmsd6, y6, color='yellow') # 234
s7=plt.scatter(rmsd7, y7, color='green') # 237

# 6 26 33 64 68 234 237
plt.xticks([0,4,8,12,16],fontsize=20)
plt.yticks([3,6,9,12,15,18],fontsize=20)
font = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 20,
        }
plt.xlabel("RMSD(Å)",fontdict=font)
plt.ylabel("Rg of Hydrophobic Core(Å)",fontdict=font)
#plt.legend((s1,s2,s3,s4,s5,s6,s7),('1','2','3','4','5','6','7') ,loc = 'lower left')
plt.tight_layout()
plt.savefig(r'C:\Users\junyong\Desktop\all\paper\plot\Fig6\fig6_a\fig6_a.png')
plt.show()
