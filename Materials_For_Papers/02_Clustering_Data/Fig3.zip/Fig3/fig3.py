import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from matplotlib import ticker
import numpy as np
# 3. 320cluster_32pick_nsnap_1/2GPU_SP/DP
data = np.genfromtxt("data3.txt",dtype=[int, float, float, float,float])  # 将文件中数据加载到data数组里
x_axis_data = np.zeros(len(data))
y_axis_data1 = np.zeros(len(data))
y_axis_data2 = np.zeros(len(data))
y_axis_data3 = np.zeros(len(data))
y_axis_data4 = np.zeros(len(data))
for i in range(len(data)):
    x_axis_data[i]=data[i][0]
    y_axis_data1[i]=data[i][1]
    y_axis_data2[i]=data[i][2]
    y_axis_data3[i]=data[i][3]
    y_axis_data4[i]=data[i][4]

x_major_locator = MultipleLocator(200000)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
formatter = ticker.ScalarFormatter(useMathText=True)
formatter.set_scientific(True)
formatter.set_powerlimits((0,0))
ax.xaxis.set_major_formatter(formatter)

plt.plot(x_axis_data, y_axis_data1, 'k^', linestyle='-', alpha=0.5, linewidth=2, label='1GPU+DP')
plt.plot(x_axis_data, y_axis_data2, 'bo', linestyle='-.', alpha=0.5, linewidth=2, label='2GPU+DP')
plt.plot(x_axis_data, y_axis_data3, 'rs', linestyle='--', alpha=0.5, linewidth=2, label='1GPU+SP')
plt.plot(x_axis_data, y_axis_data4, 'gD', linestyle=':', alpha=0.5, linewidth=2, label='2GPU+SP')
plt.ylim(0, 10)
plt.xlim(0, 1500000)

ax.xaxis.get_offset_text().set_fontsize(15)
# 2.4 坐标轴刻度字体颜色设置
plt.tick_params(axis='x',
                 labelsize=12, # y轴字体大小设置
                 direction='in' # y轴标签方向设置
                  )
plt.tick_params(axis='y',
                 labelsize=12, # y轴字体大小设置
                 direction='in' # y轴标签方向设置
                  )

plt.legend()  #显示上面的label
# plt.xlabel('Total Snapshots'+'$ \mathit{/10}^{4}$', fontsize = 12)
plt.xlabel('Total Snapshots', fontsize = 15)
plt.ylabel('Clustering Time (sec)', fontsize = 15)
plt.show()
