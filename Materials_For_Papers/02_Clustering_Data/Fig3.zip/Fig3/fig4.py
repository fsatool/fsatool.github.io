import matplotlib.pyplot as plt
import numpy as np
data = np.genfromtxt(r"C:\Users\junyong\Desktop\all\paper\plot\Fig4\data4_1.txt",dtype=[int, float, float, float, float, float, float, float, float, float, float])  # 将文件中数据加载到data数组里
data2 = np.genfromtxt(r"C:\Users\junyong\Desktop\all\paper\plot\Fig4\data4_2.txt",dtype=[int, float, float, float, float, float, float, float, float, float, float])  # 将文件中数据加载到data数组里
x = np.zeros(len(data))
y1 = np.zeros(len(data))
y2 = np.zeros(len(data2))
std_err= np.zeros(len(data))
for i in range(len(data)):
    x[i]=data[i][0]
    tpy1=np.zeros(10)
    tpy2=np.zeros(10)
    for j in range(10):
        tpy1[j]=data[i][j+1]
        tpy2[j]=data2[i][j+1]
    y1[i]=np.average(tpy1)
    y2[i]=np.average(tpy2)
    std_err[i]=np.std(tpy1)
#plt.figure(figsize=(13/2.54, 10/2.54))
fig=plt.figure(figsize=(13, 10))

print(y1[1])
print(y1[10])
# 画柱形图
ax1 = fig.add_subplot(111)
ax1.set_ylim([0, 7])
ax1.set_ylabel("Clustering Time (sec)",fontsize=25)
ax1.set_xlabel("No. of Test Centers",fontsize=25)
ax1.tick_params(labelsize=25)
error_params=dict(elinewidth=5,ecolor='k',capsize=10)#设置误差标记参数
#绘制柱状图，设置误差标记以及柱状图标签
color=[]
for i in range(len(y1)):
    color.append('orange')
_bars_=ax1.bar(x,y1,color=color,yerr=std_err,error_kw=error_params,\
                    tick_label=['32 (first)','32', '64','96','128', '160', '192', '224', '256', '288', '320'])

# 画折线图
ax2 = ax1.twinx()  # 组合图必须加这个
ax2.set_ylim([0, 0.7])      
ax2.set_ylabel("RSI Score",fontsize=25)
ax2.tick_params(labelsize=25)
_lines_,=ax2.plot(x, y2, 'r', ms=10, lw=3, marker='o') # 设置线粗细，节点样式

lns = [_bars_,_lines_]
labels = [l.get_label() for l in lns]
ax1.legend(lns,['Clustering Time',"RSI Score"],loc='upper left',prop = {'size':20})

plt.tight_layout()
plt.savefig(r'C:\Users\junyong\Desktop\all\paper\plot\Fig4\fig4.png')


