import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from matplotlib import ticker
import numpy as np
#2. 320cluster_32pick_nsnap
data = np.genfromtxt("data2_b.txt",dtype=[int, float, float, float])  # 将文件中数据加载到data数组里
x_axis_data = np.zeros(len(data))
y_axis_data1 = np.zeros(len(data))
y_axis_data2 = np.zeros(len(data))
y_axis_data2_2 = np.zeros(len(data))
for i in range(len(data)):
    x_axis_data[i]=data[i][0]
    y_axis_data1[i]=data[i][1]
    y_axis_data2[i]=data[i][2]
    y_axis_data2_2[i]=data[i][3]
for i in range(0, len(y_axis_data1)):
    y_axis_data1[i] = 1 / y_axis_data1[i]
    y_axis_data2[i] = 1 / y_axis_data2[i]
# 创建一个图形和两个y轴
fig, ax1 = plt.subplots()
ax2 = ax1
ax3 = ax1.twinx()
x_major_locator = MultipleLocator(200000)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
formatter = ticker.ScalarFormatter(useMathText=True)
formatter.set_scientific(True)
formatter.set_powerlimits((0,0))
ax.xaxis.set_major_formatter(formatter)
ax1.set_ylim(0.001,15)
#绘制折线图
line1 = ax1.semilogy(x_axis_data, y_axis_data1,'bs', linestyle='-', alpha=1, linewidth=2, label='CPU')
line2 = ax2.semilogy(x_axis_data, y_axis_data2, 'k^', linestyle='--', alpha=1, linewidth=2, label='GPU')
line3 = ax3.plot(x_axis_data, y_axis_data2_2, 'ro', linestyle=':', alpha=1, linewidth=2, label='Speed Up')

# 设置x轴和y轴的标签，指明坐标含义
ax1.set_xlabel('Total Snapshots', fontdict={'size': 15})
ax1.set_ylabel('Clustering Speed (step/sec)',fontdict={'size': 15})
ax3.set_ylabel('Speed Up',fontdict={'size': 15})
plt.ylim(0,1400)
plt.xlim(0,1450000)
#添加图表题
# plt.title('双y轴折线图')
#添加图例
lines = line1 + line2 + line3
labels = [h.get_label() for h in lines]
plt.legend(lines, labels, loc = 'upper right')

 # 2.3 坐标轴刻度字体设置
ax1.xaxis.get_offset_text().set_fontsize(15)
x1_label = ax1.get_xticklabels()
[x1_label_temp.set_fontname('Times New Roman') for x1_label_temp in x1_label]
y1_label = ax1.get_yticklabels()
[y1_label_temp.set_fontname('Times New Roman') for y1_label_temp in y1_label]

y2_label = ax3.get_yticklabels()
[y2_label_temp.set_fontname('Times New Roman') for y2_label_temp in y2_label]
# 2.4 坐标轴刻度字体颜色设置
ax1.tick_params(axis='y',
                 labelsize=15, # y轴字体大小设置
                 direction='in' # y轴标签方向设置
                  )
ax1.tick_params(axis='x',
                 labelsize=15, # y轴字体大小设置
                 direction='in' # y轴标签方向设置
                  )
ax3.tick_params(axis='y',
                 labelsize=15, # y轴字体大小设置
                 direction='in' # y轴标签方向设置
                  )
#展示图片
plt.show()


