import numpy as np
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from matplotlib import ticker
import matplotlib as mpl
plt.rc('font',family='Times New Roman')

files = ['freeenergy']
lim = np.zeros((4,2,2))
vmin = np.array([-5.2])
vmax = np.zeros([1])

plt.figure(figsize=(13/2.54,9/2.54))
#plt.subplots_adjust(wspace=0.08,hspace=0.2)

for i in range(1):
    data = np.loadtxt(files[i]+'.txt')
    num = int(np.sqrt(data.shape[0]))
    
    lim[i][0][0] = np.min(data[:,2])
    lim[i][0][1] = np.max(data[:,2])
    lim[i][1][0] = np.min(data[:,3])
    lim[i][1][1] = np.max(data[:,3])

    freeeg = data[:,0].reshape(num,num)
    x = data[:,2].reshape(num,num)
    xticks = x[0]
    y = data[:,3].reshape(num,num)
    yticks = y[:,0]
    levels = np.linspace(vmin[i],vmax[i],100)
    plt.contourf(xticks,yticks,freeeg,levels,cmap='nipy_spectral',vmin=vmin[i],vmax=vmax[i],extend = 'min')
    
    cbar = plt.colorbar()
    ticks = np.around(np.linspace(vmin[i],vmax[i],6),0)
    cbar.set_ticks(ticks)
    cbar.ax.tick_params(labelsize=20)
    plt.xlabel("RMSD ($\mathrm{\AA}$)",fontsize=20,labelpad=0.0)
    plt.ylabel("No. of Native Contacts",fontsize=20)
    plt.xticks(fontsize=20)
    plt.yticks(fontsize=20)
    x_major_locator = MultipleLocator(3)
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)

    plt.ylim(0, 15.5)

plt.savefig('fig2_b.png',bbox_inches='tight',pad_inches=0.1)
plt.savefig('fig2_b.eps',bbox_inches='tight',pad_inches=0.1)